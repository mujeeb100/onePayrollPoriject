// import React from 'react'

function Services() {
  return (
    <section id="services" className="services">
  <div className="container" data-aos="fade-up">
  <div className="section-title">
    <h2>Why Choose Elite Workforce Services Intl?</h2>
    <p className="mt-3">
        Choose Elite Workforce Services Intl for a partnership that goes beyond traditional manpower solutions, delivering excellence at every step of the journey. Your success is our priority, and we look forward to contributing to the growth and prosperity of your organization.
      </p>
  </div>

  <div className="row">
    <div className="col-md-6 d-flex align-items-stretch" data-aos="fade-up" data-aos-delay="100">
      <div className="icon-box">
        <i className="bi bi-card-checklist"></i>
        <h4><a href="#">Expertise</a></h4>
        <p>Backed by a team of seasoned professionals, we bring a wealth of experience in the intricacies of manpower consulting and related services.</p>
      </div>
    </div>
    <div className="col-md-6 d-flex align-items-stretch mt-4 mt-md-0" data-aos="fade-up" data-aos-delay="200">
      <div className="icon-box">
        <i className="bi bi-bar-chart"></i>
        <h4><a href="#">Client-Centric Approach</a></h4>
        <p>Our commitment to client satisfaction is unwavering. We tailor our services to meet the unique needs of each client,
           ensuring a personalized and efficient experience.</p>
      </div>
    </div>
    <div className="col-md-6 d-flex align-items-stretch mt-4 mt-md-0" data-aos="fade-up" data-aos-delay="300">
      <div className="icon-box">
        <i className="bi bi-binoculars"></i>
        <h4><a href="#">Compliance</a></h4>
        <p>We understand the importance of compliance in the realm of international workforce management. Our processes adhere to the latest regulations, providing you with peace of mind.</p>
      </div>
    </div>
    <div className="col-md-6 d-flex align-items-stretch mt-4 mt-md-0" data-aos="fade-up" data-aos-delay="400">
      <div className="icon-box">
        <i className="bi bi-brightness-high"></i>
        <h4><a href="#">Global Network</a></h4>
        <p>With a strong network and presence in Saudi Arabia, Oman, Qatar, and Kuwait, we have the reach to connect you with the right talent and facilitate seamless operations across borders.</p>
      </div>
    </div>
  
    {/* <div className="col-md-6 d-flex align-items-stretch mt-4 mt-md-0" data-aos="fade-up" data-aos-delay="500">
      <div className="icon-box">
        <i className="bi bi-calendar4-week"></i>
        <h4><a href="#">Magni Dolore</a></h4>
        <p>At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque</p>
      </div>
    </div>
    <div className="col-md-6 d-flex align-items-stretch mt-4 mt-md-0" data-aos="fade-up" data-aos-delay="600">
      <div className="icon-box">
        <i className="bi bi-briefcase"></i>
        <h4><a href="#">Eiusmod Tempor</a></h4>
        <p>Et harum quidem rerum facilis est et expedita distinctio. Nam libero tempore, cum soluta nobis est eligendi</p>
      </div>
    </div> */}
  </div>
  
</div>

  </section>
  )
}

export default Services