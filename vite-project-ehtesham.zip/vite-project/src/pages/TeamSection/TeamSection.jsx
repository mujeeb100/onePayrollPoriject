// import React from 'react'

function TeamSection() {
  return (
    <section id="team" className="team section-bg">
      <div className="container" data-aos="fade-up">
  <div className="section-title">
    <h2>Our Services</h2>
    <p>
      As a multi-service company, we specialize in providing key solutions to streamline your business processes and support workforce transitions. Our expertise spans across several critical areas:
    </p>
  </div>
  <div className="row content">
    <div className="col-lg-6">
      <ul>
        <li>
          <i className="ri-check-double-line"></i> 
          <strong>Manpower Consultant:</strong> We ensure the recruitment process is streamlined, identifying and placing the right talent to meet your organization's unique needs.
        </li>
        <li>
          <i className="ri-check-double-line"></i> 
          <strong>Attestation Services:</strong> We offer comprehensive attestation services, ensuring that your documents are legally recognized, facilitating a smooth transition for your employees.
        </li>
        <li>
          <i className="ri-check-double-line"></i> 
          <strong>Ticketing Services:</strong> Our ticketing services ensure efficient and cost-effective travel arrangements, allowing your employees to reach their destinations hassle-free.
        </li>
      </ul>
    </div>
    <div className="col-lg-6 pt-4 pt-lg-0">
      <ul>
        <li>
          <i className="ri-check-double-line"></i> 
          <strong>Emigration Services:</strong> We handle all necessary documentation and procedures for emigration, making the transition to a new work environment as seamless as possible.
        </li>
        <li>
          <i className="ri-check-double-line"></i> 
          <strong>Employment/Work Visa Stamping for Kuwait & Saudi Arabia:</strong> Our experienced team ensures that all visa stamping procedures are completed accurately and efficiently for Kuwait and Saudi Arabia.
        </li>
      </ul>
      <a href="#" className="btn-learn-more">Learn More</a>
    </div>
  </div>
</div>
</section>
   
  )
}

export default TeamSection

