# OnePayroll

## Local Setup

1. Create an `.env` file with the required values.


---
## Commit message format

```
[type]: [commit message]
```

type must be one of the following:


- `build`: Indicates changes that affect the build system or external dependencies.

- `chore`: Indicates changes that are done to housekeeping tasks in the repository, such as updating dependencies, formatting code, etc.

- `ci`: Indicates changes that affect the continuous integration (CI) pipeline or release process.

- `docs`: Indicates changes that are related to documentation, such as adding or updating user guides, code documentation, etc.

- `feat`: Indicates new features or capabilities that have been added to the project.

- `fix`: Indicates bug fixes or changes that correct existing code.

- `perf`: Indicates changes that improve the performance of the codebase.

- `refactor`: Indicates changes that involve code refactoring, restructuring, or cleanup without changing the functionality.

- `revert`: Indicates that a previous commit is being reverted.

- `style`: Indicates changes that do not change the functionality of the codebase, but affect the appearance of the code, such as formatting or linting.

- `test`: Indicates that the commit contains changes related to a test suite, such as adding new test cases, updating existing tests, or fixing failing tests.

---
## Naming Convention

- `Folder`: hyphen (eg. new-folder).

- `File`: underscore (eg. new_file).

- `React Components`: pascal (eg. NewComponent).

- `General functions`: camelcase (eg. newFunction).

- `Variables/Parameters`: camelCase (eg. newVariable).
---

---
Npm packages used:

- Run vsts-npm-auth to get an Azure Artifacts token added to your user-level .npmrc file

```
npm install -g vsts-npm-auth
vsts-npm-auth -config .npmrc
```
- Note: You don't need to do this every time. npm will give you a 401 Unauthorized error when you need to run it again.

## Storybook

https://6057b40e43ab64002195bec3-ghzwkbbfxv.chromatic.com/

---

## Stack

![React](https://img.shields.io/badge/React-20232A?style=for-the-badge&logo=react&logoColor=61DAFB)

![Storybook](https://img.shields.io/badge/Storybook-FF4785?style=for-the-badge&logo=storybook&logoColor=white)

![TailwindCSS](https://img.shields.io/badge/Tailwind_CSS-38B2AC?style=for-the-badge&logo=tailwind-css&logoColor=white)

![TypeScript](https://img.shields.io/badge/TypeScript-007ACC?style=for-the-badge&logo=typescript&logoColor=white)
