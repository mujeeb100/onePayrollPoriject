export type ProtectedRouteProps = {
    permission: string
    redirectPath: string
    children: React.ReactElement | null

  }
