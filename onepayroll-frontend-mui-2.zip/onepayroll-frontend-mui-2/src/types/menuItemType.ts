import * as React from 'react'

export type MainMenuType = {
  title: string;
  icon?: React.ReactElement;
  path: string;
  event: () => void;
  onClick: () => void;
  permission: string;
  active: boolean;
  expanded?: boolean;
  subTitle?: string;
  children?: MainMenuType[];
  key: string;
};
