export type RouteCompMapping = {
  path: string
  permission?: string
  component: any
}
