export type permissionType = string[]
