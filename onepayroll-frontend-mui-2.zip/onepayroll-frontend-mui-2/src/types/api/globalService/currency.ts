export type CreateCurrency = {
  body: {
    currencyCode: string,
    currencyName: string,
    currencySymbol: string,
  },
}

export type UpdateCurrency = {
  body: {
    id: string,
    currencyCode: string,
    currencyName: string,
    currencySymbol: string,
  }
}

export type CreateCountry = {
  countryCode: string,
  countryName: string,
}

export type UpdateCountry = {
  id: string,
  countryCode: string,
  countryName: string,
}

export type CreateNationality = {
  nationalityCode: string,
  nationalityName: string,
}

export type UpdateNationality = {
  id: string,
  nationalityCode: string,
  nationalityName: string,
}
export type CreatePaymentMethod = {
    paymentMethodCode: string,
    paymentMethodName: string,
    countryLocalization: string,
    remarks: string,
}
