import { MainMenuType } from './menuItemType'

type TRoleTypes = { id: string, roleCode: number, roleName: string, roleType: boolean, remarks?: string, userCount?: number}
// service provider
type TProviderType = { id: string, providerCode: string, providerName: string, providerType: string, remarks: string, status: boolean }
type EntityType= {
  id: string,
  clientGroupCode: string,
  clientGroupName: string,
  entityCode: string,
  entityName: string,
  countryLocalization?:string,
  url?: string,
  region?: string,
  requestedBy?: string,
  status?: boolean,
  role?: TRoleTypes,
}

type EntityIRDType = {
  corporateTitleCode: string
  corporateTitleName: string
  remarks: string
}

export type {
  EntityIRDType,
  EntityType, MainMenuType,
  TProviderType,
  TRoleTypes,
}

export type AccountActionHandlerType = 'edit_user_account' | 'duplicate_user_access' | 'deactivate_user_account' | 'delete_user_account' | 'edit_user_modal' | 'activate_user_account'
export type PayCycleStatus = 'Finalized' | 'Unfinalized' | 'Locked' | 'Unlocked' | 'PF Dropped' | 'Open' | 'Inactive' | 'Completed'

export type EmployeeSnapshot = {
  employeeCode: string
  employeeProfile: {
    surname: string,
    givenName: string
    displayName: string
  }
}

export type DropDownOption = {
  roleCode: string,
  roleName: string
}
