export type selectLangItemType = {
    active: boolean
    title: string
    locale: string
    onClick?: any
}

export type itemList = selectLangItemType[]

export type selectLangStateType = {
    langListItems: itemList,
    selectedLang: string
    title: string
}
