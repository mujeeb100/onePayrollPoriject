import { formatedDate } from 'utils'

export const defaultconst: any = {}
export const DRAWER_WIDTH = 240
export const entityId = ''
export const CHINESE_TITLE = '中文（简体）'
export const ENGLISH_TITLE = 'English'
export const LOCALE_ENGLISH = 'en'
export const LOCALE_CHINESE = 'zh'
// contant for OPRAlert
export const DEFAULT_VERTICAL = 'top'
export const DEFAULT_HORIZONTAL = 'right'
export const USER_ROLE_TYPES_PLACEHOLDER = 'User role types'
export const DEFAULT_AUTO_HIDE_DURATION = 6000 //  the autoHideDuration here
export const USER_ROLES_STEPS = [
  'userRoles_progress_step_user_role_information',
  'userRoles_progress_step_access_matrix',
  'userRoles_progress_step_confirmation',
]
export const COL_HEADER_CORPORATE_TITLE_CODE = 'Corporate Title Code'
export const COL_HEADER_CORPORATE_TITLE_NAME = 'Corporate Title Name'
export const COL_HEADER_REMARKS = 'Remarks'
export const ENTITY_IRD = 'IRD'
export const COMP_BANK_ACCT_TITLE = 'Company Bank Account'

export const employeeQuartersNature = [
  {
    name: 'FLAT',
    value: 'FLAT',
  },
  {
    name: 'HOUSE',
    value: 'HOUSE',
  },
  {
    name: 'SERVICE APARTMENT',
    value: 'SERVICE APARTMENT',
  },
  {
    name: '1 ROOM HOTEL',
    value: '1 ROOM HOTEL',
  },
  {
    name: '2 ROOMS HOTEL',
    value: '2 ROOMS HOTEL',
  },
]

export const employeeQuartersStatus = [
  {
    name: 'Active',
    value: 'Active',
  },
  {
    name: 'Inactive',
    value: 'Inactive',
  },
]

export const employeePensionFundStatus = [{ name: 'Active', value: 'Active' }, { name: 'Suspended in Calculation', value: 'Suspended in Calculation' }, { name: 'Terminated', value: 'Terminated' }, { name: 'Hold for Intergroup Transfer (Show Termination Date)', value: 'Hold for Intergroup Transfer (Show Termination Date)' }, { name: 'Hold for Intergroup Transfer (Don\'t Show Termination Date)', value: 'Hold for Intergroup Transfer (Don\'t Show Termination Date)' }]
export const employeeSchemeTerminationCode = [{ name: 'Hong Kong', value: 'Hong Kong' }, { name: 'Malaysia', value: 'Malaysia' }, { name: 'Singapore', value: 'Singapore' }]
export const employeeIdentityType = [{ name: 'HKID', value: 'HKID' }, { name: 'Passport', value: 'Passport' }]
export const employeeTransferCode = [{ name: '0', value: 'false' }, { name: '1', value: 'true' }]
export const employeeLongService = [{ name: ' Long Service', value: 'L' }, { name: 'Severence Pay', value: 'S' }]
export function isEmpty(value:any) {
  return (value == null || (typeof value === 'string' && value.trim().length === 0))
}

export const customeDateFormat = (date:any) => {
  if (date) {
    const t = new Date(date)
    const y = t.getFullYear()
    const m = (`0${t.getMonth() + 1}`).slice(-2)
    const d = (`0${t.getDate()}`).slice(-2)
    return `${m}/${d}/${y}`
  }
  return null
}

export const customeHyphenDateFormat = (date:any) => {
  const t = new Date(date)
  const y = t.getFullYear()
  const m = (`0${t.getMonth() + 1}`).slice(-2)
  const d = (`0${t.getDate()}`).slice(-2)
  return `${y}-${m}-${d}`
}

export const displayFormatDate = (date:any) => {
  const d = new Date(date)
  const ye = new Intl.DateTimeFormat('en', { year: 'numeric' }).format(d)
  const mo = new Intl.DateTimeFormat('en', { month: 'short' }).format(d)
  const da = new Intl.DateTimeFormat('en', { day: '2-digit' }).format(d)
  return `${da} ${mo} ${ye}`
}
export const displayFormatDateTime = (date:any) => formatedDate(date)

export const defaultPageSize = {
  pageSize: 10000,
}

export const reportCodeType = {
  ACR: 'ACR', // Annual Compensation Report
  AUTRA: 'AUTRA', // Audit Trail
  CUST: 'CUST', // Custom Report
  EAO: 'EAO', // EAO Wages Report
  HKTR: 'HKTR', // HK Tax Reporting
  ORSO: 'ORSO', // ORSO Contribution Listing
  PASP: 'PASP', // Payslip
  PASR: 'PASR', // Payment Summary Report
  PCREE: 'PCREE', // Payroll Comparison Report by Employee
  PCRPI: 'PCRPI', // Payroll Comparison Report by Pay Item
  PFRS: 'PFRS', // MPF Remittance Statement
  PSR: 'PSR', // Payroll Summary Report
  PSRCC: 'PSRCC', // Payroll Summary Report by Charge Cost Center
  PSRMC: 'PSRMC', // Payroll Summary Report by Cost Center
}

export const isEmailAddress = (email: string|null|undefined) => {
  if (email) {
    const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
    return re.test(email)
  }
  return false
}
