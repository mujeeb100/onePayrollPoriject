export const IRD_ENTITY_VALIDATION = {
  corporateTitleCode: {
    SPACE_VALIDATION: /^[^\s]*$/, // This allows all chars except space
    CHAR_LIMIT: /^[^\s]{0,40}$/, // Allows only 10 characters
  },
  corporateTitleName: {
    CHAR_LIMIT: /^.{1,120}$/, // Allows only 120 characters
  },
  remarks: {
    CHAR_LIMIT: /^.{0,500}$/, // ALlows all characters up-to 500 chars
  },
}

export const DEPT_ENTITY_VALIDATION = {
  departmentCode: {
    REQUIRED: /^$/,
    SPACE_VALIDATION: /^[^\s]*$/,
    CHAR_LIMIT: /^[^\s]{0,40}$/, // Allows only 10 characters
  },
  departmentDescription: {
    CHAR_LIMIT: /^.{1,120}$/, // Allows only 120 characters
  },
  remarks: {
    CHAR_LIMIT: /^.{0,500}$/, // ALlows all characters up-to 500 chars
  },
}

export const COST_ENTITY_VALIDATION = {
  costCenterCode: {
    REQUIRED: /^$/,
    SPACE_VALIDATION: /^[^\s]*$/,
    CHAR_LIMIT: /^[^\s]{0,40}$/, // Allows only 10 characters
  },
  costCenterDescription: {
    CHAR_LIMIT: /^.{1,120}$/, // Allows only 120 characters
  },
  remarks: {
    CHAR_LIMIT: /^.{0,500}$/, // ALlows all characters up-to 500 chars
  },
}

export const CLIENT_GROUP_ENTITY_VALIDATION = {
  entityCode: {
    REQUIRED: /^$/,
    SPACE_VALIDATION: /^[^\s]*$/,
    CHAR_LIMIT: /^[^\s]{0,30}$/, // Allows only 30 characters
  },
  entityName: {
    CHAR_LIMIT: /^.{1,120}$/, // Allows only 120 characters
  },
}

export const SETTING_VALIDATION = {
  settingCode: {
    REQUIRED: /^$/,
    SPACE_VALIDATION: /^[^\s]*$/,
    CHAR_LIMIT: /^[^\s]{0,60}$/, // Allows only 60 characters
  },
  settingName: {
    CHAR_LIMIT: /^.{1,120}$/, // Allows only 120 characters
  },
  category: {
    CHAR_LIMIT: /^.{1,60}$/, // Allows only 60 characters
  },
}

export const COMP_BANK_ACCT_VALIDATION = {
  companyBankAccountCode: {
    SPACE_VALIDATION: /^[^\s]*$/,
    CHAR_LIMIT: /^[^\s]{1,30}$/, // Allows only 10 characters
  },
  companyBankAccountDescription: {
    CHAR_LIMIT: /^.{1,120}$/, // Allows only 120 characters
  },
  bankCode: {
    SPACE_VALIDATION: /^[^\s]*$/,
    ALLOW_ONLY_NUMS: /^\d+$/,
    CHAR_LIMIT: /^.{1,15}$/, // Allows only 120 characters
  },
  branchCode: {
    SPACE_VALIDATION: /^[^\s]*$/,
    ALLOW_ONLY_NUMS: /^\d+$/, // Allow only numbers. No space/alpha
    CHAR_LIMIT: /^.{1,15}$/, // Allows only 120 characters
  },
  accountNumber: {
    SPACE_VALIDATION: /^[^\s]*$/,
    ALLOW_ONLY_NUMS: /^\d+$/,
    CHAR_LIMIT: /^.{1,35}$/,
  },
  bankReference: {
    CHAR_LIMIT: /^.{1,70}$/,
  },
  swiftCode: {
    SPACE_VALIDATION: /^[^\s]*$/,
    ALLOW_NUMS_CHARS_UC: /^[A-Z0-9]+$/,
    CHAR_LIMIT: /^.{1,11}$/, // Allows only 120 characters
  },
  hsbcmriPlanCode: {
    CHAR_LIMIT: /^.{1,1}$/, // Allows only 120 characters
  },
  hsbcmriPaymentCode: {
    ALLOW_NUMS_CHARS: /^[A-Za-z0-9]+$/,
    CHAR_LIMIT: /^.{1,3}$/, // Allows only 120 characters
  },
  hsbcifilehsbcNetCustomerID: {
    ALLOW_NUMS_CHARS: /^[A-Za-z0-9]+$/,
    CHAR_LIMIT: /^.{1,18}$/, // Allows only 120 characters
  },
  hsbcifileFileReference: {
    ALLOW_NUMS_CHARS: /^[A-Za-z0-9]+$/,
    CHAR_LIMIT: /^.{1,35}$/, // Allows only 120 characters
  },
  hsbcifilePaymentCode: {
    ALLOW_NUMS_CHARS: /^[A-Za-z0-9]+$/,
    CHAR_LIMIT: /^.{1,30}$/, // Allows only 120 characters
  },
  compBankAcctCurrency: {
    DEFAULT_VAL: '',
  },
  hsbcbiaSuffix: {
    // should allow only numbers
    ALLOW_ONLY_NUMS: /^\d+$/,
    CHAR_LIMIT: /^.{1,3}$/, // Allows only 3 characters
    // Should not allow white space
    SPACE_VALIDATION: /^[^\s]*$/,
  },
  hsbcbiaAccountType: {
    CHAR_LIMIT: /^.{1,2}$/, // Allows only 3 characters
    // Should not allow white space
    SPACE_VALIDATION: /^[^\s]*$/,
  },
}

export const ENTITY_SETTING_VALIDATION = {
  settingCode: {
    SPACE_VALIDATION: /^[^\s]*$/,
    CHAR_LIMIT: /^[^\s]{0,60}$/,
  },
  settingName: {
    CHAR_LIMIT: /^.{1,120}$/,
  },
  category: {
    CHAR_LIMIT: /^.{1,60}$/,
  },
  settingValue: {
    CHAR_LIMIT: /^.{1,60}$/,
  },
  remarks: {
    CHAR_LIMIT: /^.{0,500}$/,
  },
}

export const PAYROLL_VALIDATION = {
  payGroupCode: {
    SPACE_VALIDATION: /^[^\s]*$/, // This allows all chars except space
    CHAR_LIMIT: /^.{1,10}$/, // Allows only 10 characters
  },
  payGroupName: {
    SPACE_VALIDATION: /^[^\s]*$/, // This allows all chars except space
    CHAR_LIMIT: /^.{1,120}$/, // Allows only 120 characters
  },
  payCycleName: {
    CHAR_LIMIT: /^.{1,120}$/, // Allows only 120 characters
  },
  remarks: {
    CHAR_LIMIT: /^.{0,500}$/, // Allows only 500 characters
  },
}

export const PAYCYCLE_VALIDATION = {
  startingDateForRecurringYear: {
    SPACE_VALIDATION: /^[^\s]*$/, // This allows all chars except space
    CHAR_TYPE_AND_LIMIT: /^[0-9]{4}$/, // Allows exactly 4 numbers
  },
}

export const PAYMENT_METHOD_VALIDATION = {
  paymentMethodCode: {
    REQUIRED: /^$/,
    SPACE_VALIDATION: /^[^\s]*$/,
    CHAR_LIMIT: /^[^\s]{0,40}$/, // Allows only 40 characters
  },
  paymentMethodName: {
    CHAR_LIMIT: /^.{1,120}$/, // Allows only 120 characters
  },
}

export const ENTITY_CURRENCY_EXCHANGE_VALIDATION = {
  exchangeRate: {
    ALLOW_ONLY_NUMS: /^\d{1,9}(\.\d{1,6})?$/, // Allows only 9 digits before decimal and 6 digits after decimal
    SPACE_VALIDATION: /^[^\s]*$/, // This allows all chars except space
  },
}

export const ENTITY_PENS_FUND_SCHEME_VALIDATION = {
  pensionFundSchemeCode: {
    SPACE_VALIDATION: /^[^\s]*$/,
    CHAR_LIMIT: /^[^\s]{1,30}$/, // Allows only 20 characters
  },
  schemeDescription: {
    CHAR_LIMIT: /^.{1,500}$/, // Allows only 120 characters
  },
  serviceProviderCode: {
    CHAR_LIMIT: /^[^\s]{0,20}$/,
  },
  schemeType: {
    CHAR_LIMIT: /^[^\s]{0,20}$/,
  },
  remarks: {
    CHAR_LIMIT: /^.{0,500}$/,
  },
  schemeFileNumber: {
    CHAR_LIMIT: /^.{0,20}$/,
  },
  subSchemeFileNumber: {
    CHAR_LIMIT: /^[^\s]{0,20}$/,
  },
  contributionCycle: {
    CHAR_LIMIT: /^[^\s]{0,20}$/,
  },
  participationNumber: {
    CHAR_LIMIT: /^[^\s]{0,20}$/,
  },
  referenceNumber: {
    CHAR_LIMIT: /^[^\s]{0,20}$/,
  },
  memberClass: {
    CHAR_LIMIT: /^[^\s]{0,20}$/,
  },
  paymentMethod: {
    CHAR_LIMIT: /^[^\s]{0,5}$/,
  },
  payCentre: {
    CHAR_LIMIT: /^[^\s]{0,4}$/,
  },
  showRelevantIncomeAmount: {
    NUM_RESTRICTION: /^\d+(\.\d{1,2})?$/, // Allows only 2 digits after decimal
  },
  remittanceStatementRemarks: {
    CHAR_LIMIT: /^.{0,4000}$/,
  },
  descriptionInPensionFundSection: {
    CHAR_LIMIT: /^.{1,120}$/,
  },
}

export const ENTITY_PENS_FUND_SCHEME_RULE_VALIDATION = {
  pensionFundSchemeRuleType: {
    CHAR_LIMIT: /^.{1,40}$/,
  },
}

export const ENTITY_GRADE = {
  gradeCode: {
    SPACE_VALIDATION: /^[^\s]*$/, // This allows all chars except space
    CHAR_LIMIT: /^[^\s]{0,40}$/, // Allows only 10 characters
  },
  gradeDescription: {
    CHAR_LIMIT: /^.{1,120}$/, // Allows only 120 characters
  },
  remarks: {
    CHAR_LIMIT: /^.{0,500}$/, // Allows only 500 characters
  },
}

export const ENTITY_WORK_CALENDAR = {
  workCalendarCode: {
    SPACE_VALIDATION: /^[^\s]*$/, // This allows all chars except space
    CHAR_LIMIT: /^[^\s]{0,20}$/, // Allows only 20 characters
  },
  workCalendarName: {
    CHAR_LIMIT: /^.{1,120}$/, // Allows only 120 characters
  },
}

export const PAYITEM_VALIDATION = {
  payItemCode: {
    SPACE_VALIDATION: /^[^\s]*$/, // This allows all chars except space
    CHAR_LIMIT: /^[^\s]{0,30}$/, // Allows only 30 characters
  },
  payItemName: {
    CHAR_LIMIT: /^.{1,120}$/, // Allows only 120 characters
  },
}

export const PERSON_VALIDATION = {
  personName: {
    CHAR_LIMIT: /^.{0,600}$/,
  },
}

export const EMPLOYEE_QUARTERS = {
  address: {
    CHAR_LIMIT: /^.{0,4000}$/,
  },
}

export const ENT_EMP_MOVEMENT_TYPE = {
  movementType: {
    CHAR_LIMIT: /^[^\s]{0,20}$/, // Allows only 20 characters
  },
  movementDescription: {
    CHAR_LIMIT: /^.{1,120}$/, // Allows only 120 characters
  },
  remarks: {
    CHAR_LIMIT: /^.{0,500}$/, // Allows only 500 characters
  },
}

// cost Center validation

export const COSTCENTER_VALIDATION = {
  costCenterCode: {
    SPACE_VALIDATION: /^[^\s]*$/, // This allows all chars except space
    CHAR_LIMIT: /^[\w\W\d]{1,40}$/, // Allows 1 to 40 characters, both uppercase and lowercase
  },
  costCenterDescription: {
    CHAR_LIMIT: /^[\s\S]{1,120}$/, // Allows 1 to 120 characters, including white space, both uppercase and lowercase
  },
}

// Position validation

export const POSITION_VALIDATION = {
  positionCode: {
    SPACE_VALIDATION: /^[^\s]*$/, // This allows all chars except space
    CHAR_LIMIT: /^[\w\W\d]{1,40}$/, // Allows 1 to 40 characters, both uppercase and lowercase
  },
  positionDescription: {
    CHAR_LIMIT: /^[\s\S]{1,120}$/, // Allows 1 to 120 characters, including white space, both uppercase and lowercase
  },
}
// REGION VALIDATION
export const REGION_VALIDATION = {
  regionCode: {
    SPACE_VALIDATION: /^[^\s]*$/, // This allows all chars except space
    CHAR_LIMIT: /^[\w\W\d]{1,40}$/, // Allows 1 to 40 characters, both uppercase and lowercase
  },
  regionDescription: {
    CHAR_LIMIT: /^[\s\S]{1,120}$/, // Allows 1 to 120 characters, including white space, both uppercase and lowercase
  },
}

export const SERVICE_PROVIDER_VALIDATION = {
  providerName: {
    CHAR_LIMIT: /^[\s\S\d]{1,120}$/, // Allows 1 to 120 characters, both uppercase and lowercase, and white space
  },
  employerName: {
    CHAR_LIMIT: /^[\s\S\d]{1,120}$/, // Allows 1 to 120 characters, both uppercase and lowercase, and white space
  },
  employerRegistrationFileNo: {
    CHAR_LIMIT: /^[\s\S\d]{1,60}$/, // Allows 1 to 40 characters, both uppercase and lowercase, and white space
  },
  providerContactPerson: {
    CHAR_LIMIT: /^[\s\S\d]{1,120}$/, // Allows 1 to 40 characters, both uppercase and lowercase, and white space
  },
  providerPhoneNo: {
    CHAR_LIMIT: /^[\s\d-+()]{1,120}$/, // Allows 1 to 120 characters, which can include digits, white space, "-", "(", ")", "+"
  },
  providerAddressLine1: {
    CHAR_LIMIT: /^[\s\S\d]{1,120}$/, // Allows 1 to 120 characters, both uppercase and lowercase, and white space
  },
  providerAddressLine2: {
    CHAR_LIMIT: /^[\s\S\d]{1,120}$/, // Allows 1 to 120 characters, both uppercase and lowercase, and white space
  },
  providerAddressLine3: {
    CHAR_LIMIT: /^[\s\S\d]{1,120}$/, // Allows 1 to 120 characters, both uppercase and lowercase, and white space
  },
  employerPICName: {
    CHAR_LIMIT: /^[\s\S\d]{1,120}$/, // Allows 1 to 120 characters, both uppercase and lowercase, and white space
  },
  employerPICDesignation: {
    CHAR_LIMIT: /^[\s\S\d]{1,120}$/, // Allows 1 to 120 characters, both uppercase and lowercase, and white space
  },
  employerPICSignatureRemarks: {
    CHAR_LIMIT: /^[\s\S\d]{1,120}$/, // Allows 1 to 120 characters, both uppercase and lowercase, and white space
  },
  providerEmailAddress: {
    CHAR_LIMIT: /^[\s\S\d]{1,120}$/, // Allows 1 to 120 characters, both uppercase and lowercase, and white space
  },
}

export const PF_TERMTINATION_CODE = {
  serviceProviderCode: {
    CHAR_LIMIT: /^.{1,20}$/, // Allows only 20 characters
  },
  terminationCode: {
    CHAR_LIMIT: /^.{1,10}$/, // Allows only 10 characters
  },
  terminationDesc: {
    CHAR_LIMIT: /^.{1,100}$/, // Allows only 100 characters
  },
}
// team validation

export const TEAM_VALIDATION = {
  teamCode: {
    SPACE_VALIDATION: /^[^\s]*$/, // This allows all chars except space
    CHAR_LIMIT: /^[\w\W\d]{1,40}$/, // Allows 1 to 40 characters, both uppercase and lowercase
  },
  teamDescription: {
    CHAR_LIMIT: /^[\s\S]{1,120}$/, // Allows 1 to 120 characters, including white space, both uppercase and lowercase
  },
}

// division validation

export const DIVISION_VALIDATION = {
  divisionCode: {
    SPACE_VALIDATION: /^[^\s]*$/, // This allows all chars except space
    CHAR_LIMIT: /^[\w\W\d]{1,40}$/, // Allows 1 to 40 characters, both uppercase and lowercase
  },
  divisionDescription: {
    CHAR_LIMIT: /^[\s\S]{1,120}$/, // Allows 1 to 120 characters, including white space, both uppercase and lowercase
  },
}

// StaffType validation

export const STAFFTYPE_VALIDATION = {
  staffTypeCode: {
    SPACE_VALIDATION: /^[^\s]*$/, // This allows all chars except space
    CHAR_LIMIT: /^[\w\W\d]{1,40}$/, // Allows 1 to 40 characters, both uppercase and lowercase
  },
  staffTypeDescription: {
    CHAR_LIMIT: /^[\s\S]{1,120}$/, // Allows 1 to 120 characters, including white space, both uppercase and lowercase
  },
}
// Entity Profile validation
export const ENTITYPROFILE_VALIDATION = {
  entityProfileName: {
    CHAR_LIMIT: /^[\s\S]{1,120}$/, // Allows 1 to 120 characters, including white space, both uppercase and lowercase
  },
  entityLocalName: {
    CHAR_LIMIT: /^[\s\S]{1,120}$/, // Allows 1 to 120 characters, including white space, both uppercase and lowercase
  },
  companyRegistrationNo: {
    CHAR_LIMIT: /^[\s\S]{1,120}$/, // Allows 1 to 120 characters, including white space, both uppercase and lowercase
  },
}

// PAYROLL
export const PAYROLL_SERVICES = {
  payCycleYear: {
    SPACE_VALIDATION: /^[^\s]*$/, // This allows all chars except space
    CHAR_TYPE_AND_LIMIT: /^[0-9]{4}$/, // Allows exactly 4 numbers
  },
  reportingPeriodYear: {
    SPACE_VALIDATION: /^[^\s]*$/, // This allows all chars except space
    CHAR_TYPE_AND_LIMIT: /^[0-9]{4}$/,
  },
  quantity: {
    SPACE_VALIDATION: /^[^\s]*$/,
  },
  transactionAmount: {
    SPACE_VALIDATION: /^[^\s]*$/,
  },
  baseSalaryAmount: {
    SPACE_VALIDATION: /^[^\s]*$/,
  },
  baseSalaryWage: {
    SPACE_VALIDATION: /^[^\s]*$/,
  },

}
