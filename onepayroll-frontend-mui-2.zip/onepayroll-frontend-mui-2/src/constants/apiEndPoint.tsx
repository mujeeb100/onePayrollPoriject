// import { getSelectedEntity, getauthToken } from 'utils'

const getSelectedEntity = () => {
  const entity = localStorage.getItem('Entity')
  return entity ? JSON.parse(entity) : null
}
const selectedEntityId = getSelectedEntity()?.id
// const entityProfileSelectedListByIdList = `entity/api/v1/EntityProfile/${selectedEntityId}`

const apiEndPoint: any = {

  // const selectedEntity = getSelectedEntity()
  // country
  countryList: 'global/api/v1/Country/<SELECTED_ENTITY>/GetCountryList',
  createCountry: 'global/api/v1/Country/<SELECTED_ENTITY>/CreateCountry',
  updateCountry: 'global/api/v1/Country/<SELECTED_ENTITY>/UpdateCountry',
  countryListById: 'global/api/v1/Country/<SELECTED_ENTITY>/GetCountry?Id',
  deleteCountry: 'global/api/v1/Country/<SELECTED_ENTITY>/DeleteCountry',

  // currency
  currencyList: 'global/api/v1/Currency/<SELECTED_ENTITY>/ViewCurrencyList',
  createCurrency: 'global/api/v1/Currency/<SELECTED_ENTITY>/CreateCurrency',
  updateCurrency: 'global/api/v1/Currency/<SELECTED_ENTITY>/UpdateCurrency',
  deleteCurrency: 'global/api/v1/Currency/<SELECTED_ENTITY>/DeleteCurrency',
  currencyListById: 'global/api/v1/Currency/<SELECTED_ENTITY>/GetCurrency?Id',
  // global nationality
  nationalityList: 'global/api/v1/Nationality/<SELECTED_ENTITY>/ViewNationality',
  createNationality: 'global/api/v1/Nationality/<SELECTED_ENTITY>/CreateNationality',
  updateNationality: 'global/api/v1/Nationality/<SELECTED_ENTITY>/UpdateNationality',
  deleteNationality: 'global/api/v1/Nationality/<SELECTED_ENTITY>/DeleteNationality',
  nationalityListById: 'global/api/v1/Nationality/<SELECTED_ENTITY>/GetNationality?Id',

  // client profile Api End point
  clientProfileList: 'client-group/api/v1/ClientGroupProfile/<SELECTED_ENTITY>/GetAllClientGroupProfile',
  clientProfileChangeStatus: 'client-group/api/v1/ClientGroupProfile/<SELECTED_ENTITY>/ChangeStatus',
  createClientProfile: 'client-group/api/v1/ClientGroupProfile/<SELECTED_ENTITY>/CreateClientGroupProfile',
  updateClientProfile: 'client-group/api/v1/ClientGroupProfile/<SELECTED_ENTITY>/UpdateClientGroupProfile',
  deleteClientProfile: 'client-group/api/v1/ClientGroupProfile/<SELECTED_ENTITY>/DeleteClientGroupProfile',

  clientProfileEntityList: 'client-group/api/v1/ClientGroupProfile/<SELECTED_ENTITY>/GetAllEntitiesByProfileId',
  clientGroupEntityList: 'client-group/api/v1/ClientGroupEntity/<SELECTED_ENTITY>/GetAllClientGroupEntity',
  createClientGroupEntity: 'client-group/api/v1/ClientGroupEntity/<SELECTED_ENTITY>/CreateClientGroupEntity',
  updateClientGroupEntity: 'client-group/api/v1/ClientGroupEntity/<SELECTED_ENTITY>/UpdateClientGroupEntity',
  deleteClientGroupEntity: 'client-group/api/v1/ClientGroupEntity/<SELECTED_ENTITY>/DeleteClientGroupEntity',
  clientGroupEntityChangeStatus: 'client-group/api/v1/ClientGroupEntity/<SELECTED_ENTITY>/ChangeStatus',

  // Employee Profile
  employeeProfileList: 'employee/api/v1/EmployeeSnapshot/<SELECTED_ENTITY>/GetAll',
  employeeProfileListById: 'employee/api/v1/EmployeeSnapshot/<SELECTED_ENTITY>/Get?Id',
  createEmployeeProfile: 'employee/api/v1/EmployeeSnapshot/<SELECTED_ENTITY>/Create',
  updateEmployeeProfile: 'employee/api/v1/EmployeeProfile/<SELECTED_ENTITY>/Update',
  deleteEmployeeProfile: 'employee/api/v1/EmployeeSnapshot/<SELECTED_ENTITY>/Delete',

  // Employee Movement
  employeeAverageWageList: 'payroll/api/v1/AverageWage/<SELECTED_ENTITY>/view',
  employeeAverageWageListById: 'payroll/api/v1/AverageWage/<SELECTED_ENTITY>/GetAverageWageById?id',
  createEmployeeAverageWage: 'employee/api/v1/EmployeeAverageWage/<SELECTED_ENTITY>/Create',
  updateEmployeeAverageWage: 'employee/api/v1/EmployeeAverageWage/<SELECTED_ENTITY>/Update',
  deleteEmployeeAverageWage: 'employee/api/v1/EmployeeAverageWage/<SELECTED_ENTITY>/Delete',
  updateAverageWageDisregardedDay: 'employee/api/v1/EmployeeAverageWage/<SELECTED_ENTITY>/UpdateEmployeeAverageWageDisregard',
  updatePayRollAverageWage: 'payroll/api/v1/AverageWage/<SELECTED_ENTITY>/Recalculate',
  // Entity-Profile
  entityProfileList: 'entity/api/v1/EntityProfile/<SELECTED_ENTITY>/View',
  entityProfileListById: 'entity/api/v1/EntityProfile/<SELECTED_ENTITY>?id',
  createEntityProfile: 'entity/api/v1/EntityProfile/<SELECTED_ENTITY>',
  updateEntityProfile: 'entity/api/v1/EntityProfile/<SELECTED_ENTITY>',
  deleteEntityProfile: 'entity/api/v1/EntityProfile/<SELECTED_ENTITY>',
  entityChangeProfileList: 'entity/api/v1/EntityProfile/<SELECTED_ENTITY>/canBeDeactivated',

  // IRD
  IRDList: 'entity/api/v1/IRDCorporateTitle/<SELECTED_ENTITY>/view',
  getSingleIRDData:
  'entity/api/v1/IRDCorporateTitle/<SELECTED_ENTITY>?code=IRD-CODE',
  updateIRD: 'entity/api/v1/IRDCorporateTitle/<SELECTED_ENTITY>',
  deleteIRD:
  'entity/api/v1/IRDCorporateTitle/<SELECTED_ENTITY>',
  IRDListById: 'entity/api/v1/IRDCorporateTitle/<SELECTED_ENTITY>?id',
  createIRD: 'entity/api/v1/IRDCorporateTitle/<SELECTED_ENTITY>',

  // department
  departmentList: 'entity/api/v1/Department/<SELECTED_ENTITY>/view',
  getSingleDeptData:
     'entity/api/v1/Department/<SELECTED_ENTITY>?code=DEPT-CODE',
  createDepartment: 'entity/api/v1/Department/<SELECTED_ENTITY>',
  deleteDepartment: 'entity/api/v1/Department/<SELECTED_ENTITY>',
  departmentListById: 'entity/api/v1/Department/<SELECTED_ENTITY>?id',
  updateDepartment: 'entity/api/v1/Department/<SELECTED_ENTITY>',

  // cost center
  createCostCenter: 'entity/api/v1/CostCenter/<SELECTED_ENTITY>',
  costCenterList: 'entity/api/v1/CostCenter/<SELECTED_ENTITY>/View',
  costCenterListById:
     'entity/api/v1/CostCenter/<SELECTED_ENTITY>?id',
  deleteCostCenter: 'entity/api/v1/CostCenter/<SELECTED_ENTITY>',
  updateCostCenter: 'entity/api/v1/CostCenter/<SELECTED_ENTITY>',

  // Entity Division
  createDivision: 'entity/api/v1/Division/<SELECTED_ENTITY>',
  divisionList: 'entity/api/v1/Division/<SELECTED_ENTITY>/View',
  divisionListById: 'entity/api/v1/Division/<SELECTED_ENTITY>?id',
  updateDivision: 'entity/api/v1/Division/<SELECTED_ENTITY>',
  deleteDivision: 'entity/api/v1/Division/<SELECTED_ENTITY>',
  // Entity Region
  createRegion: 'entity/api/v1/Region/<SELECTED_ENTITY>',
  regionList: 'entity/api/v1/Region/<SELECTED_ENTITY>/View',
  updateRegion: 'entity/api/v1/Region/<SELECTED_ENTITY>',
  deleteRegion: 'entity/api/v1/Region/<SELECTED_ENTITY>',
  regionListById: 'entity/api/v1/Region/<SELECTED_ENTITY>?id',

  // Entity Team
  createTeam: 'entity/api/v1/Team/<SELECTED_ENTITY>',
  teamList: 'entity/api/v1/Team/<SELECTED_ENTITY>/View',
  updateTeam: 'entity/api/v1/Team/<SELECTED_ENTITY>',
  deleteTeam: 'entity/api/v1/Team/<SELECTED_ENTITY>',
  teamListById: 'entity/api/v1/Team/<SELECTED_ENTITY>?id',

  // Employee Pension Fund
  employeePensionFundList: 'employee/api/v1/EmployeePensionFund/<SELECTED_ENTITY>/GetAll',
  createEmployeePensionFund: 'employee/api/v1/EmployeePensionFund/<SELECTED_ENTITY>/Create',
  employeePensionFundListById: 'employee/api/v1/EmployeePensionFund/<SELECTED_ENTITY>/Get?Id',
  updateEmployeePensionFund: 'employee/api/v1/EmployeePensionFund/<SELECTED_ENTITY>/Update',
  deleteEmployeePensionFund: 'employee/api/v1/EmployeePensionFund/<SELECTED_ENTITY>/Delete',

  // user client group
  userClientGroupList: 'identity/api/v1/UserAdministration/<SELECTED_ENTITY>/GetAllUsersOfClientGroup',
  usersWithRoleList: 'identity/api/v1/UserAdmin/<SELECTED_ENTITY>/GetUsersWithRoleByEntityId',

  // Employee Password api end point
  // deepcode ignore NoHardcodedPasswords: <this is not a password this is simple api end point of api>
  employeePasswordList: 'employee/api/v1/EmployeePassword/<SELECTED_ENTITY>/GetAllEmployeePassword',
  createEmployeePassword: 'employee/api/v1/EmployeePassword/<SELECTED_ENTITY>/CreateEmployeePassword',
  updateEmployeePassword: 'employee/api/v1/EmployeePassword/<SELECTED_ENTITY>/UpdateEmployeePassword',
  deleteEmployeePassword: 'employee/api/v1/EmployeePassword/<SELECTED_ENTITY>/DeleteEmployeePassword',
  createGeneratePassword: 'employee/api/v1/EmployeePassword/<SELECTED_ENTITY>/GeneratePassword',
  employeePasswordExportList: 'employee/api/v1/EmployeePassword/<SELECTED_ENTITY>/ViewAllEmployeePassword',

  // entity position
  createPosition: 'entity/api/v1/Position/<SELECTED_ENTITY>',
  positionList: 'entity/api/v1/Position/<SELECTED_ENTITY>/View',
  updatePosition: 'entity/api/v1/Position/<SELECTED_ENTITY>',
  deletePosition: 'entity/api/v1/Position/<SELECTED_ENTITY>',
  positionListById: 'entity/api/v1/Position/<SELECTED_ENTITY>?id',
  // company bank account
  addUpdateCompBankAcct: 'entity/api/v1/CompanyBankAccount/<SELECTFED_ENTITY>',
  // companyBankAccountList:
  //    'entity/api/v1/CompanyBankAccount/<SELECTED_ENTITY>/View',
  getSingleCompBankAcctData:
     'entity/api/v1/CompanyBankAccount/<SELECTED_ENTITY>?code=COMP-BANK-ACCT-CODE',
  deleteCompBankAcctData:
   'entity/api/v1/CompanyBankAccount/<SELECTED_ENTITY>?id=COMP-BANK-ACCT-CODE',
  //  company account list by id
  companyBankAcctListById: 'entity/api/v1/CompanyBankAccount/<SELECTED_ENTITY>?id',
  // entity settings
  addUpdateEntitySettings: 'entity/api/v1/EntitySettings/<SELECTED_ENTITY>',
  getEntitySettingsData: 'entity/api/v1/EntitySettings/<SELECTED_ENTITY>/View',
  getSingleEntitySettData:
    'entity/api/v1/EntitySettings/<SELECTED_ENTITY>?code=SETTING-CODE',
  deleteEntitySetting:
    'entity/api/v1/EntitySettings/<SELECTED_ENTITY>?id=ID',
  // entity currency exchange
  addUpdateEntityCurrExch: 'entity/api/v1/CurrencyExchange/<SELECTED_ENTITY>',
  getEntityCurrExchData:
    'entity/api/v1/CurrencyExchange/<SELECTED_ENTITY>/View',
  getSingleEntityCurrExchData:
    'entity/api/v1/CurrencyExchange/<SELECTED_ENTITY>?id=EXCH-CODE',
  deleteEntityCurrExch:
    'entity/api/v1/CurrencyExchange/<SELECTED_ENTITY>?id=EXCH-CODE',
  // entity pension fund scheme
  addUpdateEntPensFundScheme:
'entity/api/v1/PensionFundScheme/<SELECTED_ENTITY>?Isdraft=false',
  getEntPensFundSchemeData:
'entity/api/v1/PensionFundScheme/<SELECTED_ENTITY>/View',
  getSingleEntPensFundSchemeData:
'entity/api/v1/PensionFundScheme/<SELECTED_ENTITY>?id=PENSION-FUND-CODE',
  deleteEntPensFundScheme:
'entity/api/v1/PensionFundScheme/<SELECTED_ENTITY>?id=ID',
  copyEntPensFundScheme:
'entity/api/v1/PensionFundScheme/<SELECTED_ENTITY>/copy',
  // entity pension fund scheme rule
  addUpdateEntPensFundSchemeRule:
    'entity/api/v1/PensionFundSchemeRule/<SELECTED_ENTITY>',
  getEntPensFundSchemeRuleData:
    'entity/api/v1/PensionFundSchemeRule/<SELECTED_ENTITY>/View',
  getSingleEntPensFundSchemeRuleData:
    'entity/api/v1/PensionFundSchemeRule/<SELECTED_ENTITY>?id=PENSION-FUND-ID',
  deleteEntPensFundSchemeRule:
    'entity/api/v1/PensionFundSchemeRule/<SELECTED_ENTITY>?id=PENSION-FUND-ID',

  // Entity Grade
  gradeList: 'entity/api/v1/Grade/<SELECTED_ENTITY>/View',
  getSingleEntityGradeData:
    'entity/api/v1/Grade/<SELECTED_ENTITY>?code=GRADE-CODE',
  deleteGrade: 'entity/api/v1/Grade/<SELECTED_ENTITY>',
  gradeListById: 'entity/api/v1/Grade/<SELECTED_ENTITY>/?id',
  createGrade: 'entity/api/v1/Grade/<SELECTED_ENTITY>',
  updateGrade: 'entity/api/v1/Grade/<SELECTED_ENTITY>',

  // staff Type
  createStaffType: 'entity/api/v1/StaffType/<SELECTED_ENTITY>',
  staffTypeList: 'entity/api/v1/StaffType/<SELECTED_ENTITY>/View',
  updateStaffType: 'entity/api/v1/StaffType/<SELECTED_ENTITY>',
  deleteStaffType: 'entity/api/v1/StaffType/<SELECTED_ENTITY>',
  staffTypeListById: 'entity/api/v1/staffType/<SELECTED_ENTITY>/?id',

  // Entity Employee Movement Type
  addUpdateEntEmpMovementType: 'entity/api/v1/EmployeeMovementType/<SELECTED_ENTITY>',
  getEntEmpMovementTypeData: 'entity/api/v1/EmployeeMovementType/<SELECTED_ENTITY>/View',
  getSingleEntEmpMovementTypeData: 'entity/api/v1/EmployeeMovementType/<SELECTED_ENTITY>?code=EMP-MOVEMENT-CODE',
  deleteEntEmpMovementType: 'entity/api/v1/EmployeeMovementType/<SELECTED_ENTITY>?id=ID',
  // Employee recurring items

  employeeRecurringList: 'payroll/api/v1/EmployeeRecurringItems/<SELECTED_ENTITY>/view',
  createEmployeeRecurring: 'payroll/api/v1/EmployeeRecurringItems/<SELECTED_ENTITY>',
  updateEmployeeRecurring: 'payroll/api/v1/EmployeeRecurringItems/<SELECTED_ENTITY>',
  employeeRecurringListById: 'payroll/api/v1/EmployeeRecurringItems/<SELECTED_ENTITY>/GetEmployeeRecurringItems?EmployeeRecurringItemId',
  deleteEmployeeRecurring: 'payroll/api/v1/EmployeeRecurringItems/<SELECTED_ENTITY>',
  employeeRecurringDropDownList: 'payroll/api/v1/EmployeeRecurringItems/<SELECTED_ENTITY>/EmployeeRecurringItemsDropDowns',
  // Employee Bank account
  employeeBankAccountList: 'employee/api/v1/EmployeeBankAccount/<SELECTED_ENTITY>/GetAll',
  createEmployeeBankAccount: 'employee/api/v1/EmployeeBankAccount/<SELECTED_ENTITY>/Create',
  employeeBankAccountListById: 'employee/api/v1/EmployeeBankAccount/<SELECTED_ENTITY>/Get?id',
  updateEmployeeBankAccount: 'employee/api/v1/EmployeeBankAccount/<SELECTED_ENTITY>/Update',
  deleteEmployeeBankAccount: 'employee/api/v1/EmployeeBankAccount/<SELECTED_ENTITY>/Delete',
  bulkUploadEmployeeBankAccount:
    'employee/api/v1/EmployeeBankAccount/<SELECTED_ENTITY>/BulkUpload?useWrapper=false',
  bulkDeleteEmployeeBankAccount:
    'employee/api/v1/EmployeeBankAccount/<SELECTED_ENTITY>/BulkDelete?useWrapper=false',
  // Employee Quarters
  employeeQuarterList: 'employee/api/v1/EmployeeQuarters/<SELECTED_ENTITY>/GetAll',
  employeeQuarterListById: 'employee/api/v1/EmployeeQuarters/<SELECTED_ENTITY>/Get?id',
  createEmployeeQuarter: 'employee/api/v1/EmployeeQuarters/<SELECTED_ENTITY>/Create',
  updateEmployeeQuarter: 'employee/api/v1/EmployeeQuarters/<SELECTED_ENTITY>/Update',
  deleteEmployeeQuarter:
    'employee/api/v1/EmployeeQuarters/<SELECTED_ENTITY>/Delete',
  // Employee person
  personList: 'employee/api/v1/Person/<SELECTED_ENTITY>/GetAllPerson',
  createPerson: 'employee/api/v1/Person/<SELECTED_ENTITY>/CreatePerson',
  updatePerson: 'employee/api/v1/Person/<SELECTED_ENTITY>/UpdatePerson',
  deletePerson: 'employee/api/v1/Person/<SELECTED_ENTITY>/DeletePerson',

  // holiday calender Api End point
  holidayCalenderList: 'global/api/v1/HolidayCalendar/<SELECTED_ENTITY>/GetAll',
  holidayCalenderListById: 'global/api/v1/HolidayCalendar/<SELECTED_ENTITY>/Get?Id',
  createHolidayCalender: 'global/api/v1/HolidayCalendar/<SELECTED_ENTITY>/Create',
  updateHolidayCalender: 'global/api/v1/HolidayCalendar/<SELECTED_ENTITY>/Update',
  deleteHolidayCalender: 'global/api/v1/HolidayCalendar/<SELECTED_ENTITY>/Delete',

  // holiday calender dates
  holidayDatesList: 'global/api/v1/HolidayDate/<SELECTED_ENTITY>/GetAllHolidayDates?HolidayCalendarId',
  holidayDatesListById: 'global/api/v1/HolidayDate/<SELECTED_ENTITY>/GetAllHolidayDates?HolidayCalendarId',
  createHolidayDates: 'global/api/v1/HolidayDate/<SELECTED_ENTITY>/AddDates',
  updateHolidayDates: 'global/api/v1/HolidayDate/<SELECTED_ENTITY>/Update',
  deleteHolidayDates: 'global/api/v1/HolidayDate/<SELECTED_ENTITY>/Delete',
  // Global pension fund scheme rule
  globalPensionFundSchemeRuleList: 'global/api/v1/PensionFundSchemeRule/<SELECTED_ENTITY>/GetAll',
  globalPensionFundSchemeRuleListById: 'global/api/v1/PensionFundSchemeRule/<SELECTED_ENTITY>/Get?Id',
  createGlobalPensionFundSchemeRule:
       'global/api/v1/PensionFundSchemeRule/<SELECTED_ENTITY>/CreatePensionFundSchemeRule',
  updateGlobalPensionFundSchemeRule:
       'global/api/v1/PensionFundSchemeRule/<SELECTED_ENTITY>/UpdatePensionFundSchemeRule',
  deleteGlobalPensionFundSchemeRule:
       'global/api/v1/PensionFundSchemeRule/<SELECTED_ENTITY>/DeletePensionFundSchemeRule',

  // Global   standard Formula
  standardFormulaList: 'global/api/v1/StandardFormula/<SELECTED_ENTITY>/ViewFormula',

  // Global Standard Expression
  standardExpressionList: 'global/api/v1/StandardExpression/<SELECTED_ENTITY>/ViewExpressions',

  // User Admin
  userAdministrationList: 'identity/api/v1/UserAdministration/<SELECTED_ENTITY>/GetAll',
  createUserAdministration: 'identity/api/v1/UserAdministration/<SELECTED_ENTITY>/Create',
  userAdministrationListById: 'identity/api/v1/UserAdministration/<SELECTED_ENTITY>/Get?Id',
  updateUserAdministration: 'identity/api/v1/UserAdministration/<SELECTED_ENTITY>/Update',
  deleteUserAdministration: 'identity/api/v1/UserAdministration/<SELECTED_ENTITY>/Delete',

  // User Admin for entities
  userAdminEntityList: 'identity/api/v1/UserAdmin/<SELECTED_ENTITY>/GetAllUserAdminEntity',
  userAdminEntityListById: 'identity/api/v1/UserAdmin/<SELECTED_ENTITY>/GetUserAdminEntity?userAdminId',
  createUserAdminEntity: 'identity/api/v1/UserAdmin/<SELECTED_ENTITY>/CreateUserAdminInBulk',
  getUserAdminEntity: 'identity/api/v1/UserAdmin/<SELECTED_ENTITY>/GetUserAdminEntity',
  deleteUserAdminEntity: 'identity/api/v1/UserAdmin/<SELECTED_ENTITY>/DeleteUserAdminEntity',
  updateUserAdminEntity: 'identity/api/v1/UserAdmin/<SELECTED_ENTITY>/UpdateUserAdminEntity',
  // createBulkUserAdminEntity: 'identity/api/v1/UserAdmin/<SELECTED_ENTITY>/CreateUserAdminInBulk',

  // user role api endpoint
  userRoleList: 'identity/api/v1/UserRole/<SELECTED_ENTITY>/GetAllUserRole',
  createUserRole: 'identity/api/v1/UserRole/<SELECTED_ENTITY>/CreateUserRole',
  updateUserRole: 'identity/api/v1/UserRole/<SELECTED_ENTITY>/UpdateUserRole',
  deleteUserRole: 'identity/api/v1/UserRole/<SELECTED_ENTITY>/DeleteUserRole',
  userRoleListById: 'identity/api/v1/UserRole/<SELECTED_ENTITY>/GetUserRole?userRoleId',

  // provider type
  providerTypeList: 'global/api/v1/ProviderType/<SELECTED_ENTITY>/GetProviderTypeList',
  createProviderType: 'global/api/v1/ProviderType/<SELECTED_ENTITY>/CreateProviderType',
  updateProviderType: 'global/api/v1/ProviderType/<SELECTED_ENTITY>/UpdateProviderType',
  deleteProviderType: 'global/api/v1/ProviderType/<SELECTED_ENTITY>/DeleteProviderType',
  providerTypeListById: 'global/api/v1/ProviderType/<SELECTED_ENTITY>/GetProviderType?Id',
  providerTypeSingleList: 'global/api/v1/ProviderType/<SELECTED_ENTITY>/GetProviderType',

  // payment method
  paymentMethodList: 'global/api/v1/PaymentMethod/<SELECTED_ENTITY>/GetAll',
  createPaymentMethod: 'global/api/v1/PaymentMethod/<SELECTED_ENTITY>/Create',
  updatePaymentMethod: 'global/api/v1/PaymentMethod/<SELECTED_ENTITY>/Update',
  deletePaymentMethod: 'global/api/v1/PaymentMethod/<SELECTED_ENTITY>/Delete',
  paymentMethodListById: 'global/api/v1/PaymentMethod/<SELECTED_ENTITY>/Get?id',
  // setting template
  settingTemplateList: 'global/api/v1/SettingTemplate/<SELECTED_ENTITY>/GetAll',
  createSettingTemplate: 'global/api/v1/SettingTemplate/<SELECTED_ENTITY>/Create',
  updateSettingTemplate: 'global/api/v1/SettingTemplate/<SELECTED_ENTITY>/Update',
  deleteSettingTemplate: 'global/api/v1/SettingTemplate/<SELECTED_ENTITY>/Delete',
  settingTemplateListById: 'global/api/v1/SettingTemplate/<SELECTED_ENTITY>/Get?id',

  // satutory mapping
  satutoryMappingList: 'global/api/v1/SettingTemplate/<SELECTED_ENTITY>/GetHkStatutoryMappingByReportId',

  // authorization
  userRoleEntityList: 'identity/api/v1/Authorization/GetEntitiesAssignedToUser',
  userRolePermissionChangeList: 'identity/api/v1/UserAdministration/<SELECTED_ENTITY>/CheckIfSystemAdmin',
  // User Role Permission
  userRolePermissionListById: 'identity/api/v1/UserPermission/<SELECTED_ENTITY>/GetUserPermissionsWithGrouping?roleCode',
  createRolePermission: 'identity/api/v1/UserRolePermission/GetPermissionListByCode',
  updateRolePermission: 'identity/api/v1/UserRolePermission/GetPermissionListByCode',
  deleteRolePermission: 'identity/api/v1/UserRolePermission/GetPermissionListByCode',
  // userRolePermissionList: 'identity/api/v1/UserRolePermission/GetRolePermissions',

  userRolesPermissionListById: 'identity/api/v1/UserPermission/<SELECTED_ENTITY>/GetUserPermissionsWithGrouping?roleCode',
  createRolesPermission: 'identity/api/v1/UserRolePermission/CreateOrUpdate',
  updateRolesPermission: 'identity/api/v1/UserRolePermission/CreateOrUpdate',
  // Termination Code
  terminationCodeList: 'entity/api/v1/TerminationCode/<SELECTED_ENTITY>/View',
  createTerminationCode: 'entity/api/v1/TerminationCode/<SELECTED_ENTITY>',
  updateTerminationCode: 'entity/api/v1/TerminationCode/<SELECTED_ENTITY>',
  deleteTerminationCode: 'entity/api/v1/TerminationCode/<SELECTED_ENTITY>',
  terminationCodeListById: 'entity/api/v1/TerminationCode/<SELECTED_ENTITY>?id',
  // user role permission
  userRolePermissionList: 'identity/api/v1/UserRolePermission/<SELECTED_ENTITY>/GetRolePermissions',
  userRolePermissionById: 'identity/api/v1/UserRolePermission/GetRolePermissions',
  createUserRolePermission: 'identity/api/v1/UserRolePermission/<SELECTED_ENTITY>/CreateOrUpdate',
  deleteUserRolePermission: 'identity/api/v1/UserRolePermission/<SELECTED_ENTITY>/Delete',

  // client group
  clientGroupProfileList: 'client-group/api/v1/ClientGroupProfile/<SELECTED_ENTITY>/GetAllClientGroupProfile',
  changeStatusClientGroupProfile: 'client-group/api/v1/ClientGroupProfile/<SELECTED_ENTITY>/ChangeStatus',
  createClientGroupProfile: 'client-group/api/v1/ClientGroupProfile/<SELECTED_ENTITY>/CreateClientGroupProfile',
  updateClientGroupProfile: 'client-group/api/v1/ClientGroupProfile/<SELECTED_ENTITY>/UpdateClientGroupProfile',
  clientGroupProfileListById: 'client-group/api/v1/ClientGroupProfile/<SELECTED_ENTITY>/GetClientGroupProfile?Id',
  deleteClientGroupProfile: 'client-group/api/v1/ClientGroupProfile/<SELECTED_ENTITY>/DeleteClientGroupProfile',

  // client group Entities
  clientGroupEntitiesList: 'client-group/api/v1/ClientGroupEntity/<SELECTED_ENTITY>/GetAllClientGroupEntity',
  createClientGroupEntities: 'client-group/api/v1/ClientGroupEntity/<SELECTED_ENTITY>/CreateClientGroupEntity',
  updateClientGroupEntities: 'client-group/api/v1/ClientGroupEntity/<SELECTED_ENTITY>/UpdateClientGroupEntity',
  clientGroupEntitiesListById: 'client-group/api/v1/ClientGroupEntity/<SELECTED_ENTITY>/GetClientGroupEntity?ClientGroupProfileId',
  deleteClientGroupEntities: 'client-group/api/v1/ClientGroupEntity/<SELECTED_ENTITY>/DeleteClientGroupEntity',
  changeStatusClientGroupEntities: 'client-group/api/v1/ClientGroupEntity/<SELECTED_ENTITY>/ChangeStatus',

  // entity service provider
  serviceProviderList: 'entity/api/v1/ServiceProvider/<SELECTED_ENTITY>/View',
  createServiceProvider: 'entity/api/v1/ServiceProvider/<SELECTED_ENTITY>',
  updateServiceProvider: 'entity/api/v1/ServiceProvider/<SELECTED_ENTITY>',
  deleteServiceProvider: 'entity/api/v1/ServiceProvider/<SELECTED_ENTITY>',
  serviceProviderListById: 'entity/api/v1/ServiceProvider/<SELECTED_ENTITY>?id',

  // entity settings
  settingsList: 'entity/api/v1/EntitySettings/<SELECTED_ENTITY>/View',
  createSettings: 'entity/api/v1/EntitySettings/<SELECTED_ENTITY>',
  updateSettings: 'entity/api/v1/EntitySettings/<SELECTED_ENTITY>',
  deleteSettings: 'entity/api/v1/EntitySettings/<SELECTED_ENTITY>',
  settingsListById: 'entity/api/v1/EntitySettings/<SELECTED_ENTITY>?id',
  // pay item Group

  payItemGroupList: 'payroll/api/v1/PayItemGroup/<SELECTED_ENTITY>/view',
  payItemGroupListById: 'payroll/api/v1/PayItemGroup/<SELECTED_ENTITY>/GetPayItemGroupById?id',
  createPayItemGroup: 'payroll/api/v1/PayItemGroup/<SELECTED_ENTITY>',
  updatePayItemGroup: 'payroll/api/v1/PayItemGroup/<SELECTED_ENTITY>',
  deletePayItemGroup: 'payroll/api/v1/PayItemGroup/<SELECTED_ENTITY>',

  // pay group

  //

  payGroupList: 'payroll/api/v1/PayGroup/<SELECTED_ENTITY>/view',
  payGroupListById: 'payroll/api/v1/PayGroup/<SELECTED_ENTITY>/GetPayGroupById?id',
  createPayGroup: 'payroll/api/v1/PayGroup/<SELECTED_ENTITY>',
  updatePayGroup: 'payroll/api/v1/PayGroup/<SELECTED_ENTITY>',
  deletePayGroup: 'payroll/api/v1/PayGroup/<SELECTED_ENTITY>',
  payGroupDropDownList: 'payroll/api/v1/PayGroup/<SELECTED_ENTITY>/PayGroupDropDowns',

  // entity currency Exchange
  currencyExchangeList: 'entity/api/v1/CurrencyExchange/<SELECTED_ENTITY>/View',
  createCurrencyExchange: 'entity/api/v1/CurrencyExchange/<SELECTED_ENTITY>',
  updateCurrencyExchange: 'entity/api/v1/CurrencyExchange/<SELECTED_ENTITY>',
  deleteCurrencyExchange: 'entity/api/v1/CurrencyExchange/<SELECTED_ENTITY>',
  currencyExchangeListById: 'entity/api/v1/CurrencyExchange/<SELECTED_ENTITY>?id',
  // employee movement type
  employeeMovementList: 'entity/api/v1/EmployeeMovementType/<SELECTED_ENTITY>/view',
  createEmployeeMovement: 'entity/api/v1/EmployeeMovementType/<SELECTED_ENTITY>',
  updateEmployeeMovement: 'entity/api/v1/EmployeeMovementType/<SELECTED_ENTITY>',
  deleteEmployeeMovement: 'entity/api/v1/EmployeeMovementType/<SELECTED_ENTITY>',
  employeeMovementListById: 'entity/api/v1/EmployeeMovementType/<SELECTED_ENTITY>?id',
  // Entity pension fund scheme item
  pensionFundSchemeItemList: 'entity/api/v1/PensionFundSchemeItem/<SELECTED_ENTITY>/View',
  createPensionFundSchemeItem: 'entity/api/v1/PensionFundSchemeItem/<SELECTED_ENTITY>',
  updatePensionFundSchemeItem: 'entity/api/v1/PensionFundSchemeItem/<SELECTED_ENTITY>',
  deletePensionFundSchemeItem: 'entity/api/v1/PensionFundSchemeItem/<SELECTED_ENTITY>',
  pensionFundSchemeItemListById: 'entity/api/v1/PensionFundSchemeItem/<SELECTED_ENTITY>?id',
  // entity pension fund scheme
  pensionFundSchemeList: 'entity/api/v1/PensionFundScheme/<SELECTED_ENTITY>/View',
  createPensionFundScheme: 'entity/api/v1/PensionFundScheme/<SELECTED_ENTITY>?Isdraft=false',
  updatePensionFundScheme: 'entity/api/v1/PensionFundScheme/<SELECTED_ENTITY>',
  deletePensionFundScheme: 'entity/api/v1/PensionFundScheme/<SELECTED_ENTITY>',
  pensionFundSchemeListById: 'entity/api/v1/PensionFundScheme/<SELECTED_ENTITY>?id',
  copyPensionFundScheme: 'entity/api/v1/PensionFundScheme/<SELECTED_ENTITY>/copy',

  // Employee recurring items

  // payroll master slice
  payItemMasterList: 'payroll/api/v1/PayItem/<SELECTED_ENTITY>/view',
  payItemMasterListById: 'payroll/api/v1/PayItem/<SELECTED_ENTITY>/GetPayItemById?id',
  createPayItemMaster: 'payroll/api/v1/PayItem/<SELECTED_ENTITY>',
  updatePayItemMaster: 'payroll/api/v1/PayItem/<SELECTED_ENTITY>',
  deletePayItemMaster: 'payroll/api/v1/PayItem/<SELECTED_ENTITY>',
  payItemMasterDropDownList: 'payroll/api/v1/PayItem/<SELECTED_ENTITY>/PayItemDropDowns',

  // pension fund in payitem master

  pensionFundSchemeItemPayItemList: 'entity/api/v1/PensionFundSchemeItem/<SELECTED_ENTITY>/View',
  pensionFundSchemeItemPayItemListById: 'entity/api/v1/PensionFundSchemeItem/<SELECTED_ENTITY>/GetByPayItemCode?payItemCode',
  createPensionFundSchemeItemPayItem: 'entity/api/v1/PensionFundSchemeItem/<SELECTED_ENTITY>/PensionFundSchemeItem',
  updatePensionFundSchemeItemPayItem: 'entity/api/v1/PensionFundSchemeItem/<SELECTED_ENTITY>/UpdatePensionFundSchemeItem',
  deletePensionFundSchemeItemPayItem: 'entity/api/v1/PensionFundSchemeItem/<SELECTED_ENTITY>/DeletByPayItemCode?payItemCode=',

  // FormulaSetup
  formulaSetupList: 'payroll/api/v1/CustomFormula/<SELECTED_ENTITY>/ViewFormula',
  formulaSetupListById: 'payroll/api/v1/CustomFormula/<SELECTED_ENTITY>/GetFormulaById?id',
  createFormulaSetup: 'payroll/api/v1/CustomFormula/<SELECTED_ENTITY>',
  updateFormulaSetup: 'payroll/api/v1/CustomFormula/<SELECTED_ENTITY>',
  deleteFormulaSetup: 'payroll/api/v1/CustomFormula/<SELECTED_ENTITY>',

  // FormulaSetup
  formulaExpressionsList: 'payroll/api/v1/CustomExpression/<SELECTED_ENTITY>/ViewExpressions',
  formulaExpressionsListById: 'payroll/api/v1/CustomExpression/<SELECTED_ENTITY>/GetExpressionById?id',
  createFormulaExpressions: 'payroll/api/v1/CustomExpression/<SELECTED_ENTITY>',
  updateFormulaExpressions: 'payroll/api/v1/CustomExpression/<SELECTED_ENTITY>',
  deleteFormulaExpressions: 'payroll/api/v1/CustomExpression/<SELECTED_ENTITY>',

  // FormulaSetup Terms
  termList: 'payroll/api/v1/CustomTerm/<SELECTED_ENTITY>/ViewTerms',
  termListById: 'payroll/api/v1/CustomTerm/<SELECTED_ENTITY>/GetTermById?id',
  createTerm: 'payroll/api/v1/CustomTerm/<SELECTED_ENTITY>',
  updateTerm: 'payroll/api/v1/CustomTerm/<SELECTED_ENTITY>',
  deleteTerm: 'payroll/api/v1/CustomTerm/<SELECTED_ENTITY>',

  termDropDownList: 'payroll/api/v1/CustomTerm/<SELECTED_ENTITY>/ViewTerms',

  // paycycle generation
  payCycleGenerationList: 'payroll/api/v1/PayItem/<SELECTED_ENTITY>/view',
  payCycleGenerationListById: 'payroll/api/v1/PayItem/<SELECTED_ENTITY>/GetPayItemById?id',
  createPayCycleGeneration: 'payroll/api/v1/PayCycleGenerate/<SELECTED_ENTITY>',
  updatePayCycleGeneration: 'payroll/api/v1/PayItem/<SELECTED_ENTITY>',
  deletePayCycleGeneration: 'payroll/api/v1/PayItem/<SELECTED_ENTITY>',
  payCycleGenerationDropDownList: 'payroll/api/v1/PayCycleGenerate/<SELECTED_ENTITY>/PayCycleGenerateDropDowns',
  // Entity Work Calendar

  workCalenderList: 'entity/api/v1/WorkCalendar/<SELECTED_ENTITY>/View',
  workCalenderListById: 'entity/api/v1/WorkCalendar/<SELECTED_ENTITY>?id',
  createWorkCalender: 'entity/api/v1/WorkCalendar/<SELECTED_ENTITY>',
  updateWorkCalender: 'entity/api/v1/WorkCalendar/<SELECTED_ENTITY>',
  deleteWorkCalender: 'entity/api/v1/WorkCalendar/<SELECTED_ENTITY>',

  // Empoyee movement configuartion

  employeeMovementConfigurationList: 'entity/api/v1/EmployeeMovementConfiguration/<SELECTED_ENTITY>/View',
  employeeMovementConfigurationListById: 'entity/api/v1/EmployeeMovementConfiguration/<SELECTED_ENTITY>?id',
  createEmployeeMovementConfiguration: 'entity/api/v1/EmployeeMovementConfiguration/<SELECTED_ENTITY>',
  updateEmployeeMovementConfiguration: 'entity/api/v1/EmployeeMovementConfiguration/<SELECTED_ENTITY>',
  deleteEmployeeMovementConfiguration: 'entity/api/v1/EmployeeMovementConfiguration/<SELECTED_ENTITY>',

  // entity pension fund scheme rule
  pensionFundSchemeRuleList: 'entity/api/v1/PensionFundSchemeRule/<SELECTED_ENTITY>/View',
  createPensionFundSchemeRule: 'entity/api/v1/PensionFundSchemeRule/<SELECTED_ENTITY>',
  updatePensionFundSchemeRule: 'entity/api/v1/PensionFundSchemeRule/<SELECTED_ENTITY>',
  deletePensionFundSchemeRule: 'entity/api/v1/PensionFundSchemeRule/<SELECTED_ENTITY>',
  pensionFundSchemeRuleListById: 'entity/api/v1/PensionFundSchemeRule/<SELECTED_ENTITY>?id',
  // entity company bank account
  companyBankAccountList: 'entity/api/v1/CompanyBankAccount/<SELECTED_ENTITY>/View',
  createCompanyBankAccount: 'entity/api/v1/CompanyBankAccount/<SELECTED_ENTITY>',
  updateCompanyBankAccount: 'entity/api/v1/CompanyBankAccount/<SELECTED_ENTITY>',
  deleteCompanyBankAccount: 'entity/api/v1/CompanyBankAccount/<SELECTED_ENTITY>',
  companyBankAccountListById: 'entity/api/v1/CompanyBankAccount/<SELECTED_ENTITY>?id',
  // PayrollNonRecurringItems
  // payRollNonRecurringList: 'payroll/api/v1/PayrollNonRecurringItems/<SELECTED_ENTITY>/view',
  payRollNonRecurringListById: 'payroll/api/v1/PayrollNonRecurringItems/<SELECTED_ENTITY>/GetPayrollNonRecurringItemsById?id',

  createPayRollNonRecurring: 'payroll/api/v1/PayrollNonRecurringItems/<SELECTED_ENTITY>',
  updatePayRollNonRecurring: 'payroll/api/v1/PayrollNonRecurringItems/<SELECTED_ENTITY>',
  deletePayRollNonRecurring: 'payroll/api/v1/PayrollNonRecurringItems/<SELECTED_ENTITY>',
  payRollNonRecurringDropDowns: 'payroll/api/v1/PayrollNonRecurringItems/<SELECTED_ENTITY>/PayrollNonRecurringItemsDropDowns',
  createPayRollNonRecurringSearch: 'payroll/api/v1/PayrollNonRecurringItems/<SELECTED_ENTITY>/search',
  payRollNonRecurringDropDownList: 'payroll/api/v1/PayrollNonRecurringItems/<SELECTED_ENTITY>/PayrollNonRecurringItemsDropDowns',

  // payroll cycle
  payrollCycleList: 'payroll/api/v1/PayCycleMaster/<SELECTED_ENTITY>/view',
  createPayrollCycle: 'payroll/api/v1/PayCycleMaster/<SELECTED_ENTITY>',
  updatePayrollCycle: 'payroll/api/v1/PayCycleMaster/<SELECTED_ENTITY>',
  deletePayrollCycle: 'payroll/api/v1/PayCycleMaster/<SELECTED_ENTITY>',
  payrollCycleListById: 'payroll/api/v1/PayCycleMaster/<SELECTED_ENTITY>/GetPayCycleById?id',

  // standard Report
  standardReportList: 'reporting/api/v1/Reporting/<SELECTED_ENTITY>/view',
  createStandardReport: 'reporting/api/v1/ReportGroup/<SELECTED_ENTITY>',
  updateStandardReport: 'reporting/api/v1/ReportGroup/<SELECTED_ENTITY>',
  deleteStandardReport: 'reporting/api/v1/Reporting/<SELECTED_ENTITY>',
  standardReportListById: 'reporting/api/v1/Reporting/<SELECTED_ENTITY>/GetPayCycleById?id',
  createStandardReportDelete: 'reporting/api/v1/ReportGroup/<SELECTED_ENTITY>/Delete',

  // ARC Report
  aRCReportList: 'reporting/api/v1/Reporting/<SELECTED_ENTITY>/view?actionStatus=Draft&genRefId=&reportTypeId=',
  createARCReport: 'reporting/api/v1/ReportGroup/<SELECTED_ENTITY>',
  updateARCReport: 'reporting/api/v1/Reporting/<SELECTED_ENTITY>',
  deleteARCReport: 'reporting/api/v1/Reporting/<SELECTED_ENTITY>',
  aRCReportListById: 'reporting/api/v1/Reporting/<SELECTED_ENTITY>/GetPayCycleById?id',

  // standard report group list
  standardReportGroupList: 'reporting/api/v1/ReportGroup/<SELECTED_ENTITY>/View?SortBy=Name&OrderByAsc=false',

  // pay cycle administration api endpoint
  // Unfinalized
  updatePayCycleAdministrationUnfinalized: 'payroll/api/v1/PayCycleAdministration/<SELECTED_ENTITY>/UnfinalizedAction',
  // finalized
  updatePayCycleAdministrationFinalized: 'payroll/api/v1/PayCycleAdministration/<SELECTED_ENTITY>/FinalizedAction',
  // Open
  updatePayCycleAdministrationOpen: 'payroll/api/v1/PayCycleAdministration/<SELECTED_ENTITY>/OpenAction',
  // Locked
  updatePayCycleAdministrationLocked: 'payroll/api/v1/PayCycleAdministration/<SELECTED_ENTITY>/LockedAction',
  // Unlocked
  updatePayCycleAdministrationUnlocked: 'payroll/api/v1/PayCycleAdministration/<SELECTED_ENTITY>/UnlockedAction',
  // DeactivateBatchAction
  updatePayCycleAdministrationDeactivate: 'payroll/api/v1/PayCycleAdministration/<SELECTED_ENTITY>/DeactivateBatchAction',
  // DropBatchAction
  updatePayCycleAdministrationDrop: 'payroll/api/v1/PayCycleAdministration/<SELECTED_ENTITY>/DropBatchAction',

  // report designer
  reportDesignerList: 'reporting-designer/<SELECTED_ENTITY>',
  // upload data
  uploadDataList: 'integration/api/v1/Integration/<SELECTED_ENTITY>/View',
  createUploadData: 'integration/api/v1/Integration/<SELECTED_ENTITY>',
  updateUploadData: 'integration/api/v1/Integration/<SELECTED_ENTITY>/View',
  deleteUploadData: 'integration/api/v1/Integration/<SELECTED_ENTITY>',
  uploadDataListById: 'integration/api/v1/Integration/<SELECTED_ENTITY>/download',

  // sunshine integration
  sunshineList: 'integration/api/v1/SunshineIntegration/<SELECTED_ENTITY>/View',
  createSunshine: 'integration/api/v1/SunshineIntegration/<SELECTED_ENTITY>/GenerateReport',
  updatesunshine: 'integration/api/v1/SunshineIntegration/<SELECTED_ENTITY>',
  deletesunshine: 'integration/api/v1/SunshineIntegration/<SELECTED_ENTITY>',
  sunshineListById: 'integration/api/v1/SunshineIntegration/<SELECTED_ENTITY>/download?fileName',
  // PayCycleMasterDropDowns
  payCycleMasterDropDownList: 'payroll/api/v1/PayCycleMaster/<SELECTED_ENTITY>/PayCycleMasterDropDowns',
  payCycleOptionsList: 'payroll/api/v1/PayCycleMaster/<SELECTED_ENTITY>/Options',

  // Report designer custom report
  customReportDesignerList: 'reporting/api/v1/ReportDesigns/<SELECTED_ENTITY>/View',
  createCustomReportDesigner: 'reporting/api/v1/ReportDesigns/<SELECTED_ENTITY>',
  updateCustomReportDesigner: 'reporting/api/v1/ReportDesigns/<SELECTED_ENTITY>',
  deleteCustomReportDesigner: 'reporting/api/v1/ReportDesigns/<SELECTED_ENTITY>',
  // payroll month end closing
  createPayrollMonthEndClosing: 'payroll/api/v1/MonthEndClosing/<SELECTED_ENTITY>',

  // entity profile useLazyGetEntityProfileByIdQuery
  entityProfileSelectedListByIdList: `entity/api/v1/EntityProfile/<SELECTED_ENTITY>?id=${selectedEntityId}`,

  // AddMonthEndClosing
  // createMonthEndClosing: 'payroll/api/v1/MonthEndClosing/<SELECTED_ENTITY>',
  // run Payroll
  createRunPayroll: 'payroll/api/v1/PayrollRun/<SELECTED_ENTITY>',
  exportCalcList: 'payroll/api/v1/PayrollRun/<SELECTED_ENTITY>/downloadCalculation',
  downloadRunLog: 'logging/api/v1/Logging/<SELECTED_ENTITY>/download',
  downloadLogsDocutaxPro: 'reporting/api/v1/Tax/<SELECTED_ENTITY>/downloadlogfile',

  // view draft transaction
  viewDraftTransactions: 'payroll/api/v1/PayrollRun/<SELECTED_ENTITY>/ViewDraftTransactions',

  // view employees by pay cycle
  viewEmployeesByPayCycle: 'payroll/api/v1/PayrollRun/<SELECTED_ENTITY>/ViewEmployeesByPayCycle?payCycleCode',

  // get filter employees
  createFilteredEmployees: 'payroll/api/v1/PayrollRun/<SELECTED_ENTITY>/GetFilteredEmployees',

  // ccan be submitted
  createCanBeSubmitted: 'payroll/api/v1/PayrollRun/<SELECTED_ENTITY>/CanBeSubmitted',

  // https://hk.up.dev.onepayroll.net/payroll/api/v1/PayrollRun/9cd7e909-ba68-4fa1-b205-117891f51b64/CanBeSubmitted

  // Open
  // updatePayCycleAdministrationOpen: 'payroll/api/v1/PayCycleAdministration/<SELECTED_ENTITY>/OpenAction',
  // dowLoadRunParollFile: 'payroll/api/v1/PayCycleMaster/<SELECTED_ENTITY>/download?fileName=',

  // Report Group
  reportGroupList: 'reporting/api/v1/ReportGroup/<SELECTED_ENTITY>/View',

  // logs paycylce
  payCycleMasterLogsList: 'payroll/api/v1/PayCycleMaster/<SELECTED_ENTITY>/Logs',

  // Download logs fils
  logDownloadList: 'payroll/api/v1/PayCycleMaster/<SELECTED_ENTITY>/download',

  // payroll slip design:

  generatePayrollSlipList: 'reporting/api/v1/Reporting/<SELECTED_ENTITY>/View',
  createGeneratePayrollSlip: 'reporting/api/v1/ReportGroup/<SELECTED_ENTITY>',
  updateGeneratePayrollSlip: 'reporting/api/v1/ReportGroup/<SELECTED_ENTITY>',

  // Report type
  reportTypeList: 'reporting/api/v1/ReportType/<SELECTED_ENTITY>/View',
  // download reports log
  reportDownloadList: 'reporting/api/v1/Reporting/<SELECTED_ENTITY>/download',

  // payment Summary report
  createPaymentSummary: 'reporting/api/v1/ReportGroup/<SELECTED_ENTITY>',

  // report design

  reportSlipModalList: 'reporting/api/v1/ReportDesigns/<SELECTED_ENTITY>/View',
  // email profile
  emailProfileList: 'notification/api/v1/EmailProfile/<SELECTED_ENTITY>/view',
  createEmailProfile: 'notification/api/v1/EmailProfile/<SELECTED_ENTITY>',
  updateEmailProfile: 'notification/api/v1/EmailProfile/<SELECTED_ENTITY>',
  deleteEmailProfile: 'notification/api/v1/EmailProfile/<SELECTED_ENTITY>',
  emailProfileListById: 'notification/api/v1/EmailProfile/<SELECTED_ENTITY>/GetEmailProfileById?id',
  sendEmailProfileDropDownList: 'notification/api/v1/EmailProfile/<SELECTED_ENTITY>/EmailProfileDropDowns',
  // pension fund termination code

  pensionFundTerminationList: 'global/api/v1/PensionFundTerminationCode/<SELECTED_ENTITY>/GetAll',
  pensionFundTerminationListById: 'global/api/v1/PensionFundTerminationCode/<SELECTED_ENTITY>/Get?id',
  createPensionFundTermination: 'global/api/v1/PensionFundTerminationCode/<SELECTED_ENTITY>/CreatePensionFundTerminationCode',
  updatePensionFundTermination: 'global/api/v1/PensionFundTerminationCode/<SELECTED_ENTITY>/UpdatePensionFundTerminationCode',
  deletePensionFundTermination: 'global/api/v1/PensionFundTerminationCode/<SELECTED_ENTITY>/Delete',
  // docuTax pro reporting
  docuTaxProReportingList: 'reporting/api/v1/Tax/<SELECTED_ENTITY>/viewtaxdocs',
  createDocuTaxProReporting: 'reporting/api/v1/Tax/<SELECTED_ENTITY>/uploadtaxdocs',

  // send email
  sendEmailList: 'notification/api/v1/SendEmailNotification/<SELECTED_ENTITY>/ExportedReports?ReportTypeId',
  sendEmailListById: 'notification/api/v1/SendEmailNotification/<SELECTED_ENTITY>/ExportedReports?ReportTypeId',
  createSendEmail: 'notification/api/v1/SendEmailNotification/<SELECTED_ENTITY>/SendEmail',
  updateSendEmail: 'notification/api/v1/SendEmailNotification/<SELECTED_ENTITY>',
  deleteSendEmail: 'notification/api/v1/SendEmailNotification/<SELECTED_ENTITY>',
  sendEmailDropDownList: 'notification/api/v1/SendEmailNotification/<SELECTED_ENTITY>/EmployeeTypeDropDowns',

  // send payrollslip
  sendPaySlipList: 'notification/api/v1/SendEmailNotification/<SELECTED_ENTITY>/ExportedReports?ReportTypeId',
  sendPaySlipListById: 'notification/api/v1/SendEmailNotification/<SELECTED_ENTITY>/ExportedReports?ReportTypeId',
  createSendPaySlip: 'notification/api/v1/SendEmailNotification/<SELECTED_ENTITY>/Dispatch',
  updateSendPaySlip: 'notification/api/v1/SendEmailNotification/<SELECTED_ENTITY>',
  deleteSendPaySlip: 'notification/api/v1/SendEmailNotification/<SELECTED_ENTITY>',

  // send test email
  sendTestEmailList: 'notification/api/v1/SendEmailNotification/<SELECTED_ENTITY>',
  sendTestEmailListById: 'notification/api/v1/SendEmailNotification/<SELECTED_ENTITY>/ExportedReports',
  createSendTestEmail: 'notification/api/v1/SendEmailNotification/<SELECTED_ENTITY>/SendTestEmail',
  updateSendTestEmail: 'notification/api/v1/SendEmailNotification/<SELECTED_ENTITY>',
  deleteSendTestEmail: 'notification/api/v1/SendEmailNotification/<SELECTED_ENTITY>',
  // MonthEndClosing
  monthEndClosingList: 'payroll/api/v1/MonthEndClosing/<SELECTED_ENTITY>/GetPreCloseCheckStatus',

  // getEmployees
  createGetEmployees: 'notification/api/v1/SendEmailNotification/<SELECTED_ENTITY>/Employees',
  // email template
  emailTemplateList: 'notification/api/v1/EmailTemplate/<SELECTED_ENTITY>',
  emailTemplateListById: 'notification/api/v1/EmailTemplate/<SELECTED_ENTITY>/GetEmailTemplateById?id',
  createEmailTemplate: 'notification/api/v1/EmailTemplate/<SELECTED_ENTITY>',
  updateEmailTemplate: 'notification/api/v1/EmailTemplate/<SELECTED_ENTITY>',
  deleteEmailTemplate: 'notification/api/v1/EmailTemplate/<SELECTED_ENTITY>',
  emailTemplateDropDownList: 'notification/api/v1/EmailTemplate/<SELECTED_ENTITY>/EmailTemplateDropDowns',
  emailTemplatePlaceHolderList: 'notification/api/v1/EmailTemplate/<SELECTED_ENTITY>/EmailTemplatePlaceholders',

  // auditTrail report
  auditTrailReportList: 'reporting/api/v1/Reporting/<SELECTED_ENTITY>/View',
  createAuditTrailReport: 'reporting/api/v1/ReportGroup/<SELECTED_ENTITY>',
  // Audit Report
  auditReportList: 'reporting/api/v1/AuditReport/<SELECTED_ENTITY>/Table',

  // Employee movement type
  empMovementList: 'employee/api/v1/EmployeeMovement/<SELECTED_ENTITY>/GetAll',
  empMovementListById: 'employee/api/v1/EmployeeMovement/<SELECTED_ENTITY>/GetEmployeeMovement?id',
  createEmpMovement: 'employee/api/v1/EmployeeMovement/<SELECTED_ENTITY>/Create',
  updateEmpMovement: 'employee/api/v1/EmployeeMovement/<SELECTED_ENTITY>/UpdateEmployeeMovement',
  deleteEmpMovement: 'employee/api/v1/EmployeeMovement/<SELECTED_ENTITY>/CancelEmployeeMovement',
  updateEmpMovement1: 'employee/api/v1/EmployeeMovement/<SELECTED_ENTITY>/CancelEmployeeMovement',

  // payroll history:
  // payrollHistoryList: 'payroll/api/v1/PayrollHistoryUpload/<SELECTED_ENTITY>/view',
  createPayrollHistory: 'payroll/api/v1/PayrollHistoryUpload/<SELECTED_ENTITY>/view',
  deletePayrollHistory: 'payroll/api/v1/PayrollHistoryUpload/<SELECTED_ENTITY>/Delete',
  payrollHistoryLogList: 'payroll/api/v1/PayrollHistoryUpload/<SELECTED_ENTITY>/Logs',

  // payroll non recurring bulk delete
  deletePayRollBulkNonRecurring: 'payroll/api/v1/PayrollNonRecurringItems/<SELECTED_ENTITY>/BulkDelete',
  delete2PayRollBulkNonRecurring: 'payroll/api/v1/PayrollNonRecurringItems/<SELECTED_ENTITY>/BulkDelete',
  payRollNonRecurringLogsList: 'logging/api/v1/Logging/<SELECTED_ENTITY>/view?logFunction=PayrollNonRecurringItemsBulkDelete',
  // pay cycle reassignment
  payCycleReassignmentList: 'payroll/api/v1/EmployeePayCycleReassignment/<SELECTED_ENTITY>/view',
  payCycleReassignmentListById: 'payroll/api/v1/EmployeePayCycleReassignment/<SELECTED_ENTITY>/view',
  createPayCycleReassignment: 'payroll/api/v1/EmployeePayCycleReassignment/<SELECTED_ENTITY>',
  updatePayCycleReassignment: 'payroll/api/v1/EmployeePayCycleReassignment/<SELECTED_ENTITY>',
  deletePayCycleReassignment: 'payroll/api/v1/EmployeePayCycleReassignment/<SELECTED_ENTITY>',
  // publish report
  publishReportList: 'reporting/api/v1/Reporting/<SELECTED_ENTITY>/View',
  publishReportListById: 'reporting/api/v1/Reporting/<SELECTED_ENTITY>/files?referenceId',
  createPublishReport: 'reporting/api/v1/Reporting/<SELECTED_ENTITY>',
  updatePublishReport: 'reporting/api/v1/Reporting/<SELECTED_ENTITY>',
  deletePublishReport: 'reporting/api/v1/Reporting/<SELECTED_ENTITY>',
  publishReportLogsList: 'logging/api/v1/Logging/<SELECTED_ENTITY>/view',

  // month end closing logs
  monthEndClosingLogsList: 'logging/api/v1/Logging/<SELECTED_ENTITY>/view?logFunction=MonthEndClosing',

  // email template
  emailTmplateList: 'notification/api/v1/EmailTemplate/<SELECTED_ENTITY>/view',
  createSendEmailTemplate: 'notification/api/v1/EmailTemplate/<SELECTED_ENTITY>',
  // review report
  reviewReportViewList: 'reporting/api/v1/Reporting/<SELECTED_ENTITY>/View',
  reviewReportList: 'reporting/api/v1/Reporting/<SELECTED_ENTITY>/files',
  createReviewReport: 'reporting/api/v1/Reporting/<SELECTED_ENTITY>/reviewAction',
  // Review Report Logs
  reviewReportLogsFileList: 'reporting/api/v1/Reporting/<SELECTED_ENTITY>/viewreportsjobs',

  // download multi report export
  createReviewReportExport: 'reporting/api/v1/Reporting/<SELECTED_ENTITY>/download',
  // EmployeeMovementAction
  employeeMovementActionList: 'employee/api/v1/EmployeeMovementAction/<SELECTED_ENTITY>/GetAll',
  employeeMovementActionListById: 'reporting/api/v1/Reporting/<SELECTED_ENTITY>/files?referenceId',
  createEmployeeMovementAction: 'reporting/api/v1/Reporting/<SELECTED_ENTITY>',
  updateEmployeeMovementAction: 'reporting/api/v1/Reporting/<SELECTED_ENTITY>',
  deleteEmployeeMovementAction: 'reporting/api/v1/Reporting/<SELECTED_ENTITY>',
  // logging
  viewLogsList: 'logging/api/v1/Logging/<SELECTED_ENTITY>/download',
  payrollRunLogsList: 'logging/api/v1/Logging/<SELECTED_ENTITY>/view',

  // create and view Pay Cycle Master
  createPayCycleMasterSearchFilter: 'payroll/api/v1/PayCycleMaster/<SELECTED_ENTITY>/view',
  payCycleMasterList: 'payroll/api/v1/PayCycleMaster/<SELECTED_ENTITY>/view',
  sendEmailLogsList: 'logging/api/v1/Logging/<SELECTED_ENTITY>/view?logFunction=SendEmailNotification',
  // employee leave Transaction
  employeeLeaveTransactionList: 'employee/api/v1/EmployeeLeaveTransaction/<SELECTED_ENTITY>/GetAll',
  employeeLeaveTransactionListById: 'employee/api/v1/EmployeeLeaveTransaction/<SELECTED_ENTITY>/Get?id',
  createEmployeeLeaveTransaction: 'employee/api/v1/EmployeeLeaveTransaction/<SELECTED_ENTITY>/Create',
  deleteEmployeeLeaveTransaction: 'employee/api/v1/EmployeeLeaveTransaction/<SELECTED_ENTITY>/delete',
  updateEmployeeLeaveTransaction: 'employee/api/v1/EmployeeLeaveTransaction/<SELECTED_ENTITY>/update',

  // employee remarks
  employeeRemarksList: 'employee/api/v1/EmployeeRemarks/<SELECTED_ENTITY>/GetAll',
  employeeRemarksListById: 'employee/api/v1/EmployeeRemarks/<SELECTED_ENTITY>/Get?Id',
  createEmployeeRemarks: 'employee/api/v1/EmployeeRemarks/<SELECTED_ENTITY>/Create',
  deleteEmployeeRemarks: 'employee/api/v1/EmployeeRemarks/<SELECTED_ENTITY>/Delete',
  updateEmployeeRemarks: 'employee/api/v1/EmployeeRemarks/<SELECTED_ENTITY>/Update',

}

export default apiEndPoint
