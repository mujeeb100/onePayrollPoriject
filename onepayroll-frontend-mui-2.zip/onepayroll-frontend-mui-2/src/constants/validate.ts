import moment from 'moment'
import * as Yup from 'yup'
import * as yup from 'yup'
// value date for company bank account
const todayDate: Date = new Date()
todayDate.setHours(0, 0, 0, 0)
// Setting hours, minutes, seconds, and milliseconds to 0 to compare only the date part
interface ProviderTypeFormValues {
  providerCode: string;
  providerName: string;
  countryLocalization: string;
  remarks: string;
  providerType: string;
  remittanceStatementReportFormat?: string;
  remittanceStatementFileFormat?: string;
  remittanceStatementTerminationCode?: string;
}

const isRequired = true // Replace this with your actual logic
const scbFormats = [5, 6, 7, 8]
export const validationSchema = yup.object().shape({
  countryCode: yup
    .string()
    .matches(/^[A-Za-z]+$/, 'Country ID must not contain numeric or symbol')
    .test(
      'no-blank-space',
      'Country ID must not contain blank space',
      (value) => {
        if (value && /\s/.test(value)) { // Check for any whitespace character
          return false
        }
        return true
      },
    )
    .max(3, 'Country ID must not be longer than 3 characters')
    // .trim() // Trim white spaces
    .required('Country ID must be filled'),
  countryName: yup.string()
    .required('Country Name must be filled.')
    .max(120, 'Country Name must not be longer than 120 characters'),
})

// Formula Setup

export const formulaSetupValidationSchema = yup.object().shape({

})

export const clientGropProfilValidationSchema = yup.object().shape({
  clientGroupCode: yup
    .string()
    .matches(/^\S*$/, 'Client Group ID  must not contain blank space')
    .required('Client Group ID must be filled').max(30, 'Client Group ID must not be longer than 30 characters.')
    .strict(),
  clientGroupName: yup.string().required('Client Group Name must be filled').max(120, 'Client Group Name must not be longer than 120 characters.'),
  remarks: yup.string().max(500, 'Remarks must not be longer than 500 characters'),
})

export const clientGropEntitiesValidationSchema = yup.object().shape({
  // clientGroupCode: yup
  //   .string()
  //   .matches(/^\S*$/, 'Client Group ID  must not contain blank space')
  //   .required('Client Group ID must be filled').max(30, 'Client Group ID must not be longer than 30 characters.')
  //   .strict(),
  // clientGroupName: yup.string().required('Client Group Name must be filled').max(120, 'Client Group Name must not be longer than 120 characters.'),
  entityCode: yup
    .string()
    .matches(/^\S*$/, 'Entity Code  must not contain blank space')
    .required('Entity Code must be filled').max(30, 'Entity Code must not be longer than 30 characters.')
    .strict(),
  entityName: yup.string().required('Entity Name must be required').max(120, 'Entity Name must not be longer than 120 characters.'),
  countryLocalization: yup.string().required('Country Localization must be filled'),
})

export const employeeQuarterSchema = yup.object().shape({
  // employeeCode: yup
  //   .string()
  //   .required('EmployeeCode must be filled'),
  // periodFromDate: yup.date().required('Period From Date must be filled.'),
  // periodToDate: yup.date()
  //   .required('Period to Date must be filled.'),

  periodFromDate: Yup.date().test('isLower', 'Period From Date must be set before or equal to the Period To Date', (value:any, testContext:any) => {
    if (testContext.parent.periodToDate >= value) {
      return true // Start date is before or equal to end date
    }
    return false // Start date is after end date
  }).required('Period From Date must be filled.'),
  periodToDate: Yup.date().test('isLarger', 'Period To Date must be set after or equal to the Period From Date.', (value:any, testContext:any) => {
    if (testContext.parent.periodFromDate <= value) {
      return true
    }
    return false
  }).required('Period From Date must be filled.'),

  // periodFromDate: Yup.date().required(' Period From Date must be filled.').max(
  //   Yup.ref('periodToDate'),
  //   'This date must be set before or equal to the Period To Date.',
  // ),
  // periodToDate: Yup.date().required('Period To Date must be filled.').min(
  //   Yup.ref('periodFromDate'),
  //   'This date must be set after or equal to the Period From Date.',
  // ),

  nature: yup.string().required('Nature must be selected.'),
  status: yup.string().required('Status must be selected.'),

  address: yup
    .string()
    .required('Address must be filled.').max(4000, 'Address must not be longer than 4000 characters.').strict(),
  // rentPaidToLandlordByEmployer: Yup.number().moreThan(0, 'Rent Paid to Landlord by Employer must be a numeric value greater than 0.').transform((value, originalValue) => (originalValue.trim() === '' ? null : value))
  //   .nullable()
  //   .typeError('Rent Paid To Landlord By Employer must be a valid number.'),
  // rentPaidToLandlordByEmployee: Yup.number().moreThan(0, 'Rent Paid to Landlord by Employee must be a numeric value greater than 0.').transform((value, originalValue) => (originalValue.trim() === '' ? null : value))
  //   .nullable()
  //   .typeError('Rent Paid To Landlord By Employee must be a valid number.'),
  // rentRefundedToEmployeeByEmployer: Yup.number().moreThan(0, 'Rent Refunded to Employee by Employer must be a numeric value greater than 0.').transform((value, originalValue) => (originalValue.trim() === '' ? null : value))
  //   .nullable()
  //   .typeError('Rent Refunded To Employee By Employer must be a valid number.'),
  // rentPaidToEmployerByEmployee: Yup.number().moreThan(0, 'Rent Paid to Employer by Employee must be a numeric value greater than 0.').transform((value, originalValue) => (originalValue.trim() === '' ? null : value))
  //   .nullable()
  //   .typeError('Rent Paid To Employer By Employee must be a valid number.'),
  rentPaidToLandlordByEmployer: yup.number()
    .nullable()
    .transform((value, originalValue) => (originalValue === '' ? null : value))
    .moreThan(0, 'Rent Paid to Landlord by Employer must be a numeric value greater than 0.'),

  rentPaidToLandlordByEmployee: yup.number()
    .nullable('')
    .transform((value, originalValue) => (originalValue === '' ? null : value))
    .moreThan(0, 'Rent Paid to Landlord by Employee must be a numeric value greater than 0.'),

  rentRefundedToEmployeeByEmployer: yup.number()
    .nullable('')
    .transform((value, originalValue) => (originalValue === '' ? null : value))
    .moreThan(0, 'Rent Refunded to Employee by Employer must be a numeric value greater than 0.'),

  rentPaidToEmployerByEmployee: yup.number()
    .nullable('')
    .transform((value, originalValue) => (originalValue === '' ? null : value))
    .moreThan(0, 'Rent Paid to Employer by Employee must be a numeric value greater than 0.'),
})

export const termsValidationSchema = yup.object().shape({
  termCode: yup
    .string()
    .required('TermCode must be required'),
  description: yup.string().required('Description must be required'),
  updateSequence: yup.number()
    .required('UpdateSequence must be required'),

  expression: yup.string().required('expression must be selelcted'),

})

// Employee Reccuring
export const employeeReccuringValidationSchema = yup.object().shape({
  payGroupId: yup.string().required('Pay Group must be selected.'),
  payItemId: yup.string().required('Pay Item must be selected.'),
  // effectiveStartDate: Yup.date().required(' Effective Start Date must be filled.').max(
  //   Yup.ref('effectiveEndDate'),
  //   'Effective Start Date must be set not earlier than Effective End Date.',
  // ),
  // effectiveEndDate: Yup.date().required(' Effective End Date must be filled.').min(
  //   Yup.ref('effectiveStartDate'),
  //   'Effective End Date must be set not earlier than Effective End Date.',
  // ),

  effectiveStartDate: Yup.date()
    .required('Effective Start Date must be filled.')
    .typeError('Invalid date format'),
  effectiveEndDate: Yup.date()
    .nullable() // Allow null or empty end date
    .typeError('Invalid date format')
    .when('effectiveStartDate', (effectiveStartDate, schema) => (effectiveStartDate
      ? schema.min(effectiveStartDate, 'Effective End Date must be set not earlier than Effective End Date.')
      : schema)),

  // remarks: yup.string().required('Effective End Date must be filled.'),
  // baseSalaryTypeId: yup.string().required('Country Localization must be required'),
  // baseSalaryCurrencyId: yup.string().required('Original Currency must be selected.'),
  // baseSalaryCurrencyId: yup.string().required('Base Salary Amount must be filled.'),
  // paymentCurrencyId: yup.string().required('Payment Currency must be selected.'),

})
export const employeeDisregardedDayValidationSchema = yup.object().shape({
  // remarks: yup.string().required('Client Group Entity Name must be required'),
  disregardedDayOthers: Yup.number()
    .typeError('Only numbers should be accepted when user enters value in Disregarded day.')
    .required('Disregarded Day Others must be required.'),
  disregardedDays: Yup.number()
    .typeError('Only numbers should be accepted when user enters value in Disregarded day - Others.')
    .required('Disregarded Days must be required.'),
  // baseSalaryTypeId: yup.string().required('Country Localization must be required'),
})
export const employeeReccuringGeneralValidationSchema = yup.object().shape({
  baseSalaryTypeId: yup.string().required('Country Localization must be required'),
  baseSalaryCurrencyId: yup.string().required('Original Currency must be selected.'),
  baseSalaryAmount: yup.string().required('Base Salary Amount must be filled.')
    .matches(/^\S*$/, 'Base Salary Amount must not contain blank space.')
    .matches(/^\d+(\.\d{1,2})?$/, 'Base Salary Amount must be numeric with up to 2 decimal points.')
    .max(20, 'Base Salary Amount must not be longer than 20 characters.'),
  paymentCurrencyId: yup.string().required('Payment Currency must be selected.'),

  // employeeCodeId: yup
  //   .string()
  //   .required('Client Group Profile Code must be required'),
  // companyBankAccountCodeId: yup.string().required('Client Group Profile Name must be required'),
  // effectiveDate: yup.string().required('Client Group Entity Code must be required'),
  // bankCode: yup.string()
  //   .matches(/^[0-9]+$/, 'Branch Code only allow numeric value')
  //   .matches(/^\S*$/, 'Branch Code must not contain blank space')
  //   .required('Branch Code must be filled'),
  // branchCode: yup.string().required('Country Localization must be required'),
  // accountNumber: yup.string().required('Country Localization must be required'),
  // accountName: yup.string().required('Country Localization must be required'),
  // swiftCode: yup.string()
  //   .matches(/^[A-Z0-9]+$/, 'Swift Code must contain only uppercase alphanumeric characters')
  //   .matches(/^\S*$/, 'Swift Code must not contain blank space')
  //   .max(11, 'Swift Code must not be longer than 35 characters'),
  // paymentReference: yup.string().required('Payment Reference must be required'),
})
export const employeeReccuringFPSValidationSalaryProrationSchema = yup.object().shape({
  salaryProrationMethodId: yup.string().required('Salary Proration Method must be selected.'),
  spM_DivideByFixedDays: yup
    .string()
    .when('salaryProrationMethodId', (salaryProrationMethodId:any, schema) => (salaryProrationMethodId[0] === '9' || salaryProrationMethodId[0] === '6' ? schema.required('Multiply actual days based on must be filled.') : schema)).nullable(),
  spM_ActualDaysMethod: yup.string().required('Divide by fixed days must be selected.'),
})
export const employeeReccuringFPSValidationSchema = yup.object().shape({
  generateBackPay: yup.string().required('The indicator for Auto-generate Backpay by system must be selected.'),
  periodToGenerateBackpay: yup
    .string()
    .when('generateBackPay', (generateBackPay:any, schema) => (generateBackPay[0] === 'Yes' ? schema.required('Period to auto-generate Backpay must be filled.') : schema)).nullable(),
  // optionalEmail: yup.boolean(),
  hsbcmrifpsProxyType: yup.string(),
  hsbcmrifpsProxyID: yup.string(),
})
// Employee Bank Account

export const employeeBankAccountGeneralValidationSchema = yup.object().shape({
  companyBankAccountCodeId: yup.string().required('Company Bank AccountCode must be filled.'),
  accountNumber: yup.string()
    .required('Company Bank Account Code must be filled.')
    .matches(/^[0-9]+$/, 'Account Number only allow numeric value')
    .matches(/^\S*$/, 'Account Number must not contain blank space')
    .max(35, 'Account Number must not be longer than 15 characters'),
  bankCode: yup.string()
    .matches(/^[0-9]+$/, 'Branch Code only allow numeric value')
    .matches(/^\S*$/, 'Bank Code must not contain blank space')
    .max(15, 'Bank Code must not be longer than 15 characters')
    .nullable(),
  branchCode: yup
    .string()
    .matches(/^[0-9]+$/, 'Branch Code only allow numeric value')
    .matches(/^\S*$/, 'Branch Code must not contain blank space')
    .max(15, 'Branch Code must not be longer than 15 characters')
    .nullable(),
  accountName: yup.string().required('Account Name must be filled')
    .max(140, 'Account Number must not be longer than 140 characters.'),
  effectiveDate: yup.string().required('Effective Date must be filled'),
  swiftCode: yup.string()
    .max(11, 'Swift Code must not be longer than 11 characters')
    .matches(/^\S*$/, 'Swift Code must not contain blank space')
    .uppercase('Swift Code must be in uppercase')
    .nullable(),
  // paymentReference: yup
  //   .string()
  //   .when('bankFileFormat', (bankFileFormat:any, schema) => (bankFileFormat === 'HSBC MRI' ? schema.required('Payment Reference must be required') : schema))
  //   .matches(/^\S*$/, 'Payment Reference must not contain blank space')
  //   .matches(/^[a-zA-Z0-9!@#$%^&*()]+$/, 'Payment Reference must not contain blank space')
  //   .max(1000, 'Payment Reference must not be longer than 1000 characters'),
  // paymentReference: yup.string()
  //   .matches(/^\S*$/, 'Payment Reference must not contain blank space')
  //   .matches(/^[a-zA-Z0-9!@#$%^&*()]+$/, 'Payment Reference must not contain blank space')
  //   .max(1000, 'Payment Reference must not be longer than 1000 characters')
  //   .when('bankFileFormat', (bankFileFormat:any, schema) => {
  //     log
  //     if (bankFileFormat[0] === 'HSBC MRI') {
  //       return schema.required('Payment Reference must be required')
  //     }
  //     return schema
  //   }),
  paymentReference: yup.string()
    .max(100, 'Payment Reference must not be longer than 1000 characters')
    .test({
      name: 'consolidateOption',
      exclusive: true,
      message: 'Payment Reference must be filled.',
      test(value, { parent }) {
        if (parent?.bankFileFormat === '0') {
          return !!value
        }
        return true
      },
    })
    .nullable(),
})
export const employeeBankAccountFPSValidationSchema = yup.object().shape({
  hsbcmrifpsProxyType: yup.string().required('hsbcmrifps Proxy Type must be required'),
  hsbcmrifpsProxyID: yup.string()
    .max(34, 'Maximum 34 chars')
    .when('hsbcmrifpsProxyType', (hsbcmrifpsProxyType:any, schema) => {
      if (['SVID (FPS Identifier)', 'EMAL (Email Address)', 'MOBN (Mobile Number)'].includes(hsbcmrifpsProxyType[0] || '')) {
        return schema.required('Conditional (Required if the Proxy Type selected is SVID, EMAL, MOBN and HKID)')
      }
      return schema
    }),
})

export const employeeBankAccountValidationSchema = yup.object().shape({
  hsbcSwiftBcdCode: yup
    .string(),
  // .when('bankFileFormat', (bankFileFormat:any, schema) => {
  //   if (bankFileFormat[0] === 'HSBC MRI') {
  //     return schema.required('Conditional (Required if Point 2 is met)')
  //   }
  //   return schema
  // }),
  hsbcSwiftCode: yup.string().when('hsbcSwiftBcdCode', (hsbcSwiftBcdCode:any, schema) => {
    if (['SWF (Swift Account Code)'].includes(hsbcSwiftBcdCode[0] || '')) {
      return schema.required('Conditional (Required if Point 2 is met)')
    }
    return schema
  }),
  hsbcCountryCode: yup.string().when('hsbcSwiftBcdCode', (hsbcSwiftBcdCode:any, schema) => {
    if (['SWF (Swift Account Code)'].includes(hsbcSwiftBcdCode[0] || '')) {
      return schema.required('Conditional (Required if Point 2 is met)')
    }
    return schema
  }),
  hsbcBankCharge: yup.string().when('hsbcSwiftBcdCode', (hsbcSwiftBcdCode:any, schema) => {
    if (['SWF (Swift Account Code)'].includes(hsbcSwiftBcdCode[0] || '')) {
      return schema.required('Conditional (Required if Point 2 is met)')
    }
    return schema
  }),
})

// employee pension fund

export const employeePensionFundGeneralValidationSchema:any = yup.object().shape < any >({
  entityPensionFundSchemeId: yup
    .string()
    .required('Pension Fund Scheme Code must be selected.').nullable(),
  schemeJoinDate: Yup.date().typeError('Invalid date format').required('Scheme Join Date must be selected').nullable(),
  schemeCeaseDate: Yup.date().typeError('Invalid date format')
    .nullable() // Allowing schemeCeaseDate to be optional
    .test(
      'isLarger',
      'Scheme Cease Date should be set after the Scheme Join Date',
      function (value) {
        const { schemeJoinDate } = this.parent
        if (value && schemeJoinDate) {
          return new Date(value) > new Date(schemeJoinDate)
        }
        return true // If schemeCeaseDate is not provided, the test passes
      },
    ),
  schemeMemberNumber: yup.string().max(10, 'Scheme Member Number must not be longer than 10 characters ').nullable(),
  status: yup.string().required('Status must be selected.').nullable(),
  SchemeTerminationCodeId: yup.number().when('schemeCeaseDate', ([schemeCeaseDate], schema) => (schemeCeaseDate ? yup.string().required('Scheme Termination Code must be selected if the scheme cease date is entered') : yup.string().notRequired())).nullable(),
  // identityType: yup.string().required('Identity Type must be required'),
  // otherReportCurrencyId: yup.string().required('Other Report Currency Id must be required'),
  classId: yup.string().max(8, 'Class ID must not be longer than 8 characters').nullable(),
  // transferCode: yup.string().required('Transfer Code must be required'),
})

export const employeePensionFundPaymentValidationSchema = yup.object().shape({
  // employeeAnnualContributionCap: Yup.number().test('isLarger', 'Employee Calculation Start Date must be selected.', (value:any, testContext:any) => {
  //   console.log(testContext.parent.employerAnnualContributionCap, value, 'checkkkkkkkkkkkkk')

  //   if (testContext.parent.employerAnnualContributionCap > value) return false
  //   return true
  // }),
  employerAnnualContributionCap: Yup.number()
    .nullable()
    .transform((value, originalValue) => (originalValue === '' ? null : Number(originalValue)))
    .min(0, 'Employer Annual Contribution Cap must be greater than or equal to 0')
    .typeError('Employer Annual Contribution Cap must be a number'),

  employeeAnnualContributionCap: Yup.number()
    .nullable()
    .transform((value, originalValue) => (originalValue === '' ? null : Number(originalValue)))
    .min(Yup.ref('employerAnnualContributionCap'), 'Employee Annual Contribution Cap must be greater than or equal to Employer Annual Contribution Cap')
    .typeError('Employee Annual Contribution Cap must be a number'),
  // employerAnnualContributionCap: Yup.string().nullable().min(0, 'Employer Annual Contribution Cap must be greater than or equal to 0'),
  // employeeAnnualContributionCap: Yup.string().nullable()
  //   .min(Yup.ref('employerAnnualContributionCap'), 'Employee Annual Contribution Cap must be greater than or equal to 0'),
  employerCalculationStartDate: Yup.date().required('Employer Calculation Start Date must be selected.'),
  employeeCalculationStartDate: Yup.date().required('Employee Calculation Start Date must be selected.').min(
    Yup.ref('employerCalculationStartDate'),
    'Employee Calculation Start Date must be set before or equal to the Employee Contribution Start Date',
  ),
  employerContributionStartDate: Yup.date().required('Employer Contribution Start Date must be selected.'),
  employeeContributionStartDate: Yup.date().required('Employee Contribution Start Date must be selected.').min(
    Yup.ref('employerContributionStartDate'),
    'Employee Contribution Start Date must be set before or equal to the Employee Contribution Start Date',
  ),

})
export const employeePensionFundFPSValidationSchema = yup.object().shape({
  lspSpFlag: yup.string().nullable(),
  paidAmountForLspSp: Yup.number().test('isLarger', 'Paid Amount for LSP / SP must be provided if the the "LSP / SP (Long Service and Severence Pay) Flag" is selected.', (value:any, testContext:any) => {
    if (testContext.parent.lspSpFlag) {
      if (value) {
        return true
      }
      return false
    }
    return true
  }).moreThan(0, 'Paid Amount for LSP / SP must be greater than 0.').nullable(),
  entitleLspSpAmount: Yup.number().test('isLowest', 'Entitle LSP / SP Amount must be provided if the the "LSP / SP (Long Service and Severence Pay) Flag" is selected.', (value:any, testContext:any) => {
    if (testContext.parent.lspSpFlag) {
      if (value) {
        return true
      }
      return false
    }
    return true
  }).moreThan(0, 'Entitle LSP / SP Amount must be greater than 0.').nullable(),

})
export const employeePensionFundFPSConditionValidationSchema = yup.object().shape({
})

// Report validation

export const standardReportValidationSchema = yup.object().shape({
  payCycleYearFrom: Yup.string()
    .required('Year is required')
    .matches(/^\d{4}$/, 'Year must be exactly 4 digits')
    .matches(/^\S*$/, 'Year must not contain blank spaces'),
  payCycleYearTo: Yup.string()
    .required('Year is required')
    .matches(/^\d{4}$/, 'Year must be exactly 4 digits')
    .matches(/^\S*$/, 'Year must not contain blank spaces'),
  payCycleMonthFrom: Yup.string()
    .required('Month must be selected.'),
  payCycleMonthTo: Yup.string()
    .required('Month must be selected.'),
  // payCycleCode: Yup.array()
  //   .of(Yup.string().required('Pay Cycle Code must be selected.')),
})
// cuurency validation schema
export const validationSchemaCurrency = yup.object().shape({

  currencyCode: yup
    .string()
    .matches(/^[A-Za-z]+$/, 'Currency Code must not contain numeric or symbol')
    .test(
      'no-blank-space',
      'Currency Code must not contain blank space.',
      (value) => {
        if (value && /\s/.test(value)) { // Check for any whitespace character
          return false
        }
        return true
      },
    )
    // .min(3, 'Currency Code must be at least 3 characters long')
    .max(3, 'Currency Code must not be longer than 3 characters')
    .required('Currency Code must be filled'),
  currencyName: yup.string()
    .max(120, 'Currency name must not be longer than 120 characters.')
    .matches(/^[A-Z\s]+$/, 'Currency name must not contain numeric or symbol characters')
    .test('uppercase', 'Currency Name must be in uppercase', (value: string | undefined) => {
      if (value) {
        return value === value.toUpperCase()
      }
      return true
    })
    .required('Currency name must be filled'),
  currencySymbol: yup.string()
    .max(20, 'Currency Symbol must not be longer than 20 characters.')
    .matches(/^[^\d\s]+$/, 'Currency Symbol must not contain space and numeric characters')
    .required('Currency Symbol must be filled'),
})

// cuurency Nationality schema
export const validationSchemaNationality = yup.object().shape({
  nationalityCode: yup
    .string()
    .required('Nationality ID must be filled')
    .max(3, 'Nationality ID must not be longer than 3 characters')
    .matches(/^\S*$/, 'Nationality ID must not contain blank space'),
  nationalityName: yup
    .string()
    .required('Nationality Name must be filled')
    .min(3, 'Country Name must be at least 3 characters')
    .max(120, 'Nationality Name must not be longer than 120 characters'),
})

// employee profile
function isLater(str1:any, str2:any) {
  return new Date(str1) > new Date(str2)
}
export const validationSchemaEmployeeProfile:any = yup.object().shape({
  surname: yup
    .string()
    .required('Surname Code must be filled'),

  givenName: yup
    .string()
    .required('GivenName Name must be filled'),
  // employeeCodeId: yup
  //   .string()
  //   .required('GivenName Name must be filled'),

  employmentStatus: yup
    .string()
    .required('GivenName Name must be filled'),
  payrollIndicator: yup
    .string()
    .required('payrollIndicator Code must be filled'),
  gender: Yup.string().test('isLowest', 'Gender must be selected if "Hong Kong IRD Tax Filing Indicator" is set to Yes.', (value:any, testContext:any) => {
    if (testContext.parent.hongKongIRDTaxFilingIndicator === 'Yes (IR56B)') {
      if (value) {
        return true
      }
      return false
    }
    return true
  }),
  nameInLocalLanguage: yup
    .string()
    .max(400, 'nameInLocalLanguage must be at least 400 characters'),
  displayName: yup
    .string()
    .max(400, 'display Name must be at least 400 characters'),
  christianName: yup
    .string()
    .max(100, 'christian Name must be at least 100 characters'),
  middleName: yup
    .string()
    .max(400, 'Middle Name must be at least 400 characters'),
  identityNumber: yup
    .string()
    .max(20, 'Identity Number must be at least 20 characters').matches(
      /^\S*$/,
      'identity Number must not contain blank space',
    ),
  passportNumber: yup
    .string()
    .max(20, 'Passport Number must be at least 20 characters').matches(
      /^\S*$/,
      'Passport Number must not contain blank space',
    ),

  // passportIssueCountry: yup
  //   .string().required('Passport Issue Country Code must be filled')
  //   .max(20, 'Country Name must be at least 20 characters'),

  passportIssueCountry: Yup.string().test('isLowest', 'Passport Issue Country must be filled if Passport Number is entered and "Hong Kong IRD Tax Filing Indicator" is set to Yes.', (value:any, testContext:any) => {
    if (testContext.parent.passportNumber && testContext.parent.hongKongIRDTaxFilingIndicator === 'Yes (IR56B)') {
      if (value) {
        return true
      }
      return false
    }
    return true
  }),
  // conditional
  maritalStatus: Yup.string().test('isLowest', 'Marital Status must be selected if "Hong Kong IRD Tax Filing Indicator" is set to Yes.', (value:any, testContext:any) => {
    if (testContext.parent.hongKongIRDTaxFilingIndicator === 'Yes (IR56B)') {
      if (value) {
        return true
      }
      return false
    }
    return true
  }),
  spouseName: yup
    .string()
    .max(50, 'Spouse Name must be at least 50 characters'),
  spouseIdentityNumber: yup
    .string()
    .max(50, 'Spouse Identity Number must be at least 50 characters').matches(
      /^\S*$/,
      'Payment Method Code must not contain blank space',
    ),
  // conditional
  spousePassportNumber: yup
    .string()
    .max(20, 'Spouse Passport Number must be at least 20 characters').matches(
      /^\S*$/,
      'Spouse Passport Number must not contain blank space',
    ),
  // condtional
  spousePassportIssueCountry: Yup.string().test('isLowest', 'Spouse Passport Issue Country must be filled if Spouse Passport Number is entered and "Hong Kong IRD Tax Filing Indicator" is set to Yes.', (value:any, testContext:any) => {
    if (testContext.parent.spousePassportNumber && testContext.parent.hongKongIRDTaxFilingIndicator === 'Yes (IR56B)') {
      if (value) {
        return true
      }
      return false
    }
    return true
  }),
  // spousePassportIssueCountry: yup.string().when('surname', {
  //   is: (v:any) => v === 'sandeep',
  //   then: (schema) => schema.required('Spouse Passport Issue Country must be filled'),
  // }).when('givenName', {
  //   is: (v:any) => v === 'singh',
  //   then: (schema) => schema.required('Spouse Passport Issue Country must be filled'),
  // }),

  visaHolderIndicator: yup
    .string()
    .required('Visa Holder Indicator must be filled'),

  // visaExpiryDate: Yup.string()
  //   .max(Yup.ref('visaIssueDate'), 'Visa Expiry Date must be set after the Visa Issue date.'),

  // visaExpiryDate: Yup.string().test('isLowest', 'Visa Expiry Date must be set after the Visa Issue date.', (value:any, testContext:any) => {
  //   const start = new Date(testContext.parent.visaIssueDate)
  //   const end = new Date(value)
  //   if (start > end) {
  //     return false
  //   }
  //   return true
  // }),

  // visaIssueDate: Yup.date()
  //   .required('Start date is required')
  //   .test(
  //     'is-before-end-date',
  //     'Start date must be before end date',
  //     function (value) {
  //       const { visaExpiryDate } = this.parent
  //       return !visaExpiryDate || value < visaExpiryDate
  //     },
  //   ),
  visaExpiryDate: Yup.string()
    .test(
      'is-after-start-date',
      'Visa Expiry Date must be set after the Visa Issue date.',
      (value:any, testContext:any) => {
        if (value && value.trim() !== '' && value !== null && value !== undefined) {
          if (value) {
            return isLater(value, testContext.parent.visaIssueDate)
          }
          return false
        }
        return true
      },
    ).typeError('Invalid date format')
    .nullable(),

  visaFirstLandingDate: Yup.string().test('isLowest', 'Visa First Landing Date must be filled if the "Visa Holder Indicatorr" is set to Yes.', (value:any, testContext:any) => {
    if (testContext.parent.visaHolderIndicator === 'Yes') {
      if (value) {
        return true
      }
      return false
    }
    return true
  }).typeError('Invalid date format')
    .nullable(),
  workEmailAddress: yup
    .string()
    .max(200, 'work Email Address must be at least 3 characters').matches(/^\S*$/, 'Email address must not contain blank space')
    .matches(/^\S*$/, 'Email address must not contain blank space'),
  // condtional
  personalEmailAddress: yup.string()
    .max(200, 'Personal Email Address must be at least 3 characters').matches(/^\S*$/, 'Email address must not contain blank space')
    .matches(/^\S*$/, 'Email address must not contain blank space'),
  mobileNumber: yup
    .string()
    .max(15, 'Mobile Number must be at least 15 characters'),
  homePhoneNumber: yup
    .string()
    .max(15, 'Home Phone Number must be at least 15 characters'),
  // condtional
  officePhoneNumber: yup
    .string()
    .max(15, 'Office Phone Number must be at least 15 characters'),
  // conditional
  residentialAddress: yup
    .string()
    .required('Residential Address must be filled').max(200, 'Residential Address must be at least 200 characters'),
  // conditional
  areaCode: yup
    .string()
    .required('Area Code must be filled'),
  postalAddress: yup
    .string().max(4000, 'Postal Address must be at least 4000 characters'),

})

export const validationSchemaEmployeeProfileEmployment:any = yup.object().shape({

  // commencementDate: Yup.date().test('isLarger', 'Commencement Date must be set after or equal to Date Join Group.', (value:any, testContext:any) => {
  //   if (new Date(testContext.parent.dateJoinGroup) <= new Date(value)) {
  //     return true
  //   }
  //   return false
  // }).required('Commencement Date must be filled.'),
  // dateJoinGroup: yup
  //   .string()
  //   .required('Date Join Group must be filled'),
  // workCalendarCode: yup
  //   .string()
  //   .required('Work Calendar Code must be filled'),
  holdPayment: yup
    .string()
    .required('Hold Payment must be filled'),
  paymentCurrencyCode: yup
    .string()
    .required('Payment Currency must be filled'),
  eligible13thMonthSalary: yup
    .string()
    .required('eligible 13th MonthSalary Name must be filled'),
})

export const validationSchemaEmployeeProfileTax:any = yup.object().shape({
  passportIssueCountry: Yup.string().test('isLowest', 'Passport Issue Country Code must be filled.', (value:any, testContext:any) => {
    if (testContext.parent.passportNumber && testContext.parent.hongKongIRDTaxFilingIndicator === 'Yes (IR56B)') {
      if (value) {
        return true
      }
      return false
    }
    return true
  }),
  quartersProvidedIndicator: yup
    .string()
    .required('Quarters Provided Indicator Code must be filled'),
  // quartersEffectiveDate: yup
  //   .string()
  //   .required('Quarters Effective Date Name must be filled'),
  hongKongIRDTaxFilingIndicator: yup
    .string()
    .required('Hong Kong IRD Tax Filing Indicator Name must be filled'),
  // condtional
  // irdCorporateTitleId: yup
  //   .string()
  //   .required('IRD Corporate Title Id Code must be filled'),

  iR56GDepartureReason: Yup.string().test('isLower', '56G Departure Reason must be filled if the "56G Departure Type" is set to 4.', (value:any, testContext:any) => {
    if (testContext.parent.iR56GDepartureType === '4') {
      if (value) {
        return true
      }
      return false
    }
    return true // Start date is after end date
  }).max(20, '56G Departure Reason must not be longer than 40 characters.'),
  // iR56GMoneyNotHeldReason: yup.string()
  //   .required('iR56G Money Not Held Reason Code must be filled'),

  iR56GMoneyNotHeldReason: Yup.string().test('isLower', '56G Money Not Held Reason must be filled if the "56G Money Held Indicator" to 0.', (value:any, testContext:any) => {
    if (testContext.parent.iR56GReturningIndicator === '0') {
      if (value) {
        return true
      }
      return false
    }
    return true // Start date is after end date
  }).max(20, '56G Money Not Held Reason must not be longer than 40 characters.'),

})

// payment method validation schema
export const validationSchemaPaymentMethod = yup.object().shape({
  paymentMethodCode: yup
    .string()
    .matches(
      /^\S*$/,
      'Payment Method Code must not contain blank space',
    )
    .max(40, 'Payment Method Code must not be longer than 40 characters')
    .required('Payment Method Code must be filled')
    .trim(), // Trim white spaces
  paymentMethodName: yup
    .string()
    .required('Payment Method Name must be filled')
    .max(120, 'Payment Method Name must not be longer than 120 characters'),
  // countryLocalization: yup
  //   .string(),
  // // .required('Country Localization must be selected'),
  remarks: yup.string().max(500, 'Remarks must not be longer than 500 characters'),
})

// setting template
export const validationSchemaSettingTemplate = yup.object().shape({
  settingCode: yup
    .string()
    .required('Setting ID must be filled')
    .matches(/^[a-zA-Z0-9!@#$%^&*()_+{}[\]:;'"|\\<,>.?/`~=-]+$/, {
      message: 'Setting ID must only contain alphanumeric characters and symbols',
      excludeEmptyString: true,
    })
    .max(60, 'Setting ID must not be longer than 60 characters')
    .matches(/^\S*$/, 'Setting ID must not contain blank space.'),
  settingName: yup
    .string()
    .required('Setting Name must be filled')
    .max(120, 'Setting Name must not be longer than 120 characters'),
  countryLocalization: yup
    .string()
    .required('Country Localization must be selected'),
  settingLevel: yup
    .string()
    .required('Setting Level must be selected'),

  category: yup
    .string()
    .required('Category must be filled')
    .max(60, 'Category must not be longer than 60 characters'),
  remarks: yup.string().max(500, 'Remarks must not be longer than 500 characters'),
})

// provider type
export const validationSchemaProviderType = yup.object().shape<any>({
  providerCode: yup
    .string()
    .matches(
      /^[^\s]+$/,
      'Provider Code must not contain blank space',
    )
    .max(20, 'Provider Code must not be longer than 20 characters')
    .required('Provider Code must be filled')
    .strict(), // White space not allowed
  providerName: yup
    .string()
    .required('Provider Name must be filled')
    .max(120, 'Provider Name must not be longer than 120 characters'),
  countryLocalization: yup
    .string()
    .required('Country Localization must be selected'),
  remarks: yup
    .string()
    .max(500, 'Remarks must not be longer than 500 characters'),
  providerType: yup.string().required('Provider Type must be selected'),
  remittanceStatementReportFormat: yup.string().test({
    name: 'conditionalValidation',
    exclusive: true,
    message: 'Remittance Statement Format must be selected.',
    test(value, { parent }) {
      if (parent.providerType === 'Pension Fund') {
        return !!value
      }
      return true
    },
  }),
  remittanceStatementFileFormat: yup.string(),
  remittanceStatementTerminationCode: yup.string(),
})
// Division validation scheme
export const validationSchemaDivision = yup.object().shape({
  divisionCode: yup
    .string()
    .matches(/^[^\s]+$/, 'ent_division_code_must_must_not_blank')
    .max(40, 'ent_division_code_must_must_not_40_character')
    .required('ent_division_code_must_filled')
    .strict(), // White space not allowed
  divisionDescription: yup
    .string()
    .required('ent_division_description_must_filled')
    .max(120, 'ent_division_description_must_must_not_120_character'),
  remarks: yup.string().max(500, 'all_fields_remarks'),
})

// costcenter validation schema
export const validationSchemaCostCenter = yup.object().shape({
  costCenterCode: yup
    .string()
    .matches(/^[^\s]+$/, 'ent_costcenter_code_must_must_not_blank')
    .max(40, 'ent_costcenter_code_must_must_not_40_character')
    .required('ent_costcenter_code_must_filled'),
  costCenterDescription: yup
    .string()
    .max(120, 'ent_costcenter_description_must_must_not_120_character')
    .required('ent_costcenter_description_must_filled'),
  remarks: yup.string().max(500, 'all_fields_remarks'),
})

// Ird validatio scheme
export const validationSchemaIrd = yup.object().shape({
  corporateTitleCode: yup
    .string()
    .matches(/^[^\s]+$/, 'ent_ird_code_must_not_blank')
    .max(40, 'ent_ird_code_must_not_longer_than_40')
    .required('ent_ird_code_must_filled')
    .strict(), // White space not allowed
  corporateTitleName: yup
    .string()
    .required('ent_ird_name_must_filled')
    .max(120, 'ent_ird_name_must_not_longer_than_120'),
  remarks: yup.string().max(500, 'all_fields_remarks'),
})

// Department validation schema
export const validationSchemaDepartment = yup.object().shape({
  departmentCode: yup
    .string()
    // .matches(/^[a-zA-Z0-9!@#$%^&*()]+$/, 'Department Code must not contain blank space')
    .matches(/^[^\s]+$/, 'ent_dept_code_must_not_blank')
    .max(40, 'ent_dept_code_must_not_longer_than_40')
    .required('ent_dept_code_must_filled')
    .strict(), // White space not allowed
  departmentDescription: yup
    .string()
    .required('ent_dept_desc_must_filled')
    .max(120, 'ent_dept_desc_must_not_longer_than_120'),
  remarks: yup.string().max(500, 'ent_dept_remarks_must_not_longer_than_500'),
})
// position validation schema
export const validationSchemaPosition = yup.object().shape({
  positionCode: yup
    .string()
    .matches(/^[^\s]+$/, 'ent_position_code_must_must_not_blank')
    .max(40, 'ent_position_code_must_must_not_40_character')
    .required('ent_position_code_must_filled')
    .strict(), // White space not allowed
  positionDescription: yup
    .string()
    .required('ent_position_description_must_filled')
    .max(120, 'ent_position_description_must_must_not_120_character'),
  remarks: yup.string().max(500, 'all_fields_remarks'),
})

// termination code validation schema
export const validationSchemaTerminationCode = yup.object().shape({
  terminationCode: yup
    .string()
    .matches(/^[^\s]+$/, 'entity_termination_error_not_contain_blank')
    .max(40, 'entity_termination_error_not_more_then_40_character')
    .required('entity_termination_error_code_name')
    .strict(), // White space not allowed
  terminationReason: yup
    .string()
    .required('entity_termination_reason_must_filled')
    .max(120, 'enity_termination_reason_not_more_then_120'),
  remarks: yup.string().max(500, 'all_fields_remarks'),
})

// staff type validation schema
export const validationSchemaStaffType = yup.object().shape({
  staffTypeCode: yup
    .string()
    .matches(/^[^\s]+$/, 'ent_stafftype_code_must_must_not_blank')
    .max(40, 'ent_stafftype_code_must_must_not_40_character')
    .required('ent_stafftype_code_must_filled')
    .strict(), // White space not allowed
  staffTypeDescription: yup
    .string()
    .required('ent_stafftype_description_must_filled')
    .max(120, 'ent_stafftype_description_must_must_not_120_character'),
  remarks: yup.string().max(500, 'all_fields_remarks'),
})
// entity region validation schema
export const validationSchemaRegion = yup.object().shape({
  regionCode: yup
    .string()
    .matches(/^[^\s]+$/, 'region_code_must_not_blank_space')
    .max(40, 'region_code_must_no_longer_then_40_characters')
    .required('region_code_must_be_filled')
    .strict(), // White space not allowed
  regionDescription: yup
    .string()
    .required('ent_region_description_must_filled')
    .max(120, 'region_code_must_no_longer_then_120_characters'),
  remarks: yup.string().max(500, 'all_fields_remarks'),
})
// team validation schema
export const validationSchemaTeam = yup.object().shape({
  teamCode: yup
    .string()
    .matches(/^[^\s]+$/, 'ent_team_code_must_must_not_blank')
    .max(40, 'ent_team_code_must_must_not_40_character')
    .required('ent_team_code_must_filled')
    .strict(), // White space not allowed
  teamDescription: yup
    .string()
    .required('ent_team_description_must_filled')
    .max(120, 'ent_team_description_must_must_not_120_character'),
  remarks: yup.string().max(500, 'all_fields_remarks'),
})
// Grade validation schema
export const validationSchemaGrade = yup.object().shape({
  gradeCode: yup
    .string()
    .matches(/^[^\s]+$/, 'ent_grade_code_blank_space_err')
    .max(40, 'ent_grade_code_max_char_err')
    .required('ent_grade_code_must_fill')
    .strict(), // White space not allowed
  gradeDescription: yup
    .string()
    .required('ent_grade_description_must_fill')
    .max(120, 'ent_grade_description_max_char_err'),
  remarks: yup.string().max(500, 'all_fields_remarks'),
})

export const validationUserRolesSchema = yup.object().shape({
  roleCode: yup.string()
    .matches(/^\S*$/, 'User Role ID must not contain blank space.').max(30, 'User Role ID must not be longer than 30 characters').required('User Role ID must be filled'),
  roleName: yup.string().max(120, 'Role Name must not be longer than 120 characters.').required('User Role Name must be filled'),
  roleType: yup.string().required('User Role Type must be selected.'),
  // remarks: yup.string().max(500, 'Remarks must not be longer than 500 character.'),

})

export const validationSchemaUserAccount = yup.object().shape({
  username: yup
    .string()
    // .matches(/^[a-zA-Z0-9!@#$%^&*()]+$/, 'Setting Code must not contain blank space')
    .max(120, 'Usernamemust not be longer than 120 characters')
    .required('Username must be filled'),
  firstName: yup
    .string()
    .required('First Name must be filled')
    .max(120, 'First Name must not be longer than 120 characters'),
  lastName: yup
    .string()
    .required('Last Name must be filled')
    .max(120, 'SLast Name must not be longer than 120 characters'),
  emailAddress: yup
    .string()
    .required('Email address must be filled')
    .matches(/^[\s\S\d]{1,120}$/, 'Email address must not contain blank space')
    .matches(/^\S*$/, 'Email address must not contain blank space')
    .max(120, 'Email address must not be longer than 120 characters'),
  mobileNumber: yup
    .string()
    .max(120, 'Phone number must not be longer than 120 characters')
    .matches(/^[0-9()+ -]*$/, 'Phone number must not contain symbols except "-", "(", ")", "+"'),
  officeNumber: yup
    .string()
    .max(120, 'Phone number must not be longer than 120 characters')
    .matches(/^[0-9()+ -]*$/, 'Phone number must not contain symbols except "-", "(", ")", "+"'),
  // defaultLanguage: yup
  //   .string()
  //   .required('Default language must be selected'),
  // defaultTimeZone: yup
  //   .string()
  //   .required('Default Timezone must be selected'),
  remarks: yup.string().max(500, 'all_fields_remarks'),
  // descriptionInPensionFundSection: yup
  //   .string()
  //   .required('Description In Pension Fund Section must be filled'),
})

// global pension fund scheme item rule
export const validationPFSR = yup.object().shape({

  countryLocalization: yup
    .string()
    .required('countryLocalization must be selected.'),

  pensionFundSchemeRuleType: yup
    .string()
    .max(40, 'Pension Fund Scheme Rule Type must not be longer than 40 characters')
    .required('Pension Fund Scheme Rule Type must be filled'),

  effectiveStartDate: yup
    .date()
    .nullable('effective Start Date must be filled')
    .max(yup.ref('effectiveEndDate'), 'Effective Start Date must be set before the End Date')
    .test(
      'Is date greater',
      "effective Start Date cannot be greater than today's date",
      (value) => {
        if (!value) return true
        return moment(today).diff(value) > 0
      },
    )
    .required('Effective Start Date must be filled'),

  effectiveEndDate: yup
    .date()
    .min(yup.ref('effectiveStartDate'), 'Effective End Date must be set after the Start Date')
    .default(() => new Date('3000-12-31')) // Set default end date if not provided
    .required('Effective End Date must be filled'),

  relevantIncomeMinAmount: yup
    .number()
    .typeError('Relevant Income Min Amount must be a number')
    .min(0, 'Relevant Income Min Amount must be greater than or equal to 0')
    .transform((value, originalValue) => (Number.isNaN(originalValue) || originalValue === '' ? undefined : Number(originalValue)))
    .required('Relevant Income Min Amount must be filled')
    .test({
      name: 'less-than-relevant-income-max',
      message: 'Relevant Income Min Amount must be set less than Relevant Income Max Amount',
      test(value) {
        const { relevantIncomeMaxAmount } = this.parent
        return value === undefined || relevantIncomeMaxAmount === undefined || value < relevantIncomeMaxAmount
      },
    }),
  relevantIncomeMaxAmount: yup
    .number()
    .typeError('Relevant Income Max Amount must be a number')
    .min(0, 'Relevant Income Max Amount must be greater than or equal to 0')
    .transform((value, originalValue) => (Number.isNaN(originalValue) || originalValue === '' ? undefined : Number(originalValue)))
    .required('Relevant Income Max Amount must be filled')
    .test({
      name: 'greater-than-relevant-income-min',
      message: 'Relevant Income Max Amount must be set greater than Relevant Income Min Amount',
      test(value) {
        const { relevantIncomeMinAmount } = this.parent
        return value === undefined || relevantIncomeMinAmount === undefined || value > relevantIncomeMinAmount
      },
    }),
  ageFrom: yup
    .number()
    .typeError('Age From must be a number')
    .min(0, 'Age From must be greater than or equal to 0')
    .max(99, 'Age From should be less than or equal to 99')
    .test(
      'is-less-than-age-to',
      'Age From must be less than Age To',
      function (value) {
        const { ageTo } = this.parent
        return value === undefined || ageTo === undefined || value < ageTo
      },
    ),

  ageTo: yup
    .number()
    .typeError('Age To must be a number')
    .min(0, 'Age To must be greater than Age From')
    .max(100, 'Age To should be less than or equal to 99')
    .test(
      'is-greater-than-age-from',
      'Age To must be greater than Age From',
      function (value:any) {
        const { ageFrom } = this.parent
        return value === undefined || ageFrom === undefined || value > ageFrom
      },
    ),
  // .default(99),

  employerContributionRate: yup
    .number()
    .typeError('Employer Contribution Rate must be a number')
    .min(0, 'Employer Contribution Rate must be greater than or equal to 0')
    .max(100, 'Employer Contribution Rate must be less than or equal to 100'),
  // Employee Contribution Rate
  employeeContributionRate: yup
    .number()
    .typeError('Employee Contribution Rate must be a number')
    .min(0, 'Employee Contribution Rate must be greater than or equal to 0')
    .max(100, 'Employee Contribution Rate must be less than or equal to 100'),
  // Employer Fixed Contribution Amount

  employerFixedContributionAmount: yup
    .number()
    .typeError('Employer Fixed Contribution Amount must be a number')
    .min(0, 'Employer Fixed Contribution Amount must be greater than or equal to 0')
    .max(999999999, 'Employer Fixed Contribution Amount must be less than or equal to 999999999'),

  employeeFixedContributionAmount: yup
    .number()
    .typeError('Employee Fixed Contribution Amount must be a number')
    .min(0, 'Employee Fixed Contribution Amount must be greater than or equal to 0')
    .max(999999999, 'Employee Fixed Contribution Amount must be less than or equal to 999999999'),

  employerAnnualContributionCap: yup
    .number()
    .typeError('Employer Annual Contribution Cap must be a number')
    .min(0, 'Employer Annual Contribution Cap must be greater than or equal to 0')
    .max(999999999, 'Employer Annual Contribution Cap must be less than or equal to 999999999'),

  employeeAnnualContributionCap: yup
    .number()
    .typeError('Employee Annual Contribution Cap must be a number')
    .min(0, 'Employee Annual Contribution Cap must be greater than or equal to 0')
    .max(999999999, 'Employee Annual Contribution Cap must be less than or equal to 999999999'),

})
// Holiday calender
export const validationSchemaHolidayCalender = yup.object().shape({
  holidayCalendarCode: yup
    .string()
    // .trim() // Remove leading and trailing whitespace
    .test(
      'no-blank-space',
      'Holiday Calendar ID must not contain blank space.',
      (value) => {
        if (value && /\s/.test(value)) { // Check for any whitespace character
          return false
        }
        return true
      },
    )
    // .matches(/^[a-zA-Z0-9!@#$%^&*()_+{}[\]:;"'<>,./?|\\-]+$/, 'Holiday Calendar Code must contain only alphanumeric characters and symbols')
    .max(30, 'Holiday Calendar ID must not be longer than 30 characters')
    .required('Holiday Calendar ID must be filled'),

  holidayCalendarName: yup
    .string()
    .trim() // Remove leading and trailing whitespace
    .required('Holiday Calendar Name must be filled.')
    .max(120, 'Holiday Calendar Name must not be longer than 120 characters'),
  remarks: yup.string().max(500, 'all_fields_remarks'),
  status: yup
    .string()
    .required('Status must be selected.'),
})
export const validationSchemaHolidayCalenderDates = yup.object().shape({
  fromDate: yup
    .string()
    .trim() // Remove leading and trailing whitespace
    .required('Holiday Date must be filled.'),
  toDate: yup
    .string()
    .trim() // Remove leading and trailing whitespace
    .required('Holiday Date must be filled.'),
  holidayType: yup
    .object()
    .required('Holiday Type must be selected.'),
})
// entity  ServiceProvider
export const validationSchemaServiceProvider = yup.object().shape({
  providerCode: yup
    .string()
    .required('Provider Type must be selected.'),
  providerName: yup
    .string()
    .trim() // Remove leading and trailing whitespace
    .required('Service Provider Name must be filled.')
    .max(120, 'Service Provider Name must not be longer than 120 characters'),
  providerContactPerson: yup.string().max(120, 'Provider Contact Person must not be longer than 120 characters'),

  providerPhoneNo: yup
    .string()
    .max(120, 'Phone number must not be longer than 120 characters.')
    .test('is-empty-or-valid', 'Phone number must not contain symbols except "-", "(", ")", "+".', (value) => {
      if (!value) return true // No error if value is empty
      return /^[\d()+/-]*$/.test(value) // Check if it contains only valid symbols
    }),
  providerFaxNo: yup
    .string()
    .max(120, 'Fax Number must not be longer than 120 characters')
    .test('is-empty-or-valid', 'Fax number must not contain symbols except "-", "(", ")", "+".', (value) => {
      if (!value) return true // No error if value is empty
      return /^[\d()+/-]*$/.test(value) // Check if it contains only valid symbols
    }),

  officePhoneNo: yup
    .string()
    .max(120, 'FOffice Phone Number must not be longer than 120 characters')
    .test('is-empty-or-valid', 'Office Phone number must not contain symbols except "-", "(", ")", "+".', (value) => {
      if (!value) return true // No error if value is empty
      return /^[\d()+/-]*$/.test(value) // Check if it contains only valid symbols
    }),

  officeFaxNo: yup
    .string()
    .max(120, 'Office Fax Number must not be longer than 120 characters')
    .test('is-empty-or-valid', 'Office Fax number must not contain symbols except "-", "(", ")", "+".', (value) => {
      if (!value) return true // No error if value is empty
      return /^[\d()+/-]*$/.test(value) // Check if it contains only valid symbols
    }),

  providerEmailAddress: yup
    .string()
    .email('Invalid email address')
    .max(120, 'Provider Email Address must not be longer than 120 characters.')
    .test('no-blank-space', 'Enter a valid email address', (value) => {
      if (!value) return true // No error if value is empty
      return /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/.test(value) // Check if it doesn't contain any whitespace
    }),
  // .string()
  // .max(120, 'Provider Email must not be longer than 120 characters')
  // .matches(
  //   /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/,
  //   'Enter a valid email address',
  // ),
  // providerEmailAddress: yup.string().max(120, 'Provider Email must not be longer than 120 characters'),
  providerAddressLine1: yup.string().max(120, 'Address Line-1 must not be longer than 120 characters.'),
  providerAddressLine2: yup.string().max(120, 'Address Line-2 must not be longer than 120 characters.'),
  providerAddressLine3: yup.string().max(120, 'Address Line-3 must not be longer than 120 characters.'),
  employerName: yup
    .string()
    .required('Employer Name must be filled.')
    .max(120, 'Provider Employer Name must not be longer than 120 characters'),

  employerRegistrationFileNo: yup.string()
    .when('providerCode', (providerCode: any, schema: yup.StringSchema<string | undefined>) => {
      if (providerCode === 'Inland Revenue') {
        return schema.required('Employer Registration/File No. must be filled.')
          .max(60, 'Employer Registration/File No. must not be longer than 60 characters.')
      }
      return schema
    }),
  employerPICName: yup.string().max(120, 'Contact Persons Name must not be longer than 120 characters.'),
  employerPICDesignation: yup.string().max(120, 'Contact Persons Designation must not be longer than 120 characters.'),
  employerPICSignatureRemarks: yup.string().max(120, 'Employer Registration/File No. must not be longer than 120 characters.'),

})
// Pay Item Group
export const validationSchemaPayItemGroup = yup.object().shape({
  itemGroupCode: yup
    .string()
    .trim()
    .required('Item Group Code must be filled.')
    .matches(/^\S+$/, 'Item Group Code must not contain blank space')
    .matches(/^[a-zA-Z0-9!@#$%^&*()_+{}[\]:;"'<>,./?|\\-]+$/, 'Item Group Code must contain only alphanumeric characters and symbols')
    .max(10, 'Item Group Code must not be longer than 10 characters'),
  itemGroupName: yup
    .string()
    .required('Item Group Name must be filled.')
    .max(60, 'Item Group Name must not be longer than 60 characters.'),
  remarks: yup.string().max(500, 'all_fields_remarks'),
  // status: yup
  //   .string()
  //   .required('Status must be selected.'),
})
// pay group
export const validationSchemaPayGroup = yup.object().shape({
  payGroupCode: yup
    .string()
    .required('Pay Group Code must be filled.')
    .max(10, 'Pay Group Code must not be longer than 10 characters.')
    .matches(/^\S*$/, 'Pay Group Code must not contain blank space.'),

  payGroupName: yup
    .string()
    .required('Pay Group Name must be filled.')
    .max(120, 'Pay Group Name must not be longer than 120 characters.'),

  remarks: yup.string().max(500, 'all_fields_remarks'),

  payCycleName: yup
    .string()
    .required('Pay Cycle Name must be filled.')
    .max(120, 'Pay Cycle Name must not be longer than 120 characters.'),

  // payCycleCode: Yup.object().shape({
  //   id: Yup.number()
  //     .nullable()
  //     .required('ID is required'),
  //   label: Yup.string()
  //     .nullable()
  //     .required('Label is required'),
  // }).required('Pay Cycle Code must be selected.').strict(true),
  // payrollPeriodStartMonth: Yup.object().shape({
  //   id: Yup.number()
  //     .nullable()
  //     .required('ID is required'),
  //   label: Yup.string()
  //     .nullable()
  //     .required('Label is required'),
  // }).required('Payroll period start month must be selected.').strict(true),

  // payrollPeriodStartDay: Yup.object().shape({
  //   id: Yup.number()
  //     .nullable()
  //     .required('ID is required'),
  //   label: Yup.string()
  //     .nullable()
  //     .required('Label is required'),
  // }).required('The day of Payroll Period Start Date must be selected.').strict(true),

  // payrollPeriodEndMonth: Yup.object().shape({
  //   id: Yup.number()
  //     .nullable()
  //     .required('ID is required'),
  //   label: Yup.string()
  //     .nullable()
  //     .required('Label is required'),
  // }).required('The month of Payroll Period End Date must be selected.').strict(true),

  // payrollPeriodEndDay: Yup.object().shape({
  //   id: Yup.number()
  //     .nullable()
  //     .required('ID is required'),
  //   label: Yup.string()
  //     .nullable()
  //     .required('Label is required'),
  // }).required('The day of Payroll Period End Date must be selected.').strict(true),

  // status: Yup.object().shape({
  //   id: Yup.number()
  //     .nullable()
  //     .required('ID is required'),
  //   label: Yup.string()
  //     .nullable()
  //     .required('Label is required'),
  // }).required('Status must be selected.').strict(true),

  status: yup.object().shape({
    id: yup.number().required('Status must be selected.'),
    label: yup.string(),
  }),

  payrollPeriodStartMonth: yup.object().shape({
    id: yup.number().required('Payroll period start month must be selected.'),
    label: yup.string(),
  }),

  payCycleCode: yup.object().shape({
    id: yup.number().required('Pay Cycle Code must be selected.'),
    label: yup.string(),
  }),

  payrollPeriodStartDay: yup.object().shape({
    id: yup.number().required('The day of Payroll Period Start Date must be selected.'),
    label: yup.string(),
  }),

  payrollPeriodEndMonth: yup.object().shape({
    id: yup.number().required('The month of Payroll Period End Date must be selected.'),
    label: yup.string(),
  }),

  payrollPeriodEndDay: yup.object().shape({
    id: yup.number().required('The day of Payroll Period End Date must be selected.'),
    label: yup.string(),
  }),

  cutOffDateMethod: Yup.object().shape({
    id: Yup.string().nullable(),
    label: Yup.string().nullable(),
  }).nullable(),

  cutOffDateDay: Yup.object().shape({
    id: Yup.number()
      .nullable()
      .test({
        name: 'cutOffDateValidation',
        message: 'ID is required',
        test(value, context) {
          const { cutOffDateMethod } = context.parent
          // Check if cutOffDateMethod is an object and has the id property not equal to '3'
          if (cutOffDateMethod && cutOffDateMethod.id !== '3') {
            // Ensure that value is present and not empty
            return Boolean(value)
          }
          return true
        },
      }),
    label: Yup.string()
      .nullable()
      .test({
        name: 'cutOffDateValidation',
        message: 'Label is required',
        test(value, context) {
          const { cutOffDateMethod } = context.parent
          // Check if cutOffDateMethod is an object and has the id property not equal to '3'
          if (cutOffDateMethod && cutOffDateMethod.id !== '3') {
            // Ensure that value is present and not empty
            return Boolean(value)
          }
          return true
        },
      }),
  })
    .nullable()
    .test({
      name: 'cutOffDateValidation',
      message: 'Cut-off date must be selected',
      test(value, context) {
        const { cutOffDateMethod } = context.parent
        // Check if cutOffDateMethod is an object and has the id property not equal to '3'
        if (cutOffDateMethod && cutOffDateMethod.id !== '3') {
          // Ensure that value is present and not empty
          return Boolean(value && value.id)
        }
        return true
      },
    }),

  payDateMethod: Yup.object().shape({
    id: Yup.string().nullable(),
    label: Yup.string().nullable(),
  }).nullable(),

  payDateDay: Yup.object().shape({
    id: Yup.number()
      .nullable()
      .test({
        name: 'payDateValidation',
        message: 'ID is required',
        test(value, context) {
          const { payDateMethod } = context.parent
          // Check if payDateMethod is an object and has the id property not equal to '3'
          if (payDateMethod && payDateMethod.id !== '3') {
            // Ensure that value is present and not empty
            return Boolean(value)
          }
          return true
        },
      }),
    label: Yup.string()
      .nullable()
      .test({
        name: 'payDateValidation',
        message: 'Label is required',
        test(value, context) {
          const { payDateMethod } = context.parent
          // Check if payDateMethod is an object and has the id property not equal to '3'
          if (payDateMethod && payDateMethod.id !== '3') {
            // Ensure that value is present and not empty
            return Boolean(value)
          }
          return true
        },
      }),
  })
    .nullable()
    .test({
      name: 'payDateValidation',
      message: 'Pay date day must be selected',
      test(value, context) {
        const { payDateMethod } = context.parent
        // Check if payDateMethod is an object and has the id property not equal to '3'
        if (payDateMethod && payDateMethod.id !== '3') {
          // Ensure that value is present and not empty
          return Boolean(value && value.id)
        }
        return true
      },
    }),

  // cutOffDateMethod: Yup.object().shape({
  //   id: Yup.string().nullable(),
  //   label: Yup.string().nullable(),
  // }).nullable(),

  // cutOffDateDay: Yup.object().shape({
  //   id: Yup.number()
  //     .nullable()
  //     .required('ID is required'),
  //   label: Yup.string()
  //     .nullable()
  //     .required('Label is required'),
  // }).required('Cut-off date must be selected.').strict(true),

  // payDateMethod: Yup.object().shape({
  //   id: Yup.string().nullable(),
  //   label: Yup.string().nullable(),
  // }).nullable(),

  // payDateDay: Yup.object().shape({
  //   id: Yup.number()
  //     .nullable()
  //     .required('ID is required'),
  //   label: Yup.string()
  //     .nullable()
  //     .required('Label is required'),
  // }).required('Pay date day must be selected.').strict(true),

})
export const validationSchemaPayItem = yup.object().shape({
  payItemCode: yup
    .string()
    .matches(/^[^\s]+$/, 'Pay Item Code must not contain blank space.')
    .max(30, 'Pay Item Code must not be longer than 30 characters')
    .required('Pay Item Code must be filled')
    .strict(), // White space not allowed
  payItemName: yup
    .string()
    .max(120, 'Pay Item Name must not be longer than 120 characters')
    .required('Pay Item Name must be filled')
    .strict(), // White space not allowed
  payItemLocalName: yup
    .string()
    .nullable()
    .max(120, 'Pay Item Local Name must not be longer than 120 characters'),
  // .strict(), // White space not allowed
  status: yup
    .string()
    .required('Status must be selected.'),
  payType: yup
    .string()
    .required('Pay Type must be selected.'),
  incomeType: yup
    .string()
    .required('Pay Type must be selected.'),
  unitBase: yup
    .string()
    .required('Pay Type must be selected.'),
  paymentMethod: yup
    .string()
    .required('Payment Method must be selected.'),
  grossNetPay: yup
    .string()
    .required('Gross Net Pay must be selected.'),
  taxableWage: yup
    .boolean()
    .required('Taxable flag must be selected.'),
  eaoRegardedWage: yup
    .boolean()
    .required('EAO Regarded Wage must be selected.'),
  eaoCawWage: yup
    .boolean()
    .required('EAO CAW Wage must be selected.'),
  calculationBasedOnCoveringPeriod: yup
    .boolean()
    .required('EAO Avg. Wage by Covering Period must be selected.'),
  pensionFundableWage: Yup.string().required('Pension Fund-able Wage must be selected.'),

  // pensionFundSchemeCode: Yup.string().test({
  //   name: 'conditionalValidation',
  //   exclusive: true,
  //   message: 'Form Number must be filled if the Remittance File Format is "HSBC".',
  //   test(value, context) {
  //     const { pensionFundableWage } = context.parent
  //     if (pensionFundableWage === true) {
  //       return !!value || this.createError({
  //         message: 'Form Number must be filled if the Remittance File Format is "HSBC".',
  //       })
  //     }
  //     return true
  //   },
  // }),

  // pensionFundSchemeCode: Yup.string()
  //   .required('Pay Cycle Code must be selected.')
  //   .test({
  //     name: 'is-string',
  //     message: 'Pension Fund Scheme Code must be a string.',
  //     test(value) {
  //       return typeof value === 'string'
  //     },
  //   }),
  displaySequence: Yup.string()
    .nullable()
    .matches(/^\d+$/, 'Display Sequence must be filled in numbers only.') // Only numbers
    .max(2, 'Display Sequence must be 2 digit'), // Maximum 2 digits
})
// entity settings schema
export const validationSchemaSettings = yup.object().shape({
  settingCode: yup
    .string()
    .matches(/^[^\s]+$/, 'Setting Code must not contain blank space.')
    .max(60, 'Setting Code must not be longer than 60 characters')
    .required('Setting Code must be filled')
    .strict(), // White space not allowed
  settingName: yup
    .string()
    .required('Setting Name must be filled')
    .max(120, 'Setting Name must not be longer than 120 characters'),
  category: yup
    .string()
    .required('Category must be filled')
    .max(60, 'Category must not be longer than 60 characters'),

  settingValue: yup.string()
    .required('Setting Value must be filled')
    .max(60, 'Setting Value must not be longer than 60 characters'),
  remarks: yup.string().max(500, 'Remarks must not be longer than 500 character.'),

})
// Entity currency exchange schema
export const validationSchemaCurrencyExchange = yup.object().shape({
  currencyFrom: yup.string()
    .test(
      'not-same-as-currency-to',
      'Currency From and Currency To must be different.',
      function (value) {
        const { currencyTo } = this.parent
        // Check if both values are different
        return value !== currencyTo
      },
    )
    .required('Currency From must be selected.'),
  currencyTo: yup.string()
    .test(
      'not-same-as-currency-from',
      'Currency From and Currency To must be different.',
      function (value) {
        const { currencyFrom } = this.parent
        // Check if both values are different
        return value !== currencyFrom
      },
    )
    .required('Currency To must be selected.'),
  currencyFromToCheck: yup.string()
    .test(
      'not-same-as-currency-to',
      'Currency From and Currency To must be different.',
      function (value) {
        const { currencyTo } = this.parent
        return value !== currencyTo
      },
    ),
  conversionMethod: yup
    .string()
    .required('Conversion Method must be selected.'),
  exchangeRate: yup.string()
    .matches(/^\d{1,9}(\.\d{0,6})?$/, 'Exchange Rate must be maximum up to 9 integral part with 6 decimal points.')
    .test('noBlankSpace', 'Exchange Rate must not contain blank space.', (value) => {
      if (!value) return true
      return !/\s/.test(value)
    })
    .required('Exchange Rate must be filled.'),
  effectiveDate: yup.date()
    .nullable() // Allow null values
    .required('Effective Date must be filled.')
    .typeError('Effective Date must be filled.'),
})
// validation scheme employemovment type
export const validationSchemaEmploymentType = yup.object().shape({
  movementType: yup
    .string()
    .max(20, 'Movement Type must not be longer than 20 characters')
    .required('Movement Type must be filled')
    .strict(), // White space not allowed
  movementDescription: yup
    .string()
    .required('Movement Description must be filled')
    .max(120, 'Movement Description must not be longer than 120 characters'),
  status: yup
    .boolean()
    .required('Status must be selected.'),

  remarks: yup.string().max(500, 'all_fields_remarks'),
})
// entity pension fund scheme item

export const validationSchemaPensionFundSchemeItem = yup.object().shape({
  pensionFundSchemeCode: yup
    .string()
    .required('Pension Fund Scheme Code must be selected.'),
  payItemCode: yup
    .string()
    .required('Pay Item Code must be selected.')
    .strict(), // White space not allowed
  status: yup
    .boolean()
    .required('Status must be selected.')
    .strict(), // White space not allowed
  effectiveStartDate: yup
    .date()
    .max(yup.ref('effectiveEndDate'), 'Effective Start Date must be set before the End Date')
    .required('Effective Start Date must be filled'),
  effectiveEndDate: yup
    .date()
    .min(yup.ref('effectiveStartDate'), 'Effective End Date must be set after the Start Date')
    .default(() => new Date('3000-12-31')) // Set default end date if not provided
    .required('Effective End Date must be filled'),
})
// entity pension fund schme rule schema
export const validationSchemaPensionFundSchemeRule = yup.object().shape({
  // Pension Fund Scheme Rule Type
  pensionFundSchemeRuleType: yup
    .string()
    .max(40, 'Pension Fund Scheme Rule Type must not be longer than 40 characters')
    .required('Pension Fund Scheme Rule Type must be filled'),
  // effective start date
  effectiveStartDate: yup
    .date()
    .nullable()
    .transform((value, originalValue) => (originalValue === '' ? null : value))
    .required('Effective Start Date must be filled and correct')
    .max(
      yup.ref('effectiveEndDate'),
      'Effective Start Date must be set before the End Date',
    )
  // Commented out the date validation if you don't want to restrict it with today's date
  // .test(
  //   'is-date-valid',
  //   "Effective Start Date cannot be greater than today's date",
  //   (value) => {
  //     if (!value) return true;
  //     return moment().isSameOrAfter(value, 'day');
  //   },
  // )
    .test(
      'not-same-as-end-date',
      'Effective Start Date must be set before the End Date',
      function (value) {
        const { effectiveEndDate } = this.parent
        return value && effectiveEndDate ? !moment(value).isSame(effectiveEndDate, 'day') : true
      },
    ),

  effectiveEndDate: yup
    .date()
    .nullable()
    .transform((value, originalValue) => (originalValue === '' ? null : value))
    .required('Effective End Date must be filled and correct')
    .min(
      yup.ref('effectiveStartDate'),
      'Effective End Date must be set after the Start Date',
    )
    .default(() => new Date('3000-12-31'))
    .test(
      'not-same-as-start-date',
      'Effective End Date must be set after the Start Date',
      function (value) {
        const { effectiveStartDate } = this.parent
        return value && effectiveStartDate ? !moment(value).isSame(effectiveStartDate, 'day') : true
      },
    ),
  // Relevant Income Min Amount
  relevantIncomeMinAmount: yup
    .number()
    .typeError('Relevant Income Min Amount must be a number')
    .min(0, 'Relevant Income Min Amount must be greater than or equal to 0')
    .transform((value, originalValue) => (Number.isNaN(originalValue) || originalValue === '' ? undefined : Number(originalValue)))
    .test({
      name: 'less-than-relevant-income-max',
      message: 'Relevant Income Min Amount must be less than Relevant Income Max Amount',
      test(value) {
        const { relevantIncomeMaxAmount } = this.parent
        return value === undefined || relevantIncomeMaxAmount === undefined || value < relevantIncomeMaxAmount
      },
    })
    .required('Relevant Income Min Amount must be filled'),

  relevantIncomeMaxAmount: yup
    .number()
    .typeError('Relevant Income Max Amount must be a number')
    .min(0, 'Relevant Income Max Amount must be greater than or equal to 0')
    .transform((value, originalValue) => (Number.isNaN(originalValue) || originalValue === '' ? undefined : Number(originalValue)))
    .test({
      name: 'greater-than-relevant-income-min',
      message: 'Relevant Income Max Amount must be greater than Relevant Income Min Amount',
      test(value) {
        const { relevantIncomeMinAmount } = this.parent
        return value === undefined || relevantIncomeMinAmount === undefined || value > relevantIncomeMinAmount
      },
    })
    .required('Relevant Income Max Amount must be filled'),

  // year Of Service From
  yearOfServiceFrom: yup
    .number()
    .typeError('Year Of Service From must be filled')
    .min(0, 'Year Of Service From must be greater than or equal to 0')
    .max(yup.ref('yearOfServiceTo'), 'Year of Service From must be set less than Year of Service To'),

  yearOfServiceTo: yup
    .number()
    .typeError('Year Of Service To must be filled')
    .min(0, 'Year Of Service To must be greater than or equal to 0')
    .moreThan(yup.ref('yearOfServiceFrom'), 'Year of Service To must be set greater than Year of Service From'),

  // Employer Contribution Rate
  employerContributionRate: yup
    .number()
    .typeError('Employer Contribution Rate must be a number')
    .min(0, 'Employer Contribution Rate must be greater than or equal to 0')
    .max(100, 'Employer Contribution Rate must be less than or equal to 100'),
  // Employee Contribution Rate
  employeeContributionRate: yup
    .number()
    .typeError('Employee Contribution Rate must be a number')
    .min(0, 'Employee Contribution Rate must be greater than or equal to 0')
    .max(100, 'Employee Contribution Rate must be less than or equal to 100'),
  // Employer Fixed Contribution Amount
  employerFixedContributionAmount: yup
    .number()
    .typeError('Employer Fixed Contribution must be a number')
    .min(0, 'Employer Fixed Contribution Amount must be greater than or equal to 0')
    .max(999999999, 'Employer Fixed Contribution Amount must be less than or equal to 999999999'),

  // Employee Fixed Contribution Amount
  employeeFixedContributionAmount: yup
    .number()
    .typeError('Employee Fixed Contribution must be a number')
    .min(0, 'Employee Fixed Contribution Amount must be greater than or equal to 0')
    .max(999999999, 'Employee Fixed Contribution Amount must be less than or equal to 999999999'),

  // employer Annual Contribution Cap
  employerAnnualContributionCap: yup
    .number()
    .typeError('Employer Annual Contribution Cap Amount must be a number')
    .min(0, 'Employer Annual Contribution Cap must be greater than or equal to 0')
    .max(999999999, 'Employer Annual Contribution Cap must be less than or equal to 999999999'),

  // employee Annual Contribution Cap
  employeeAnnualContributionCap: yup
    .number()
    .typeError('Employee Annual Contribution Cap Amount must be a number')
    .min(0, 'Employee Annual Contribution Cap must be greater than or equal to 0')
    .max(999999999, 'Employee Annual Contribution Cap must be less than or equal to 999999999'),

})

// costcenter validation schema
export const validationSchemaWorkCalender = yup.object().shape({
  workCalendarCode: yup
    .string()
    .max(20, 'Work Calendar Code must not be longer than 20 characters')
    .matches(/^[^\s]+$/, 'Work Calendar Code must not contain blank space.')
    .required('Work Calendar Code must be filled'),

  workCalendarName: yup
    .string()
    .max(120, 'Work Calendar Name must not be longer than 120 characters.')
    .required('Work Calendar Name must be filled.'),

  holidayCalendar: yup
    .string()
    .required('Holiday Calendar must be selected.'),

  holidaysPaymentOption: yup
    .string()
    .required('Holidays Payment Option must be selected.'),

  salaryProrationMethod: yup.string().required('Salary Proration Method must be selected'),
  spM_DivideByFixedDays: yup.string().test({
    name: 'conditionalValidation',
    exclusive: true,
    message: 'Salary Proration Method - Divide by Fixed Days is required',
    test(value, { parent }) {
      const methodsRequiringValue = ['Base Salary / Fixed Days', 'Base Salary * 12 / Fixed Days']
      if (methodsRequiringValue.includes(parent.salaryProrationMethod)) {
        if (!value) {
          return false
        }
        // Check for no whitespace
        if (/\s/.test(value)) {
          return this.createError({ message: 'White Space is not allowed' })
        }
        // Check for valid number with up to 3 decimal points
        if (!/^\d+(\.\d{1,3})?$/.test(value)) {
          return this.createError({ message: 'Enter a valid number with up to 3 decimal points' })
        }
        const numericValue = parseFloat(value)
        if (numericValue < 1.000 || numericValue > 366.000) {
          return this.createError({ message: 'Value must be between 1.000 and 366.000' })
        }
      }
      return true
    },
  }),
  spM_ActualDaysMethod: yup.string().test({
    name: 'actualDaysMethodValidation',
    exclusive: true,
    message: 'Actual Days Method must be selected.',
    test(value, { parent }) {
      const methodsRequiringValue = ['Base Salary / Fixed Days', 'Base Salary * 12 / Fixed Days']
      if (methodsRequiringValue.includes(parent.salaryProrationMethod)) {
        return !!value
      }
      return true
    },
  }),
  cawCalculationMethod: yup
    .string()
    .required('CAW Method must be selected.'),
  // new field cawCalculationMethodDivided
  caW_DivideByFixedDays: Yup.string().test({
    name: 'cawConditionalValidation',
    exclusive: true,
    message: 'CAW Calculation Method - Divide by Fixed Days is required',
    test(value, { parent }) {
      const methodsRequiringValue = ['Base Salary / Fixed Days', 'Base Salary * 12 / Fixed Days']

      // Check if the selected calculation method requires a value for caW_DivideByFixedDays
      if (methodsRequiringValue.includes(parent.cawCalculationMethod)) {
        if (!value) {
          return false // Field is required if the calculation method requires it and no value is provided
        }

        // Additional validation for the value
        if (/\s/.test(value)) {
          return this.createError({ message: 'White Space is not allowed' })
        }
        if (!/^\d+(\.\d{1,3})?$/.test(value)) {
          return this.createError({ message: 'Enter a valid number with up to 3 decimal points' })
        }
        const numericValue = parseFloat(value)
        if (numericValue < 1.000 || numericValue > 366.000) {
          return this.createError({ message: 'Value must be between 1.000 and 366.000' })
        }
      }

      return true // Validation passes if no error is returned
    },
  }),

  remarks: yup.string().max(500, 'all_fields_remarks'),

  sunday: yup
    .string()
    .required('Sunday must be selected.'),
  monday: yup
    .string()
    .required('Monday must be selected.'),
  tuesday: yup
    .string()
    .required('Tuesday must be selected.'),
  wednesday: yup
    .string()
    .required('Wednesday must be selected.'),
  thursday: yup
    .string()
    .required('Thursday must be selected.'),
  friday: yup
    .string()
    .required('Friday must be selected.'),
  saturday: yup
    .string()
    .required('Saturday must be selected.'),

  hoursPerFullWorkDay: yup
    .string()
    .required('Number of hours for one full working day must be filled.')
    .matches(/^\d+(\.\d{1,2})?$/, 'Number of hours must be numeric with up to 2 decimal points.')
    .min(0.01, 'Number of hours must be more than Zero.')
    .max(24.00, 'Number of hours must be maximum up to 24.00.')
    .test('no-blank-space', 'Number of hours must not contain blank space.', (value) => !/\s/.test(value)),

})
export const validationSchemaEmployeeMovementConfiguration = yup.object().shape({

  movementType: yup
    .string()
    .required('Movement Type must be selected.'),
  fieldName: yup
    .string()
    .required(' Field Name must be selected.'),
  mandatory: yup
    .string()
    .required('Mandatory must be selected.'),

  displaySequence: yup
    .number()
    .required('Display Sequence must be filled')
    .positive('Display Sequence must be greater than 0')
    .integer('Display Sequence must be a whole number'),
})

// employee movement
export const validationSchemaEmployeeMovement = yup.object().shape({
  employeeMovementType: yup.object().test({
    name: 'employeeMovementType',
    exclusive: true,
    message: 'Movement Type must be selected.',
    test(value:any, { parent }) {
      const condition = !!value?.label
      if (!condition) {
        return false
      }
      return true
    },
  }),
  rehireUsingSameEmployeeCode: yup.object().test({
    name: 'employeeMovementType',
    exclusive: true,
    message: 'Re Hire Using Same Employee Code must be selected.',
    test(value:any, { parent }) {
      const condition = parent?.employeeMovementType?.label === 'Rehire From Same Entity'
      const valueCondition = !!value

      if (condition && !valueCondition) {
        return false
      }
      return true
    },
  }),
  effectiveDate: yup.string().test({
    name: 'employeeMovementType',
    exclusive: true,
    message: 'Effective Date must be filled.',
    test(value:any, { parent }) {
      const condition = parent?.employeeMovementType?.label !== 'Termination'
      const valueCondition = !!value

      if (condition && !valueCondition) {
        return false
      }
      return true
    },
  }),

  sequence: yup
    .number()
    .test({
      name: 'employeeMovementType',
      exclusive: true,
      message: 'Sequence must be filled.',
      test(value:any, { parent }) {
        const condition = parent?.employeeMovementType?.label !== 'Rehire From Same Entity'
        const valueCondition = !!value

        if (condition && !valueCondition) {
          return false
        }
        return true
      },
    })
    .positive('Sequence must be greater than 0')
    .integer('Sequence must be a whole number'),
  reason: yup
    .string()
    .max(200, 'Reason must not be longer than 200 characters'),

})
export const validationSchemaEmployeeMovement2 = yup.object().shape({
  lastEmploymentDate: yup.string().test({
    name: 'lastEmploymentDate',
    exclusive: true,
    message: 'Last Employment Date must be filled.',
    test(value:any, { parent }) {
      const condition = parent?.employeeMovementType?.label === 'Termination'
      const valueCondition = !!value

      if (condition && !valueCondition) {
        return false
      }
      return true
    },
  }),
  irdCorporateTitle: yup.object().test({
    name: 'irdCorporateTitle',
    exclusive: true,
    message: 'IRD Corporate Title must be selected.',
    test(value:any, { parent }) {
      const condition = parent?.employeeMovementType?.label === 'Change of Assignment' || parent?.employeeMovementType?.label === 'Rehire From Same Entity'
      const valueCondition = !!value

      if (condition && !valueCondition) {
        return false
      }
      return true
    },
  }),
  workCalendar: yup.object().test({
    name: 'workCalendar',
    exclusive: true,
    message: 'Work Calendar must be selected.',
    test(value:any, { parent }) {
      const condition = parent?.employeeMovementType?.label === 'Change of Remuneration' || parent?.employeeMovementType?.label === 'Rehire From Same Entity'
      const valueCondition = !!value?.label
      if (condition && !valueCondition) {
        return false
      }
      return true
    },
  }),
  caw: yup.object().test({
    name: 'caw',
    exclusive: true,
    message: 'CAW calculation method - One-day wage based on must be selected.',
    test(value:any, { parent }) {
      const condition = parent?.employeeMovementType?.label === 'Change of Remuneration' || parent?.employeeMovementType?.label === 'Rehire From Same Entity'
      const valueCondition = !!value?.label
      if (condition && !valueCondition) {
        return false
      }
      return true
    },
  }),
  commencementDate: yup.string().test({
    name: 'employeeMovementType',
    exclusive: true,
    message: 'Commencement Date must be selected.',
    test(value:any, { parent }) {
      const condition = parent?.employeeMovementType?.label === 'Rehire From Same Entity'
      const valueCondition = !!value
      if (condition && !valueCondition) {
        return false
      }
      return true
    },
  }),
  fourOneEightDate: yup.string().test({
    name: 'employeeMovementType',
    exclusive: true,
    message: '418 start date must be selected.',
    test(value:any, { parent }) {
      const condition = parent?.employeeMovementType?.label === 'Rehire From Same Entity'
      const valueCondition = !!value
      if (condition && !valueCondition) {
        return false
      }
      return true
    },
  }),
  EmployeeCode: yup.string().test({
    name: 'employeeMovementType',
    exclusive: true,
    message: 'Employee Code must be filled.',
    test(value:any, { parent }) {
      const condition = parent?.employeeMovementType?.label === 'Rehire From Same Entity'
      const valueCondition = !!value
      const rehireUsingSameEmployeeCode = parent?.rehireUsingSameEmployeeCode?.label === 'No'
      if (condition && !valueCondition && rehireUsingSameEmployeeCode) {
        return false
      }
      return true
    },
  }),
})
export const validationSchemaEmployeeMovement3 = yup.object().shape({
  employeeMovementType: yup.object().test({
    name: 'employeeMovementType',
    exclusive: true,
    message: 'Movement Type must be selected.',
    test(value:any, { parent }) {
      const condition = !!value?.label
      if (!condition) {
        return false
      }
      return true
    },
  }),
  rehireUsingSameEmployeeCode: yup.object().test({
    name: 'employeeMovementType',
    exclusive: true,
    message: 'Re Hire Using Same Employee Code must be selected.',
    test(value:any, { parent }) {
      const condition = parent?.employeeMovementType?.label === 'Rehire From Same Entity'
      const valueCondition = !!value

      if (condition && !valueCondition) {
        return false
      }
      return true
    },
  }),
  effectiveDate: yup.string().test({
    name: 'employeeMovementType',
    exclusive: true,
    message: 'Effective Date must be filled.',
    test(value:any, { parent }) {
      const condition = parent?.employeeMovementType?.label !== 'Termination'
      const valueCondition = !!value
      console.log(value, condition, '%%%%%%%%%%%%%%%%%%%%%', !valueCondition)

      if (condition && !valueCondition) {
        return false
      }
      return true
    },
  }),

  sequence: yup
    .number()
    .test({
      name: 'employeeMovementType',
      exclusive: true,
      message: 'Display Sequence must be filled.',
      test(value:any, { parent }) {
        const condition = parent?.employeeMovementType?.label !== 'Rehire From Same Entity'
        const valueCondition = !!value

        if (condition && !valueCondition) {
          return false
        }
        return true
      },
    })
    .positive('Display Sequence must be greater than 0')
    .integer('Display Sequence must be a whole number'),
  reason: yup
    .string()
    .max(200, 'Reason must not be longer than 20 characters'),
  lastEmploymentDate: yup.string().test({
    name: 'employeeMovementType',
    exclusive: true,
    message: 'Effective Date must be filled.',
    test(value:any, { parent }) {
      const condition = parent?.employeeMovementType?.label === 'Termination'
      const valueCondition = !!value

      if (condition && !valueCondition) {
        return false
      }
      return true
    },
  }),
  irdCorporateTitle: yup.object().test({
    name: 'employeeMovementType',
    exclusive: true,
    message: 'Ird Corporate Title must be selected.',
    test(value:any, { parent }) {
      const condition = parent?.employeeMovementType?.label === 'Change of Assignment' || 'Rehire From Same Entity'
      const valueCondition = !!value
      console.log(value, condition, '%%%%%%%%%%%%%%%%%%%%%', !valueCondition)

      if (condition && !valueCondition) {
        return false
      }
      return true
    },
  }),
  workCalendar: yup.object().test({
    name: 'workCalendar',
    exclusive: true,
    message: 'Work Calendar must be selected.',
    test(value:any, { parent }) {
      const condition = parent?.employeeMovementType?.label === 'Change of Remuneration' || 'Rehire From Same Entity'
      const valueCondition = !!value?.label
      console.log(condition === undefined || 'undefined', 'TTTTTTT', condition, value)
      if (condition && !valueCondition) {
        return false
      }
      return true
    },
  }),
  caw: yup.object().test({
    name: 'caw',
    exclusive: true,
    message: 'caw must be selected.',
    test(value:any, { parent }) {
      const condition = parent?.employeeMovementType?.label === 'Change of Remuneration' || 'Rehire From Same Entity'
      const valueCondition = !!value?.label
      console.log(condition === undefined || 'undefined', 'TTTTTTT', condition, value)
      if (condition && !valueCondition) {
        return false
      }
      return true
    },
  }),
  commencementDate: yup.string().test({
    name: 'employeeMovementType',
    exclusive: true,
    message: 'Commencement Date must be selected.',
    test(value:any, { parent }) {
      const condition = parent?.employeeMovementType?.label === 'Rehire From Same Entity'
      const valueCondition = !!value?.label
      console.log(condition === undefined || 'undefined', 'TTTTTTT', condition, value)
      if (condition && valueCondition) {
        return false
      }
      return true
    },
  }),
  fourOneEightDate: yup.string().test({
    name: 'employeeMovementType',
    exclusive: true,
    message: 'Four One Eight Date must be selected.',
    test(value:any, { parent }) {
      const condition = parent?.employeeMovementType?.label === 'Rehire From Same Entity'
      const valueCondition = !!value?.label
      console.log(condition === undefined || 'undefined', 'TTTTTTT', condition, value)
      if (condition && valueCondition) {
        return false
      }
      return true
    },
  }),

})
export const validationSchemaCompanyBankAcc = yup.object().shape({
  companyBankAccountCode: yup
    .string()
    .required('Company Bank Account Code must be filled')
    .max(30, 'Company Bank Account Code must not be longer than 30 characters')
    .matches(/^\S*$/, 'Company Bank Account Code must not contain blank space'),
  companyBankAccountDescription: yup
    .string()
    .required('Company Bank Account name must be filled')
    .max(120, 'Company Bank Account name must not be longer than 120 characters'),
  status: yup
    .string()
    .required('Status must be selected.'),
  bankCode: yup
    .string()
    .matches(/^[0-9]+$/, 'Bank Code only allow numeric value')
    .matches(/^\S*$/, 'Bank Code must not contain blank space')
    .max(15, 'Bank Code must not be longer than 15 characters')
    .required('Bank Code must be filled'),
  branchCode: yup
    .string()
    .matches(/^[0-9]+$/, 'Branch Code only allow numeric value')
    .matches(/^\S*$/, 'Branch Code must not contain blank space')
    .required('Branch Code must be filled')
    .max(15, 'Branch Code must not be longer than 15 characters'),
  accountNumber: yup
    .string()
    .matches(/^[0-9]+$/, 'Account Number only allow numeric value')
    .matches(/^\S*$/, 'Account Number must not contain blank space')
    .required('Account Number must be filled')
    .max(35, 'Account Number must not be longer than 35 characters'),
  valueDate: yup
    .date()
    .nullable()
    .notRequired()
    .min(todayDate, 'Value Date must be set on or after today.')
    .typeError('Value Date must be a valid date'),
  swiftCode: yup
    .string()
    .nullable()
    .notRequired()
    .test('no-whitespace', 'White space is not allowed in Swift Code.', (value:any) => {
      if (!value) return true // If the field is empty, it is valid
      return /^\S*$/.test(value) // Otherwise, check for white space
    })
    .matches(/^[A-Z0-9]*$/, 'Swift Code must contain only uppercase alphanumeric characters.') // Updated regex to allow empty string
    .max(11, 'Swift Code must not be longer than 11 characters.'),
  currency: yup
    .string()
    .required('Currency must be selected.'),
  bankReference: yup
    .string()
    .nullable()
    .max(70, 'Reference must not be longer than 70 characters'),
  hsbcmriPaymentCode: yup
    .string()
    .nullable()
    .max(3, 'HSBC MRI Payment must not be longer than 3 characters'),
  hsbcifilehsbcNetCustomerID: yup
    .string()
    .nullable()
    .max(18, 'HSBC IFILE HSBCnet Customer ID must not be longer than 18 characters'),
  hsbcifileFileReference: yup
    .string()
    .nullable()
    .max(35, 'HSBC IFILE File Reference must not be longer than 35 characters'),
  hsbcifilePaymentCode: yup
    .string()
    .nullable()
    .max(30, 'HSBC IFILE Payment Code must not be longer than 18 characters'),
  hsbcifilehsbcConnectCustomerId: yup
    .string()
    .nullable()
    .max(11, 'HSBC IFILE HSBC Connect Customer ID must not be longer than 11 characters.'),
  hsbcmriPlanCode: yup
    .string()
    .nullable()
    .max(1, 'HSBC MRI Plan Code must be filled if HSBC MRI is selected as bank file format.'),
  // hsbcbiaSuffix: yup
  //   .string()
  //   .nullable('')
  //   .notRequired()
  //   .matches(/^[0-9]+$/, 'HSBC BIA Suffix only allow numeric value')
  //   .matches(/^\S*$/, 'HSBC BIA Suffix must not contain blank space')
  //   .max(3, 'HSBC BIA Suffix must not be longer than 3 characters'),
  // // .required('HSBC BIA Suffix must be filled'),
  // hsbcbiaAccountType: yup
  //   .string()
  //   .nullable()
  //   .matches(/^\S*$/, 'HSBC BIA Account Type must not contain blank space')
  //   .max(2, 'HSBC BIA Account Type must not be longer than 2 characters'),
  hsbcBusinessIntegratedAccount: yup.boolean(),
  hsbcbiaSuffix: yup
    .string()
    .nullable()
    .when(['hsbcBusinessIntegratedAccount', 'bankFileFormat'], {
      is: (hsbcBusinessIntegratedAccount:any, bankFileFormat:any) => hsbcBusinessIntegratedAccount === true && !scbFormats.includes(bankFileFormat),
      then: (schema) => schema
        .required('HSBC BIA Suffix must be filled if HSBC Business Integrated Account is selected.')
        .matches(/^[0-9]+$/, 'HSBC BIA Suffix only allows numeric value')
        .matches(/^\S*$/, 'HSBC BIA Suffix must not contain blank space')
        .max(3, 'HSBC BIA Suffix must not be longer than 3 characters'),
      otherwise: (schema) => schema
        .matches(/^\S*$/, 'HSBC BIA Suffix must not contain blank space')
        .max(3, 'HSBC BIA Suffix must not be longer than 3 characters')
        .nullable(),
    }),

  hsbcbiaAccountType: yup
    .string()
    .nullable()
    .when(['hsbcBusinessIntegratedAccount', 'bankFileFormat'], {
      is: (hsbcBusinessIntegratedAccount:any, bankFileFormat:any) => hsbcBusinessIntegratedAccount === true && !scbFormats.includes(bankFileFormat),
      then: (schema) => schema
        .required('HSBC BIA Account Type must be filled if HSBC Business Integrated Account is selected.')
        .matches(/^\S*$/, 'HSBC BIA Account Type must not contain blank space')
        .max(2, 'HSBC BIA Account Type must not be longer than 2 characters'),
      otherwise: (schema) => schema
        .matches(/^\S*$/, 'HSBC BIA Account Type must not contain blank space')
        .max(2, 'HSBC BIA Account Type must not be longer than 2 characters')
        .nullable(),
    }),
  // .required('HSBC BIA Account Type must be filled'),
})
// payroll non recurring schema
export const validationSchemaPayrollNonRecurring = yup.object().shape({
  // payCycle: yup
  //   .string()
  //   .test('is-valid-year', 'Pay Cyle Year must be 4 digits in the format "YYYY', (value) => {
  //     if (!value) return false // Required validation will handle empty values
  //     const yearRegex = /^\d{4}$/ // Regex to match 4 digits
  //     return yearRegex.test(value) && !/\s/.test(value) // Check for format and absence of spaces
  //   })
  //   .test('is-not-blank-space', 'Pay Cyle Year must not contain blank space', (value:any) => !/\s/.test(value))
  //   .required('Pay Cycle Year must be Filled.'),
  employeeCode: yup
    .string()
    .required('Employee Code must be selected.'),
  // // payitemCode
  payItemCode: yup
    .string()
    .required('Pay Item must be selected.'),
  // // Quantity
  quantity: yup
    .string()
    .test('check-required', 'Quality must be filled', function (value) {
      const unitBaseSelection = this.parent.payItemMasterUnitBaseSelection
      return unitBaseSelection !== 'Not Available' ? !!value : true
    })
    .test('check-max-length', 'Quality must be maximum up to 13 integral part with 2 decimal points', (value) => {
      if (!value) return true // Required validation will handle empty values
      const numericRegex = /^-?\d{1,13}(?:\.\d{1,2})?$/ // Regex to match the format
      return numericRegex.test(value)
    })
    .test('check-no-space', 'Quality must not contain blank space', (value) => {
      if (!value) return true // Required validation will handle empty values
      return !/\s/.test(value)
    })
    .test('check-numeric-only', 'Quantity must only include numeric values and a dot for decimal points', (value) => {
      if (!value) return true // Required validation will handle empty values
      const numericRegex = /^[\d.]+$/ // Regex to match numeric values and dot
      return numericRegex.test(value)
    })
    .transform((value, originalValue) => value.trim()) // Trim whitespace from the input
    .typeError('Invalid quantity format') // Error message for invalid numeric format
    .required('Quantity must be filled') // Error message for required field
    .min(0, 'Quantity must be greater than or equal to 0'), // Minimum value validation
  // // originalCurrency
  // originalCurrency: yup
  //   .string()
  //   .required('Original Currency must be selected.'),
  // // paymentCurrency
  // paymentCurrency: yup
  //   .string()
  //   .required('Payment Currency must be selected.'),
  // // ratePerUnit
  // ratePerUnit: yup
  //   .string()
  //   .nullable() // Field is optional
  //   .test('check-max-length', 'Rate Per Unit must be maximum up to 13 integral part with 10 decimal points', (value) => {
  //     if (!value) return true // Optional field
  //     const numericRegex = /^\d{1,13}(?:\.\d{1,10})?$/ // Regex to match the format
  //     return numericRegex.test(value)
  //   })
  //   .test('check-no-space', 'Rate Per Unit must not contain blank space', (value) => {
  //     if (!value) return true // Optional field
  //     return !/\s/.test(value)
  //   })
  //   .test('check-positive-value', 'Rate Per Unit must be a positive value', (value) => {
  //     if (!value) return true // Optional field
  //     const numericValue = parseFloat(value)
  //     return numericValue >= 0 // Check if the value is non-negative
  //   })
  //   .transform((value, originalValue) => {
  //     if (!value) return null // Convert empty string to null
  //     return value.trim() // Trim whitespace from the input
  //   })
  //   .typeError('Invalid rate per unit format'), // Error message for invalid format
  // // transactionAmount
  // transactionAmount: yup
  //   .string()
  //   .nullable() // Field is optional
  //   .test('check-max-length', 'Transaction Amount must be maximum up to 20 integral part with 2 decimal points', (value) => {
  //     if (!value) return true // Optional field
  //     const numericRegex = /^-?\d{1,20}(?:\.\d{1,2})?$/ // Regex to match the format
  //     return numericRegex.test(value)
  //   })
  //   .test('check-no-space', 'Transaction Amount must not contain blank space', (value) => {
  //     if (!value) return true // Optional field
  //     return !/\s/.test(value)
  //   })
  //   .transform((value, originalValue) => {
  //     if (!value) return null // Convert empty string to null
  //     return value.trim() // Trim whitespace from the input
  //   })
  //   .typeError('Invalid transaction amount format'), // Error message for invalid format
  // // exchangeRate
  // exchangeRate: yup
  //   .string()
  //   .nullable() // Field is optional
  //   .test('check-max-length', 'Agreed Exchange Rate must be maximum up to 9 integral part with 6 decimal points', (value) => {
  //     if (!value) return true // Optional field
  //     const numericRegex = /^-?\d{1,9}(?:\.\d{1,6})?$/ // Regex to match the format
  //     return numericRegex.test(value)
  //   })
  //   .test('check-no-space', 'Agreed Exchange Rate must not contain blank space', (value) => {
  //     if (!value) return true // Optional field
  //     return !/\s/.test(value)
  //   })
  //   .transform((value, originalValue) => {
  //     if (!value) return null // Convert empty string to null
  //     return value.trim() // Trim whitespace from the input
  //   })
  //   .typeError('Invalid agreed exchange rate format'), // Error message for invalid format
  // // coveringStartDate
  // coveringStartDate: yup
  //   .date()
  //   .nullable() // Field is optional
  //   // .when('coveringEndDate', (coveringEndDate: Date | null | undefined, schema: any) => (coveringEndDate ? schema.required('Covering Start Date is required if Covering End Date is provided') : schema))
  //   .test({
  //     name: 'date-comparison',
  //     message: 'Covering Start Date must not be later than Covering End Date',
  //     test(coveringStartDate: Date | null | undefined) {
  //       const coveringEndDate = this.resolve(yup.ref('coveringEndDate'))
  //       if (!coveringEndDate || !coveringStartDate) {
  //         return true // Validation will be handled by the 'required' check or other validations
  //       }
  //       return new Date(coveringStartDate) <= new Date()
  //     },
  //   }),

  // coveringEndDate: yup
  //   .date()
  //   .nullable() // Field is optional
  //   // .when('coveringStartDate', (coveringStartDate: Date | null | undefined, schema: any) => (coveringStartDate ? schema.required('Covering End Date is required if Covering Start Date is provided') : schema))
  //   .test({
  //     name: 'date-comparison',
  //     message: 'Covering End Date must not be earlier than Covering Start Date',
  //     test(coveringEndDate: Date | null | undefined) {
  //       const coveringStartDate = this.resolve(yup.ref('coveringStartDate'))
  //       if (!coveringStartDate || !coveringEndDate) {
  //         return true // Validation will be handled by the 'required' check or other validations
  //       }
  //       return new Date(coveringEndDate) >= new Date()
  //     },
  //   }),
  // // reportingPeriodYear
  // reportingPeriodYear: yup
  //   .string()
  //   .matches(/^\d{4}$/, 'Reporting Period Year must be 4 digits in the format "YYYY"')
  //   .test('no-blank-space', 'Reporting Period Year must not contain blank space', (value) => {
  //     if (!value) return true // Required validation will handle empty values
  //     return !/\s/.test(value) // Check for absence of spaces
  //   })
  //   .required('Reporting Period Year must be filled.'),
  // // reportingperiodMonth
  // reportingPeriodMonth: yup
  //   .string()
  //   .required('Reporting Period Month must be selected.'),
  // remarks: yup
  //   .string()
  //   .max(120, 'Remarks must not be longer than 120 characters.'),
})
export const validationSchemaPensionfundscheme = (isServiceProviderSuccess:any) => yup.object().shape({
  // DateFrom: yup
  //   .string()
  //   .required('Scheme Code must be filled'),
  // DateTo: yup
  //   .string()
  //   .required('Scheme Code must be filled'),
  pensionFundSchemeCode: yup
    .string()
    .required('Pension fund scheme ID must be filled')
    .max(30, 'Scheme Code must not be longer than 30 characters'),
  // .matches(/^\S*$/, 'Company Bank Account Code must not contain blank space'),
  schemeDescription: yup
    .string()
    .required('Pension fund scheme name must be filled')
    .max(500, 'Scheme Description must not be longer than 500 characters'),
  serviceProviderCode: yup
    .string()
    .required('Service provider must be selected'),
  schemeType: yup
    .string()
    .required('Scheme Type must be selected.'),
  status: yup
    .string()
    .required('Status must be selected.'),
  remarks: yup.string().max(500, 'all_fields_remarks'),
  schemeFileNumber: yup
    .string()
    .required('Scheme file number must be filled')
    .max(20, 'Scheme File Number must not be longer than 20 characters'),
  subSchemeFileNumber: yup
    .string()
    .max(20, 'Sub Scheme File Number must not be longer than 20 characters'),
  supplementaryScheme: yup
    .string()
    .required('Supplementary Scheme must be selected.'),
  schemeCurrency: yup
    .string()
    .required('Scheme Currency must be selected.'),
  contributionCycle: yup
    .string()
    .required('Contribution Cycle must be selected.'),
  participationNumber: yup
    .string()
    .max(20, 'Participation Number must not be longer than 20 characters'),
  // referenceNumber: yup
  //   .string()
  //   .max(20, 'Reference Number must not be longer than 20 characters'),
  memberClass: yup
    .string()
    .max(20, 'Member Class must not be longer than 20 characters'),

  surchargePercentage: yup
    .number()
    .nullable()
    .min(0, 'Surcharge Percentage must be greater than 0'),
  employeeSurchargeAmount: yup
    .number()
    .nullable()
    .min(0, 'Employee Surcharge Amount must be greater than 0'),
  employerSurchargeAmount: yup
    .number()
    .nullable()
    .min(0, 'Employer Surcharge Amount must be greater than 0'),

  // payCentre: yup
  //   .string()
  //   .max(4, 'pay centre must not be longer than 4 characters'),

  // paymentMethod: yup
  //   .string()
  //   .test(
  //     'isRequired',
  //     'Payment Method must be filled if the Remittance file format is HSBC.',
  //     (value) => (isServiceProviderSuccess ? !!value : true),
  //   ),
  payCentre: Yup.string().test({
    name: 'conditionalValidation',
    exclusive: true,
    message: 'pay centre must be filled if the Remittance file format is HSBC and must not be longer than 4 characters.',
    test(value, context) {
      const { serviceProviderCode } = context.parent
      if (serviceProviderCode === 'HSBC') {
        if (!value) {
          return this.createError({ message: 'pay centre must be filled if the Remittance file format is "HSBC".' })
        }
        if (value.length > 4) {
          return this.createError({ message: 'pay centre must not be longer than 4 characters.' })
        }
      }
      return true
    },
  }),

  paymentMethod: Yup.string().test({
    name: 'conditionalValidation',
    exclusive: true,
    message: 'Payment Method must be filled if the Remittance file format is HSBC.',
    test(value, context) {
      const { serviceProviderCode, remittanceFileFormat } = context.parent
      if (serviceProviderCode === 'HSBC') {
        return !!value || this.createError({
          message: 'Payment Method must be filled if the Remittance file format is "HSBC".',
        })
      }
      return true
    },
  }),

  formNumber: Yup.string().test({
    name: 'conditionalValidation',
    exclusive: true,
    message: 'Form Number must be filled if the Remittance File Format is "HSBC".',
    test(value, context) {
      const { serviceProviderCode, remittanceFileFormat } = context.parent
      if (serviceProviderCode === 'HSBC') {
        return !!value || this.createError({
          message: 'Form Number must be filled if the Remittance File Format is "HSBC".',
        })
      }
      return true
    },
  }),

  // formNumber: yup
  //   .string()
  //   .test(
  //     'isRequired',
  //     'Form Number must be filled if the Remittance file format is HSBC.',
  //     (value) => (isServiceProviderSuccess ? !!value : true),
  //   )
  //   .required('Form Number must be filled'),

})

export const validationSchemaPensionfundscheme1 = yup.object().shape({
  schemeRuleType: yup
    .string()
    .required('Scheme Rule Type must be selected.'),
  roundingType: yup
    .string()
    .required('Rounding Type must be selected.'),

  decimalPoint: yup
    .number()
    .nullable()
    .min(0, 'Decimal Point must between 0 to 6.')
    .max(6, 'Decimal Point must between 0 to 6.')
    .required('Decimal Point must be filled'),
  schemeJoinDateOption: yup
    .string()
    .required('Scheme Join Date Option must be selected.'),
  employeeContributionPayItemCode: yup
    .string()
    .required('Employee contribution pay item must be selected.'),
  employeeCalculationStartDateOption: yup
    .string()
    .required('Employee Calculation Start Date Option must be selected.'),
  employeeCalculationStartDateDays: yup
    .number()
    .nullable()
    .min(0, 'No. of Days After Employment for Employee Calculation Start Date must be greater than or equal to 0')
    // .max(yup.ref('employeeContributionStartDateDays'), 'This value must be less than or equal to the No. of Days After Employment for Employee Contribution Start Date.')
    .required('No. of Days After Employment for Employee Calculation Start Date must be selected.'),
  employeeContributionStartDateDays: yup
    .number()
    .nullable()
    .min(0, 'No. of Days After Employment for Employee Contribution Start Date must be greater than or equal to 0')
    .min(yup.ref('employeeCalculationStartDateDays'), 'This value must be greater than or equal to the No. of Days After Employment for Employee Calculation Start Date.')
    .required('No. of Days After Employment for Employee Calculation Start Date must be selected.'),
  deductMPFMCForEmployeeContribution: yup
    .string()
    .required('Deduct MPF MC for Employee Contribution must be selected.'),
  employerContributionPayItemCode: yup
    .string()
    .required('Employer contribution pay item must be selected.'),
  employerCalculationStartDateOption: yup
    .string()
    .required('Employer Calculation Start Date Option must be selected.'),
  employerCalculationStartDateDays: yup
    .number()
    .nullable()
    .min(0, 'No. of Days After Employment for Employer Calculation Start Date must be greater than or equal to 0')
    // .max(yup.ref('employerContributionStartDateDays'), 'This value must be less than or equal to the No. of Days After Employment for Employee Contribution Start Date.')
    .required('No. of Days After Employment for Employer Calculation Start Date must be selected.'),
  employerContributionStartDateDays: yup
    .number()
    .nullable()
    .min(0, 'No. of Days After Employment for Employer Contribution Start Date must be greater than or equal to 0')
    .min(yup.ref('employerCalculationStartDateDays'), 'This value must be greater than or equal to the No. of Days After Employment for Employer Calculation Start Date.')
    .required('No. of Days After Employment for Employer Contribution Start Date must be selected.'),
  deductMPFMCForEmployerContribution: yup
    .string()
    .required('Deduct MPF MC for Employer Contribution must be selected.'),
  addContributionPeriodToPaymentDescription: yup
    .string()
    .required('Add Contribution Period to the Payment Description must be selected.'),
  showRelevantIncomeAmount: yup
    .number()
    .nullable()
    .min(0, 'Show Relevant Income Amount if Over this Cap must be greater than 0'),
  remittanceStatementRemarks: yup
    .string().max(4000, 'Remittance Statement Remarks must not be longer than 4000 characters'),
  // descriptionInPensionFundSection: yup
  //   .string()
  //   .required('Description in Pension Fund Section must be filled')
  //   .max(120, 'Description in Pension Fund Section must not be longer than 120 characters'),
  // showContributionInPensionFundSection: yup
  //   .string()
  //   .required('Show Contribution in Pension Fund Section must be selected.'),
  // showRelevantIncomeInPensionFundSection: yup
  //   .string()
  //   .required('Show Relevant Income in Pension Fund Section must be selected.'),
})

export const validationSchemaPensionfundscheme2 = yup.object().shape({
  descriptionInPensionFundSection: yup
    .string()
    .required('Description In PensionFund must be filled.'),

})

const today = new Date()
export const validationSchemaEntityProfile = yup.object().shape({
  entityName: yup
    .string()
    .trim()
    .required('Entity Name must be filled')
    .max(120, 'Entity Name must not be longer than 120 characters'),

  entityLocalName: yup
    .string()
    .trim()
    .max(120, 'Entity Local Name must not be longer than 120 characters'),

  baseCurrency: yup
    .string()
    .required('Base Currency must be selected.'),

  registeredAddressCountry: yup
    .string()
    .required('Country selection must be selected.'),

  goLivePayrollMonthYear: yup
    .string()
    .nullable()
    .test('is-empty-or-valid', 'The year of Go Live Payroll Month must be 4 digits in the format "YYYY".', (value) => {
      if (!value) return true // No error if value is empty
      return /^[0-9]*$/.test(value) && value.length === 4 // Check if it's a number and has 4 digits
    })
    .matches(/^\S*$/, 'The year of Go Live Payroll Month must not contain blank space.'),

  goLivePayrollMonth: yup
    .string()
    // .nullable()
    .required('Go Live Payroll Month must be selected.'),

  currentPayrollMonthYear: yup
    .string()
    .nullable()
    .test('is-empty-or-valid', 'The year of Current Payroll  Month must be 4 digits in the format "YYYY".', (value) => {
      if (!value) return true // No error if value is empty
      return /^[0-9]*$/.test(value) && value.length === 4 // Check if it's a number and has 4 digits
    })
    .matches(/^\S*$/, 'The year of  Current Payroll Month must not contain blank space.'),

  currentPayrollMonth: yup
    .string()
    // .nullable()
    .required('Go Live Payroll Month must be selected.'),

  startDateForAuditLogging: Yup.date().test({
    name: 'startDateForAuditLoggingValidation',
    exclusive: true,
    message: ' Start Date for Audit Logging should not be earlier than today.',
    test(value, context) {
      const { goLivePayrollMonth } = context.parent
      if (goLivePayrollMonth) {
        return value && value >= today
      }
      return true
    },
  }),

  companyRegistrationNo: yup
    .string()
    .max(60, 'Company Registration No. must not be longer than 60 characters.'),
  contactPerson: yup
    .string()
    .max(120, 'Contact Person must not be longer than 120 characters.'),

  phoneNumber: yup
    .string()
    .max(120, 'Phone number must not be longer than 120 characters.')
    .test('is-empty-or-valid', 'Phone number must not contain symbols except "-", "(", ")", "+".', (value) => {
      if (!value) return true // No error if value is empty
      return /^[\d()+/-]*$/.test(value) // Check if it contains only valid symbols
    }),

  emailAddress: yup
    .string()
    .email('Invalid email address')
    .max(120, '  Email Address must not be longer than 120 characters.')
    .test('no-blank-space', ' Email Address must not contain blank space.', (value) => {
      if (!value) return true // No error if value is empty
      return /^\S*$/.test(value) // Check if it doesn't contain any whitespace
    }),
  registeredAddressLine1: yup
    .string()
    .max(120, 'Registered Address Line-1 must not be longer than 120 characters.'),
  registeredAddressLine2: yup
    .string()
    .max(120, 'Registered Address Line-2 must not be longer than 120 characters.'),
  registeredAddressLine3: yup
    .string()
    .max(120, 'Registered Address Line-3 must not be longer than 120 characters.'),
  remarks: yup.string().max(500, 'all_fields_remarks'),
})
// payroll administrator
// payroll administrator scheme
export const validationSchemaPayrollAdministratorScheme = yup.object().shape({
  payCycleYear: yup
    .string()
    .required('Pay Cycle Year must be selected.'),
  payCycleMonth: yup
    .string()
    .required('Pay Cycle Month must be selected.'),
  payCycleCode: yup
    .number()
    .typeError('')
    .required('Pay Cycle Code must be selected.'),
  payCycleName: yup
    .string()
    .required('Pay Cycle Name must be selected.'),
  payCycleStartDate: yup
    .date()
    .required('Pay Cycle Start Date must be selected.'),
  payCycleEndDate: yup
    .date()
    .required('Pay Cycle End Date must be selected.'),
  remarks: yup.string().max(500, 'all_fields_remarks').nullable(),
})
export const validationSchemaPaycyclegeneration = yup.object().shape({
  year: yup
    .string()
    .test('is-valid-year', 'The year of starting month must be 4 digits in the format "YYYY', (value) => {
      if (!value) return false // Required validation will handle empty values
      const yearRegex = /^\d{4}$/ // Regex to match 4 digits
      return yearRegex.test(value) && !/\s/.test(value) // Check for format and absence of spaces
    })
    .test('is-not-blank-space', 'The year of starting month must not contain blank space', (value:any) => !/\s/.test(value))
    .required('The year of starting month must be Filled.'),
})
// custom report designer schema
export const validationSchemaCustomReportDesigner = yup.object().shape({
  reportName: yup
    .string()
    .required('Report Name must be filled')
    .max(120, 'Report Name must not be longer than 120 characters'),
  reportDescription: yup
    .string()
    .required('Report Description must be filled')
    .max(500, 'Report Description must not be longer than 500 characters'),
  reportType: yup
    .string()
    .required('Report Type must be selected'),
  reportCategory: yup
    .string()
    .required('Report Category must be selected'),
  reportFormat: yup
    .string()
    .required('Report Format must be selected'),
  reportQuery: yup
    .string()
    .required('Report Query must be filled'),
  remarks: yup
    .string()
    .max(500, 'Remarks must not be longer than 500 characters'),
})
export const validationSchemaPensionFundTermination = yup.object().shape({

  countryLocalization: yup
    .string()
    .required('Country Localization must be selected'),

  serviceProviderCode: yup
    .string()
    .max(20, 'Service Provider Code must not be longer than 20 characters')
    .required('Service Provider Code must be filled'),

  terminationCode: yup
    .string()
    .max(10, ' Termination Code  must not be longer than 10 characters')
    .required(' Termination Code  must be filled'),

  terminationDescription: yup
    .string()
    .max(100, 'Termination Description must not be longer than 100 characters')
    .required('Termination Description must be filled'),

  terminationLocalDescription: yup
    .string()
    .max(100, 'Termination Local Description must not be longer than 100 characters'),

  status: yup
    .string()
    .required('stutus must be selected'),

})
export const validationSchemaRunPayroll = yup.object().shape({
  calculatePensionFund: yup
    .string()
    .required('Pay Cycle Name must be selected.'),
  exportProcessLogMessage: yup
    .string()
    .required('Pay Cycle Name must be selected.'),
})
export const validationSchemaEmail = yup.object().shape({
  sender: yup.string()
    .matches(/^[^\s@]+@[^\s@]+\.[^\s@]+$/, 'Sender\'s email address is not a valid address')
    .max(120, 'Sender\'s email address must not be longer than 120 characters')
    .required('Sender\'s email address must be filled'),
  emailProfileCode: yup.string()
    .matches(/^\S*$/, 'Email profile code not contain blank space')
    .max(20, 'Email profile code must not be longer than 20 characters')
    .required('Email profile code must be filled'),
  emailProfileName: yup.string()
    .max(120, 'Email profile name must not be longer than 120 characters')
    .required('Email profile name must be filled'),
})
export const validationSchemaEmail1 = yup.object().shape({
  recipients: yup.array()
    .of(
      yup.string()
        .matches(/^[^\s@]+@[^\s@]+\.[^\s@]+$/, "To Recipient's email address is not a valid address")
        .max(120, "To Recipient's email address must not be longer than 120 characters")
        .required("To Recipient's email address must be filled"),
    ),
  cc: yup.string()
    .matches(/^[^\s@]+@[^\s@]+\.[^\s@]+$/, 'Cc Recipient\'s email address is not a valid address')
    .max(120, 'Cc Recipient\'s email address must not be longer than 120 characters')
    .required('Cc Recipient\'s email address must be filled'),
  bcc: yup.string()
    .matches(/^[^\s@]+@[^\s@]+\.[^\s@]+$/, 'Bcc Recipient\'s email address is not a valid address')
    .max(120, 'Bcc Recipient\'s email address must not be longer than 120 characters')
    .required('Bcc Recipient\'s email address must be filled'),
})

// payslip validation
export const validationSchemaPayrollSlip = yup.object().shape({
  payCycleYear: yup.string()
    .matches(/^\d{4}$/, 'Year must be 4 digits in the format "YYYY".')
    .matches(/^\S*$/, 'Year must not contain blank space.')
    .required('Year must be filled.'),
  // payCycleMonth: yup.object().shape({
  //   id: yup.number().nullable('abc').required('Pay cycle must be selected.'),
  //   label: yup.string(),
  // }),
  // payCycleCode: yup.object().shape({
  //   id: yup.number().required('Pay cycle  must be selected.'),
  //   label: yup.string(),
  // }),

  payCycleMonth: yup.object().shape({
    // id: Yup.number()
    //   .nullable()
    //   .required('ID is required'),
    label: Yup.string()
      .nullable()
      .required('Label is required'),
  }).required('Month must be selected.').strict(true),
  // payCycleCode: Yup.object().shape({
  //   id: Yup.number()
  //     .nullable()
  //     .required('ID is required'),
  //   label: Yup.string()
  //     .nullable()
  //     .required('Label is required'),
  // }).required('Pay Cycle Code must be selected.').strict(true),

  payCycleCode: Yup.array()
    .of(Yup.string().required('Pay Cycle Code must be selected.')).required('Pay Cycle Code must be selected.'),

  excludeEmployees: yup.string()
    .required('Employee must be selected.'),

})

export const validationSchemaPayrollSlip1 = yup.object().shape({
  // Define your validation schema for step 1
})

export const validationSchemaPayrollSlip2 = yup.object().shape({
  exportOptions: Yup.string().required('Export file format must be selected.'),

  // userFilePassword: Yup.string().test({
  //   name: 'conditionalValidationUser',
  //   message: 'Password must contain at least one digit, one letter, one special character, and be at least 12 characters long.',
  //   test(value, context) {
  //     const { exportOptions } = context.parent
  //     if (exportOptions === '2') {
  //       // If exportOptions is '1', then userFilePassword is required and must match the regex
  //       return Yup.string()
  //         .required('Password is required.')
  //         .matches(
  //           /^(?=.*?[0-9])(?=.*?[a-zA-Z])(?=.*?[^a-zA-Z0-9]).{12,}$/,
  //           'Password must contain at least one digit, one letter, one special character, and be at least 12 characters long.',
  //         )
  //         .isValidSync(value) // Check if value satisfies the above conditions
  //     }
  //     // If exportOptions is not '1', no validation needed for userFilePassword
  //     return true
  //   },
  // }),

  zipPassword: Yup.string().test({
    name: 'conditionalValidationZip',
    message: 'Password must contain at least one digit, one letter, one special character, and be at least 12 characters long.',
    test(value, context) {
      const { exportOptions } = context.parent
      if (exportOptions === '3') {
        // If exportOptions is '2', then zipPassword is required and must match the regex
        return Yup.string()
          .isValidSync(value) // Check if value satisfies the above conditions
      }
      // If exportOptions is not '2', no validation needed for zipPassword
      return true
    },
  }),
})
const todayDateTime = new Date().toISOString().split('T')[0] // Ensures the format is 'YYYY-MM-DD'

export const validationSchemaPaymentSummary = yup.object().shape({

  payCycleYear: yup.string()
    .matches(/^\d{4}$/, 'Year must be 4 digits in the format "YYYY".')
    .matches(/^\S*$/, 'Year must not contain blank space.')
    .required('Year must be filled.'),

  // companyBankAccountCode: yup
  //   .string()
  //   .required('Company Bank Account must be selected'),
  companyBankAccountCode: Yup.string().required('Company bank account is required')
    .test('valueDate-check', 'The value date must be today or in the future.', (value) => {
      if (!value) return false // Ensure a value is selected

      const valueDate = new Date()
      const today = new Date()

      // If valueDate is today or in the future, return true to indicate validation passes
      if (valueDate >= today) {
        return true
      }

      // If valueDate is in the past, return false to indicate validation fails
      return false
    })
    .transform((value, originalValue) => {
    // If the validation condition is met (valueDate >= today), return the original value
    // This will clear the error message
      if (value && originalValue && new Date(originalValue) >= new Date()) {
        return originalValue
      }

      // Otherwise, return the current value to keep the error message
      return value
    }),

  payCycleMonth: Yup.object({
    label: Yup.string()
      .nullable()
      .required('Label is required'),
    value: Yup.string()
      .nullable()
      .required('Value is required'),
  }).required('Month must be selected.').strict(true),
  // payCycleCode: Yup.array()
  //   .of(Yup.string().required('Pay Cycle Code must be selected.')).required('Pay Cycle Code must be selected.'),
  payCycleCode: Yup.array()
    .min(1, 'Pay cycle code is required') // Display this message if no options are selected
    .required('Pay cycle code is required'), // Ensure the field is required
  excludeEmployees: yup.string()
    .required('Employee must be selected.'),

})

export const validationSchemaPaymentSummary1 = yup.object().shape({
  GenerateInterfaceFile: yup.string()
    .required('Generate interface file must be selected.'),
  exportFileFormat: Yup.array()
    .of(Yup.string().required('Export file format must be selected.')).required('Export file format must be selected.'),

})

export const payCycleCodevalidationSchemaFilterCriteria = yup.object().shape({
  year: yup.string().required('Year must be filled'),
  month: yup.string().required('Moth must be filled'),
  payCycleCode: Yup.array()
    .of(Yup.string().required('Pay Cycle Code must be selected.')).required('Pay Cycle Code must be selected.'),
})

export const validationSchemaFilterCriteriaAdditionalfilter = yup.object().shape({
  excludeEmployees: Yup.string().required('Pay Cycle Code must be selected.'),
})

export const validationSchemaFilterCriteriaReportOption = yup.object().shape({

  consolidateOption: Yup.array()
    .of(Yup.string().required('Consolidate Option must be selected')) // Specify the type of items and their validation
    .required('Consolidate Option must be selected'),
  showIRDCodeOption: yup.string().required('Show IRD Code Option must be selected'),
  includeEmployeeGroupOption: Yup.array()
    .of(Yup.string().required('Exclude Employees must be selected')) // Specify the type of items and their validation
    .required('Exclude Employees must be selected'),
  includePaymentHistoryOption: yup.string().required('Include Payment History Option must be selected'),
})
export const validationSchemaFilterCriteriaExportOption = yup.object().shape({
  paperSize: yup.string().required('Paper Size must be selected'),
  paperOrientation: yup.string().required('Paper Orientation must be selected'),
  exportFileFormat: yup.string().required('Export File Format must be selected'),
  // exportFileName: yup.string().required('Export File Name must be filled'),
  exportToSingleZipFile: yup.string().required('Export To Single Zip File must be selected'),
  // zipPassword: yup.string().required('Zip Password must be filled'),
  // zipFileName: yup.string().required('Zip FileName must be filled'),
  zipPassword: Yup.string().test('required', 'Zip Password must be filled.', function (value) {
    const { exportToSingleZipFile } = this.parent
    console.log(exportToSingleZipFile, 'exportToSingleZipFileexportToSingleZipFile')

    if (exportToSingleZipFile === 'true' && !value) {
      return false
    }
    return true
  }),
  zipFileName: Yup.string().test('required', 'Zip FileName must be filled.', function (value) {
    const { exportToSingleZipFile } = this.parent
    if (exportToSingleZipFile === 'true' && !value) {
      return false
    }
    return true
  }),
})

// export const validationSchemaPaymentSummary = yup.object().shape({

// })
export const validationSchemaPasswordEmpgeneration = yup.object().shape({

})

// validationschemaemailtemplate
export const validationSchemaEmailTemplate = yup.object().shape({
  emailTemplateCode: yup
    .string()
    .required('Template Code must be filled')
    .max(20, 'Template Code must not be longer than 20 characters')
    .matches(/^\S*$/, 'Template code must not contain blank space'),
  emailTemplateName: yup
    .string()
    .required('Template Name must be filled')
    .max(120, 'Template Name must not be longer than 120 characters'),
  // emailTemplateTypeId: Yup.object()
  //   .shape({
  //     id: Yup.string().required('Template Type must be selected.'),
  //     label: Yup.string().nullable().required('Label is required'),
  //   })
  //   .nullable()
  //   .required('Template Type must be selected.')
  //   .strict(true),
  emailSubject: yup
    .string()
    .required('Email Subject must be filled'),
  // emailContent: yup
  //   .string()
  //   .nullable()
  //   .required('Email Content must be filled'),

})

export const validationSchemaReviewReport = yup.object().shape({
  referenceNumber: yup
    .string()
    .required('Generation refernce must be selected'),

})

// validaiton schema for the send email
export const validationSchemaSendEmail = Yup.object().shape({
  emplFiltering: Yup
    .object()
    .shape({
      label: Yup.string()
        .nullable()
        .required('Label is required'),
    }).required('Must choose one selection').strict(true),
  // Apply validation for commencement date if emplFiltering.id === 1
  FromDate: Yup.date().nullable().test({
    test(value) {
      const { emplFiltering } = this.parent
      const toDate = this.parent.ToDate
      // Check if emplFiltering.id === 1 and FromDate is defined
      if (emplFiltering?.id === 1 && toDate && value) {
        // Validate FromDate if emplFiltering.id is 1, ToDate is defined, and FromDate is earlier or equal to ToDate
        return Yup.date().max(toDate, "Commencement Date's From Date must be set earlier or equal to To Date.").isValidSync(value)
      }
      return true // Skip validation if conditions are not met
    },
    message: "Commencement Date's From Date must be set earlier or equal to To Date.",
  }),

  ToDate: Yup.date().nullable().test({
    test(value) {
      const { emplFiltering } = this.parent
      const fromDate = this.parent.FromDate
      // Check if emplFiltering.id === 1, FromDate is defined, and ToDate is after or equal to FromDate
      if (emplFiltering?.id === 1 && fromDate && value) {
        // Validate ToDate only if emplFiltering.id is 1, FromDate is defined, and ToDate is after or equal to FromDate
        const isValidDate = Yup.date().min(fromDate, "Commencement Date's To Date must be set after or equal to From Date").isValidSync(value)
        const isDifferentDate = value !== fromDate
        return isValidDate && isDifferentDate // Check if ToDate is valid and different from FromDate
      }
      return true // Skip validation if conditions are not met
    },
    message: "Commencement Date's To Date must be set after or equal to From Date.",
  }),
})

export const validationSchemaSendEmail1 = Yup.object().shape({
  // fromDate: Yup.date().test('required', 'Commencement Date must be filled for "New Hire" and "Some Other Filter"', function (value) {
  //   const { emplFiltering } = this.parent
  //   if (emplFiltering?.id === 2) {
  //     return value !== undefined
  //   }
  //   return true
  // }),

  // toDate: Yup.date().test('validity', 'Commencement Date\'s To Date must be set after or equal to From Date.', function (value) {
  //   const { emplFiltering, fromDate } = this.parent
  //   if (emplFiltering?.id === 2) {
  //     if (!fromDate) return false
  //     return Yup.date().min(fromDate, 'Commencement Date\'s To Date must be set after or equal to From Date.').isValidSync(value)
  //   }
  //   return true
  // }),
})
export const validationSchemaTaxReturn = Yup.object().shape({
  // // Tax Return validations
  // payCycleYearTax: Yup.string().test({
  //   name: 'conditional-year-validation-tax',
  //   message: 'Year must be filled and be 4 digits in the format "YYYY".',
  //   test(value) {
  //     const reportType = this.parent.reprortType || []
  //     if (reportType.includes('Tax Return')) {
  //       return Yup.string()
  //         .required('Year must be filled.')
  //         .matches(/^\d{4}$/, 'Year must be 4 digits in the format "YYYY".')
  //         .matches(/^\S*$/, 'Year must not contain blank space.')
  //         .isValidSync(value)
  //     }
  //     return true
  //   },
  // }),
  // payCycleMonthTax: Yup.object().test({
  //   name: 'conditional-month-validation-tax',
  //   message: 'Month must be selected.',
  //   test(value) {
  //     const reportType = this.parent.reprortType || []
  //     if (reportType.includes('Tax Return')) {
  //       return Yup.object().shape({
  //         label: Yup.string().nullable().required('Month must be selected.'),
  //       }).isValidSync(value)
  //     }
  //     return true
  //   },
  // }).required('Month must be selected.'),
  // genRefIdTax: Yup.string().test({
  //   name: 'conditional-genref-validation-tax',
  //   message: 'Generation Reference must be selected.',
  //   test(value) {
  //     const reportType = this.parent.reprortType || []
  //     if (reportType.includes('Tax Return')) {
  //       return Yup.string().nullable().required('Generation Reference must be selected.').isValidSync(value)
  //     }
  //     return true
  //   },
  // }),
})

export const validationSchemaSendEmailPayroll = Yup.object().shape({
  // payroll slip
  reprortType: Yup.array()
    .min(1, 'Report Type must be selected')
    .nullable()
    .required('Report Type must be selected'),

  payCycleYear: Yup.string()
    // .nullable()
    .test({
      name: 'conditional-year-validation-payroll',
      message: 'Year must be filled, be 4 digits in the format "YYYY", and must not contain blank space.',
      test(value, context) {
        const reportType = context.parent.reprortType || []
        if (reportType.includes('Payroll Slip')) {
          if (!value) {
            return this.createError({ message: 'Year must be filled.' })
          }
          if (!/^\d{4}$/.test(value)) {
            return this.createError({ message: 'Year must be 4 digits in the format "YYYY".' })
          }
          // Check for any whitespace character
          if (/\s/.test(value.trim())) {
            return this.createError({ message: 'Year must not contain blank space.' })
          }
        }
        return true
      },
    })
    .test(
      'no-blank-space',
      'Year must not contain blank space',
      (value) => {
        if (value && /\s/.test(value)) { // Check for any whitespace character
          return false
        }
        return true
      },
    ),

  payCycleMonth: Yup.object().test({
    name: 'conditional-month-validation-payroll',
    message: 'Month must be selected.',
    test(value, context) {
      const reportType = context.parent.reprortType || []
      if (reportType.includes('Payroll Slip')) {
        return Yup.object().shape({
          label: Yup.string().nullable().required('Month must be selected.'),
        }).isValidSync(value)
      }
      return true
    },
  }).nullable(),

  genRefId: Yup.string().test({
    name: 'conditional-genref-validation-payroll',
    message: 'Generation Reference must be selected.',
    test(value, context) {
      const reportType = context.parent.reprortType || []
      if (reportType.includes('Payroll Slip')) {
        return Yup.string().nullable().required('Generation Reference must be selected.').isValidSync(value)
      }
      return true
    },
  }).nullable(),

  // Tax Return validations
  payCycleYearTax: Yup.string()
  // .nullable()
    .test({
      name: 'conditional-year-validation-payroll',
      message: 'Year must be filled, be 4 digits in the format "YYYY", and must not contain blank space.',
      test(value, context) {
        const reportType = context.parent.reprortType || []
        if (reportType.includes('Tax Return')) {
          if (!value) {
            return this.createError({ message: 'Year must be filled.' })
          }
          if (!/^\d{4}$/.test(value)) {
            return this.createError({ message: 'Year must be 4 digits in the format "YYYY".' })
          }
          // Check for any whitespace character
          if (/\s/.test(value.trim())) {
            return this.createError({ message: 'Year must not contain blank space.' })
          }
        }
        return true
      },
    })
    .test(
      'no-blank-space',
      'Year must not contain blank space',
      (value) => {
        if (value && /\s/.test(value)) { // Check for any whitespace character
          return false
        }
        return true
      },
    ),

  payCycleMonthTax: Yup.object().test({
    name: 'conditional-month-validation-tax',
    message: 'Month must be selected.',
    test(value, context) {
      const reportType = context.parent.reprortType || []
      if (reportType.includes('Tax Return')) {
        return Yup.object().shape({
          label: Yup.string().nullable().required('Month must be selected.'),
        }).isValidSync(value)
      }
      return true
    },
  }).nullable(),

  genRefIdTax: Yup.string().test({
    name: 'conditional-genref-validation-tax',
    message: 'Generation Reference must be selected.',
    test(value, context) {
      const reportType = context.parent.reprortType || []
      if (reportType.includes('Tax Return')) {
        return Yup.string().nullable().required('Generation Reference must be selected.').isValidSync(value)
      }
      return true
    },
  }).nullable(),

  // Annual Compensation Report
  payCycleYearReport: Yup.string()
  // .nullable()
    .test({
      name: 'conditional-year-validation-payroll',
      message: 'Year must be filled, be 4 digits in the format "YYYY", and must not contain blank space.',
      test(value, context) {
        const reportType = context.parent.reprortType || []
        if (reportType.includes('Tax Return')) {
          if (!value) {
            return this.createError({ message: 'Year must be filled.' })
          }
          if (!/^\d{4}$/.test(value)) {
            return this.createError({ message: 'Year must be 4 digits in the format "YYYY".' })
          }
          // Check for any whitespace character
          if (/\s/.test(value.trim())) {
            return this.createError({ message: 'Year must not contain blank space.' })
          }
        }
        return true
      },
    })
    .test(
      'no-blank-space',
      'Year must not contain blank space',
      (value) => {
        if (value && /\s/.test(value)) { // Check for any whitespace character
          return false
        }
        return true
      },
    ),

  payCycleMonthReport: Yup.object().test({
    name: 'conditional-month-validation-report',
    message: 'Month must be selected.',
    test(value, context) {
      const reportType = context.parent.reprortType || []
      if (reportType.includes('Annual Compensation Report')) {
        return Yup.object().shape({
          label: Yup.string().nullable().required('Month must be selected.'),
        }).isValidSync(value)
      }
      return true
    },
  }).nullable(),

  genRefIdTaxACR: Yup.string().test({
    name: 'conditional-genref-validation-report',
    message: 'Generation Reference must be selected.',
    test(value, context) {
      const reportType = context.parent.reprortType || []
      if (reportType.includes('Annual Compensation Report')) {
        return Yup.string().nullable().required('Generation Reference must be selected.').isValidSync(value)
      }
      return true
    },
  }).nullable(),

})

export const validationSchemaSendEmailPayroll3 = Yup.object().shape({
  // email: Yup.string().email('Invalid email address.').required('Email is required.'),
  emailSubject: Yup.string().when('$populated', (populated, schema) => (populated
    ? schema
      .required('Email Subject must be filled.')
      .test('htmlFormat', 'Support Plain Text and HTML format', (value) => {
        // Regular expression to check for HTML tags
        const htmlRegex = /<[a-z][\s\S]*>/i
        return !htmlRegex.test(value) // Check if value contains HTML tags
      })
      .test('fontFormatting', 'Allow font formatting', (value) => {
        // Regular expression to check for font formatting tags
        const fontFormattingRegex = /<(?:b|strong|i|em|u|ins|s|strike|del|sup|sub|mark|small|big)>/i
        return !fontFormattingRegex.test(value) // Check if value contains font formatting tags
      })
    : schema.nullable())),
  emailProfile: Yup.object()
    .shape({
      label: Yup.string()
        .nullable()
        .required('Email Profile must be selected.'),
    })
    .required('Email Profile must be selected.')
    .strict(true),
})

export const validationSchemaSendEmailSteps2 = Yup.object().shape({
  emailSubject: Yup.string().when('$populated', (populated, schema) => (populated
    ? schema
      .required('Email Subject must be filled.')
      .test('htmlFormat', 'Support Plain Text and HTML format', (value) => {
        // Regular expression to check for HTML tags
        const htmlRegex = /<[a-z][\s\S]*>/i
        return !htmlRegex.test(value) // Check if value contains HTML tags
      })
      .test('fontFormatting', 'Allow font formatting', (value) => {
        // Regular expression to check for font formatting tags
        const fontFormattingRegex = /<(?:b|strong|i|em|u|ins|s|strike|del|sup|sub|mark|small|big)>/i
        return !fontFormattingRegex.test(value) // Check if value contains font formatting tags
      })
    : schema.nullable())),
  // emailContent: yup
  //   .string()
  //   .nullable()
  //   .required('Email Content must be filled'),

  emailProfile: Yup.object()
    .shape({
      label: Yup.string()
        .nullable()
        .required('Email Profile must be selected.'),
    })
    .required('Email Profile must be selected.')
    .strict(true),
})
export const validationSchemaDocuTaxPro = Yup.object().shape({

  // emailContent: Yup.string();

})

export const validationSchemaSendEmailSteps3 = Yup.object().shape({

  // emailContent: Yup.string();

})

export const validationSchemaSendEmailSteps4 = Yup.object().shape({

  testEmailBox: Yup.string()
    .required('Email Box must be filled up.')
    .max(60, 'Email Box must not be longer than 60 characters.')
    .matches(/^[^\s]+$/, 'Email Box must not contain blank space.')
    .nullable(),
  // emailDomain: Yup.string().required('Email Domain must be selected.'),
  emailDomain: Yup.object()
    .shape({
      label: Yup.string()
        .nullable()
        .required('Email Domain must be selected.'),
    })
    .required('Email Domain must be selected.')
    .strict(true),
})

// validation schema audit trail
export const validationSchemeAuditTrail = Yup.object().shape({
  // emailContent: Yup.string(),
})

export const validationSchemaSunshineIntegration = Yup.object().shape({
  // emailContent: Yup.string(),
})

// Employee Leave Transaction validation schema
export const validationSchemaEmployeeLeaveTransaction = yup.object().shape({
  year: yup
    .string()
    .matches(/^\d{4}$/, 'employee_year_error_msg_formet')
    .matches(/^\S*$/, 'employee_year_must_not_contain')
    .required('employee_year_error_msg'),
  month: yup
    .string()
    .matches(/^\d{2}$/, 'employee_month_month_be_mm_formet')
    .required('employee_month_month_selected'),
  employeeProfileId: yup
    .string()
    .nullable('')
    .required('employee_leave_employee_code_must_be_selected'),
  description: yup
    .string()
    .max(120, 'employee_leave_description_must_not_be_longer_than_character')
    .required('employee_leave_description_must_be_filled'),
  leaveTransactionType: yup
    .string()
    .required('employee_leave_leave_transaction_type_must_be_selected'),
  unit: yup.string()
    .matches(/^\d+$/, 'employee_leave_unit_must_be_a_numeric_value') // Ensures it's numeric but treated as a string
    // .matches(/^\d{4}$/, 'Unit must be 4 digits in the format "YYYY".') // For a 4-digit year format, if needed
    // .matches(/^\S*$/, 'Unit must not contain blank space.') // Ensures no spaces
    .required('employee_leave_unit_must_be_filled'), // Required validation
  remarks: yup.string().max(500, 'all_fields_remarks'),
})

// employee remarks
export const validationSchemaEmployeeRemark = Yup.object().shape({
  employeeCode: yup
    .string()
    .required('emp_remark_employee_validation'),
  payCycle: Yup.string().required('emp_remark_paycyle_validation'),

  type: yup
    .string()
    .required('emp_remark_type_validation'),
  remarks: yup.string().max(4000, 'emp_remark_remarks_char_validation')
    .required('emp_remark_remarks_validation'),
})
