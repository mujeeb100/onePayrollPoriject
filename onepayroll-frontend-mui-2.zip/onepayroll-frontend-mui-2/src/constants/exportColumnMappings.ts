export const nationalityColumnMappings = [
  {
    key: 'nationalityCode', // API key
    title: 'nationality_code', // Localazy code
  },
  {
    key: 'nationalityName',
    title: 'nationality_name',
  },
]

export const countryColumnMappings = [
  {
    key: 'countryCode',
    title: 'country_code',
  },
  {
    key: 'countryName',
    title: 'country_name',
  },
  {
    key: 'createdAt',
    title: 'created_at',
  },
]
// cost center
export const costCenterColumnMappings = [
  {
    key: 'costCenterCode',
    title: 'costCenterCode',
  },
  {
    key: 'costCenterDescription',
    title: 'costCenterDescription',
  },
  {
    key: 'remarks',
    title: 'remarks',
  },
]
// division
export const divisionColumnMappings = [
  {
    key: 'divisionCode',
    title: 'divisioncode',
  },
  {
    key: 'divisionDescription',
    title: 'divisiondescription',
  },
  {
    key: 'remarks',
    title: 'remarks',
  },
]
// region
export const regionColumnMappings = [
  {
    key: 'regionCode',
    title: 'region_Code',
  },
  {
    key: 'regionDescription',
    title: 'region_Description',
  },
  {
    key: 'remarks',
    title: 'remarks',
  },
]
// team
export const teamColumnMappings = [
  {
    key: 'teamCode',
    title: 'teamCode',
  },
  {
    key: 'teamDescription',
    title: 'teamDescription',
  },
  {
    key: 'remarks',
    title: 'remarks',
  },
]
// department
export const departmentColumnMappings = [
  {
    key: 'departmentCode',
    title: 'ent_dept_code',
  },
  {
    key: 'departmentDescription',
    title: 'ent_dept_description',
  },
  {
    key: 'remarks',
    title: 'remarks',
  },
]
// IRD
export const irdColumnMappings = [
  {
    key: 'corporateTitleCode',
    title: 'ent_ird_corporate_title_code',
  },
  {
    key: 'corporateTitleName',
    title: 'ent_ird_corporate_title_name',
  },
  {
    key: 'remarks',
    title: 'remarks',
  },
]
// grade
export const gradeColumnMappings = [
  {
    key: 'gradeCode',
    title: 'ent_grade_view_code',
  },
  {
    key: 'gradeDescription',
    title: 'ent_grade_view_description',
  },
  {
    key: 'remarks',
    title: 'remarks',
  },
]
// position
export const positionColumnMappings = [
  {
    key: 'positionCode',
    title: 'position_Code_text',
  },
  {
    key: 'positionDescription',
    title: 'position_Description_text',
  },
  {
    key: 'remarks',
    title: 'remarks',
  },
]
// staff type
export const staffTypeColumnMappings = [
  {
    key: 'staffTypeCode',
    title: 'staffTypeCode',
  },
  {
    key: 'staffTypeDescription',
    title: 'staffTypeDescription',
  },
  {
    key: 'remarks',
    title: 'remarks',
  },
]
// termination code
export const terminationCodeColumnMappings = [
  {
    key: 'terminationCode',
    title: 'entity_termination_code_name',
  },
  {
    key: 'terminationReason',
    title: 'employee_profile_termination_reason',
  },
  {
    key: 'remarks',
    title: 'remarks',
  },
]
// currency exchange
export const currencyExchangeColumnMappings = [
  {
    key: 'currencyFrom',
    title: 'Currency From',
  },
  {
    key: 'currencyTo',
    title: 'Currency To',
  },
  {
    key: 'effectiveDate',
    title: 'Effective Date',
  },
  {
    key: 'conversionMethod',
    title: 'Conversion Method',
  },
  {
    key: 'exchangeRate',
    title: 'Exchange Rate',
  },

]
// service provider
export const ServiceProviderColumnMappings = [
  {
    key: 'providerCode',
    title: 'Provider Type',
  },
  {
    key: 'providerName',
    title: 'Provider Name',
  },
  {
    key: 'providerContactPerson',
    title: 'providerContactPerson',
  },
  {
    key: 'providerPhoneNo',
    title: 'providerPhoneNo',
  },
  {
    key: 'providerFaxNo',
    title: 'providerFaxNo',
  },
  {
    key: 'providerEmailAddress',
    title: 'providerEmailAddress',
  },
  {
    key: 'providerAddressLine1',
    title: 'providerAddressLine1',
  },
  {
    key: 'providerAddressLine2',
    title: 'providerAddressLine2',
  },
  {
    key: 'providerAddressLine3',
    title: 'providerAddressLine3',
  },
  {
    key: 'providerAddressCountry',
    title: 'providerAddressCountry',
  },
  {
    key: 'employerName',
    title: 'employerName',
  },
  {
    key: 'employerRegistrationFileNo',
    title: 'employerRegistrationFileNo',
  },
  {
    key: 'employerPICName',
    title: 'employerPICName',
  },
  {
    key: 'officeFaxNo',
    title: 'officeFaxNo',
  },
  {
    key: 'officePhoneNo',
    title: 'officePhoneNo',
  },
  {
    key: 'employerPICDesignation',
    title: 'employerPICDesignation',
  },
  {
    key: 'employerPICSignatureRemarks',
    title: 'employerPICSignatureRemarks',
  },

]
// entity setting
export const SettingsColumnMappings = [
  {
    key: 'settingCode',
    title: 'settingCode',
  },
  {
    key: 'settingName',
    title: 'settingName',
  },
  {
    key: 'category',
    title: 'category',
  },
  {
    key: 'settingValue',
    title: 'settingValue',
  },
  {
    key: 'remarks',
    title: 'remarks',
  },
]
// EmployeeMovementColumnMappings
export const EmployeeMovementColumnMappings = [
  {
    key: 'movementType',
    title: 'movement Type',
  },
  {
    key: 'movementDescription',
    title: 'Movement Description',
  },
  {
    key: 'status',
    title: 'status',
  },
  {
    key: 'remarks',
    title: 'remarks',
  },
]
// pension fund scheme item
export const PensionFundSchemeItemColumnMappings = [
  {
    key: 'pensionFundSchemeCode',
    title: 'Pension Fund Scheme',
  },
  {
    key: 'effectiveStartDate',
    title: 'Effective Start Date',
  },
  {
    key: 'effectiveEndDate',
    title: 'Effective End Date',
  },
  {
    key: 'payItemCode',
    title: 'Pay Item',
  },
  {
    key: 'status',
    title: 'Status',
    render: (status: any) => (status === 'Active' ? 'Active' : 'Inactive'),
  },
  // data: allPosts?.records?.map((record:any) => ({
  //   ...record,
  //   status: record.status ? 'Active' : 'Inactive',
  // })),
]

// employee movement configuration
export const EmpMovementConfigurationColumnMappings = [
  {
    key: 'movementType',
    title: 'ent_emp_movement_configuration_movement_type',
  },
  {
    key: 'fieldName',
    title: 'ent_emp_movement_configuration_field_name',
  },
  {
    key: 'mandatory',
    title: 'ent_emp_movement_configuration_mandatory',
  },
  {
    key: 'displaySequence',
    title: 'ent_emp_movement_configuration_dsp',
  },

]

// pension fund scheme item
export const WorkCalenderColumnMappings = [
  {
    key: 'cawCalculationMethod',
    title: 'ent_work_calendar_caw_calculation_method',
  },
  {
    key: 'holidayCalendar',
    title: 'ent_work_calendar_holiday_calendar',
  },
  {
    key: 'holidaysPaymentOption',
    title: 'ent_work_calendar_holidays_pay_opt',
  },
  {
    key: 'workCalendarCode',
    title: 'ent_work_calendar_view_code',
  },
  {
    key: 'workCalendarName',
    title: 'ent_work_calendar_view_name',
  },
  {
    key: 'hoursPerFullWorkDay',
    title: 'ent_work_calendar_hrs_day',
  },
  {
    key: 'salaryProrationMethod',
    title: 'ent_work_calendar_salary_proration_method',
  },
  {
    key: 'remarks',
    title: 'remarks',
  },
  {
    key: 'sunday',
    title: 'ent_work_calendar_sunday',
  },

  {
    key: 'monday',
    title: 'ent_work_calendar_monday',
  },
  {
    key: 'tuesday',
    title: 'ent_work_calendar_tuesday',
  },
  {
    key: 'wednesday',
    title: 'ent_work_calendar_wednesday',
  },

  {
    key: 'thursday',
    title: 'ent_work_calendar_thursday',
  },
  {
    key: 'friday',
    title: 'ent_work_calendar_friday',
  },
  {
    key: 'saturday',
    title: 'ent_work_calendar_saturday',
  },

]
// entity profile
// pension fund scheme item
export const EntityProfileColumnMappings = [
  {
    key: 'cawCalculationMethod',
    title: 'ent_work_calendar_caw_calculation_method',
  },
  {
    key: 'holidayCalendar',
    title: 'ent_work_calendar_holiday_calendar',
  },
  {
    key: 'holidaysPaymentOption',
    title: 'ent_work_calendar_holidays_pay_opt',
  },
  {
    key: 'workCalendarCode',
    title: 'ent_work_calendar_view_code',
  },
  {
    key: 'workCalendarName',
    title: 'ent_work_calendar_view_name',
  },
  {
    key: 'hoursPerFullWorkDay',
    title: 'ent_work_calendar_hrs_day',
  },
  {
    key: 'salaryProrationMethod',
    title: 'ent_work_calendar_salary_proration_method',
  },
  {
    key: 'remarks',
    title: 'remarks',
  },
  {
    key: 'sunday',
    title: 'ent_work_calendar_sunday',
  },

  {
    key: 'monday',
    title: 'ent_work_calendar_monday',
  },
  {
    key: 'tuesday',
    title: 'ent_work_calendar_tuesday',
  },
  {
    key: 'wednesday',
    title: 'ent_work_calendar_wednesday',
  },

  {
    key: 'thursday',
    title: 'ent_work_calendar_thursday',
  },
  {
    key: 'friday',
    title: 'ent_work_calendar_friday',
  },
  {
    key: 'saturday',
    title: 'ent_work_calendar_saturday',
  },

]
// pay item group
export const payItemGroupColumnMappings = [
  {
    key: 'itemGroupCode',
    title: 'itemGroupCode',
  },
  {
    key: 'itemGroupName',
    title: 'itemGroupName',
  },
  {
    key: 'remarks',
    title: 'remarks',
  },
]

// pay group
// cost center
export const payGroupColumnMappings = [
  {
    key: 'payGroupCode',
    title: 'payGroupCode',
  },
  {
    key: 'payGroupName',
    title: 'payGroupName',
  },
  {
    key: 'status',
    title: 'status',
  },
  {
    key: 'remarks',
    title: 'remarks',
  },
  {
    key: 'payCycleCode',
    title: 'payCycleCode',
  },
  {
    key: ' payCycleName',
    title: ' payCycleName',
  },
  {
    key: 'payCycleFrequency',
    title: 'payCycleFrequency',
  },
  {
    key: 'payCycleType',
    title: 'payCycleType',
  },
  {
    key: 'payrollPeriodStartMonth',
    title: 'payrollPeriodStartMonth',
  },
  {
    key: 'payrollPeriodStartDay',
    title: 'payrollPeriodStartDay',
  },
  {
    key: 'payrollPeriodEndMonth',
    title: 'payrollPeriodEndMonth',
  },
  {
    key: 'payrollPeriodEndDay',
    title: 'payrollPeriodEndDay',
  },
  {
    key: 'cutOffDateMethod',
    title: 'cutOffDateMethod',
  }, {
    key: 'cutOffDateDay',
    title: 'cutOffDateDay',
  },
  {
    key: 'payDateMethod',
    title: 'payDateMethod',
  },
  {
    key: 'payDateDay',
    title: 'payDateDay',
  },

]

export const clientGroupProfileColumnMappings = [
  {
    key: 'clientGroupCode',
    title: 'Client Group Code',
  },
  {
    key: 'clientGroupName',
    title: 'Client Group Name',
  },
  {
    key: 'id',
    title: 'Id',
  },
  {
    key: 'remarks',
    title: 'Remarks',
  },
  {
    key: 'status',
    title: 'status',
  },

]
export const employeePasswordColumnMappings = [
  {
    key: 'employeeCode',
    title: 'employeeCode',
  },
  {
    key: 'givenName',
    title: 'givenName',
  },
  {
    key: 'surname',
    title: 'surname',
  },
  {
    key: 'departmentCode',
    title: 'departmentCode',
  },
  {
    key: 'costCenterCode',
    title: 'costCenterCode',
  },
  {
    key: 'staffTypeCode',
    title: 'staffTypeCode',
  },
  {
    key: 'expiryDate',
    title: 'expiryDate',
  },
]
// Entity  pension fund scheme rule
export const pensionFundSchemeRuleColumnMappings = [
  {
    key: 'pensionFundSchemeRuleType',
    title: 'pensionFundSchemeRuleType',
  },
  {
    key: 'effectiveStartDate',
    title: 'effective Start Date',
  },
  {
    key: 'effectiveEndDate',
    title: 'effective End Date',
  },
  {
    key: 'relevantIncomeMinAmount',
    title: 'Relevant Income Min Amount',
  },
  {
    key: 'relevantIncomeMaxAmount',
    title: 'Relevant Income Max Amount',
  },
  {
    key: 'yearOfServiceFrom',
    title: 'Year Of Service From',
  },
  {
    key: 'yearOfServiceTo',
    title: 'Year Of Service To',
  },
  {
    key: 'employerContributionRate',
    title: 'Employer Contribution Rate',
  },
  {
    key: 'employeeContributionRate',
    title: 'Employee Contribution Rate',
  },
  {
    key: 'employerFixedContributionAmount',
    title: 'Employer Fixed Contribution Amount',
  },
  {
    key: 'employeeFixedContributionAmount',
    title: 'Employee Fixed Contribution Amount',
  },
  {
    key: 'employerAnnualContributionCap',
    title: 'Employer Annua lContribution Cap',
  },
  {
    key: 'employeeAnnualContributionCap',
    title: 'Employer Annual Contribution Cap',
  },
]

export const companyBankAccountColumnMappings = [
  {
    key: 'accountNumber',
    title: 'accountNumber',
  },
  {
    key: 'bankCode',
    title: 'bankCode',
  },
  {
    key: 'bankFileFormat',
    title: 'bankFileFormat',
  },
  {
    key: 'bankReference',
    title: 'bankReference',
  },
  {
    key: 'branchCode',
    title: 'branchCode',
  },
  {
    key: 'companyBankAccountCode',
    title: 'companyBankAccountCode',
  },
  {
    key: 'companyBankAccountDescription',
    title: 'companyBankAccountDescription',
  },
  {
    key: 'currency',
    title: 'currency',
  },
  {
    key: 'hsbcbiaAccountType',
    title: 'hsbcbiaAccountType',
  },
  {
    key: 'hsbcbiaSuffix',
    title: 'hsbcbiaSuffix',
  },
  {
    key: 'hsbcBusinessIntegratedAccount',
    title: 'hsbcBusinessIntegratedAccount',
  },
  {
    key: 'hsbcifileFileReference',
    title: 'hsbcifileFileReference',
  },
  {
    key: 'hsbcifilehsbcNetCustomerID',
    title: 'hsbcifilehsbcNetCustomerID',
  },
  {
    key: 'hsbcifilehsbcConnectCustomerId',
    title: 'hsbcifilehsbcConnectCustomerId',
  },
  {
    key: 'hsbcifilePaymentCode',
    title: 'hsbcifilePaymentCode',
  },
  {
    key: 'hsbcmriFileExtension',
    title: 'hsbcmriFileExtension',
  },
  {
    key: 'hsbcmriPaymentCode',
    title: 'hsbcmriPaymentCode',
  },
  {
    key: 'hsbcmriPlanCode',
    title: 'hsbcmriPlanCode',
  },
  {
    key: 'id',
    title: 'id',
  },
  {
    key: 'status',
    title: 'status',
  },
  {
    key: 'swiftCode',
    title: 'swiftCode',
  },
  {
    key: 'valueDate',
    title: 'valueDate',
  },
]

export const pensionFundSchemeColumnMappings = [
  {
    key: 'id',
    title: 'id',
  },
  {
    key: 'pensionFundSchemeCode',
    title: 'pensionFundSchemeCode',
  },
  {
    key: 'schemeDescription',
    title: 'schemeDescription',
  },
  {
    key: 'serviceProviderCode',
    title: 'serviceProviderCode',
  },
  {
    key: 'schemeType',
    title: 'schemeType',
  },
  {
    key: 'status',
    title: 'status',
  },
  {
    key: 'remarks',
    title: 'remarks',
  },
  {
    key: 'schemeFileNumber',
    title: 'schemeFileNumber',
  },
  {
    key: 'subSchemeFileNumber',
    title: 'subSchemeFileNumber',
  },
  {
    key: 'supplementaryScheme',
    title: 'supplementaryScheme',
  },
  {
    key: 'schemeCurrency',
    title: 'schemeCurrency',
  },
  {
    key: 'contributionCycle',
    title: 'contributionCycle',
  },
  {
    key: 'participationNumber',
    title: 'participationNumber',
  },
  {
    key: 'referenceNumber',
    title: 'referenceNumber',
  },
  {
    key: 'memberClass',
    title: 'memberClass',
  },
  {
    key: 'paymentMethod',
    title: 'paymentMethod',
  },
  {
    key: 'payCentre',
    title: 'payCentre',
  },
  {
    key: 'schemeRuleType',
    title: 'schemeRuleType',
  },
  {
    key: 'roundingType',
    title: 'roundingType',
  },
  {
    key: 'decimalPoint',
    title: 'decimalPoint',
  },
  {
    key: 'annualCapStartMonthOption',
    title: 'annualCapStartMonthOption',
  },
  {
    key: 'schemeJoinDateOption',
    title: 'schemeJoinDateOption',
  },
  {
    key: 'employeeContributionPayItemCode',
    title: 'employeeContributionPayItemCode',
  },
  {
    key: 'employeeAccrualContributionPayItemCode',
    title: 'employeeAccrualContributionPayItemCode',
  },
  {
    key: 'employeeCalculationStartDateOption',
    title: 'employeeCalculationStartDateOption',
  },
  {
    key: 'employeeCalculationStartDateDays',
    title: 'employeeCalculationStartDateDays',
  },
  {
    key: 'employeeContributionStartDateDays',
    title: 'employeeContributionStartDateDays',
  },
  {
    key: 'deductMPFMCForEmployeeContribution',
    title: 'deductMPFMCForEmployeeContribution',
  },
  {
    key: 'employerContributionPayItemCode',
    title: 'employerContributionPayItemCode',
  },
  {
    key: 'employerAccrualContributionPayItemCode',
    title: 'employerAccrualContributionPayItemCode',
  },
  {
    key: 'employerCalculationStartDateOption',
    title: 'employerCalculationStartDateOption',
  },
  {
    key: 'employerCalculationStartDateDays',
    title: 'employerCalculationStartDateDays',
  },
  {
    key: 'employerContributionStartDateDays',
    title: 'employerContributionStartDateDays',
  },
  {
    key: 'deductMPFMCForEmployerContribution',
    title: 'deductMPFMCForEmployerContribution',
  },
  {
    key: 'addContributionPeriodToPaymentDescription',
    title: 'addContributionPeriodToPaymentDescription',
  },
  {
    key: 'showRelevantIncomeAmount',
    title: 'showRelevantIncomeAmount',
  },
  {
    key: 'remittanceStatementRemarks',
    title: 'remittanceStatementRemarks',
  },
  {
    key: 'descriptionInPensionFundSection',
    title: 'descriptionInPensionFundSection',
  },
  {
    key: 'showContributionInPensionFundSection',
    title: 'showContributionInPensionFundSection',
  },
  {
    key: 'showRelevantIncomeInPensionFundSection',
    title: 'showRelevantIncomeInPensionFundSection',
  },
  {
    key: 'surchargePercentage',
    title: 'surchargePercentage',
  },
  {
    key: 'surchargePayDate',
    title: 'surchargePayDate',
  },
  {
    key: 'employeeSurchargeAmount',
    title: 'employeeSurchargeAmount',
  },
  {
    key: 'employerSurchargeAmount',
    title: 'employerSurchargeAmount',
  },
  {
    key: 'draft',
    title: 'draft',
  },
]
// payroll non recurring
// payroll non recurring
export const PayRollNonRecurringColumnMappings = [
  {
    key: 'payCycleYear',
    title: 'Pay Cycle Year',
  },
  {
    key: 'payCycleMonth',
    title: 'Pay Cycle Month',
  },
  {
    key: 'payCycleCode',
    title: 'Pay Cycle Code',
  },
  {
    key: 'employeeCode',
    title: 'Employee Code',
  },
  {
    key: 'payItemCode',
    title: 'Pay Item Code',
  },
  {
    key: 'ratePerUnit',
    title: 'Rate Per Unit',
  },
  {
    key: 'quantity',
    title: 'Quantity',
  },
  {
    key: 'transactionAmount',
    title: 'Transaction Amount',
  },
  {
    key: 'originalCurrency',
    title: 'Original Currency',
  },
  {
    key: 'paymentCurrency',
    title: 'Payment Currency',
  },
  {
    key: 'exchangeRate',
    title: 'Exchange Rate',
  },
  {
    key: 'paymentMethod',
    title: 'Payment Method',
  },
  {
    key: 'employeeBankAccount',
    title: 'Employee Bank Account',
  },
  {
    key: 'costCenterCode',
    title: 'Cost Center Code',
  },
  {
    key: 'coveringStartDate',
    title: 'Covering Star tDate',
  },
  {
    key: 'coveringEndDate',
    title: 'Covering EndDate',
  },
  {
    key: 'reportingPeriodYear',
    title: 'Reporting Period Year',
  },
  {
    key: 'reportingPeriodMonth',
    title: 'Reporting Period Month',
  },
  {
    key: 'remarks',
    title: 'Remarks',
  },
]
// Pay Cycle Master administrator
export const PayCycleMasterColumnMappings = [
  {
    key: 'payCycleCode',
    title: 'Pay Cycle Code',
  },
  {
    key: 'payCycleName',
    title: 'Pay Cycle Name',
  },
  {
    key: 'payCycleYear',
    title: 'Pay Cycle Year',
  },
  {
    key: 'payCycleMonth',
    title: 'Pay Cycle Month',
  },
  {
    key: 'statusId',
    title: 'StatusID',
  },
  {
    key: 'status.label',
    title: 'Status',
  },
  {
    key: 'payCycleTypeId',
    title: 'payCycleTypeId',
  },
  {
    key: 'payCycleType.label',
    title: 'payCycleType',
  },
  {
    key: 'payCycleStartDate',
    title: 'payCycleStartDate',
  },
  {
    key: 'payCycleEndDate',
    title: 'payCycleEndDate',
  },
  {
    key: 'payCycleCutOffDate',
    title: 'payCycleCutOffDate',
  },
  {
    key: 'payCyclePayDate',
    title: 'payCyclePayDate',
  },
  {
    key: 'paymentMethod',
    title: 'paymentMethod',
  },
  {
    key: 'remarks',
    title: 'Remarks',
  },

]
// Email Template
export const emailTemplateColumnMappings = [
  {
    key: 'emailTemplateCode',
    title: 'Template Code',
  },
  {
    key: 'emailTemplateName',
    title: 'Template Name',
  },
  {
    key: 'emailTemplateType',
    title: 'Code',
    // Provide a function to dynamically extract and concatenate nested properties into a string
    getValue: (rowData:any) => {
      const { emailTemplateType } = rowData
      if (emailTemplateType) {
        const { code } = emailTemplateType
        return code || '' // Return the code if available, or an empty string
      }
      return '' // Return an empty string if emailTemplateType is null or undefined
    },
  },

]
// user role
export const userRoleColumnMappings = [
  {
    key: 'id',
    title: 'id',
  },
  {
    key: 'roleCode',
    title: 'Role Code',
  },
  {
    key: 'roleName',
    title: 'Role Name',
  },
  {
    key: 'roleType',
    title: 'Role Type',
  },
  {
    key: 'remarks',
    title: 'Remarks',
  },
  {
    key: 'userCount',
    title: 'User Count',
  },
]
export const emailProfileColumnMappings = [
  {
    key: 'emailProfileCode',
    title: 'Email Profile Code',
  },
  {
    key: 'emailProfileName',
    title: 'Email Profile Name',
  },
  {
    key: 'setAsDefaultEmailProfile',
    title: 'Set As Default EmailProfile',
  },
  {
    key: 'sender',
    title: 'Sender',
  },
]

// employee password
export const employeePasswordColumnMappingsView = [
  {
    key: 'employeeCode',
    title: 'Employee Code',
  },
  {
    key: 'password',
    title: 'Password',
  },
  {
    key: 'expiryDate',
    title: 'Expirty Date',
  },

]
// employee Leave Transaction

export const ColumnemployeeLeaveTransaction = [
  {
    key: 'year',
    title: 'Pay cycle - Year',
  },
  {
    key: 'month',
    title: 'Pay cycle  - Month',
  },
  {
    key: 'employeeProfileId',
    title: 'Employee',
  },
  {
    key: 'description',
    title: 'Description',
  },
  {
    key: 'leaveTransactionType',
    title: 'Leave transaction type',
  },
  {
    key: 'unit',
    title: 'Unit',
  },
  {
    key: 'remarks',
    title: 'Remarks',
  },
]

// employee Remarks
export const employeeRemarksColumnMappings = [
  {
    key: 'employeeCode',
    title: 'employee_bank_account_employee_profile_id',
  },
  {
    key: 'payCycle',
    title: 'emp_remark_paycyle',
  },
  {
    key: 'type',
    title: 'emp_remark_type',
  },
  {
    key: 'remarks',
    title: 'emp_remark_remarks',
  },
]
