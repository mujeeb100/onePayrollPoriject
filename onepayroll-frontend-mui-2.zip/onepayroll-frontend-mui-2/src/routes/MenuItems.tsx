import AccountCircleIcon from '@mui/icons-material/AccountCircle'
import BusinessIcon from '@mui/icons-material/Business'
import CloudUploadOutlinedIcon from '@mui/icons-material/CloudUploadOutlined'
import CurrencyExchangeIcon from '@mui/icons-material/CurrencyExchange'
import DashboardOutlinedIcon from '@mui/icons-material/DashboardOutlined'
import FormatListBulletedIcon from '@mui/icons-material/FormatListBulleted'
import GroupOutlinedIcon from '@mui/icons-material/GroupOutlined'
import LanIcon from '@mui/icons-material/Lan'
import NewspaperIcon from '@mui/icons-material/Newspaper'
import NotificationsIcon from '@mui/icons-material/Notifications'
import PublicIcon from '@mui/icons-material/Public'
import { NavigateFunction } from 'react-router-dom'

import { MainMenuType } from '../types'
import { routes } from './routes'

export const MenuItems = (navigate: NavigateFunction): MainMenuType[] => [
  {
    title: 'dashboard_menu_title',
    key: crypto.randomUUID(),
    // icon: <DashboardIcon />,
    icon: <DashboardOutlinedIcon />,
    path: routes.dashboard,
    permission: 'Country_Create',
    onClick: () => {},
    event: () => {
      navigate(routes.home)
    },
    active: false,
  },
  {
    title: 'entity_menu_title',
    icon: <BusinessIcon />,
    path: routes.entities,
    onClick: () => {},
    key: crypto.randomUUID(),
    permission: 'Entity_EntityProfile_View',
    event: () => {
      navigate(routes.irdIndex)
    },
    active: false,
    children: [

      {
        title: 'EntityProfile',
        path: routes.entityProfile,
        permission: 'Entity_EntityProfile_View',
        onClick: () => {},
        key: crypto.randomUUID(),
        event: () => {
          navigate(routes.entityProfile)
        },
        active: false,
      },

      {
        title: 'companyBankAccounts',
        path: routes.companyBankAccount,
        permission: 'Entity_CompanyBankAccount_View',
        onClick: () => {},
        key: crypto.randomUUID(),
        event: () => {
          navigate(routes.companyBankAccount)
        },
        active: false,
      },

      {
        title: 'entity_termination_code_name',
        path: routes.terminationCode,
        permission: 'Entity_TerminationCode_View',
        onClick: () => {},
        key: crypto.randomUUID(),
        event: () => {
          navigate(routes.terminationCode)
        },
        active: false,
      },

      // enitity service provider
      {
        title: 'Service_Provider_Sub_Menu',
        path: routes.serviceProvider,
        permission: 'Entity_ServiceProvider_View',
        onClick: () => {},
        key: crypto.randomUUID(),
        event: () => {
          navigate(routes.serviceProvider)
        },
        active: false,
      },
      // entity settings
      {
        // title: 'entity_settings_submenu_title',
        title: 'Entity settings',
        path: routes.settings,
        permission: 'Entity_Settings_View',
        onClick: () => {},
        key: crypto.randomUUID(),
        event: () => {
          navigate(routes.settings)
        },
        active: false,
      },

    ],
  },
  {
    title: 'Employees',
    icon: <GroupOutlinedIcon />,
    path: routes.employee,
    permission: 'EmployeeSnapshot_View',
    key: crypto.randomUUID(),
    onClick: () => {},
    event: () => {
      navigate(routes.person)
    },
    active: false,
    children: [
      {
        title: 'employee_submenu_person_title',
        path: routes.person,
        permission: 'Person_View',
        key: crypto.randomUUID(),
        onClick: () => {},
        event: () => {
          navigate(routes.person)
        },
        active: false,
      },
      {
        title: 'employee_submenu_currency_settings_title',
        path: routes.person,
        permission: 'Currency_View',
        key: crypto.randomUUID(),
        onClick: () => {},
        event: () => {
          navigate(routes.home)
        },
        active: false,
      },
      {
        title: 'employee_submenu_person_settings',
        path: routes.person,
        permission: 'Person_View',
        key: crypto.randomUUID(),
        onClick: () => {},
        event: () => {
          navigate(routes.person)
        },
        active: false,
      },
      {
        title: 'Employees',
        path: routes.employeeProfile,
        permission: 'Person_View',
        key: crypto.randomUUID(),
        onClick: () => {},
        event: () => {
          navigate(routes.employeeProfile)
        },
        active: false,
      },
      {
        title: 'employee_remark',
        path: routes.employeeRemark,
        permission: 'EmployeeRemarks_View',
        onClick: () => {},
        key: crypto.randomUUID(),
        event: () => {
          navigate(routes.employeeRemark)
        },
        active: false,
      },
      {
        title: 'emp_password',
        path: routes.employeePassword,
        permission: 'EmployeePassword_View',
        onClick: () => {},
        key: crypto.randomUUID(),
        event: () => {
          navigate(routes.employeePassword)
        },
        active: false,
      },
      {
        title: 'employee_leave_text',
        path: routes.employeeLeaveTransaction,
        permission: 'Person_View',
        key: crypto.randomUUID(),
        onClick: () => {},
        event: () => {
          navigate(routes.employeeLeaveTransaction)
        },
        active: false,
      },
    ],
  },
  {
    title: 'Report',
    icon: <NewspaperIcon />,
    path: routes.employee,
    permission: 'Reporting_Reporting_View',
    key: crypto.randomUUID(),
    onClick: () => {},
    event: () => {
      navigate(routes.standardReports)
    },
    active: false,
    children: [
      {
        title: 'Review Report',
        path: routes.reviewReport,
        permission: 'Reporting_Reporting_View',
        key: crypto.randomUUID(),
        onClick: () => {},
        event: () => {
          navigate(routes.reviewReport)
        },
        active: false,
      },
      {
        title: 'Standard reports',
        path: routes.standardReports,
        permission: 'Reporting_Reporting_View',
        key: crypto.randomUUID(),
        onClick: () => {},
        event: () => {
          navigate(routes.standardReports)
        },
        active: false,
      },
      {
        title: 'Annual compensation reports',
        path: routes.annualCompensationReport,
        permission: 'Reporting_Reporting_View',
        key: crypto.randomUUID(),
        onClick: () => {},
        event: () => {
          navigate(routes.annualCompensationReport)
        },
        active: false,
      },
      {
        title: 'Payroll Slip',
        path: routes.payrollSlip,
        permission: 'Reporting_Reporting_View',
        key: crypto.randomUUID(),
        onClick: () => {},
        event: () => {
          navigate(routes.payrollSlip)
        },
        active: false,
      },
      {
        title: 'Payment Summary report',
        path: routes.paymentSummary,
        permission: 'Reporting_Reporting_View',
        key: crypto.randomUUID(),
        onClick: () => {},
        event: () => {
          navigate(routes.paymentSummary)
        },
        active: false,
      },
      {
        title: 'publish_report_title',
        path: routes.publishReport,
        permission: 'Reporting_Reporting_View',
        onClick: () => {},
        key: crypto.randomUUID(),
        event: () => {
          navigate(routes.publishReport)
        },
        active: false,
      },
      {
        title: 'Custom report',
        path: routes.reportDesignerCustomReport,
        permission: 'Reporting_ReportDesigns_View',
        onClick: () => {},
        key: crypto.randomUUID(),
        event: () => {
          navigate(routes.reportDesignerCustomReport)
        },
        active: false,
      },
      {
        title: 'Upload integration documents',
        path: routes.docutaxPro,
        permission: 'Integration_Integration_View',
        onClick: () => {},
        key: crypto.randomUUID(),
        event: () => {
          navigate(routes.docutaxPro)
        },
        active: false,
      },
      {
        title: 'Audit trails report',
        path: routes.auditTrail,
        permission: 'Reporting_Reporting_View',
        key: crypto.randomUUID(),
        onClick: () => {},
        event: () => {
          navigate(routes.auditTrail)
        },
        active: false,
      },
    ],
  },
  {
    title: 'global_settings',
    icon: <PublicIcon />,
    path: routes.global,
    onClick: () => {},
    key: crypto.randomUUID(),
    permission: 'Country_View',
    event: () => {
      navigate(routes.country)
    },
    active: false,
    children: [
      {
        title: 'global_settings_submenu_country_title',
        path: routes.country,
        onClick: () => {},
        key: crypto.randomUUID(),
        permission: 'Country_View',
        event: () => {
          navigate(routes.country)
        },
        active: false,
      },
      {
        title: 'global_settings_submenu_currency_title',
        path: routes.currency,
        onClick: () => {},
        key: crypto.randomUUID(),
        permission: 'Currency_View',
        event: () => {
          navigate(routes.currency)
        },
        active: false,
      },
      {
        title: 'global_settings_submenu_nationality_title',
        path: routes.nationality,
        onClick: () => {},
        key: crypto.randomUUID(),
        permission: 'Nationality_View',
        event: () => {
          navigate(routes.nationality)
        },
        active: false,
      },
      {
        title: 'ent_work_calendar_holiday_calendar',
        path: routes.holidayCalender,
        onClick: () => {},
        key: crypto.randomUUID(),
        permission: 'Entity_WorkCalendar_View',
        event: () => {
          navigate(routes.holidayCalender)
        },
        active: false,
      },
      {
        title: 'Pension Fund Scheme Rule',
        path: routes.globalPensionFundSchemeRuleList,
        onClick: () => {},
        key: crypto.randomUUID(),
        permission: 'PensionFundSchemeRule_View',
        event: () => {
          navigate(routes.globalPensionFundSchemeRuleList)
        },
        active: false,
      },
      {
        title: 'Pension fund Termination code',
        path: routes.pensionFundTermination,
        onClick: () => {},
        key: crypto.randomUUID(),
        permission: 'PensionFundTerminationCode_View',
        event: () => {
          navigate(routes.pensionFundTermination)
        },
        active: false,
      },
      // {
      //   // title: 'standard_expression_menu_title',
      //   title: 'Standard Expression',
      //   path: routes.standardExpression,
      //   onClick: () => {},
      //   key: crypto.randomUUID(),
      //   permission: 'home',
      //   event: () => {
      //     navigate(routes.standardExpression)
      //   },
      //   active: false,
      // },
      // {
      //   // title: 'standard_formula_menu_title',
      //   title: 'Standard Formula',
      //   path: routes.standardFormula,
      //   onClick: () => {},
      //   key: crypto.randomUUID(),
      //   permission: 'home',
      //   event: () => {
      //     navigate(routes.standardFormula)
      //   },
      //   active: false,
      // },
      {
        // title: 'global_settings_submenu_provider_type_title',
        title: 'Provider Type',
        path: routes.providertype,
        onClick: () => {},
        key: crypto.randomUUID(),
        permission: 'ProviderType_View',
        event: () => {
          navigate(routes.providertype)
        },
        active: false,
      },
      {
        // title: 'global_settings_submenu_payment_method_title',
        title: 'Payment Method',
        path: routes.paymentmethod,
        onClick: () => {},
        key: crypto.randomUUID(),
        permission: 'PaymentMethod_View',
        event: () => {
          navigate(routes.paymentmethod)
        },
        active: false,
      },
      {
        // title: 'global_settings_submenu_setting_template_title',
        title: 'Setting Template',
        path: routes.settingtemplate,
        onClick: () => {},
        key: crypto.randomUUID(),
        permission: 'SettingTemplate_View',
        event: () => {
          navigate(routes.settingtemplate)
        },
        active: false,
      },

    ],
  },
  // {
  //   title: 'client_groups_menu_title',
  //   icon: <ClientGroupIcon />,
  //   path: routes.home,
  //   permission: 'ClientGroupProfile_View',
  //   key: crypto.randomUUID(),
  //   onClick: () => {},
  //   event: () => {
  //     navigate(routes.home)
  //   },
  //   active: false,
  // },
  {
    title: 'users_menu_title',
    icon: <AccountCircleIcon />,
    path: routes.home,
    permission: 'UserRole_View',
    key: crypto.randomUUID(),
    onClick: () => {},
    event: () => {
      navigate(routes.userRolesListing)
    },
    active: false,
    subTitle: 'User management',
    children: [
      {
        title: 'user_submenu_user_roles_title',
        path: routes.userRolesListing,
        permission: 'UserRole_View',
        onClick: () => {},
        key: crypto.randomUUID(),
        event: () => {
          navigate(routes.userRolesListing)
        },
        active: false,
      },
      {
        title: 'user_submenu_user_accounts_title',
        path: routes.userAccounts,
        permission: 'UserAdministration_View',
        onClick: () => {},
        key: crypto.randomUUID(),
        event: () => {
          navigate(routes.userAccounts)
        },
        active: false,
      },
    ],
  },

  {
    title: 'Client groups',
    icon: <LanIcon />,
    path: routes.client,
    permission: 'ClientGroupProfile_View',
    key: crypto.randomUUID(),
    onClick: () => {},
    event: () => {
      navigate(routes.clientGroupProfile)
    },
    active: false,
    subTitle: 'User management',
    children: [
      {
        title: 'Client Group Profile',
        path: routes.clientGroupProfile,
        permission: 'ClientGroupProfile_View',
        onClick: () => {},
        key: crypto.randomUUID(),
        event: () => {
          navigate(routes.clientGroupProfile)
        },
        active: false,
      },
      // {
      //   title: 'Provider Type',
      //   path: routes.userAccounts,
      //   permission: 'Person_View',
      //   onClick: () => {},
      //   key: crypto.randomUUID(),
      //   event: () => {
      //     navigate(routes.userAccounts)
      //   },
      //   active: false,
      // },
    ],
  },
  // Report
  // {
  //   title: 'Report',
  //   icon: <GroupOutlinedIcon />,
  //   path: routes.entities,
  //   key: crypto.randomUUID(),
  //   onClick: () => {},
  //   permission: 'Country_Create',
  //   event: () => {
  //     navigate(routes.irdIndex)
  //   },
  //   active: false,
  //   subTitle: 'Report Setup',
  //   children: [
  //     {
  //       title: 'publish_report_title',
  //       path: routes.publishReport,
  //       permission: 'Person_View',
  //       onClick: () => {},
  //       key: crypto.randomUUID(),
  //       event: () => {
  //         navigate(routes.publishReport)
  //       },
  //       active: false,
  //     },
  //     {
  //       title: 'Custom report',
  //       path: routes.reportDesignerCustomReport,
  //       permission: 'Person_View',
  //       onClick: () => {},
  //       key: crypto.randomUUID(),
  //       event: () => {
  //         navigate(routes.reportDesignerCustomReport)
  //       },
  //       active: false,
  //     },
  //     {
  //       title: 'Upload integration documents',
  //       path: routes.docutaxPro,
  //       permission: 'Person_View',
  //       onClick: () => {},
  //       key: crypto.randomUUID(),
  //       event: () => {
  //         navigate(routes.docutaxPro)
  //       },
  //       active: false,
  //     },
  //     {
  //       title: 'Audit trails report',
  //       path: routes.auditTrail,
  //       permission: 'Person_View',
  //       key: crypto.randomUUID(),
  //       onClick: () => {},
  //       event: () => {
  //         navigate(routes.auditTrail)
  //       },
  //       active: false,
  //     },
  //   ],
  // },

  {
    title: 'Payroll',
    icon: <CurrencyExchangeIcon />,
    path: routes.payroll,
    permission: 'Payroll_PayCycleAdministration_View',
    key: crypto.randomUUID(),
    onClick: () => {},
    event: () => {
      navigate(routes.payItemGroup)
    },
    active: false,
    children: [

      {
        title: 'run_payroll',
        path: routes.runPayroll,
        permission: 'Payroll_PayrollRun_View',
        key: crypto.randomUUID(),
        onClick: () => {},
        event: () => {
          navigate(routes.runPayroll)
        },
        active: false,
      },
      {
        title: 'pay_item_group_title',
        path: routes.payItemGroup,
        permission: 'Payroll_PayItem_View',
        key: crypto.randomUUID(),
        onClick: () => {},
        event: () => {
          navigate(routes.payItemGroup)
        },
        active: false,
      },

      {
        title: 'Pay_group_title',
        path: routes.payGroup,
        permission: 'Payroll_PayGroup_View',
        key: crypto.randomUUID(),
        onClick: () => {},
        event: () => {
          navigate(routes.payGroup)
        },
        active: false,
      },
      // payroll non rucurring
      {
        title: 'Non-recurring items',
        path: routes.payRollNonRecurring,
        permission: 'Payroll_PayrollNonRecurringItems_View',
        key: crypto.randomUUID(),
        onClick: () => {},
        event: () => {
          navigate(routes.payRollNonRecurring)
        },
        active: false,
      },
      {
        title: 'Pay_item_master_title',
        path: routes.payItemMaster,
        permission: 'Payroll_PayItem_View',
        key: crypto.randomUUID(),
        onClick: () => {},
        event: () => {
          navigate(routes.payItemMaster)
        },
        active: false,
      },
      // payroll cyle administrator
      {
        title: 'pay_cycle_administration',
        path: routes.payCycleAdministration,
        permission: 'Payroll_PayCycleAdministration_View',
        key: crypto.randomUUID(),
        onClick: () => {},
        event: () => {
          navigate(routes.payCycleAdministration)
        },
        active: false,
      },
      // payroll month-end-closing
      {
        title: 'Month end closing',
        path: routes.payRollMonthClosing,
        permission: 'Payroll_MonthEndClosing_View',
        key: crypto.randomUUID(),
        onClick: () => {},
        event: () => {
          navigate(routes.payRollMonthClosing)
        },
        active: false,
      },
      {
        title: 'pay_cycle_reassignment',
        path: routes.payCycleReassignment,
        permission: 'Payroll_EmployeePayCycleReassignment_View',
        key: crypto.randomUUID(),
        onClick: () => {},
        event: () => {
          navigate(routes.payCycleReassignment)
        },
        active: false,
      },
    ],
  },

  {
    title: 'Data setup',
    icon: <FormatListBulletedIcon />,
    path: routes.entities,
    onClick: () => {},
    key: crypto.randomUUID(),
    permission: 'Integration_Integration_View',
    event: () => {
      navigate(routes.irdIndex)
    },
    active: false,
    children: [
      // Region
      {
        title: 'entity_region_submenu_title',
        path: routes.region,
        permission: 'Entity_Region_View',
        onClick: () => { },
        key: crypto.randomUUID(),
        event: () => { navigate(routes.region) },
        active: false,
      },
      // Department
      {
        title: 'entity_submenu_department_title',
        path: routes.department,
        permission: 'Entity_Department_View',
        onClick: () => {},
        key: crypto.randomUUID(),
        event: () => {
          navigate(routes.department)
        },
        active: false,
      },
      // Cost center
      {
        title: 'costCenter',
        path: routes.costCenter,
        permission: 'Entity_CostCenter_Create',
        onClick: () => {},
        key: crypto.randomUUID(),
        event: () => {
          navigate(routes.costCenter)
        },
        active: false,
      },
      // Division
      {
        title: 'entity_division_submenu_title',
        path: routes.division,
        permission: 'Entity_Division_Create',
        onClick: () => { },
        key: crypto.randomUUID(),
        event: () => { navigate(routes.division) },
        active: false,
      },
      // Team
      {
        title: 'entity_team_submenu_title',
        path: routes.team,
        permission: 'Entity_Team_View',
        onClick: () => {},
        key: crypto.randomUUID(),
        event: () => {
          navigate(routes.team)
        },
        active: false,
      },
      // entity staff type
      {
        title: 'StaffType',
        path: routes.staffType,
        permission: 'Entity_StaffType_View',
        onClick: () => {},
        key: crypto.randomUUID(),
        event: () => {
          navigate(routes.staffType)
        },
        active: false,
      },
      // Position
      {
        title: 'entity_submenu_position_title',
        path: routes.position,
        permission: 'Entity_Position_View',
        onClick: () => {},
        key: crypto.randomUUID(),
        event: () => {
          navigate(routes.position)
        },
        active: false,
      },
      // Grade
      {
        title: 'ent_grade_title',
        path: routes.grade,
        permission: 'Entity_Grade_View',
        onClick: () => {},
        key: crypto.randomUUID(),
        event: () => {
          navigate(routes.grade)
        },
        active: false,
      },
      // entity ird
      {
        title: 'entity_submenu_ird_title',
        path: routes.ird,
        permission: 'Entity_IRDCorporateTitle_View',
        onClick: () => {},
        key: crypto.randomUUID(),
        event: () => {
          navigate(routes.ird)
        },
        active: false,
      },
      // currency exchange
      {
        title: 'ent_curr_exch_submenu_title',
        path: routes.currencyExchange,
        permission: 'Global_CurrencyExchange_View',
        onClick: () => {},
        key: crypto.randomUUID(),
        event: () => {
          navigate(routes.currencyExchange)
        },
        active: false,
      },

      // entity pension fund scheme item
      {
        title: 'pension_fund_scheme',
        path: routes.pensionFundScheme,
        permission: 'Entity_PensionFundScheme_View',
        onClick: () => {},
        key: crypto.randomUUID(),
        event: () => {
          navigate(routes.pensionFundScheme)
        },
        active: false,
      },
      // entity pension fund scheme item
      {
        title: 'Pension fund scheme rules',
        path: routes.pensionFundSchemeRule,
        permission: 'PensionFundSchemeRule_View',
        onClick: () => {},
        key: crypto.randomUUID(),
        event: () => {
          navigate(routes.pensionFundSchemeRule)
        },
        active: false,
      },
      // entity pension fund scheme item
      {
        title: 'pension_fund_schme_item',
        path: routes.pensionFundSchemeItem,
        permission: 'Entity_PensionFundSchemeItem_View',
        onClick: () => {},
        key: crypto.randomUUID(),
        event: () => {
          navigate(routes.pensionFundSchemeItem)
        },
        active: false,
      },
      // entity work calender
      {
        title: 'ent_work_calendar_title',
        path: routes.workCalender,
        permission: 'Entity_WorkCalendar_View',
        onClick: () => {},
        key: crypto.randomUUID(),
        event: () => {
          navigate(routes.workCalender)
        },
        active: false,
      },
      // employee movement type
      {
        title: 'ent_emp_move_type_title',
        path: routes.employeeMovement,
        permission: 'Entity_EmployeeMovementType_View',
        onClick: () => {},
        key: crypto.randomUUID(),
        event: () => {
          navigate(routes.employeeMovement)
        },
        active: false,
      },
      // employee moevement configuartion
      {
        title: 'ent_emp_movement_configuration_title',
        path: routes.employeeMovementConfiguration,
        permission: 'PensionFundSchemeRule_View',
        onClick: () => {},
        key: crypto.randomUUID(),
        event: () => {
          navigate(routes.employeeMovementConfiguration)
        },
        active: false,
      },
      // Formula Setup
      {
        title: 'Formula Setup',
        path: routes.standardFormulation,
        permission: 'Entity_EntityProfile_Create',
        onClick: () => {},
        key: crypto.randomUUID(),
        event: () => {
          navigate(routes.standardFormulation)
        },
        active: false,
      },
      // Formula Expression
      {
        title: 'Formula Expression',
        path: routes.formulaExpressionListing,
        permission: 'Entity_EntityProfile_Create',
        onClick: () => {},
        key: crypto.randomUUID(),
        event: () => {
          navigate(routes.formulaExpressionListing)
        },
        active: false,
      },

    ],
  },
  {
    title: 'Notification',
    icon: <NotificationsIcon />,
    path: routes.emailProfile,
    permission: 'Notification_EmailProfile_View',
    onClick: () => {},
    key: crypto.randomUUID(),
    event: () => {
      navigate(routes.emailProfile)
    },
    active: false,
    subTitle: 'Notification',
    children: [
      {
        title: 'Send email notification',
        path: routes.sendEmail,
        permission: 'Notification_SendEmailNotification_View',
        onClick: () => {},
        key: crypto.randomUUID(),
        event: () => {
          navigate(routes.sendEmail)
        },
        active: false,
        subTitle: 'Notification Setup',

      },
      // email template
      {
        title: 'Email templates',
        path: routes.emailTemplate,
        permission: 'Notification_EmailTemplate_View',
        onClick: () => {},
        key: crypto.randomUUID(),
        event: () => {
          navigate(routes.emailTemplate)
        },
        active: false,
      },
      {
        title: 'Email profiles',
        path: routes.emailProfile,
        permission: 'Notification_EmailProfile_View',
        onClick: () => {},
        key: crypto.randomUUID(),
        event: () => {
          navigate(routes.emailProfile)
        },
        active: false,
      },

    ],
  },

  // Data upload
  {
    title: 'data_upload_menu_title',
    icon: <CloudUploadOutlinedIcon />,
    path: routes.dataUpload,
    permission: 'Integration_Integration_View',
    onClick: () => {},
    key: crypto.randomUUID(),
    event: () => {
      navigate(routes.home)
    },
    active: false,
    subTitle: 'Bulk actions',
    children: [
      {
        title: 'Data upload (Add/Edit/Delete)',
        path: routes.dataUpload,
        permission: 'Integration_Integration_View',
        onClick: () => {},
        key: crypto.randomUUID(),
        event: () => {
          navigate(routes.dataUpload)
        },
        active: false,
      },
      {
        title: 'Delete non-recurring items',
        path: routes.deleteNonRecurringItem,
        permission: 'Payroll_PayrollNonRecurringItems_BulkDelete',
        onClick: () => {},
        key: crypto.randomUUID(),
        event: () => {
          navigate(routes.deleteNonRecurringItem)
        },
        active: false,
      },
      {
        title: 'Delete payroll history',
        path: routes.payrollHistory,
        permission: 'Payroll_PayrollHistoryUpload_View',
        onClick: () => {},
        key: crypto.randomUUID(),
        event: () => {
          navigate(routes.payrollHistory)
        },
        active: false,
      },

    ],
  },
]
