import OPROuterLayout from 'components/molecules/OPROuterLayout'
import * as React from 'react'
import { Suspense } from 'react'
import { useSelector } from 'react-redux'
import { Route, Routes } from 'react-router-dom'
import ProtectedRoute from 'services/protectedRoutes'
import { activePermissions } from 'slices/permissionSlice'
import { RouteCompMapping } from 'types/routeCompMapping'

function Router(props: { children?: React.ReactNode }) {
  const { children } = props
  // eslint-disable-next-line react/jsx-no-useless-fragment
  return <>{children}</>
}

export default function OPRRouter({ routes }: { routes: RouteCompMapping[] }) {
  const permissionList = useSelector(activePermissions)
  return (
    <Router>
      <Suspense fallback={<div>Loading...</div>}>
        <Routes>
          {
            routes && routes.filter((route) => {
              const { permission } = route
              return permission ? permissionList.includes(permission) : false
            })
              .map((route:any) => (
                <Route
                  key={route.key}
                  element={(
                    <ProtectedRoute
                      permission={route.permission ? route.permission : 'defaultPermission'}
                      redirectPath="/"
                    >
                      <route.component />
                    </ProtectedRoute>
                  )}
                  path={route.path}
                />
              ))
          }
        </Routes>
      </Suspense>
      <OPROuterLayout />
    </Router>
  )
}

/**
 * /entity/ird --- IRD page where all details will be shown
 * /entity/ird/:entityId/:irdId -- View selected record
 * /entity/ird/:entityId/:irdId/edit -- Edit selected record
 * /entity/ird/:entityId/new -- Add new record
 */
