export const routes = {
  landingPage: '/',
  login: '/login',
  loginCallback: '/login/callback',
  home: '/home',
  client: '/client',
  employee: 'employee',
  person: 'employee/person',
  entities: 'entity',
  payroll: 'payroll',
  global: 'global',
  dashboard: 'dashboard',
  irdIndex: 'entities/ird',
  irdEdit: '/ird/:entityId/:code/edit',
  irdNew: 'ird/:entityId/new',
  irdView: 'ird/:entityId/:code/view',
  departmentIndex: 'entities/department',
  departmentEdit: '/department/:entityId/:code/edit',
  departmentNew: 'department/:entityId/new',
  departmentView: 'department/:entityId/:code/view',
  sampleAlert: 'sampleAlert',
  country: 'global/country',

  editCountry: '/global/country/:id/edit',
  viewCountry: '/global/country/:id/view',
  createCountry: '/global/country/create',
  // entity division start
  editDivision: '/entity/division/:id/edit',
  createDivision: '/entity/division/create',
  division: 'entity/division',
  viewDivision: '/entity/division/:id/view',
  // company bank account
  editCompanyBankAccount: '/entity/companyBankAccount/:id/edit',
  createCompanyBankAccount: '/entity/companyBankAccount/create',
  companyBankAccount: 'entity/companyBankAccount',
  viewCompanyBankAccount: '/entity/companyBankAccount/:id/view',
  // deleteCompanyBankAccount: '/entity/companyBankAccount
  // entity division end
  currency: 'global/currency',
  userAccounts: 'usermanagement/useraccounts',
  createUserAccounts: '/global/useraccounts/create',
  viewUserAccounts: '/global/useraccounts/:id/view',
  editUserAccounts: '/global/useraccounts/:id/edit',
  // global currency
  createCurrency: '/global/currency/create',
  editCurrency: '/global/currency/:id/edit',
  viewCurrency: '/global/currency/:id/view',

  // global nationality
  nationality: 'global/nationality',
  createNationality: '/global/nationality/create',
  editNationality: '/global/nationality/:id/edit',
  viewNationality: '/global/nationality/:id/view',

  providertype: 'global/providertype',
  viewProviderType: '/global/providertype/:id/view',
  // payment method
  paymentmethod: 'global/paymentmethod',
  editPaymentMethod: '/global/paymentmethod/:id/edit',
  viewPaymentMethod: '/global/paymentmethod/:id/view',
  settingtemplate: 'global/settingtemplate',
  editSettingTemplate: '/global/settingtemplate/:id/edit',
  viewSettingTemplate: '/global/settingtemplate/:id/view',
  // createNationality: '/global/nationality/create',
  createProviderType: '/global/providertype/create',
  createPaymentMethod: '/global/paymentmethod/create',
  editProviderType: '/global/providertype/:id/edit',
  createSettingTemplate: '/global/settingtemplate/create',
  restOfRoutes: '*',
  // holiday calender

  holidayCalender: 'global/holidaycalender',
  editHolidayCalender: '/global/holidaycalender/:id/edit',
  viewHolidayCalender: '/global/holidaycalender/:id/view',
  createHolidayCalender: '/global/holidaycalender/create',

  // global pension fund
  globalPensionFundSchemeRuleList: 'global/pensionFundSchemeRule',
  editGlobalPensionFundSchemeRule: '/global/pensionFundSchemeRule/:id/edit',
  viewGlobalPensionFundSchemeRule: '/global/pensionFundSchemeRule/:id/view',
  createGlobalPensionFundSchemeRule: '/global/pensionFundSchemeRule/create',

  // standard
  standardExpression: 'global/standardExpression',
  standardFormula: 'global/standardFormula',
  formulaSetupListing: 'global/formula-setup',
  createFormulaSetup: '/global/formula-setup/create',
  viewFormulaSetup: '/global/formula-setup/:id/view',
  editFormulaSetup: '/global/formula-setup/:id/edit',

  // expression
  formulaExpressionListing: 'entity/formula-expression',
  createFormulaExpression: '/entity/formula-expression/create',
  viewFormulaExpression: '/entity/formula-expression/:id/view',
  editFormulaExpression: '/entity/formula-expression/:id/edit',
  // User Roles
  userRolesListing: 'identity/user-roles',
  createUserRole: '/identity/user-roles/create',
  viewUserRole: '/identity/user-roles/:id/view',
  editUserRole: '/identity/user-roles/:id/edit',

  // Entity ird
  ird: 'entity/ird',
  editIrd: '/entity/IRDCorporateTitle/:id/edit',
  createIrd: '/entity/IRDCorporateTitle',
  viewIrd: '/entity/IRDCorporateTitle/:id/view',

  // Entity department
  department: 'entity/department',
  editDepartment: '/entity/Department/:id/edit',
  createDepartment: '/entity/Department/create',
  viewDepartment: '/entity/Department/:id/view',

  // Enity Cost center
  editCostCenter: '/entity/costcenter/:id/edit',
  createCostCenter: '/entity/costcenter/create',
  costCenter: 'entity/costcenter',
  viewCostCenter: '/entity/costcenter/:id/view',

  // Employee Password
  employeePassword: 'employee/employeePassword',
  viewEmployeePassword: '/employee/employeePassword/:id/view',
  createEmployeePassword: '/employee/employeePassword/create',
  editEmployeePassword: '/employee/employeePassword/:id/edit',

  // Entity Region
  region: 'entity/region',
  editRegion: '/entity/region/:id/edit',
  createRegion: '/entity/region/create',
  viewRegion: '/entity/region/:id/view',

  // Entity Team
  team: 'entity/team',
  editTeam: '/entity/team/:id/edit',
  createTeam: '/entity/team/create',
  viewTeam: '/entity/team/:id/view',

  // Entity grade
  grade: 'entity/grade',
  editGrade: '/entity/grade/:id/edit',
  createGrade: '/entity/grade/create',
  viewGrade: '/entity/grade/:id/view',

  // entity position
  position: 'entity/position',
  editPosition: '/entity/Position/:id/edit',
  createPosition: '/entity/Position/create',
  viewPosition: '/entity/Position/:id/view',

  // stafftype
  staffType: 'entity/staffType',
  editStaffType: '/entity/staffType/:id/edit',
  createStaffType: '/entity/staffType/create',
  viewStaffType: '/entity/staffType/:id/view',

  // termination code
  terminationCode: 'entity/terminationcode',
  editTerminationCode: '/entity/TerminationCode/:id/edit',
  createTerminationCode: '/entity/TerminationCode/create',
  viewTerminationCode: '/entity/TerminationCode/:id/view',

  // client Group code
  clientGroupProfile: 'client/clientGroupProfile',
  editClientGroupProfile: '/client/clientGroupProfile/:id/edit',
  createClientGroupProfile: '/client/clientGroupProfile/create',
  viewClientGroupProfile: '/client/clientGroupProfile/:id/view',

  // client Group code
  clientGroupEntities: 'client/clientGroupProfile/:id/clientGroupEntities/',
  editClientGroupEntities: '/client/clientGroupProfile/:id/clientGroupEntities/:profilId/view',
  createClientGroupEntities: '/client/clientGroupProfile/:id/clientGroupEntities/create',
  viewClientGroupEntities: '/client/clientGroupProfile/:id/clientGroupEntities/:profilId/view',
  // pay item group
  // entity service provider
  serviceProvider: 'entity/serviceProvider',
  editServiceProvider: '/entity/serviceProvider/:id/edit',
  createServiceProvider: '/entity/serviceProvider/create',
  viewServiceProvider: '/entity/serviceProvider/:id/view',

  // entity settings
  settings: 'entity/settings',
  editSettings: '/entity/settings/:id/edit',
  createSettings: '/entity/settings/create',
  viewSettings: '/entity/settings/:id/view',

  // pay item group
  payItemGroup: 'payroll/payitemgroup',
  editPayItemGroup: '/payroll/payitemgroup/:id/edit',
  viewPayItemGroup: '/payroll/payitemgroup/:id/view',
  createPayItemGroup: '/payroll/payitemgroup/create',

  // pay group
  payGroup: 'payroll/paygroup',
  editPayGroup: '/payroll/paygroup/:id/edit',
  viewPayGroup: '/payroll/paygroup/:id/view',
  createPayGroup: '/payroll/paygroup/create',

  // currency Exchange Rate
  currencyExchange: 'entity/currencyExchange',
  editCurrencyExchange: '/entity/currencyExchange/:id/edit',
  viewCurrencyExchange: '/entity/currencyExchange/:id/view',
  createCurrencyExchange: '/entity/currencyExchange/create',

  iframe: '/iframe',

  // employee movement Type
  employeeMovement: 'entity/employeeMovementType',
  editemployeeMovement: '/entity/employeeMovementType/:id/edit',
  viewemployeeMovement: '/entity/employeeMovementType/:id/view',
  createemployeeMovement: '/entity/employeeMovementType/create',

  // entity pension fund scheme item
  pensionFundSchemeItem: 'entity/pensionFundSchemeItem',
  editPensionFundSchemeItem: '/entity/pensionFundSchemeItem/:id/edit',
  viewPensionFundSchemeItem: '/entity/pensionFundSchemeItem/:id/view',
  createPensionFundSchemeItem: '/entity/pensionFundSchemeItem/create',

  // employee Profile item
  employeeProfile: 'employee/employeeProfile',
  editEmployeeProfile: '/employee/employeeProfile/:id/edit',
  viewEmployeeProfile: '/employee/employeeProfile/:id/view',
  createEmployeeProfile: '/employee/employeeProfile/create',
  editEmployeeProfileDetalis: '/employee/profile/employeeProfile/:id/edit',
  // work calender

  workCalender: 'entity/workcalender',
  editWorkCalender: '/entity/workcalender/:id/edit',
  viewWorkCalender: '/entity/workcalender/:id/view',
  createWorkCalender: '/entity/workcalender/create',

  // entity profile

  entityProfile: 'entity/entityprofile',
  editEntityProfile: '/entity/entityprofile/:id/edit',
  viewEntityProfile: '/entity/entityprofile/:id/view',
  createEntityProfile: '/entity/entityprofile/create',

  // Employee movement configuration

  employeeMovementConfiguration: 'entity/employeemovementconfiguration',
  editEmployeeMovementConfiguration: '/entity/employeemovementconfiguration/:id/edit',
  viewEmployeeMovementConfiguration: '/entity/employeemovementconfiguration/:id/view',
  createEmployeeMovementConfiguration: '/entity/employeemovementconfiguration/create',

  // entity pension fund scheme rule
  pensionFundSchemeRule: 'entity/pensionFundSchemeRule',
  editPensionFundSchemeRule: '/entity/pensionFundSchemeRule/:id/edit',
  viewPensionFundSchemeRule: '/entity/pensionFundSchemeRule/:id/view',
  createPensionFundSchemeRule: '/entity/pensionFundSchemeRule/create',
  // entity pension fund scheme
  pensionFundScheme: 'entity/pensionFundScheme',
  editPensionFundScheme: '/entity/pensionFundScheme/:id/edit',
  viewPensionFundScheme: '/entity/pensionFundScheme/:id/view',
  createPensionFundScheme: '/entity/pensionFundScheme/create',
  // pay item master
  payItemMaster: 'payroll/payItemMaster',
  editPayItemMaster: '/payroll/payItemMaster/:id/edit',
  viewPayItemMaster: '/payroll/payItemMaster/:id/view',
  createPayItemMaster: '/payroll/payItemMaster/create',

  // payroll non recurring
  payRollNonRecurring: 'payroll/payrollnonrecurring',
  editPayRollNonRecurring: '/payroll/payrollnonrecurring/:id/edit',
  viewPayRollNonRecurring: '/payroll/payrollnonrecurring/:id/view',
  createPayRollNonRecurring: '/payroll/payrollnonrecurring/create',

  // pay cycle administration
  payCycleAdministration: 'payroll/payCycleAdministration',
  editPayCycleAdministration: '/payroll/payCycleAdministration/:id/edit',
  viewPayCycleAdministration: '/payroll/payCycleAdministration/:id/view',
  createPayCycleAdministration: '/payroll/payCycleAdministration/create',
  // Report Designer custom report
  reportDesignerCustomReport: 'reportdesigner/customreport',
  editReportDesignerCustomReport: '/reportdesigner/customreport/:id/edit',
  viewReportDesignerCustomReport: '/reportdesigner/customreport/:id/view',
  createReportDesignerCustomReport: '/reportdesigner/customreport/create',

  // payroll month closing
  payRollMonthClosing: 'payroll/payrollmonthclosing',
  editPayRollMonthClosing: '/payroll/payrollmonthclosing/:id/edit',
  viewPayRollMonthClosing: '/payroll/payrollmonthclosing/:id/view',
  createPayRollMonthClosing: '/payroll/payrollmonthclosing/create',

  // pay cycle reassignment
  payCycleReassignment: 'payroll/payCycleReassigment',

  dataUpload: 'uploadData',
  createDataUpload: '/uploadData/create',

  // run Payroll process
  runPayroll: 'payroll/runPayroll',
  editRunPayroll: '/payroll/runPayroll/:id/edit',
  viewRunPayroll: '/payroll/runPayroll/:id/view',
  createRunPayroll: '/payroll/runPayroll/create',
  // payment summary report
  paymentSummary: 'report/paymentSummaryReport',
  editPaymentSummary: '/report/paymentSummaryReport/:id/edit',
  viewPaymentSummary: '/report/paymentSummaryReport/:id/view',
  createPaymentSummary: '/report/paymentSummaryReport/create',

  // Standard Formulation
  standardFormulation: 'entity/standardFormulation',
  editStandardFormulation: '/entity/standardFormulation/:id/edit',
  viewStandardFormulation: '/entity/standardFormulation/:id/view',
  createStandardFormulation: '/entity/standardFormulation/create',

  // Standard Report
  standardReports: 'report/standard',
  standardReportsGenerate: 'report/standard/:id/create',
  standardReportsGenerateView: 'report/standard/:id/edit',

  // Annual compensation reports
  annualCompensationReport: 'report/annualCompensation',
  annualCompensationReportCreate: 'report/annualCompensation/:id/create',
  annualCompensationReportView: 'report/annualCompensation/:id/view',
  // generate Payroll Slip
  payrollSlip: 'report/payrollSlip',
  editPayrollSlip: '/report/payrollSlip/:id/edit',
  viewPayrollSlip: '/report/payrollSlip/:id/view',
  createPayrollSlip: '/report/payrollSlip/create',

  // notification
  emailProfile: '/notification/emailProfile',
  createEmailProfile: '/notification/emailProfile/create',
  editEmailProfile: '/notification/emailProfile/:id/edit',
  viewEmailProfile: '/notification/emailProfile/:id/view',

  sendEmail: '/notification/sendEmail',
  createSendEmail: '/notification/sendEmail/create',
  createSendPaySlip: '/notification/sendPaySlip/create',
  // pension fund termination code
  pensionFundTermination: 'global/pensionFundTermination',
  createPensionFundTermination: '/global/pensionFundTermination/create',
  editPensionFundTermination: '/global/pensionFundTermination/:id/edit',
  viewPensionFundTermination: '/global/pensionFundTermination/:id/view',

  // audit Trail
  auditTrail: '/auditTrail',
  viewAuditTrail: '/auditTrail/:id/view',
  createAuditTrail: '/auditTrail/create',
  // docutax pro
  docutaxPro: 'global/docutaxPro',
  createDocutaxPro: '/global/docutaxPro/create',
  editDocutaxPro: '/global/docutaxPro/:id/edit',
  viewDocutaxPro: '/global/docutaxPro/:id/view',

  //  Delete non Recurring Item
  deleteNonRecurringItem: 'payroll/deleteNonRecurringItem',
  createDeleteNonRecurringItem: '/payroll/deleteNonRecurringItem/create',
  editDeleteNonRecurringItem: '/payroll/deleteNonRecurringItem/:id/edit',
  viewDeleteNonRecurringItem: '/payroll/deleteNonRecurringItem/:id/view',

  // publish report
  publishReport: '/report/publishReport',
  viewpublishReport: '/report/publishReport/:id/view',
  createpublishReport: '/report/publishReport/create',
  // payroll history
  payrollHistory: 'bulkaction/payrollHistory',
  viewPayrollHistory: '/bulkaction/payrollHistory/:id/view',

  // email template
  emailTemplate: '/notification/emailTemplate',
  createEmailTemplate: '/notification/emailTemplate/create',
  viewEmailTemplate: '/notification/emailTemplate/:id/view',
  editEmailTemplate: '/notification/emailTemplate/:id/edit',
  // report review
  reviewReport: 'report/reviewReport',
  // employee leave transaction
  employeeLeaveTransaction: 'employee/employeeLeaveTransaction',
  createEmployeeLeaveTransaction: '/employee/employeeLeaveTransaction/create',
  viewEmployeeLeaveTransaction: '/employee/employeeLeaveTransaction/:id/view',
  editEmployeeLeaveTransaction: '/employee/employeeLeaveTransaction/:id/edit',

  // Empoyee Remark

  employeeRemark: '/employee/employeeRemark',
  viewEmployeeRemark: '/employee/employeeRemark/:id/view',
  createEmployeeRemark: '/employee/employeeRemark/create',
  editEmployeeRemark: '/employee/employeeRemark/:id/edit',

}
