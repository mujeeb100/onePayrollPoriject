import { lazy } from 'react'
import { RouteCompMapping } from 'types/routeCompMapping'

import { routes } from './routes'

export const routesWithComponents = (): RouteCompMapping[] => [
  {
    path: routes.dashboard,
    permission: 'Country_Create',
    component: lazy(() => import('pages/dashboard/index')),
  },
  {
    path: routes.home,
    permission: 'Country_Create',
    component: lazy(() => import('pages/dashboard/index')),
  },
  {
    path: routes.irdIndex,
    permission: 'Entity_IRDCorporateTitle_View',
    component: lazy(() => import('pages/entity/ird')),
  },
  {
    path: routes.irdEdit,
    permission: 'Entity_IRDCorporateTitle_Update',
    component: lazy(() => import('pages/entity/ird/IRDForm')),
  },
  {
    path: routes.irdView,
    permission: 'Entity_IRDCorporateTitle_View',
    component: lazy(() => import('pages/entity/ird/IRDForm')),
  },
  {
    path: routes.irdNew,
    permission: 'Entity_IRDCorporateTitle_View',
    component: lazy(() => import('pages/entity/ird/IRDForm')),
  },
  {
    path: routes.departmentIndex,
    permission: 'Entity_Department_View',
    component: lazy(() => import('pages/entity/department')),
  },
  {
    path: routes.departmentEdit,
    permission: 'Entity_Department_Update',
    component: lazy(() => import('pages/entity/department/DepartmentForm')),
  },
  {
    path: routes.departmentView,
    permission: 'Entity_Department_View',
    component: lazy(() => import('pages/entity/department/DepartmentForm')),
  },
  {
    path: routes.departmentNew,
    permission: 'Entity_Department_View',
    component: lazy(() => import('pages/entity/department/DepartmentForm')),
  },
  {
    path: routes.dataUpload,
    permission: 'Integration_Integration_View',
    component: lazy(() => import('pages/uploadData/index')),
  },
  {
    path: routes.createDataUpload,
    permission: 'Integration_Integration_Create',
    component: lazy(() => import('pages/uploadData/UploadDataForm')),
  },
  {
    path: routes.userRolesListing,
    permission: 'UserRole_View',
    component: lazy(() => import('pages/userRoles/index')),
  },
  {
    path: routes.viewUserRole,
    permission: 'UserRole_View',
    component: lazy(() => import('pages/userRoles/UserRolesForm')),
  },
  {
    path: routes.editUserRole,
    permission: 'UserRole_Update',
    component: lazy(() => import('pages/userRoles/UserRolesForm')),
  },
  {
    path: routes.createUserRole,
    permission: 'UserRole_Create',
    component: lazy(() => import('pages/userRoles/UserRolesForm')),
  },
  {
    path: routes.restOfRoutes,
    permission: 'restOfRoutes',
    component: lazy(() => import('pages/error/ErrorPage404')),
  },
  {
    path: routes.person,
    permission: 'Person_View',
    component: lazy(() => import('pages/employee/person/index')),
  },
  {
    path: routes.country,
    permission: 'Country_View',
    component: lazy(() => import('pages/global/country/index')),
  },
  {
    path: routes.viewCountry,
    permission: 'Country_View',
    component: lazy(() => import('pages/global/country/CountryForm')),
  },
  {
    path: routes.editCountry,
    permission: 'Country_Update',
    component: lazy(() => import('pages/global/country/CountryForm')),
  },
  {
    path: routes.createCountry,
    permission: 'Country_Create',
    component: lazy(() => import('pages/global/country/CountryForm')),
  },
  // currency view
  {
    path: routes.currency,
    permission: 'Currency_View',
    component: lazy(() => import('pages/global/currency/index')),
  },

  {
    path: routes.createCurrency,
    permission: 'Currency_Create',
    component: lazy(() => import('pages/global/currency/CurrencyForm')),
  },
  {
    path: routes.editCurrency,
    permission: 'Currency_Update',
    component: lazy(() => import('pages/global/currency/CurrencyForm')),
  },
  {
    path: routes.viewCurrency,
    permission: 'Currency_View',
    component: lazy(() => import('pages/global/currency/CurrencyForm')),
  },
  // global Nationality view
  {
    path: routes.nationality,
    permission: 'Nationality_View',
    component: lazy(() => import('pages/global/nationality/index')),
  },
  {
    path: routes.createNationality,
    permission: 'Nationality_Create',
    component: lazy(() => import('pages/global/nationality/NationalityForm')),
  },
  {
    path: routes.editNationality,
    permission: 'Nationality_Update',
    component: lazy(() => import('pages/global/nationality/NationalityForm')),
  },
  {
    path: routes.viewNationality,
    permission: 'Nationality_View',
    component: lazy(() => import('pages/global/nationality/NationalityForm')),
  },

  // global ProviderType view
  {
    path: routes.providertype,
    permission: 'ProviderType_View',
    component: lazy(() => import('pages/global/providerType/index')),
  },
  {
    path: routes.createProviderType,
    permission: 'ProviderType_Create',
    component: lazy(() => import('pages/global/providerType/ProviderTypeForm')),
  },
  {
    path: routes.editProviderType,
    permission: 'ProviderType_Update',
    component: lazy(() => import('pages/global/providerType/ProviderTypeForm')),
  },
  {
    path: routes.viewProviderType,
    permission: 'ProviderType_View',
    component: lazy(() => import('pages/global/providerType/ProviderTypeForm')),
  },

  // global PaymentMethod view
  {
    path: routes.paymentmethod,
    permission: 'PaymentMethod_View',
    component: lazy(() => import('pages/global/paymentMethod/index')),
  },
  {
    path: routes.createPaymentMethod,
    permission: 'PaymentMethod_Create',
    component: lazy(
      () => import('pages/global/paymentMethod/PaymentMethodForm'),
    ),
  },
  {
    path: routes.editPaymentMethod,
    permission: 'PaymentMethod_Update',
    component: lazy(
      () => import('pages/global/paymentMethod/PaymentMethodForm'),
    ),
  },
  {
    path: routes.viewPaymentMethod,
    permission: 'PaymentMethod_View',
    component: lazy(
      () => import('pages/global/paymentMethod/PaymentMethodForm'),
    ),
  },

  // global SettingTemplate view
  {
    path: routes.settingtemplate,
    permission: 'SettingTemplate_View',
    component: lazy(() => import('pages/global/settingTemplate/index')),
  },
  {
    path: routes.viewSettingTemplate,
    permission: 'SettingTemplate_View',
    component: lazy(
      () => import('pages/global/settingTemplate/SettingTemplateForm'),
    ),
  },
  {
    path: routes.editSettingTemplate,
    permission: 'SettingTemplate_Update',
    component: lazy(
      () => import('pages/global/settingTemplate/SettingTemplateForm'),
    ),
  },
  {
    path: routes.createSettingTemplate,
    permission: 'SettingTemplate_View',
    component: lazy(
      () => import('pages/global/settingTemplate/SettingTemplateForm'),
    ),
  },
  {
    path: routes.userAccounts,
    permission: 'UserAdministration_View',
    component: lazy(() => import('pages/usermanagement/useraccounts/index')),
  },
  {
    path: routes.createUserAccounts,
    permission: 'UserAdministration_Create',
    component: lazy(
      () => import('pages/usermanagement/useraccounts/userAccountsForm'),
    ),
  },
  {
    path: routes.viewUserAccounts,
    permission: 'UserAdministration_View',
    component: lazy(() => import('pages/usermanagement/useraccounts/viewUserAccount')),
  },
  {
    path: routes.editUserAccounts,
    permission: 'UserAdministration_Update',
    component: lazy(
      () => import('pages/usermanagement/useraccounts/userAccountsForm'),
    ),
  },
  {
    path: routes.createSettingTemplate,
    permission: 'SettingTemplate_View',
    component: lazy(
      () => import('pages/global/settingTemplate/SettingTemplateForm'),
    ),
  },
  {
    path: routes.editSettingTemplate,
    permission: 'SettingTemplate_Update',
    component: lazy(
      () => import('pages/global/settingTemplate/SettingTemplateForm'),
    ),
  },
  // global HolidayCalender view
  {
    path: routes.holidayCalender,
    permission: 'HolidayCalendar_View',
    component: lazy(() => import('pages/global/holidayCalender/index')),
  },
  {
    path: routes.viewHolidayCalender,
    permission: 'HolidayCalendar_View',
    component: lazy(
      () => import('pages/global/holidayCalender/HolidayCalenderForm'),
    ),
  },
  {
    path: routes.editHolidayCalender,
    permission: 'HolidayCalendar_Create',
    component: lazy(
      () => import('pages/global/holidayCalender/HolidayCalenderForm'),
    ),
  },
  {
    path: routes.createHolidayCalender,
    permission: 'HolidayCalendar_Create',
    component: lazy(
      () => import('pages/global/holidayCalender/HolidayCalenderForm'),
    ),
  },

  // pension fund
  {
    path: routes.globalPensionFundSchemeRuleList,
    permission: 'PensionFundSchemeRule_View',
    component: lazy(() => import('pages/global/pensionFund/index')),
  },
  {
    path: routes.viewGlobalPensionFundSchemeRule,
    permission: 'PensionFundSchemeRule_View',
    component: lazy(() => import('pages/global/pensionFund/PensionFundForm')),
  },
  {
    path: routes.editGlobalPensionFundSchemeRule,
    permission: 'PensionFundSchemeRule_Create',
    component: lazy(() => import('pages/global/pensionFund/PensionFundForm')),
  },
  {
    path: routes.createGlobalPensionFundSchemeRule,
    permission: 'PensionFundSchemeRule_Create',
    component: lazy(() => import('pages/global/pensionFund/PensionFundForm')),
  },
  // standard formula Expression
  {
    path: routes.formulaExpressionListing,
    permission: 'Payroll_CustomFormula_View',
    component: lazy(() => import('pages/entity/formulaExpression/index')),
  },
  {
    path: routes.createFormulaExpression,
    permission: 'Payroll_CustomFormula_Create',
    component: lazy(() => import('pages/entity/formulaExpression/FormulaExpressionForm')),
  },
  {
    path: routes.viewFormulaExpression,
    permission: 'Payroll_CustomExpression_View',
    component: lazy(() => import('pages/entity/formulaExpression/FormulaExpressionForm')),
  },

  {
    path: routes.editFormulaExpression,
    permission: 'Payroll_CustomFormula_Create',
    component: lazy(() => import('pages/entity/formulaExpression/FormulaExpressionForm')),
  },

  // standard formula
  {
    path: routes.formulaSetupListing,
    permission: 'Payroll_CustomFormula_View',
    component: lazy(() => import('pages/entity/standardFormula/index')),
  },
  {
    path: routes.createFormulaSetup,
    permission: 'Payroll_CustomFormula_Create',
    component: lazy(() => import('pages/entity/standardFormula/StandardFormulaForm')),
  },
  {
    path: routes.viewFormulaSetup,
    permission: 'Payroll_CustomFormula_View',
    component: lazy(() => import('pages/entity/standardFormula/StandardFormulaForm')),
  },

  // Entity Cost Center
  {
    path: routes.costCenter,
    permission: 'Entity_CostCenter_View',
    component: lazy(() => import('pages/entity/costCenter/index')),
  },
  {
    path: routes.createCostCenter,
    permission: 'Entity_CostCenter_Create',
    component: lazy(() => import('pages/entity/costCenter/CostCenterForm')),
  },
  {
    path: routes.editCostCenter,
    permission: 'Entity_CostCenter_Update',
    component: lazy(() => import('pages/entity/costCenter/CostCenterForm')),
  },
  {
    path: routes.viewCostCenter,
    permission: 'Entity_CostCenter_View',
    component: lazy(() => import('pages/entity/costCenter/CostCenterForm')),
  },
  // Entity Division
  {
    path: routes.division,
    permission: 'Entity_Division_View',
    component: lazy(() => import('pages/entity/division/index')),
  },
  {
    path: routes.createDivision,
    permission: 'Entity_Division_Create',
    component: lazy(() => import('pages/entity/division/DivisionForm')),
  },
  {
    path: routes.editDivision,
    permission: 'Entity_Division_Update',
    component: lazy(() => import('pages/entity/division/DivisionForm')),
  },
  {
    path: routes.viewDivision,
    permission: 'Entity_Division_View',
    component: lazy(() => import('pages/entity/division/DivisionForm')),
  },
  // Entity Region
  {
    path: routes.region,
    permission: 'Entity_Region_View',
    component: lazy(() => import('pages/entity/region/index')),
  },
  {
    path: routes.createRegion,
    permission: 'Entity_Region_Create',
    component: lazy(() => import('pages/entity/region/RegionForm')),
  },
  {
    path: routes.editRegion,
    permission: 'Entity_Region_Update',
    component: lazy(() => import('pages/entity/region/RegionForm')),
  },
  {
    path: routes.viewRegion,
    permission: 'Entity_Region_View',
    component: lazy(() => import('pages/entity/region/RegionForm')),
  },
  // Entity Team
  {
    path: routes.team,
    permission: 'Entity_Team_View',
    component: lazy(() => import('pages/entity/team/index')),
  },
  {
    path: routes.createTeam,
    permission: 'Entity_Team_Create',
    component: lazy(() => import('pages/entity/team/TeamForm')),
  },
  {
    path: routes.editTeam,
    permission: 'Entity_Team_Update',
    component: lazy(() => import('pages/entity/team/TeamForm')),
  },
  {
    path: routes.viewTeam,
    permission: 'Entity_Team_View',
    component: lazy(() => import('pages/entity/team/TeamForm')),
  },
  // Entity Ird
  {
    path: routes.ird,
    permission: 'Entity_IRDCorporateTitle_View',
    component: lazy(() => import('pages/entity/ird/index')),
  },
  {
    path: routes.createIrd,
    permission: 'Entity_IRDCorporateTitle_Create',
    component: lazy(() => import('pages/entity/ird/IRDForm')),
  },
  {
    path: routes.editIrd,
    permission: 'Entity_IRDCorporateTitle_Update',
    component: lazy(() => import('pages/entity/ird/IRDForm')),
  },
  {
    path: routes.viewIrd,
    permission: 'Entity_IRDCorporateTitle_View',
    component: lazy(() => import('pages/entity/ird/IRDForm')),
  },
  // Entity Department
  {
    path: routes.department,
    permission: 'Entity_Department_View',
    component: lazy(() => import('pages/entity/department/index')),
  },
  {
    path: routes.createDepartment,
    permission: 'Entity_Department_Create',
    component: lazy(() => import('pages/entity/department/DepartmentForm')),
  },
  {
    path: routes.editDepartment,
    permission: 'Entity_Department_Update',
    component: lazy(() => import('pages/entity/department/DepartmentForm')),
  },
  {
    path: routes.viewDepartment,
    permission: 'Entity_Department_View',
    component: lazy(() => import('pages/entity/department/DepartmentForm')),
  },
  // Entity Position
  {
    path: routes.position,
    permission: 'Entity_Position_View',
    component: lazy(() => import('pages/entity/position/index')),
  },
  {
    path: routes.createPosition,
    permission: 'Entity_Position_Create',
    component: lazy(() => import('pages/entity/position/PositionForm')),
  },
  {
    path: routes.editPosition,
    permission: 'Entity_Position_Update',
    component: lazy(() => import('pages/entity/position/PositionForm')),
  },
  {
    path: routes.viewPosition,
    permission: 'Entity_Position_View',
    component: lazy(() => import('pages/entity/position/PositionForm')),
  },
  // Entity Grade
  {
    path: routes.grade,
    permission: 'Entity_Grade_View',
    component: lazy(() => import('pages/entity/grade/index')),
  },
  {
    path: routes.createGrade,
    permission: 'Entity_Grade_Create',
    component: lazy(() => import('pages/entity/grade/GradeForm')),
  },
  {
    path: routes.editGrade,
    permission: 'Entity_Grade_Update',
    component: lazy(() => import('pages/entity/grade/GradeForm')),
  },
  {
    path: routes.viewGrade,
    permission: 'Entity_Grade_View',
    component: lazy(() => import('pages/entity/grade/GradeForm')),
  },
  // Entity StaffType
  {
    path: routes.staffType,
    permission: 'Entity_StaffType_View',
    component: lazy(() => import('pages/entity/staffType/index')),
  },
  {
    path: routes.createStaffType,
    permission: 'Entity_StaffType_Create',
    component: lazy(() => import('pages/entity/staffType/StaffTypeForm')),
  },
  {
    path: routes.editStaffType,
    permission: 'Entity_StaffType_Update',
    component: lazy(() => import('pages/entity/staffType/StaffTypeForm')),
  },
  {
    path: routes.viewStaffType,
    permission: 'Entity_StaffType_View',
    component: lazy(() => import('pages/entity/staffType/StaffTypeForm')),
  },
  // Entity TerminationCode
  {
    path: routes.terminationCode,
    permission: 'Entity_TerminationCode_View',
    component: lazy(() => import('pages/entity/terminationCode/index')),
  },
  {
    path: routes.createTerminationCode,
    permission: 'Entity_TerminationCode_Create',
    component: lazy(
      () => import('pages/entity/terminationCode/TerminationCodeForm'),
    ),
  },
  {
    path: routes.editTerminationCode,
    permission: 'Entity_TerminationCode_Update',
    component: lazy(
      () => import('pages/entity/terminationCode/TerminationCodeForm'),
    ),
  },
  {
    path: routes.viewTerminationCode,
    permission: 'Entity_TerminationCode_View',
    component: lazy(
      () => import('pages/entity/terminationCode/TerminationCodeForm'),
    ),
  },

  // client Group
  {
    path: routes.clientGroupProfile,
    permission: 'ClientGroupProfile_View',
    component: lazy(() => import('pages/client/clientGroup/index')),
  },
  {
    path: routes.createClientGroupProfile,
    permission: 'ClientGroupProfile_Create',
    component: lazy(() => import('pages/client/clientGroup/clientGroupProfile/ClientGroupProfile')),

  },
  {
    path: routes.editClientGroupProfile,
    permission: 'ClientGroupProfile_Update',
    component: lazy(() => import('pages/client/clientGroup/clientGroupProfile/ClientGroupProfile')),

  },
  {
    path: routes.viewClientGroupProfile,
    permission: 'ClientGroupProfile_View',
    component: lazy(() => import('pages/client/clientGroup/clientGroupProfile/ClientGroupProfileView')),
  },
  {
    path: routes.editClientGroupEntities,
    permission: 'ClientGroupProfile_Update',
    component: lazy(() => import('pages/client/clientGroup/clientGroupEntities/ClientGroupEntities')),
  },
  {
    path: routes.createClientGroupEntities,
    permission: 'ClientGroupProfile_Create',
    component: lazy(() => import('pages/client/clientGroup/clientGroupEntities/ClientGroupEntities')),

  },
  {
    path: routes.viewClientGroupEntities,
    permission: 'ClientGroupProfile_View',
    component: lazy(() => import('pages/client/clientGroup/clientGroupEntities/ClientGroupEntitiesView')),
  },
  // entity service provider
  {
    path: routes.serviceProvider,
    permission: 'Entity_ServiceProvider_View',
    component: lazy(() => import('pages/entity/serviceProvider/index')),
  },
  {
    path: routes.createServiceProvider,
    permission: 'Entity_ServiceProvider_Create',
    component: lazy(
      () => import('pages/entity/serviceProvider/ServiceProviderForm'),
    ),
  },
  {
    path: routes.editServiceProvider,
    permission: 'Entity_ServiceProvider_Update',
    component: lazy(
      () => import('pages/entity/serviceProvider/ServiceProviderForm'),
    ),
  },
  {
    path: routes.viewServiceProvider,
    permission: 'Entity_ServiceProvider_View',
    component: lazy(
      () => import('pages/entity/serviceProvider/ServiceProviderForm'),
    ),
  },
  // entity settings
  {
    path: routes.settings,
    permission: 'Entity_EntitySettings_View',
    component: lazy(() => import('pages/entity/Settings/index')),
  },
  {
    path: routes.createSettings,
    permission: 'Entity_EntitySettings_Create',
    component: lazy(() => import('pages/entity/Settings/EntitySettingsForm')),
  },
  {
    path: routes.editSettings,
    permission: 'Entity_EntitySettings_Update',
    component: lazy(() => import('pages/entity/Settings/EntitySettingsForm')),
  },
  {
    path: routes.viewSettings,
    permission: 'Entity_EntitySettings_View',
    component: lazy(() => import('pages/entity/Settings/EntitySettingsForm')),
  },
  // currency exchange
  {
    path: routes.currencyExchange,
    permission: 'Entity_CurrencyExchange_View',
    component: lazy(() => import('pages/entity/currencyExchange/index')),
  },
  {
    path: routes.createCurrencyExchange,
    permission: 'Entity_CurrencyExchange_Create',
    component: lazy(() => import('pages/entity/currencyExchange/currencyExchange')),
  },
  {
    path: routes.editCurrencyExchange,
    permission: 'Entity_CurrencyExchange_Update',
    component: lazy(() => import('pages/entity/currencyExchange/currencyExchange')),
  },
  {
    path: routes.viewCurrencyExchange,
    permission: 'Entity_CurrencyExchange_View',
    component: lazy(() => import('pages/entity/currencyExchange/currencyExchange')),
  },
  {
    path: routes.iframe,
    permission: 'Reporting_ReportDesigns_View',
    component: lazy(() => import('pages/SamplePageAlert/Iframe')),
  },

  // report
  {
    path: routes.standardReports,
    permission: 'Reporting_Reporting_View',
    component: lazy(() => import('pages/reports/standardReport/index')),
  },

  {
    path: routes.standardReportsGenerate,
    permission: 'Reporting_Reporting_Create',
    component: lazy(() => import('pages/reports/standardReport/reportForm/ReportForm')),
  },

  {
    path: routes.standardReportsGenerateView,
    permission: 'Reporting_Reporting_View',
    component: lazy(() => import('pages/reports/standardReport/reportForm/ReportForm')),
  },

  // Anual Composiation
  {
    path: routes.annualCompensationReport,
    permission: 'Reporting_Reporting_View',
    component: lazy(() => import('pages/reports/annualCompensationReport/index')),
  },

  {
    path: routes.annualCompensationReportCreate,
    permission: 'Reporting_ReportGroups_Create',
    component: lazy(() => import('pages/reports/annualCompensationReport/reportForm/ReportForm')),
  },

  // enitity employee movement type
  {
    path: routes.employeeMovement,
    permission: 'EmployeeMovement_View',
    component: lazy(() => import('pages/entity/employeeMovementType/index')),
  },
  {
    path: routes.createemployeeMovement,
    permission: 'EmployeeMovement_Create',
    component: lazy(() => import('pages/entity/employeeMovementType/EmployeeMovementform')),
  },
  {
    path: routes.editemployeeMovement,
    permission: 'EmployeeMovement_Update',
    component: lazy(() => import('pages/entity/employeeMovementType/EmployeeMovementform')),
  },
  {
    path: routes.viewemployeeMovement,
    permission: 'EmployeeMovement_View',
    component: lazy(() => import('pages/entity/employeeMovementType/EmployeeMovementform')),
  },
  // pension fund scheme item
  {
    path: routes.pensionFundSchemeItem,
    permission: 'Entity_PensionFundSchemeItem_View',
    component: lazy(() => import('pages/entity/pensionFundSchemeItem/index')),
  },
  {
    path: routes.createPensionFundSchemeItem,
    permission: 'Entity_PensionFundSchemeItem_Create',
    component: lazy(() => import('pages/entity/pensionFundSchemeItem/PFSIForm')),
  },
  {
    path: routes.editPensionFundSchemeItem,
    permission: 'Entity_PensionFundSchemeItem_Update',
    component: lazy(() => import('pages/entity/pensionFundSchemeItem/PFSIForm')),
  },
  {
    path: routes.viewPensionFundSchemeItem,
    permission: 'Entity_PensionFundSchemeItem_View',
    component: lazy(() => import('pages/entity/pensionFundSchemeItem/PFSIForm')),
  },

  // entity employee movement configuration
  {
    path: routes.employeeMovementConfiguration,
    permission: 'Entity_EmployeeMovementConfiguration_View',
    component: lazy(() => import('pages/entity/empMovementConfiguration/index')),
  },
  {
    path: routes.createEmployeeMovementConfiguration,
    permission: 'Entity_EmployeeMovementConfiguration_Create',
    component: lazy(() => import('pages/entity/empMovementConfiguration/EmpMovementConfigurationForm')),
  },
  {
    path: routes.editEmployeeMovementConfiguration,
    permission: 'Entity_EmployeeMovementConfiguration_Update',
    component: lazy(() => import('pages/entity/empMovementConfiguration/EmpMovementConfigurationForm')),
  },
  {
    path: routes.viewEmployeeMovementConfiguration,
    permission: 'Entity_EmployeeMovementConfiguration_View',
    component: lazy(() => import('pages/entity/empMovementConfiguration/EmpMovementConfigurationForm')),
  },

  // entity work calender
  {
    path: routes.workCalender,
    permission: 'Entity_WorkCalendar_View',
    component: lazy(() => import('pages/entity/workCalender/index')),
  },
  {
    path: routes.createWorkCalender,
    permission: 'Entity_WorkCalendar_Create',
    component: lazy(() => import('pages/entity/workCalender/WorkCalenderForm')),
  },
  {
    path: routes.editWorkCalender,
    permission: 'Entity_WorkCalendar_Update',
    component: lazy(() => import('pages/entity/workCalender/WorkCalenderForm')),
  },
  {
    path: routes.viewWorkCalender,
    permission: 'Entity_WorkCalendar_View',
    component: lazy(() => import('pages/entity/workCalender/WorkCalenderForm')),
  },

  // pay  group
  {
    path: routes.payGroup,
    permission: 'Payroll_PayGroup_View',
    component: lazy(() => import('pages/payroll/payGroup/index')),
  },
  {
    path: routes.viewPayGroup,
    permission: 'Payroll_PayGroup_View',
    component: lazy(() => import('pages/payroll/payGroup/PayGroupForm')),
  },
  {
    path: routes.editPayGroup,
    permission: 'Payroll_PayGroup_Update',
    component: lazy(() => import('pages/payroll/payGroup/PayGroupForm')),
  },
  {
    path: routes.createPayGroup,
    permission: 'Payroll_PayGroup_Create',
    component: lazy(() => import('pages/payroll/payGroup/PayGroupForm')),
  },
  // pay item group

  {
    path: routes.payItemGroup,
    permission: 'Payroll_PayItem_View',
    component: lazy(() => import('pages/payroll/payItemGroup/index')),
  },
  {
    path: routes.viewPayItemGroup,
    permission: 'Payroll_PayItem_View',
    component: lazy(() => import('pages/payroll/payItemGroup/PayItemGroupForm')),
  },
  {
    path: routes.editPayItemGroup,
    permission: 'Payroll_PayItem_Update',
    component: lazy(() => import('pages/payroll/payItemGroup/PayItemGroupForm')),
  },
  {
    path: routes.createPayItemGroup,
    permission: 'Payroll_PayItemGroup_Create',
    component: lazy(() => import('pages/payroll/payItemGroup/PayItemGroupForm')),
  },

  // entity profile

  {
    path: routes.entityProfile,
    permission: 'Entity_EntityProfile_View',
    component: lazy(() => import('pages/entity/entityProfile/index')),
  },
  {
    path: routes.viewEntityProfile,
    permission: 'Entity_EntityProfile_View',
    component: lazy(() => import('pages/entity/entityProfile/EntityProfile')),
  },
  {
    path: routes.editEntityProfile,
    permission: 'Entity_EntityProfile_Update',
    component: lazy(() => import('pages/entity/entityProfile/EntityProfile')),
  },
  {
    path: routes.createEntityProfile,
    permission: 'Entity_EntityProfile_Create',
    component: lazy(() => import('pages/entity/entityProfile/EntityProfile')),
  },

  // employee profile

  {
    path: routes.employeeProfile,
    permission: 'EmployeeSnapshot_View',
    component: lazy(() => import('pages/employee/profile/index')),
  },
  {
    path: routes.editEmployeeProfileDetalis,
    permission: 'EmployeeSnapshot_Update',
    component: lazy(() => import('pages/employee/profile/employeeDetails/EmployeeProfileForm')),
  },

  {
    path: routes.createEmployeeProfile,
    permission: 'EmployeeSnapshot_Create',
    component: lazy(() => import('pages/client/clientGroup/clientGroupProfile/ClientGroupProfile')),

  },
  {
    path: routes.editEmployeeProfile,
    permission: 'EmployeeSnapshot_Update',
    component: lazy(() => import('pages/client/clientGroup/clientGroupProfile/ClientGroupProfile')),

  },
  {
    path: routes.viewEmployeeProfile,
    permission: 'EmployeeSnapshot_View',
    component: lazy(() => import('pages/employee/profile/employeeDetails/index')),
  },
  {
    path: routes.employeePassword,
    permission: 'EmployeePassword_View',
    component: lazy(() => import('pages/employee/employeePassword/index')),
  },
  // {
  //   path: routes.viewEmployeePassword,
  //   permission: 'EmployeePassword_View',
  //   component: lazy(() => import('pages/employee/employeePassword/EmployeePasswordForm')),
  // },
  // pension fund scheme rule
  {
    path: routes.pensionFundSchemeRule,
    permission: 'Entity_PensionFundSchemeRule_View',
    component: lazy(() => import('pages/entity/pensionFundSchemeRule/index')),
  },
  {
    path: routes.createPensionFundSchemeRule,
    permission: 'Entity_PensionFundSchemeRule_Create',
    component: lazy(() => import('pages/entity/pensionFundSchemeRule/PensionFundSchemeRule')),
  },
  {
    path: routes.editPensionFundSchemeRule,
    permission: 'Entity_PensionFundSchemeRule_Update',
    component: lazy(() => import('pages/entity/pensionFundSchemeRule/PensionFundSchemeRule')),
  },
  {
    path: routes.viewPensionFundSchemeRule,
    permission: 'Entity_PensionFundSchemeRule_View',
    component: lazy(() => import('pages/entity/pensionFundSchemeRule/PensionFundSchemeRule')),
  },
  // company bank account
  {
    path: routes.companyBankAccount,
    permission: 'Entity_CompanyBankAccount_View',
    component: lazy(() => import('pages/entity/companyBankAccount/index')),
  },
  {
    path: routes.createCompanyBankAccount,
    permission: 'Entity_CompanyBankAccount_Create',
    component: lazy(() => import('pages/entity/companyBankAccount/CompanyBankAccountForm')),
  },
  {
    path: routes.editCompanyBankAccount,
    permission: 'Entity_CompanyBankAccount_Update',
    component: lazy(() => import('pages/entity/companyBankAccount/CompanyBankAccountForm')),
  },
  {
    path: routes.viewCompanyBankAccount,
    permission: 'Entity_CompanyBankAccount_View',
    component: lazy(() => import('pages/entity/companyBankAccount/CompanyBankAccountForm')),
  },
  // entity pension fund scheme
  {
    path: routes.pensionFundScheme,
    permission: 'Entity_PensionFundScheme_View',
    component: lazy(() => import('pages/entity/pensionFundScheme/index')),
  },
  {
    path: routes.createPensionFundScheme,
    permission: 'Entity_PensionFundScheme_Create',
    component: lazy(() => import('pages/entity/pensionFundScheme/PensionFundSchemeForm')),
  },
  {
    path: routes.editPensionFundScheme,
    permission: 'Entity_PensionFundScheme_Update',
    component: lazy(() => import('pages/entity/pensionFundScheme/PensionFundSchemeForm')),
  },
  {
    path: routes.viewPensionFundScheme,
    permission: 'Entity_PensionFundScheme_Delete',
    component: lazy(() => import('pages/entity/pensionFundScheme/viewPensionFundScheme')),
  },
  // pay item master
  {
    path: routes.payItemMaster,
    permission: 'Payroll_PayItem_View',
    component: lazy(() => import('pages/payroll/payItemMaster/index')),
  },
  {
    path: routes.viewPayItemMaster,
    permission: 'Payroll_PayItem_View',
    component: lazy(() => import('pages/payroll/payItemMaster/viewPayItemMaster')),
  },
  {
    path: routes.editPayItemMaster,
    permission: 'Payroll_PayItem_Update',
    component: lazy(() => import('pages/payroll/payItemMaster/PayItemMasterForm')),
  },
  {
    path: routes.createPayItemMaster,
    permission: 'Payroll_PayItem_Create',
    component: lazy(() => import('pages/payroll/payItemMaster/PayItemMasterForm')),
  },
  // payroll non rucurring
  {
    path: routes.payRollNonRecurring,
    permission: 'Payroll_PayrollNonRecurringItems_View',
    component: lazy(() => import('pages/payroll/payrollNonRucurring/index')),
  },
  {
    path: routes.createPayRollNonRecurring,
    permission: 'Payroll_PayrollNonRecurringItems_Create',
    component: lazy(() => import('pages/payroll/payrollNonRucurring/payrollNonRecurruingForm')),
  },
  {
    path: routes.editPayRollNonRecurring,
    permission: 'Payroll_PayrollNonRecurringItems_Update',
    component: lazy(() => import('pages/payroll/payrollNonRucurring/payrollNonRecurruingForm')),
  },
  {
    path: routes.viewPayRollNonRecurring,
    permission: 'Payroll_PayrollNonRecurringItems_View',
    component: lazy(() => import('pages/payroll/payrollNonRucurring/payrollNonRecurruingForm')),
  },
  // pay cycle administrator
  {
    path: routes.payCycleAdministration,
    permission: 'Payroll_PayCycleAdministration_View',
    component: lazy(() => import('pages/payroll/payCycleAdministrator/index')),
  },
  {
    path: routes.createPayCycleAdministration,
    permission: 'Payroll_PayCycleAdministration_Create',
    component: lazy(() => import('pages/payroll/payCycleAdministrator/PayCycleAdministrationForm')),
  },
  {
    path: routes.editPayCycleAdministration,
    permission: 'Payroll_PayCycleAdministration_Update',
    component: lazy(() => import('pages/payroll/payCycleAdministrator/PayCycleAdministrationForm')),
  },
  {
    path: routes.viewPayCycleAdministration,
    permission: 'Payroll_PayCycleAdministration_View',
    component: lazy(() => import('pages/payroll/payCycleAdministrator/PayCycleAdministrationForm')),
  },
  // Report
  {
    path: routes.reportDesignerCustomReport,
    permission: 'Reporting_ReportDesigns_View',
    component: lazy(() => import('pages/Report/ReportDesigner/index')),
  },
  {
    path: routes.createReportDesignerCustomReport,
    permission: 'Reporting_ReportDesigns_Create',
    component: lazy(() => import('pages/Report/ReportDesigner/ReportDesignerAlert')),
  },
  // payroll month end closing
  {
    path: routes.payRollMonthClosing,
    permission: 'Payroll_MonthEndClosing_View',
    component: lazy(() => import('pages/payroll/payrollMonthEndClosing/index')),
  },
  // paycycle reassignment
  {
    path: routes.payCycleReassignment,
    permission: 'Payroll_MonthEndClosing_View',
    component: lazy(() => import('pages/payroll/payCycleReassigment/index')),
  },
  // add payroll month and closing
  // {
  //   path: routes.createPayRollMonthClosing,
  //   permission: 'Payroll_MonthEndClosing_View',
  //   component: lazy(() => import('pages/payroll/payrollMonthEndClosing/MonthEndClosingAlert')),
  // },

  // Genearte payroll slip
  {
    path: routes.payrollSlip,
    permission: 'Reporting_ReportGroups_View',
    component: lazy(() => import('pages/reports/payrollSlip/index')),
  },
  {
    path: routes.createPayrollSlip,
    permission: 'Reporting_Reporting_Create',
    component: lazy(() => import('pages/reports/payrollSlip/payrollSlipForm/payrollSlipsForm')),
  },
  // {
  //   path: routes.editPayrollSlip,
  //   permission: 'Payroll_PayrollRun_View',
  //   component: lazy(() => import('pages/reports/payrollSlip/RunPayrollStepperForm')),
  // },
  // {
  //   path: routes.viewPayrollSlip,
  //   permission: 'Payroll_PayrollRun_View',
  //   component: lazy(() => import('pages/reports/payrollSlip/RunPayrollStepperForm')),
  // },

  // Payment summary report
  {
    path: routes.paymentSummary,
    permission: 'Reporting_Reporting_View',
    component: lazy(() => import('pages/reports/paymentSummary/index')),
  },
  {
    path: routes.createPaymentSummary,
    permission: 'Reporting_Reporting_Create',
    component: lazy(() => import('pages/reports/paymentSummary/paymentsSummaryForm/paymentSummaryForm')),
  },

  // Run Payroll Process
  {
    path: routes.runPayroll,
    permission: 'Payroll_PayrollRun_View',
    component: lazy(() => import('pages/payroll/runPayroll/index')),
  },
  {
    path: routes.createRunPayroll,
    permission: 'Payroll_PayrollRun_Create',
    component: lazy(() => import('pages/payroll/runPayroll/RunPayrollStepperForm')),
  },
  {
    path: routes.editRunPayroll,
    permission: 'Payroll_PayrollRun_Update',
    component: lazy(() => import('pages/payroll/runPayroll/RunPayrollStepperForm')),
  },
  {
    path: routes.viewRunPayroll,
    permission: 'Payroll_PayrollRun_View',
    component: lazy(() => import('pages/payroll/runPayroll/RunPayrollStepperForm')),
  },
  {
    path: routes.emailProfile,
    permission: 'Notification_EmailProfile_View',
    component: lazy(() => import('pages/notification/emailProfile/index')),
  },
  {
    path: routes.createEmailProfile,
    permission: 'Notification_EmailProfile_Create',
    component: lazy(() => import('pages/notification/emailProfile/EmailProfileForm')),
  },
  {
    path: routes.editEmailProfile,
    permission: 'Notification_EmailProfile_Update',
    component: lazy(() => import('pages/notification/emailProfile/emailProfileView')),
  },
  {
    path: routes.viewEmailProfile,
    permission: 'Notification_EmailProfile_View',
    component: lazy(() => import('pages/notification/emailProfile/emailProfileView')),
  },
  {
    path: routes.sendEmail,
    permission: 'Notification_SendEmailNotification_View',
    component: lazy(() => import('pages/notification/sendEmail/index')),
  },
  {
    path: routes.createSendEmail,
    permission: 'Notification_SendEmailNotification_Create',
    component: lazy(() => import('pages/notification/sendEmail/SendEmailForm')),
  },
  {
    path: routes.createSendPaySlip,
    permission: 'Notification_SendEmailNotification_View',
    component: lazy(() => import('pages/notification/sendEmail/SendPaySlip')),
  },
  // pension fund termination code
  {
    path: routes.pensionFundTermination,
    permission: 'PensionFundTerminationCode_View',
    component: lazy(() => import('pages/global/fundTermination/index')),
  },
  {
    path: routes.createPensionFundTermination,
    permission: 'PensionFundTerminationCode_Create',
    component: lazy(() => import('pages/global/fundTermination/FundTerminationForm')),
  },
  {
    path: routes.editPensionFundTermination,
    permission: 'PensionFundTerminationCode_Update',
    component: lazy(() => import('pages/global/fundTermination/FundTerminationForm')),
  },
  {
    path: routes.viewPensionFundTermination,
    permission: 'PensionFundTerminationCode_View',
    component: lazy(() => import('pages/global/fundTermination/FundTerminationForm')),
  },
  // docuTax Pro
  {
    path: routes.docutaxPro,
    permission: 'Integration_Integration_View',
    component: lazy(() => import('pages/Report/DocuTaxPro/index')),
  },
  {
    path: routes.createDocutaxPro,
    permission: 'Integration_Integration_Create',
    component: lazy(() => import('pages/Report/DocuTaxPro/FileUploadForm')),
  },

  // Standard Formulation

  {
    path: routes.standardFormulation,
    permission: 'Payroll_CustomFormula_View',
    component: lazy(() => import('pages/entity/standardFormula/index')),
  },

  {
    path: routes.createStandardFormulation,
    permission: 'Payroll_CustomFormula_Create',
    component: lazy(() => import('pages/entity/standardFormula/StandardFormulaForm')),
  },
  {
    path: routes.editStandardFormulation,
    permission: 'Payroll_CustomFormula_Update',
    component: lazy(() => import('pages/entity/standardFormula/StandardFormulaForm')),
  },
  {
    path: routes.viewStandardFormulation,
    permission: 'Payroll_CustomFormula_View',
    component: lazy(() => import('pages/entity/standardFormula/StandardFormulaForm')),
  },
  // Audit Trail
  {
    path: routes.auditTrail,
    permission: 'Reporting_Reporting_View',
    component: lazy(() => import('pages/Report/auditTrailLogging/index')),
  },
  {
    path: routes.createAuditTrail,
    permission: 'Reporting_Reporting_Create',
    component: lazy(() => import('pages/Report/auditTrailLogging/GenerateAuditReport')),
  },

  // Delete Non Recurring Item
  {
    path: routes.deleteNonRecurringItem,
    permission: 'Payroll_PayrollNonRecurringItems_BulkDelete',
    component: lazy(() => import('pages/uploadData/deleteNonRecurringItem/index')),
  },
  // Publish report
  {
    path: routes.publishReport,
    permission: 'Reporting_ReportGroups_View',
    component: lazy(() => import('pages/Report/PublishReport/index')),
  },
  {
    path: routes.viewpublishReport,
    permission: 'Reporting_ReportGroups_View',
    component: lazy(() => import('pages/Report/PublishReport/publishReportView')),
  },
  {
    path: routes.createpublishReport,
    permission: 'Reporting_ReportGroups_Create',
    component: lazy(() => import('pages/Report/PublishReport/publishReportCreate')),
  },

  // payroll history
  {
    path: routes.payrollHistory,
    permission: 'Payroll_PayrollHistoryUpload_View',
    component: lazy(() => import('pages/bulkAction/payrollHistory/index')),
  },
  // email template
  {
    path: routes.emailTemplate,
    permission: 'Notification_EmailProfile_View',
    component: lazy(() => import('pages/notification/emailTemplate/index')),
  },
  {
    path: routes.createEmailTemplate,
    permission: 'Notification_EmailProfile_Create',
    component: lazy(() => import('pages/notification/emailTemplate/EmailTemplateForm')),
  },
  {
    path: routes.viewEmailTemplate,
    permission: 'Notification_EmailProfile_View',
    component: lazy(() => import('pages/notification/emailTemplate/EmailTemplateForm')),
  },
  {
    path: routes.editEmailTemplate,
    permission: 'Notification_EmailProfile_Update',
    component: lazy(() => import('pages/notification/emailTemplate/EmailTemplateForm')),
  },

  // report review

  {
    path: routes.reviewReport,
    permission: 'Reporting_Reporting_View',
    component: lazy(() => import('pages/reports/reviewReport/index')),
  },
  // employee transaction
  {
    path: routes.employeeLeaveTransaction,
    permission: 'EmployeeLeaveTransaction_View',
    component: lazy(() => import('pages/employee/empoyeeLeaveTransaction/index')),
  },
  {
    path: routes.createEmployeeLeaveTransaction,
    permission: 'EmployeeLeaveTransaction_Create', // need to be change
    component: lazy(() => import('pages/employee/empoyeeLeaveTransaction/employeeLeaveTransactionForm')),
  },
  {
    path: routes.editEmployeeLeaveTransaction,
    permission: 'EmployeeLeaveTransaction_Update', // need to be change
    component: lazy(() => import('pages/employee/empoyeeLeaveTransaction/employeeLeaveTransactionForm')),
  },
  // viewEmployeeLeaveTransaction
  {
    path: routes.viewEmployeeLeaveTransaction,
    permission: 'EmployeeLeaveTransaction_View', // need to be change
    component: lazy(() => import('pages/employee/empoyeeLeaveTransaction/employeeLeaveTransactionView')),
  },

  // employee remarks
  {
    path: routes.employeeRemark,
    permission: 'EmployeeRemarks_View',
    component: lazy(() => import('pages/employee/employeeRemark/index')),
  },
  {
    path: routes.createEmployeeRemark,
    permission: 'EmployeeRemarks_Create',
    component: lazy(() => import('pages/employee/employeeRemark/EmployeeRemarkForm')),
  },
  {
    path: routes.editEmployeeRemark,
    permission: 'EmployeeRemarks_Update',
    component: lazy(() => import('pages/employee/employeeRemark/EmployeeRemarkForm')),
  },
  {
    path: routes.viewEmployeeRemark,
    permission: 'EmployeeRemarks_View',
    component: lazy(() => import('pages/employee/employeeRemark/EmployeeRemarkView')),
  },
]
