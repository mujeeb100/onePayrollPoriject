// common function,varible and so on
import {
  COL_HEADER_CORPORATE_TITLE_CODE,
  COL_HEADER_CORPORATE_TITLE_NAME,
  COL_HEADER_REMARKS,
  COMP_BANK_ACCT_TITLE,
  ENTITY_IRD,
} from 'constants/index'
import i18nConfig from 'i18n'
import { jsPDF as JSPdf } from 'jspdf'
import autoTable from 'jspdf-autotable'
import _ from 'lodash'
import merge from 'lodash/merge'
import Template from 'lodash/template'
import moment from 'moment-timezone'
import { DropDownOption, EntityIRDType } from 'types'
import { utils, writeFileXLSX } from 'xlsx'

const setRouteValues = (str: string, data: any) => {
  const compiled = Template(str, { interpolate: /:(\w+)/g })
  return compiled(data)
}
export const getSelectedEntity = () => {
  const entity = localStorage.getItem('Entity')
  // getauthToken()
  return entity ? JSON.parse(entity) : null
}
export const getAPIWithEntityUrl = (url: string) => {
  const entity: any = getSelectedEntity()
  let entityUrl: string = url
  // TODO: Handle negative scenario after completing the positive scenario

  if (entity) {
    entityUrl = entityUrl?.replace('<SELECTED_ENTITY>', entity.id)
  }

  // TODO: Think about below return value whether it would be null or apiEndPoint
  // or something else
  return entityUrl
}

export const generateFilterUrl: any = (filterData: any) => {
  const params: Record<string, any> = {}
  // skip all empty value
  Object.keys(filterData).reduce((result, key) => {
    const value = filterData[key]
    const skip = value === null || value === undefined || ((_.isString(value) || _.isArray(value)) && _.isEmpty(value))
    if (!skip) {
      params[key] = value
    }
    return result
  }, params)

  const url = new URLSearchParams(params).toString()
  return url === '' ? url : `?${url}`
}

export const generateFilterUrl1 = (filterData:any) => {
  const years = filterData.years.map((yearObj:any) => yearObj.roleCode).join(',')

  // Generate the URL with other parameters
  const url = `?Year=${years}`

  return url
}

// do not remove it is used in review report

export const generateFilterUrlNew: any = (reportData: any) => {
  let url = ''
  const keys = Object.keys(reportData)
  keys.forEach((key, index) => {
    if (key === 'orderByAsc') {
      url += `${`&orderByAsc=${reportData[key]}`}`
    } else {
      url += `${reportData[key] ? `&${key}=${reportData[key]}` : ''}`
    }
  })

  return url === '' ? url : `?${url.substring(1)}`
}

export const firstLatterCapital = (str: string) => str.charAt(0).toUpperCase() + str.slice(1)

const getEnv = <T>(key: string, defaultValue: T | null | undefined) => process.env[key] || defaultValue

export { getEnv, setRouteValues }

export const getauthToken = () => {
  const entity: any = localStorage.getItem('okta-token-storage')

  return entity ? JSON.parse(entity)?.accessToken?.accessToken : null
}

export function getDefaultLang(lang: string) {
  i18nConfig(lang)
}

export const formateDate: any = (date: any, zone: string) => {
  const dateValue = moment.utc(date).tz(zone)
  return dateValue.format()
}

export const formatedDate = (isoDate: string, format = 'DD MMM YYYY HH:mm:ss') : string => {
  const formatDate = new Date(isoDate)
  return moment(formatDate).format(format)
}

export const formatedYearDate = (isoDate: string, format = 'YYYY-MM-DD') : string => {
  const formatDate = new Date(isoDate)
  return moment(formatDate).format(format)
}

export const customDateFormate = (newDate:any) => {
  const formatDate = new Date(newDate)
  const date = formatDate.toLocaleDateString('en-us', { day: 'numeric' })
  const month = formatDate.toLocaleDateString('en-us', { month: 'short' })
  const year = formatDate.toLocaleDateString('en-us', { year: 'numeric' })
  const FormattedDate = `${date} ${month} ${year}`
  // console.log(FormattedDate)
  return FormattedDate
}

// PDF Generation on Landscape
export const exportToPdf = (
  data: any[],
  columns: any[],
  fileName: string,
  orientation: 'landscape' | 'portrait' = 'landscape',
  colSize = 100,
  formatX = 1800,
  formatY = 800,
) => {
  const doc = new JSPdf(orientation, 'px', [formatX, formatY])
  const cntStr = `Total Count: ${data.length}`

  // This will set the title of Total count
  doc.setFontSize(12)
  doc.text(cntStr, 15, 10)

  // 100% will zoom document to 100% on Acrobat reader. This display mode supports on selected
  //  pdf readers only and adobe reader supperts it but browser pdf viewere doesn't.
  doc.setDisplayMode('100%')

  autoTable(doc, {
    body: [...data],
    columns: [...columns],
    // This will increase size of each column to 100px as we had set document prop in px.
    columnStyles: changeWidthOfAllCols(data, colSize),
  })

  doc.save(setFileName(`${fileName} data`, 'pdf'))
}

const changeWidthOfAllCols = (rd: any, cw: number) => rd.reduce((acc: any, c: any, i: number) => {
  const objAcc = { [i]: { cw } }
  return merge(objAcc, acc)
}, {})

/**
 * This function creates file name based on prefix and file extension(ext)
 * @param prefix String
 * @param ext String
 * @returns String
 */
export const setFileName = (prefix: string, ext: string) => `${prefix}-${Math.floor(Date.now() / 1000)}.${ext}`

export const exportToExcel = (dataToExcel: any[], fileName: string) => {
  const ws = utils.json_to_sheet(dataToExcel)
  const wb = utils.book_new()

  // While generating excel file, it takes column length as default
  // and due to that most of the data doesn't show.
  // So increase the size of columns using -- setColWidth() -- method,
  // and you can change from width from 26 to any size.
  if (fileName === COMP_BANK_ACCT_TITLE) {
    const wsCols = setColWidth(dataToExcel.length, 26)
    ws['!cols'] = wsCols
  }

  utils.book_append_sheet(wb, ws, 'Data')
  writeFileXLSX(wb, setFileName(`${fileName} data`, 'xlsx'))
}

const setColWidth = (cl: number, cw: number): { wch: number }[] => Array(cl).fill({ wch: cw })

export const valuesMappedWithKeys = (
  fileName: string,
  responseData: any,
  headers: any[] = [],
) => {
  switch (fileName) {
    case ENTITY_IRD:
      return replaceKeyWithColNameInIRD(responseData)
    default:
      return responseData
  }
}

export const replaceKeyWithColNameInIRD = (rData: EntityIRDType[]) => rData.map((IRDData: EntityIRDType) => {
  const { corporateTitleCode, corporateTitleName, remarks } = IRDData
  return {
    [COL_HEADER_CORPORATE_TITLE_CODE]: corporateTitleCode,
    [COL_HEADER_CORPORATE_TITLE_NAME]: corporateTitleName,
    [COL_HEADER_REMARKS]: remarks,
  }
})
export const getParamsValue:any = (url: any, index: any) => {
  let id
  const viewUrl = url?.pathname?.split('/').pop() === 'view'
  const newUrl = url?.pathname?.slice(0, url?.pathname?.lastIndexOf('/'))
  if (url?.pathname === index) {
    id = null
  } else {
    id = newUrl?.split('/').pop()
  }
  return { id, viewUrl }
}

export const getParamsGenerateReport:any = (url: any, index: any) => {
  let id
  const viewUrl = url?.pathname?.split('/').pop() === 'edit'
  const newUrl = url?.pathname?.slice(0, url?.pathname?.lastIndexOf('/'))
  if (url?.pathname === index) {
    id = null
  } else {
    id = newUrl?.split('/').pop()
  }
  return { id, viewUrl }
}

export const getColumnNames = (
  columns: any,
): { header: string; dataKey: string }[] => columns
  .map((column: any) => {
    if (column.title !== '') return { header: column.title, dataKey: column.key }
    return null
  })
  .filter((column: string) => column !== null)

export const translatedColumnsForExcel = (
  columns: any,
): { header: string; key: string }[] => columns.map((column: any) => column.header)

/**
 * Method will be used for mapping the header to data using response data and headers
 * @param rData Response data
 * @param headers Headers which will be shown in excel file
 * @returns Headers mapped to Data
 */
export const getDataByMappingKeyToHeaders = (
  rData: any[],
  headerWithKeys: any[],
) => rData.map((data: any) => {
  const values = Object.values(data)
  const keys = Object.keys(data)
  return headerWithKeys.reduce((acc, curr, index) => {
    let storingValue = data[curr.dataKey]
    if (
      typeof keys[index] === 'string'
        && keys[index].toLowerCase() === 'status'
    ) {
      storingValue = data[curr.dataKey] === 0
          || data[curr.dataKey] === '0'
          || data[curr.dataKey] === false
        ? 'Inactive'
        : 'Active'
    }
    return merge(acc, { [curr.header]: storingValue })
  }, {})
})

export const getAllRecordsAtOnce = async (
  filterData: any,
  baseURL: string,
  endpoint: string,
) => {
  // Generate filter url from given filter data for adding as query params
  const filterURL = generateFilterUrl({
    ...filterData,
    pageSize: filterData.totalItems,
  })

  // Fetch data from API
  const response = await fetch(`${baseURL}/${endpoint}${filterURL}`, {
    method: 'GET',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${getauthToken()}`,
    },
  })

  return response
}

export const exportAllRecordsToPdfAndExcel = (
  allRecords: any,
  fileName: string,
  columns: any,
  handleClose: any,
  typeOfFile: 'pdf' | 'excel',
  orientation: 'landscape' | 'portrait' = 'landscape',
): any => {
  if (
    allRecords
    && allRecords.baseURL
    && allRecords.endpoint
    && allRecords.filterData
  ) {
    const { baseURL, endpoint, filterData } = allRecords
    const allData = getAllRecordsAtOnce(filterData, baseURL, endpoint)
    allData
      .then(async (response: any) => {
        const res = await response.json()
        if (
          res
          && res.data
          && res.data.records
          && res.data.records.length > 0
        ) {
          // Transform the status field in each record
          const transformedRecords = res.data.records.map((record: any) => ({
            ...record,
            status: record.status ? 'Active' : 'Inactive',
          }))

          if (typeOfFile === 'pdf') {
            exportToPdf(transformedRecords, columns, fileName, orientation)
          } else {
            const dataToExcel = getDataByMappingKeyToHeaders(
              transformedRecords,
              columns,
            )
            exportToExcel(dataToExcel, fileName)
          }
          handleClose()
        }
      })
      .catch((err) => {
        alert('Something went wrong')
      })
  } else {
    alert('Incomplete data for export')
  }
}

export const formatEffectiveDate = (date: Date = new Date()) => moment(date).format('MM/DD/yyyy')
export const flattenDropDownOptions = (arr: DropDownOption[]) => arr?.map((item: DropDownOption) => item?.roleCode).join(',')
