import List from '@mui/material/List'
import ListItem from '@mui/material/ListItem'
import ListItemButton from '@mui/material/ListItemButton'
import ListItemText from '@mui/material/ListItemText'
import { useGetAllUserRoleEntityQuery } from 'api/identityServices'
import CustomLoader from 'components/atoms/loader/OPRLoader'
import { t } from 'i18next'
import { useState } from 'react'
import { useAPI } from 'services/apiContext'
import { generateFilterUrl } from 'utils'

import { CustomDialog } from '../../atoms/modal/OPRModal'

type EntitySelectModalProps = {
    onClick: (value: any) => void;
    isOpen: boolean;
    isLoggedin?: boolean;
  };

export function EntitySelectModal({ onClick, isLoggedin, isOpen }: EntitySelectModalProps) {
  const [filterData, setFilterData]:any = useState({
    pageNumber: 1,
    pageSize: 20,
    totalItems: 0,
    orderByAsc: true,
    sortBy: '',
    SearchText: '',
  })
  const context = useAPI()
  const handleLogout = () => context?.handleLogout()

  const logout = () => {
    handleLogout()
  }

  const {
    data: allPosts,
    isLoading: isLoadingAllPosts,
    isSuccess: isSuccessAllPosts,
    isError: isErrorAllPosts,
    error: errorAllPosts,
    refetch: refetchAllPosts,
  } = useGetAllUserRoleEntityQuery(generateFilterUrl(filterData))

  return (
    <CustomDialog
      enableLeftButton
      CustomStyles={{ borderRadius: '16px' }}
      handleClose={() => {}}
      isOpen={isOpen}
      leftButtonAction={logout}
      title={t('select_entity_title')}
    >
      { !allPosts ? <CustomLoader /> : (
        <List sx={{ pt: 0, pb: 0 }}>
          {allPosts?.map((entity: any) => (
            <ListItem key={entity.id} disableGutters sx={{ pt: 0, pb: 0 }}>
              <ListItemButton onClick={() => onClick(entity)}>
                <ListItemText primary={entity.entityName} />
              </ListItemButton>
            </ListItem>
          ))}
        </List>
      ) }

    </CustomDialog>
  )
}
