// funcs coverage not 100
import '@testing-library/jest-dom/extend-expect'

import {
  fireEvent, render, screen, waitFor,
} from '@testing-library/react'
import { useGetAllUserRoleEntityQuery } from 'api/identityServices'
import { t } from 'i18next'
import React from 'react'
import { useAPI } from 'services/apiContext'

import { EntitySelectModal } from './index'

// Mocking dependencies
jest.mock('api/identityServices')
jest.mock('services/apiContext')
jest.mock('i18next', () => ({
  t: jest.fn((key) => key),
}))

const mockHandleLogout = jest.fn()
const mockOnClick = jest.fn()

const mockContext = {
  handleLogout: mockHandleLogout,
}

const mockData = [
  { id: 1, entityName: 'Entity 1' },
  { id: 2, entityName: 'Entity 2' },
]

describe('EntitySelectModal', () => {
  const renderComponent = (props = {}) => render(<EntitySelectModal isLoggedin isOpen onClick={mockOnClick} {...props} />)
  beforeEach(() => {
    (t as unknown as jest.Mock).mockImplementation((key) => key);
    (useAPI as jest.Mock).mockReturnValue(mockContext)
    useGetAllUserRoleEntityQuery.mockReturnValue({
      data: mockData,
      isLoading: false,
      isSuccess: true,
      isError: false,
      error: null,
      refetch: jest.fn(),
    })
  })

  afterEach(() => {
    jest.clearAllMocks()
  })

  test('renders the modal with entities', async () => {
    renderComponent()
    expect(screen.getByText('select_entity_title')).toBeInTheDocument()
    await waitFor(() => {
      expect(screen.getByText('Entity 1')).toBeInTheDocument()
      expect(screen.getByText('Entity 2')).toBeInTheDocument()
    })
  })

  test('calls onClick with the correct entity when an entity is clicked', async () => {
    renderComponent()

    await waitFor(() => {
      fireEvent.click(screen.getByText('Entity 1'))
    })

    expect(mockOnClick).toHaveBeenCalledWith(mockData[0])
  })

  test('calls handleLogout when the left button is clicked', () => {
    renderComponent()

    fireEvent.click(screen.getByText('sign_out'))

    expect(mockHandleLogout).toHaveBeenCalled()
  })

  test('renders loader when data is loading', () => {
    useGetAllUserRoleEntityQuery.mockReturnValue({
      data: null,
      isLoading: true,
      isSuccess: false,
      isError: false,
      error: null,
      refetch: jest.fn(),
    })

    renderComponent()
    expect(document.getElementById('clip0_10302_104369')).toBeInTheDocument()
  })
})
