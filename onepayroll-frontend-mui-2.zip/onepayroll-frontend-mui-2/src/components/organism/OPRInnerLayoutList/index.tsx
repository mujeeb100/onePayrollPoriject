import { useTheme } from '@emotion/react'
import styled from '@emotion/styled'
import {
  Box, Container, Grid, Paper,
} from '@mui/material'
import { LeftBack } from 'assets/svg-images/SvgComponents'
import OPRButton from 'components/atoms/button/OPRButton'
import OPRLabel from 'components/atoms/label/OPRLabel'
import CustomLoader from 'components/atoms/loader/OPRLoader'
import { CustomDialog } from 'components/atoms/modal/OPRModal'
import OPRPagination from 'components/atoms/pagination/OPRPagination'
import OPRTable from 'components/atoms/table/OPRTable'
import { OPRDeleteControl } from 'components/molecules/OPRAlertControl/OPRDeleteControl'
import OPRErrorAlertControl from 'components/molecules/OPRAlertControl/OPRErrorControl'
import OPRExportButton from 'components/molecules/OPRExportButton'
import OPRResponsiveGrid from 'components/molecules/OPRResponsiveGrid'
import OPRSearchIcon from 'components/molecules/OPRSearchIcon'
import {
  forwardRef,
  Ref,
  useEffect, useImperativeHandle, useState,
} from 'react'
import { useNavigate } from 'react-router'

const TableHeader = styled(Grid)<any>(({ theme, CustomStyles }: any) => ({
  ...{
    ...CustomStyles,
  },
}))
const filterForm = () => (
  <TableHeader
    item
    md={2}
    sm={1}
    sx={{
      alignItems: 'center',
      display: 'flex',
      flexDirection: 'row',
      gap: 2,
    }}
    xs={1}
  />
)

export interface TableRefInterface {
  setSearchField: (value: string) => void
}

export const OPRInnerListLayout = forwardRef(({
  renderTopButtons = () => null,
  handleFileDownload = () => {},
  title = 'Dashboard Page',
  isAdd = true,
  selectedEntity,
  selectedCodes,
  customAdd = '',
  isSearchText = false,
  isBack = false,
  isExport = false,
  isManageReport = false,
  addManageReport = () => {},
  isSearch = true,
  isHeader = true,
  showHeaderTitleRow = true,
  exportHandleClick = () => {},
  addHandleClick = () => {},
  filterLayout = filterForm,
  columns = [],
  dataList = [],
  sortHandleClick = () => {},
  handlePagination,
  loading = false,
  sort = {},
  handleSearch,
  listOfItems = [''],
  recordCount = null,
  selectedValuesInMultiSelect = [''],
  filterData,
  exportProps = {
    data: {},
    fileName: '',
    columns: [],
    allRecords: {},
    pdf: {},
    excel: {},

  },
  error = {},
  isError = false,
  rowNumber = null,
  rowClickHandler = (item: any) => {},
  success,
  deleteCallBack = (item:any) => {},
  selelctedUser = { data: {}, isDelete: false, name: '' },
  setSelelctedUser = (item:any) => {},
}: any, ref: Ref<TableRefInterface>) => {
  const theme:any = useTheme()
  const { isDelete, data, name }:any = selelctedUser
  const handleEdit = (item: any, type: any) => () => {
    console.log('type')
  }
  const navigate = useNavigate()
  const Item = styled(Paper)(({ theme }: any) => ({
    backgroundColor: theme.palette.mode === 'dark' ? '#1A2027' : '#fff',
    ...theme.typography.body2,
    padding: theme.spacing(1),
    textAlign: 'center',
    color: theme.palette.text.secondary,
  }))

  const ListHeader = styled(Box)<any>(({ theme, style }: any) => ({
    ...{
      ...style,
    },
    // customstyle will override the above styles and theme styles for the component
  }))
  const { totalItems, pageSize, pageNumber }:any = filterData
  const [searchField, setSearchField] = useState('')
  const [alert, setAlert] = useState(success)
  useEffect(() => {
    if (success) {
      setAlert(success)
      // setTimeout(() => {
      //   setAlert(false)
      // }, 10000)
    }
  }, [success])

  useImperativeHandle(ref, () => ({
    setSearchField(value: string) {
      setSearchField(value)
    },
  }))

  const finalCount = recordCount || filterData?.totalItems
  return (
    <Container>
      <OPRErrorAlertControl
        error={error}
        header="Failed to Delete"
        isBackButton={false}
        isError={isError}
        isTry={false}
        name={title}

        // handleSubmit={handleSubmit}

        // onEditable={handleEditable}
        // onSetValue={handleSetValue}
      />
      <OPRDeleteControl
        deleteCallBack={deleteCallBack}
        selelctedUser={selelctedUser}
        setSelelctedUser={setSelelctedUser}
        title={title}
      />

      <CustomDialog
        CustomStyles={{ borderRadius: '16px', padding: '0px' }}
        isOpen={alert}
        type="loader"
      >
        <OPRLabel CustomStyles={{ marginTop: 2 }} variant="h4">
          {title}
          {' '}
          deleted
        </OPRLabel>
        <OPRLabel
          CustomStyles={{
            marginTop: '12px',
            display: 'flex',
            alignItems: 'center',
            gap: '12px',
          }}
          variant="body1"
        >
          {name}
          {' '}
          has been deleted.
        </OPRLabel>
        {/* <Box sx={{ borderBottom: '1px solid black' }} /> */}

        <OPRButton
          color="info"
          style={{
            marginLeft: 'auto',
            display: 'flex',
            padding: '8px 16px',
            alignItems: 'center',
            gap: '12px',
            color: '#FFF',
            background: 'var(--blue-blue-5000049-db, #0049DB)',
            borderRadius: '110px',
            border: '1px solid #0049DB',
            overflow: 'hidden',
          }}
          variant="text"
          onClick={() => {
            setAlert(false)
          }}
        >
          Close
        </OPRButton>
        {/* <CustomLoader text="Deleted successfully" /> */}
      </CustomDialog>
      <CustomDialog
        CustomStyles={{ borderRadius: '16px' }}
        isOpen={loading}
        type="loader"
      >
        <CustomLoader text="Processing request" />
      </CustomDialog>
      {isHeader && (
        <>
          {showHeaderTitleRow
          && (
            <Box sx={{ display: 'flex', justifyContent: 'space-between' }}>
              <Box sx={{
                display: 'flex', justifyContent: 'flex-start', alignItems: 'center', gap: '25px',
              }}
              >
                {isBack && (
                  <Box
                    component="div"
                    onClick={() => navigate(-1)}
                  >
                    <LeftBack />
                  </Box>
                )}
                <OPRLabel color="black" variant="h1">
                  {title}
                </OPRLabel>
              </Box>
              <ListHeader
                style={{ display: 'flex', alignItems: 'center', gap: '10px' }}
              >
                {/* extra button */}
                {isManageReport
              && (
                <OPRButton
                  color="primary"
                  handleClick={addManageReport}
                  style={{ borderRadius: '110px' }}
                  variant="contained"
                >
                  Manage Report
                </OPRButton>
              )}
                {isExport && (
                // <OPRButton
                //   color="secondary"
                //   handleClick={exportHandleClick}
                //   style={{ borderRadius: '110px' }}
                //   variant="outlined"
                // >
                //   Export
                // </OPRButton>

                  <OPRExportButton
                    exportProps={exportProps}
                  />

                )}
                {isAdd && (
                  <OPRButton
                    startIcon
                    color="primary"
                    handleClick={addHandleClick}
                    style={{ borderRadius: '110px' }}
                    variant="contained"
                  >
                    {customAdd.length > 0 ? `${customAdd}` : `Add  ${title}` }
                  </OPRButton>
                // extra button
                )}
              </ListHeader>
            </Box>
          )}
          <br />
          <OPRResponsiveGrid>
            {/* <TableHeader
                 item
                 md={2}
                 sm={1}
                 sx={{
                   alignItems: 'center', display: 'flex', flexDirection: 'row', gap: 2,
                 }}
                 xs={1}
               >

                 {filterLayout()}
               </TableHeader> */}

            <TableHeader
              item
              md={3}
              sm={1}
              sx={{
                alignItems: 'center',
                display: 'flex',
                flexDirection: 'row',
                gap: '5px',
              }}
              xs={1}
            >
              {filterLayout()}
            </TableHeader>

            {isSearch && (
              <Grid
                item
                md={1}
                sm={1}
                sx={{
                  display: 'flex',
                  justifyContent: 'end',
                  alignItems: 'center',

                }}

              >
                <Box sx={{
                  width: '280px',
                }}
                >
                  <OPRSearchIcon
                  // name or ID ${title}
                    placeholder="Search "
                    value={searchField}
                    onChange={(e: any) => {
                      const { value } = e.target
                      setSearchField(value)
                      if (value?.length === 0 || e.type === 'submit') {
                        handleSearch(e, { pageNumber: 1, SearchText: e.target.value })
                      }
                    }}
                  />
                </Box>
              </Grid>
            )}
          </OPRResponsiveGrid>
        </>
      )}
      <Box>
        {renderTopButtons()}
        {/* Render the renderTopButtons function */}
      </Box>
      <br />
      <OPRLabel CustomStyles={{ marginBottom: 5 }} variant="body2">
        {dataList.length}
        {' '}
        items
      </OPRLabel>
      <OPRTable
        cols={columns}
        data={dataList}
        handleEdit={handleEdit}
        handleFileDownload={handleFileDownload}
        isLoader={loading}
        isSearchText={isSearchText}
        newOptions={[]}
        orderBy={filterData?.orderByAsc}
        rowClickHandler={rowClickHandler}
        rowNumber={rowNumber}
        sortBy={filterData?.sortBy}
        title={title}
        onRequestSort={sortHandleClick}
      />
      {
        finalCount > 20 && (
          <Box sx={{ display: 'flex', justifyContent: 'center', mt: 2 }}>
            <OPRPagination
              limit={filterData?.pageSize}
              page={filterData?.pageNumber}
              setPage={handlePagination}
              total={finalCount}
            />
          </Box>
        )
      }

    </Container>
  )
})
