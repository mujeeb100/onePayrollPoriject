import '@testing-library/jest-dom/extend-expect'

import { useTheme } from '@emotion/react'
import { fireEvent, render, screen } from '@testing-library/react'
import { useNavigate } from 'react-router'

import { OPRInnerListLayout } from './index'

jest.mock('react-router', () => ({
  useNavigate: jest.fn(),
}))

jest.mock('components/molecules/OPRSearchIcon', () => function OPRSearchIconMock({ placeholder, value, onChange }: any) {
  return <input data-testid="search-icon" placeholder={placeholder} value={value} onChange={onChange} />
})

jest.mock('components/atoms/pagination/OPRPagination', () => function OPRPaginationMock({ page, total }: any) {
  return <div data-testid="pagination">{`Page: ${page}, Total: ${total}`}</div>
})

jest.mock('components/atoms/loader/OPRLoader', () => function OPRLoaderMock({ text }: any) {
  return <div data-testid="custom-loader">{text}</div>
})

const mockTheme = {
  palette: {
    mode: ['light', 'dark'],
    text: { primary: '#000', secondary: '#fff' },
    error: { main: '#f00' },
    Invite: { main: '#f00' },
  },
}

jest.mock('@emotion/react', () => {
  const originalModule = jest.requireActual('@emotion/react')
  return {
    ...originalModule,
    useTheme: jest.fn(),
  }
})

jest.mock('assets/svg-images/SvgComponents', () => ({
  LeftBack: () => <div data-testid="left-back-icon" />,
}))

jest.mock('components/molecules/OPRAlertControl/OPRDeleteControl', () => ({
  OPRDeleteControl: () => <div data-testid="delete-control" />,
}))

jest.mock('react-i18next', () => ({
  useTranslation: () => ({
    t: (key: any) => key,
  }),
}))

describe('OPRInnerListLayout', () => {
  let navigate: jest.Mock<any, any>
  const filterData = { pageSize: 20, pageNumber: 1, totalItems: 100 }
  const renderComponent = (props = {}) => render(<OPRInnerListLayout filterData={filterData} {...props} />)
  beforeEach(() => {
    jest.clearAllMocks()
    navigate = jest.fn();
    (useNavigate as jest.Mock).mockReturnValue(navigate);
    (useTheme as jest.Mock).mockReturnValue(mockTheme)
  })

  test('renders without crashing', () => {
    renderComponent({})
    expect(screen.getByText('Dashboard Page')).toBeInTheDocument()
  })

  test('renders custom title', () => {
    renderComponent({ title: 'Custom Title' })
    expect(screen.getByText('Custom Title')).toBeInTheDocument()
  })

  test('renders with back button and handles click', () => {
    renderComponent({ isBack: true })
    fireEvent.click(screen.getByTestId('left-back-icon'))
    expect(navigate).toHaveBeenCalledWith(-1)
  })

  test('renders with export button and handles click', () => {
    renderComponent({ isExport: true })
    expect(screen.getByTestId('MoreVertIcon')).toBeInTheDocument()
  })

  test('renders with add button and handles click', () => {
    const addHandleClick = jest.fn()
    renderComponent({ isAdd: true, addHandleClick })
    fireEvent.click(screen.getByText('Add Dashboard Page'))
    expect(addHandleClick).toHaveBeenCalled()
  })

  test('renders with search icon and handles change', () => {
    const handleSearch = jest.fn()
    renderComponent({ handleSearch })
    fireEvent.change(screen.getByTestId('search-icon'), { target: { value: 'test' } })
    expect(screen.getByTestId('search-icon')).toHaveValue('test')
  })

  test('renders with pagination', () => {
    renderComponent({})
    expect(screen.getByTestId('pagination')).toHaveTextContent('Page: 1, Total: 100')
  })

  test('renders with table and data', () => {
    const dataList = [{ id: 1 }, { id: 2 }]
    renderComponent({ dataList })
    expect(screen.getByLabelText('simple table')).toBeInTheDocument()
    expect(screen.getByTestId('table-body')).toBeInTheDocument()
    expect(screen.getAllByTestId('table-row').length).toBe(2)
  })

  test('renders with delete control', () => {
    renderComponent({ selelctedUser: { data: {}, isDelete: true, name: 'Test User' } })
    expect(screen.getByTestId('delete-control')).toBeInTheDocument()
  })

  test('renders with error control', () => {
    renderComponent({ isError: true, error: { message: 'Error' } })
    expect(screen.getByText('ErrorIcon.svg')).toBeInTheDocument()
    expect(screen.getByText('ErrorStatus.svg')).toBeInTheDocument()
  })

  test('renders with custom loader', () => {
    renderComponent({ loading: true })
    expect(screen.getByTestId('custom-loader')).toHaveTextContent('Processing request')
  })
})
