// line 99-100 is not tested because it is not called/used in the component
// console error exists
import '@testing-library/jest-dom/extend-expect'

import { useTheme } from '@emotion/react'
import { fireEvent, render, screen } from '@testing-library/react'
import { useModal } from 'hooks/useModal'
import React from 'react'
import { Provider } from 'react-redux'
import { useLocation, useNavigate } from 'react-router-dom'

import OPRAlertControl from './index'

const creaeMonthEndClosing = jest.fn()

const mockPayrollMonthEndClosingCreateMutation = [
  creaeMonthEndClosing,
  {
    status: 'uninitialized',
    isUninitialized: true,
    isLoading: false,
    isSuccess: false,
    isError: false,
    originalArgs: undefined,
    reset: [jest.fn()],
  },
]

const mockEntityProfileByIdResponse = {
  status: 'pending',
  isUninitialized: false,
  isLoading: true,
  isSuccess: false,
  isError: false,
  data: undefined,
  currentData: undefined,
  isFetching: true,
  refetch: jest.fn(),
}

jest.mock('api/entityServices', () => ({
  useGetAllEntityProfileSelectedListByIdQuery: () => mockEntityProfileByIdResponse,
}))

jest.mock('api/payRollServices', () => ({
  usePayrollMonthEndClosingCreateMutation: () => mockPayrollMonthEndClosingCreateMutation,
}))

jest.mock('@emotion/react', () => {
  const originalModule = jest.requireActual('@emotion/react')
  return {
    ...originalModule,
    useTheme: jest.fn(),
  }
})

jest.mock('hooks/useModal', () => ({
  useModal: jest.fn(),
}))

jest.mock('react-router-dom', () => ({
  useNavigate: jest.fn(),
  useLocation: jest.fn(),
}))

describe('OPRAlertControl Component', () => {
  let toggle: jest.Mock<any, any>
  let mockNavigate: jest.Mock<any, any>
  const mockTheme = {
    palette: {
      Invite: {
        main: '#000',
      },
      error: { main: '#f00' },
    },
  }

  beforeEach(() => {
    toggle = jest.fn()
    mockNavigate = jest.fn();
    (useTheme as jest.Mock).mockReturnValue(mockTheme);
    (useModal as jest.Mock).mockReturnValue({ isToggele: false, toggle });
    (useNavigate as jest.Mock).mockReturnValue(mockNavigate);
    (useLocation as jest.Mock).mockReturnValue({ pathname: '/test-path' })
    //   mockIdData.data = [
    //     {
    //       id: 1,
    //       name: 'Leanne Graham',
    //       entityName: 'Bret',
    //       email: 'Sincere@april.biz',
    //       phone: '1-770-736-8031 x56442',
    //       entityCode: 'hildegard',
    //       isSystemAdmin: false,
    //     },
    //     {
    //       id: 2,
    //       name: 'Ervin Howell',
    //       entityName: 'Antonette',
    //       email: 'Shanna@melissa.tv',
    //       phone: '010-692-6593 x09125',
    //       entityCode: 'anastasia',
    //       isSystemAdmin: true,
    //     },
    //   ]
  })

  afterEach(() => {
    jest.clearAllMocks()
  })

  const defaultProps = {
    title: 'Test Title',
    handleEditable: jest.fn(),
    isSuccess: false,
    isCustom: false,
    isCustomError: false,
    customTitle: 'Custom Title',
    setIsSuccessPayCycle: jest.fn(),
    customMessage: 'Custom Message',
    name: 'Test Name',
    isCancelPayCycleAlert: false,
    IsCancelMonthEndAlert: false,
    handleCancelPayCycleAlert: jest.fn(),
    updatedPayCyleName: 'Updated Pay Cycle Name',
    handleCloseMonthEnd: jest.fn(),
    handleConfirmMonthEnd: jest.fn(),
    handleSubmit: jest.fn(),
    handleSetValue: jest.fn(),
    isEntity: false,
    isLoading: false,
    error: {
      status: 500,
      data: {
        errors: [{ code: 'error_code', message: 'error_message' }],
      },
    },
    isError: false,
    callBack: jest.fn(),
    type: 'New',
    previousUrl: '/previous',
    isCancel: false,
    handleCancel: jest.fn(),
    customBack: jest.fn(),
    addAnother: true,
  }

  const renderComponent = (props = {}) => {
    const mockStore = {
      getState: () => ({
        entityService: {
          data: [],
          isLoading: false,
          isError: false,
        },
        // Provide the initial state for the mock store
        someState: 'mockState',
      }),
      subscribe: jest.fn(),
      dispatch: jest.fn(),
      replaceReducer: jest.fn(),
      [Symbol.observable]: jest.fn(() => ({
        subscribe: jest.fn(),
        [Symbol.observable]: jest.fn(),
      })),
    }
    return (render(
      <Provider store={mockStore}>
        <OPRAlertControl {...defaultProps} {...props} />
      </Provider>,
    ))
  }
  it('should not render anything if nothing provided', () => {
    renderComponent()
    expect(screen.queryByRole('presentation')).not.toBeInTheDocument()
  })

  it('displays the loader when isLoading is true', () => {
    renderComponent({ isLoading: true })
    expect(screen.queryAllByRole('presentation')[0]).toBeInTheDocument()
    expect(screen.getAllByText('Processing request')[0]).toBeInTheDocument()
  })

  it('renders success dialog correctly', () => {
    renderComponent({ isSuccess: true })
    expect(screen.getByText('Custom Title')).toBeInTheDocument()

    const addAnotherButton = screen.getByText('Add Another')
    fireEvent.click(addAnotherButton)
    expect(defaultProps.handleSetValue).toHaveBeenCalled()

    const closeButton = screen.getByText('Close')
    fireEvent.click(closeButton)
    expect(defaultProps.callBack).toHaveBeenCalled()
  })

  it('calls toggle and navigate on Confirm button click', () => {
    (useModal as jest.Mock).mockReturnValue({ isToggele: true, toggle })

    renderComponent()
    expect(screen.getByText('Are you sure you want to quit?')).toBeInTheDocument()
    expect(screen.getByText('Are you sure you want to quit without saving your changes? Any unsaved progress will be lost.')).toBeInTheDocument()
    const confirmButton = screen.getByText('Confirm')
    fireEvent.click(confirmButton)
    // expect(toggle).toHaveBeenCalledWith(false) // don't know why this is not working

    const cancelButton = screen.getByText('Cancel')
    fireEvent.click(cancelButton)
    expect(mockNavigate).toHaveBeenCalledWith(-1)
  })

  it('displays custom error message when isCustomError is true', () => {
    renderComponent({ isCustomError: true, isError: true })
    expect(screen.getByText('ErrorIcon.svg')).toBeInTheDocument()
    expect(screen.getByText('Error Code : 500')).toBeInTheDocument()

    const tryAgainButton = screen.getByText('Try Again')
    fireEvent.click(tryAgainButton)
    expect(defaultProps.handleSubmit).toHaveBeenCalled()

    const backButton = screen.getByText('Back')
    fireEvent.click(backButton)
    expect(defaultProps.customBack).toHaveBeenCalled()

    const closeButton = screen.getByText('Close')
    fireEvent.click(closeButton)
    expect(toggle).toHaveBeenCalled()
  })

  it('displays the cancel alert when isCancel is true', () => {
    renderComponent({ isCancel: true })
    expect(screen.getByText('Are you sure you want to quit?')).toBeInTheDocument()
    expect(screen.getByText('Are you sure you want to quit without saving your changes? Any unsaved progress will be lost.')).toBeInTheDocument()
    const confirmButton = screen.getByText('Confirm')
    fireEvent.click(confirmButton)
    expect(defaultProps.callBack).toHaveBeenCalled()

    const backButton = screen.getByText('Back')
    fireEvent.click(backButton)
    expect(defaultProps.handleCancel).toHaveBeenCalledWith(false)

    const cancelButton = screen.getByText('Cancel')
    fireEvent.click(cancelButton)
    expect(defaultProps.handleCancel).toHaveBeenCalled()
  })

  it('displays the pay cycle alert when isCancelPayCycleAlert is true', () => {
    renderComponent({ isCancelPayCycleAlert: true })
    expect(screen.getByText('Are you sure you want to Test Title')).toBeInTheDocument()
    expect(screen.getByText('Test Name will be Test Title.')).toBeInTheDocument()
    const confirmButton = screen.getByText('Confirm')
    fireEvent.click(confirmButton)
    expect(defaultProps.callBack).toHaveBeenCalled()

    const cancelButton = screen.getByText('Cancel')
    fireEvent.click(cancelButton)
    expect(defaultProps.handleCancelPayCycleAlert).toHaveBeenCalled()
  })

  it('displays the month end closing alert when IsCancelMonthEndAlert is true', () => {
    renderComponent({ IsCancelMonthEndAlert: true })
    expect(screen.getByText('Test Title Confirmation')).toBeInTheDocument()
    expect(screen.getByText('Are you sure you want to proceed with the month-end closing process for ?')).toBeInTheDocument()
    expect(screen.getByText('You will not be able to revert it.')).toBeInTheDocument()
    expect(screen.getByText('Please note that there are a few pay cycles for that have not been finalized yet.')).toBeInTheDocument()
    const confirmButton = screen.getByText('Confirm check') // component is changed. button text is changed.
    fireEvent.click(confirmButton)
    // expect(defaultProps.monthClosingData).toHaveBeenCalled() // prop is not called in component

    const cancelButton = screen.getByText('Cancel')
    fireEvent.click(cancelButton)
    // expect(defaultProps.onClose).toHaveBeenCalled() // prop is not in the component

    const showButton = screen.getByText('Show pay cycles')
    fireEvent.click(showButton)
    expect(defaultProps.handleCloseMonthEnd).toHaveBeenCalled()
  })
})
