import { useTheme } from '@emotion/react'
import {
  Box,
} from '@mui/material'
import { Info } from 'assets/svg-images/SvgComponents'
import OPRButton from 'components/atoms/button/OPRButton'
import OPRLabel from 'components/atoms/label/OPRLabel'
import CustomLoader from 'components/atoms/loader/OPRLoader'
import { CustomDialog } from 'components/atoms/modal/OPRModal'
import CancelAlert from 'components/molecules/OPRAlertControl/CancelAlert'
import OPRErrorAlertControl from 'components/molecules/OPRAlertControl/OPRErrorControl'
import { OPRSuccesControl } from 'components/molecules/OPRAlertControl/OPRSuccesControl'
import PayCycleAlert from 'components/molecules/OPRAlertControl/PyaCycleAdminAlert'
import { useModal } from 'hooks/useModal'
import { t } from 'i18next'
import MonthEndClosingAlert from 'pages/payroll/payrollMonthEndClosing/MonthEndClosingAlert'
import { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'

type Props = {
        title?:string,
        customTitle?:string,
        customMessage?:any,
        handleSubmit ?: (item:any) => void;
        handleSetValue ?: any;
        handleEditable?:any;
        callBack ?: (type:any) => void;
        isCustom?:boolean,
        isCustomError?:boolean,
        customBack?: () => void;
        isLoading?:boolean
        isEntity?:boolean
        isError?:any,
        error?:any
        isSuccess?:boolean
        name?:any
        type?:string,
        previousUrl?:string
        isCancel?:boolean
        handleCancel?:any
         // for pay cycle master start
        isCancelPayCycleAlert?:boolean
        handleCancelPayCycleAlert?:any
        updatedPayCyleName?:any
        setIsSuccessPayCycle?:any
         // for pay cycle master end
        //  payroll mont and closing start
        IsCancelMonthEndAlert?:boolean
        handleCloseMonthEnd?:any
        handleConfirmMonthEnd?:any
        addAnother?:any
         //  payroll mont and closing end
      };

function OPRAlertControl({
  title = '',
  handleEditable,
  isSuccess = false,
  isCustom = false,
  isCustomError = false,
  customTitle,
  setIsSuccessPayCycle,
  customMessage,
  name,
  // for pay cycle master start
  isCancelPayCycleAlert,
  IsCancelMonthEndAlert,
  handleCancelPayCycleAlert,
  updatedPayCyleName,
  handleCloseMonthEnd,
  handleConfirmMonthEnd,
  // for pay cycle master end
  handleSubmit,
  handleSetValue,
  isEntity = false,
  isLoading = false,
  error,
  isError = false,
  callBack,
  type = 'New',
  previousUrl,
  isCancel = false,
  handleCancel = () => {},
  customBack = () => {},
  addAnother = true,
  ...rest
}: Props) {
  const theme:any = useTheme() // Use the Theme type for the theme variable
  const {
    isToggele,
    toggle,
  }:any = useModal()
  const [loader, setLoader] = useState(false)
  const navigate = useNavigate()
  useEffect(() => {
    setLoader(isLoading)
  }, [isLoading])
  const handleBack = () => {
    handleEditable(true)
    handleSetValue(false)
  }
  return (
    <Box>
      <CustomDialog
        CustomStyles={{ borderRadius: '16px' }}
        callBack={callBack}
        isOpen={loader}
        type="loader"
      >
        <CustomLoader text="Processing request" />
      </CustomDialog>
      <OPRSuccesControl
        addAnother={addAnother}
        callBack={callBack}
        customMessage={customMessage}
        customTitle={customTitle}
        isCustom={isCustom}
        isEntity={isEntity}
        isSuccess={isSuccess}
        name={name}
        payCycleUpdatedName={updatedPayCyleName}
        setIsSuccessPayCycle={setIsSuccessPayCycle}
        title={t(title)}
        type={type}
        onEditable={handleEditable}
        onSetValue={handleSetValue}
      />
      <OPRErrorAlertControl
        callBack={() => {
          const isFunction = typeof callBack === 'function'
          // previousUrl ? navigate(previousUrl) :
          // if (previousUrl) {
          //   navigate(`/${previousUrl}`)
          // } else {
          //   handleBack()
          // }

          // handleEditable(false)
          // handleEditable(false)
          toggle(true)
        }}
        customBack={customBack}
        error={error}
        handleSubmit={handleSubmit}
        isCustomError={isCustomError}
        isError={isError}
        name={t(title)}
        onEditable={handleEditable}
        onSetValue={handleSetValue}
      />
      <CustomDialog
        CustomStyles={{ borderRadius: '16px' }}
        isOpen={isLoading}
        type="loader"
      >
        <CustomLoader text="Processing request" />
      </CustomDialog>
      <CustomDialog
        CustomStyles={{ borderRadius: '16px' }}
        isOpen={isToggele}
        type="loader"
      >
        <div style={{ marginBottom: '15px' }}>
          <OPRLabel variant="h4">
            Are you sure you want to quit?
          </OPRLabel>
        </div>
        <Box
          className="pop-up"
          sx={{
            display: 'flex',
            padding: '12px',
            gap: '12px',
            alignItems: 'flex-start',
            borderRadius: '4px',
            alignSelf: 'stretch',
            backgroundColor: `${theme.palette.Invite.main}`,
            marginTop: 1,
          }}
        >
          <Info />
          <OPRLabel
            CustomStyles={{
              backgroundColor: `${theme.palette.Invite.main}`,
            }}
            backgroundColor={theme.palette.Invite.main}
            variant="body2"
          >
            Are you sure you want to quit without saving your changes? Any unsaved progress will be lost.
          </OPRLabel>
        </Box>
        <Box sx={{
          display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: 5,
        }}
        >
          <OPRButton color="info" variant="text" onClick={() => toggle(false)}>
            Cancel
          </OPRButton>
          <OPRButton
            color="info"
            variant="text"
            onClick={() => {
              navigate(-1)
            }}
          >
            Confirm
          </OPRButton>
        </Box>
      </CustomDialog>
      <CancelAlert
        callBack={callBack}
        handleCancel={handleCancel}
        isCancel={isCancel}
      />
      <PayCycleAlert
        callBack={callBack}
        handleCancelPayCycleAlert={handleCancelPayCycleAlert}
        isCancelPayCycleAlert={isCancelPayCycleAlert}
        name={name}
        title={title}
      />

      <MonthEndClosingAlert
        IsCancelMonthEndAlert={IsCancelMonthEndAlert}
        callBack={callBack}
        handleCloseMonthEnd={handleCloseMonthEnd}
        handleConfirmMonthEnd={handleConfirmMonthEnd} // Added this prop
        title={title}
      />
    </Box>
  )
}

export default OPRAlertControl
