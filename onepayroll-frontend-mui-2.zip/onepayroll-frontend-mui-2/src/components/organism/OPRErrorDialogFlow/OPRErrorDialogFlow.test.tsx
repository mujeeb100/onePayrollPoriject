// coverage not complete
import '@testing-library/jest-dom/extend-expect'

import { fireEvent, render, screen } from '@testing-library/react'
import { OPRConfirmationDialogProps } from 'components/molecules/OPRAlertControl/OPRConfirmationDialog'

import OPRErrorDialogFlow from './index'

jest.mock('i18next', () => ({
  t: jest.fn((key) => key),
}))

// jest.mock('components/molecules/OPRAlertControl/OPRConfirmationDialog', () => ({
//   OPRConfirmationDialog: jest.fn(({
//     open, title, infoMessage, onConfirm, onCancel, onClose,
//   }) => (
//     <div>
//       {open && (
//         <div role="dialog">
//           <h1>{title}</h1>
//           <p>{infoMessage}</p>
//           <button onClick={onConfirm}>Confirm</button>
//           <button onClick={onCancel}>Cancel</button>
//           {onClose && <button onClick={onClose}>Close</button>}
//         </div>
//       )}
//     </div>
//   )),
// }))

describe('OPRErrorDialogFlow Component', () => {
  const defaultDialogProps: OPRConfirmationDialogProps = {
    open: false,
    title: 'Test Title',
    buttonLayout: 'confirm',
    infoMessage: 'Test Info Message',
    onConfirm: jest.fn(),
    onCancel: jest.fn(),
    onClose: undefined,
  }

  const setDialogProps = jest.fn()

  const renderComponent = (props = {}) => render(
    <OPRErrorDialogFlow
      dialogProps={defaultDialogProps}
      setDialogProps={setDialogProps}
      {...props}
    />,
  )

  it('does not render if nothing is provided', () => {
    renderComponent()
    expect(screen.queryAllByText('Test Title')).toHaveLength(0)
    expect(screen.queryAllByText('Test Info Message')).toHaveLength(0)
    expect(screen.queryAllByRole('presentation')).toHaveLength(0)
  })

  it('renders the dialog when open is true', () => {
    renderComponent({ dialogProps: { ...defaultDialogProps, open: true } })
    expect(screen.queryAllByText('Test Title')).not.toHaveLength(0)
    expect(screen.queryAllByText('Test Info Message')).not.toHaveLength(0)
    expect(screen.queryAllByRole('presentation')).not.toHaveLength(0)
    expect(screen.getByTestId('cancel-button')).toBeInTheDocument()
    expect(screen.getByTestId('confirm-button')).toBeInTheDocument()
  })

  it('opens the confirmation dialog when onClose is called', () => {
    renderComponent({ dialogProps: { ...defaultDialogProps, open: true } })
    const cancelButton = screen.getByTestId('cancel-button')
    fireEvent.click(cancelButton)
    expect(defaultDialogProps.onCancel).toHaveBeenCalled()
  })

  it('calls onConfirm and closes the dialog', () => {
    renderComponent({ dialogProps: { ...defaultDialogProps, open: true } })
    fireEvent.click(screen.getByTestId('confirm-button'))
    expect(defaultDialogProps.onConfirm).toHaveBeenCalled()
  })

  it('displays default confirmation message when not provided', () => {
    const customConfirmation = {
      title: 'Custom Title',
      infoMessage: 'Custom Info Message',
    }
    const onClose = jest.fn()
    renderComponent({
      dialogProps: {
        ...defaultDialogProps, open: true, buttonLayout: 'close', onClose,
      },
      confirmation: customConfirmation,
    })
    fireEvent.click(screen.getByTestId('close-button'))
    expect(onClose).toHaveBeenCalled()
  })
})
