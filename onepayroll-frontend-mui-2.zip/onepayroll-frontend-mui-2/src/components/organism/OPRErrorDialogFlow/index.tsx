import {
  Box,
} from '@mui/material'
import { OPRConfirmationDialog, OPRConfirmationDialogProps } from 'components/molecules/OPRAlertControl/OPRConfirmationDialog'
import { t } from 'i18next'
import { useState } from 'react'

type OPRErrorDialogFlowProps = {
  dialogProps: OPRConfirmationDialogProps
  setDialogProps: (value: OPRConfirmationDialogProps) => void
  confirmation?: {
    title?: React.ReactNode | string,
    infoMessage?: React.ReactNode | string,
  }
}

function OPRErrorDialogFlow(props: OPRErrorDialogFlowProps) {
  const { dialogProps, setDialogProps, confirmation = {} } = props
  const [confirmationDialog, setConfirmationDialog] = useState<OPRConfirmationDialogProps>({
    open: false,
    title: confirmation.title || t('Are you sure you want to quit?'),
    buttonLayout: 'confirm',
    infoMessage: confirmation.infoMessage || t('Are you sure you want to quit without saving your changes? Any unsaved progress will be lost. '),
    onConfirm: () => {
      setConfirmationDialog({ ...confirmationDialog, open: false })
      setDialogProps({ ...dialogProps, open: false })
    },
    onCancel: () => {
      setConfirmationDialog({ ...confirmationDialog, open: false })
    },
  })
  return (
    <Box>
      <OPRConfirmationDialog
        {...dialogProps}
        onClose={() => {
          if (dialogProps.onClose) {
            dialogProps.onClose()
          } else {
            setConfirmationDialog({ ...confirmationDialog, open: true })
          }
        }}
      />

      <OPRConfirmationDialog
        {...confirmationDialog}
      />
    </Box>
  )
}

export default OPRErrorDialogFlow
