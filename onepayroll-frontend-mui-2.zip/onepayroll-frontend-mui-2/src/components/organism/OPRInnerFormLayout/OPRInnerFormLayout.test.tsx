import '@testing-library/jest-dom/extend-expect'

import { useTheme } from '@emotion/react'
import { fireEvent, render, screen } from '@testing-library/react'
import { useModal } from 'hooks/useModal'
import { t } from 'i18next'
import React from 'react'
import { useLocation, useNavigate } from 'react-router'
import { getParamsValue } from 'utils'

import { OPRInnerFormLayout } from './index'

jest.mock('i18next', () => ({
  t: jest.fn(),
}))

jest.mock('react-router', () => ({
  useLocation: jest.fn(),
  useNavigate: jest.fn(),
}))

jest.mock('@emotion/react', () => {
  const originalModule = jest.requireActual('@emotion/react')
  return {
    ...originalModule,
    useTheme: jest.fn(),
  }
})

jest.mock('hooks/useModal', () => ({
  useModal: jest.fn(),
}))

jest.mock('utils', () => ({
  getParamsValue: jest.fn(),
}))

jest.mock('assets/svg-images/SvgComponents', () => ({
  Info: () => <div data-testid="info-icon" />,
  LeftBack: () => <div data-testid="left-back-icon" />,
  LeftCaret: () => <div data-testid="left-caret-icon" />,
  RighCaretBlue: () => <div data-testid="right-caret-blue-icon" />,
}))

describe('OPRInnerFormLayout', () => {
  let navigate: jest.Mock<any, any>
  let location
  let theme
  let toggle: jest.Mock<any, any>

  beforeEach(() => {
    navigate = jest.fn()
    location = { pathname: '/test' }
    theme = { palette: { Invite: { main: '#fff' } } }
    toggle = jest.fn();
    (t as unknown as jest.Mock).mockImplementation((key) => key);
    (useNavigate as jest.Mock).mockReturnValue(navigate);
    (useLocation as jest.Mock).mockReturnValue(location);
    (useTheme as jest.Mock).mockReturnValue(theme);
    (getParamsValue as jest.Mock).mockReturnValue({ viewUrl: false, id: '123' });
    (useModal as jest.Mock).mockReturnValue({ isToggele: false, toggle })
  })

  test('renders without crashing', () => {
    render(<OPRInnerFormLayout />)
    expect(screen.getByText('Dashboard Page')).toBeInTheDocument()
  })

  test('closes custom dialog on cancel button click', () => {
    (useModal as jest.Mock).mockReturnValue({ isToggele: true, toggle })
    render(<OPRInnerFormLayout />)
    expect(screen.getAllByText('Cancel')).toHaveLength(2)
    fireEvent.click(screen.getAllByText('Cancel')[1])
    expect(toggle).toHaveBeenCalledWith(false)
  })

  test('opens custom dialog on cancel button click', () => {
    (useModal as jest.Mock).mockReturnValue({ isToggele: false, toggle })
    render(<OPRInnerFormLayout />)
    expect(screen.getAllByText('Cancel')).toHaveLength(1)
    fireEvent.click(screen.getAllByText('Cancel')[0])
    expect(toggle).toHaveBeenCalledWith(true)
  })

  test('navigates to previous page on confirm button click', () => {
    (useModal as jest.Mock).mockReturnValue({ isToggele: true, toggle })
    render(<OPRInnerFormLayout />)
    fireEvent.click(screen.getByText('Confirm'))
    expect(navigate).toHaveBeenCalledWith(-1)
  })

  test('navigates to given previous page url on confirm button click', () => {
    (useModal as jest.Mock).mockReturnValue({ isToggele: true, toggle })
    render(<OPRInnerFormLayout previousPageUrl="test123" />)
    fireEvent.click(screen.getByText('Confirm'))
    expect(navigate).toHaveBeenCalledWith('/test123')
  })

  test('navigates to previous page on back button click', () => {
    render(<OPRInnerFormLayout />)
    fireEvent.click(screen.getByTestId('left-back-icon'))
    expect(navigate).toHaveBeenCalledWith(-1)
  })

  test('renders with correct default title if isBack', () => {
    render(<OPRInnerFormLayout title="Back Test Title" />)
    const title = screen.getByText('Back Test Title')
    expect(title).toBeInTheDocument()
  })

  test('renders with correct custom title if isBack', () => {
    render(<OPRInnerFormLayout customTitle="Custom Test" title="Back Test Title" />)
    const title = screen.getByText((content, element) => element?.tagName.toLowerCase() === 'h2' && content.includes('Add Back Test Title'))
    expect(title).toBeInTheDocument()
  })

  test('handleEditable is called if isStepper is false and isBackButton is true on back button click', () => {
    const handleEditable = jest.fn()
    render(<OPRInnerFormLayout isBackButton handleEditable={handleEditable} />)
    fireEvent.click(screen.getByTestId('right-caret-blue-icon'))
    expect(handleEditable).toHaveBeenCalledWith(false)
  })

  test('handle edit is called with false if isStepper is true and isBackButton is true on back button click', () => {
    const handleBack = jest.fn()
    render(<OPRInnerFormLayout isBackButton isStepper handleBack={handleBack} />)
    fireEvent.click(screen.getByTestId('right-caret-blue-icon'))
    expect(handleBack).toHaveBeenCalled()
  })

  test('renders custom header if provided', () => {
    render(<OPRInnerFormLayout customHeader={<div>Custom Header</div>} />)
    expect(screen.getByText('Custom Header')).toBeInTheDocument()
  })

  test('renders children content', () => {
    render(<OPRInnerFormLayout><div>Child Content</div></OPRInnerFormLayout>)
    expect(screen.getByText('Child Content')).toBeInTheDocument()
  })

  test('handles add date button click', () => {
    const handleAddDate = jest.fn()
    render(<OPRInnerFormLayout isAddDate handleAddDate={handleAddDate} />)
    fireEvent.click(screen.getByText('Add Dates'))
    expect(handleAddDate).toHaveBeenCalled()
  })

  test('handles add user button click', () => {
    const handleAddUser = jest.fn()
    render(<OPRInnerFormLayout isAddUser isEditUser handleAddUser={handleAddUser} />)
    fireEvent.click(screen.getByText('Add user'))
    expect(handleAddUser).toHaveBeenCalled()
  })

  test('handles edit user button click', () => {
    const handleUserCreate = jest.fn()
    render(<OPRInnerFormLayout isEditUser handleUserCreate={handleUserCreate} />)
    fireEvent.click(screen.getByText('Edit Dashboard Page'))
    expect(handleUserCreate).toHaveBeenCalled()
  })

  test('handles continue click', () => {
    const handleContinueClick = jest.fn()
    render(<OPRInnerFormLayout isStepper handleContinueClick={handleContinueClick} />)
    const leftCaret = screen.getByTestId('left-caret-icon')
    expect(screen.getByText('Continue')).toBeInTheDocument()
    fireEvent.click(leftCaret)
    expect(handleContinueClick).toHaveBeenCalled()
  })

  test('render with correct text', () => {
    render(<OPRInnerFormLayout isConfirm isStepper />)
    expect(screen.getByText('Confirm')).toBeInTheDocument()
  })

  test('edit button is not available if isEditable is false', () => {
    render(<OPRInnerFormLayout isEditUser isEditable={false} />)
    expect(screen.queryAllByText('Edit Dashboard Page')).toHaveLength(0)
  })

  test('renders correct default title with isEditable', () => {
    render(<OPRInnerFormLayout isEditUser isEditable customTitle="Custom Test Title" />)
    const title = screen.getByText('Edit Custom Test Title')
    expect(title).toBeInTheDocument()
  })

  test('handle continue click if isHandleContinueClick', () => {
    const handleContinueClick = jest.fn()
    render(<OPRInnerFormLayout isHandleContinueClick handleContinueClick={handleContinueClick} />)
    fireEvent.click(screen.getByText('Continue'))
    expect(handleContinueClick).toHaveBeenCalled
  })

  test('renders when urlId', () => {
    (getParamsValue as jest.Mock).mockReturnValue({ viewUrl: true, id: '123' })

    render(<OPRInnerFormLayout />)
    expect(screen.queryAllByTestId('left-caret-icon')).toHaveLength(0)
  })
})
