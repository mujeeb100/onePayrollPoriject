import { useTheme } from '@emotion/react'
import {
  Box,
  Container,
} from '@mui/material'
import {
  Info, LeftBack, LeftCaret, RighCaretBlue,
} from 'assets/svg-images/SvgComponents'
import OPRButton from 'components/atoms/button/OPRButton'
import OPRLabel from 'components/atoms/label/OPRLabel'
import { CustomDialog } from 'components/atoms/modal/OPRModal'
import { useModal } from 'hooks/useModal'
import { t } from 'i18next'
import { useLocation, useNavigate } from 'react-router'
import { routes } from 'routes/routes'
import { getParamsValue } from 'utils'

export function OPRInnerFormLayout({
  isAddUser = false,
  isAddDate = false,
  isBack = false,
  isBackButton = false,
  isConfirm = false,
  title = 'Dashboard Page',
  pageType = 'detailsPage',
  customHeader = null,
  subtitle = 'All field to mandatory expect those mark optional',
  children = <h1>All field to mandatory expect those mark optional</h1>,
  handleCancelClick = () => { },
  handleContinueClick = (type:any) => { },
  isHandleContinueClick = false,
  isLoading = false,
  customTitle = '',
  isStepper = false,
  handleBack = (type:any) => { },
  handleEditable = (type:any) => { },
  onScreenClose = () => {},
  error = {},
  isEditable = true,
  isHeader = true,
  previousPageUrl,
  isEditUser = false,
  handleUserCreate,
  handleAddUser,
  handleAddDate,
  showbottomButton = true,
  isConfirmationBtn = false,
}:any) {
  const location: any = useLocation()
  const navigate = useNavigate()
  const { viewUrl, id } = getParamsValue(location, routes.createCountry)

  const {
    isToggele,
    toggle,
  }:any = useModal()
  const theme:any = useTheme() // Use the Theme type for the theme variable

  return (
    <Container>
      <CustomDialog
        CustomStyles={{ borderRadius: '16px' }}
        isOpen={isToggele}
        type="loader"
      >
        <div style={{ marginBottom: '15px' }}>
          <OPRLabel variant="h4">
            Are you sure you want to quit?
          </OPRLabel>
        </div>
        <Box
          className="pop-up"
          sx={{
            display: 'flex',
            padding: '12px',
            gap: '12px',
            alignItems: 'flex-start',
            borderRadius: '4px',
            alignSelf: 'stretch',
            backgroundColor: `${theme.palette.Invite.main}`,
            marginTop: 1,
          }}
        >
          <Info />
          <OPRLabel
            CustomStyles={{
              backgroundColor: `${theme.palette.Invite.main}`,
            }}
            backgroundColor={theme.palette.Invite.main}
            variant="body2"
          >
            Are you sure you want to quit without saving your changes? Any unsaved progress will be lost.
          </OPRLabel>
        </Box>
        <Box sx={{
          display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: 5,
        }}
        >
          <OPRButton color="info" variant="text" onClick={() => toggle(false)}>
            Cancel
          </OPRButton>
          <OPRButton
            color="primary"
            variant="contained"
            onClick={() => {
              previousPageUrl ? navigate(`/${previousPageUrl}`)
                : navigate(-1)
            }}
          >
            Confirm
          </OPRButton>
        </Box>
      </CustomDialog>
      {
        !isLoading && (
          <>
            {
              customHeader || (
                isHeader && (
                  <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                    <Box>
                      <Box sx={{
                        display: 'flex', justifyContent: 'flex-start', alignItems: 'center', gap: '25px',
                      }}
                      >
                        {!isBack && (
                          <Box
                            component="div"
                            onClick={() => navigate(-1)}
                          >
                            <LeftBack />
                          </Box>
                        )}
                        <OPRLabel variant="h2">
                          {customTitle?.length > 0 && 'Add'}
                          {' '}
                          {` ${t(title)}`}
                        </OPRLabel>
                      </Box>
                      <Box sx={{
                        display: 'flex', justifyContent: 'flex-start', mb: 7, mt: 1,
                      }}
                      >

                        <OPRLabel variant="body2">

                          {`  ${subtitle}`}
                        </OPRLabel>
                      </Box>
                    </Box>
                    {isAddDate && (
                      <OPRButton
                        color="primary"
                        handleClick={() => {
                          handleAddDate()
                        }}
                        style={{ borderRadius: '110px', marginLeft: '10px' }}
                        variant="contained"
                      >
                        Add Dates
                      </OPRButton>
                    )}
                    {
                      isEditUser && (
                        <Box sx={{
                          display: 'flex', justifyContent: 'flex-start', mb: 7, mt: 1,
                        }}
                        >
                          { isEditable ? (
                            <OPRButton
                              color="primary"
                              handleClick={() => {
                                handleUserCreate()
                              }}
                              style={{ borderRadius: '110px' }}
                              variant="outlined"
                            >
                              Edit
                              {' '}
                              {customTitle?.length > 0 ? customTitle : title}
                            </OPRButton>
                          ) : null}
                          {isAddUser && (
                            <OPRButton
                              color="primary"
                              handleClick={() => {
                                handleAddUser()
                              }}
                              style={{ borderRadius: '110px', marginLeft: '10px' }}
                              variant="contained"
                            >
                              Add user
                            </OPRButton>
                          )}
                        </Box>
                      )
                    }
                  </Box>
                )
              )
            }
            <Box>
              {children}
            </Box>

            {
              viewUrl ? null : (
                !isBack && (
                  <Box sx={{
                    display: 'flex', alignItems: 'center', flexDirection: 'row', justifyContent: 'space-between', mt: 6,
                  }}
                  >
                    <OPRButton color="info" variant="text" onClick={() => toggle(true)}>
                      Cancel
                    </OPRButton>
                    {isBackButton && (
                      <OPRButton
                        style={{ marginLeft: 'auto' }}
                        variant="text"
                        onClick={() => {
                          isStepper ? handleBack() : handleEditable(false)
                        }}
                      >
                        <RighCaretBlue />
                        Back
                      </OPRButton>
                    )}
                    {isStepper ? (
                      <OPRButton
                        handleClick={(e) => handleContinueClick(e)}
                        type="submit"
                        variant="contained"
                      >
                        {isConfirm ? 'Confirm' : 'Continue'}
                        <LeftCaret />
                      </OPRButton>
                    ) : (
                      <OPRButton
                        handleClick={isHandleContinueClick ? handleContinueClick : () => {
                        }}
                        type="submit"
                        variant="contained"
                      >
                        {isConfirm || isBackButton ? 'Confirm' : 'Continue'}
                        <LeftCaret />
                      </OPRButton>
                    )}
                  </Box>
                )
              )
            }
          </>
        )
      }

    </Container>

  )
}
