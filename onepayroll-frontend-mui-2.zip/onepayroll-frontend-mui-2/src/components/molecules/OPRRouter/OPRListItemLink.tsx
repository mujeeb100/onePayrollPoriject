import KeyboardArrowRightIcon from '@mui/icons-material/KeyboardArrowRight'
import {
  ListItemButton, ListItemIcon, ListItemText,
} from '@mui/material'
import { OPRListItemLinkProps } from 'interfaces/OPRListItemLinkProps'
import React from 'react'
import { useTranslation } from 'react-i18next'
import {
  Link as RouterLink,
  LinkProps as RouterLinkProps,
} from 'react-router-dom'

const Link = React.forwardRef<HTMLAnchorElement, RouterLinkProps>((
  itemProps,
  ref,
) => <RouterLink ref={ref} {...itemProps} role={undefined} />)

export function OPRListItemLink(props: OPRListItemLinkProps) {
  const {
    icon, primary, to, onClick, sx, hasChild, ...rest
  } = props
  // react-dom.development.js:86 Warning: Internal React error: Expected static flag was missing. Please notify the React team.
  // This t function causing above warning in terminal
  const { t } = useTranslation()
  return (
    <li className="side-bar-menu">
      <ListItemButton component={Link} sx={sx} to={to} onClick={onClick} {...rest}>
        {icon ? <ListItemIcon className="side-icon">{icon}</ListItemIcon> : null}
        <ListItemText primary={t(primary)} />
        {hasChild && <KeyboardArrowRightIcon sx={{ opacity: 0.5 }} />}
      </ListItemButton>
    </li>
  )
}
