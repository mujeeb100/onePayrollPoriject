import '@testing-library/jest-dom/extend-expect'

import { ListItemIcon } from '@mui/material'
import { fireEvent, render, screen } from '@testing-library/react'
import { MemoryRouter } from 'react-router-dom'

import { OPRListItemLink } from './OPRListItemLink' // Adjust the import path as necessary

// Mock the useTranslation hook
jest.mock('react-i18next', () => ({
  useTranslation: () => ({
    t: (key: string) => key,
  }),
}))

describe('OPRListItemLink Component', () => {
  const mockOnClick = jest.fn()

  const setup = (props = {}) => render(
    <MemoryRouter>
      <OPRListItemLink
        primary="test-primary"
        to="/test"
        onClick={mockOnClick}
        {...props}
      />
    </MemoryRouter>,
  )

  it('renders without crashing', () => {
    setup()
    expect(screen.getByText('test-primary')).toBeInTheDocument()
  })

  it('renders with an icon if provided', () => {
    setup({ icon: <ListItemIcon>Icon</ListItemIcon> })
    expect(screen.getByText('Icon')).toBeInTheDocument()
  })

  it('renders with a child indicator if hasChild is true', () => {
    setup({ hasChild: true })
    expect(screen.getByTestId('KeyboardArrowRightIcon')).toBeInTheDocument()
  })

  it('calls onClick when clicked', () => {
    setup()
    fireEvent.click(screen.getByText('test-primary'))
    expect(mockOnClick).toHaveBeenCalled()
  })
})
