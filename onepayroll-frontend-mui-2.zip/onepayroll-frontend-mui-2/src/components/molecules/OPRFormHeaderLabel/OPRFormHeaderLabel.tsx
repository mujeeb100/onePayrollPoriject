import OPRLabel from 'components/atoms/label/OPRLabel'

type AllProps={
    title:string,
    subTitle?:string,
    isSubTitle?:boolean
}
function OPRFormHeaderLabel({
  title = 'Title',
  subTitle = 'All fields are mandatory except those marked optional.',
  isSubTitle = true,
}:AllProps) {
  return (
    <div style={{ width: '100%' }}>
      <OPRLabel variant="h4">{title}</OPRLabel>
      <br />
      {isSubTitle && <OPRLabel variant="body2">{subTitle}</OPRLabel>}
      <br />
    </div>
  )
}
export default OPRFormHeaderLabel
