// Coverage is not 100% because the default title is not tested.
// It is not possible to test the default title because the title is a required prop.
// Consider removing the default value
import '@testing-library/jest-dom/extend-expect'

import { render, screen } from '@testing-library/react'

import OPRFormHeaderLabel from './OPRFormHeaderLabel'

describe('OPRFormHeaderLabel Component', () => {
  test('renders title and subtitle by default', () => {
    render(<OPRFormHeaderLabel title="Test Title" />)

    expect(screen.getByText('Test Title')).toBeInTheDocument()
    expect(screen.getByText('All fields are mandatory except those marked optional.')).toBeInTheDocument()
  })

  test('renders custom subtitle when provided', () => {
    render(<OPRFormHeaderLabel subTitle="Custom Subtitle" title="Test Title" />)

    expect(screen.getByText('Test Title')).toBeInTheDocument()
    expect(screen.getByText('Custom Subtitle')).toBeInTheDocument()
  })

  test('does not render subtitle when isSubTitle is false', () => {
    render(<OPRFormHeaderLabel isSubTitle={false} title="Test Title" />)

    expect(screen.getByText('Test Title')).toBeInTheDocument()
    expect(screen.queryByText('All fields are mandatory except those marked optional.')).not.toBeInTheDocument()
  })
})
