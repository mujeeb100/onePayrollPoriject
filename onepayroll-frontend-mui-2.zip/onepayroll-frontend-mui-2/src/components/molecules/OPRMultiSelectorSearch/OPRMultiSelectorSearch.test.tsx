// incomplete jest test
// missing lines 133-137, 237-252
import '@testing-library/jest-dom/extend-expect'

import { createTheme, ThemeProvider } from '@mui/material/styles'
import { fireEvent, render, screen } from '@testing-library/react'
import React from 'react'

import GitHubLabel from './OPRMultiSelectorSearch'

const theme = createTheme()

describe('GitHubLabel Component', () => {
  it('renders the component and opens the popper on button click', () => {
    render(
      <ThemeProvider theme={theme}>
        <GitHubLabel />
      </ThemeProvider>,
    )

    // Check if the button is rendered
    const button = screen.getByRole('button', { name: /labels/i })
    expect(button).toBeInTheDocument()

    // Simulate button click to open the popper
    fireEvent.click(button)

    // Check if the popper is opened
    const popper = screen.getByRole('presentation')
    expect(popper).toBeInTheDocument()

    // Check if the autocomplete input is rendered
    const input = screen.getByPlaceholderText('Filter labels')
    expect(input).toBeInTheDocument()
  })

  it('filters labels based on input', () => {
    render(
      <ThemeProvider theme={theme}>
        <GitHubLabel />
      </ThemeProvider>,
    )

    // Simulate button click to open the popper
    const button = screen.getByRole('button', { name: /labels/i })
    fireEvent.click(button)

    // Type in the autocomplete input
    const input = screen.getByPlaceholderText('Filter labels')
    fireEvent.change(input, { target: { value: 'bug' } })

    // Check if the filtered label is displayed
    const filteredLabel = screen.getByText('type: bug')
    expect(filteredLabel).toBeInTheDocument()
  })
})
