import MoreVertIcon from '@mui/icons-material/MoreVert'
import { MenuItem } from '@mui/material'
import { OPRButtonStyle } from 'components/atoms/button/OPRButton'
import OPRMenu from 'components/atoms/menu/OPRMenu'
import cloneDeep from 'lodash/cloneDeep'
import * as React from 'react'
import { useTranslation } from 'react-i18next'
import {
  exportAllRecordsToPdfAndExcel,
  exportToExcel,
  exportToPdf,
  getDataByMappingKeyToHeaders,
} from 'utils'

function OPRExportButton(props: any) {
  const [anchorEl, setAnchorEl] = React.useState<null | HTMLElement>(null)
  const { t } = useTranslation()
  const { exportProps } = props

  return (
    <>
      <OPRButtonStyle
        disabled={
          exportProps?.data?.length === 0 || exportProps?.data?.length === 0
        }
        startIcon={<MoreVertIcon />}
        variant="outlined"
        onClick={(e) => setAnchorEl(e.currentTarget)}
        // onMouseOver={(e) => setAnchorEl(e.currentTarget)}
      >
        {t('export_button_title')}
      </OPRButtonStyle>
      <ListOfExportOptions
        anchorEl={anchorEl}
        exportData={exportProps}
        setAnchorEl={setAnchorEl}
      />
    </>
  )
}

function ListOfExportOptions(props: any) {
  const { anchorEl, setAnchorEl, exportData } = props

  const {
    pdf, data, fileName, columns, allRecords,
  } = exportData
  const { t } = useTranslation()

  const handleClose = () => {
    setAnchorEl(null)
  }

  return (
    <OPRMenu
      keepMounted
      anchorEl={anchorEl}
      id="simple-menu"
      open={Boolean(anchorEl)}
      onClose={handleClose}
    >
      <MenuItem
        onClick={() => {
          exportAllRecordsToPdfAndExcel(
            allRecords,
            fileName,
            columns,
            handleClose,
            'excel',
          )
        }}
      >
        {t('export_option_excel_all_fields')}
      </MenuItem>
      <MenuItem
        onClick={() => {
          let resData = cloneDeep(data)
          if (
            resData
            && resData.length > 0
            && Object.keys(resData[0]).includes('id')
          ) {
            resData = resData.map((data: any) => {
              const { id, ...rest } = data
              return rest
            })
          }
          const dataToExcel = getDataByMappingKeyToHeaders(resData, columns)
          exportToExcel(dataToExcel, fileName)
          handleClose()
        }}
      >
        {t('export_option_excel_current_fields')}
      </MenuItem>
      <MenuItem
        onClick={() => {
          exportAllRecordsToPdfAndExcel(
            allRecords,
            fileName,
            columns,
            handleClose,
            'pdf',
            pdf.orientation,
          )
        }}
      >
        {t('export_option_pdf_all_fields')}
      </MenuItem>
      <MenuItem
        onClick={() => {
          exportToPdf(data, columns, fileName, pdf.orientation)
          handleClose()
        }}
      >
        {t('export_option_pdf_current_fields')}
      </MenuItem>
    </OPRMenu>
  )
}

export default OPRExportButton
