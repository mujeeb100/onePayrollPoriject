import '@testing-library/jest-dom/extend-expect'

import { fireEvent, render, screen } from '@testing-library/react'
import {
  exportAllRecordsToPdfAndExcel, exportToExcel, exportToPdf,
  getDataByMappingKeyToHeaders,
} from 'utils'

import OPRExportButton from './index'

jest.mock('utils', () => ({
  exportAllRecordsToPdfAndExcel: jest.fn(),
  exportToExcel: jest.fn(),
  exportToPdf: jest.fn(),
  getDataByMappingKeyToHeaders: jest.fn(),
}))

jest.mock('react-i18next', () => ({
  useTranslation: () => ({
    t: (key: any) => key,
  }),
}))

describe('OPRExportButton Component', () => {
  const mockExportProps = {
    pdf: { orientation: 'portrait' },
    data: [{ id: 1, name: 'Test' }],
    fileName: 'test-file',
    columns: ['id', 'name'],
    allRecords: [{ id: 1, name: 'Test' }],
  }

  const renderComponent = (props = {}) => render(<OPRExportButton exportProps={mockExportProps} {...props} />)

  beforeEach(() => {
    jest.clearAllMocks()
  })

  test('renders export button', () => {
    renderComponent()
    const button = screen.getByText('export_button_title')
    expect(button).toBeInTheDocument()
  })

  test('opens menu on button hover', () => {
    renderComponent()
    const button = screen.getByText('export_button_title')
    fireEvent.mouseOver(button)
    expect(screen.getByText('export_option_excel_all_fields')).toBeInTheDocument()
  })

  test('calls exportAllRecordsToPdfAndExcel for exporting all records to Excel', () => {
    renderComponent()
    const button = screen.getByText('export_button_title')
    fireEvent.mouseOver(button)
    const menuItem = screen.getByText('export_option_excel_all_fields')
    fireEvent.click(menuItem)
    expect(exportAllRecordsToPdfAndExcel).toHaveBeenCalledWith(
      mockExportProps.allRecords,
      mockExportProps.fileName,
      mockExportProps.columns,
      expect.any(Function),
      'excel',
    )
  })

  test('calls exportToExcel for exporting current fields to Excel', () => {
    renderComponent()
    const button = screen.getByText('export_button_title')
    fireEvent.mouseOver(button)
    const menuItem = screen.getByText('export_option_excel_current_fields')
    fireEvent.click(menuItem)
    expect(exportToExcel).toHaveBeenCalled()
  })

  test('calls exportAllRecordsToPdfAndExcel for exporting all records to PDF', () => {
    renderComponent()
    const button = screen.getByText('export_button_title')
    fireEvent.mouseOver(button)
    const menuItem = screen.getByText('export_option_pdf_all_fields')
    fireEvent.click(menuItem)
    expect(exportAllRecordsToPdfAndExcel).toHaveBeenCalledWith(
      mockExportProps.allRecords,
      mockExportProps.fileName,
      mockExportProps.columns,
      expect.any(Function),
      'pdf',
      mockExportProps.pdf.orientation,
    )
  })

  test('calls exportToPdf for exporting current fields to PDF', () => {
    renderComponent()
    const button = screen.getByText('export_button_title')
    fireEvent.mouseOver(button)
    const menuItem = screen.getByText('export_option_pdf_current_fields')
    fireEvent.click(menuItem)
    expect(exportToPdf).toHaveBeenCalledWith(
      mockExportProps.data,
      mockExportProps.columns,
      mockExportProps.fileName,
      mockExportProps.pdf.orientation,
    )
  })

  it('does not modify data when exporting current fields to Excel if id field does not exist', () => {
    const modifiedExportProps = {
      ...mockExportProps,
      data: [{ name: 'Test' }], // Data without 'id' field
    }

    render(<OPRExportButton exportProps={modifiedExportProps} />)

    const button = screen.getByText('export_button_title')
    fireEvent.mouseOver(button)
    const menuItem = screen.getByText('export_option_excel_current_fields')
    fireEvent.click(menuItem)

    expect(getDataByMappingKeyToHeaders).toHaveBeenCalledWith(modifiedExportProps.data, modifiedExportProps.columns)
    expect(exportToExcel).toHaveBeenCalled()
  })
})
