import {
  Box,
} from '@mui/material'
import { OPRTopBar } from 'components/atoms/top-bar'
import { useState } from 'react'

import DrawerContent from './OPRDrawerContent'

export default function OPROuterLayout() {
  const [open, setOpen] = useState(true)

  return (
    <Box
      data-testid="outer-layout-box"
      sx={{
        display: 'flex', minWidth: 'sm', maxWidth: 'xl', width: '100%',
      }}
    >
      <OPRTopBar handleDrawerToggle={() => {
        setOpen(!open)
      }}
      />
      <DrawerContent />
    </Box>
  )
}
