// coverage not 100%, unable to figure out how to test dismiss and show
import '@testing-library/jest-dom/extend-expect'

import {
  act, fireEvent, render, screen,
} from '@testing-library/react'
import { Provider } from 'react-redux'
import { BrowserRouter as Router } from 'react-router-dom'

import OPRDrawerContent from './OPRDrawerContent'

const mockOnClick = jest.fn()
const mockOnMouseHover = jest.fn()
const mockOnMouseLeave = jest.fn()
const mockOnFocus = jest.fn()

jest.mock('routes/MenuItems', () => ({
  MenuItems: () => [
    {
      title: 'Dashboard',
      key: 'dashboardkey',
      icon: <div>Dashboard Icon</div>,
      path: '/dashboard',
      permission: 'dashboard',
      onClick: mockOnClick(),
      active: false,
      expanded: false,
      children: [],
      event: jest.fn(),
    },
    {
      title: 'Reports',
      key: 'reportskey',
      icon: <div>Reports Icon</div>,
      path: '/reports',
      permission: 'reports',
      onClick: mockOnClick(),
      active: false,
      expanded: false,
      children: [
        {
          title: 'Monthly Report',
          key: 'monthlykey',
          icon: <div>Monthly Report Icon</div>,
          path: '/reports/monthly',
          permission: 'monthly',
          onClick: mockOnClick(),
          active: false,
          children: [],
          event: jest.fn(),
        },
      ],
      event: jest.fn(),
    },
    {
      title: 'Documents',
      key: 'documentskey',
      icon: <div>Documents Icon</div>,
      path: '/documents',
      permission: 'documents',
      onClick: mockOnClick(),
      active: false,
      expanded: true,
      children: [
        {
          title: 'Paper',
          key: 'paper',
          icon: <div>Paper Icon</div>,
          path: '/documents/paper',
          permission: 'paper',
          onClick: mockOnClick(),
          active: false,
          children: [],
          event: jest.fn(),
        },
      ],
      event: jest.fn(),
    },
  ],
}))

const mockActivePermissions = ['dashboard', 'reports', 'monthly', 'documents', 'paper']

jest.mock('slices/permissionSlice', () => ({
  activePermissions: () => mockActivePermissions,
}))

jest.mock('react-router-dom', () => ({
  ...jest.requireActual('react-router-dom'),
  useNavigate: jest.fn(),
}))

jest.mock('components/atoms/label/OPRLabel', () => ({
  OPRLabel: jest.fn(({ label }) => (
    <div data-test={`label-${label}`}>{label}</div>
  )),
}))

jest.mock('components/atoms/OPRSwipeableDrawer', () => function OPRSwipeableDrawerMock({ anchor, children, ...restProps }: any) {
  return (
    <div data-testid={`drawer-${anchor}`} {...restProps}>
      {children}
    </div>
  )
})

jest.mock('react-i18next', () => ({
  useTranslation: () => ({
    t: (key: any) => key,
  }),
}))

describe('OPRDrawerContent Component', () => {
  const renderComponent = () => {
    const mockStore = {
      getState: () => {},
      subscribe: jest.fn(),
      dispatch: jest.fn(),
      replaceReducer: jest.fn(),
      [Symbol.observable]: jest.fn(() => ({
        subscribe: jest.fn(),
        [Symbol.observable]: jest.fn(),
      })),
    }

    return render(
      <Provider store={mockStore}>
        <Router>
          <OPRDrawerContent />
        </Router>
      </Provider>,
    )
  }

  beforeEach(() => {
    jest.clearAllMocks()
  })

  test('renders correctly', () => {
    renderComponent()

    expect(screen.getAllByTestId('drawer-left')[1]).toBeInTheDocument()
    expect(screen.getAllByTestId('drawer-left')[1]).toBeVisible()
    expect(screen.getByText('Dashboard')).toBeInTheDocument()
    expect(screen.getByText('Reports')).toBeInTheDocument()
    expect(screen.getByText('Documents')).toBeInTheDocument()
    expect(screen.getByText('Dashboard Icon')).toBeInTheDocument()
    expect(screen.getByText('Reports Icon')).toBeInTheDocument()
    expect(screen.getByText('Documents Icon')).toBeInTheDocument()
    expect(screen.getByText('VERSION: local')).toBeInTheDocument()
    expect(screen.queryByText('Monthly Report')).not.toBeInTheDocument()
  })

  test('handles menu item hover and state change', async () => {
    jest.useFakeTimers()
    renderComponent()

    const reportsItem = screen.getByText('Reports Icon')
    fireEvent.mouseOver(reportsItem)

    expect(screen.getByText('Monthly Report')).toBeInTheDocument()
    expect(screen.getByText('Monthly Report Icon')).toBeInTheDocument()

    fireEvent.mouseLeave(reportsItem)
    act(() => {
      jest.runAllTimers()
    })
    // expect(screen.queryByText('Monthly Report')).not.toBeInTheDocument()
    // expect(screen.queryByText('Monthly Report Icon')).not.toBeInTheDocument()
  })
})
