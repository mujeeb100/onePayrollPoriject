import {
  Box,
  Collapse,
  Drawer,
  List,
  Toolbar,
} from '@mui/material'
import isEqual from 'lodash/isEqual'
import * as React from 'react'
import { useNavigate } from 'react-router-dom'
import { MenuItems } from 'routes/MenuItems'
import { MainMenuType } from 'types'

import { DRAWER_WIDTH } from '../../../constants/index'
import { OPRListItemLink as ListItemLink } from '../OPRRouter/OPRListItemLink'

// This function controls the selection of menu items from sidebar
const resetMenuState = (menus: MainMenuType[], item: MainMenuType | null) => {
  for (let i = 0; i < menus.length; i += 1) {
    const target = menus[i]
    target.active = isEqual(target, item)
    if (target && target.children) {
      for (let i = 0; i < target.children.length; i += 1) {
        if (target?.children[i] !== item) {
          target.children[i].active = false
        }
      }
    }
  }
  return menus
}

function DrawerContent() {
  const navigate = useNavigate()
  const [menuItems, setMenuItems] = React.useState<MainMenuType[]>(
    MenuItems(navigate),
  )
  return (
    <>
      <Toolbar sx={{ pt: 15 }} />
      <List>
        {menuItems.map((item, index) => (
          <>
            <ListItemLink
              key={item.title}
              icon={item.icon}
              primary={item.title}
              selected={item.active}
              to={item.path}
              onClick={() => {
                item.active = true
                item.expanded = !item.expanded

                resetMenuState(menuItems, item)

                item?.event()
                setMenuItems([...menuItems])
              }}
            />
            {item?.expanded && (
              <Collapse unmountOnExit in={item?.expanded} timeout="auto">
                {item?.children?.map((child, index) => (
                  <ListItemLink
                    key={child.title}
                    icon={child.icon}
                    primary={child.title}
                    selected={child.active}
                    sx={{ pl: 4 }}
                    to={child.path}
                    onClick={() => {
                      child.active = true

                      resetMenuState(menuItems, child)
                      child?.event()
                    }}
                  />
                ))}
              </Collapse>
            )}
          </>
        ))}
      </List>
    </>
  )
}

function OPRDrawer({
  mobileOpen,
  handleDrawerClose,
  handleDrawerTransitionEnd,
}: {
  mobileOpen: boolean
  handleDrawerClose: () => void
  handleDrawerTransitionEnd: () => void
}) {
  return (
    <Box
      aria-label="payroll menu folders"
      component="nav"
      sx={{
        width: { sm: DRAWER_WIDTH },
        flexShrink: { sm: 0 },
      }}
    >
      {/* The implementation can be swapped with js to avoid SEO duplication of links. */}
      <Drawer
        ModalProps={{
          keepMounted: true, // Better open performance on mobile.
        }}
        open={mobileOpen}
        sx={{
          display: { xs: 'block', sm: 'none' },
          '& .MuiDrawer-paper': {
            boxSizing: 'border-box',
            width: DRAWER_WIDTH,
          },
        }}
        variant="temporary"
        onClose={handleDrawerClose}
        onTransitionEnd={handleDrawerTransitionEnd}
      >
        <DrawerContent />
      </Drawer>
      <Drawer
        open
        sx={{
          display: { xs: 'none', sm: 'block' },
          '& .MuiDrawer-paper': { boxSizing: 'border-box', width: DRAWER_WIDTH },
        }}
        variant="permanent"
      >
        <DrawerContent />
      </Drawer>
    </Box>
  )
}

export default OPRDrawer
