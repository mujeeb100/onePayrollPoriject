import '@testing-library/jest-dom/extend-expect'

import { fireEvent, render, screen } from '@testing-library/react'

import OPROuterLayout from './index'

jest.mock('components/atoms/top-bar', () => ({
  OPRTopBar: ({ handleDrawerToggle }: { handleDrawerToggle: () => void }) => (
    <button type="button" onClick={handleDrawerToggle}>Toggle Drawer</button>
  ),
}))

jest.mock('./OPRDrawerContent', () => function () {
  return <div>Drawer Content</div>
})

describe('OPROuterLayout Component', () => {
  const setup = () => render(<OPROuterLayout />)

  it('renders without crashing', () => {
    setup()
    expect(screen.getByText('Toggle Drawer')).toBeInTheDocument()
    expect(screen.getByText('Drawer Content')).toBeInTheDocument()
  })

  it('toggles the drawer state when the top bar button is clicked', () => {
    setup()
    const toggleButton = screen.getByText('Toggle Drawer')
    fireEvent.click(toggleButton)
    expect(toggleButton).toBeInTheDocument()
  })

  it('applies the correct styles to the Box component', () => {
    setup()
    const boxElement = screen.getByTestId('outer-layout-box')
    expect(boxElement).toHaveStyle({
      display: 'flex',
      width: '100%',
    })
  })
})
