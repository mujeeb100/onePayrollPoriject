// coverage not 100% due to uncovered lines 22
import '@testing-library/jest-dom/extend-expect'

import { fireEvent, render, screen } from '@testing-library/react'
import React from 'react'
import { BrowserRouter as Router } from 'react-router-dom'

import OPRDrawer from './OPRDrawer'

const mockOnClick = jest.fn()

jest.mock('routes/MenuItems', () => ({
  MenuItems: () => [
    {
      title: 'Dashboard',
      key: 'dashboardkey',
      icon: <div>Dashboard Icon</div>,
      path: '/dashboard',
      permission: 'dashboard',
      onClick: mockOnClick(),
      active: false,
      expanded: false,
      children: [],
      event: jest.fn(),
    },
    {
      title: 'Reports',
      key: 'reportskey',
      icon: <div>Reports Icon</div>,
      path: '/reports',
      permission: 'reports',
      onClick: mockOnClick(),
      active: false,
      expanded: false,
      children: [
        {
          title: 'Monthly Report',
          key: 'monthlykey',
          icon: <div>Monthly Report Icon</div>,
          path: '/reports/monthly',
          permission: 'monthly',
          onClick: mockOnClick(),
          active: false,
          children: [],
          event: jest.fn(),
        },
      ],
      event: jest.fn(),
    },
    {
      title: 'Documents',
      key: 'documentskey',
      icon: <div>Documents Icon</div>,
      path: '/documents',
      permission: 'documents',
      onClick: mockOnClick(),
      active: false,
      expanded: true,
      children: [
        {
          title: 'Paper',
          key: 'paper',
          icon: <div>Paper Icon</div>,
          path: '/documents/paper',
          permission: 'paper',
          onClick: mockOnClick(),
          active: false,
          children: [],
          event: jest.fn(),
        },
      ],
      event: jest.fn(),
    },
  ],
}))

jest.mock('react-router-dom', () => ({
  ...jest.requireActual('react-router-dom'),
  useNavigate: jest.fn(),
}))

// jest.mock('components/molecules/OPRRouter/OPRListItemLink', () => ({
//   OPRListItemLink: (props: any) => (
//     <div data-testid={`list-item-${props.primary}`}>
//       {props.primary}
//       <button
//         data-testid={`button-${props.primary}`}
//         type="button"
//         onClick={props.onClick}
//       >
//         {props.icon}
//       </button>
//     </div>
//   ),
// }))

jest.mock('react-i18next', () => ({
  useTranslation: () => ({
    t: (key: any) => key,
  }),
}))

describe('OPRDrawer Component', () => {
  const defaultProps = {
    handleDrawerClose: jest.fn(),
    handleDrawerTransitionEnd: jest.fn(),
    mobileOpen: true,
  }

  const renderComponent = (props = {}) => render(
    <Router>
      <OPRDrawer
        {...defaultProps}
        {...props}
      />
    </Router>,
  )

  beforeEach(() => {
    jest.clearAllMocks()
  })

  test('renders correctly', () => {
    renderComponent({ mobileOpen: true })

    const menu = screen.getByLabelText('payroll menu folders')

    expect(menu).toBeInTheDocument()
    expect(menu).toBeVisible()
    expect(menu).toHaveTextContent('Dashboard')
    expect(menu).toHaveTextContent('Reports')
  })

  test('renders correctly when close', () => {
    renderComponent({ mobileOpen: false })

    expect(screen.getByRole('navigation')).toBeInTheDocument()
  })

  test('handles menu item click and state change', () => {
    renderComponent({ mobileOpen: true })

    const reportItem = screen.getAllByText('Reports Icon')[0]
    const dashboardItem = screen.getAllByText('Dashboard Icon')[0]
    fireEvent.click(dashboardItem)
    expect(mockOnClick).toBeCalled()
    fireEvent.click(reportItem)
    expect(mockOnClick).toBeCalled()
    expect(screen.getByText('Monthly Report')).toBeInTheDocument()
    fireEvent.click(reportItem)
    expect(mockOnClick).toBeCalled()
    expect(screen.queryByText('Monthly Report')).not.toBeInTheDocument()
  })

  test('renders submenu', () => {
    renderComponent({ mobileOpen: true })
    expect(screen.getAllByText('Documents')[0]).toBeInTheDocument()
    expect(screen.getAllByText('Paper')[0]).toBeInTheDocument()
  })

  test('handles submenu item click and state change', () => {
    renderComponent({ mobileOpen: true })

    const paperItem = screen.getAllByText('Paper')[0]
    fireEvent.click(paperItem)
    expect(mockOnClick).toHaveBeenCalled()
  })
})
