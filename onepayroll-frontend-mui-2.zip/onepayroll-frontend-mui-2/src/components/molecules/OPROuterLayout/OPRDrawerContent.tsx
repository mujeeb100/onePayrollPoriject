import { Box, List, Typography } from '@mui/material'
import OPRLabel from 'components/atoms/label/OPRLabel'
import OPRSwipeableDrawer from 'components/atoms/OPRSwipeableDrawer'
import { DRAWER_WIDTH } from 'constants/index'
import { useEffect, useState } from 'react'
import { useSelector } from 'react-redux'
import { useNavigate } from 'react-router-dom'
import { MenuItems } from 'routes/MenuItems'
import { activePermissions } from 'slices/permissionSlice'
import { MainMenuType } from 'types'

import { OPRListItemLink as ListItemLink } from '../OPRRouter/OPRListItemLink'

export default function OPRDrawerContent() {
  const navigate = useNavigate()
  const [menuItems, setMenuItems] = useState<MainMenuType[]>([])
  const [selectedItem, setSelectedItem] = useState<MainMenuType|null>(null)

  const permissionList = useSelector(activePermissions)
  const [open, setOpen] = useState(false)
  const [timeOutRef, setTimeoutRef] = useState(null as NodeJS.Timeout | null)

  useEffect(() => {
    const permittedMenuItems = MenuItems(navigate).filter((route) => {
      const { permission } = route
      return permissionList.includes(permission)
    })
    setMenuItems((updatedItems) => permittedMenuItems)
  }, [permissionList])

  const dismiss = () => {
    const ref = setTimeout(() => {
      setOpen(false)
    }, 400)
    setTimeoutRef(ref)
  }

  const show = () => {
    if (timeOutRef) {
      clearTimeout(timeOutRef)
      setTimeoutRef(null)
    }
    if (!open) {
      setOpen(true)
    }
  }

  const { REACT_APP_GIT_HASH } = process.env

  return (
    <>
      {/* Submenu */}
      <OPRSwipeableDrawer
        anchor="left"
        constainerWidth={DRAWER_WIDTH * 2}
        open={open}
        openPosition={DRAWER_WIDTH - 1} // avoid the border
        width={DRAWER_WIDTH + 1}
        onClose={() => { }}
        onMouseLeave={() => {
          dismiss()
        }}
        onMouseOverCapture={() => {
          show()
        }}
        onOpen={() => { }}
      >
        <List>
          <>
            {selectedItem?.subTitle && <OPRLabel color="doubleLightGray.main" label={selectedItem.subTitle} sx={{ px: 2, py: 1 }} variant="subtitle2" />}
            {selectedItem?.children?.map((child, index) => (
              <ListItemLink
                key={child.title}
                icon={child.icon}
                primary={child.title}
                to={child.path}
              />
            ))}
          </>
        </List>
      </OPRSwipeableDrawer>

      {/* Main Menu */}
      <OPRSwipeableDrawer
        open
        anchor="left"
        constainerWidth={DRAWER_WIDTH}
        openPosition={0}
        width={DRAWER_WIDTH}
        onClose={() => {}}
        onMouseLeave={() => {
          dismiss()
        }}
        onMouseOverCapture={() => {

        }}
        onOpen={() => {}}
      >
        <Box sx={{ display: 'flex', flexDirection: 'column', height: '100%' }}>
          <List sx={{ flexGrow: 1 }}>
            {menuItems.map((item, index) => (
              <ListItemLink
                key={item.title}
                hasChild={item.children && item.children.length > 0}
                icon={item.icon}
                primary={item.title}
                to={item.path}
                onMouseLeave={() => {}}
                onMouseOver={() => {
                  if (item.children && item.children.length > 0) {
                    setSelectedItem(item)
                    show()
                  } else {
                  // dismiss for no submenu
                    dismiss()
                  }
                }}
              />
            ))}
          </List>
          <Box sx={{
            display: 'flex', justifyContent: 'center', alignItems: 'center', p: 2, mb: 2,
          }}
          >
            <Typography color="textSecondary" variant="body2">
              VERSION:
              {' '}
              {REACT_APP_GIT_HASH}
            </Typography>
          </Box>
        </Box>
      </OPRSwipeableDrawer>
    </>
  )
}
