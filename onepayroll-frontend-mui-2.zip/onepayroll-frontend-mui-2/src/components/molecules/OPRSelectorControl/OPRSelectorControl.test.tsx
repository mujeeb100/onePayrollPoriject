import '@testing-library/jest-dom/extend-expect'

import { ThemeProvider } from '@emotion/react'
import { createTheme } from '@mui/material/styles'
import { render, screen } from '@testing-library/react'
import i18n from 'i18next'
import React from 'react'
import { I18nextProvider, initReactI18next } from 'react-i18next'

import OPRSelectorControl from './OPRSelectorControl'

i18n.use(initReactI18next).init({
  lng: 'en',
  resources: {
    en: {
      translation: {
        'Test Label': 'Test Label',
        'Optional Text': 'Optional Text',
      },
    },
  },
})

const theme = createTheme()

describe('OPRSelectorControl Component', () => {
  const defaultProps = {
    name: 'testName',
    placeholder: 'Test Placeholder',
    options: [],
    onChange: jest.fn(),
  }

  const renderComponent = (props = {}) => render(
    <ThemeProvider theme={theme}>
      <I18nextProvider i18n={i18n}>
        <OPRSelectorControl {...defaultProps} {...props} />
      </I18nextProvider>
    </ThemeProvider>,
  )

  test('renders without crashing', () => {
    renderComponent({ label: 'Test Label' })
    expect(screen.getByText('Test Label')).toBeInTheDocument()
  })

  test('renders optional text when provided', () => {
    renderComponent({ optionalText: 'Optional Text' })
    expect(screen.getByText('(Optional Text)')).toBeInTheDocument()
  })

  test('renders error message when error prop is true', () => {
    renderComponent({ error: true })
    expect(screen.getByTestId('error-msg')).toBeInTheDocument()
  })

  test('renders OPRAutoCompleteSelect when isEditable is false', () => {
    renderComponent({ isEditable: false })
    expect(screen.getByPlaceholderText('Test Placeholder')).toBeInTheDocument()
  })

  test('renders value when isEditable is true', () => {
    renderComponent({ isEditable: true, value: { key: 'value' }, valueKey: 'key' })
    expect(screen.getByText('value')).toBeInTheDocument()
  })

  test('renders with correct sx', () => {
    const autoComplete = renderComponent({ multiple: true })
    const box = autoComplete.container.getElementsByClassName('MuiAutocomplete-root')[0]
    expect(box).toHaveStyle('height: auto')
  })
})
