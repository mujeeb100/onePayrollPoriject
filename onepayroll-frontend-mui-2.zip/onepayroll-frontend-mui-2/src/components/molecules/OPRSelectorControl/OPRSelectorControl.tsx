import './index.css'

import { useTheme } from '@emotion/react'
import {
  Box,
  SxProps,
} from '@mui/material'
import OPRAutoCompleteSelect from 'components/atoms/autoCompleteSelect/OPRAutoCompleteSelect'
import OPRLabel from 'components/atoms/label/OPRLabel'
import { SyntheticEvent } from 'react'
import { useTranslation } from 'react-i18next'

interface AutoCompleteSelectProps {
  value?: any;
  error?: string;
  name: string;
  label?: string;
  defaultValue?: any;
  placeholder?: string;
  isRequired?: boolean;
  maxWidth?: number;
  minWidth?: number;
  helperText?: string;
  dataList?:any;
  options?: any;
  multiple?: boolean;
  onChange?: (event: SyntheticEvent<Element, Event>) => void;
  keyName?:any;
  valueKey?:any;
  isEditable?: boolean;
  disabled?: boolean;
  style?: React.CSSProperties; // Add style prop
  optionalText?:any; // Added optionalText prop
  sx?: SxProps;
}

function OPRSelectorControl({
  value = {},
  name,
  disabled,
  label = '',
  placeholder,
  error,
  maxWidth,
  isRequired = false,
  defaultValue,
  dataList,
  optionalText,
  minWidth,
  options = [],
  style,
  onChange,
  helperText,
  multiple = false,
  keyName,
  valueKey,
  isEditable = false,
  sx,
  ...props
}: AutoCompleteSelectProps) {
  const theme:any = useTheme()
  const { t } = useTranslation()
  // console.log(options?.sort((a:any, b:any) => a[keyName]?.localeCompare(b[keyName])), 'HHHHHHHHHHHHHHH')

  // const rowList = options.length > 0 ? options?.sort((a:any, b:any) => a[keyName]?.localeCompare(b[keyName])) : []
  return (
    <Box
      sx={{
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'flex-start',
        gap: '4px',
        flex: '1 0 0',
        ...sx,
      }}
    >
      <OPRLabel
        CustomStyles={{
          display: 'flex',
          alignItems: 'flex-start',
          gap: '0px',
          alignSelf: 'stretch',

        }}
        color={error ? theme.palette.error.contrastText : ''}
      >
        {label ? t(label) : ''}
        {optionalText && ( // Conditionally render the optional text span
          <span style={{ fontWeight: 'lighter' }}>
            &nbsp;(
            {t(optionalText)}
            )
          </span>
        )}
      </OPRLabel>
      {isEditable && (
        <OPRLabel
          CustomStyles={{
            display: 'flex',
            alignItems: 'flex-start',
            gap: '8px',
            alignSelf: 'stretch',
          }}
          variant="body2"
        >
          <br />
          {(value !== null) && value[`${valueKey}`]}
        </OPRLabel>
      )}
      {!isEditable && (
        <OPRAutoCompleteSelect
          CustomStyles={{
            padding: '0px !important',
            width: '100%',
            borderRadius: '8px',
            height: !multiple ? '40px' : 'auto',
            border: error ? `1px solid ${theme.palette.error.contrastText}` : '',
          }}
          className="opr-select-complete"
          disabled={disabled}
          isRequired={isRequired}
          maxWidth={255}
          minWidth={255}
          multiple={multiple}
          name={name}
          options={options}
          placeholder={placeholder}
          selectedKey={keyName}
          value={value}
          onChange={onChange}
        />
      )}
      {/* {error ? <OPRLabel color="error">Error Name</OPRLabel> : null} */}
      <OPRLabel color={error ? theme.palette.error.contrastText : ''} data-testid="error-msg" variant="body2">{error}</OPRLabel>
    </Box>
  )
}

export default OPRSelectorControl
