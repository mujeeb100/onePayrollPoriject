// coverage not 100
import '@testing-library/jest-dom/extend-expect'

import { fireEvent, render, screen } from '@testing-library/react'

import OPRSearchIcon from './index'

jest.mock('assets/svg-images/SvgComponents', () => ({
  SerachBar: () => <svg data-testid="search-bar-icon" />,
}))

jest.mock('themes', () => ({
  palette: {
    topAdmin: { main: '#000' },
    secondary: { main: '#fff' },
  },
}))

describe('OPRSearchIcon Component', () => {
  const renderComponent = (props = {}) => render(<OPRSearchIcon {...props} />)

  it('should render the search icon', () => {
    renderComponent()
    expect(screen.getByTestId('search-bar-icon')).toBeInTheDocument()
  })

  it('should render the input field with the correct placeholder', () => {
    renderComponent({ placeholder: 'Search...' })
    expect(screen.getByPlaceholderText('Search...')).toBeInTheDocument()
  })

  it('should call onChange when the input value changes', () => {
    const handleChange = jest.fn()
    renderComponent({ placeholder: 'Search...', onChange: handleChange })
    const input = screen.getByPlaceholderText('Search...')
    fireEvent.change(input, { target: { value: 'New Value' } })
    expect(handleChange).toHaveBeenCalled()
  })

  it('should call onChange when the form is submitted', () => {
    const handleChange = jest.fn()
    renderComponent({ onChange: handleChange, value: 'Test Value' })
    const form = screen.getByRole('button')
    fireEvent.submit(form)
    expect(handleChange).toHaveBeenCalled()
  })

  it('should render the input field with the correct value', () => {
    renderComponent({ value: 'Test Value' })
    const input = screen.getByRole('textbox')
    expect(input).toHaveValue('Test Value')
  })
})
