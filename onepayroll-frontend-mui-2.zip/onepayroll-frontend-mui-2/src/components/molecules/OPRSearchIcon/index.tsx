import styled from '@emotion/styled'
import IconButton from '@mui/material/IconButton'
import InputBase from '@mui/material/InputBase'
import Paper from '@mui/material/Paper'
import { RedLoader, SerachBar } from 'assets/svg-images/SvgComponents'
import * as React from 'react'
import customTheme from 'themes'

type CustomProps = {
      buttonText?: string;
      CustomStyles?: React.CSSProperties;
      icon?: boolean;
      loading?: boolean;
  }
export default function OPRSearchIcon({
  value, onChange, placeholder, loading, ...rest
}: { value?: string, onChange?: any, placeholder?: string, loading?: boolean}) {
  const CustomInput = styled(InputBase)<CustomProps>(({ theme, CustomStyles }: any) => ({
    ...({
      color: 'black',
      backgroundColor: theme.palette.secondary.main,
    }),
    // customstyle will override the above styles and theme styles for the component
    ...CustomStyles,
  }))

  const [showLoader, setShowLoader] = React.useState(false)

  // React.useEffect(() => {
  //   const interval = setInterval(() => {
  //     setShowLoader((prevShowLoader) => !prevShowLoader)
  //   }, 5000)

  //   return () => clearInterval(interval)
  // }, [])
  React.useEffect(() => {
    const timer = setTimeout(() => {
      setShowLoader(true)
    }, 2000) // 2 seconds

    // Cleanup timeout if the component unmounts before the timer completes
    return () => clearTimeout(timer)
  }, [])
  return (
    <Paper
      component="form"
      sx={{
        border: `1px solid ${customTheme.palette.topAdmin.main}`,
        borderRadius: '8px',
        boxShadow: 'none',
        p: '4px 8px',
        display: 'flex',
        alignItems: 'center',
        gap: '10px',
        // width: '100%',
        // mb: 4,
      }}
      onSubmit={(e) => {
        // inject the value into the event object which is not a good practice
        (e.target as any).value = value
        onChange(e)
        e.preventDefault()
      }}
    >
      <IconButton aria-label="search" data-testid="search-icon" sx={{ p: '0px' }} type="button">
        <SerachBar />
      </IconButton>

      <InputBase
        inputProps={{ 'aria-label': 'search google maps' }}
        placeholder={placeholder}
        // sx={{ ml: 1, flex: 1 }}
        value={value}
        onChange={onChange}
      />
      {loading && showLoader && (
        <div style={{ marginLeft: 'auto' }}>
          <RedLoader />
        </div>
      )}

      {/* <TextField
        id="outlined-basic"
        label="Outlined"
        placeholder={`Search By ${placeholder}`}
        value={value}
        variant="outlined"
        onChange={onChange}
      /> */}
    </Paper>
  )
}
