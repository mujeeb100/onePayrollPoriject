import './index.css'

import { useTheme } from '@emotion/react'
import {
  Box,
  OutlinedInput,
} from '@mui/material'
import OPRLabel from 'components/atoms/label/OPRLabel'
import { t } from 'i18next'
import { useLocation } from 'react-router'

type Props = {
    value?: number | string;
    onChange?: (item: any) => void;
    disabled?: boolean;
    name?: string;
    isRequired?: boolean;
    max?: number;
    placeholder?: string;
    type?: string;
    maxLength?: number;
    error?: string;
  min?: number
    color?:any;
    label?: string;
    isEditable?: boolean;
    multiline?: boolean;
    rows?: number;
    optionalText?: any; // New prop for optional text
  };

function OPRInputControl({
  value = '',
  onChange,
  disabled,
  name,
  label,
  isRequired = false,
  placeholder = '',
  type = 'text',
  optionalText = '', // Default value for optional text
  maxLength,
  error,
  color,
  isEditable = true,
  rows = 1,
  multiline = false,
  min = 9999999999,
  ...rest
}: Props) {
  const theme:any = useTheme() // Use the Theme type for the theme variable
  const location: any = useLocation()
  return (
    <Box
      sx={{
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'flex-start',
        gap: '4px',
        flex: '1 0 0',
      }}
    >
      <OPRLabel
        CustomStyles={{
          display: 'flex',
          alignItems: 'flex-start',
          gap: '0px',
          alignSelf: 'stretch',

        }}
        color={error ? theme.palette.error.contrastText : ''}
        // color={error ? '#DA3237' : ''}
      >
        {label ? t(label) : ''}
        {optionalText && (
          <span style={{ fontWeight: 'lighter' }}>
&nbsp;(
            {t(optionalText)}
            )
          </span>
        )}
        {' '}
        {/* Display optional text if provided */}
      </OPRLabel>
      {isEditable && (
        <OPRLabel
          CustomStyles={{
            display: 'flex',
            alignItems: 'flex-start',
            gap: '8px',
            alignSelf: 'stretch',
          }}
          variant="body2"
        >
          <br />
          {value?.toString() || '-'}
        </OPRLabel>
      )}
      {!isEditable && (
        <OutlinedInput
          disabled={disabled}
          id={`outlined-${name}`}
          inputProps={{
            maxLength,
          }}
          multiline={multiline}
          name={name}
          notched={false}
          placeholder={placeholder}
          required={isRequired}
          rows={rows}
          sx={{
            width: '100%',
            borderRadius: '8px',
            height: !multiline ? '40px' : 'auto',
            border: error ? `1px solid ${theme.palette.error.contrastText}` : '',
          }}
          // sx={{
          //   width: '100%',
          //   height: '100%',
          //   justifyContent: 'flex-start',
          //   alignItems: 'center',
          //   display: 'inline-flex',
          //   border: error ? '1px solid #DA3237' : '',
          // }}
          type={type}
          value={value}
          onChange={onChange}
        />
      )}
      {/* {error ? <OPRLabel color="error">Error Name</OPRLabel> : null} */}
      <OPRLabel color={error ? theme.palette.error.contrastText : ''} variant="body2">{error}</OPRLabel>
    </Box>
  )
}

export default OPRInputControl
