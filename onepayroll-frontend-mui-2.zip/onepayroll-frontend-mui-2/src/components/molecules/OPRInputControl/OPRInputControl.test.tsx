import '@testing-library/jest-dom/extend-expect'

import { useTheme } from '@emotion/react'
import { fireEvent, render, screen } from '@testing-library/react'
import { t } from 'i18next'
import { useLocation } from 'react-router'

import OPRInputControl from './index'

jest.mock('@emotion/react', () => {
  const originalModule = jest.requireActual('@emotion/react')
  return {
    ...originalModule,
    useTheme: jest.fn(),
  }
})

jest.mock('i18next', () => ({
  t: jest.fn(),
}))

jest.mock('react-router', () => ({
  useLocation: jest.fn(),
}))

const mockTheme = {
  palette: {
    error: { contrastText: '#f00' },
  },
}

describe('OPRInputControl Component', () => {
  const renderComponent = (props = {}) => render(<OPRInputControl {...props} />)

  beforeEach(() => {
    (useTheme as jest.Mock).mockReturnValue(mockTheme);
    (t as unknown as jest.Mock).mockImplementation((key) => key);
    (useLocation as jest.Mock).mockReturnValue({ pathname: '/test-path' })
  })

  it('should render the label and optional text', () => {
    renderComponent({ label: 'Test Label', optionalText: 'Optional' })
    expect(screen.getByText('Test Label')).toBeInTheDocument()
    expect(screen.getByText('(Optional)')).toBeInTheDocument()
  })

  it('should render the input field when not editable', () => {
    renderComponent({ isEditable: false })
    expect(screen.getByRole('textbox')).toBeInTheDocument()
  })

  it('should render the value as text when editable', () => {
    renderComponent({ isEditable: true, value: 'Test Value' })
    expect(screen.getByText('Test Value')).toBeInTheDocument()
  })

  it('should call onChange with the correct value when input value changes', () => {
    const handleChange = jest.fn()
    renderComponent({ isEditable: false, onChange: handleChange })
    const input = screen.getByRole('textbox')
    fireEvent.change(input, { target: { value: 'New Value' } })
    expect(handleChange).toHaveBeenCalledWith(expect.any(Object))
  })

  it('should display error message when error prop is provided', () => {
    renderComponent({ error: 'Test Error' })
    expect(screen.getByText('Test Error')).toBeInTheDocument()
  })

  it('should render with correct sx', () => {
    renderComponent({
      placeholder: 'placeholder', isEditable: false, multiline: true, error: 'error',
    })
    const box = screen.getByPlaceholderText('placeholder')
    expect(box).toHaveStyle('height: 0px')
    expect(box).toHaveStyle('border: 0px')
  })
})
