import Box from '@mui/material/Box'
import Grid from '@mui/material/Grid'
import Paper from '@mui/material/Paper'
import { experimentalStyled as styled } from '@mui/material/styles'
import * as React from 'react'

const Item = styled(Paper)(({ theme }) => ({
  backgroundColor: theme.palette.mode === 'dark' ? '#1A2027' : '#fff',
  ...theme.typography.body2,
  padding: theme.spacing(2),
  textAlign: 'center',
  color: theme.palette.text.secondary,
}))

export default function OPRResponsiveGrid({ children, styles }: any) {
  return (
    <Box sx={{
      display: 'flex', alignItems: 'center', justifyContent: 'space-between', ...styles,
    }}
    >
      <Grid
        container
        columns={{ xs: 1, sm: 1, md: 4 }}
        spacing={{ xs: 2, md: 2 }}
        // sx={{
        //   display: 'flex', alignItems: 'center', justifyContent: 'space-between',
        // }}
      >
        {children}
      </Grid>
    </Box>
  )
}
