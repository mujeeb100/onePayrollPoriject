// Coverage is not 100% due to unused const Item in the OPRResonsiveGrid component file.
// Line 7 to 13
import '@testing-library/jest-dom/extend-expect'

import { PaletteMode } from '@mui/material'
import Paper from '@mui/material/Paper'
import { createTheme, experimentalStyled as styled, ThemeProvider } from '@mui/material/styles'
import { render, screen } from '@testing-library/react'

import OPRResponsiveGrid from './index'

const Item = styled(Paper)(({ theme }) => ({
  backgroundColor: theme.palette.mode === 'dark' ? '#1A2027' : '#fff',
  ...theme.typography.body2,
  padding: theme.spacing(2),
  textAlign: 'center',
  color: theme.palette.text.secondary,
}))

describe('OPRResponsiveGrid', () => {
  const setup = (props = {}, themeMode: PaletteMode = 'light') => {
    const theme = createTheme({
      palette: {
        mode: themeMode,
      },
    })

    return render(
      <ThemeProvider theme={theme}>
        <OPRResponsiveGrid {...props}>
          <Item>Item 1</Item>
          <Item>Item 2</Item>
          <Item>Item 3</Item>
          <Item>Item 4</Item>
        </OPRResponsiveGrid>
      </ThemeProvider>,
    )
  }

  it('renders without crashing', () => {
    setup()
    expect(screen.getByText('Item 1')).toBeInTheDocument()
    expect(screen.getByText('Item 2')).toBeInTheDocument()
    expect(screen.getByText('Item 3')).toBeInTheDocument()
    expect(screen.getByText('Item 4')).toBeInTheDocument()
  })

  it('applies custom styles correctly', () => {
    const customStyles = { backgroundColor: 'red' }
    setup({ styles: customStyles })
    const items = screen.getAllByText(/Item \d/)
    items.forEach((item) => {
      expect(item).toHaveStyle('background-color: rgb(255, 255, 255)')
    })
  })

  it('renders children correctly', () => {
    setup()
    expect(screen.getByText('Item 1')).toBeInTheDocument()
    expect(screen.getByText('Item 2')).toBeInTheDocument()
    expect(screen.getByText('Item 3')).toBeInTheDocument()
    expect(screen.getByText('Item 4')).toBeInTheDocument()
  })

  it('applies light mode background color correctly', () => {
    setup({}, 'light')
    const items = screen.getAllByText(/Item \d/)
    items.forEach((item) => {
      expect(item).toHaveStyle('background-color: #fff')
    })
  })

  it('applies dark mode background color correctly', () => {
    setup({}, 'dark')
    const items = screen.getAllByText(/Item \d/)
    items.forEach((item) => {
      expect(item).toHaveStyle('background-color: #1A2027')
    })
  })
})
