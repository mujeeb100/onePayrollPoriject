import { useTheme } from '@emotion/react'
import {
  Box, TextareaAutosizeProps,
  TextField,
} from '@mui/material'
import OPRLabel from 'components/atoms/label/OPRLabel'
import { t } from 'i18next'
import React from 'react'

type CustomProps = {
  value?: number | string;
  onChange?: (item: any) => void;
  disabled?: boolean;
  label?: string;
  isEditable?: boolean;
  placeholder?: string;
  name?: string;
  isRequired?: boolean;
  rows?: any;
  error?: string;
  optionalText?: string; // New prop for optional text
};

// Define a new interface that extends TextareaAutosizeProps
interface CustomTextareaProps extends TextareaAutosizeProps {
  rows?: any;
}

function OPRTextArea({
  value = '',
  onChange,
  error,
  label,
  disabled = false,
  optionalText = '', // Default value for optional text
  name,
  isEditable = true,
  placeholder = '',
  isRequired = false,
  rows = 3,
}: CustomProps): JSX.Element {
  const theme: any = useTheme() // Use the Theme type for the theme variable

  return (
    <Box
      sx={{
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'flex-start',
        gap: '4px',
        flex: '1 0 0',
      }}
    >
      <OPRLabel
        CustomStyles={{
          display: 'flex',
          alignItems: 'flex-start',
          gap: '0px',
          alignSelf: 'stretch',

        }}
        color={error ? theme.palette.error.contrastText : ''}
        // color={error ? '#DA3237' : ''}
      >
        {label ? t(label) : ''}
        {optionalText && (
          <span style={{ fontWeight: 'lighter' }}>
&nbsp;(
            {t(optionalText)}
            )
          </span>
        )}
        {' '}
        {/* Display optional text if provided */}
      </OPRLabel>
      {isEditable && (
        <OPRLabel
          CustomStyles={{
            display: 'flex',
            alignItems: 'flex-start',
            gap: '8px',
            alignSelf: 'stretch',
            resize: 'vertical',
            overflow: 'auto',
            overflowWrap: 'break-word',
            wordBreak: 'break-word',
            height: '50px',
          }}
          variant="body2"
        >
          {value}
        </OPRLabel>
      ) }
      {!isEditable && (
        <TextField
          fullWidth
          multiline
          InputProps={{
            sx: {
              width: '100%',
              maxWidth: '100%',
              fontSize: '1em',
              fontWeight: 700,
              fontStyle: 'normal',
              fontFamily: 'Lato',
              lineHeight: '1.4375em',
              color: 'rgba(0, 0, 0, 0.87)',
              boxSizing: 'border-box',
              position: 'relative',
              cursor: 'text',
              display: 'inline-flex',
              alignItems: 'center',
              padding: '4px 0 5px',
              borderRadius: '8px',
              p: '16.5px 14px',
              border: error ? `1px solid ${theme.palette.error.contrastText}` : '',
              overflowX: 'auto', // Handle horizontal overflow
              overflowY: 'auto', // Handle vertical overflow

              // border: '0px solid var(--grey-grey-600666364, #666364)',
            },
          }}
          disabled={disabled}
          maxRows={4}
          minRows={4}
          name={name}
          placeholder={placeholder}
          required={isRequired}
          value={value}
          onChange={onChange}
        />
      )}

      <OPRLabel color={error ? theme.palette.error.contrastText : ''} variant="body2">{error}</OPRLabel>
    </Box>
  )
}

export default OPRTextArea
