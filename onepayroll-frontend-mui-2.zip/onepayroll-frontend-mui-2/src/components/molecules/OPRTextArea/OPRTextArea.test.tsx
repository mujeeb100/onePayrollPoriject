import '@testing-library/jest-dom/extend-expect'

import { ThemeProvider } from '@emotion/react'
import { createTheme } from '@mui/material/styles'
import { fireEvent, render, screen } from '@testing-library/react'
import i18n from 'i18next'
import { I18nextProvider, initReactI18next } from 'react-i18next'

import OPRTextArea from './OPRTextArea'

i18n.use(initReactI18next).init({
  lng: 'en',
  resources: {
    en: {
      translation: {
        'Test Label': 'Test Label',
        'Optional Text': 'Optional Text',
      },
    },
  },
})

const theme = createTheme()

describe('OPRTextArea Component', () => {
  const renderComponent = (props = {}) => render(
    <ThemeProvider theme={theme}>
      <I18nextProvider i18n={i18n}>
        <OPRTextArea {...props} />
      </I18nextProvider>
    </ThemeProvider>,
  )

  test('renders with text provided', () => {
    renderComponent({ value: 'Test Value', optionalText: 'Optional Text' })
    expect(screen.getByText('Test Value')).toBeInTheDocument()
    expect(screen.getByText('(Optional Text)')).toBeInTheDocument()
  })

  test('renders label when label prop is provided', () => {
    renderComponent({ label: 'Test Label' })
    expect(screen.getByText('Test Label')).toBeInTheDocument()
  })

  test('renders error message when error prop is true', () => {
    renderComponent({ error: 'Error Message' })
    expect(screen.getByText('Error Message')).toBeInTheDocument()
  })

  test('renders value when isEditable is true', () => {
    renderComponent({ isEditable: true, value: 'Editable Value' })
    expect(screen.getByText('Editable Value')).toBeInTheDocument()
  })

  test('renders TextField when isEditable is false', () => {
    renderComponent({ isEditable: false, placeholder: 'Test Placeholder' })
    expect(screen.getByPlaceholderText('Test Placeholder')).toBeInTheDocument()
  })

  test('calls onChange when TextField value changes', () => {
    const onChange = jest.fn()
    renderComponent({ isEditable: false, onChange, placeholder: 'Test Placeholder' })
    const textField = screen.getByPlaceholderText('Test Placeholder')
    fireEvent.change(textField, { target: { value: 'New Value' } })
    expect(onChange).toHaveBeenCalled()
  })

  test('renders correctly when error', () => {
    renderComponent({ error: 'Error Message', isEditable: false, placeholder: 'Test Placeholder' })
    expect(screen.getByText('Error Message')).toHaveStyle({ color: '#FFFFFF' })
  })
})
