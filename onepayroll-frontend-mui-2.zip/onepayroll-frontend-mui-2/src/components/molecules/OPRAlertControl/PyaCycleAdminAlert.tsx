import { useTheme } from '@emotion/react'
import {
  Box,
} from '@mui/material'
import { Info } from 'assets/svg-images/SvgComponents'
import OPRButton from 'components/atoms/button/OPRButton'
import OPRLabel from 'components/atoms/label/OPRLabel'
import { CustomDialog } from 'components/atoms/modal/OPRModal'
// import { useEditable } from 'hooks/useEdit'

          type Props = {
            title?:string,
            isCancelPayCycleAlert?:boolean
            handleCancelPayCycleAlert?:any
            // onEditable ?: (item:any) => void;
            callBack?:any
            name?:string
          };

function PayCycleAlert({
  title,
  name,
  isCancelPayCycleAlert = false,
  handleCancelPayCycleAlert = () => {
  },
  callBack = () => {},
  ...rest
}: Props) {
  const theme:any = useTheme() // Use the Theme type for the theme variable
  // const {
  //   isEditable,
  //   setEditable,
  // } = useEditable()
  return (
    <Box>
      <CustomDialog
        CustomStyles={{ borderRadius: '16px' }}
        isOpen={isCancelPayCycleAlert}
        type="loader"
      >
        <div style={{ marginBottom: '15px' }}>
          <OPRLabel variant="h4">
            {`Are you sure you want to ${title}`}
          </OPRLabel>
        </div>
        <Box
          className="pop-up"
          sx={{
            display: 'flex',
            padding: '12px',
            gap: '12px',
            alignItems: 'flex-start',
            borderRadius: '4px',
            alignSelf: 'stretch',
            backgroundColor: `${theme.palette.Invite.main}`,
            marginTop: 1,
          }}
        >
          <Info />
          <OPRLabel
            CustomStyles={{
              backgroundColor: `${theme.palette.Invite.main}`,
            }}
            backgroundColor={theme.palette.Invite.main}
            variant="body2"
          >
            {`${name} will be ${title}.`}
          </OPRLabel>
        </Box>
        <Box sx={{
          display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: 5,
        }}
        >
          <OPRButton color="info" variant="text" onClick={handleCancelPayCycleAlert}>
            Cancel
          </OPRButton>
          <OPRButton
            color="info"
            variant="text"
            onClick={callBack}
          >
            Confirm
          </OPRButton>
        </Box>
      </CustomDialog>
    </Box>
  )
}

export default PayCycleAlert
