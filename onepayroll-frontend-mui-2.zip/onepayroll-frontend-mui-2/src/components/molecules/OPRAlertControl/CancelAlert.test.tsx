// coverage for functions is not 100, dk why
import '@testing-library/jest-dom/extend-expect'

import { useTheme } from '@emotion/react'
import { fireEvent, render, screen } from '@testing-library/react'

import CancelAlert from './CancelAlert'

jest.mock('@emotion/react', () => {
  const originalModule = jest.requireActual('@emotion/react')
  return {
    ...originalModule,
    useTheme: jest.fn(),
  }
})

describe('CancelAlert Component', () => {
  const mockTheme = {
    palette: {
      Invite: {
        main: '#000000',
      },
    },
  }

  beforeEach(() => {
    (useTheme as jest.Mock).mockReturnValue(mockTheme)
  })

  it('renders without crashing', () => {
    render(<CancelAlert isCancel />)
    expect(screen.getAllByRole('presentation')[0]).toBeInTheDocument()
  })

  it('should not open if isCancel is default/not provided', () => {
    render(<CancelAlert />)
    expect(screen.queryByRole('presentation')).not.toBeInTheDocument()
  })

  it('displays the correct title and message', () => {
    render(<CancelAlert isCancel />)
    expect(screen.getByText('Are you sure you want to quit?')).toBeInTheDocument()
    expect(screen.getByText('Are you sure you want to quit without saving your changes? Any unsaved progress will be lost.')).toBeInTheDocument()
  })

  it('calls handleCancel when the Cancel button is clicked', () => {
    const handleCancel = jest.fn()
    render(<CancelAlert isCancel handleCancel={handleCancel} />)
    fireEvent.click(screen.getByText('Cancel'))
    expect(handleCancel).toHaveBeenCalled()
  })

  it('calls callBack when the Confirm button is clicked', () => {
    const callBack = jest.fn()
    render(<CancelAlert isCancel callBack={callBack} />)
    fireEvent.click(screen.getByText('Confirm'))
    expect(callBack).toHaveBeenCalled()
  })

  it('closes the dialog when the Back button is clicked', () => {
    const handleCancel = jest.fn()
    render(<CancelAlert isCancel handleCancel={handleCancel} />)
    fireEvent.click(screen.getByText('Back'))
    expect(handleCancel).toHaveBeenCalledWith(false)
  })
})
