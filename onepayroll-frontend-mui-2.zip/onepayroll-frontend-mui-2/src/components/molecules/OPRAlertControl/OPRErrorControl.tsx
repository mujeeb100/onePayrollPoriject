import { useTheme } from '@emotion/react'
import {
  Box,
} from '@mui/material'
import { ReactComponent as ErrorIcon } from 'assets/svg-icons/ErrorIcon.svg'
import { ReactComponent as ErrorStatus } from 'assets/svg-icons/ErrorStatus.svg'
import { RighCaretBlue } from 'assets/svg-images/SvgComponents'
import OPRButton from 'components/atoms/button/OPRButton'
import OPRLabel from 'components/atoms/label/OPRLabel'
import { CustomDialog } from 'components/atoms/modal/OPRModal'
import { useEditable } from 'hooks/useEdit'
import { t } from 'i18next'
import { useEffect } from 'react'
import { useNavigate } from 'react-router-dom'

      type Props = {
        label?: string;
        isSuccess?: boolean;
        isCustomError?: boolean;
        isError?: boolean;
        handleCancelClick?: () => void;
        toggle?: (item: boolean) => void;
        title?:string
        name?:string
        handleSubmit?: (item:any) => void;
        onSetValue ?: (item:any) => void;
        onEditable ?: (item:any) => void;
        customBack ?: () => void;
        error?:any;
        isBackButton?:boolean
        isTry?:boolean
        header?:string
        callBack ?: (type:any) => void;
      };

export function OPRErrorAlertControl({
  isError = false,
  isCustomError = false,
  handleCancelClick,
  toggle = (item:any) => {},
  title = 'Country',
  name = 'Jane Doe ',
  handleSubmit = (item:any) => {},
  onEditable = (item:any) => {},
  customBack = () => {},
  header = 'Failed to add new',
  error = {
    status: 500,
  },
  isBackButton = true,
  isTry = true,
  callBack,
  ...rest
}: Props) {
  const navigate = useNavigate()
  const theme:any = useTheme() // Use the Theme type for the theme variable
  const {
    isEditable,
    setEditable,
  } = useEditable()
  const { status, data }:any = error

  useEffect(() => {
    isError && setEditable(true)
    // setEditable(true)
  }, [isError])
  return (
    <Box>
      <CustomDialog
        CustomStyles={{ borderRadius: '16px' }}
        isOpen={isEditable}
        type="loader"
      >
        <div
          className="AtomPopupTitleStrip"
          style={{
            width: '100%', flexDirection: 'column', justifyContent: 'flex-start', alignItems: 'flex-start', gap: 16, display: 'inline-flex',
          }}
        >
          <div
            className="Header"
            style={{
              alignSelf: 'stretch', justifyContent: 'flex-start', alignItems: 'flex-start', gap: 8, display: 'inline-flex',
            }}
          >
            <div
              className="Icon"
              style={{
                paddingTop: 5, paddingBottom: 5, justifyContent: 'flex-start', alignItems: 'flex-start', display: 'flex',
              }}
            >
              <div className="Tick" style={{ width: 24, height: 24, position: 'relative' }}>
                <ErrorIcon />
              </div>
            </div>
            <div
              className="Text"
              style={{
                flex: '1 1 0', flexDirection: 'column', justifyContent: 'flex-start', alignItems: 'flex-start', display: 'inline-flex',
              }}
            >
              <OPRLabel CustomStyles={{ marginTop: 2 }} variant="h4">
                {header}
                {' '}
                {name}
                .
              </OPRLabel>
            </div>
          </div>
        </div>
        <Box sx={{
          display: 'flex',
          padding: '12px',
          gap: '12px',
          alignItems: 'flex-start',
          // flexDirection: 'row',
          borderRadius: '4px',
          alignSelf: 'stretch',
          // gap: 1,
          marginTop: 1,
          backgroundColor: `${theme.palette.error.main}`,
        }}
        >
          <ErrorStatus />
          <Box sx={{
            display: 'flex',
            flexDirection: 'column',

          }}
          >
            <OPRLabel variant="body1">
              Error Code :
              {' '}
              {error?.status}
            </OPRLabel>
            {
              data?.errors?.map((item:any, i:any) => (
                <OPRLabel CustomStyles={{ marginTop: 2 }} data-testid="errorCodeMessage" variant="body2">
                  {t(item.code) || t(item.message)}
                </OPRLabel>
              ))
            }
          </Box>

        </Box>

        <Box sx={{
          display: 'flex', alignItems: 'center', flexDirection: 'row', justifyContent: 'space-between', mt: 6,
        }}
        >
          <OPRButton
            color="info"
            variant="text"
            onClick={() => {
              setEditable(true)
              callBack && callBack('back')
            }}
          >
            Close
          </OPRButton>

          {isBackButton && (
            <OPRButton
              style={{ marginLeft: 'auto' }}
              variant="text"
              onClick={() => {
                if (isCustomError) {
                  customBack()
                  setEditable(false)
                } else {
                  // onEditable(false)
                  setEditable(false)
                // callBack && callBack('back')
                }
              }}
            >
              <RighCaretBlue />
              Back
            </OPRButton>
          )}

          {
            isTry && (
              <OPRButton
                handleClick={() => {
                  handleSubmit('')
                  setEditable(false)
                }}
                variant="contained"
              >
                Try Again
              </OPRButton>
            )
          }
        </Box>

      </CustomDialog>
    </Box>
  )
}

export default OPRErrorAlertControl
