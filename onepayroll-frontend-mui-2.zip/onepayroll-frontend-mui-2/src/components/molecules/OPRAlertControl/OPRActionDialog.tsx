import { useTheme } from '@emotion/react'
import {
  Box,
} from '@mui/material'
import { Info } from 'assets/svg-images/SvgComponents'
import OPRButton from 'components/atoms/button/OPRButton'
import OPRLabel from 'components/atoms/label/OPRLabel'
import { CustomDialog } from 'components/atoms/modal/OPRModal'

type OPRActionDialogProps = {
  title?: string,
  message?: string
  open?: boolean
  cancelHandler?: ()=> void
  confirmHandler?: ()=> void
};

function OPRActionDialog({
  title,
  message,
  open = false,
  cancelHandler,
  confirmHandler,
}: OPRActionDialogProps) {
  const theme: any = useTheme() // Use the Theme type for the theme variable
  return (
    <Box>
      <CustomDialog
        CustomStyles={{ borderRadius: '16px' }}
        isOpen={open}
        type="loader"
      >
        <div style={{ marginBottom: '15px' }}>
          <OPRLabel variant="h4">
            {title}
          </OPRLabel>
        </div>
        <Box
          className="pop-up"
          sx={{
            display: 'flex',
            padding: '12px',
            gap: '12px',
            alignItems: 'flex-start',
            borderRadius: '4px',
            alignSelf: 'stretch',
            backgroundColor: `${theme.palette.Invite.main}`,
            marginTop: 1,
          }}
        >
          <Info />
          <OPRLabel
            CustomStyles={{
              backgroundColor: `${theme.palette.Invite.main}`,
            }}
            backgroundColor={theme.palette.Invite.main}
            variant="body2"
          >
            $
            {message}
          </OPRLabel>
        </Box>
        <Box sx={{
          display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: 5,
        }}
        >
          <OPRButton color="info" variant="text" onClick={cancelHandler}>
            Cancel
          </OPRButton>
          <OPRButton
            color="info"
            variant="text"
            onClick={confirmHandler}
          >
            Confirm
          </OPRButton>
        </Box>
      </CustomDialog>
    </Box>
  )
}

export default OPRActionDialog
