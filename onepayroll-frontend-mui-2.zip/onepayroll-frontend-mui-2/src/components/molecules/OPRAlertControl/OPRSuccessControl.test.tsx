// funcs coverage is not 100
import '@testing-library/jest-dom/extend-expect'

import { ThemeProvider, useTheme } from '@emotion/react'
import { createTheme } from '@mui/material/styles'
import { fireEvent, render, screen } from '@testing-library/react'
import { useLocation } from 'react-router-dom'
import { getParamsValue } from 'utils'

import { OPRSuccesControl } from './OPRSuccesControl'

const mockSetEditable = jest.fn()
let mockIsEditable = true
const mockNavigate = jest.fn()

jest.mock('hooks/useEdit', () => ({
  useEditable: () => ({ isEditable: mockIsEditable, setEditable: mockSetEditable }),
}))

jest.mock('@emotion/react', () => {
  const originalModule = jest.requireActual('@emotion/react')
  return {
    ...originalModule,
    useTheme: jest.fn(),
  }
})

jest.mock('react-router-dom', () => ({
  useNavigate: () => mockNavigate,
  useLocation: jest.fn(),
}))

jest.mock('assets/svg-icons/Tick.svg', () => ({
  ReactComponent: () => <svg data-testid="success-icon" />,
}))

jest.mock('utils', () => ({
  getParamsValue: jest.fn(),
}))

const theme = createTheme({
  palette: {
    error: {
      main: '#f44336',
    },
  },
})

describe('OPRSuccesControl Component', () => {
  const renderComponent = (props = {}) => render(
    <ThemeProvider theme={theme}>
      <OPRSuccesControl {...props} />
    </ThemeProvider>,
  )

  beforeEach(() => {
    (useTheme as jest.Mock).mockReturnValue(theme);
    (useLocation as jest.Mock).mockReturnValue({ pathname: '/test-path' });
    (getParamsValue as jest.Mock).mockReturnValue({ viewUrl: '/view-url', id: '123' })
    mockIsEditable = true
    mockSetEditable.mockClear()
    mockNavigate.mockClear()
  })

  it('should render the component with default props', () => {
    renderComponent()
    expect(screen.getByText('New Added')).toBeInTheDocument()
    expect(screen.getByTestId('success-icon')).toBeInTheDocument()
  })

  it('should render the component with custom title and message', () => {
    renderComponent({ customTitle: 'Custom Title', customMessage: 'Custom Message' })
    expect(screen.getByText('Custom Title')).toBeInTheDocument()
    expect(screen.getByText('Custom Message')).toBeInTheDocument()
  })

  it('should call setEditable and onScreenClose when Close button is clicked', () => {
    const onSetValue = jest.fn()
    const onEditable = jest.fn()
    const callBack = jest.fn()
    renderComponent({
      onSetValue, onEditable, callBack, addAnother: true,
    })
    const addAnotherButton = screen.getByText('Add Another')
    fireEvent.click(addAnotherButton)
    expect(mockSetEditable).toHaveBeenCalledWith(true)
    expect(onEditable).toHaveBeenCalled()
    expect(onSetValue).toHaveBeenCalled()
    expect(callBack).toHaveBeenCalledWith('success')
  })

  it('should call navigate when Close button is clicked and isCustom is false and is update', () => {
    const setIsSuccessPayCycle = jest.fn()
    renderComponent({
      type: 'update', isCustom: false, isEntity: false, setIsSuccessPayCycle,
    })
    const closeButton = screen.getByText('Close')
    fireEvent.click(closeButton)
    expect(mockNavigate).toHaveBeenCalledWith(-1)
    expect(setIsSuccessPayCycle).toHaveBeenCalledWith(false)
    expect(mockSetEditable).toHaveBeenCalledWith(false)
  })

  it('should not call navigate and setIsSuccessPayCycle when Close button is clicked and isCustom is false and is update', () => {
    const setIsSuccessPayCycle = jest.fn()
    renderComponent({
      type: 'update', isCustom: false, isEntity: true,
    })
    const closeButton = screen.getByText('Close')
    fireEvent.click(closeButton)
    expect(mockNavigate).not.toHaveBeenCalledWith(-1)
    expect(setIsSuccessPayCycle).not.toHaveBeenCalledWith(false)
    expect(mockSetEditable).toHaveBeenCalledWith(false)
  })

  it('should call setEditable and callBack when Close button is clicked and isCustom is true and is new', () => {
    const callBack = jest.fn()
    const setIsSuccessPayCycle = jest.fn()
    renderComponent({ isCustom: true, callBack })
    const closeButton = screen.getByText('Close')
    fireEvent.click(closeButton)
    expect(mockSetEditable).toHaveBeenCalledWith(false)
    expect(callBack).toHaveBeenCalledWith('back')
    expect(setIsSuccessPayCycle).not.toHaveBeenCalledWith(false)
  })

  it('should call setEditable and navigate when Close button is clicked and isCustom is false and is new', () => {
    const callBack = jest.fn()
    const setIsSuccessPayCycle = jest.fn()
    renderComponent({ isCustom: false, callBack })
    const closeButton = screen.getByText('Close')
    fireEvent.click(closeButton)
    expect(mockSetEditable).toHaveBeenCalledWith(false)
    expect(mockNavigate).toHaveBeenCalledWith(-1)
    expect(setIsSuccessPayCycle).not.toHaveBeenCalledWith(false)
  })

  it('should call setIsSuccessPayCycle when Close button is clicked and setIsSuccessPayCycle is true and is new', () => {
    const setIsSuccessPayCycle = jest.fn()
    renderComponent({
      isCustom: false, setIsSuccessPayCycle,
    })
    const closeButton = screen.getByText('Close')
    fireEvent.click(closeButton)
    expect(setIsSuccessPayCycle).toHaveBeenCalledWith(false)
    expect(mockSetEditable).toHaveBeenCalledWith(false)
  })

  it('should call setEditable and onSetValue when Add Another button is clicked', () => {
    const onSetValue = jest.fn()
    renderComponent({ addAnother: true, onSetValue })
    const addAnotherButton = screen.getByText('Add Another')
    fireEvent.click(addAnotherButton)
    expect(mockSetEditable).toHaveBeenCalledWith(true)
    expect(onSetValue).toHaveBeenCalled()
  })

  it('should not have a button for add another', () => {
    renderComponent({ addAnother: true, type: 'update' })
    expect(screen.queryByText('Add Another')).not.toBeInTheDocument()
  })

  it('should not render the component if isEditable is false', () => {
    mockIsEditable = false
    renderComponent()
    expect(screen.queryByText('New Added')).not.toBeInTheDocument()
  })

  it('should setEditable to true if isSuccess is true', () => {
    renderComponent({ isSuccess: true })
    expect(mockSetEditable).toHaveBeenCalledWith(true)
  })

  it('should call onSetValue if id is null when onScreenClose is called', () => {
    (getParamsValue as jest.Mock).mockReturnValue({ viewUrl: '/view-url', id: null })
    const onSetValue = jest.fn()
    const callBack = jest.fn()
    renderComponent({ callBack, onSetValue, addAnother: true })
    const closeButton = screen.getByText('Add Another')
    fireEvent.click(closeButton)
    expect(callBack).toHaveBeenCalledWith('success')
    expect(onSetValue).toHaveBeenCalled()
  })
})
