import '@testing-library/jest-dom/extend-expect'

import { useTheme } from '@emotion/react'
import { fireEvent, render, screen } from '@testing-library/react'

import { OPRDeleteControl } from './OPRDeleteControl'

jest.mock('@emotion/react', () => {
  const originalModule = jest.requireActual('@emotion/react')
  return {
    ...originalModule,
    useTheme: jest.fn(),
  }
})

describe('OPRDeleteControl Component', () => {
  const defaultProps = {
    deleteCallBack: jest.fn(),
    selelctedUser: { data: {}, isDelete: false, name: '' },
    setSelelctedUser: jest.fn(),
    title: 'User',
  }

  const renderComponent = (props = {}) => render(
    <OPRDeleteControl {...defaultProps} {...props} />,
  )

  const mockTheme = {
    palette: {
      Invite: {
        main: '#000000',
      },
    },
  }

  beforeEach(() => {
    (useTheme as jest.Mock).mockReturnValue(mockTheme)
  })

  it('should not render', () => {
    renderComponent({
      selelctedUser: undefined,
    })
    expect(screen.queryByRole('presentation')).not.toBeInTheDocument()
  })

  it('should render the component with isUserDelete prop', () => {
    renderComponent({
      selelctedUser: { data: { id: 1 }, isDelete: true, name: 'John Doe' },
      isUserDelete: true,
    })
    expect(screen.getByText('Are you sure you want to delete the User?')).toBeInTheDocument()
    expect(screen.getByText('Deleting John Doe means they will no longer have access to Tricor Unify.')).toBeInTheDocument()
    expect(screen.getByText('Delete')).toBeInTheDocument()
  })

  it('should render the component with isDeactivate prop', () => {
    renderComponent({
      selelctedUser: { data: { id: 1 }, isDelete: true, name: 'John Doe' },
      isDeactivate: true,
      isUserDelete: true,
    })
    expect(screen.getByText('Are you sure you want to deactive the User?')).toBeInTheDocument()
    expect(screen.getByText('Deactivating John Doe means they will no longer have access to Tricor Unify.')).toBeInTheDocument()
    expect(screen.getByText('Deactivate')).toBeInTheDocument()
  })

  it('should render the component with isWithdraw prop', () => {
    renderComponent({
      selelctedUser: { data: { id: 1 }, isDelete: true, name: 'John Doe' },
      isWithdraw: true,
    })
    expect(screen.getByText('Are you sure you want to withdraw movement')).toBeInTheDocument()
    expect(screen.getByText("If this movement is withdrawn, you won't be able to revert it. All information will be reverted back to previous records.")).toBeInTheDocument()
    expect(screen.getByText('Withdraw')).toBeInTheDocument()
  })

  it('should call setSelelctedUser when Cancel button is clicked', () => {
    renderComponent({ selelctedUser: { data: { id: 1 }, isDelete: true, name: 'John Doe' } })
    const cancelButton = screen.getByText('Cancel')
    fireEvent.click(cancelButton)
    expect(defaultProps.setSelelctedUser).toHaveBeenCalledWith(false)
  })

  it('should call deleteCallBack and setSelelctedUser when Delete button is clicked', () => {
    renderComponent({ selelctedUser: { data: { id: 1 }, isDelete: true, name: 'John Doe' } })
    const deleteButton = screen.getByText('Delete')
    fireEvent.click(deleteButton)
    expect(defaultProps.deleteCallBack).toHaveBeenCalledWith({ id: 1 })
    expect(defaultProps.setSelelctedUser).toHaveBeenCalledWith({ data: { id: 1 }, isDelete: false, name: 'John Doe' })
  })

  it('should call deleteCallBack and setSelelctedUser when Deactivate button is clicked', () => {
    renderComponent({ isDeactivate: true, selelctedUser: { data: { id: 1 }, isDelete: true, name: 'John Doe' } })
    const deactivateButton = screen.getByText('Deactivate')
    fireEvent.click(deactivateButton)
    expect(defaultProps.deleteCallBack).toHaveBeenCalledWith({ id: 1 })
    expect(defaultProps.setSelelctedUser).toHaveBeenCalledWith({ data: { id: 1 }, isDelete: false, name: 'John Doe' })
  })

  it('should call deleteCallBack and setSelelctedUser when Withdraw button is clicked', () => {
    renderComponent({ isWithdraw: true, selelctedUser: { data: { id: 1 }, isDelete: true, name: 'John Doe' } })
    const withdrawButton = screen.getByText('Withdraw')
    fireEvent.click(withdrawButton)
    expect(defaultProps.deleteCallBack).toHaveBeenCalledWith({ id: 1 })
    expect(defaultProps.setSelelctedUser).toHaveBeenCalledWith({ data: { id: 1 }, isDelete: false, name: 'John Doe' })
  })

  it('should render even if deletecallback and setselecteduser is undefined', () => {
    renderComponent({
      selelctedUser: { data: { id: 1 }, isDelete: true, name: 'John Doe' },
      setSelelctedUser: undefined,
      title: undefined,
      deleteCallBack: undefined,
    })

    expect(screen.getByText('Are you sure you want to delete the User?')).toBeInTheDocument()
    expect(screen.getByText('If it is deleted, you will not be able to revert it.')).toBeInTheDocument()

    const cancelButton = screen.getByText('Cancel')
    expect(cancelButton).toBeInTheDocument()
    fireEvent.click(cancelButton)

    const deleteButton = screen.getByText('Delete')
    expect(deleteButton).toBeInTheDocument()
    fireEvent.click(deleteButton)
  })
})
