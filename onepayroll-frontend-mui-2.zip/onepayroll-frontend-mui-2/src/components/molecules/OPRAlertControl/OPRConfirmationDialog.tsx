import {
  Box,
  SxProps,
} from '@mui/material'
import { ReactComponent as ErrorStatus } from 'assets/svg-icons/ErrorStatus.svg'
import {
  RighCaretBlue,
  WarningExclamationIcon,
} from 'assets/svg-images/SvgComponents'
import OPRButton from 'components/atoms/button/OPRButton'
import OPRLabel from 'components/atoms/label/OPRLabel'
import { CustomDialog } from 'components/atoms/modal/OPRModal'
import { t } from 'i18next'
import React from 'react'
import { CSSProperties } from 'styled-components'

import theme from '../../../themes'

export type OPRConfirmationDialogButtonLayout = 'close' | 'try-again' | 'confirm' | 'delete' | 'add-another'

export type OPRConfirmationDialogProps = {
  open: boolean
  error?: any
  icon?: React.ReactNode
  messageStyle?: CSSProperties
  titleStyle?: CSSProperties
  title: React.ReactNode | string
  subtitleMessage?: React.ReactNode | string // New prop for subtitle
  message?: React.ReactNode | string
  infoMessage?: React.ReactNode | string
  errorMessage?: React.ReactNode | string
  buttonLayout: OPRConfirmationDialogButtonLayout
  titleSx?: SxProps
  addAnotherButtonTitle?: React.ReactNode | string
  onClose?: () => void
  onBack?: () => void
  onTryAgain?: () => void
  onConfirm?: () => void
  onCancel?: () => void
  onDelete?: () => void
  onAddAnother?: () => void
  info?: Record<string, any>
};

export function OPRConfirmationDialog({
  open, error, title, subtitleMessage, message, messageStyle = {}, buttonLayout, addAnotherButtonTitle,
  icon, titleStyle = {}, infoMessage, errorMessage, titleSx = {}, info,
  onClose, onBack, onTryAgain, onCancel, onConfirm, onDelete, onAddAnother,
}: OPRConfirmationDialogProps) {
  let buttons: React.ReactNode = []
  let justifyContent = 'space-between'
  let errorContent = errorMessage

  if (error) {
    const { status, data } = error

    errorContent = (
      data?.errors?.map((item:any, i:any) => (
        <OPRLabel key={item.code} CustomStyles={{ marginTop: 2 }} data-testid="error-message" variant="body2">
          {t(item.code) || t(item.message)}
        </OPRLabel>
      ))
    )
  }

  switch (buttonLayout) {
    case 'close':
      justifyContent = 'flex-end'
      buttons = [
        <OPRButton
          key="close"
          data-testid="close-button"
          variant="contained"
          onClick={() => {
            onClose?.()
          }}
        >
          {t('Close')}
        </OPRButton>,
      ]
      break
    case 'try-again':
      buttons = [
        <OPRButton
          key="close"
          data-testid="close-button"
          variant="text"
          onClick={() => {
            onClose?.()
          }}
        >
          {t('Close')}
        </OPRButton>,
        <OPRButton
          key="back"
          data-testid="back-button"
          style={{ marginLeft: 'auto' }}
          variant="text"
          onClick={() => {
            onBack?.()
          }}
        >
          <RighCaretBlue />
          {t('Back')}
        </OPRButton>,
        <OPRButton
          key="try-again"
          data-testid="try-again-button"
          variant="contained"
          onClick={() => {
            onTryAgain?.()
          }}
        >
          {t('Try Again')}
        </OPRButton>,
      ]
      break
    case 'confirm':
      buttons = [
        <OPRButton
          key="cancel"
          data-testid="cancel-button"
          variant="text"
          onClick={() => {
            onCancel?.()
          }}
        >
          {t('Cancel')}
        </OPRButton>,
        <OPRButton
          key="confirm"
          data-testid="confirm-button"
          variant="contained"
          onClick={() => {
            onConfirm?.()
          }}
        >
          {t('Confirm')}
        </OPRButton>,
      ]
      break
    case 'delete':
      buttons = [
        <OPRButton
          key="cancel"
          data-testid="cancel-button"
          variant="text"
          onClick={() => {
            onCancel?.()
          }}
        >
          {t('Cancel')}
        </OPRButton>,
        <OPRButton
          key="delete"
          data-testid="delete-button"
          style={{
            color: `${theme.palette.error.contrastText}`,
            borderColor: `${theme.palette.error.contrastText}`,
          }}
          variant="outlined"
          onClick={() => {
            onDelete?.()
          }}
        >
          {t('Delete')}
        </OPRButton>,
      ]
      break
    case 'add-another':
      buttons = [
        <OPRButton
          key="add-another"
          data-testid="add-another-button"
          variant="text"
          onClick={() => {
            onAddAnother?.()
          }}
        >
          {addAnotherButtonTitle || 'Add Another'}
        </OPRButton>,
        <OPRButton
          key="close"
          data-testid="close-button"
          variant="contained"
          onClick={() => {
            onClose?.()
          }}
        >
          {t('Close')}
        </OPRButton>,
      ]
      break
    default:
      break
  }

  return (
    <Box>
      <CustomDialog
        CustomStyles={{ borderRadius: '16px' }}
        isOpen={open}
        type="loader"
      >
        <div
          style={{
            width: '100%', flexDirection: 'column', justifyContent: 'flex-start', alignItems: 'flex-start', gap: 16, display: 'inline-flex',
          }}
        >
          <div
            style={{
              alignSelf: 'stretch', justifyContent: 'flex-start', alignItems: 'flex-start', gap: 8, display: 'inline-flex', margin: '0px 0px 8px 0px',
            }}
          >
            {icon && (
              <div
                style={{
                  paddingTop: 5, paddingBottom: 5, justifyContent: 'flex-start', alignItems: 'flex-start', display: 'flex',
                }}
              >
                <div className="Tick" data-testid="icon" style={{ width: 24, height: 24, position: 'relative' }}>
                  {icon}
                </div>
              </div>
            )}
            <div
              style={{
                flex: '1 1 0', flexDirection: 'column', justifyContent: 'center', alignItems: 'flex-start', display: 'inline-flex', height: '32px',
              }}
            >
              <OPRLabel
                CustomStyles={{ ...titleStyle }}
                sx={{
                  '&::first-letter': {
                    textTransform: 'capitalize',
                  },
                  ...titleSx,
                }}
                variant="h4"
              >
                {title}
              </OPRLabel>

              {/* Subtitle message */}
              {subtitleMessage && (
                <OPRLabel
                  CustomStyles={{ marginTop: 2 }}
                  sx={{ fontSize: '14px', color: theme.palette.text.secondary }}
                  variant="body2"
                >
                  {subtitleMessage}
                </OPRLabel>
              )}

            </div>
          </div>
        </div>

        {message && (
          <Box sx={{ justifyContent: 'center', marginBottom: 2, ...messageStyle }}>
            {message}
          </Box>
        )}

        {infoMessage && (
          <Box sx={{
            display: 'flex',
            padding: '12px',
            gap: '12px',
            alignItems: 'flex-start',
            borderRadius: '4px',
            alignSelf: 'stretch',
            background: `${theme.palette.Invite.main}`,
          }}
          >
            <Box>
              <WarningExclamationIcon />
            </Box>
            <Box style={{ fontWeight: '400', fontSize: '14px' }}>
              {infoMessage}
            </Box>
          </Box>
        )}

        {/* Error message */}
        {errorContent && (
          <Box sx={{
            display: 'flex',
            padding: '12px',
            gap: '12px',
            alignItems: 'flex-start',
            borderRadius: '4px',
            alignSelf: 'stretch',
            backgroundColor: `${theme.palette.error.main}`,
          }}
          >
            <Box>
              <ErrorStatus />
            </Box>
            <Box sx={{
              display: 'flex',
              flexDirection: 'column',

            }}
            >
              <OPRLabel variant="body1">
                {`Error ${error?.status || ''}`}
              </OPRLabel>

              <OPRLabel CustomStyles={{ marginTop: 2 }} variant="body2">
                {errorContent}
              </OPRLabel>

            </Box>

          </Box>
        )}

        {/* hirzontal line */}
        <Box sx={{
          width: '100%',
          border: '1px solid #E0E0E0',
          display: 'flex',
          flexDirection: 'row',
          alignItems: 'center',
          mt: 4,
        }}
        />

        <Box sx={{
          display: 'flex', alignItems: 'center', flexDirection: 'row', justifyContent: { justifyContent }, mt: 2,
        }}
        >
          {buttons}
        </Box>

      </CustomDialog>
    </Box>
  )
}
