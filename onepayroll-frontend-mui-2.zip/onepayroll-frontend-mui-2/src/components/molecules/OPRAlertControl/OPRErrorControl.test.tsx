// funcs coverage not 100
import '@testing-library/jest-dom/extend-expect'

import { ThemeProvider, useTheme } from '@emotion/react'
import { createTheme } from '@mui/material/styles'
import { fireEvent, render, screen } from '@testing-library/react'

import { OPRErrorAlertControl } from './OPRErrorControl'

const mockSetEditable = jest.fn()
let mockIsEditable = true

jest.mock('hooks/useEdit', () => ({
  useEditable: () => ({ isEditable: mockIsEditable, setEditable: mockSetEditable }),
}))

jest.mock('@emotion/react', () => {
  const originalModuletwo = jest.requireActual('@emotion/react')
  return {
    ...originalModuletwo,
    useTheme: jest.fn(),
  }
})

jest.mock('react-router-dom', () => ({
  useNavigate: () => jest.fn(),
}))

jest.mock('assets/svg-icons/ErrorIcon.svg', () => ({
  ReactComponent: () => <svg data-testid="error-icon" />,
}))

jest.mock('assets/svg-icons/ErrorStatus.svg', () => ({
  ReactComponent: () => <svg data-testid="error-status" />,
}))

jest.mock('assets/svg-images/SvgComponents', () => ({
  RighCaretBlue: () => <svg data-testid="right-caret-blue" />,
}))

const theme = createTheme({
  palette: {
    error: {
      main: '#f44336',
    },
  },
})

describe('OPRErrorAlertControl Component', () => {
  const renderComponent = (props = {}) => render(
    <ThemeProvider theme={theme}>
      <OPRErrorAlertControl {...props} />
    </ThemeProvider>,
  )

  beforeEach(() => {
    (useTheme as jest.Mock).mockReturnValue(theme)
  })

  it('should render the component with default props', () => {
    renderComponent()
    expect(screen.getByText('Failed to add new Jane Doe .')).toBeInTheDocument()
    expect(screen.getByText('Error Code : 500')).toBeInTheDocument()
    expect(screen.getByText('Close')).toBeInTheDocument()
    expect(screen.getByText('Back')).toBeInTheDocument()
    expect(screen.getByText('Try Again')).toBeInTheDocument()
  })

  it('should render the component with error message', () => {
    renderComponent({
      error: {
        status: 500,
        data: {
          errors: [{ code: 'error_code', message: 'error_message' }],
        },
      },
    })
    expect(screen.getByTestId('errorCodeMessage')).toBeInTheDocument()
  })

  it('should call setEditable and callBack when Close button is clicked', () => {
    const callBack = jest.fn()
    renderComponent({ isError: true, callBack })
    const closeButton = screen.getByText('Close')
    fireEvent.click(closeButton)
    expect(mockSetEditable).toHaveBeenCalledWith(true)
    expect(callBack).toHaveBeenCalledWith('back')
  })

  it('should call customBack and setEditable when Back button is clicked with isCustomError', () => {
    const customBack = jest.fn()
    renderComponent({
      isCustomError: true, customBack,
    })
    const backButton = screen.getByText('Back')
    fireEvent.click(backButton)
    expect(customBack).toHaveBeenCalled()
    expect(mockSetEditable).toHaveBeenCalledWith(false)
  })

  it('should call setEditable when Back button is clicked without isCustomError', () => {
    renderComponent()
    const backButton = screen.getByText('Back')
    fireEvent.click(backButton)
    expect(mockSetEditable).toHaveBeenCalledWith(false)
  })

  it('should call handleSubmit and setEditable when Try Again button is clicked', () => {
    const handleSubmit = jest.fn()
    renderComponent({ handleSubmit })
    const tryAgainButton = screen.getByText('Try Again')
    fireEvent.click(tryAgainButton)
    expect(handleSubmit).toHaveBeenCalledWith('')
    expect(mockSetEditable).toHaveBeenCalledWith(false)
  })

  it('should not render the component if isEditable is false', () => {
    mockIsEditable = false
    renderComponent()
    expect(screen.queryByText('Failed to add new Jane Doe .')).not.toBeInTheDocument()
  })
})
