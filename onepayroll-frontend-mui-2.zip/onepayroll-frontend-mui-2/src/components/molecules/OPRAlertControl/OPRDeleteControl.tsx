import { useTheme } from '@emotion/react'
import {
  Box,
} from '@mui/material'
import { Info } from 'assets/svg-images/SvgComponents'
import OPRButton from 'components/atoms/button/OPRButton'
import OPRLabel from 'components/atoms/label/OPRLabel'
import { CustomDialog } from 'components/atoms/modal/OPRModal'
import { useEffect, useState } from 'react'

  type Props = {
  isDeactivate?: boolean,
  isUserDelete?: boolean,
  isWithdraw?: boolean,
  deleteCallBack : (item:any) => void,
  selelctedUser : any,
  setSelelctedUser : any,
  title:string
  success?:any
  };

export function OPRDeleteControl({
  success,
  isUserDelete = false,
  isDeactivate = false,
  isWithdraw = false,
  deleteCallBack = (item:any) => {},
  selelctedUser = { data: {}, isDelete: false, name: '' },
  setSelelctedUser = (item:any) => {},
  title = 'User',
  ...rest
}: Props) {
  const theme:any = useTheme()
  const { isDelete, data, name }:any = selelctedUser
  const [alert, setAlert] = useState(success)
  useEffect(() => {
    if (success) {
      setAlert(success)
      // setTimeout(() => {
      //   setAlert(false)
      // }, 10000)
    }
  }, [success])
  return (
    <>
      <CustomDialog
        CustomStyles={{ borderRadius: '16px' }}
        isOpen={isDelete}
        type="loader"
      >
        <div style={{ marginBottom: '15px' }}>
          {isWithdraw ? (
            <OPRLabel variant="h5">
              Are you sure you want to withdraw movement
            </OPRLabel>
          )
            : (
              <OPRLabel variant="h5">
                {`Are you sure you want to ${isDeactivate ? 'deactive' : 'delete'} the ${title}?`}
              </OPRLabel>
            )}
          {/* <OPRLabel variant="h5">
          {`Are you sure you want to ${isDeactivate ? 'deactive' : 'delete'} the ${title}?`}
        </OPRLabel> */}
        </div>
        <Box
          className="pop-up"
          sx={{
            display: 'flex',
            padding: '12px',
            gap: '12px',
            alignItems: 'flex-start',
            borderRadius: '4px',
            alignSelf: 'stretch',
            backgroundColor: `${theme.palette.Invite.main}`,
            marginTop: 1,
          }}
        >
          <Info />
          {isWithdraw ? (
            <OPRLabel
              CustomStyles={{
                backgroundColor: `${theme.palette.Invite.main}`,
              }}
              backgroundColor={theme.palette.Invite.main}
              variant="body2"
            >
              {'If this movement is withdrawn, you won\'t be able to revert it. All information will be reverted back to previous records.'}
            </OPRLabel>
          ) : (
            <OPRLabel
              CustomStyles={{
                backgroundColor: `${theme.palette.Invite.main}`,
              }}
              backgroundColor={theme.palette.Invite.main}
              variant="body2"
            >
              {isUserDelete ? `${isDeactivate ? 'Deactivating' : 'Deleting'} ${name} means they will no longer have access to Tricor Unify.` : 'If it is deleted, you will not be able to revert it.'}
            </OPRLabel>
          )}
        </Box>
        <Box sx={{
          display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: 5,
        }}
        >
          <OPRButton color="info" variant="text" onClick={() => setSelelctedUser(false)}>
            Cancel
          </OPRButton>
          {isWithdraw ? (
            <OPRButton
              color="info"
              style={{
                color: 'var(--red-red-500-da-3237, #DA3237)',
                borderRadius: '110px',
                border: '1px solid var(--red-red-500-da-3237, #DA3237)',
              }}
              variant="text"
              onClick={() => {
                deleteCallBack(data)
                setSelelctedUser({ ...selelctedUser, isDelete: false })
              }}
            >
              Withdraw
            </OPRButton>
          ) : (
            <OPRButton
              color="info"
              style={{
                color: 'var(--red-red-500-da-3237, #DA3237)',
                borderRadius: '110px',
                border: '1px solid var(--red-red-500-da-3237, #DA3237)',
              }}
              variant="text"
              onClick={() => {
                setAlert(true)
                deleteCallBack(data)
                setSelelctedUser({ ...selelctedUser, isDelete: false })
              }}
            >
              {isDeactivate ? 'Deactivate' : 'Delete' }
            </OPRButton>
          )}
        </Box>
      </CustomDialog>
      {/* Success message dialog */}
      <CustomDialog
        CustomStyles={{ borderRadius: '16px', padding: '0px' }}
        isOpen={alert}
        type="loader"
      >
        <OPRLabel CustomStyles={{ marginTop: 2 }} variant="h4">
          {title}
          {' '}
          deleted
        </OPRLabel>
        <OPRLabel
          CustomStyles={{
            marginTop: '12px',
            display: 'flex',
            alignItems: 'center',
            gap: '12px',
          }}
          variant="body1"
        >
          {name}
          {' '}
          has been deleted.
        </OPRLabel>
        <OPRButton
          color="info"
          style={{
            marginLeft: 'auto',
            display: 'flex',
            padding: '8px 16px',
            alignItems: 'center',
            gap: '12px',
            color: '#FFF',
            background: 'var(--blue-blue-5000049-db, #0049DB)',
            borderRadius: '110px',
            border: '1px solid #0049DB',
            overflow: 'hidden',
          }}
          variant="text"
          onClick={() => setAlert(false)}
        >
          Close
        </OPRButton>
      </CustomDialog>
    </>
  )
}
