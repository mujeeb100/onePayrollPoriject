// onScreenClose is not used in the component, therefore coverage is not 100%
// The component is not complete, close button does not have any instructions
// error is not coded for
import '@testing-library/jest-dom/extend-expect'

import { ThemeProvider } from '@emotion/react'
import { createTheme } from '@mui/material/styles'
import { render, screen } from '@testing-library/react'
import { BrowserRouter as Router } from 'react-router-dom'

import { OPRAlertControlEmployee } from './OPRAlertControlEmployee'

jest.mock('hooks/useEdit', () => ({
  useEditable: () => ({
    isEditable: true,
    setEditable: jest.fn(),
  }),
}))

const theme = createTheme()

describe('OPRAlertControlEmployee Component', () => {
  const defaultProps = {
    isEntity: false,
    isSuccess: false,
    setIsSuccessPayCycle: jest.fn(),
    payCycleUpdatedName: '',
    isCustom: false,
    handleCancelClick: jest.fn(),
    toggle: jest.fn(),
    title: 'Country',
    name: 'Jane Doe',
    customTitle: '',
    customMessage: '',
    onSetValue: jest.fn(),
    onEditable: jest.fn(),
    callBack: jest.fn(),
    error: false,
    type: 'New',
  }

  const renderComponent = (props = {}) => render(
    <ThemeProvider theme={theme}>
      <Router>
        <OPRAlertControlEmployee {...defaultProps} {...props} />
      </Router>
    </ThemeProvider>,
  )

  it('should render the component with default props', () => {
    renderComponent()
    expect(screen.getByText('New Country Added')).toBeInTheDocument()
    expect(screen.getByText('Jane Doe has been added.')).toBeInTheDocument()
  })

  it('should render custom title and message when provided', () => {
    renderComponent({
      customTitle: 'Custom Title',
      customMessage: 'Custom Message',
    })
    expect(screen.getByText('Custom Title')).toBeInTheDocument()
    expect(screen.getByText('Custom Message')).toBeInTheDocument()
  })

  //   it('should call handleCancelClick when Close button is clicked', () => {
  //     renderComponent()
  //     const closeButton = screen.getByText('Close')
  //     fireEvent.click(closeButton)
  //   })

  it('should handle success state correctly', () => {
    renderComponent({ isSuccess: true })
    expect(screen.getByText('New Country Added')).toBeInTheDocument()
  })

  //   it('should handle error state correctly', () => {
  //     renderComponent({ error: { status: 500, data: 'Error' } })
  //     expect(screen.getByText('Error')).toBeInTheDocument()
  //   })

  it('should handle different types correctly', () => {
    renderComponent({ type: 'Update' })
    expect(screen.getByText('Country Updated')).toBeInTheDocument()
    expect(screen.getByText('Jane Doe has been updated.')).toBeInTheDocument()
  })
})
