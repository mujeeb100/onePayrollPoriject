import '@testing-library/jest-dom/extend-expect'

import { useTheme } from '@emotion/react'
import { fireEvent, render, screen } from '@testing-library/react'

import OPRActionDialog from './OPRActionDialog'

jest.mock('@emotion/react', () => {
  const originalModule = jest.requireActual('@emotion/react')
  return {
    ...originalModule,
    useTheme: jest.fn(),
  }
})

describe('OPRActionDialog Component', () => {
  const mockTheme = {
    palette: {
      Invite: {
        main: '#000000',
      },
    },
  }

  beforeEach(() => {
    (useTheme as jest.Mock).mockReturnValue(mockTheme)
  })

  it('renders without crashing', () => {
    render(<OPRActionDialog open />)
    expect(screen.getAllByRole('presentation')[0]).toBeInTheDocument()
  })

  it('does not render when open is false', () => {
    render(<OPRActionDialog />)
    expect(screen.queryByRole('presentation')).not.toBeInTheDocument
  })

  it('displays the correct title and message', () => {
    const title = 'Test Title'
    const message = 'Test Message'
    render(<OPRActionDialog open message={message} title={title} />)
    expect(screen.getByText(title)).toBeInTheDocument()
    const regex = new RegExp(`\\$\\s*${message}`)
    expect(screen.getByText(regex)).toBeInTheDocument()
  })

  it('calls cancelHandler when the Cancel button is clicked', () => {
    const cancelHandler = jest.fn()
    render(<OPRActionDialog open cancelHandler={cancelHandler} />)
    fireEvent.click(screen.getByText('Cancel'))
    expect(cancelHandler).toHaveBeenCalled()
  })

  it('calls confirmHandler when the Confirm button is clicked', () => {
    const confirmHandler = jest.fn()
    render(<OPRActionDialog open confirmHandler={confirmHandler} />)
    fireEvent.click(screen.getByText('Confirm'))
    expect(confirmHandler).toHaveBeenCalled()
  })
})
