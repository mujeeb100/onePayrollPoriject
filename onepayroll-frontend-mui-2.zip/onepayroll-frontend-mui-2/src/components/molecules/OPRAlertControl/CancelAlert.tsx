import { useTheme } from '@emotion/react'
import {
  Box,
} from '@mui/material'
import { Info, RighCaretBlue } from 'assets/svg-images/SvgComponents'
import OPRButton from 'components/atoms/button/OPRButton'
import OPRLabel from 'components/atoms/label/OPRLabel'
import { CustomDialog } from 'components/atoms/modal/OPRModal'

        type Props = {
          title?:string,
          isCancel?:boolean
          handleCancel?:any
          callBack?:any
        };

function CancelAlert({
  title,
  isCancel = false,
  handleCancel = () => {
  },
  callBack = () => {},
  ...rest
}: Props) {
  const theme:any = useTheme() // Use the Theme type for the theme variable

  return (
    <Box>
      <CustomDialog
        CustomStyles={{ borderRadius: '16px' }}
        isOpen={isCancel}
        type="loader"
      >
        <div style={{ marginBottom: '15px' }}>
          <OPRLabel variant="h4">
            Are you sure you want to quit?
          </OPRLabel>
        </div>
        <Box
          className="pop-up"
          sx={{
            display: 'flex',
            padding: '12px',
            gap: '12px',
            alignItems: 'flex-start',
            borderRadius: '4px',
            alignSelf: 'stretch',
            backgroundColor: `${theme.palette.Invite.main}`,
            marginTop: 1,
          }}
        >
          <Info />
          <OPRLabel
            CustomStyles={{
              backgroundColor: `${theme.palette.Invite.main}`,
            }}
            backgroundColor={theme.palette.Invite.main}
            variant="body2"
          >
            Are you sure you want to quit without saving your changes? Any unsaved progress will be lost.
          </OPRLabel>
        </Box>
        <Box sx={{
          display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: 5,
        }}
        >
          <OPRButton color="info" variant="text" onClick={handleCancel}>
            Cancel
          </OPRButton>
          <>
            <OPRButton
              style={{ marginLeft: 'auto' }}
              variant="text"
              onClick={() => {
              // alert('back')
                handleCancel(false)
              }}
            >
              <RighCaretBlue />
              Back
            </OPRButton>
            <OPRButton
              color="info"
              variant="text"
              onClick={callBack}
            >
              Confirm
            </OPRButton>
          </>
        </Box>
      </CustomDialog>
    </Box>
  )
}

export default CancelAlert
