import { useTheme } from '@emotion/react'
import {
  Box,
} from '@mui/material'
import { ReactComponent as SuccessIcon } from 'assets/svg-icons/Tick.svg'
import OPRButton from 'components/atoms/button/OPRButton'
import OPRLabel from 'components/atoms/label/OPRLabel'
import { CustomDialog } from 'components/atoms/modal/OPRModal'
import { useEditable } from 'hooks/useEdit'
import { useEffect } from 'react'
import { useLocation, useNavigate } from 'react-router-dom'
import { routes } from 'routes/routes'
import { getParamsValue } from 'utils'

type Props = {
        label?: string;
        isEntity?: boolean;
        isSuccess?: boolean;
        isCustom?: boolean;
        isError?: boolean;
        handleCancelClick?: () => void;
        toggle?: (item: boolean) => void;
        customTitle?: string;
        customMessage?: any;
        title?:string
        name?:string
        handleSubmit?: (item:any) => void;
        onSetValue ?: (item:any) => void;
        onEditable ?: (item:any) => void;
        callBack ?: (type:any) => void;
        type?:string
        error?:any
        payCycleUpdatedName?: string
        setIsSuccessPayCycle?: any
        addAnother?:any
};

export function OPRSuccesControl({
  isEntity = false,
  isSuccess = false,
  setIsSuccessPayCycle,
  payCycleUpdatedName = '',
  isCustom = false,
  handleCancelClick,
  toggle = (item:any) => {},
  title = '',
  name = '',
  customTitle = '',
  customMessage = '',
  onSetValue = (item:any) => {},
  onEditable = (item:any) => {},
  callBack = () => {},
  error = false,
  type = 'New',
  addAnother,
  ...rest
}: Props) {
  const navigate = useNavigate()
  const theme:any = useTheme() // Use the Theme type for the theme variable
  const location: any = useLocation()
  const { viewUrl, id } = getParamsValue(location, routes.createCountry)
  const {
    isEditable,
    setEditable,
  } = useEditable()
  useEffect(() => {
    if (isSuccess) {
      setEditable(true)
    }
    // setEditable(true)
  }, [isSuccess])
  const onScreenClose = (item:any) => {
    setEditable(item)
    onEditable({})
    if (id === null) {
      onSetValue({})
    }
    callBack('success')
  }
  const { status, data }:any = error
  return (
    <Box>
      <CustomDialog
        CustomStyles={{ borderRadius: '16px' }}
        isOpen={isEditable}
        type="loader"
      >
        <div
          className="AtomPopupTitleStrip"
          style={{
            width: '100%', flexDirection: 'column', justifyContent: 'flex-start', alignItems: 'flex-start', gap: 16, display: 'inline-flex',
          }}
        >
          <div
            className="Header"
            style={{
              alignSelf: 'stretch', justifyContent: 'flex-start', alignItems: 'flex-start', gap: 8, display: 'inline-flex',
            }}
          >
            <div
              className="Icon"
              style={{
                paddingTop: 5, paddingBottom: 5, justifyContent: 'flex-start', alignItems: 'flex-start', display: 'flex',
              }}
            >
              <div className="Tick" style={{ width: 24, height: 24, position: 'relative' }}>
                <SuccessIcon />
              </div>
            </div>
            <div
              className="Text"
              style={{
                flex: '1 1 0', flexDirection: 'column', justifyContent: 'flex-start', alignItems: 'flex-start', display: 'inline-flex',
              }}
            >
              {customTitle.length > 0 ? (
                <OPRLabel CustomStyles={{ marginTop: 2 }} variant="h4">
                  {customTitle}
                </OPRLabel>
              ) : (
                <OPRLabel CustomStyles={{ marginTop: 2 }} variant="h4">
                  {!isEntity && type.toLocaleLowerCase() === 'update' ? title : 'New'}
                  {' '}
                  {type.toLocaleLowerCase() !== 'update' && title}
                  {' '}
                  {isEntity && 'Assigned'}
                  {!isEntity && (type.toLocaleLowerCase() === 'update' ? 'Updated' : 'Added')}
                </OPRLabel>
              )}

            </div>
          </div>
        </div>
        {customMessage.length > 0 ? (
          <OPRLabel CustomStyles={{ marginTop: 2 }} variant="body1">
            {/* {customMessage} */}
            <div dangerouslySetInnerHTML={{ __html: customMessage }} />
          </OPRLabel>
        ) : (
          <OPRLabel
            CustomStyles={{
              marginTop: '12px',
              display: 'flex',
              alignItems: 'center',
              gap: '12px',
            }}
            variant="body1"
          >
            {name}
            {' '}
            has been
            {' '}
            {payCycleUpdatedName || (type.toLocaleLowerCase() === 'new' ? 'added.' : 'updated.')}
            {' '}
            {type.toLocaleLowerCase() !== 'update' && ''}
          </OPRLabel>
        )}
        <Box sx={{
          display: 'flex', justifyContent: !isCustom ? 'space-between' : 'flex-end', marginTop: 5,
        }}
        >
          {(!isCustom && addAnother) ? (
            <OPRButton
              color="info"
              style={{ textAlign: 'left', paddingLeft: '15px' }} // Align button text to the left
              variant="text"
              onClick={() => {
                onScreenClose(true)
                onSetValue({})
                // setEditable(true)
              }}
            >
              {type.toLocaleLowerCase() === 'update' ? null : `Add Another ${title}`}
              {/* {type.toLocaleLowerCase() === 'update' ? `Update ${title}` : `Add Another ${title}`} */}

              {/* {`Add Another ${title}`} */}
            </OPRButton>

          ) : <div />}
          {type.toLocaleLowerCase() === 'update' && (
            <OPRButton
              color="info"
              style={{
                display: 'flex',
                padding: '8px 16px',
                alignItems: 'center',
                gap: '12px',
                color: '#FFF',
                background: 'var(--blue-blue-5000049-db, #0049DB)',
              }}
              variant="text"
              onClick={() => {
                if (!isEntity) {
                  navigate(-1)
                }
                if (setIsSuccessPayCycle) {
                  setIsSuccessPayCycle(false)
                }
                setEditable(false)
              }}
            >
              Close
            </OPRButton>
          )}
          {type.toLocaleLowerCase() !== 'update' && (
            <OPRButton
              color="info"
              style={{
                display: 'flex',
                padding: '8px 16px',
                alignItems: 'center',
                gap: '12px',
                color: '#FFF',
                background: 'var(--blue-blue-5000049-db, #0049DB)',
              }}
              variant="text"
              onClick={() => {
                if (isCustom) {
                  setEditable(false)
                  callBack('back')
                } else {
                  navigate(-1)
                  setEditable(false)
                }
                if (setIsSuccessPayCycle) {
                  setIsSuccessPayCycle(false)
                }
              }}
            >
              Close
            </OPRButton>
          )}
        </Box>
      </CustomDialog>
    </Box>
  )
}
