// funcs coverage not 100
import '@testing-library/jest-dom/extend-expect'

import { useTheme } from '@emotion/react'
import { fireEvent, render, screen } from '@testing-library/react'

import PayCycleAlert from './PyaCycleAdminAlert'

jest.mock('@emotion/react', () => {
  const originalModule = jest.requireActual('@emotion/react')
  return {
    ...originalModule,
    useTheme: jest.fn(),
  }
})

jest.mock('assets/svg-images/SvgComponents', () => ({
  Info: () => <svg data-testid="info-icon" />,
}))

describe('PayCycleAlert Component', () => {
  const mockTheme = {
    palette: {
      Invite: {
        main: '#f0f0f0',
      },
    },
  }

  const renderComponent = (props = {}) => render(
    <PayCycleAlert {...props} />,
  )

  beforeEach(() => {
    (useTheme as jest.Mock).mockReturnValue(mockTheme)
  })

  it('should not render', () => {
    renderComponent()
    expect(screen.queryByRole('presentation')).not.toBeInTheDocument
  })

  it('should render the component with default props', () => {
    renderComponent({ isCancelPayCycleAlert: true })
    expect(screen.getByText('Are you sure you want to undefined')).toBeInTheDocument()
    expect(screen.getByText('undefined will be undefined.')).toBeInTheDocument()
    expect(screen.getByText('Cancel')).toBeInTheDocument()
    expect(screen.getByText('Confirm')).toBeInTheDocument()
    expect(screen.getByTestId('info-icon')).toBeInTheDocument()
  })

  it('should render the component with props', () => {
    renderComponent({ title: 'cancel', name: 'PayCycle', isCancelPayCycleAlert: true })
    expect(screen.getByText('Are you sure you want to cancel')).toBeInTheDocument()
    expect(screen.getByText('PayCycle will be cancel.')).toBeInTheDocument()
    expect(screen.getByText('Cancel')).toBeInTheDocument()
    expect(screen.getByText('Confirm')).toBeInTheDocument()
    expect(screen.getByTestId('info-icon')).toBeInTheDocument()
  })

  it('should call handleCancelPayCycleAlert when Cancel button is clicked', () => {
    const handleCancelPayCycleAlert = jest.fn()
    renderComponent({ handleCancelPayCycleAlert, isCancelPayCycleAlert: true })
    const cancelButton = screen.getByText('Cancel')
    fireEvent.click(cancelButton)
    expect(handleCancelPayCycleAlert).toHaveBeenCalled()
  })

  it('should call callBack when Confirm button is clicked', () => {
    const callBack = jest.fn()
    renderComponent({ callBack, isCancelPayCycleAlert: true })
    const confirmButton = screen.getByText('Confirm')
    fireEvent.click(confirmButton)
    expect(callBack).toHaveBeenCalled()
  })
})
