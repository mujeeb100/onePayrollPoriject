// OPRConfirmationDialog is giving console warnings
// Warning: validateDOMNesting(...): <p> cannot appear as a descendant of <p>.
import '@testing-library/jest-dom/extend-expect'

import { SxProps } from '@mui/material'
import { render, screen } from '@testing-library/react'
import {
  TickIcon,
} from 'assets/svg-images/SvgComponents'
import { CSSProperties } from 'styled-components'

import { OPRConfirmationDialog } from './OPRConfirmationDialog'

export type OPRConfirmationDialogButtonLayout = 'close' | 'try-again' | 'confirm' | 'delete' | 'add-another'

export type OPRConfirmationDialogProps = {
    open: boolean
    error?: any
    icon?: React.ReactNode
    messageStyle?: CSSProperties
    titleStyle?: CSSProperties
    title: React.ReactNode | string
    message?: React.ReactNode | string
    infoMessage?: React.ReactNode | string
    errorMessage?: React.ReactNode | string
    buttonLayout: OPRConfirmationDialogButtonLayout
    titleSx?: SxProps
    addAnotherButtonTitle?: React.ReactNode | string
    onClose?: () => void
    onBack?: () => void
    onTryAgain?: () => void
    onConfirm?: () => void
    onCancel?: () => void
    onDelete?: () => void
    onAddAnother?: () => void
    info?: Record<string, any>
  };

const setupClose = (props: Partial<OPRConfirmationDialogProps> = {}) => {
  const mockCloseProps: OPRConfirmationDialogProps = {
    open: true,
    title: 'Test Title',
    buttonLayout: 'close',
    onClose: jest.fn(),
    ...props,
  }

  return render(
    <OPRConfirmationDialog {...mockCloseProps} />,
  )
}

const setupTryAgain = (props: Partial<OPRConfirmationDialogProps> = {}) => {
  const mockTryAgainProps: OPRConfirmationDialogProps = {
    open: true,
    title: 'Test Title',
    buttonLayout: 'try-again',
    onClose: jest.fn(),
    onBack: jest.fn(),
    onTryAgain: jest.fn(),
    ...props,
  }

  return render(
    <OPRConfirmationDialog {...mockTryAgainProps} />,
  )
}

const setupConfirm = (props: Partial<OPRConfirmationDialogProps> = {}) => {
  const mockConfirmProps: OPRConfirmationDialogProps = {
    open: true,
    title: 'Test Title',
    buttonLayout: 'confirm',
    onCancel: jest.fn(),
    onConfirm: jest.fn(),
    ...props,
  }

  return render(
    <OPRConfirmationDialog {...mockConfirmProps} />,
  )
}

const setupDelete = (props: Partial<OPRConfirmationDialogProps> = {}) => {
  const mockDeleteProps: OPRConfirmationDialogProps = {
    open: true,
    title: 'Test Title',
    buttonLayout: 'delete',
    onCancel: jest.fn(),
    onDelete: jest.fn(),
    ...props,
  }

  return render(
    <OPRConfirmationDialog {...mockDeleteProps} />,
  )
}

const setupAddAnother = (props: Partial<OPRConfirmationDialogProps> = {}) => {
  const mockAddAnotherProps: OPRConfirmationDialogProps = {
    open: true,
    title: 'Test Title',
    buttonLayout: 'add-another',
    onClose: jest.fn(),
    onAddAnother: jest.fn(),
    ...props,
  }

  return render(
    <OPRConfirmationDialog {...mockAddAnotherProps} />,
  )
}

describe('OPRConfirmationDialog Component', () => {
  test('should render close button layout', () => {
    setupClose()
    expect(screen.getByText('Test Title')).toBeInTheDocument()
    expect(screen.getByTestId('close-button')).toBeInTheDocument()
  })

  test('should close when close button is clicked for close button layout', () => {
    const onClose = jest.fn()
    setupClose({ onClose })
    const closeButton = screen.getByTestId('close-button')
    closeButton.click()
    expect(onClose).toHaveBeenCalled()
  })

  test('should render try-again button layout', () => {
    setupTryAgain()
    expect(screen.getByText('Test Title')).toBeInTheDocument()
    expect(screen.getByTestId('back-button')).toBeInTheDocument()
    expect(screen.getByTestId('try-again-button')).toBeInTheDocument()
    expect(screen.getByTestId('close-button')).toBeInTheDocument()
  })

  test('should go back when back button is clicked for try-again button layout', () => {
    const onBack = jest.fn()
    setupTryAgain({ onBack })
    const backButton = screen.getByTestId('back-button')
    backButton.click()
    expect(onBack).toHaveBeenCalled()
  })

  test('should try again when try again button is clicked for try-again button layout', () => {
    const onTryAgain = jest.fn()
    setupTryAgain({ onTryAgain })
    const tryAgainButton = screen.getByTestId('try-again-button')
    tryAgainButton.click()
    expect(onTryAgain).toHaveBeenCalled()
  })

  test('should close when close button is clicked for try-again button layout', () => {
    const onClose = jest.fn()
    setupTryAgain({ onClose })
    const closeButton = screen.getByTestId('close-button')
    closeButton.click()
    expect(onClose).toHaveBeenCalled()
  })

  test('should render confirm button layout', () => {
    setupConfirm()
    expect(screen.getByText('Test Title')).toBeInTheDocument()
    expect(screen.getByTestId('cancel-button')).toBeInTheDocument()
    expect(screen.getByTestId('confirm-button')).toBeInTheDocument()
  })

  test('should cancel when cancel button is clicked for confirm button layout', () => {
    const onCancel = jest.fn()
    setupConfirm({ onCancel })
    const cancelButton = screen.getByTestId('cancel-button')
    cancelButton.click()
    expect(onCancel).toHaveBeenCalled()
  })

  test('should confirm when confirm button is clicked for confirm button layout', () => {
    const onConfirm = jest.fn()
    setupConfirm({ onConfirm })
    const confirmButton = screen.getByTestId('confirm-button')
    confirmButton.click()
    expect(onConfirm).toHaveBeenCalled()
  })

  test('should render delete button layout', () => {
    setupDelete()
    expect(screen.getByText('Test Title')).toBeInTheDocument()
    expect(screen.getByTestId('cancel-button')).toBeInTheDocument()
    expect(screen.getByTestId('delete-button')).toBeInTheDocument()
  })

  test('should cancel when cancel button is clicked for delete button layout', () => {
    const onCancel = jest.fn()
    setupDelete({ onCancel })
    const cancelButton = screen.getByTestId('cancel-button')
    cancelButton.click()
    expect(onCancel).toHaveBeenCalled()
  })

  test('should delete when delete button is clicked for delete button layout', () => {
    const onDelete = jest.fn()
    setupDelete({ onDelete })
    const deleteButton = screen.getByTestId('delete-button')
    deleteButton.click()
    expect(onDelete).toHaveBeenCalled()
  })

  test('should render add-another button layout', () => {
    setupAddAnother()
    expect(screen.getByText('Test Title')).toBeInTheDocument()
    expect(screen.getByTestId('close-button')).toBeInTheDocument()
    expect(screen.getByTestId('add-another-button')).toBeInTheDocument()
  })

  test('should close when close button is clicked for add-another button layout', () => {
    const onClose = jest.fn()
    setupAddAnother({ onClose })
    const closeButton = screen.getByTestId('close-button')
    closeButton.click()
    expect(onClose).toHaveBeenCalled()
  })

  test('should add another when add another button is clicked for add-another button layout', () => {
    const onAddAnother = jest.fn()
    setupAddAnother({ onAddAnother })
    const addAnotherButton = screen.getByTestId('add-another-button')
    addAnotherButton.click()
    expect(onAddAnother).toHaveBeenCalled()
  })

  test('renders error messages when error prop is provided', () => {
    const error = {
      status: 500,
      data: {
        errors: [
          { code: 'error_code_1', message: 'Error message 1' },
          { code: 'error_code_2', message: 'Error message 2' },
        ],
      },
    }

    setupConfirm({ error })

    expect(screen.getByText('Error 500')).toBeInTheDocument()

    const errorMessages = screen.getAllByTestId('error-message')
    expect(errorMessages).toHaveLength(2)
  })

  test('should render nothing if invalid button layout is provided', () => {
    setupClose({ buttonLayout: undefined })
    expect(screen.getByText('Test Title')).toBeInTheDocument()
    expect(screen.queryByRole('button')).not.toBeInTheDocument()
  })

  test('should render icon if icon is provided', () => {
    setupClose({ icon: <TickIcon /> })
    expect(screen.getByTestId('icon')).toBeInTheDocument()
  })

  test('should render message if message is provided', () => {
    setupClose({ message: 'Test Message' })
    expect(screen.getByText('Test Message')).toBeInTheDocument()
  })

  test('should render info message if infoMessage is provided', () => {
    setupClose({ infoMessage: 'Test Info Message' })
    expect(screen.getByText('Test Info Message')).toBeInTheDocument()
  })

  test('should render error message if errorMessage is provided', () => {
    setupClose({ errorMessage: 'Test Error Message' })
    expect(screen.getByText('Test Error Message')).toBeInTheDocument()
  })
})
