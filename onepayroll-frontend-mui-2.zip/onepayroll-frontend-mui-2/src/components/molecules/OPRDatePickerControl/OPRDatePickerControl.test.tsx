// coverage not 100%
// onChange(null) test missing
import '@testing-library/jest-dom/extend-expect'

import { useTheme } from '@emotion/react'
import { fireEvent, render, screen } from '@testing-library/react'
import { t } from 'i18next'

import OPRDatePickerControl from './OPRDatePickerControl'

jest.mock('@emotion/react', () => {
  const originalModule = jest.requireActual('@emotion/react')
  return {
    ...originalModule,
    useTheme: jest.fn(),
  }
})

jest.mock('i18next', () => ({
  t: jest.fn(),
}))

describe('OPRDatePickerControl Component', () => {
  const mockTheme = {
    palette: {
      error: { contrastText: '#f00' },
    },
  }
  const renderComponent = (props = {}) => render(<OPRDatePickerControl {...props} />)

  beforeEach(() => {
    (useTheme as jest.Mock).mockReturnValue(mockTheme);
    (t as unknown as jest.Mock).mockImplementation((key) => key)
  })

  it('should render the label and optional text', () => {
    renderComponent({ label: 'Test Label', optionalText: 'Optional' })
    expect(screen.getByText('Test Label')).toBeInTheDocument()
    expect(screen.getByText('(Optional)')).toBeInTheDocument()
  })

  it('should render the date picker when not editable', () => {
    renderComponent({ isEditable: false })
    expect(screen.getByTestId('CalendarIcon')).toBeInTheDocument()
  })

  it('should call onChange with null when date picker value is null', () => {
    const handleChange = jest.fn()
    renderComponent({ isEditable: false, onChange: handleChange })
    const datePicker = screen.getByPlaceholderText('mm/dd/yyyy')
    fireEvent.change(datePicker, { target: { value: undefined } })
    expect(handleChange).not.toHaveBeenCalled()
  })

  it('should call onChange with the correct date when date picker value is valid', () => {
    const handleChange = jest.fn()
    renderComponent({ isEditable: false, onChange: handleChange })
    const datePicker = screen.getByPlaceholderText('mm/dd/yyyy')
    fireEvent.change(datePicker, { target: { value: '01/01/2023' } })
    expect(handleChange).toHaveBeenCalledWith(new Date('01/01/2023'))
  })

  it('should call onChange with null when date picker value is invalid', () => {
    const handleChange = jest.fn()
    renderComponent({ isEditable: false, onChange: handleChange })
    const datePicker = screen.getByPlaceholderText('mm/dd/yyyy')
    fireEvent.change(datePicker, { target: { value: 'invalid-date' } })
    expect(handleChange).not.toHaveBeenCalled()
  })

  it('should render the formatted date when editable', () => {
    renderComponent({ isEditable: true, value: '2023-01-01' })
    expect(screen.getByText('1 Jan 2023')).toBeInTheDocument()
  })

  it('should call onChange with the correct date when date picker value changes', () => {
    const handleChange = jest.fn()
    renderComponent({ isEditable: false, onChange: handleChange })
    const datePicker = screen.getByPlaceholderText('mm/dd/yyyy')
    fireEvent.change(datePicker, { target: { value: '01/01/2023' } })
    expect(handleChange).toHaveBeenCalledWith(new Date('01/01/2023'))
  })

  it('should display error message when error prop is provided', () => {
    renderComponent({ error: 'Test Error' })
    expect(screen.getByText('Test Error')).toBeInTheDocument()
  })
})
