import './index.css'

import { useTheme } from '@emotion/react'
import {
  Box,
} from '@mui/material'
import OPRDatePicker from 'components/atoms/datePicker/OPRDatePicker'
import OPRLabel from 'components/atoms/label/OPRLabel'
import { t } from 'i18next'
import { formatedDate } from 'utils'

type Props = {
      value?: any;
      onChange?: (date: Date | null) => void;
      disabled?: boolean;
      name?: string;
      isRequired?: boolean;
      max?: number;
      placeholder?: string;
      type?: string;
      maxLength?: number;
      error?: string;
      color?:any;
      label?: string;
      isEditable?: boolean;
      CustomStyles?: string;
  optionalText?:any; // Added optionalText prop
  dateFormate?:string

    };

function OPRDatePickerControl({
  value = null,
  onChange,
  disabled,
  name,
  label,
  isRequired = false,
  placeholder = '',
  type = 'text',
  maxLength,
  optionalText,
  error,
  color,
  isEditable,
  CustomStyles,
  dateFormate = 'D MMM YYYY',
  ...rest
}: Props) {
  const theme:any = useTheme() // Use the Theme type for the theme variable

  return (
    <Box>
      <OPRLabel
        CustomStyles={{
          display: 'flex',
          alignItems: 'flex-start',
          gap: '0px',
          alignSelf: 'stretch',
        }}
        color={error ? theme.palette.error.contrastText : ''}
      >
        {label ? t(label) : ''}
        {optionalText && ( // Conditionally render the optional text span
          <span style={{ fontWeight: 'lighter' }}>
            &nbsp;(
            {t(optionalText)}
            )
          </span>
        )}
      </OPRLabel>
      {isEditable && (
        <OPRLabel
          CustomStyles={{
            display: 'flex',
            alignItems: 'flex-start',
            gap: '8px',
            alignSelf: 'stretch',
          }}
          variant="body2"
        >
          <br />
          {value && formatedDate(value, dateFormate)}
        </OPRLabel>
      )}
      {!isEditable && (
        <OPRDatePicker
          CustomStyles={{
            width: '100%',
            borderRadius: '8px',
            border: error ? `1px solid ${theme.palette.error.contrastText}` : '',
          }}
          value={value}
          onChange={(item: any) => {
            if (onChange) {
              if (item == null) {
                onChange(null)
              } else if (item.isValid()) {
                onChange(new Date(item))
              } else {
                onChange(null)
              }
            }
          }}
        />
      )}
      {/* {error ? <OPRLabel color="error">Error Name</OPRLabel> : null} */}
      <OPRLabel color={error ? theme.palette.error.contrastText : ''} variant="body2">{error}</OPRLabel>
      {/* <OPRLabel color="red" variant="body2">{error}</OPRLabel> */}
    </Box>
  )
}

export default OPRDatePickerControl
