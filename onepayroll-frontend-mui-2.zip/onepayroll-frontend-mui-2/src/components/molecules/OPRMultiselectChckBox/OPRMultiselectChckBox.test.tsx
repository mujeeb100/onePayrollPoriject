import '@testing-library/jest-dom/extend-expect'

import { fireEvent, render, screen } from '@testing-library/react'

import OPRMultiselectChckBox from './OPRMultiselectChckBox'

const mockEmployees = [
  {
    code: 'E001', surname: 'Doe', givenName: 'John', employeeProfile: { displayName: 'John Doe' }, employeeCode: 'E001',
  },
  {
    code: 'E002', surname: 'Doe', givenName: 'Jane', employeeProfile: { displayName: 'Jane Doe' }, employeeCode: 'E002',
  },
]

const mockHandleCheckboxChange = jest.fn()
const mockHandleRemoveEmployee = jest.fn()
const mockHandleSelectAllChange = jest.fn()

describe('OPRMultiselectChckBox Component', () => {
  beforeEach(() => {
    render(
      <OPRMultiselectChckBox
        dataList={mockEmployees}
        handleCheckboxChange={mockHandleCheckboxChange}
        handleRemoveEmployee={mockHandleRemoveEmployee}
        handleSelectAllChange={mockHandleSelectAllChange}
        selectAll={false}
        selectedList={['E001']}
      />,
    )
  })

  test('renders Select All checkbox', () => {
    const selectAllCheckbox = screen.getByLabelText(/Select All/i)
    expect(selectAllCheckbox).toBeInTheDocument()
    expect(selectAllCheckbox).not.toBeChecked()
  })

  test('renders employee checkboxes', () => {
    const employeeCheckboxes = screen.getAllByRole('checkbox')
    expect(employeeCheckboxes).toHaveLength(3)
  })

  test('renders employee names and codes', () => {
    expect(screen.getByText('John Doe')).toBeInTheDocument()
    expect(screen.getByText('E001')).toBeInTheDocument()
    expect(screen.getByText('Jane Doe')).toBeInTheDocument()
    expect(screen.getByText('E002')).toBeInTheDocument()
  })

  test('handles individual checkbox change', () => {
    const employeeCheckbox = screen.getByText('John Doe')
    fireEvent.click(employeeCheckbox)
    expect(mockHandleCheckboxChange).toHaveBeenCalledWith(expect.any(Object), 'E001')
    const employeeCheckboxs = screen.getAllByTestId('employee-checkbox')
    expect(employeeCheckboxs[0]).toBeChecked()
  })

  test('handles Select All checkbox change', () => {
    const selectAllCheckbox = screen.getByLabelText(/Select All/i)
    fireEvent.click(selectAllCheckbox)
    expect(mockHandleSelectAllChange).toHaveBeenCalledWith(expect.any(Object))
  })

  test('unchecks the correct employee checkbox based on selectedList', () => {
    const employeeCheckbox = screen.getByText('Jane Doe')
    expect(employeeCheckbox).not.toBeChecked()
  })
})
