import { Typography, TypographyOwnProps } from '@mui/material'
import React from 'react'

type PageHeaderProps = {
  title: string
  subTitle?: string
  titleVariant: TypographyOwnProps['variant']
  subTitleVariant?: TypographyOwnProps['variant']
  titleComponent: React.ElementType
  subTitleComponent?: React.ElementType
}

function OPRPageHeader(props: PageHeaderProps) {
  const {
    title,
    subTitle,
    titleVariant,
    subTitleVariant,
    titleComponent,
    subTitleComponent,
  } = props
  return (
    <header>
      <Typography component={titleComponent || 'h1'} variant={titleVariant}>
        {title}
      </Typography>
      <Typography
        component={subTitleComponent || 'p'}
        variant={subTitleVariant}
      >
        {subTitle}
      </Typography>
    </header>
  )
}

export default OPRPageHeader
