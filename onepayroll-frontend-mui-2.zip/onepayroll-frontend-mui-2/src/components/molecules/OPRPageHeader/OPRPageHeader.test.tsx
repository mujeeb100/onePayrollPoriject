// Coverage is not 100% because in the OPRPageHeader component file, the default value for the titleComponent is never used.
// Line 24
//     <Typography component={titleComponent || 'h1'} variant={titleVariant}>
// The titleComponent prop is required and will always be provided.
import '@testing-library/jest-dom/extend-expect'

import { render, screen } from '@testing-library/react'

import OPRPageHeader from './index'

describe('OPRPageHeader Component', () => {
  it('renders title correctly without subtitle', () => {
    render(<OPRPageHeader
      title="Test Title"
      titleComponent="h1"
      titleVariant="h1"
    />)
    const titleElement = screen.getByText('Test Title')
    expect(titleElement).toBeInTheDocument()
    expect(titleElement.tagName).toBe('H1')
    expect(screen.queryByText('Test Subtitle')).toBeNull()
  })

  it('renders subtitle correctly', () => {
    render(<OPRPageHeader
      subTitle="Test Subtitle"
      title="Test Title"
      titleComponent="h1"
      titleVariant="h1"
    />)
    const subTitleElement = screen.getByText('Test Subtitle')
    expect(subTitleElement).toBeInTheDocument()
    expect(subTitleElement.tagName).toBe('P')
  })

  it('applies the correct variants', () => {
    render(<OPRPageHeader
      subTitle="Test Subtitle"
      subTitleComponent="p"
      subTitleVariant="body1"
      title="Test Title"
      titleComponent="h2"
      titleVariant="h2"
    />)
    const titleElement = screen.getByText('Test Title')
    const subTitleElement = screen.getByText('Test Subtitle')
    expect(titleElement).toHaveClass('MuiTypography-h2')
    expect(subTitleElement).toHaveClass('MuiTypography-body1')
  })
})
