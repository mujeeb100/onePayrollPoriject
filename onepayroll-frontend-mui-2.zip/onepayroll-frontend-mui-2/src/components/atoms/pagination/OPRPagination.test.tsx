import '@testing-library/jest-dom/extend-expect'

import { createTheme, ThemeProvider } from '@mui/material/styles'
import { fireEvent, render, screen } from '@testing-library/react'

import OPRPagination from './OPRPagination'

describe('OPRPagination Component', () => {
  const theme = createTheme()

  const renderWithTheme = (ui: any) => render(<ThemeProvider theme={theme}>{ui}</ThemeProvider>)

  const setup = (page: any, total: any, limit: any) => {
    const setPage = jest.fn()
    renderWithTheme(<OPRPagination limit={limit} page={page} setPage={setPage} total={total} />)
    return { setPage }
  }

  it('renders the pagination buttons and labels correctly', () => {
    setup(1, 100, 10)
    expect(screen.getByText('1')).toBeInTheDocument()
    expect(screen.getByText('of')).toBeInTheDocument()
    expect(screen.getByText('10')).toBeInTheDocument()
  })

  it('disables the first and previous buttons on the first page', () => {
    setup(1, 100, 10)
    const buttons = screen.getAllByRole('button')
    expect(buttons[0]).toBeDisabled() // First button (DoubleLeftIcon)
    expect(buttons[1]).toBeDisabled() // Previous button (LeftIcon)
  })

  it('disables the last and next buttons on the last page', () => {
    setup(10, 100, 10)
    const buttons = screen.getAllByRole('button')
    expect(buttons[2]).toBeDisabled() // Next button (RightCaretGray)
    expect(buttons[3]).toBeDisabled() // Last button (DoubleRightDisabledIcon)
  })

  it('calls setPage with the correct value when the first button is clicked', () => {
    const { setPage } = setup(5, 100, 10)
    const buttons = screen.getAllByRole('button')
    fireEvent.click(buttons[0]) // First button (DoubleLeftIcon)
    expect(setPage).toHaveBeenCalledWith(1)
  })

  it('calls setPage with the correct value when the previous button is clicked', () => {
    const { setPage } = setup(5, 100, 10)
    const buttons = screen.getAllByRole('button')
    fireEvent.click(buttons[1]) // Previous button (LeftIcon)
    expect(setPage).toHaveBeenCalledWith(4)
  })

  it('calls setPage with the correct value when the next button is clicked', () => {
    const { setPage } = setup(5, 100, 10)
    const buttons = screen.getAllByRole('button')
    fireEvent.click(buttons[2]) // Next button (RightCaretGray)
    expect(setPage).toHaveBeenCalledWith(6)
  })

  it('calls setPage with the correct value when the last button is clicked', () => {
    const { setPage } = setup(5, 100, 10)
    const buttons = screen.getAllByRole('button')
    fireEvent.click(buttons[3]) // Last button (DoubleRight)
    expect(setPage).toHaveBeenCalledWith(10)
  })
})
