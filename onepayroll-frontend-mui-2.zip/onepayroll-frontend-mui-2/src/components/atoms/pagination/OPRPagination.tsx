import { ReactComponent as DoubleLeftIcon } from 'assets/svg-icons/DoubleLeftIcon.svg'
import { ReactComponent as DoubleRightDisabledIcon } from 'assets/svg-icons/DoubleRightDisabledIcon.svg'
import { ReactComponent as LeftIcon } from 'assets/svg-icons/LeftIcon.svg'
import { ReactComponent as RightDisabledIcon } from 'assets/svg-icons/RightDisabledIcon.svg'
import {
  DoubleLeft, DoubleRight, LeftCaretGray, RightCaretGray,
} from 'assets/svg-images/SvgComponents'
import styled from 'styled-components'

const PaginationContainer = styled.div`
  display: flex;
  margin-top:50px;
  // background: aqua;
  align-items: center;
  > * {
    margin-right: 0.8rem;
  }
`

const PaginationButton = styled.button`
  display: flex;
  align-items: center;
  outline: none;
  border: none;
  border-radius: 50px;
  img {
    filter: invert(100%) sepia(0%) saturate(7500%) hue-rotate(175deg)
      brightness(121%) contrast(114%);
  }
  
  ${(props:any) => (props.disabled ? disabled : enabled)};
`

const enabled = `
cursor: pointer;
background-color: var(--color-primary);
transition: background-color 0.2s;

&:hover {
  background-color: var(--color-primary-dark);
}

&:active {
  background-color: var(--color-primary-light);
}
`

const disabled = `
  background-color: var(--color-primary-disabled);
`

const PaginationLabel = styled.label`
  font-size: 1.2rem;
  margin-bottom: 6px;
`

function OPRPagination({
  page, setPage, total, limit,
}:any) {
  const goToFirstPage = () => setPage(1)

  const goToLastPage = () => setPage(getLastPage())

  const incrementPage = () => page < getLastPage() && setPage(page + 1)

  const decrementPage = () => page > 1 && setPage(page - 1)

  const atFirstPage = () => page === 1

  const atLastPage = () => page === getLastPage()

  const getLastPage = () => Math.ceil(total / limit)

  return (
    <PaginationContainer>
      <PaginationButton
        disabled={atFirstPage()}
        onClick={() => goToFirstPage()}
      >
        {/* <DoubleLeftIcon /> */}
        {/* <DoubleLeft /> */}
        {
          atFirstPage() ? <DoubleLeft /> : <DoubleLeftIcon />
        }
      </PaginationButton>
      <PaginationButton
        disabled={atFirstPage()}
        onClick={() => decrementPage()}
      >

        {/* <LeftIcon /> */}
        {
          atFirstPage() ? <LeftCaretGray /> : <LeftIcon />
        }
        {/* <LeftCaretGray /> */}
      </PaginationButton>
      <PaginationLabel>
        <span style={{
          borderRadius: '5px',
          border: '1px solid #B5B3B4',
          padding: '5px 8px 5px 8px',
          fontSize: '14px',
        }}
        >
          {page}
        </span>
        <span style={{
          padding: '5px 8px 5px 8px',
          fontSize: '14px',
        }}
        >
          of
        </span>
        <span style={{
          padding: '5px 8px 5px 8px',
          fontSize: '14px',
        }}
        >
          {getLastPage()}
        </span>
      </PaginationLabel>
      <PaginationButton disabled={atLastPage()} onClick={incrementPage}>
        {/* <RightCaretGray /> */}
        {atLastPage() ? <RightDisabledIcon /> : <RightCaretGray /> }

      </PaginationButton>
      <PaginationButton disabled={atLastPage()} onClick={goToLastPage}>
        {/* <DoubleRight /> */}
        {
          atLastPage() ? <DoubleRightDisabledIcon /> : <DoubleRight />
        }
      </PaginationButton>
    </PaginationContainer>
  )
}

export default OPRPagination
