import { Check } from '@mui/icons-material'
import CircleOutlinedIcon from '@mui/icons-material/CircleOutlined'
import { StepButton } from '@mui/material'
import Stack from '@mui/material/Stack'
import Step from '@mui/material/Step'
import StepConnector, {
  stepConnectorClasses,
} from '@mui/material/StepConnector'
import { StepIconProps } from '@mui/material/StepIcon'
import StepLabel from '@mui/material/StepLabel'
import Stepper from '@mui/material/Stepper'
import { styled } from '@mui/material/styles'
import { IOPRStepperProps } from 'interfaces'
import { useTranslation } from 'react-i18next'

const StepperConnector = styled(StepConnector)(({ theme }) => ({
  [`&.${stepConnectorClasses.alternativeLabel}`]: {
    top: 10,
    left: 'calc(-50% + 16px)',
    right: 'calc(50% + 16px)',
  },
  [`&.${stepConnectorClasses.active}`]: {
    [`& .${stepConnectorClasses.line}`]: {
      borderColor: theme.palette.primary.main,
    },
  },
  [`&.${stepConnectorClasses.completed}`]: {
    [`& .${stepConnectorClasses.line}`]: {
      borderColor: theme.palette.primary.main,
    },
  },
  [`& .${stepConnectorClasses.line}`]: {
    borderColor:
      theme.palette.mode === 'dark' ? theme.palette.grey[800] : '#eaeaf0',
    borderTopWidth: 3,
    borderRadius: 1,
  },
}))

const ProgressStepIconRoot = styled('div')<{ ownerState: { active?: boolean } }>(
  ({ theme, ownerState }) => ({
    color: theme.palette.mode === 'dark' ? theme.palette.grey[700] : '#eaeaf0',
    display: 'flex',
    height: 22,
    alignItems: 'center',
    ...(ownerState.active && {
      color: theme.palette.primary.main,
    }),
    '& .QontoStepIcon-completedIcon': {
      color: theme.palette.primary.contrastText,
      backgroundColor: theme.palette.primary.main,
      width: 24,
      height: 24,
      borderRadius: '50%',
      zIndex: 1,
      fontSize: 18,
    },
    '& .QontoStepIcon-circle': {
      width: 24,
      height: 24,
      borderRadius: '50%',
      backgroundColor: 'currentColor',
    },
  }),
)

function QontoStepIcon(props: StepIconProps) {
  const { active, completed, className } = props

  return (
    <ProgressStepIconRoot className={className} ownerState={{ active }}>
      {completed ? (
        <Check className="QontoStepIcon-completedIcon" />
      ) : (
        <CircleOutlinedIcon className="QontoStepIcon-circle" />
      )}
    </ProgressStepIconRoot>
  )
}

export default function OPRStepper({
  alternativeLabel = true,
  activeStep = 0, // Numbers from 0 to steps.length - 1. 0 means first step, 1 means second step, etc.
  steps, // Make sure to pass "Localazy" keys(in array) of the steps as the values
}: IOPRStepperProps) {
  const { t } = useTranslation()
  if (!steps || steps.length === 0) return null
  return (
    <Stack spacing={4} sx={{ width: '100%' }}>
      <Stepper
        activeStep={activeStep}
        alternativeLabel={alternativeLabel}
        connector={<StepperConnector />}
        sx={{ border: '2px solid #0049DB', py: 5, borderRadius: 5 }}
      >
        {steps.map((label) => (
          <Step key={label}>
            <StepButton>
              <StepLabel StepIconComponent={QontoStepIcon}>
                {t(label)}
              </StepLabel>
            </StepButton>
          </Step>
        ))}
      </Stepper>
    </Stack>
  )
}
