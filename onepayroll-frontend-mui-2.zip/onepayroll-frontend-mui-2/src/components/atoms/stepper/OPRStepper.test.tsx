import '@testing-library/jest-dom/extend-expect'

import { createTheme, ThemeProvider } from '@mui/material/styles'
import { render, screen } from '@testing-library/react'
import customTheme from 'themes'

import OPRStepper from './index'
// Mock the useTranslation hook
jest.mock('react-i18next', () => ({
  useTranslation: () => ({
    t: (key: any) => key,
  }),
}))

// we cant achieve 100% coverage because activeStep is always going to be provided.
describe('OPRStepper Component', () => {
  const renderWithTheme = (ui: any) => render(<ThemeProvider theme={customTheme}>{ui}</ThemeProvider>)
  const renderWithTheme2 = (ui: any, theme: any) => render(<ThemeProvider theme={theme}>{ui}</ThemeProvider>)

  it('renders the Stepper with the correct steps', () => {
    const steps = ['Step 1', 'Step 2', 'Step 3']
    renderWithTheme(<OPRStepper activeStep={0} steps={steps} />)
    steps.forEach((step) => {
      expect(screen.getByText(step)).toBeInTheDocument()
    })
  })

  it('renders the Stepper with the correct active step', () => {
    const steps = ['Step 1', 'Step 2', 'Step 3']
    renderWithTheme(<OPRStepper activeStep={1} steps={steps} />)
    const activeStep = screen.getByText('Step 2')
    expect(activeStep).toBeInTheDocument()
  })

  it('renders the Stepper with the correct step icons', () => {
    const steps = ['Step 1', 'Step 2', 'Step 3']
    const darkTheme = createTheme({
      palette: {
        primary: {
          main: '#1976d2',
          contrastText: '#fff',
        },
        mode: 'dark',
        grey: {
          700: '#b0bec5',
          800: '#37474f',
        },
      },
    })
    renderWithTheme2(<OPRStepper activeStep={0} steps={steps} />, darkTheme)
    const stepIcons = screen.getAllByTestId('CircleOutlinedIcon')
    expect(stepIcons.length).toBe(steps.length)
  })

  it('renders null when no steps are provided', () => {
    const lightTheme = createTheme({
      palette: {
        primary: {
          main: '#1976d2',
          contrastText: '#fff',
        },
        mode: 'light',
        grey: {
          700: '#b0bec5',
          800: '#37474f',
        },
      },
    })
    const { container } = renderWithTheme2(<OPRStepper activeStep={0} steps={[]} />, lightTheme)
    expect(container.firstChild).toBeNull()
  })
})
