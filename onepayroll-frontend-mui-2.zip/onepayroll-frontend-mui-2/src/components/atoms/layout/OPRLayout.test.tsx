import '@testing-library/jest-dom/extend-expect'

import { createTheme, ThemeProvider } from '@mui/material/styles'
import { render, screen } from '@testing-library/react'

import OPRLayout from './OPRLayout'

describe('OPRLayout Component', () => {
  const theme = createTheme()

  const renderWithTheme = (ui: any) => render(<ThemeProvider theme={theme}>{ui}</ThemeProvider>)

  it('renders the children correctly', () => {
    renderWithTheme(<OPRLayout>Test Children</OPRLayout>)
    const childrenElement = screen.getByText('Test Children')
    expect(childrenElement).toBeInTheDocument()
  })

  it('applies the correct component', () => {
    renderWithTheme(<OPRLayout component="section">Test Section</OPRLayout>)
    const sectionElement = screen.getByText('Test Section')
    expect(sectionElement.tagName).toBe('SECTION')
  })

  it('applies additional props to the Box component', () => {
    renderWithTheme(<OPRLayout className="test-class" id="test-id">Test Props</OPRLayout>)
    const boxElement = screen.getByText('Test Props')
    expect(boxElement).toHaveAttribute('id', 'test-id')
    expect(boxElement).toHaveClass('test-class')
  })

  it('renders with the default component when no component prop is provided', () => {
    renderWithTheme(<OPRLayout>Default Component</OPRLayout>)
    const defaultElement = screen.getByText('Default Component')
    expect(defaultElement.tagName).toBe('DIV')
  })
})
