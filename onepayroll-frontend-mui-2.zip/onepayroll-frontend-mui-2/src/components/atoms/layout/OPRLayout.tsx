import {
  Box, BoxProps, Theme,
} from '@mui/material'
import React from 'react'

type Props = BoxProps & {
 theme?: Theme
};

function OPRLayout({
  children, theme, component = 'div', ...pops
}: Props) {
  const box = (
    <Box
      component={component}
      {...pops}
    >
      {children}
    </Box>
  )
  return (
    <Box
      component={component}
      {...pops}
    >
      {children}
    </Box>
  )
}

export default OPRLayout
