import { PayCycleStatus } from 'types'

import OPRChip from './OPRChip'

type OPRStatusChipProps = {
    status: PayCycleStatus
}

const OPRStatusMap = {
  Finalized: { label: 'Finalised', color: '#00701C', backgroundColor: '#EBFFF0' },
  Unfinalized: { label: 'Unfinalized', color: '#3B3839', backgroundColor: '#E8E6E7' },
  Locked: { label: 'Locked', color: '#0049DB', backgroundColor: '#E9F4FF' },
  Unlocked: { label: 'Unlocked', color: '#3B3839', backgroundColor: '#E8E6E7' },
  'PF Dropped': { label: 'PF Dropped', color: '#3B3839', backgroundColor: '#E8E6E7' },
  Open: { label: 'Open', color: '#9E5A00', backgroundColor: '#FFF7EB' },
  Inactive: { label: 'Inactive', color: '#3B3839', backgroundColor: '#E8E6E7' },
  Unknown: { label: 'Unknown', color: '#3B3839', backgroundColor: '#E8E6E7' },
  Completed: { label: 'Completed', color: '#9E5A00', backgroundColor: '#FFF7EB' },
}

function OPRStatusChip({
  status,
}: OPRStatusChipProps) {
  const config = OPRStatusMap[status] || OPRStatusMap.Unknown
  return (
    <OPRChip
      label={config.label}
      sx={{
        height: 'auto',
        backgroundColor: config.backgroundColor,
        '& .MuiChip-label': {
          margin: '3px 0px',
          color: config.color,
          fontWeight: 700,
        },
      }}
    />
  )
}

export default OPRStatusChip
