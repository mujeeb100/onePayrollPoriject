import '@testing-library/jest-dom/extend-expect'

import { render, screen } from '@testing-library/react'
import { PayCycleStatus } from 'types'

import OPRStatusChip from './OPRStatusChip'

describe('OPRStatusChip Component', () => {
  const statuses: PayCycleStatus[] = [
    'Finalized',
    'Unfinalized',
    'Locked',
    'Unlocked',
    'PF Dropped',
    'Open',
    'Inactive',
    'Completed',
  ]

  const OPRStatusMap = {
    Finalized: { label: 'Finalised', color: '#00701C', backgroundColor: '#EBFFF0' },
    Unfinalized: { label: 'Unfinalized', color: '#3B3839', backgroundColor: '#E8E6E7' },
    Locked: { label: 'Locked', color: '#0049DB', backgroundColor: '#E9F4FF' },
    Unlocked: { label: 'Unlocked', color: '#3B3839', backgroundColor: '#E8E6E7' },
    'PF Dropped': { label: 'PF Dropped', color: '#3B3839', backgroundColor: '#E8E6E7' },
    Open: { label: 'Open', color: '#9E5A00', backgroundColor: '#FFF7EB' },
    Inactive: { label: 'Inactive', color: '#3B3839', backgroundColor: '#E8E6E7' },
    Unknown: { label: 'Unknown', color: '#3B3839', backgroundColor: '#E8E6E7' },
    Completed: { label: 'Completed', color: '#9E5A00', backgroundColor: '#FFF7EB' },
  }

  statuses.forEach((status) => {
    it(`renders the correct label and styles for status: ${status}`, () => {
      render(<OPRStatusChip status={status} />)
      const config = OPRStatusMap[status] || OPRStatusMap.Unknown
      const chip = screen.getByText(config.label)

      const chipElement = chip.closest('.MuiChip-root')
      if (chipElement != null) {
        expect(chipElement).toHaveStyle(`background-color: ${config.backgroundColor}`)
      }

      expect(chip).toBeInTheDocument()
      expect(chip).toHaveStyle(`color: ${config.color}`)
      expect(chip).toHaveStyle('font-weight: 700')
    })
  })

  it('renders the correct label and styles for an unknown status', () => {
    // @ts-expect-error For testing purpose
    const unknownStatus: PayCycleStatus = 'NonExistentStatus' // This is an unknown status
    render(<OPRStatusChip status={unknownStatus} />)
    const config = OPRStatusMap.Unknown
    const chip = screen.getByText(config.label)

    const chipElement = chip.closest('.MuiChip-root')
    if (chipElement != null) {
      expect(chipElement).toHaveStyle(`background-color: ${config.backgroundColor}`)
    }

    expect(chip).toBeInTheDocument()
    expect(chip).toHaveStyle(`color: ${config.color}`)
    expect(chip).toHaveStyle('font-weight: 700')
  })
})
