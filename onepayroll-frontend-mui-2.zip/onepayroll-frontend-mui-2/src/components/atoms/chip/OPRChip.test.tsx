import '@testing-library/jest-dom/extend-expect'

import { createTheme, ThemeProvider } from '@mui/material'
import { render, screen } from '@testing-library/react'

import OPRChip from './OPRChip'

describe('OPRChip Component', () => {
  const theme = createTheme()
  const label = 'Test Chip'

  it('renders the component', () => {
    render(
      <ThemeProvider theme={theme}>
        <OPRChip label={label} />
      </ThemeProvider>,
    )
    expect(screen.getByText(label)).toBeInTheDocument()
  })

  it('displays the correct label', () => {
    render(
      <ThemeProvider theme={theme}>
        <OPRChip label={label} />
      </ThemeProvider>,
    )
    const chip = screen.getByText(label)
    expect(chip).toHaveTextContent(label)
  })
})
