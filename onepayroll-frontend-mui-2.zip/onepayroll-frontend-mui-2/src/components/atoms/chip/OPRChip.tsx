import { Chip, SxProps, Theme } from '@mui/material'

type OPRChipProps = {
    label: string
    sx?: SxProps<Theme>
}

function OPRChip({
  label, sx = {},
}: OPRChipProps) {
  return (
    <Chip
      label={label}
      sx={{ ...sx }}
    />
  )
}

export default OPRChip
