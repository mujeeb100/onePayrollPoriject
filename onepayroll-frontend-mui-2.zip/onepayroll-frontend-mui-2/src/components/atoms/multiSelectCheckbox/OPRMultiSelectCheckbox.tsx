import { useTheme } from '@emotion/react'
import {
  Box,
  Checkbox,
  FormControl,
  ListItemText,
  MenuItem,
} from '@mui/material'
import Select, { SelectChangeEvent } from '@mui/material/Select'
import OPRLabel from 'components/atoms/label/OPRLabel'
import { t } from 'i18next'

type Option = {
  name: string;
  value: string;
};

type Props = {
  value?: string[];
  onChange?: (value: string[]) => void;
  disabled?: boolean;
  name?: string;
  isRequired?: boolean;
  placeholder?: string;
  label?: string;
  options: Option[];
  error?: string;
  optionalText?: string;
  isEditable?: boolean;
};

function OPRMultiSelect({
  value = [],
  onChange,
  disabled,
  name,
  label,
  isRequired = false,
  placeholder = '',
  options,
  error,
  optionalText = '',
  isEditable = true,
}: Props) {
  const theme: any = useTheme()

  const handleChange = (event: SelectChangeEvent<string[]>) => {
    if (onChange) {
      onChange(event.target.value as string[])
    }
  }

  return (
    <Box
      sx={{
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'flex-start',
        gap: '4px',
        flex: '1 0 0',
      }}
    >
      <OPRLabel
        CustomStyles={{
          display: 'flex',
          alignItems: 'flex-start',
          gap: '0px',
          alignSelf: 'stretch',
        }}
        color={error ? theme.palette.error.contrastText : ''}
      >
        {label ? t(label) : ''}
        {optionalText && (
          <span style={{ fontWeight: 'lighter' }}>
&nbsp;(
            {t(optionalText)}
            )
          </span>
        )}
      </OPRLabel>
      <FormControl className="multi-check-box" sx={{ width: '100%' }}>
        {/* <InputLabel id={`${name}-label`}>{placeholder}</InputLabel> */}
        <Select
          multiple
          id={name}
          labelId={`${name}-label`}
          placeholder={placeholder}
          renderValue={(selected: string[]) => selected.join(', ')}
          style={{
            padding: '0px !important',
            width: '100%',
            borderRadius: '8px',
            height: '40px',
            border: error ? `1px solid ${theme.palette.error.contrastText}` : '',
          }}
          // style={{ height: 40 }}
          value={value}
          variant="outlined"
          onChange={handleChange}
          //   input={<OutlinedInput label={placeholder} />}
        >
          {options.map((option) => (
            <MenuItem key={option.value} value={option.value}>
              <Checkbox checked={value?.indexOf(option.value) > -1} />
              <ListItemText primary={option.name} />
            </MenuItem>
          ))}
        </Select>
      </FormControl>
      <OPRLabel color={error ? theme.palette.error.contrastText : ''} variant="body2">
        {error}
      </OPRLabel>
    </Box>
  )
}

export default OPRMultiSelect
