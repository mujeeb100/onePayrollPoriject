// Coverage not 100% due to line 36
//    const updatedValue = Array.isArray(value) ? value : [value]
// this code ensures that value is always an array
// not sure how to test this line
import '@testing-library/jest-dom/extend-expect'

import { fireEvent, render, screen } from '@testing-library/react'

import OPRMultiSelectCheckbox from './index'

const mockOptions = [
  { id: 1, roleName: 'Admin', roleCode: 'ADMIN' },
  { id: 2, roleName: 'User', roleCode: 'USER' },
  { id: 3, roleName: 'Guest', roleCode: 'GUEST' },
]

const mockAltOptions = [
  { id: 1, roleCode: 'ADMIN' },
  { id: 2, roleCode: 'USER' },
  { id: 3, roleCode: 'GUEST' },
]

const renderValue = (selected: any[]) => selected.map((option: { roleName: any }) => option.roleName).join(', ')

describe('OPRMultiSelectCheckbox', () => {
  let selectedOptions: any[]
  let setSelectedOptions: jest.Mock<void, [newOptions: any]>

  beforeEach(() => {
    selectedOptions = []
    setSelectedOptions = jest.fn((newOptions) => {
      selectedOptions = newOptions
    })
  })

  test('renders without crashing', () => {
    render(
      <OPRMultiSelectCheckbox
        listOfOptions={mockOptions}
        renderValue={renderValue}
        selectedOptions={selectedOptions}
        setSelectedOptions={setSelectedOptions}
      />,
    )

    expect(screen.getByRole('combobox')).toBeInTheDocument()
    expect(screen.getByTestId('form')).toHaveStyle('width: 150px')
  })

  test('displays options when clicked', () => {
    render(
      <OPRMultiSelectCheckbox
        listOfOptions={mockOptions}
        renderValue={renderValue}
        selectedOptions={selectedOptions}
        setSelectedOptions={setSelectedOptions}
      />,
    )

    fireEvent.mouseDown(screen.getByRole('combobox'))
    mockOptions.forEach((option) => {
      expect(screen.getByText(option.roleName)).toBeInTheDocument()
    })
  })

  test('selects and deselects options', () => {
    render(
      <OPRMultiSelectCheckbox
        listOfOptions={mockOptions}
        renderValue={renderValue}
        selectedOptions={selectedOptions}
        setSelectedOptions={setSelectedOptions}
      />,
    )

    fireEvent.mouseDown(screen.getByRole('combobox'))
    const adminOption = screen.getByText('Admin')
    fireEvent.click(adminOption)

    expect(setSelectedOptions).toHaveBeenCalledWith([mockOptions[0]])
    expect(selectedOptions).toEqual([mockOptions[0]])

    fireEvent.click(adminOption)
    expect(setSelectedOptions).toHaveBeenCalled()
    expect(selectedOptions).toEqual([mockOptions[0]])
  })

  test('renders selected options correctly', () => {
    selectedOptions = [mockOptions[0], mockOptions[1]]

    render(
      <OPRMultiSelectCheckbox
        listOfOptions={mockOptions}
        renderValue={renderValue}
        selectedOptions={selectedOptions}
        setSelectedOptions={setSelectedOptions}
      />,
    )

    expect(screen.getByRole('combobox')).toHaveTextContent('Admin, User')
  })

  test('should rendor form with correct width', () => {
    render(
      <OPRMultiSelectCheckbox
        fullWidth
        listOfOptions={mockOptions}
        renderValue={renderValue}
        selectedOptions={selectedOptions}
        setSelectedOptions={setSelectedOptions}
      />,
    )
    expect(screen.getByTestId('form')).toHaveStyle('width: 420px')
  })

  test('renders with correct text if roleName not available', () => {
    render(
      <OPRMultiSelectCheckbox
        listOfOptions={mockAltOptions}
        renderValue={renderValue}
        selectedOptions={selectedOptions}
        setSelectedOptions={setSelectedOptions}
      />,
    )
    fireEvent.mouseDown(screen.getByRole('combobox'))
    mockAltOptions.forEach((option) => {
      expect(screen.getByText(option.roleCode)).toBeInTheDocument()
    })
    const options = screen.getAllByRole('option')
    expect(options).toHaveLength(3)
  })

  //   test('value should always be an array', () => {
  //     const handleChange = jest.fn((event) => {
  //       const { target: { value } } = event
  //       const updatedValue = Array.isArray(value) ? value : [value]
  //       selectedOptions = updatedValue
  //     })

  //     render(
  //       <OPRMultiSelectCheckbox
  //         listOfOptions={mockOptions}
  //         renderValue={renderValue}
  //         selectedOptions={selectedOptions}
  //         setSelectedOptions={handleChange}
  //       />,
  //     )

//     fireEvent.mouseDown(screen.getByRole('combobox'))
//     const adminOption = screen.getByText('Admin')
//     fireEvent.click(adminOption)
//     expect(handleChange).toHaveBeenCalled()
//     const callValue = handleChange.mock.calls[0][0]
//     expect(callValue).toEqual([mockOptions[0]])
//     expect(renderValue(callValue)).toBe('Admin')
//   })
})
