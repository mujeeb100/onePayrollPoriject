import '@testing-library/jest-dom/extend-expect'

import { fireEvent, render, screen } from '@testing-library/react'

import OPRSelectCheckbox from './OPRSelectCheckbox'

const mockOptions = [
  { id: 1, roleName: 'Admin', roleCode: 'ADMIN' },
  { id: 2, roleName: 'User', roleCode: 'USER' },
  { id: 3, roleName: 'Guest', roleCode: 'GUEST' },
]

const mockAltOptions = [
  { id: 1, roleCode: 'ADMIN' },
  { id: 2, roleCode: 'USER' },
  { id: 3, roleCode: 'GUEST' },
]

const renderValue = (selected: any[]) => selected.map((option: { roleName: any }) => option.roleName).join(', ')

describe('OPRSelectCheckbox', () => {
  let selectedOptions: any[]
  let setSelectedOptions: jest.Mock<void, [newOptions: any]>

  beforeEach(() => {
    selectedOptions = []
    setSelectedOptions = jest.fn((newOptions) => {
      selectedOptions = newOptions
    })
  })

  test('renders without crashing', () => {
    render(
      <OPRSelectCheckbox
        listOfOptions={mockOptions}
        renderValue={renderValue}
        selectedOptions={selectedOptions || null}
        setSelectedOptions={setSelectedOptions}
      />,
    )

    expect(screen.getByRole('combobox')).toBeInTheDocument()
    expect(screen.getByTestId('form')).toHaveStyle({ width: '210px' })
  })

  test('displays options when clicked', () => {
    render(
      <OPRSelectCheckbox
        listOfOptions={mockOptions}
        renderValue={renderValue}
        selectedOptions={selectedOptions || null}
        setSelectedOptions={setSelectedOptions}
      />,
    )

    fireEvent.mouseDown(screen.getByRole('combobox'))
    mockOptions.forEach((option) => {
      expect(screen.getByText(option.roleName)).toBeInTheDocument()
    })
    const options = screen.getAllByRole('option')
    expect(options).toHaveLength(3)
  })

  test('selects and deselects options in multi-select mode', () => {
    render(
      <OPRSelectCheckbox
        isMultiSelect
        listOfOptions={mockOptions}
        renderValue={renderValue}
        selectedOptions={selectedOptions || null}
        setSelectedOptions={setSelectedOptions}
      />,
    )
    const selectBox = screen.getByRole('combobox')
    fireEvent.mouseDown(selectBox)

    const adminOption = screen.getByRole('option', { name: 'Admin' })
    const userOption = screen.getByRole('option', { name: 'User' })

    fireEvent.click(adminOption)
    expect(setSelectedOptions).toHaveBeenCalled()
    expect(selectedOptions).toEqual([mockOptions[0]])

    fireEvent.click(userOption)
    expect(setSelectedOptions).toHaveBeenCalled()
    expect(selectedOptions).toEqual([mockOptions[1]])

    fireEvent.click(adminOption)
    expect(setSelectedOptions).toHaveBeenCalled()
    expect(selectedOptions).toEqual([mockOptions[0]])
  })

  test('selects a single option in single-select mode', () => {
    render(
      <OPRSelectCheckbox
        isMultiSelect={false}
        listOfOptions={mockOptions}
        renderValue={renderValue}
        selectedOptions={selectedOptions || null}
        setSelectedOptions={setSelectedOptions}
      />,
    )

    fireEvent.mouseDown(screen.getByRole('combobox'))
    const adminOption = screen.getByText('Admin')
    fireEvent.click(adminOption)

    expect(setSelectedOptions).toHaveBeenCalledWith([mockOptions[0]])
    expect(selectedOptions).toEqual([mockOptions[0]])
  })

  test('renders selected options correctly', () => {
    selectedOptions = [mockOptions[0], mockOptions[1]]

    render(
      <OPRSelectCheckbox
        isMultiSelect
        listOfOptions={mockOptions}
        renderValue={renderValue}
        selectedOptions={selectedOptions || null}
        setSelectedOptions={setSelectedOptions}
      />,
    )

    expect(screen.getByRole('combobox')).toHaveTextContent('Admin, User')
  })

  test('renders correct widths', () => {
    render(
      <OPRSelectCheckbox
        fullWidth
        listOfOptions={mockOptions}
        renderValue={renderValue}
        selectedOptions={selectedOptions || null}
        setSelectedOptions={setSelectedOptions}
      />,
    )
    expect(screen.getByTestId('form')).toHaveStyle({ width: '420px' })
  })

  test('renders with correct text if roleName not available', () => {
    render(
      <OPRSelectCheckbox
        listOfOptions={mockAltOptions}
        renderValue={renderValue}
        selectedOptions={selectedOptions || null}
        setSelectedOptions={setSelectedOptions}
      />,
    )
    fireEvent.mouseDown(screen.getByRole('combobox'))
    mockAltOptions.forEach((option) => {
      expect(screen.getByText(option.roleCode)).toBeInTheDocument()
    })
    const options = screen.getAllByRole('option')
    expect(options).toHaveLength(3)
  })
})
