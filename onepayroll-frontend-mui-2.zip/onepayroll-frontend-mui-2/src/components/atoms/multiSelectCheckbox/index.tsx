import KeyboardArrowDownOutlinedIcon from '@mui/icons-material/KeyboardArrowDownOutlined'
import {
  Checkbox,
} from '@mui/material'
import FormControl from '@mui/material/FormControl'
import ListItemText from '@mui/material/ListItemText'
import MenuItem from '@mui/material/MenuItem'
import Select, { SelectChangeEvent } from '@mui/material/Select'
import { IOPRMultiSelectCheckboxProps } from 'interfaces'
import { useState } from 'react'

function OPRMultiSelectCheckbox({
  selectedOptions,
  setSelectedOptions,
  listOfOptions,
  renderValue,
  fullWidth = false,
  sx = { formSx: {} },
}: IOPRMultiSelectCheckboxProps) {
  const { value, setValue }:any = useState()
  const ITEM_HEIGHT = 48
  const ITEM_PADDING_TOP = 8
  const MenuProps = {
    PaperProps: {
      sx: {
        maxHeight: ITEM_HEIGHT * 4.5 + ITEM_PADDING_TOP,
        width: 120,
      },
    },
  }
  const handleChange = (event: SelectChangeEvent<typeof selectedOptions>) => {
    const {
      target: { value },
    } = event

    // Ensure value is always an array
    const updatedValue = Array.isArray(value) ? value : [value]

    // Update the selected options based on the new value
    setSelectedOptions(updatedValue)
  }

  const onChange = (e:any) => {
    setValue(e.target.value)
  }

  return (
    <FormControl data-testid="form" sx={{ m: 0, width: fullWidth ? 420 : 150, ...sx.formSx }}>
      <Select
        displayEmpty
        multiple
        IconComponent={KeyboardArrowDownOutlinedIcon}
        MenuProps={MenuProps}
        id="multiple-checkbox"
        labelId="multiple-checkbox-label"
        renderValue={renderValue}
        sx={{
          // backgroundColor: selectedOptions.length > 0 ? '#00308F' : 'transparent',
          backgroundColor: 'transparent',
          // '.MuiSvgIcon-root ': {
          //   fill: selectedOptions.length > 0 ? 'white' : 'initial',
          // },
          '& .MuiSelect-select': {
            padding: '10px 5px',
          },
          ...sx,
        }}
        value={selectedOptions}
        variant="outlined"
        onChange={handleChange}
      >
        {/* <OPRInput
          error={false}
          errorName=""
          type="text"
          value={value}
          onChange={onChange}
        /> */}
        {listOfOptions?.map((option) => (
          <MenuItem
            key={option.id}
            sx={{
              fontSize: '13px',
              p: '5px 5px',
              wordWrap: 'break-word',
              overflowWrap: 'break-word',
              whiteSpace: 'normal', // Allow text to wrap to the next line
            }}
            value={option}
          >
            <Checkbox checked={selectedOptions?.indexOf(option) > -1} sx={{ fontSize: fullWidth ? '10px' : '13px', p: '0' }} />
            <ListItemText primary={option.roleName || option.roleCode} />
          </MenuItem>
        ))}
        {/* <MenuItem key="Clear filter">
          <ListItemText color="primary" primary="Clear filter" />
        </MenuItem> */}
      </Select>
    </FormControl>
  )
}

export default OPRMultiSelectCheckbox
