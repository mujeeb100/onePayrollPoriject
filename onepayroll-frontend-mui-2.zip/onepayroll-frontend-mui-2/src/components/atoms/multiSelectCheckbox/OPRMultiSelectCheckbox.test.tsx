import '@testing-library/jest-dom/extend-expect'

import { createTheme, ThemeProvider } from '@mui/material/styles'
import { fireEvent, render, screen } from '@testing-library/react'

import OPRMultiSelect from './OPRMultiSelectCheckbox'

// Mock data for the test
const mockOptions = [
  { name: 'Option 1', value: '1' },
  { name: 'Option 2', value: '2' },
  { name: 'Option 3', value: '3' },
]

type Option = {
  name: string;
  value: string;
};

type Props = {
  value?: string[];
  onChange?: (value: string[]) => void;
  disabled?: boolean;
  name?: string;
  isRequired?: boolean;
  placeholder?: string;
  label?: string;
  options: Option[];
  error?: string;
  optionalText?: string;
  isEditable?: boolean;
};

const theme = createTheme()

const setup = (props: Partial<Props> = {}) => {
  const defaultProps: Props = {
    value: [],
    onChange: jest.fn(),
    disabled: false,
    name: 'test-select',
    label: 'Test Label',
    isRequired: false,
    placeholder: 'Select options',
    options: mockOptions,
    error: '',
    optionalText: '',
    isEditable: true,
    ...props,
  }

  return render(
    <ThemeProvider theme={theme}>
      <OPRMultiSelect {...defaultProps} />
    </ThemeProvider>,
  )
}

describe('OPRMultiSelect', () => {
  test('renders without crashing', () => {
    setup()
    expect(screen.getByRole('combobox')).toBeInTheDocument()
  })

  test('displays the correct number of options', () => {
    setup()
    fireEvent.mouseDown(screen.getByRole('combobox'))
    const options = screen.getAllByRole('option')
    expect(options).toHaveLength(mockOptions.length)
  })

  test('displays selected options correctly', () => {
    const selectedOptions = ['1', '2']
    setup({ value: selectedOptions })
    // Open the dropdown to render the selected options
    fireEvent.mouseDown(screen.getByRole('combobox'))

    // Check if the selected options are displayed correctly
    expect(screen.getByText('Option 1')).toBeInTheDocument()
    expect(screen.getByText('Option 2')).toBeInTheDocument()
  })

  test('calls onChange when an option is selected', () => {
    const onChange = jest.fn()
    setup({ onChange })

    fireEvent.mouseDown(screen.getByRole('combobox'))
    const option = screen.getByText('Option 1')
    fireEvent.click(option)

    expect(onChange).toHaveBeenCalledWith(['1'])
  })

  test('calls onChange when an option is deselected', () => {
    const onChange = jest.fn()
    const selectedOptions = ['1']
    setup({ value: selectedOptions, onChange })

    fireEvent.mouseDown(screen.getByRole('combobox'))
    const option = screen.getByText('Option 1')
    fireEvent.click(option)

    expect(onChange).toHaveBeenCalledWith([])
  })

  test('displays error message correctly', () => {
    const errorMessage = 'This is an error'
    setup({ error: errorMessage, onChange: undefined })
    fireEvent.mouseDown(screen.getByRole('combobox'))
    const option = screen.getByText('Option 1')
    fireEvent.click(option)
    expect(screen.getByText(errorMessage)).toBeInTheDocument()
  })

  // Tests for optional props
  // disabled is not used
  // test('disables the select when disabled prop is true', () => {
  //   setup({ disabled: true })
  //   expect(screen.getByRole('combobox')).toBeDisabled()
  // })

  // isRequired is not used
  // test('renders required label when isRequired prop is true', () => {
  //   setup({ isRequired: true })
  //   expect(screen.getByText('*')).toBeInTheDocument()
  // })

  // isEditable is not used
  // test('renders correctly when isEditable is false', () => {
  //   setup({ isEditable: false })
  //   expect(screen.getByRole('combobox')).toBeDisabled()
  // })
})
