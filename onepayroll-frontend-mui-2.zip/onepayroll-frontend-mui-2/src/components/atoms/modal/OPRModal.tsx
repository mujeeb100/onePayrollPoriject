import {
  Box,
  Button, Dialog, DialogActions, DialogContent, DialogTitle, Divider, styled,
} from '@mui/material'
import { RighCaretBlue } from 'assets/svg-images/SvgComponents'
import OPRSearchIcon from 'components/molecules/OPRSearchIcon'
import { t } from 'i18next'
import React from 'react'

import OPRButton from '../button/OPRButton'
import OPRLabel from '../label/OPRLabel'

interface CustomDialogProps {
  className?: string; // Add className prop here
  onSelection?: (selectedCodes: string[]) => void;
  isBackButton?: boolean;
  isClose?: boolean;
  isOpen: boolean;
  isSearch?: boolean;
  isResume?: boolean;
  handleBack?: () => void;
  handleClose?: () => void;
  handleChange?: (value: any) => void;
  onSearch?: (value: any) => void;
  handleResume?: () => void;
  callBack?: (type:any) => void;
  closeTitle?: string;
  resumeTitle?: string;
  searchValue?: string;
  title?: string;
  subtitle?: string;
  children?: React.ReactNode;
  CustomStyles?: React.CSSProperties;
  type?: string;
  enableLeftButton?: boolean;
  leftButtonAction?: () => void;
}

const CustomStyledDialog = styled(Dialog)(
  ({ theme, CustomStyles }: any) => ({
    '& .MuiDialog-paper': {
      borderRadius: '10px',
      maxWidth: '40%',
    },

  }),
)

export const CustomDialog: React.FC<CustomDialogProps> = function ({
  className, // Receive className prop
  isBackButton = false,
  isClose = true,
  isOpen,
  isResume = false,
  isSearch = false,
  CustomStyles,
  handleBack,
  handleClose,
  handleResume,
  onSearch,
  searchValue,
  title = '',
  closeTitle = 'sign_out',
  resumeTitle = 'Resume',
  type,
  subtitle = '',
  children,
  callBack,
  onSelection,
  enableLeftButton = false,
  leftButtonAction,
}) {
  return (
    <CustomStyledDialog
      fullWidth
      aria-labelledby="alert-dialog-title"
      className={className}
      maxWidth="xs"
      open={isOpen}
      style={CustomStyles}
      onClose={handleClose}

    >
      <DialogTitle id="alert-dialog-title" sx={{ fontSize: '20px', fontWeight: 'bold' }}>{title}</DialogTitle>
      {subtitle.length > 0 && (
        <Box sx={{ margin: '0 24px' }}>
          <OPRLabel CustomStyles={{ marginBottom: '15px' }} data-testid="subtitle" variant="body2">{t(subtitle)}</OPRLabel>
          {isSearch && (
            <OPRSearchIcon
              placeholder="Search for existing users"
              value={searchValue}
              onChange={onSearch}
            />
          )}
          <Divider />
        </Box>
      )}
      <DialogContent sx={{ borderBottom: '1px solid #E8E6E7' }}>
        {children}
      </DialogContent>
      {type !== 'loader' && (
        <DialogActions sx={{ justifyContent: 'space-between', alignItems: 'center', mb: '10px' }}>
          {(isClose || enableLeftButton) && (
            <Button
              data-testid="close-button"
              sx={{ textTransform: 'none', color: '#0049DB', ml: '24px' }}
              variant="text"
              onClick={() => {
                if (enableLeftButton && leftButtonAction) {
                  leftButtonAction()
                } else if (handleClose) {
                  handleClose()
                }
              }}
            >
              {t(closeTitle)}
            </Button>
          )}

          {isBackButton && (
            <OPRButton
              data-testid="back-button"
              style={{ marginLeft: 'auto' }}
              variant="text"
              onClick={handleBack}
            >
              <RighCaretBlue />
              Back
            </OPRButton>
          )}
          { isResume && (
            <Button
              color="primary"
              data-testid="resume-button"
              sx={{
                textTransform: 'none', borderRadius: '110px', mr: '24px', marginLeft: isClose ? 'none' : 'auto',
              }}
              variant="contained"
              onClick={handleResume}
            >
              {t(resumeTitle)}
            </Button>
          )}
        </DialogActions>
      )}

    </CustomStyledDialog>
  )
}
