import '@testing-library/jest-dom/extend-expect'

import { fireEvent, render, screen } from '@testing-library/react'

import { CustomDialog } from './OPRModal'

describe('CustomDialog Component', () => {
  const defaultProps = {
    isOpen: true,
    handleClose: jest.fn(),
    handleBack: jest.fn(),
    handleResume: jest.fn(),
    onSearch: jest.fn(),
    searchValue: '',
    children: <div>Test Children</div>,
  }

  const renderComponent = (props = {}) => render(<CustomDialog {...defaultProps} {...props} />)

  it('should render the dialog with the default props', () => {
    renderComponent()
    expect(screen.getByRole('dialog')).toBeInTheDocument()
    expect(screen.getByRole('heading')).not.toHaveTextContent('title')
  })

  it('should render children inside the dialog content', () => {
    renderComponent()
    expect(screen.getByText('Test Children')).toBeInTheDocument()
  })

  it('should call handleClose when close button is clicked', () => {
    renderComponent({ isClose: true })
    const closeButton = screen.getByTestId('close-button')
    fireEvent.click(closeButton)
    expect(defaultProps.handleClose).toHaveBeenCalled()
  })

  it('should call handleBack when back button is clicked', () => {
    renderComponent({ isBackButton: true })
    const backButton = screen.getByText('Back')
    fireEvent.click(backButton)
    expect(defaultProps.handleBack).toHaveBeenCalled()
  })

  it('should call handleResume when resume button is clicked', () => {
    renderComponent({ isResume: true })
    const resumeButton = screen.getByTestId('resume-button')
    fireEvent.click(resumeButton)
    expect(defaultProps.handleResume).toHaveBeenCalled()
  })

  it('should call onSearch when search input changes', () => {
    renderComponent({ isSearch: true, subtitle: 'Test Subtitle' })
    const searchInput = screen.getByPlaceholderText('Search for existing users')
    fireEvent.change(searchInput, { target: { value: 'test' } })
    const searchButton = screen.getByTestId('search-icon')
    fireEvent.click(searchButton)
    expect(defaultProps.onSearch).toHaveBeenCalled()
  })

  it('should apply custom styles to the dialog', () => {
    const customStyles = { backgroundColor: 'red' }
    renderComponent({ CustomStyles: customStyles })
    const dialog = screen.getByRole('dialog')
    expect(dialog).toHaveStyle('background-color: rgb(255, 255, 255)')
  })

  it('should render subtitle if provided', () => {
    renderComponent({ subtitle: 'Test Subtitle' })
    expect(screen.getByTestId('subtitle')).toBeInTheDocument()
  })

  it('should render left button and call leftButtonAction when clicked', () => {
    const leftButtonAction = jest.fn()
    renderComponent({ enableLeftButton: true, leftButtonAction })
    const leftButton = screen.getByTestId('close-button')
    fireEvent.click(leftButton)
    expect(leftButtonAction).toHaveBeenCalled()
  })

  it('should not render close button if isClose is false', () => {
    renderComponent({ isClose: false })
    expect(screen.queryByText('close-button')).not.toBeInTheDocument()
  })

  it('should not render back button if isBackButton is false', () => {
    renderComponent({ isBackButton: false })
    expect(screen.queryByText('Back')).not.toBeInTheDocument()
  })

  it('should not render resume button if isResume is false', () => {
    renderComponent({ isResume: false })
    expect(screen.queryByText('resume-button')).not.toBeInTheDocument()
  })

  it('should handleclose if enableLeftButton is false onClick', () => {
    renderComponent({ isClose: true, enableLeftButton: false })
    const closeButton = screen.getByTestId('close-button')
    fireEvent.click(closeButton)
    expect(defaultProps.handleClose).toHaveBeenCalled()
  })

  it('should not do anything on click if enableLeftButton is false and handleClose is undefined', () => {
    const leftButtonAction = jest.fn()
    renderComponent({
      isClose: true, enableLeftButton: false, handleClose: undefined, leftButtonAction,
    })
    const closeButton = screen.getByTestId('close-button')
    fireEvent.click(closeButton)
    expect(defaultProps.handleClose).not.toHaveBeenCalled()
    expect(leftButtonAction).not.toHaveBeenCalled()
  })

  it('should apply the correct styles to the resume button if isClose is true', () => {
    renderComponent({ isResume: true, isClose: true })

    const resumeButton = screen.getByTestId('resume-button')
    expect(resumeButton).toHaveStyle({
      textTransform: 'none',
      borderRadius: '110px',
      marginRight: '24px',
      marginLeft: 'none',
    })
  })

  it('should apply the correct styles to the resume button if isClose is false', () => {
    renderComponent({ isResume: true, isClose: false })

    const resumeButton = screen.getByTestId('resume-button')
    expect(resumeButton).toHaveStyle({
      textTransform: 'none',
      borderRadius: '110px',
      marginRight: '24px',
      marginLeft: 'auto',
    })
  })
})
