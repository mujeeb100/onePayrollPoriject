// missing test for langauge, switch to regular user, switch to admin user, and sign out
// console error: menu component doesn't accept fragment as a child.
import '@testing-library/jest-dom/extend-expect'

import { fireEvent, render, screen } from '@testing-library/react'
import { Provider } from 'react-redux'

import { OPRTopBar } from './index'

// Mock the useAPI hook
jest.mock('../../../services/apiContext', () => ({
  useAPI: () => ({
    accessToken: 'mockAccessToken',
    userInfo: { name: 'Mock User', email: 'test@example.com' },
    handleLogin: jest.fn(),
    handleLogout: jest.fn(),
    isLoading: false,
    handleEntity: jest.fn(),
    entity: { id: 1, entityName: 'Mock Entity', entityCode: 'Mock Code' },
  }),
}))

const mock = {
  data: [{}],
  isLoading: false,
  isSuccess: true,
  isError: false,
  error: null,
  refetch: jest.fn(),
}
jest.mock('api/identityServices', () => ({
  useGetAllUserAdministrationQuery: () => mock,
  useGetAllUserRolePermissionChangeQuery: () => mock,
  useGetAllUserRoleEntityQuery: () => mock,
}))
// Mock react-redux
jest.mock('react-redux', () => ({
  ...jest.requireActual('react-redux'),
  useDispatch: jest.fn(),
  useSelector: jest.fn(),
}))

jest.mock('assets/svg-images/SvgComponents', () => ({
  GlobeIcon: () => <div data-testid="globe">GlobeIcon</div>,
  TricorUnifyLogo: () => <div data-testid="tricor">TricorUnifyLogo</div>,
  UserCaret: () => <div data-testid="usercaret">UserCaret</div>,
  UserIcon: () => <div data-testid="usericon">UserIcon</div>,
}))

describe('OPRTopBar', () => {
  const useDispatchMock = jest.fn()
  const useSelectorMock = jest.fn();
  (useDispatchMock as jest.Mock).mockReturnValue(useDispatchMock);
  (useSelectorMock as jest.Mock).mockImplementation((selector) => selector({
    someState: 'mockState',
  }))

  const handleDrawerToggle = jest.fn()
  const renderComponent = () => {
    const mockStore = {
      getState: () => ({
        // Provide the initial state for the mock store
        someState: 'mockState',
      }),
      subscribe: jest.fn(),
      dispatch: jest.fn(),
      replaceReducer: jest.fn(),
      [Symbol.observable]: jest.fn(() => ({
        subscribe: jest.fn(),
        [Symbol.observable]: jest.fn(),
      })),
    }

    return render(
      <Provider store={mockStore}>
        <OPRTopBar handleDrawerToggle={handleDrawerToggle} />
      </Provider>,
    )
  }
  beforeEach(() => {
    mock.data = [
      {
        id: 1,
        name: 'Leanne Graham',
        entityName: 'Bret',
        email: 'Sincere@april.biz',
        phone: '1-770-736-8031 x56442',
        entityCode: 'hildegard',
        isSystemAdmin: false,
      },
      {
        id: 2,
        name: 'Ervin Howell',
        entityName: 'Antonette',
        email: 'Shanna@melissa.tv',
        phone: '010-692-6593 x09125',
        entityCode: 'anastasia',
        isSystemAdmin: true,
      },
    ]
  })

  afterEach(() => {
    jest.clearAllMocks()
  })

  it('should render the component', () => {
    renderComponent()
    expect(screen.getByTestId('MenuIcon')).toBeInTheDocument()
    expect(screen.getByTestId('tricor')).toBeInTheDocument()
    expect(screen.getByTestId('globe')).toBeInTheDocument()
    expect(screen.getByTestId('usericon')).toBeInTheDocument()
    expect(screen.getByTestId('usercaret')).toBeInTheDocument()
    expect(screen.getByText('Switch to Entity')).toBeInTheDocument()
    expect(screen.getByText('Signed in as')).toBeInTheDocument()
    expect(screen.getByText('Sign out')).toBeInTheDocument()
    expect(screen.getByText('Mock Entity')).toBeInTheDocument()
  })

  it('should call handleDrawerToggle when MenuIcon is clicked', () => {
    renderComponent()
    fireEvent.click(screen.getByLabelText('open drawer'))
    expect(handleDrawerToggle).toHaveBeenCalled()
  })

  it('should open the entity modal when Switch to Entity button is clicked', () => {
    renderComponent()
    fireEvent.click(screen.getByText('Switch to Entity'))
    expect(screen.getByText('Bret')).toBeInTheDocument()
    expect(screen.getByText('Antonette')).toBeInTheDocument()
    fireEvent.click(screen.getByText('Bret'))
  })

  it('should open the language menu when GlobeIcon is clicked', () => {
    renderComponent()
    expect(document.getElementById('simple-menu')).not.toBeVisible()
    fireEvent.click(screen.getByTestId('globe'))
    expect(document.getElementById('simple-menu')).toBeVisible()
  })

  it('should open settings menu when UserIcon is clicked', () => {
    renderComponent()
    expect(document.getElementById('settings-menu')).not.toBeVisible()
    fireEvent.click(screen.getByTestId('usericon'))
    expect(document.getElementById('settings-menu')).toBeVisible()
  })
})
