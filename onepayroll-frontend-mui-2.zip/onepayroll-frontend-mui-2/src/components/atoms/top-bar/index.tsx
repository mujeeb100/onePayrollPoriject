import MenuIcon from '@mui/icons-material/Menu'
import {
  AppBar,
  Box,
  Button,
  Divider,
  Grid,
  IconButton,
  MenuItem,
  Toolbar,
  Tooltip,
  Typography,
  useTheme,
} from '@mui/material'
import { useGetAllUserAdministrationQuery, useGetAllUserRolePermissionChangeQuery } from 'api/identityServices'
import {
  GlobeIcon, TricorUnifyLogo, UserCaret, UserIcon,
} from 'assets/svg-images/SvgComponents'
import { defaultPageSize } from 'constants/index'
import * as React from 'react'
import { useState } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { selectLangSelector, setActiveLang } from 'slices/select-lang-slice'
import customTheme from 'themes'
import { selectLangItemType } from 'types/select-lang-slice-type'
import { generateFilterUrl, getSelectedEntity } from 'utils'

import { useAPI } from '../../../services/apiContext'
import { EntitySelectModal } from '../../organism/OPREntityModal'
import OPRMenu from '../menu/OPRMenu'

export function OPRTopBar({
  handleDrawerToggle,
}: {
  handleDrawerToggle: () => void
}) {
  const theme = useTheme()
  const context = useAPI()
  const dispatch = useDispatch()
  const languageList = useSelector(selectLangSelector) || []

  const [openEntityModal, setOpenEntityModal] = useState(false)
  const [skip, setSkip] = useState(true)

  const [anchorEl, setAnchorEl] = React.useState<null | HTMLElement>(null)
  const [settingAnchorEl, setSettingAnchorEl] = React.useState<null | HTMLElement>(null)
  const {
    data: allPosts,
    isLoading: isLoadingAllPosts,
    isSuccess: isSuccessAllPosts,
    isError: isErrorAllPosts,
    error: errorAllPosts,
    refetch: refetchAllPosts,
  } = useGetAllUserAdministrationQuery(generateFilterUrl({
    ...defaultPageSize,
    searchText: context?.userInfo?.email,
  }))
  const {
    data: allUserRolePermissionChange,
    isLoading: isLoadingAllUserRolePermissionChange,
    isSuccess: isSuccessAllUserRolePermissionChange,
    isError: isErrorAllUserRolePermissionChange,
    error: errorAllUserRolePermissionChange,
    refetch: refetchAllUserRolePermissionChange,
  } = useGetAllUserRolePermissionChangeQuery(generateFilterUrl({}), { skip: false })
  console.log(allUserRolePermissionChange, 'allUserRolePermissionChangeallUserRolePermissionChangeallUserRolePermissionChangeallUserRolePermissionChange')

  React.useEffect(() => {
    if (isSuccessAllUserRolePermissionChange) {
      // alert('go')
    }
  }, [isSuccessAllUserRolePermissionChange])

  // const {
  //   data: allUserRoles,
  //   error: createAllPostsBankAccountError,
  //   isLoading: isLoadingAllUserRoles,
  //   isSuccess: isSuccessAllPosts,
  //   isError: isErrorAllPosts,
  //   error: errorAllPosts,
  // } = useGetAllUserAdministrationQuery(generateFilterUrl({
  //   ...defaultPageSize,
  //   searchText: context?.userInfo?.email,
  // }))
  const handleSettingClick = (event: React.MouseEvent<HTMLElement>) => { setSettingAnchorEl(event.currentTarget) }
  const handleSettingClose = (event: React.MouseEvent<HTMLElement>) => { setSettingAnchorEl(null) }

  const handleClick = (event: React.MouseEvent<HTMLElement>) => {
    setAnchorEl(event.currentTarget)
  }

  const handleClose = (event: React.MouseEvent<HTMLElement>) => {
    setAnchorEl(null)
  }

  const selectLanguage = (event: React.MouseEvent<HTMLElement>) => {
    const selectedLocale = event.currentTarget.id
    dispatch(setActiveLang({ langLocale: selectedLocale }))
    setAnchorEl(null)
  }

  const handleSignOut = () => {
    setAnchorEl(null)
    context?.handleLogout()
  }

  const handleListItemClick = (e:any) => {
    setOpenEntityModal(false)
    context.handleEntity(e)
  }
  const entity:any = getSelectedEntity()?.entityCode !== 'SYSADMIN'
  console.log(entity, 'EEEEEEEEEEEE')

  return (
    <>
      <EntitySelectModal isOpen={openEntityModal} onClick={(e) => handleListItemClick(e)} />
      <Box sx={{ display: 'flex', alignItems: 'center' }}>
        <AppBar
          position="fixed"
          sx={{
            backgroundColor: theme.palette.background.paper,
            width: '100%',
            zIndex: (theme) => theme.zIndex.drawer + 1,
            boxShadow: 'none',
            borderBottom: `1px solid ${customTheme.palette.lightGray.main}`,

          }}
        >
          <Grid container>
            <Grid item lg={7} sm={5} xl={7} xs={12}>
              <Toolbar disableGutters>
                {/** Below button will be showed on mobile screens */}
                <IconButton
                  aria-label="open drawer"
                  color="inherit"
                  edge="start"
                  sx={{
                    display: { sm: 'none' }, // Hide on desktop, only visible on mobile
                    color: theme.palette.primary.main,
                    ml: 1,
                  }}
                  onClick={handleDrawerToggle}
                >
                  <MenuIcon />
                </IconButton>
                <Box
                  sx={{
                    px: theme.spacing(3),
                    py: theme.spacing(2),
                    borderRight: `1px solid ${customTheme.palette.lightGray.main} `,
                  }}
                >
                  <TricorUnifyLogo />
                </Box>
                <Typography
                  component="div"
                  sx={{
                    px: 3,
                    color: customTheme.palette.topAdmin.main,
                    letterSpacing: theme.spacing(0.25), // 2px
                    textTransform: 'uppercase',
                  }}
                  variant="body2"
                >
                  {context?.entity?.entityName || ''}
                </Typography>
              </Toolbar>
            </Grid>
            <Grid
              item
              lg={5}
              sm={7}
              sx={{ display: 'flex', justifyContent: 'flex-end', pr: 5 }}
              xl={5}
              xs={12}
            >
              <Toolbar disableGutters>
                <Box sx={{ mx: 2 }}>
                  {
                    entity && (
                      <Button
                        color="primary"
                        sx={{ borderRadius: 2, mx: 1, p: 1 }}
                        variant="outlined"
                        onClick={() => { setOpenEntityModal(true) }}
                      >
                        Switch to Entity
                      </Button>
                    )
                  }

                  <Tooltip title="Select Language">
                    <IconButton
                      color="primary"
                      sx={{ mx: 1 }}
                      onClick={handleClick}
                    >
                      {/* <GlobeLogo /> */}
                      <GlobeIcon />
                    </IconButton>
                  </Tooltip>
                  <OPRMenu
                    keepMounted
                    anchorEl={anchorEl}
                    id="simple-menu"
                    open={Boolean(anchorEl)}
                    onClose={handleClose}
                  >
                    {languageList
                    && languageList?.langListItems
                    && languageList?.langListItems?.map(
                      (lang: selectLangItemType) => (
                        <MenuItem
                          key={crypto.randomUUID()}
                          id={lang.locale}
                          selected={lang.active}
                          onClick={selectLanguage}
                        >
                          {lang.title}
                        </MenuItem>
                      ),
                    )}
                  </OPRMenu>
                  <Tooltip title="Open settings">
                    <IconButton
                      className="top-svg-img"
                      sx={{ mx: 1 }}
                      onClick={handleSettingClick}
                    >
                      {/* <Avatar
                      alt="user-avatar"
                      src="https://api.dicebear.com/7.x/avataaars/svg?size=24&randomizeIds=true&clothing=blazerAndShirt&backgroundColor=ffdfbf"
                      sx={{ width: 24, height: 24 }}
                      variant="square"
                    /> */}
                      <UserIcon />
                      <UserCaret />
                      {/* <ExpandMoreOutlined /> */}
                    </IconButton>
                  </Tooltip>
                  <OPRMenu
                    keepMounted
                    anchorEl={settingAnchorEl}
                    id="settings-menu"
                    open={Boolean(settingAnchorEl)}
                    onClose={handleSettingClose}
                  >
                    <MenuItem
                      sx={{
                        display: 'flex', flexDirection: 'column', alignItems: 'flex-start', gap: '8px',
                      }}
                      onClick={() => {}}
                    >
                      <Typography>Signed in as</Typography>
                      <Typography>{context?.userInfo?.email}</Typography>
                    </MenuItem>
                    {
                      !entity && (
                        <MenuItem
                          onClick={() => { setOpenEntityModal(true) }}
                        >
                          <Typography sx={{ fontWeight: 400 }} variant="body1">
                            Switch to Regular User
                          </Typography>

                        </MenuItem>
                      )
                    }

                    <Divider />
                    {
                      allUserRolePermissionChange?.isSystemAdmin === true && entity ? (
                        <>
                          <MenuItem
                            onClick={() => {
                              // setSkip(!skip)
                              const data = {
                                entityCode: 'SYSADMIN',
                                entityName: 'System Admin',
                                id: allUserRolePermissionChange?.systemAdminEntityId,
                              }
                              localStorage.setItem('Entity', JSON.stringify(data))
                              window.location.reload()
                              // setEntity(data)
                            }}
                          >
                            <Typography sx={{ fontWeight: 400 }} variant="body1">
                              Switch to System Admin
                            </Typography>

                          </MenuItem>

                          <Divider />
                        </>
                      ) : (
                        <>
                        </>
                      )
                    }

                    <MenuItem
                      onClick={handleSignOut}
                    >
                      <Typography sx={{ fontWeight: 400 }} variant="body1">
                        Sign out
                      </Typography>

                    </MenuItem>
                  </OPRMenu>
                </Box>
              </Toolbar>
            </Grid>
          </Grid>
        </AppBar>
      </Box>
    </>
  )
}
