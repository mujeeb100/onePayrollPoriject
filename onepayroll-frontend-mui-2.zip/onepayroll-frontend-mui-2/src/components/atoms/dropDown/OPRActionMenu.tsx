import MoreVertIcon from '@mui/icons-material/MoreVert'
import { Box, IconButton } from '@mui/material'
import Menu from '@mui/material/Menu'
import MenuItem from '@mui/material/MenuItem'
import * as React from 'react'
import styled from 'styled-components'

const StyledMenu = styled((props: any) => (
  <Menu
    anchorOrigin={{
      vertical: 'bottom',
      horizontal: 'right',
    }}
    elevation={0}
    transformOrigin={{
      vertical: 'top',
      horizontal: 'right',
    }}
    {...props}
  />
))(({ theme }) => ({
  '& .MuiPaper-root': {
    borderRadius: 6,
    // minWidth: 180,
    boxShadow:
      'rgb(255, 255, 255) 0px 0px 0px 0px, rgba(0, 0, 0, 0.05) 0px 0px 0px 1px, rgba(0, 0, 0, 0.1) 0px 10px 15px -3px, rgba(0, 0, 0, 0.05) 0px 4px 6px -2px',
    '& .MuiMenu-list': {
      padding: '4px 0',
    },
    '& .MuiMenuItem-root': {
      '& .MuiSvgIcon-root': {
        fontSize: 18,
      },

    },
  },
}))

export type OPRActionMenuOption = {
  title: string
  value: string|number|boolean
  divider?: boolean
  destructive?: boolean
  action?: (value: OPRActionMenuOption) => void
  info?: Record<string, any>
}

export type OPRActionMenuProps = {
  options: OPRActionMenuOption[]
  onClose: () => void
  menuStyle?: React.CSSProperties
  itemStyle?: React.CSSProperties
}

export default function OPRActionMenu({
  options, onClose, menuStyle = {}, itemStyle = {},
}: OPRActionMenuProps) {
  const [anchorEl, setAnchorEl] = React.useState<null | HTMLElement>(null)
  const open = Boolean(anchorEl)
  const handleClick = (event: React.MouseEvent<HTMLElement>) => {
    setAnchorEl(event.currentTarget)
  }
  const handleClose = (value: string|number|boolean) => {
    setAnchorEl(null)
    onClose?.()
  }
  return (
    <Box>
      <IconButton
        aria-controls={open ? 'long-menu' : undefined}
        aria-expanded={open ? 'true' : undefined}
        aria-haspopup="true"
        aria-label="more"
        id="long-button"
        onClick={handleClick}
      >
        <MoreVertIcon />
      </IconButton>
      <StyledMenu
        MenuListProps={{
          'aria-labelledby': 'long-button',
        }}
        PaperProps={{
          style: {
            ...{
              padding: '6px 8px 6px 8px',
              width: '258px',
            },
            ...menuStyle,
          },
        }}
        anchorEl={anchorEl}
        id="long-menu"
        open={open}
        onClose={handleClose}
      >
        {[...options].map((option) => (
          <MenuItem
            key={`${option.value}`}
            divider={option.divider}
            sx={{
              ...{
                fontWeight: 400, fontSize: '14px', height: '40px',
              },
              ...menuStyle,
              ...(option.destructive ? { color: '#DA3237' } : {}),
            }}
            onClick={() => {
              option.action?.(option)
              handleClose(option.value)
            }}
          >
            {option.title}
          </MenuItem>
        ))}
      </StyledMenu>
    </Box>
  )
}
