import '@testing-library/jest-dom/extend-expect'

import { fireEvent, render, screen } from '@testing-library/react'

import OPRDropDown from './OPRDropDown'

describe('OPRDropDown Component', () => {
  const newOptions = ['view', 'delete']
  const data = { id: 1, name: 'Test' }
  const onHandleclick = jest.fn()
  const title = 'Options'

  it('renders the component with a button when isMenubutton is true', () => {
    render(<OPRDropDown isMenubutton data={data} newOptions={newOptions} title={title} onHandleclick={onHandleclick} />)
    expect(screen.getByText(title)).toBeInTheDocument()
  })

  it('renders the component with an icon button when isMenubutton is false', () => {
    render(<OPRDropDown data={data} isMenubutton={false} newOptions={newOptions} onHandleclick={onHandleclick} />)
    expect(screen.getByLabelText('more')).toBeInTheDocument()
  })

  it('opens the menu when the button is clicked', () => {
    render(<OPRDropDown isMenubutton data={data} newOptions={newOptions} title={title} onHandleclick={onHandleclick} />)
    const button = screen.getByText(title)
    fireEvent.click(button)
    expect(screen.getByRole('menu')).toBeInTheDocument()
  })

  it('opens the menu when the icon button is clicked', () => {
    render(<OPRDropDown data={data} isMenubutton={false} newOptions={newOptions} onHandleclick={onHandleclick} />)
    const button = screen.getByLabelText('more')
    fireEvent.click(button)
    expect(screen.getByRole('menu')).toBeInTheDocument()
  })

  it('displays the correct number of menu items', () => {
    render(<OPRDropDown isMenubutton data={data} newOptions={newOptions} title={title} onHandleclick={onHandleclick} />)
    const button = screen.getByText(title)
    fireEvent.click(button)
    const menuItems = screen.getAllByRole('menuitem')
    expect(menuItems).toHaveLength(newOptions.length)
  })

  it('calls the onHandleclick function with the correct arguments when a menu item is clicked', () => {
    render(<OPRDropDown isMenubutton data={data} newOptions={newOptions} title={title} onHandleclick={onHandleclick} />)
    const button = screen.getByText(title)
    fireEvent.click(button)
    const menuItem = screen.getByText('View')
    fireEvent.click(menuItem)
    expect(onHandleclick).toHaveBeenCalledWith(data, 'view')
  })

  it('closes the menu when a menu item is clicked', () => {
    render(<OPRDropDown isMenubutton data={data} newOptions={newOptions} title={title} onHandleclick={onHandleclick} />)
    const button = screen.getByText(title)
    fireEvent.click(button)
    const menuItem = screen.getByText('View')
    fireEvent.click(menuItem)
    expect(screen.queryByRole('menu')).not.toBeInTheDocument()
  })

  it('renders the component without errors when no newOptions are provided', () => {
    render(<OPRDropDown isMenubutton data={data} title={title} onHandleclick={onHandleclick} />)
    expect(screen.getByText(title)).toBeInTheDocument()
  })

  it('renders the component without errors when newOptions is an empty array', () => {
    render(<OPRDropDown isMenubutton data={data} newOptions={[]} title={title} onHandleclick={onHandleclick} />)
    expect(screen.getByText(title)).toBeInTheDocument()
  })

  it('opens the menu but displays no menu items when newOptions is an empty array', () => {
    render(<OPRDropDown isMenubutton data={data} newOptions={[]} title={title} onHandleclick={onHandleclick} />)
    const button = screen.getByText(title)
    fireEvent.click(button)
    expect(screen.getByRole('menu')).toBeInTheDocument()
    const menuItems = screen.queryAllByRole('menuitem')
    expect(menuItems).toHaveLength(0)
  })

  it('opens the menu but displays no menu items when newOptions is not provided', () => {
    render(<OPRDropDown isMenubutton data={data} title={title} onHandleclick={onHandleclick} />)
    const button = screen.getByText(title)
    fireEvent.click(button)
    expect(screen.getByRole('menu')).toBeInTheDocument()
    const menuItems = screen.queryAllByRole('menuitem')
    expect(menuItems).toHaveLength(0)
  })

  it('updates anchorEl state when handleClick is called', () => {
    render(<OPRDropDown isMenubutton data={data} newOptions={newOptions} title={title} onHandleclick={onHandleclick} />)
    const button = screen.getByText(title)
    fireEvent.click(button)
    expect(screen.getByRole('menu')).toBeInTheDocument()
  })

  it('calls onHandleclick with the correct arguments when handleClose is called with a string', () => {
    render(<OPRDropDown isMenubutton data={data} newOptions={newOptions} title={title} onHandleclick={onHandleclick} />)
    const button = screen.getByText(title)
    fireEvent.click(button)
    const menuItem = screen.getByText('View')
    fireEvent.click(menuItem)
    expect(onHandleclick).toHaveBeenCalledWith(data, 'view')
  })

  it('closes the menu when handleClose is called with a string', () => {
    render(<OPRDropDown isMenubutton data={data} newOptions={newOptions} title={title} onHandleclick={onHandleclick} />)
    const button = screen.getByText(title)
    fireEvent.click(button)
    const menuItem = screen.getByText('View')
    fireEvent.click(menuItem)
    expect(screen.queryByRole('menu')).not.toBeInTheDocument()
  })

  it('closes the menu when handleClose is called without any argument', () => {
    render(<OPRDropDown isMenubutton data={data} title={title} onHandleclick={onHandleclick} />)
    const button = screen.getByText(title)
    fireEvent.click(button)
    expect(screen.getByRole('menu')).toBeInTheDocument()
    fireEvent.mouseDown(document.body)
    fireEvent.click(document.body)
  })
})
