import KeyboardArrowDownIcon from '@mui/icons-material/KeyboardArrowDown'
import MoreVertIcon from '@mui/icons-material/MoreVert'
import { Box, Button } from '@mui/material'
import IconButton from '@mui/material/IconButton'
import Menu from '@mui/material/Menu'
import MenuItem from '@mui/material/MenuItem'
import * as React from 'react'
import styled from 'styled-components'

const options = ['view', 'delete']

const ITEM_HEIGHT = 48

function splitCamelCaseToString(s: string) {
  return s.split(/(?=[A-Z])/).map((p) => p.charAt(0).toUpperCase() + p.slice(1)).join(' ')
}

const StyledMenu = styled((props: any) => (
  <Menu
    anchorOrigin={{
      vertical: 'bottom',
      horizontal: 'right',
    }}
    elevation={0}
    transformOrigin={{
      vertical: 'top',
      horizontal: 'right',
    }}
    {...props}
  />
))(({ theme }) => ({
  '& .MuiPaper-root': {
    borderRadius: 6,
    // minWidth: 180,
    boxShadow:
      'rgb(255, 255, 255) 0px 0px 0px 0px, rgba(0, 0, 0, 0.05) 0px 0px 0px 1px, rgba(0, 0, 0, 0.1) 0px 10px 15px -3px, rgba(0, 0, 0, 0.05) 0px 4px 6px -2px',
    '& .MuiMenu-list': {
      padding: '4px 0',
    },
    '& .MuiMenuItem-root': {
      '& .MuiSvgIcon-root': {
        fontSize: 18,
      },

    },
  },
}))

export default function OPRDropDown({
  newOptions = [], data, onHandleclick, isMenubutton, title, customeStyle = 'abc',
}: any) {
  const [anchorEl, setAnchorEl] = React.useState<null | HTMLElement>(null)
  const open = Boolean(anchorEl)
  const handleClick = (event: React.MouseEvent<HTMLElement>) => {
    setAnchorEl(event.currentTarget)
  }
  const handleClose = (option: any) => {
    if (typeof option === 'string') {
      onHandleclick(data, option)
    }
    // option.stopPropagation()
    // alert('fdhd')

    setAnchorEl(null)
  }
  return (
    <Box>
      {isMenubutton ? (
        <Button
          disableElevation
          aria-controls={open ? 'demo-customized-menu' : undefined}
          aria-expanded={open ? 'true' : undefined}
          aria-haspopup="true"
          endIcon={<KeyboardArrowDownIcon />}
          id="demo-customized-button"
          variant="outlined"
          onClick={handleClick}
        >
          {title}
        </Button>
      ) : (
        <IconButton
          aria-controls={open ? 'long-menu' : undefined}
          aria-expanded={open ? 'true' : undefined}
          aria-haspopup="true"
          aria-label="more"
          id="long-button"
          onClick={handleClick}
        >
          <MoreVertIcon />
        </IconButton>
      )}

      <StyledMenu
        MenuListProps={{
          'aria-labelledby': 'long-button',
        }}
        PaperProps={{
          style: {
            maxHeight: ITEM_HEIGHT * 4.5,
            // width: '20ch',
          },
        }}
        anchorEl={anchorEl}
        id="long-menu"
        open={open}
        onClose={handleClose}
      >
        {[...newOptions].map((option: any) => (
          <MenuItem
            key={option}
            selected={option === 'Pyxis'}
            onClick={() => handleClose(option)}
          >
            {splitCamelCaseToString(option)}
          </MenuItem>
        ))}
      </StyledMenu>
    </Box>
  )
}
