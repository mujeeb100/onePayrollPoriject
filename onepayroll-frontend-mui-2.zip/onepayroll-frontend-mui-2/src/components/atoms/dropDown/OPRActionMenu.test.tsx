import '@testing-library/jest-dom/extend-expect'

import { fireEvent, render, screen } from '@testing-library/react'

import OPRActionMenu, { OPRActionMenuOption } from './OPRActionMenu'

describe('OPRActionMenu Component', () => {
  const options: OPRActionMenuOption[] = [
    { title: 'Option 1', value: '1' },
    { title: 'Option 2', value: '2', divider: true },
    { title: 'Option 3', value: '3', destructive: true },
  ]

  const onClose = jest.fn()

  it('renders the component', () => {
    render(<OPRActionMenu options={options} onClose={onClose} />)
    expect(screen.getByLabelText('more')).toBeInTheDocument()
  })

  it('opens the menu when the icon button is clicked', () => {
    render(<OPRActionMenu options={options} onClose={onClose} />)
    const button = screen.getByLabelText('more')
    fireEvent.click(button)
    expect(screen.getByRole('menu')).toBeInTheDocument()
  })

  it('displays the correct number of menu items', () => {
    render(<OPRActionMenu options={options} onClose={onClose} />)
    const button = screen.getByLabelText('more')
    fireEvent.click(button)
    const menuItems = screen.getAllByRole('menuitem')
    expect(menuItems).toHaveLength(options.length)
  })

  it('calls the onClose function when a menu item is clicked', () => {
    render(<OPRActionMenu options={options} onClose={onClose} />)
    const button = screen.getByLabelText('more')
    fireEvent.click(button)
    const menuItem = screen.getByText('Option 1')
    fireEvent.click(menuItem)
    expect(onClose).toHaveBeenCalled()
  })

  it('calls the action function of the menu item when clicked', () => {
    const action = jest.fn()
    const optionsWithAction: OPRActionMenuOption[] = [
      { title: 'Option 1', value: '1', action },
    ]
    render(<OPRActionMenu options={optionsWithAction} onClose={onClose} />)
    const button = screen.getByLabelText('more')
    fireEvent.click(button)
    const menuItem = screen.getByText('Option 1')
    fireEvent.click(menuItem)
    expect(action).toHaveBeenCalledWith(optionsWithAction[0])
  })

  it('applies the destructive style to the destructive menu item', () => {
    render(<OPRActionMenu options={options} onClose={onClose} />)
    const button = screen.getByLabelText('more')
    fireEvent.click(button)
    const destructiveItem = screen.getByText('Option 3')
    expect(destructiveItem).toHaveStyle('color: #DA3237')
  })
})
