import '@testing-library/jest-dom/extend-expect'

import { createTheme, ThemeProvider } from '@mui/material/styles'
import { fireEvent, render, screen } from '@testing-library/react'

import OPRRadioGroup from './index'

describe('OPRRadioGroup Component', () => {
  const theme = createTheme()

  const renderWithTheme = (ui: any) => render(<ThemeProvider theme={theme}>{ui}</ThemeProvider>)

  const options = ['Edit user account', 'Assign entity', 'Remove entity']

  it('calls handleChange when an option is selected', () => {
    const handleChange = jest.fn()
    renderWithTheme(<OPRRadioGroup handleChange={handleChange} options={options} />)
    const optionElement = screen.getByDisplayValue(options[0])
    fireEvent.click(optionElement)
    expect(handleChange).toHaveBeenCalled()
  })

  it('applies custom styles to the RadioGroup', () => {
    const customStyles = { backgroundColor: 'lightblue' }
    renderWithTheme(<OPRRadioGroup options={options} style={customStyles} />)
    const radioGroupElement = screen.getByRole('radiogroup')
    expect(radioGroupElement).toHaveStyle('background-color: lightblue')
  })

  it('updates the selected value when an option is clicked', () => {
    renderWithTheme(<OPRRadioGroup options={options} />)
    const optionElement = screen.getByDisplayValue(options[0])
    fireEvent.click(optionElement)
    expect(optionElement).toBeChecked()
  })
})
