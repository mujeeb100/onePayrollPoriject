import {
  FormControlLabel, Radio, RadioGroup, styled,
} from '@mui/material'
import { t } from 'i18next'
import * as React from 'react'

// const options = ['Edit user account', 'Assign entity', 'Remove entity']

type CustomProps = {
    style?: React.CSSProperties;
    options: string[];
    handleChange?: (e:any) => void;
    [x:string]: any;
};

export const OPRRadioGroupStyle = styled(RadioGroup)<CustomProps>(({ theme, style }: any) => ({
  ...({
    ...style,
    textTransform: 'none',
    borderRadius: '110px',
    padding: '8px 16px',
  }),
  // customstyle will override the above styles and theme styles for the component
}))

function OPRRadioGroup({
  options, handleChange, style, ...rest
}:CustomProps) {
  const [value, setValue] = React.useState('')

  const handleSelectChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    setValue((event.target as HTMLInputElement).value)
    if (handleChange) {
      handleChange(event)
    }
  }

  return (
    <OPRRadioGroupStyle
      // ref={radioGroupRef}
      aria-label="RadioGroup"
      name="RadioGroup"
      options={options}
      style={style}
      value={value}
      onChange={handleSelectChange}
    >
      {options.map((option) => (
        <FormControlLabel
          key={option}
          control={<Radio />}
          label={t(option)}
          value={option}
        />
      ))}
    </OPRRadioGroupStyle>
  )
}
export default OPRRadioGroup
