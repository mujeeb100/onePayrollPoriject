import '@testing-library/jest-dom/extend-expect'

import { MenuItem } from '@mui/material'
import { createTheme, ThemeProvider } from '@mui/material/styles'
import { render, screen } from '@testing-library/react'

import OPRMenu from './OPRMenu'

describe('OPRMenu Component', () => {
  const theme = createTheme()

  const renderWithTheme = (ui: any) => render(<ThemeProvider theme={theme}>{ui}</ThemeProvider>)

  it('renders the Menu component with the correct items', () => {
    const anchorEl = document.createElement('div')
    document.body.appendChild(anchorEl)

    renderWithTheme(
      <OPRMenu open anchorEl={anchorEl} onClose={() => {}}>
        <MenuItem>Item 1</MenuItem>
        <MenuItem>Item 2</MenuItem>
      </OPRMenu>,
    )

    const item1 = screen.getByText('Item 1')
    const item2 = screen.getByText('Item 2')

    expect(item1).toBeInTheDocument()
    expect(item2).toBeInTheDocument()
  })
})
