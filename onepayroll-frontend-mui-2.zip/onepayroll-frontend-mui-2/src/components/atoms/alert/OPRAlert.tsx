import Alert from '@mui/material/Alert'
import Button from '@mui/material/Button'
import Snackbar, { SnackbarOrigin } from '@mui/material/Snackbar'
import * as React from 'react'

import { DEFAULT_AUTO_HIDE_DURATION, DEFAULT_HORIZONTAL, DEFAULT_VERTICAL } from '../../../constants/index'

type CustomizedSnackbarProps = {
  vertical?: 'top' | 'bottom';
  horizontal?: 'right' | 'left' | 'center'; // Update the type to include 'center'
  title: string;
  severity?: any;
  autoHideDuration?: number;
};

export default function OPRAlert({
  vertical = DEFAULT_VERTICAL,
  horizontal = DEFAULT_HORIZONTAL,
  title = '',
  severity = 'success', // default for success
  autoHideDuration = DEFAULT_AUTO_HIDE_DURATION,
}: CustomizedSnackbarProps) {
  const [open, setOpen] = React.useState({
    vertical: DEFAULT_VERTICAL,
    horizontal: DEFAULT_HORIZONTAL,
    open: false,
  })

  const handleClick = (newState: SnackbarOrigin) => () => {
    setOpen({ ...newState, open: true })
  }

  const handleClose = (
    event?: React.SyntheticEvent | Event,
    reason?: string,
  ) => {
    if (reason === 'clickaway') {
      return
    }

    setOpen({ ...open, open: false })
  }

  return (
    <>
      <Button onClick={handleClick({ vertical, horizontal })}>
        Open Success Alert
      </Button>
      <Snackbar
        anchorOrigin={{ vertical, horizontal }}
        autoHideDuration={autoHideDuration}
        open={open.open}
        onClose={handleClose}
      >
        <Alert
          severity={severity}
          // sx={{ background: 'green', color: 'white', width: '100%' }}
          variant="filled"
          onClose={handleClose}
        >
          {title}
        </Alert>
      </Snackbar>
    </>
  )
}
