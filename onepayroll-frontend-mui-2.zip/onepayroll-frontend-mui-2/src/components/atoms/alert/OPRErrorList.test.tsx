import '@testing-library/jest-dom/extend-expect'

import { fireEvent, render, screen } from '@testing-library/react'
import crypto from 'crypto'

import OPRErrorList from './OPRErrorList'

Object.defineProperty(global, 'crypto', {
  value: {
    randomUUID: () => crypto.randomUUID(),
  },
})

describe('OPRErrorList', () => {
  test('renders without crashing', () => {
    render(<OPRErrorList />)
    expect(screen.getByRole('alert')).toBeInTheDocument()
  })

  test('displays the correct severity', () => {
    render(<OPRErrorList severity="error" />)
    expect(screen.getByRole('alert')).toHaveClass('MuiAlert-filledError')
  })

  test('displays the correct messages', () => {
    const messages = ['Error 1', 'Error 2']
    render(<OPRErrorList messages={messages} />)
    messages.forEach((message, index) => {
      const regex = new RegExp(`${index + 1}\\s*\\.\\s*${message}`)
      expect(screen.getByText(regex)).toBeInTheDocument()
    })
  })

  test('closes the alert when the close button is clicked', () => {
    render(<OPRErrorList messages={['Error 1']} />)
    const closeButton = screen.getByRole('button', { name: /close/i })
    fireEvent.click(closeButton)
    expect(screen.queryByRole('alert')).not.toBeInTheDocument()
  })

  test('displays default severity when severity prop is not provided', () => {
    render(<OPRErrorList />)
    expect(screen.getByRole('alert')).toHaveClass('MuiAlert-filledInfo')
  })

  test('displays no messages when messages prop is not provided', () => {
    render(<OPRErrorList />)
    expect(screen.queryByText(/1\./)).not.toBeInTheDocument()
  })

  test('handleClose function sets alertOpen to false', () => {
    render(<OPRErrorList messages={['Error 1']} />)
    const closeButton = screen.getByRole('button', { name: /close/i })
    fireEvent.click(closeButton)
    expect(screen.queryByRole('alert')).not.toBeInTheDocument()
  })
})
