import '@testing-library/jest-dom/extend-expect'

import { createTheme, ThemeProvider } from '@mui/material/styles'
import { fireEvent, render, screen } from '@testing-library/react'

import OPRDialog from './OPRDialog'

const theme = createTheme()

interface CustomDialogProps {
    open: boolean;
    handleClose: () => void;
    title?: string;
    content?: string;
    cancelText?: string;
    submitText?: string;
    onSubmit: () => void;
    message: string;
    cancelButtonStyle?: React.CSSProperties;
    deleteButtonStyle?: React.CSSProperties;
    deleteCallBack: () => void;
    setDialogOpen: React.Dispatch<React.SetStateAction<boolean>>;
    // openDialogButton?: string;
  }

const setup = (props: Partial<CustomDialogProps> = {}) => {
  const defaultProps: CustomDialogProps = {
    open: true,
    handleClose: jest.fn(),
    onSubmit: jest.fn(),
    message: 'Are You Sure you want to submit the test? You will not be able to edit after submitting.',
    deleteCallBack: jest.fn(),
    setDialogOpen: jest.fn(),
    ...props,
  }

  return render(
    <ThemeProvider theme={theme}>
      <OPRDialog {...defaultProps} />
    </ThemeProvider>,
  )
}

describe('OPRDialog', () => {
  test('renders without crashing', () => {
    setup({ message: undefined })
    expect(screen.getByRole('dialog')).toBeInTheDocument()
  })

  test('displays the correct title', () => {
    setup()
    expect(screen.getByText('Submit the test?')).toBeInTheDocument()
  })

  test('applies default styles to the cancel button', () => {
    setup()
    expect(screen.getByText('Cancel')).toHaveStyle('color: #0049DB')
  })

  test('applies default styles to the delete button', () => {
    setup()
    expect(screen.getByText('Yes, delete it!')).toHaveStyle('background-color: white')
    expect(screen.getByText('Yes, delete it!')).toHaveStyle('border-radius: 110px')
    expect(screen.getByText('Yes, delete it!')).toHaveStyle('border: 1px solid red')
    expect(screen.getByText('Yes, delete it!')).toHaveStyle('color: red')
  })

  test('calls handleClose when the cancel button is clicked', () => {
    const handleClose = jest.fn()
    setup({ handleClose })

    fireEvent.click(screen.getByText('Cancel'))
    expect(handleClose).toHaveBeenCalled()
  })

  test('calls deleteCallBack when the delete button is clicked', () => {
    const deleteCallBack = jest.fn()
    setup({ deleteCallBack })

    fireEvent.click(screen.getByText('Yes, delete it!'))
    expect(deleteCallBack).toHaveBeenCalled()
  })

  test('applies custom styles to the cancel button', () => {
    const customCancelButtonStyle = { color: 'blue' }
    setup({ cancelButtonStyle: customCancelButtonStyle })

    expect(screen.getByText('Cancel')).toHaveStyle('color: blue')
  })

  test('applies custom styles to the delete button', () => {
    const customDeleteButtonStyle = { backgroundColor: 'black', color: 'white' }
    setup({ deleteButtonStyle: customDeleteButtonStyle })

    expect(screen.getByText('Yes, delete it!')).toHaveStyle('background-color: black')
    expect(screen.getByText('Yes, delete it!')).toHaveStyle('color: white')
  })
})
