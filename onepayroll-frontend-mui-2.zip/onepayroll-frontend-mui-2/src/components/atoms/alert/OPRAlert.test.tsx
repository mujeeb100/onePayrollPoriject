import '@testing-library/jest-dom/extend-expect'

import { fireEvent, render, screen } from '@testing-library/react'

import OPRAlert from './OPRAlert'

describe('OPRAlert Component', () => {
  const defaultProps = {
    title: 'Test Alert',
    severity: 'success',
  }

  it('renders the button with the correct text', () => {
    render(<OPRAlert {...defaultProps} />)
    const buttonElement = screen.getByText('Open Success Alert')
    expect(buttonElement).toBeInTheDocument()
  })

  it('does not close the Snackbar when the reason is "clickaway"', () => {
    render(<OPRAlert {...defaultProps} />)
    const buttonElement = screen.getByText('Open Success Alert')
    fireEvent.click(buttonElement)
    const alertElement = screen.getByText(defaultProps.title)
    expect(alertElement).toBeInTheDocument()
    fireEvent.click(document.body) // Simulate a clickaway event
    fireEvent.click(document.body, { reason: 'clickaway' }) // Simulate a clickaway event with reason

    expect(alertElement).toBeInTheDocument() // Snackbar should still be open
  })

  it('closes the Snackbar when the close button is clicked', () => {
    render(<OPRAlert {...defaultProps} />)
    const buttonElement = screen.getByText('Open Success Alert')
    fireEvent.click(buttonElement)
    const alertElement = screen.getByText(defaultProps.title)
    expect(alertElement).toBeInTheDocument()
    const closeButton = screen.getByTitle('Close') // Identify the close button by its title
    fireEvent.click(closeButton)
  })
})
