import Alert from '@mui/material/Alert'
import { Stack } from '@mui/system'
import React, { useState } from 'react'

interface CustomAlertProps {
  severity?: 'success' | 'info' | 'warning' | 'error';
  messages?:any[];
}

function OPRErrorList({ severity = 'info', messages }: CustomAlertProps) {
  const [alertOpen, setAlertOpen] = useState(true)

  const handleClose = () => {
    setAlertOpen(false)
    // Additional logic if needed
  }

  return (

    <Stack spacing={2} sx={{ width: '100%' }}>
      {alertOpen && (
        <Alert severity={severity} variant="filled" onClose={handleClose}>
          {messages?.map((message: any, index: number) => (
            <p key={crypto.randomUUID()}>
              {index + 1}
              .
              {message}
            </p>
          ))}
        </Alert>
      )}
    </Stack>
  )
}

export default OPRErrorList
