import {
  Button,
  Dialog,
  DialogActions,
  DialogContent,
  DialogContentText,
  DialogTitle,
} from '@mui/material'
import React from 'react'

interface CustomDialogProps {
  open: boolean;
  handleClose: () => void;
  title?: string;
  content?: string;
  cancelText?: string;
  submitText?: string;
  onSubmit: () => void;
  message: string;
  cancelButtonStyle?: React.CSSProperties;
  deleteButtonStyle?: React.CSSProperties;
  deleteCallBack: () => void;
  setDialogOpen: React.Dispatch<React.SetStateAction<boolean>>;
  // openDialogButton?: string;
}

function OPRDialog({
  open,
  handleClose,
  onSubmit,
  message = 'Are You Sure you want to submit the test? You will not be able to edit after submitting.', // Set a default message
  cancelButtonStyle = { color: '#0049DB' },
  deleteButtonStyle = {
    backgroundColor: 'white',
    borderRadius: '110px',
    border: '1px solid red',
    color: 'red',
  },
  deleteCallBack,
  setDialogOpen,
  // openDialogButton,
}: CustomDialogProps) {
  // const [dialogOpen, setDialogOpen] = useState(open)

  // const handleOpen = () => {
  //   setDialogOpen(true)
  // }

  // const handleDelete = () => {
  //   // Check if deleteCallBack is defined before invoking it
  //   if (deleteCallBack) {
  //     deleteCallBack()
  //       .then(() => {
  //         setDialogOpen(false)
  //       })
  //       .catch((error) => {
  //         console.error('Error during delete:', error)
  //       })
  //   } else {
  //     setDialogOpen(false)
  //   }
  // }

  return (
    <>
      {/* {openDialogButton && <Button onClick={handleOpen}>{openDialogButton}</Button>} */}

      <Dialog
        aria-describedby="dialog-description"
        aria-label="dialog-title"
        open={open}
        onClose={handleClose}
      >
        <DialogTitle id="dialog-title">Submit the test?</DialogTitle>
        <DialogContent>
          <DialogContentText id="dialog-description">
            {`Want to delete this ${message}?`}
            You won’t be able to revert this.
          </DialogContentText>
        </DialogContent>
        <DialogActions>
          <Button sx={cancelButtonStyle} onClick={handleClose}>
            Cancel
          </Button>
          <Button autoFocus sx={deleteButtonStyle} onClick={deleteCallBack}>
            Yes, delete it!
          </Button>
        </DialogActions>
      </Dialog>
    </>
  )
}

export default OPRDialog
