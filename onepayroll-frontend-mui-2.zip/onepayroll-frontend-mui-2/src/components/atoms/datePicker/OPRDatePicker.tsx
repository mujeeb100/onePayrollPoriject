import './index.css'

import { useTheme } from '@emotion/react'
import {
  Box, TextField,
} from '@mui/material'
import { DatePicker, LocalizationProvider } from '@mui/x-date-pickers'
import { AdapterMoment } from '@mui/x-date-pickers/AdapterMoment'
import styled from 'styled-components'

  type CustomProps = {
    value?: any;
    label?: string;
    onChange?: (item: any) => void;
    disabled?: boolean;
    name?: string;
    isRequired?: boolean;
    max?: number;
    placeholder?: string;
    type?: string;
    formateDate?: string;
    maxLength?: number;
    error?: boolean;
    errorName?:string;
    color?:any;
    CustomStyles?: React.CSSProperties;
  };

function OPRDatePicker({
  value,
  label,
  onChange = () => {},
  disabled,
  name,
  isRequired = false,
  placeholder = '',
  type = 'text',
  formateDate = 'MM/DD/YYYY',
  maxLength,
  error = false,
  errorName = '',
  color,
  CustomStyles,
  ...rest
}: CustomProps) {
  const theme:any = useTheme() // Use the Theme type for the theme variable
  const StyledDatePicker:any = styled(DatePicker)<CustomProps>(({ theme, style }: any) => ({
    ...style,
    '& .dt-pkr input': {
      padding: '8px',
      background: 'blue',
    },
    '& .dt-pkr .css-5ifve1-MuiInputBase-root-MuiOutlinedInput-root': {
      padding: '8px',
      background: 'blue',
    },
    ...CustomStyles,
  }))

  return (
    <LocalizationProvider dateAdapter={AdapterMoment}>
      <Box sx={{
        // width: '100%',
        // height: '40px',
        // border: error ? '1px solid red' : '',
        // borderRadius: '8px',
      }}
      >
        <StyledDatePicker
          className="dt-pkr"
          disabled={disabled}
          inputFormat={formateDate}
          label={label}
          renderInput={(params:any) => (
            <TextField
              {...params}
              InputProps={{
                ...params.InputProps,
                style: {
                  border: '1px solid #ccc',
                  borderRadius: '4px',
                },
              }}
              sx={{ width: '100%' }}
            />
          )}
          value={value}
          onChange={onChange}
        />
      </Box>
    </LocalizationProvider>
  )
}

export default OPRDatePicker
