import '@testing-library/jest-dom/extend-expect'

import { createTheme, ThemeProvider } from '@mui/material/styles'
import { LocalizationProvider } from '@mui/x-date-pickers'
import { AdapterMoment } from '@mui/x-date-pickers/AdapterMoment'
import { fireEvent, render, screen } from '@testing-library/react'

import OPRDatePicker from './OPRDatePicker'

describe('OPRDatePicker Component', () => {
  const theme = createTheme()
  const onChange = jest.fn()
  const label = 'Select Date'
  const value = null

  it('renders the component', () => {
    render(
      <ThemeProvider theme={theme}>
        <LocalizationProvider dateAdapter={AdapterMoment}>
          <OPRDatePicker label={label} value={value} onChange={onChange} />
        </LocalizationProvider>
      </ThemeProvider>,
    )
    expect(screen.getByLabelText(label)).toBeInTheDocument()
  })

  it('calls the onChange function when a date is selected', () => {
    render(
      <ThemeProvider theme={theme}>
        <LocalizationProvider dateAdapter={AdapterMoment}>
          <OPRDatePicker label={label} value={value} onChange={onChange} />
        </LocalizationProvider>
      </ThemeProvider>,
    )
    const input = screen.getByLabelText(label)
    fireEvent.change(input, { target: { value: '01/01/2022' } })
    expect(onChange).toHaveBeenCalled()
  })

  it('applies custom styles', () => {
    const customStyles = { width: '100%' }
    render(
      <ThemeProvider theme={theme}>
        <LocalizationProvider dateAdapter={AdapterMoment}>
          <OPRDatePicker CustomStyles={customStyles} label={label} value={value} onChange={onChange} />
        </LocalizationProvider>
      </ThemeProvider>,
    )
    const input = screen.getByLabelText(label)
    const computedStyle = window.getComputedStyle(input)
    expect(computedStyle.width).toBe('100%')
  })

  it('disables the date picker when disabled prop is true', () => {
    render(
      <ThemeProvider theme={theme}>
        <LocalizationProvider dateAdapter={AdapterMoment}>
          <OPRDatePicker disabled label={label} value={value} onChange={onChange} />
        </LocalizationProvider>
      </ThemeProvider>,
    )
    const input = screen.getByLabelText(label)
    expect(input).toBeDisabled()
  })

  it('renders with the correct date format', () => {
    const formateDate = 'DD/MM/YYYY'
    render(
      <ThemeProvider theme={theme}>
        <LocalizationProvider dateAdapter={AdapterMoment}>
          <OPRDatePicker formateDate={formateDate} label={label} value={value} onChange={onChange} />
        </LocalizationProvider>
      </ThemeProvider>,
    )
    const input = screen.getByLabelText(label)
    fireEvent.change(input, { target: { value: '01/01/2022' } })
    expect(input).toHaveValue('01/01/2022')
  })

  it('works correctly when no onChange function is provided', () => {
    render(
      <ThemeProvider theme={theme}>
        <LocalizationProvider dateAdapter={AdapterMoment}>
          <OPRDatePicker label={label} value={value} />
        </LocalizationProvider>
      </ThemeProvider>,
    )
    const input = screen.getByLabelText(label)
    fireEvent.change(input, { target: { value: '01/01/2022' } })
    // No assertion needed, just ensure no errors are thrown
  })
})
