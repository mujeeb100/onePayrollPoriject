import '@testing-library/jest-dom/extend-expect'

import { fireEvent, render, screen } from '@testing-library/react'
import { displayFormatDateTime } from 'constants/index'
import { t } from 'i18next'
import { customDateFormate } from 'utils'

import OPRTable from './OPRTable'
import * as tableOptions from './OPRTableConstant'

jest.mock('react-i18next', () => ({
  useTranslation: () => ({
    t: (key: any) => key,
  }),
}))

jest.mock('i18next', () => ({
  t: jest.fn((key) => key),
}))

jest.mock('../button/OPRButton', () => function OPRButtonMock({ onClick }: any) {
  return (
    <button data-testid="button" type="button" onClick={onClick}>
      Button
    </button>
  )
})

jest.mock('../checkbox/OPRCheckbox', () => function OPRCheckboxMock() {
  return (
    <div data-testid="checkbox">Checkbox</div>
  )
})

jest.mock('../chip/OPRStatusChip', () => function OPRStatusChipMock({ status }: any) {
  return (
    <div data-testid="status-chip">{status}</div>
  )
})

jest.mock('../label/OPRLabel', () => function OPRLabelMock({ label, children, ...props }: any) {
  return (
    <div data-testid="label" style={props.CustomStyles}>{label || children}</div>
  )
})

const mockHandleEdit = jest.fn()
const mockHandleClick = jest.fn()

const renderTable = ({ tableConfig, mockData }: any) => render(
  <OPRTable cols={tableConfig} data={mockData} onRequestSort={jest.fn()} />,
)

beforeEach(() => {
  (t as unknown as jest.Mock).mockImplementation((key) => key)
})

afterEach(() => {
  jest.clearAllMocks()
})

describe('employeeBankAccountColumn', () => {
  const mockArrayList = [
    {
      companyBankAccountCode: 'CA001',
      companyBankAccountDescription: 'Company Account 1',
    },
    {
      companyBankAccountCode: 'CA002',
      companyBankAccountDescription: 'Company Account 2',
    },
  ]

  const tableConfig = tableOptions.employeeBankAccountColumn(mockHandleEdit, mockArrayList)

  const mockData = [
    {
      accountName: 'John Doe',
      accountNumber: '12345678',
      branchCode: 'ABC123 (123)',
      companyBankAccountCode: 'CA001',
      effectiveDate: '2022-01-01',
      id: 0,
      companyBankAccountDescription: 'Company Account 1',
    },
    {
      accountName: 'Jane Smith',
      accountNumber: '87654321',
      branchCode: 'DEF456 (456)',
      companyBankAccountCode: 'CA002',
      effectiveDate: '2021-06-15',
      id: 1,
      companyBankAccountDescription: 'Company Account 2',
    },
    {
      accountName: 'Bobby Tommy',
      accountNumber: '1284312683',
      branchCode: 'ABC143 (134)',
      companyBankAccountCode: 'CA003',
      effectiveDate: '2020-01-01',
      id: 2,
      companyBankAccountDescription: 'Company Account 3',
    },
  ]

  test('renders correct table', () => {
    renderTable({ tableConfig, mockData })

    expect(screen.getByText('Beneficiary name | Account number')).toBeInTheDocument()
    expect(screen.getByText('Bank name | Bank code (Branch code)')).toBeInTheDocument()
    expect(screen.getByText('Company bank account')).toBeInTheDocument()
    expect(screen.getByText('Effective date')).toBeInTheDocument()
    expect(screen.getByText('action')).toBeInTheDocument()

    mockData.forEach((data) => {
      expect(screen.queryAllByText(data.accountName)).toHaveLength(2)
      expect(screen.getByText(data.accountNumber)).toBeInTheDocument()
      expect(screen.getByText(data.branchCode)).toBeInTheDocument()
      expect(screen.getByText(customDateFormate(data.effectiveDate))).toBeInTheDocument()
    })

    expect(screen.getByText('Company Account 1(CA001)')).toBeInTheDocument()
    expect(screen.getByText('Company Account 2(CA002)')).toBeInTheDocument()
    expect(screen.getByText('null(CA003)')).toBeInTheDocument()

    const dropdownButtons = screen.getAllByLabelText('more')
    fireEvent.click(dropdownButtons[0])
    expect(screen.getByText('Edit Employee Bank')).toBeInTheDocument()
  })
})

describe('standardReportColumn', () => {
  const tableConfig = tableOptions.standardReportColumn(mockHandleEdit)

  const mockData = [
    {
      jobs: [
        {
          reportGroup: {
            name: 'Report Group 1',
          },
          referenceNumber: 'REF-001',
          jobId: 'JOB-001',
          createdAt: '2023-07-01T12:00:00Z',
          createdByName: 'John Doe',
          createdByEmail: 'john.doe@example.com',
          publishTime: '2023-07-15T12:00:00Z',
          jobStatus: true,
        },
      ],
      referenceNumber: 'REF-001',
      createdByName: 'John Doe',
      createdByEmail: 'john.doe@example.com',
      reportJobStatus: 'Completed',
    },
    {
      jobs: [
        {
          reportGroup: {
            name: 'Report Group 2',
          },
          referenceNumber: 'REF-002',
          jobId: 'JOB-002',
          createdAt: '2023-07-10T12:00:00Z',
          createdByName: 'Jane Smith',
          createdByEmail: 'jane.smith@example.com',
          publishTime: '2023-07-20T12:00:00Z',
          jobStatus: false,
        },
        {
          reportGroup: {
            name: 'Report Group 3',
          },
          referenceNumber: 'REF-003',
          jobId: 'JOB-003',
          createdAt: '2024-07-10T12:00:00Z',
          createdByName: 'Jane Smith',
          createdByEmail: 'jane.smith@example.com',
          publishTime: '2024-07-20T12:00:00Z',
          jobStatus: false,
        },
      ],
      referenceNumber: 'REF-002',
      createdByName: 'Jane Smith',
      createdByEmail: 'jane.smith@example.com',
      reportJobStatus: 'In Progress',
    },
  ]

  test('renders correct table', () => {
    renderTable({ tableConfig, mockData })

    expect(screen.getByText('Report group')).toBeInTheDocument()
    expect(screen.getByText('Generation references')).toBeInTheDocument()
    expect(screen.getByText('Job ID | Job created date & by')).toBeInTheDocument()
    expect(screen.getByText('Completed date')).toBeInTheDocument()
    expect(screen.getByText('Status')).toBeInTheDocument()

    mockData.forEach((data) => {
      expect(screen.getByText(`${data.jobs[0].reportGroup.name || '-'}`)).toBeInTheDocument()
      expect(screen.getByText(data.referenceNumber ? data.referenceNumber : '-')).toBeInTheDocument()
      expect(screen.getByText(`${data.jobs.map((item) => item.jobId).join(', ')}`)).toBeInTheDocument()
      expect(screen.getByText(`${displayFormatDateTime(data.jobs[0].createdAt)} by ${data.createdByName} (${data.createdByEmail})`)).toBeInTheDocument()
      expect(screen.getByText(data.jobs[0].publishTime ? displayFormatDateTime(data.jobs[0].publishTime) : '-')).toBeInTheDocument()
      expect(screen.getByText(data.reportJobStatus ? data.reportJobStatus : '-')).toBeInTheDocument()
    })
  })

  test('renders correct table when no data', () => {
    renderTable({ tableConfig, mockData: [{ jobs: [{}] }] })

    expect(screen.getByText('Report group')).toBeInTheDocument()
    expect(screen.getByText('Generation references')).toBeInTheDocument()
    expect(screen.getByText('Job ID | Job created date & by')).toBeInTheDocument()
    expect(screen.getByText('Completed date')).toBeInTheDocument()
    expect(screen.getByText('Status')).toBeInTheDocument()

    expect(screen.getAllByText('-')).toHaveLength(4)
    expect(screen.getByText('Invalid date by undefined (undefined)')).toBeInTheDocument()
  })
})

describe('employeeRecurringItemsColumn', () => {
  const tableConfig = tableOptions.employeeRecurringItemsColumn(mockHandleEdit)

  const mockData = [
    {
      employeeCode: 'EMP-001',
      payItemCode: 'PAY-001',
      payItemName: 'Base Salary',
    },
    {
      employeeCode: 'EMP-002',
      payItemCode: 'PAY-002',
      payItemName: 'Overtime Pay',
    },
  ]

  test('renders correct table', () => {
    renderTable({ tableConfig, mockData })

    expect(screen.getByText('employee_recurring_title_code')).toBeInTheDocument()
    expect(screen.getByText('employee_recurring_title_paycode')).toBeInTheDocument()
    expect(screen.getByText('employee_recurring_title_payname')).toBeInTheDocument()
    expect(screen.getByText('action')).toBeInTheDocument()

    mockData.forEach((data) => {
      expect(screen.queryAllByText(data.employeeCode)).toHaveLength(2)
      expect(screen.getByText(data.payItemCode)).toBeInTheDocument()
      expect(screen.getByText(data.payItemName)).toBeInTheDocument()
    })

    const dropdownButtons = screen.getAllByLabelText('more')
    fireEvent.click(dropdownButtons[0])
    expect(screen.getByText('Edit Recurring Item')).toBeInTheDocument()
  })
})

describe('employeeQuarterColumn', () => {
  const tableConfig = tableOptions.employeeQuarterColumn(mockHandleEdit)

  const mockData = [
    {
      periodFromDate: '2023-01-01',
      periodToDate: '2023-03-31',
      nature: 'Full-Time',
      status: true,
    },
    {
      periodFromDate: '2023-04-01',
      periodToDate: '2023-06-30',
      nature: 'Part-Time',
      status: false,
    },
  ]

  test('renders correct table', () => {
    renderTable({ tableConfig, mockData })

    expect(screen.getByText('Period (From - To)')).toBeInTheDocument()
    expect(screen.getByText('emp_quarters_nature')).toBeInTheDocument()
    expect(screen.getByText('emp_quarters_status')).toBeInTheDocument()

    mockData.forEach((data) => {
      expect(screen.getByText(`${customDateFormate(data.periodFromDate)} - ${customDateFormate(data.periodToDate)}`)).toBeInTheDocument()
      expect(screen.getByText(data.nature)).toBeInTheDocument()
      const statusLabel = screen.getByText(data.status ? 'Active' : 'Inactive')
      expect(statusLabel).toBeInTheDocument()
      expect(statusLabel).toHaveStyle({
        background: data.status ? '#EBFFF0' : '#E8E6E7',
        color: data.status ? '#00701C' : '#3B3839',
      })
    })

    const dropdownButtons = screen.getAllByLabelText('more')
    fireEvent.click(dropdownButtons[0])
  })
})

describe('employeePensionFundColumn', () => {
  const tableConfig = tableOptions.employeePensionFundColumn(mockHandleEdit)

  const mockData = [
    {
      pensionFundSchemeCode: 'PFS-001',
      entityPensionFundSchemeId: 'PFS-ID-001',
      status: true,
    },
    {
      pensionFundSchemeCode: 'PFS-002',
      entityPensionFundSchemeId: 'PFS-ID-002',
      status: false,
    },
  ]

  test('renders correct table', () => {
    renderTable({ tableConfig, mockData })

    expect(screen.getByText('Pension fund scheme name | Pension fund scheme ID')).toBeInTheDocument()
    expect(screen.getByText('employee_pension_fund_status')).toBeInTheDocument()
    expect(screen.getByText('action')).toBeInTheDocument()

    mockData.forEach((data) => {
      expect(screen.getByText(data.pensionFundSchemeCode)).toBeInTheDocument()
      expect(screen.getByText(data.entityPensionFundSchemeId)).toBeInTheDocument()
      const statusLabel = screen.getByText(data.status ? 'Active' : 'Inactive')
      expect(statusLabel).toBeInTheDocument()
      expect(statusLabel).toHaveStyle({
        background: data.status ? '#EBFFF0' : '#E8E6E7',
        color: data.status ? '#00701C' : '#3B3839',
      })
    })

    const dropdownButtons = screen.getAllByLabelText('more')
    fireEvent.click(dropdownButtons[0])
    expect(screen.getByText('Edit Pension Fund')).toBeInTheDocument()
  })
})

describe('entityEmployeePassword', () => {
  const mockHandleCheckboxChange = jest.fn()
  const mockSelectedCodes = ['EMP-001']
  const tableConfig = tableOptions.entityEmployeePassword(mockHandleEdit, mockHandleCheckboxChange, mockSelectedCodes)

  const mockData = [
    {
      employeeCode: 'EMP-001',
      givenName: 'John Doe',
      departmentCode: 'DEPT-001',
      costCenterCode: 'COST-001',
      expiryDate: '2023-12-31',
      staffTypeCode: 'STAFF-001',
    },
    {
      employeeCode: 'EMP-002',
      givenName: 'Jane Smith',
      departmentCode: 'DEPT-002',
      costCenterCode: 'COST-002',
      expiryDate: null,
      staffTypeCode: 'STAFF-002',
    },
  ]

  test('renders correct table', () => {
    renderTable({ tableConfig, mockData })

    expect(screen.getByText('emp_code_name')).toBeInTheDocument()
    expect(screen.getByText('department_code')).toBeInTheDocument()
    expect(screen.getByText('cost_Center_Code')).toBeInTheDocument()
    expect(screen.getByText('Expiry Date')).toBeInTheDocument()
    expect(screen.getByText('staff_type_code')).toBeInTheDocument()
    expect(screen.getByText('action')).toBeInTheDocument()

    mockData.forEach((data) => {
      expect(screen.getByText(data.employeeCode)).toBeInTheDocument()
      expect(screen.getByText(data.givenName)).toBeInTheDocument()
      expect(screen.getByText(data.departmentCode)).toBeInTheDocument()
      expect(screen.getByText(data.costCenterCode)).toBeInTheDocument()
      if (data.expiryDate) {
        const mockDate = new Date(data.expiryDate)
        expect(screen.getByText(mockDate.toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' }))).toBeInTheDocument()
      } else {
        expect(screen.getByText('-')).toBeInTheDocument()
      }
      expect(screen.getByText(data.staffTypeCode)).toBeInTheDocument()
    })

    const checkboxes = screen.getAllByRole('checkbox')
    expect(checkboxes.length).toBe(mockData.length)
    expect(checkboxes[0]).toBeChecked()
    expect(checkboxes[1]).not.toBeChecked()

    fireEvent.click(checkboxes[1])
    expect(mockHandleCheckboxChange).toBeCalled()

    const dropdownButtons = screen.getAllByLabelText('more')
    fireEvent.click(dropdownButtons[0])
    expect(screen.getByText('Generate Password')).toBeInTheDocument()
  })
})

describe('companyBankAccountColumn', () => {
  const tableConfig = tableOptions.companyBankAccountColumn(mockHandleEdit)

  const mockData = [
    {
      companyBankAccountCode: 'BANK-001',
      companyBankAccountDescription: 'Company Bank Account 1',
      status: true,
    },
    {
      companyBankAccountCode: 'BANK-002',
      companyBankAccountDescription: 'Company Bank Account 2',
      status: false,
    },
  ]

  test('renders correct table', () => {
    renderTable({ tableConfig, mockData })

    expect(screen.getByText('bank_account_name_id')).toBeInTheDocument()
    expect(screen.getByText('status')).toBeInTheDocument()

    mockData.forEach((data) => {
      expect(screen.getByText(data.companyBankAccountDescription)).toBeInTheDocument()
      expect(screen.getByText(data.companyBankAccountCode)).toBeInTheDocument()

      const statusLabel = screen.getByText(data.status ? 'Active' : 'Inactive')
      expect(statusLabel).toBeInTheDocument()
      expect(statusLabel).toHaveStyle({
        background: data.status ? '#EBFFF0' : '#E8E6E7',
        color: data.status ? '#00701C' : '#3B3839',
      })
    })

    const dropdownButtons = screen.getAllByLabelText('more')
    fireEvent.click(dropdownButtons[0])
    expect(screen.getByText('Edit company')).toBeInTheDocument()
    expect(screen.getByText('Delete company bank account')).toBeInTheDocument()
  })
})

describe('pensionFundSchemeColumn', () => {
  const tableConfig = tableOptions.pensionFundSchemeColumn(mockHandleEdit)

  const mockData = [
    {
      pensionFundSchemeCode: 'PFS-001',
      schemeDescription: 'Pension Fund Scheme 1',
      schemeFileNumber: 'PFSFN-001',
      status: true,
    },
    {
      pensionFundSchemeCode: 'PFS-002',
      schemeDescription: 'Pension Fund Scheme 2',
      schemeFileNumber: 'PFSFN-002',
      status: false,
    },
  ]

  test('renders correct table', () => {
    renderTable({ tableConfig, mockData })

    expect(screen.getByText('pension_fund_scheme_name_id')).toBeInTheDocument()
    expect(screen.getByText('ent_pens_fund_scheme_file_number')).toBeInTheDocument()
    expect(screen.getByText('status')).toBeInTheDocument()
    expect(screen.getByText('action')).toBeInTheDocument()

    mockData.forEach((data) => {
      expect(screen.getByText(data.pensionFundSchemeCode)).toBeInTheDocument()
      expect(screen.getByText(data.schemeDescription)).toBeInTheDocument()
      expect(screen.getByText(data.schemeFileNumber)).toBeInTheDocument()

      const statusLabel = screen.getByText(data.status ? 'Active' : 'Inactive')
      expect(statusLabel).toBeInTheDocument()
      expect(statusLabel).toHaveStyle({
        background: data.status ? '#EBFFF0' : '#E8E6E7',
        color: data.status ? '#00701C' : '#3B3839',
      })
    })

    const dropdownButtons = screen.getAllByLabelText('more')
    fireEvent.click(dropdownButtons[0])
    expect(screen.getByText('Edit pension fund scheme')).toBeInTheDocument()
    expect(screen.getByText('Delete pension fund scheme')).toBeInTheDocument()
  })
})

describe('pensionFundItemPayItemColumn', () => {
  const tableConfig = tableOptions.pensionFundItemPayItemColumn(mockHandleEdit)

  const mockData = [
    {
      pensionFundSchemeCode: 'PFS-001',
      effectiveStartDate: '2023-01-01',
      effectiveEndDate: '2023-12-31',
      status: true,
    },
    {
      pensionFundSchemeCode: 'PFS-002',
      effectiveStartDate: '2022-06-01',
      effectiveEndDate: '2023-05-31',
      status: false,
    },
  ]

  test('renders correct table', () => {
    renderTable({ tableConfig, mockData })

    expect(screen.getByText('Pension fund scheme name | Pension fund scheme ID')).toBeInTheDocument()
    expect(screen.getByText('pension_fund_schme_item_date')).toBeInTheDocument()

    mockData.forEach((data) => {
      expect(screen.queryAllByText(data.pensionFundSchemeCode)).toHaveLength(2)

      const formattedStartDate = new Date(data.effectiveStartDate).toLocaleDateString('en-GB', {
        day: '2-digit',
        month: 'short',
        year: 'numeric',
      })
      const formattedEndDate = new Date(data.effectiveEndDate).toLocaleDateString('en-GB', {
        day: '2-digit',
        month: 'short',
        year: 'numeric',
      })
      expect(screen.getByText(`${formattedStartDate} - ${formattedEndDate}`)).toBeInTheDocument()
    })

    const dropdownButtons = screen.getAllByLabelText('more')
    fireEvent.click(dropdownButtons[0])
    expect(screen.getByText('Edit Pension Fund Scheme Item')).toBeInTheDocument()
    expect(screen.getByText('Delete Pension Fund Scheme Item')).toBeInTheDocument()
  })
})

describe('entitypensionFundSchemeItemsColumn', () => {
  const tableConfig = tableOptions.entitypensionFundSchemeItemsColumn(mockHandleEdit)

  const mockData = [
    {
      payItemCode: 'PIS-001',
      effectiveStartDate: '2023-01-01',
      effectiveEndDate: '2023-12-31',
      status: true,
    },
    {
      payItemCode: 'PIS-002',
      effectiveStartDate: '2022-06-01',
      effectiveEndDate: '2023-05-31',
      status: false,
    },
  ]

  test('renders correct table', () => {
    renderTable({ tableConfig, mockData })

    expect(screen.getByText('payItemCode')).toBeInTheDocument()
    expect(screen.getByText('pension_fund_schme_item_date')).toBeInTheDocument()
    expect(screen.getByText('status')).toBeInTheDocument()

    mockData.forEach((data) => {
      expect(screen.getByText(data.payItemCode)).toBeInTheDocument()

      const formattedStartDate = new Date(data.effectiveStartDate).toLocaleDateString('en-GB', {
        day: '2-digit',
        month: 'short',
        year: 'numeric',
      })
      const formattedEndDate = new Date(data.effectiveEndDate).toLocaleDateString('en-GB', {
        day: '2-digit',
        month: 'short',
        year: 'numeric',
      })
      expect(screen.getByText(`${formattedStartDate} - ${formattedEndDate}`)).toBeInTheDocument()

      expect(screen.getByText(data.status ? 'Active' : 'Inactive')).toBeInTheDocument()
    })

    const dropdownButtons = screen.getAllByLabelText('more')
    fireEvent.click(dropdownButtons[0])
    expect(screen.getByText('Edit Pension Fund Scheme Item')).toBeInTheDocument()
    expect(screen.getByText('Delete Pension Fund Scheme Item')).toBeInTheDocument()
  })
})

describe('pensionSchemeModalColumn', () => {
  const tableConfig = tableOptions.pensionSchemeModalColumn(mockHandleClick)

  const mockData = [
    {
      payItemCode: 'PIS-001',
      effectiveStartDate: '2023-01-01',
      effectiveEndDate: '2023-12-31',
    },
    {
      payItemCode: 'PIS-002',
      effectiveStartDate: '2022-06-01',
      effectiveEndDate: '2023-05-31',
    },
  ]

  test('renders correct table', () => {
    renderTable({ tableConfig, mockData })

    expect(screen.getByText('ent_pens_fund_scheme_title')).toBeInTheDocument()
    expect(screen.getByText('pension_fund_schme_item_date')).toBeInTheDocument()

    mockData.forEach((data) => {
      expect(screen.getByText(data.payItemCode)).toBeInTheDocument()

      const formattedStartDate = new Date(data.effectiveStartDate).toLocaleDateString('en-GB', {
        day: '2-digit',
        month: 'short',
        year: 'numeric',
      })
      const formattedEndDate = new Date(data.effectiveEndDate).toLocaleDateString('en-GB', {
        day: '2-digit',
        month: 'short',
        year: 'numeric',
      })
      expect(screen.getByText(`${formattedStartDate} - ${formattedEndDate}`)).toBeInTheDocument()
    })
  })
})

describe('payCycleAdministratorColumn', () => {
  const tableConfig = tableOptions.payCycleAdministratorColumn(mockHandleEdit)

  const mockData = [
    {
      payCycleName: 'Pay Cycle 1',
      payCycleYear: 2022,
      payCycleMonth: 5,
      payCycleStartDate: '2022-05-01',
      payCycleEndDate: '2022-05-31',
      payCycleType: { label: 'Regular' },
      status: { label: 'undefined' },
    },
    {
      payCycleName: 'Pay Cycle 2',
      payCycleYear: 2023,
      payCycleMonth: 6,
      payCycleStartDate: '2023-06-01',
      payCycleEndDate: '2023-06-30',
      payCycleType: { label: 'Supplementary' },
      status: { label: 'undefined2' },
    },
  ]

  test('renders correct table', () => {
    renderTable({ tableConfig, mockData })

    expect(screen.getByText('Pay Cycle|Month & Year')).toBeInTheDocument()
    expect(screen.getByText('Payroll period')).toBeInTheDocument()
    expect(screen.getByText('Type')).toBeInTheDocument()
    expect(screen.getByText('Status')).toBeInTheDocument()

    mockData.forEach((data) => {
      expect(screen.getByText(data.payCycleName)).toBeInTheDocument()

      const formattedMonthYear = new Date(`${data.payCycleYear}-${data.payCycleMonth}`).toLocaleString('default', {
        month: 'long',
        year: 'numeric',
      })
      expect(screen.getByText(formattedMonthYear)).toBeInTheDocument()

      const formattedStartDate = new Date(data.payCycleStartDate).toLocaleDateString('en-GB', {
        day: '2-digit',
        month: 'short',
        year: 'numeric',
      })
      const formattedEndDate = new Date(data.payCycleEndDate).toLocaleDateString('en-GB', {
        day: '2-digit',
        month: 'short',
        year: 'numeric',
      })
      expect(screen.getByText(`${formattedStartDate} - ${formattedEndDate}`)).toBeInTheDocument()

      expect(screen.getByText(data.payCycleType.label)).toBeInTheDocument()
      expect(screen.getByText(data.status.label)).toBeInTheDocument()
    })

    const actionMenuButtons = screen.getAllByLabelText('more')
    fireEvent.click(actionMenuButtons[0])
    expect(screen.queryAllByRole('presentation')).toHaveLength(1)
  })

  const mockActionMenuData = (mockStatus: string) => [{
    payCycleName: 'Pay Cycle Mock',
    payCycleYear: 2000,
    payCycleMonth: 1,
    payCycleStartDate: '2000-01-01',
    payCycleEndDate: '2000-01-30',
    payCycleType: { label: 'Mock' },
    status: { label: mockStatus },
  }]

  test('renders correct action menu when finalized', () => {
    renderTable({ tableConfig, mockData: mockActionMenuData('Finalized') })

    const actionMenuButtons = screen.getByLabelText('more')
    fireEvent.click(actionMenuButtons)
    const menuButtons = screen.getByRole('presentation')
    fireEvent.click(menuButtons)
    expect(screen.getByText(t('Unfinalize batch'))).toBeInTheDocument()
    fireEvent.click(screen.getByText(t('Unfinalize batch')))
    expect(mockHandleEdit).toBeCalled()
  })

  test('renders correct action menu when unfinalized', () => {
    renderTable({ tableConfig, mockData: mockActionMenuData('Unfinalized') })

    const actionMenuButtons = screen.getByLabelText('more')
    fireEvent.click(actionMenuButtons)
    const menuButtons = screen.getByRole('presentation')
    fireEvent.click(menuButtons)
    expect(screen.getByText(t('Deactivate batch'))).toBeInTheDocument()
    fireEvent.click(screen.getByText(t('Deactivate batch')))
    expect(mockHandleEdit).toHaveBeenCalledTimes(1)
    expect(screen.getByText(t('Edit pay cycle'))).toBeInTheDocument()
    fireEvent.click(screen.getByText(t('Edit pay cycle')))
    expect(mockHandleEdit).toHaveBeenCalledTimes(2)
  })

  test('renders correct action menu when locked', () => {
    renderTable({ tableConfig, mockData: mockActionMenuData('Locked') })

    const actionMenuButtons = screen.getByLabelText('more')
    fireEvent.click(actionMenuButtons)
    const menuButtons = screen.getByRole('presentation')
    fireEvent.click(menuButtons)
    expect(screen.getByText(t('Unlock batch'))).toBeInTheDocument()
    fireEvent.click(screen.getByText(t('Unlock batch')))
    expect(mockHandleEdit).toHaveBeenCalledTimes(1)
    expect(screen.getByText(t('Finalize batch'))).toBeInTheDocument()
    fireEvent.click(screen.getByText(t('Finalize batch')))
    expect(mockHandleEdit).toHaveBeenCalledTimes(2)
    expect(screen.getByText(t('Edit pay cycle'))).toBeInTheDocument()
    fireEvent.click(screen.getByText(t('Edit pay cycle')))
    expect(mockHandleEdit).toHaveBeenCalledTimes(3)
  })

  test('renders correct action menu when unlocked', () => {
    renderTable({ tableConfig, mockData: mockActionMenuData('Unlocked') })

    const actionMenuButtons = screen.getByLabelText('more')
    fireEvent.click(actionMenuButtons)
    const menuButtons = screen.getByRole('presentation')
    fireEvent.click(menuButtons)
    expect(screen.getByText(t('Drop batch on selected employee'))).toBeInTheDocument()
    fireEvent.click(screen.getByText(t('Drop batch on selected employee')))
    expect(mockHandleEdit).toHaveBeenCalledTimes(1)
    expect(screen.getByText(t('Drop whole batch'))).toBeInTheDocument()
    fireEvent.click(screen.getByText(t('Drop whole batch')))
    expect(mockHandleEdit).toHaveBeenCalledTimes(2)
    expect(screen.getByText(t('Lock batch'))).toBeInTheDocument()
    fireEvent.click(screen.getByText(t('Lock batch')))
    expect(mockHandleEdit).toHaveBeenCalledTimes(3)
    expect(screen.getByText(t('Edit pay cycle'))).toBeInTheDocument()
    fireEvent.click(screen.getByText(t('Edit pay cycle')))
    expect(mockHandleEdit).toHaveBeenCalledTimes(4)
  })

  test('renders correct action menu when PF dropped', () => {
    renderTable({ tableConfig, mockData: mockActionMenuData('PF Dropped') })

    const actionMenuButtons = screen.getByLabelText('more')
    fireEvent.click(actionMenuButtons)
    const menuButtons = screen.getByRole('presentation')
    fireEvent.click(menuButtons)
    expect(screen.getByText(t('Drop batch on selected employee'))).toBeInTheDocument()
    fireEvent.click(screen.getByText(t('Drop batch on selected employee')))
    expect(mockHandleEdit).toHaveBeenCalledTimes(1)
    expect(screen.getByText(t('Drop whole batch'))).toBeInTheDocument()
    fireEvent.click(screen.getByText(t('Drop whole batch')))
    expect(mockHandleEdit).toHaveBeenCalledTimes(2)
    expect(screen.getByText(t('Edit pay cycle'))).toBeInTheDocument()
    fireEvent.click(screen.getByText(t('Edit pay cycle')))
    expect(mockHandleEdit).toHaveBeenCalledTimes(3)
  })

  test('renders correct action menu when open', () => {
    renderTable({ tableConfig, mockData: mockActionMenuData('Open') })

    const actionMenuButtons = screen.getByLabelText('more')
    fireEvent.click(actionMenuButtons)
    const menuButtons = screen.getByRole('presentation')
    fireEvent.click(menuButtons)
    expect(screen.getByText(t('Deactivate batch'))).toBeInTheDocument()
    fireEvent.click(screen.getByText(t('Deactivate batch')))
    expect(mockHandleEdit).toHaveBeenCalledTimes(1)
    expect(screen.getByText(t('Edit pay cycle'))).toBeInTheDocument()
    fireEvent.click(screen.getByText(t('Edit pay cycle')))
    expect(mockHandleEdit).toHaveBeenCalledTimes(2)
  })

  test('renders correct action menu when inactive', () => {
    renderTable({ tableConfig, mockData: mockActionMenuData('Inactive') })

    const actionMenuButtons = screen.getByLabelText('more')
    fireEvent.click(actionMenuButtons)
    const menuButtons = screen.getByRole('presentation')
    fireEvent.click(menuButtons)
    expect(screen.getByText(t('Open batch'))).toBeInTheDocument()
    fireEvent.click(screen.getByText(t('Open batch')))
    expect(mockHandleEdit).toHaveBeenCalledTimes(1)
    expect(screen.getByText(t('Edit pay cycle'))).toBeInTheDocument()
    fireEvent.click(screen.getByText(t('Edit pay cycle')))
    expect(mockHandleEdit).toHaveBeenCalledTimes(2)
  })

  test('renders correct action menu when completed', () => {
    renderTable({ tableConfig, mockData: mockActionMenuData('Completed') })

    const actionMenuButtons = screen.getByLabelText('more')
    fireEvent.click(actionMenuButtons)
    const menuButtons = screen.getByRole('presentation')
    fireEvent.click(menuButtons)
    expect(screen.getByText(t('Drop batch on selected employee'))).toBeInTheDocument()
    fireEvent.click(screen.getByText(t('Drop batch on selected employee')))
    expect(mockHandleEdit).toHaveBeenCalledTimes(1)
    expect(screen.getByText(t('Drop whole batch'))).toBeInTheDocument()
    fireEvent.click(screen.getByText(t('Drop whole batch')))
    expect(mockHandleEdit).toHaveBeenCalledTimes(2)
    expect(screen.getByText(t('Lock batch'))).toBeInTheDocument()
    fireEvent.click(screen.getByText(t('Lock batch')))
    expect(mockHandleEdit).toHaveBeenCalledTimes(3)
    expect(screen.getByText(t('Edit pay cycle'))).toBeInTheDocument()
    fireEvent.click(screen.getByText(t('Edit pay cycle')))
    expect(mockHandleEdit).toHaveBeenCalledTimes(4)
  })
})

describe('entityCustomReportDesignerColumn', () => {
  const tableConfig = tableOptions.entityCustomReportDesignerColumn(mockHandleEdit)

  const mockData = [
    {
      reportName: 'Report 1',
      reportCode: 'REP001',
      reportFormats: ['PDF', 'Excel', 'CSV'],
    },
    {
      reportName: 'Report 2',
      reportCode: 'REP002',
      reportFormats: ['PDF2', 'CSV2'],
    },
  ]

  test('renders correct table', () => {
    renderTable({ tableConfig, mockData })

    expect(screen.getByText('Report Name | Report ID')).toBeInTheDocument()
    expect(screen.getByText('Report format')).toBeInTheDocument()

    mockData.forEach((data) => {
      expect(screen.getByText(data.reportName)).toBeInTheDocument()
      expect(screen.getByText(data.reportCode)).toBeInTheDocument()

      data.reportFormats.forEach((format) => {
        expect(screen.getByText(format)).toBeInTheDocument()
      })
    })

    const dropdownButtons = screen.getAllByLabelText('more')
    fireEvent.click(dropdownButtons[0])
    expect(screen.getByText('Delete custom report')).toBeInTheDocument()
  })
})

describe('payrollMonthEndClosingColumn', () => {
  const tableConfig = tableOptions.payrollMonthEndClosingColumn(mockHandleEdit)

  const mockData = [
    {
      payCycleName: 'Monthly Payroll',
      payCycleCode: 'MP01',
      payCycleStartDate: '2023-07-01',
      payCycleEndDate: '2023-07-31',
      payCycleType: { label: 'Regular' },
      status: { label: 'Finalized' },
    },
    {
      payCycleName: 'Bi-Weekly Payroll',
      payCycleCode: 'BP02',
      payCycleStartDate: '2023-08-01',
      payCycleEndDate: '2023-08-15',
      payCycleType: { label: 'Regular2' },
      status: { label: 'Open' },
    },
    {
      payCycleName: 'Quarterly Payroll',
      payCycleCode: 'QP03',
      payCycleStartDate: '2023-09-01',
      payCycleEndDate: '2023-09-30',
      payCycleType: { label: 'Regular3' },
      status: { label: 'Locked' },
    },
    {
      payCycleName: 'Yearly Payroll',
      payCycleCode: 'QP04',
      payCycleStartDate: '2021-09-01',
      payCycleEndDate: '2021-09-30',
      payCycleType: { label: 'Regular4' },
      status: { label: 'unknown' },
    },
    {
      payCycleName: 'Total Payroll',
      payCycleCode: 'QP05',
      payCycleStartDate: '2020-09-01',
      payCycleEndDate: '2020-09-30',
      payCycleType: { label: 'Regular5' },
      status: { label: 'Inactive' },
    },
  ]

  test('renders correct table', () => {
    renderTable({ tableConfig, mockData })

    expect(screen.getByText('Pay Cycle')).toBeInTheDocument()
    expect(screen.getByText('Payroll period')).toBeInTheDocument()
    expect(screen.getByText('Type')).toBeInTheDocument()
    expect(screen.getByText('Status')).toBeInTheDocument()

    mockData.forEach((data) => {
      expect(screen.getByText(`${data.payCycleName} - (${data.payCycleCode})`)).toBeInTheDocument()

      const startDate = new Date(data.payCycleStartDate)
      const formattedStartDate = startDate.toLocaleDateString('en-GB', {
        day: '2-digit',
        month: 'short',
        year: 'numeric',
      })

      const endDate = new Date(data.payCycleEndDate)
      const formattedEndDate = endDate.toLocaleDateString('en-GB', {
        day: '2-digit',
        month: 'short',
        year: 'numeric',
      })

      expect(screen.getByText(`${formattedStartDate} - ${formattedEndDate}`)).toBeInTheDocument()
      expect(screen.getByText(data.payCycleType.label)).toBeInTheDocument()
      expect(screen.getByText(data.status.label)).toBeInTheDocument()

      const statusLabel = screen.getByText(data.status.label)
      if (data.status.label === 'Finalized') {
        expect(statusLabel).toHaveStyle({
          background: '#EBFFF0',
          color: '#00701C',
        })
      } else if (data.status.label === 'Open') {
        expect(statusLabel).toHaveStyle({
          background: '#EBFFF0',
          color: '#9E5A00',
        })
      } else if (data.status.label === 'Locked') {
        expect(statusLabel).toHaveStyle({
          background: '#EBFFF0',
          color: '#FF0000',
        })
      } else if (data.status.label === 'Inactive') {
        expect(statusLabel).toHaveStyle({
          background: '#F0F0F0',
          color: '#808080',
        })
      } else {
        expect(statusLabel).toHaveStyle({
          background: '#E8E6E7',
          color: '#3B3839',
        })
      }
    })
  })
})

describe('logsPaycycle', () => {
  const tableConfig = tableOptions.logsPaycycle(mockHandleEdit)

  const mockData = [
    {
      payCycleYear: 2023,
      payCycleMonth: 1,
      payrollMonth: 'January',
      cycleCode: 'PC001',
      jobRunId: 'J001',
      jobCreatedBy: 'John Doe',
      completedDateTime: '2023-01-15',
      status: 'Success',
      logFile: 'log_file.txt',
    },
    {
      payCycleYear: 2022,
      payCycleMonth: 2,
      payrollMonth: 'February',
      cycleCode: 'PC002',
      jobRunId: 'J002',
      jobCreatedBy: 'Jane Smith',
      completedDateTime: '2022-02-28',
      status: 'Failed',
      logFile: 'log_file_2.txt',
    },
    {
      payCycleYear: 2021,
      payCycleMonth: 3,
      payrollMonth: 'March',
      cycleCode: 'PC003',
      jobRunId: 'J003',
      jobCreatedBy: 'Bob Johnson',
      completedDateTime: '2021-03-31',
      status: 'Pending',
      logFile: 'log_file_3.txt',
    },
    {
      payCycleYear: 2020,
      payCycleMonth: 4,
      payrollMonth: 'April',
      cycleCode: 'PC004',
      jobRunId: 'J004',
      jobCreatedBy: 'Charlie Brown',
      completedDateTime: '2020-03-31',
      status: 'unknown',
      logFile: 'log_file_4.txt',
    },
  ]

  test('renders correct table', () => {
    renderTable({ tableConfig, mockData })

    expect(screen.getByText('Pay cycle name|Pay cycle ID')).toBeInTheDocument()
    expect(screen.getByText('Job ID | Job created date & by')).toBeInTheDocument()
    expect(screen.getByText('Completed date')).toBeInTheDocument()
    expect(screen.getByText('Status')).toBeInTheDocument()
    expect(screen.getByText('Intermediate step calculation')).toBeInTheDocument()
    expect(screen.getByText('File')).toBeInTheDocument()

    mockData.forEach((data) => {
      expect(screen.getByText(data.payrollMonth)).toBeInTheDocument()
      expect(screen.getByText(data.cycleCode)).toBeInTheDocument()
      expect(screen.getByText(data.jobRunId)).toBeInTheDocument()
      expect(screen.getByText(data.jobCreatedBy)).toBeInTheDocument()
      expect(screen.getByText(data.completedDateTime)).toBeInTheDocument()
      expect(screen.getByText(data.status)).toBeInTheDocument()
      expect(screen.getByText(data.logFile)).toBeInTheDocument()
    })

    const downloadButtons = screen.getAllByText('Button')
    expect(downloadButtons).toHaveLength(8)
    const button = screen.getAllByText('Button')[0]
    fireEvent.click(button)
    expect(mockHandleEdit).toBeCalled()
  })
})

describe('payrollSlipColumn', () => {
  const tableConfig = tableOptions.payrollSlipColumn(mockHandleEdit)

  const mockData = [
    {
      referenceNumber: '12345',
      jobs: [
        {
          jobId: 'JOB001',
          createdAt: '2022-08-01',
        },
      ],
      createdByName: 'John Doe',
      createdByEmail: 'john.doe@example.com',
      publishTime: '2022-08-15',
      reportJobStatus: 'Success',
    },
    {
      referenceNumber: '67890',
      jobs: [
        {
          jobId: 'JOB002',
          createdAt: '2023-08-05',
        },
        {
          jobId: 'JOB003',
          createdAt: '2023-08-10',
        },
      ],
      createdByName: 'Jane Smith',
      createdByEmail: 'jane.smith@example.com',
      publishTime: '2021-08-20',
      reportJobStatus: 'Failed',
    },
    {
      referenceNumber: '54321',
      jobs: [
        {
          jobId: 'JOB004',
          createdAt: '2021-08-15',
        },
      ],
      createdByName: 'Bob Johnson',
      createdByEmail: 'bob.johnson@example.com',
      publishTime: null,
      reportJobStatus: 'Pending',
    },
    {
      referenceNumber: '15951',
      jobs: [
        {
          jobId: 'JOB005',
          createdAt: '2020-08-15',
        },
      ],
      createdByName: 'Charlie Brown',
      createdByEmail: 'brown.charlie@example.com',
      publishTime: '2000-08-20',
      reportJobStatus: 'unknown',
    },
  ]

  test('renders correct table', () => {
    renderTable({ tableConfig, mockData })

    expect(screen.getByText('Generation references')).toBeInTheDocument()
    expect(screen.getByText('Job ID | Job created date & by')).toBeInTheDocument()
    expect(screen.getByText('Completed date')).toBeInTheDocument()
    expect(screen.getByText('Status')).toBeInTheDocument()

    mockData.forEach((data) => {
      const mockdatadata:any = (data?.jobs || []).map((item:any) => item?.jobId)
      const valuesString = mockdatadata?.join(', ')
      expect(screen.getByText(data.referenceNumber)).toBeInTheDocument()
      expect(screen.getByText(valuesString)).toBeInTheDocument()
      expect(screen.getByText(`${displayFormatDateTime(data?.jobs[0]?.createdAt)} by ${data?.createdByName} (${data?.createdByEmail})`)).toBeInTheDocument()
      expect(screen.getByText(data.reportJobStatus)).toBeInTheDocument()

      const statusLabel = screen.getByText(data.reportJobStatus)
      expect(statusLabel).toBeInTheDocument()
      if (data.reportJobStatus === 'Success') {
        expect(statusLabel).toHaveStyle('color: #00701C; background: #EBFFF0;')
      } else if (data.reportJobStatus === 'Failed') {
        expect(statusLabel).toHaveStyle('color: #FF0000; background: #FFEAEA;')
      } else if (data.reportJobStatus === 'Pending') {
        expect(statusLabel).toHaveStyle('color: #0000FF; background: #EAF0FF;')
      } else {
        expect(statusLabel).toHaveStyle('color: #3B3839; background: #EBEBEB;')
      }
      if (data.publishTime) {
        expect(screen.getByText(displayFormatDateTime(data.publishTime))).toBeInTheDocument()
      } else {
        expect(screen.getByText('-')).toBeInTheDocument()
      }
    })
  })

  test('renders correct table when data is missing', () => {
    renderTable({
      tableConfig,
      mockData: [
        {
          jobs: [
            {
              jobId: 'JOB002',
              createdAt: '2023-08-05',
            },
            {
              jobId: 'JOB003',
              createdAt: '2023-08-10',
            },
          ],
          createdByName: 'Jane Smith',
          createdByEmail: 'jane.smith@example.com',
          publishTime: '2021-08-20',
          reportJobStatus: 'Failed',
        },
      ],
    })
    expect(screen.getByText('-')).toBeInTheDocument()
  })
})

describe('emailProfileColumn', () => {
  const tableConfig = tableOptions.emailProfileColumn(mockHandleEdit)

  const mockData = [
    {
      emailProfileName: 'Default Email Profile',
      emailProfileCode: 'DEF001',
      setAsDefaultEmailProfile: true,
    },
    {
      emailProfileName: 'Marketing Email Profile',
      emailProfileCode: 'MKT001',
      setAsDefaultEmailProfile: false,
    },
  ]

  test('renders correct table', () => {
    renderTable({ tableConfig, mockData })

    expect(screen.getByText('email_profile_name_id')).toBeInTheDocument()
    expect(screen.getByText('Default')).toBeInTheDocument()
    expect(screen.getByText('action')).toBeInTheDocument()

    mockData.forEach((data) => {
      expect(screen.getByText(data.emailProfileName)).toBeInTheDocument()
      expect(screen.getByText(data.emailProfileCode)).toBeInTheDocument()
      expect(screen.getByText(data.setAsDefaultEmailProfile ? 'Yes' : 'No')).toBeInTheDocument()
    })

    const dropdownButtons = screen.getAllByLabelText('more')
    fireEvent.click(dropdownButtons[0])
    expect(screen.getByText('Edit email profile')).toBeInTheDocument()
    expect(screen.getByText('Delete email profile')).toBeInTheDocument()
  })
})

describe('movementModalColumn', () => {
  const tableConfig = tableOptions.movementModalColumn(mockHandleEdit)

  const mockData = [
    {
      employeeProfile: {
        givenName: 'John Doe',
      },
      employeeCode: 'EMP001',
      employeeWorkEmailAddress: 'john.doe@example.com',
      commencementDate: '2022-01-01',
      lastEmploymentDate: '2024-12-31',
      employeeStatus: true,
    },
    {
      employeeProfile: {
        givenName: 'Jane Smith',
      },
      employeeCode: 'EMP002',
      employeeWorkEmailAddress: 'jane.smith@example.com',
      commencementDate: '2020-06-15',
      lastEmploymentDate: '2023-09-30',
      employeeStatus: false,
    },
  ]

  test('renders correct table', () => {
    renderTable({ tableConfig, mockData })

    expect(screen.getByText('employee_name_code')).toBeInTheDocument()
    expect(screen.getByText('Provider_Email_Address')).toBeInTheDocument()
    expect(screen.getByText('employee_profile_commencement_date')).toBeInTheDocument()
    expect(screen.getByText('employee_profile_last_working_date')).toBeInTheDocument()
    expect(screen.getByText('Employment status')).toBeInTheDocument()

    mockData.forEach((data) => {
      expect(screen.getByText(data.employeeProfile.givenName)).toBeInTheDocument()
      expect(screen.getByText(data.employeeCode)).toBeInTheDocument()
      expect(screen.getByText(data.employeeWorkEmailAddress)).toBeInTheDocument()
      expect(screen.getByText(data.commencementDate)).toBeInTheDocument()
      expect(screen.getByText(data.lastEmploymentDate)).toBeInTheDocument()

      const statusLabel = screen.getByText(data.employeeStatus ? 'Active' : 'Inactive')
      expect(statusLabel).toBeInTheDocument()
      expect(statusLabel).toHaveStyle({
        background: data.employeeStatus ? '#EBFFF0' : '#E8E6E7',
        color: data.employeeStatus ? '#00701C' : '#3B3839',
      })
    })
  })
})

describe('sendPaySlipColumn', () => {
  const tableConfig = tableOptions.sendPaySlipColumn(mockHandleEdit)

  const mockData = [
    {
      employeeDetail: {
        employeeGivenName: 'John Doe',
        employeeCode: 'EMP001',
        employeeWorkEmailAddress: 'john.doe@example.com',
      },
      fileName: 'pay_slip_2023-05-01.pdf',
    },
    {
      employeeDetail: {
        employeeGivenName: 'Jane Smith',
        employeeCode: 'EMP002',
        employeeWorkEmailAddress: 'jane.smith@example.com',
      },
      fileName: 'pay_slip_2023-06-15.pdf',
    },
  ]

  test('renders correct table', () => {
    renderTable({ tableConfig, mockData })

    expect(screen.getByText('employee_name_code')).toBeInTheDocument()
    expect(screen.getByText('Provider_Email_Address')).toBeInTheDocument()
    expect(screen.getByText('File Name 1')).toBeInTheDocument()
    expect(screen.getByText('File Name 2')).toBeInTheDocument()
    expect(screen.getByText('File Name 3')).toBeInTheDocument()

    mockData.forEach((data) => {
      expect(screen.getByText(data.employeeDetail.employeeGivenName)).toBeInTheDocument()
      expect(screen.getByText(data.employeeDetail.employeeCode)).toBeInTheDocument()
      expect(screen.getByText(data.employeeDetail.employeeWorkEmailAddress)).toBeInTheDocument()
      expect(screen.getAllByText(data.fileName)).toHaveLength(3)
    })
  })
})

describe('reassignmentModalColumn', () => {
  const tableConfig = tableOptions.reassignmentModalColumn(mockHandleEdit)

  const mockData = [
    {
      employeeCode: 'EMP001',
      terminationDate: '2023-06-30',
      defaultMainCycleCode: 'MAINC001',
      changeToPayCycleCode: 'NEWC001',
    },
    {
      employeeCode: 'EMP002',
      terminationDate: '2023-07-31',
      defaultMainCycleCode: 'MAINC002',
      changeToPayCycleCode: 'NEWC002',
    },
  ]

  test('renders correct table', () => {
    renderTable({ tableConfig, mockData })

    expect(screen.getByText('empl_name_empl_id')).toBeInTheDocument()
    expect(screen.getByText('termination_date')).toBeInTheDocument()
    expect(screen.getByText('default_main_cycle')).toBeInTheDocument()
    expect(screen.getByText('new_pay_cycle')).toBeInTheDocument()

    mockData.forEach((data) => {
      expect(screen.getByText(data.employeeCode)).toBeInTheDocument()
      const terminationDate = new Date(data.terminationDate)
      const formattedDate = terminationDate.toLocaleDateString('en-GB', {
        day: '2-digit',
        month: 'long',
        year: 'numeric',
      })
      expect(screen.getByText(formattedDate)).toBeInTheDocument()
      expect(screen.getByText(data.defaultMainCycleCode)).toBeInTheDocument()
    })
  })
})

describe('reassignmentConfirmModalColumn', () => {
  const tableConfig = tableOptions.reassignmentConfirmModalColumn(mockHandleEdit)

  const mockData = [
    {
      employeeCode: 'EMP001',
      defaultMainCycleCode: 'MAINC001',
      changeToPayCycleCode: 'NEWC001',
    },
    {
      employeeCode: 'EMP002',
      defaultMainCycleCode: 'MAINC002',
      changeToPayCycleCode: 'NEWC002',
    },
  ]

  test('renders correct table', () => {
    renderTable({ tableConfig, mockData })

    expect(screen.getByText('empl_name_empl_id')).toBeInTheDocument()
    expect(screen.getByText('default_main_cycle')).toBeInTheDocument()
    expect(screen.getByText('new_pay_cycle')).toBeInTheDocument()

    mockData.forEach((data) => {
      expect(screen.getByText(data.employeeCode)).toBeInTheDocument()
      expect(screen.getByText(data.defaultMainCycleCode)).toBeInTheDocument()
      expect(screen.getByText(data.changeToPayCycleCode)).toBeInTheDocument()
    })
  })
})

describe('logsPaycycleData', () => {
  const mockOnChange = jest.fn()

  const tableConfig = tableOptions.logsPaycycleData(mockHandleEdit, true, false, mockOnChange)

  const mockData = [
    {
      payCycleName: 'Pay Cycle 1',
      payCycleMonth: '06',
      payCycleYear: '2022',
      jobId: 'JOB001',
      createdBy: 'John Doe',
      completedDate: '2022-06-30',
      status: { label: 'Completed' },
    },
    {
      payCycleName: 'Pay Cycle 2',
      payCycleMonth: '07',
      payCycleYear: '2023',
      jobId: 'JOB002',
      createdBy: 'Jane Smith',
      completedDate: '2023-07-31',
      status: { label: 'Pending' },
    },
  ]

  test('renders correct table', () => {
    renderTable({ tableConfig, mockData })

    expect(screen.getByText(`${t('Pay Cycle')}|${t('Month & Year')}`)).toBeInTheDocument()
    expect(screen.getByText('Job ID | Job created date & by')).toBeInTheDocument()
    expect(screen.getByText('Completed date')).toBeInTheDocument()
    expect(screen.getByText('Status')).toBeInTheDocument()
    expect(screen.getByText('action')).toBeInTheDocument()

    expect(screen.queryAllByText('Checkbox')).toHaveLength(2)

    mockData.forEach((data) => {
      expect(screen.getByText(data.payCycleName)).toBeInTheDocument()

      const monthYear = new Date(`${data?.payCycleYear}-${data?.payCycleMonth}`)
      const formattedMonthYear = monthYear.toLocaleString('default', { month: 'long', year: 'numeric' })
      expect(screen.getByText(formattedMonthYear)).toBeInTheDocument()

      expect(screen.getByText(data.jobId)).toBeInTheDocument()
      expect(screen.getByText(data.createdBy)).toBeInTheDocument()
      expect(screen.getByText(data.completedDate)).toBeInTheDocument()
      expect(screen.getByText(data.status.label)).toBeInTheDocument()
    })

    const actionMenuButtons = screen.getAllByLabelText('more')
    fireEvent.click(actionMenuButtons[0])
    expect(screen.getByText('Generate Password')).toBeInTheDocument()
  })
})

describe('auditTrailCoulumn', () => {
  const tableConfig = tableOptions.auditTrailCoulumn(mockHandleEdit)

  const mockData = [
    {
      referenceNumber: 'REF001',
      jobs: [
        {
          jobId: 'JOB001',
          createdAt: '2023-06-01T12:00:00Z',
          updatedAt: '2023-06-30T12:00:00Z',
          jobStatus: 'Completed',
        },
      ],
      createdByName: 'John Doe',
      createdByEmail: 'john.doe@example.com',
    },
    {
      referenceNumber: 'REF002',
      jobs: [
        {
          jobId: 'JOB002',
          createdAt: '2023-07-01T12:00:00Z',
          updatedAt: '2023-07-31T12:00:00Z',
          jobStatus: 'Pending',
        },
      ],
      createdByName: 'Jane Smith',
      createdByEmail: 'jane.smith@example.com',
    },
  ]

  test('renders correct table', () => {
    renderTable({ tableConfig, mockData })

    expect(screen.getByText('Generation references')).toBeInTheDocument()
    expect(screen.getByText('Job ID | Job created date & by')).toBeInTheDocument()
    expect(screen.getByText('Completed date')).toBeInTheDocument()
    expect(screen.getByText('Status')).toBeInTheDocument()

    mockData.forEach((data) => {
      expect(screen.getByText(data.referenceNumber)).toBeInTheDocument()
      const mockDataData:any = (data?.jobs || []).map((item:any) => item?.jobId)
      const valuesString = mockDataData?.join(', ')
      expect(screen.getByText(valuesString)).toBeInTheDocument()
      expect(screen.getByText(`${displayFormatDateTime(data?.jobs[0]?.createdAt)} by ${data?.createdByName} (${data?.createdByEmail})`)).toBeInTheDocument()
      expect(screen.getByText(`${displayFormatDateTime(data?.jobs[0]?.updatedAt)}`)).toBeInTheDocument()
      expect(screen.getByText(data?.jobs[0]?.jobStatus)).toBeInTheDocument()
    })
  })
})

describe('sendEmailColumn', () => {
  const tableConfig = tableOptions.sendEmailColumn(mockHandleEdit)

  const mockData = [
    {
      emailSubject: 'Welcome to our company',
      emailsSent: 50,
      emailsNotSent: 5,
      jobID: 'JOB001',
      jobCreatedDateTime: '2023-06-01T12:00:00Z',
      jobCreatedBy: 'John Doe',
      status: 'Completed',
    },
    {
      emailSubject: 'Important announcement',
      emailsSent: 30,
      emailsNotSent: 0,
      jobID: 'JOB002',
      jobCreatedDateTime: '2023-07-01T12:00:00Z',
      jobCreatedBy: 'Jane Smith',
      status: 'In Progress',
    },
  ]

  test('renders correct table', () => {
    renderTable({ tableConfig, mockData })

    expect(screen.getByText('email_subject')).toBeInTheDocument()
    expect(screen.getByText('delivered')).toBeInTheDocument()
    expect(screen.getByText('not_delivered')).toBeInTheDocument()
    expect(screen.getByText('job_id_created_date_by')).toBeInTheDocument()
    expect(screen.getByText('bulk_upload_data_created_date')).toBeInTheDocument()
    expect(screen.getByText('status')).toBeInTheDocument()

    mockData.forEach((data) => {
      expect(screen.getByText(data.emailSubject)).toBeInTheDocument()
      expect(screen.getByText(data.emailsSent.toString())).toBeInTheDocument()
      expect(screen.getByText(data.emailsNotSent === 0 ? '-' : data.emailsNotSent.toString())).toBeInTheDocument()
      expect(screen.getByText(data.jobID)).toBeInTheDocument()
      const datejobCreatedDateTime = new Date(data.jobCreatedDateTime)
      const formattedDate = `${datejobCreatedDateTime.getDate()} ${datejobCreatedDateTime.toLocaleString('en-GB', { month: 'short' })} ${datejobCreatedDateTime.getFullYear()} ${datejobCreatedDateTime.toTimeString().split(' ')[0]}`
      expect(screen.getByText(formattedDate)).toBeInTheDocument()
      expect(screen.getByText(data.jobCreatedBy)).toBeInTheDocument()
      const formateDate = datejobCreatedDateTime.toLocaleDateString('en-GB', {
        day: '2-digit',
        month: 'short',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit',
      })
      expect(screen.getByText(formateDate)).toBeInTheDocument()
      expect(screen.getByText(data.status)).toBeInTheDocument()
    })

    expect(mockHandleEdit).not.toHaveBeenCalled()
  })
})

describe('payrollHistory', () => {
  const mockHandleCheckboxChange = jest.fn()
  const mockSelectedPayrollCodes = ['001', '002']

  const tableConfig = tableOptions.payrollHistory(
    mockHandleEdit,
    mockHandleCheckboxChange,
    mockSelectedPayrollCodes,
  )

  const mockData = [
    {
      id: '001',
      employeeCode: 'E001',
      employeeName: 'John Doe',
      payItemCode: 'Salary',
      payCycleYear: '2021',
      payCycleMonth: 'Jan',
      payCycleCode: 'Q1',
    },
    {
      id: '002',
      employeeCode: 'E002',
      employeeName: 'Jane Smith',
      payItemCode: 'Bonus',
      payCycleYear: '2022',
      payCycleMonth: 'Feb',
      payCycleCode: 'Q2',
    },
    {
      id: '003',
      employeeCode: 'E003',
      employeeName: 'Bob Johnson',
      payItemCode: 'Overtime',
      payCycleYear: '2023',
      payCycleMonth: 'Mar',
      payCycleCode: 'Q3',
    },
  ]

  test('renders correct table', () => {
    renderTable({ tableConfig, mockData })

    expect(screen.getByText('Employee name | Employee ID')).toBeInTheDocument()
    expect(screen.getByText('Pay item')).toBeInTheDocument()
    expect(screen.getByText('Pay cycle')).toBeInTheDocument()

    mockData.forEach((data) => {
      expect(screen.getByText(data.employeeCode)).toBeInTheDocument()
      expect(screen.getByText(data.employeeName)).toBeInTheDocument()
      expect(screen.getByText(data.payItemCode)).toBeInTheDocument()
      expect(screen.getByText(`${data.payCycleYear}-${data.payCycleMonth} (${data.payCycleCode})`)).toBeInTheDocument()
    })

    expect(screen.getAllByRole('checkbox')).toHaveLength(3)
    const checkbox1 = screen.getAllByRole('checkbox')[0]
    const checkbox2 = screen.getAllByRole('checkbox')[1]
    const checkbox3 = screen.getAllByRole('checkbox')[2]

    expect(checkbox1).toBeChecked()
    expect(checkbox2).toBeChecked()
    expect(checkbox3).not.toBeChecked()

    fireEvent.click(checkbox1)
    expect(mockHandleCheckboxChange).toBeCalled()
  })
})

describe('logPayrollHistory', () => {
  const tableConfig = tableOptions.logPayrollHistory(mockHandleEdit)

  const mockData = [
    {
      jobId: 'JOB001',
      createdAt: '2023-04-01 10:30 AM',
      completedDate: '2023-04-02 11:45 AM',
      status: true,
      logFile: 'payroll_log_001.txt',
    },
    {
      jobId: 'JOB002',
      createdAt: '2023-04-05 2:15 PM',
      completedDate: '2023-04-06 4:30 PM',
      status: false,
      logFile: 'payroll_log_002.txt',
    },
  ]

  test('renders correct table', () => {
    renderTable({ tableConfig, mockData })

    expect(screen.getByText('Job ID | Job created date & by')).toBeInTheDocument()
    expect(screen.getByText('Completed date')).toBeInTheDocument()
    expect(screen.getByText('status')).toBeInTheDocument()
    expect(screen.getByText('File')).toBeInTheDocument()

    mockData.forEach((data) => {
      expect(screen.getByText(data.jobId)).toBeInTheDocument()
      expect(screen.getByText(data.createdAt)).toBeInTheDocument()
      expect(screen.getByText(data.completedDate)).toBeInTheDocument()
      expect(screen.getByText(data.logFile)).toBeInTheDocument()

      const statusLabel = screen.getByText(data.status ? 'Successful' : 'Failed')
      expect(statusLabel).toBeInTheDocument()
      expect(statusLabel).toHaveStyle({
        background: data.status ? '#EBFFF0' : '#E8E6E7',
        color: data.status ? '#00701C' : '#3B3839',
      })
    })
  })
})

describe('payrollNoRecurringSearch', () => {
  const mockSelectedEntity = ['employee1', 'employee2']
  const mockHandleCheckboxChange = jest.fn()

  const tableConfig = tableOptions.payrollNoRecurringSearch(mockHandleEdit, mockSelectedEntity, mockHandleCheckboxChange)

  const mockData = [
    {
      id: 'employee1',
      employeeName: 'John Doe',
      employeeCode: 'EMP001',
      payItemName: 'Salary',
      payItemCode: 'SALARY',
      payType: 'Regular',
      quantity: 20,
      ratePerUnit: 50.0,
      originalCurrency: 'USD',
      transactionAmount: 1000.0,
      creationDate: '2023-04-01T10:30:00Z',
    },
    {
      id: 'employee2',
      employeeName: 'Jane Smith',
      employeeCode: 'EMP002',
      payItemName: 'Overtime',
      payItemCode: 'OT',
      payType: 'Overtime',
      quantity: 10,
      ratePerUnit: null,
      originalCurrency: 'HKD',
      transactionAmount: 750.0,
      creationDate: '2023-04-05T14:15:00Z',
    },
    {
      id: 'employee3',
      employeeName: 'Bobby Tom',
      employeeCode: 'EMP003',
      payItemName: 'Pay Item Name',
      payItemCode: 'PIN',
      payType: 'pay item name',
      quantity: 30,
      ratePerUnit: undefined,
      originalCurrency: 'SGD',
      transactionAmount: 550.0,
      creationDate: '2022-04-05T14:15:00Z',
    },
  ]

  test('renders correct table', () => {
    renderTable({ tableConfig, mockData })

    expect(screen.getByText('Employee')).toBeInTheDocument()
    expect(screen.getByText('Pay Item')).toBeInTheDocument()
    expect(screen.getByText(`${t('Quantity')} | ${t('Rate per unit')}`)).toBeInTheDocument()
    expect(screen.getByText('Amount')).toBeInTheDocument()
    expect(screen.getByText('Creation date')).toBeInTheDocument()

    mockData.forEach((data) => {
      expect(screen.getByText(data.employeeName)).toBeInTheDocument()
      expect(screen.getByText(data.employeeCode)).toBeInTheDocument()
      expect(screen.getByText(data.payItemName)).toBeInTheDocument()
      expect(screen.getByText(`${data.payItemCode} (${data.payType})`)).toBeInTheDocument()
      expect(screen.getByText(`${data.quantity} (Day)`)).toBeInTheDocument()
      if (data.ratePerUnit) {
        expect(screen.getByText(data.ratePerUnit)).toBeInTheDocument()
      }
      expect(screen.getByText(data.originalCurrency)).toBeInTheDocument()
      expect(screen.getByText(data.transactionAmount)).toBeInTheDocument()
      const creationDate = new Date(data.creationDate)
      const formattedDate = `${creationDate.getDate()} ${creationDate.toLocaleString('en', { month: 'short' })} ${creationDate.getFullYear()} ${creationDate.getHours()}:${creationDate.getMinutes()}:${creationDate.getSeconds()}`
      expect(screen.getByText(formattedDate)).toBeInTheDocument()
    })

    expect(screen.getAllByRole('checkbox')).toHaveLength(3)
    const checkbox1 = screen.getAllByRole('checkbox')[0]
    const checkbox2 = screen.getAllByRole('checkbox')[1]
    const checkbox3 = screen.getAllByRole('checkbox')[2]
    expect(checkbox1).toBeChecked()
    expect(checkbox2).toBeChecked()
    expect(checkbox3).not.toBeChecked()

    fireEvent.click(checkbox1)
    expect(mockHandleCheckboxChange).toBeCalled()
  })
})

describe('logsPayRollNonRecurring', () => {
  const tableConfig = tableOptions.logsPayRollNonRecurring(mockHandleEdit)

  const mockData = [
    {
      jobID: 'JOB-001',
      jobCreatedDateTime: '2023-08-01T10:30:00Z',
      createdBy: 'John Doe',
      status: 'Success',
    },
    {
      jobID: 'JOB-002',
      jobCreatedDateTime: '2023-08-05T14:45:00Z',
      createdBy: 'Jane Smith',
      status: 'Failed',
    },
    {
      jobID: 'JOB-003',
      jobCreatedDateTime: '2023-08-10T09:15:00Z',
      createdBy: 'Michael Johnson',
      status: 'Pending',
    },
    {
      jobID: 'JOB-004',
      jobCreatedDateTime: '2023-08-15T16:20:00Z',
      createdBy: 'Sarah Lee',
      status: 'Completed',
    },
    {
      jobID: 'JOB-005',
      jobCreatedDateTime: '2023-08-20T11:50:00Z',
      createdBy: 'David Chen',
      status: 'Delete',
    },
    {
      jobID: 'JOB-006',
      jobCreatedDateTime: '2021-08-20T11:50:00Z',
      createdBy: 'Zhongli',
      status: 'Finalized',
    },
    {
      jobID: 'JOB-007',
      jobCreatedDateTime: '2022-08-20T11:50:00Z',
      createdBy: 'Pyro',
      status: 'default',
    },
  ]

  test('renders correct table', () => {
    renderTable({ tableConfig, mockData })

    expect(screen.getByText('Job ID | Job created date & by')).toBeInTheDocument()
    expect(screen.getByText('Completed date')).toBeInTheDocument()
    expect(screen.getByText('Status')).toBeInTheDocument()

    expect(screen.getAllByText('by')).toHaveLength(7)

    mockData.forEach((data) => {
      const jobCreatedDate = new Date(data?.jobCreatedDateTime)
      const formattedDate = jobCreatedDate.toLocaleString('default', {
        day: '2-digit',
        month: 'short',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit',
        hour12: false,
      })
      expect(screen.getByText(`${data.jobID}`)).toBeInTheDocument()
      expect(screen.getAllByText(formattedDate)).toHaveLength(2)
      expect(screen.getByText(`${data.createdBy}`)).toBeInTheDocument()

      if (data.status === 'Completed') {
        expect(screen.getByText('Completed')).toBeInTheDocument()
        expect(screen.getByText('Completed')).toHaveStyle('color: #00701C; background: #EBFFF0')
      } else if (data.status === 'Delete') {
        expect(screen.getByText('Successful')).toBeInTheDocument()
        expect(screen.getByText('Successful')).toHaveStyle('color: #00701C; background: #EBFFF0')
      } else if (data.status === 'Pending') {
        expect(screen.getByText('Pending')).toBeInTheDocument()
        expect(screen.getByText('Pending')).toHaveStyle('color: #0000FF; background: #EAF0FF')
      } else if (data.status === 'Failed') {
        expect(screen.getByText('Failed')).toBeInTheDocument()
        expect(screen.getByText('Failed')).toHaveStyle('color: #FF0000; background: #FFEAEA')
      } else if (data.status === 'Success') {
        expect(screen.getByText('Success')).toBeInTheDocument()
      } else if (data.status === 'Finalized') {
        expect(screen.getByText('Finalized')).toBeInTheDocument()
      } else {
        expect(screen.getByText('default')).toBeInTheDocument()
        expect(screen.getByText('default')).toHaveStyle('color: #3B3839; background: #EBEBEB')
      }
    })
  })
})

describe('publishReportColumn', () => {
  const tableConfig = tableOptions.publishReportColumn(mockHandleEdit)

  const mockData = [
    {
      generationReferenceNo: 'GEN001',
      jobID: 'JOB001',
      createdAt: '2023-07-01T12:00:00.000Z',
      createdByName: 'John Doe',
      createdByEmail: 'john.doe@example.com',
      completedDateTime: '2023-07-01T15:00:00.000Z',
      jobStatus: 'Success',
      status: 'Success',
      logFileUrl: 'https://example.com/logfile.txt',
      jobs: [
        {
          generationReferenceNo: 'GEN001',
          jobID: 'JOB001',
        },
      ],
    },
    {
      generationReferenceNo: 'GEN002',
      jobID: 'JOB002',
      createdAt: '2023-07-02T09:30:00.000Z',
      createdByName: 'Jane Smith',
      createdByEmail: 'jane.smith@example.com',
      completedDateTime: '2023-07-02T12:00:00.000Z',
      jobStatus: 'Failed',
      status: 'Failed',
      logFileUrl: 'https://example.com/logfile2.txt',
      jobs: [
        {
          generationReferenceNo: 'GEN002',
          jobID: 'JOB002',
        },
      ],
    },
    {
      generationReferenceNo: 'GEN003',
      jobID: 'JOB003',
      createdAt: '2023-07-03T14:15:00.000Z',
      createdByName: 'Bob Johnson',
      createdByEmail: 'bob.johnson@example.com',
      completedDateTime: null,
      jobStatus: 'Pending',
      status: 'Pending',
      logFileUrl: null,
      jobs: [
        {
          generationReferenceNo: 'GEN003',
          jobID: 'JOB003',
        },
      ],
    },
  ]

  test('renders correct table columns', () => {
    renderTable({ tableConfig, mockData })

    expect(screen.getByText('Generation Reference')).toBeInTheDocument()
    expect(screen.getByText('Job ID | Job created date & by')).toBeInTheDocument()
    expect(screen.getByText('Completed date')).toBeInTheDocument()
    expect(screen.getByText('Status')).toBeInTheDocument()
    expect(screen.getByText('bulk_upload_data_file_name')).toBeInTheDocument()
    mockData.forEach((data) => {
      expect(screen.getByText(data.generationReferenceNo)).toBeInTheDocument()
      expect(screen.getByText(data.jobID)).toBeInTheDocument()
      expect(screen.getByText(`${displayFormatDateTime(data.createdAt)} by ${data.createdByName} (${data.createdByEmail})`)).toBeInTheDocument()
      expect(screen.getByText(data.completedDateTime ? displayFormatDateTime(data.completedDateTime) : '-')).toBeInTheDocument()
      const statusLabel = screen.getByText(data.status)
      expect(statusLabel).toBeInTheDocument()
      if (data.jobStatus === 'Success') {
        expect(statusLabel).toHaveStyle('color: #00701C; background: #EBFFF0;')
      } else if (data.jobStatus === 'Failed') {
        expect(statusLabel).toHaveStyle('color: #DA3237;')
      } else {
        expect(statusLabel).toHaveStyle('color: #3B3839; background: #E8E6E7;')
      }
    })

    expect(screen.getAllByText('Button')).toHaveLength(2)

    const button1 = screen.getAllByText('Button')[0]
    fireEvent.click(button1)
    expect(mockHandleEdit).toBeCalled()
  })
})

describe('reportDocuTaxProColumn', () => {
  const mockHandler = jest.fn()
  const tableConfig = tableOptions.reportDocuTaxProColumn(mockHandler)

  const mockData = [
    {
      generationReferenceNo: 'GEN001',
      jobId: 'JOB001',
      createdAt: '2023-07-01T12:00:00.000Z',
      createdByName: 'John Doe',
      createdByEmail: 'john.doe@example.com',
      completedDateTime: '2023-07-01T15:00:00.000Z',
      publishTime: '2024-07-01T15:00:00.000Z',
      jobStatus: 'Success',
      logFileUrl: 'https://example.com/logfile.txt',
      generationReference:
        {
          referenceNumber: 'GEN001v',
          jobID: 'JOB001v',
        },
    },
    {
      generationReferenceNo: 'GEN002',
      jobId: 'JOB002',
      createdAt: '2023-07-02T09:30:00.000Z',
      createdByName: 'Jane Smith',
      createdByEmail: 'jane.smith@example.com',
      completedDateTime: '2023-07-02T12:00:00.000Z',
      publishTime: '2024-07-02T12:00:00.000Z',
      jobStatus: 'Failed',
      logFileUrl: 'https://example.com/logfile2.txt',
      generationReference:
        {
          referenceNumber: 'GEN002v',
          jobID: 'JOB002v',
        },
    },
    {
      generationReferenceNo: 'GEN003',
      jobId: 'JOB003',
      createdAt: '2023-07-03T14:15:00.000Z',
      createdByName: 'Bob Johnson',
      createdByEmail: 'bob.johnson@example.com',
      completedDateTime: null,
      publishTime: '2025-07-02T12:00:00.000Z',
      jobStatus: 'Pending',
      logFileUrl: null,
      jobs: [
        {
          generationReferenceNo: 'GEN003v',
          jobID: 'JOB003v',
        },
      ],
    },
  ]

  test('renders correct table', () => {
    renderTable({ tableConfig, mockData })

    expect(screen.getByText('Generation references')).toBeInTheDocument()
    expect(screen.getByText('Job ID | Job created date & by')).toBeInTheDocument()
    expect(screen.getByText('Completed date')).toBeInTheDocument()
    expect(screen.getByText('Status')).toBeInTheDocument()
    expect(screen.getByText('bulk_upload_data_file_name')).toBeInTheDocument()

    mockData.forEach((data) => {
      expect(screen.getByText(data?.generationReference?.referenceNumber ? data?.generationReference?.referenceNumber : '-')).toBeInTheDocument()
      expect(screen.getByText(data.jobId)).toBeInTheDocument()
      expect(screen.getByText(`${displayFormatDateTime(data.createdAt)} by ${data.createdByName} (${data.createdByEmail})`)).toBeInTheDocument()
      expect(screen.getByText(data.publishTime ? displayFormatDateTime(data.publishTime) : '-')).toBeInTheDocument()

      const statusLabel = screen.getByText(data.jobStatus)
      expect(statusLabel).toBeInTheDocument()
      if (data.jobStatus === 'Success') {
        expect(statusLabel).toHaveStyle('color: #00701C; background: #EBFFF0;')
      } else if (data.jobStatus === 'Failed') {
        expect(statusLabel).toHaveStyle('color: #DA3237;')
      } else {
        expect(statusLabel).toHaveStyle('color: #3B3839; background: #E8E6E7;')
      }
    })
    expect(screen.getAllByText('Button')).toHaveLength(1)
    const button = screen.getAllByText('Button')[0]
    fireEvent.click(button)
    expect(mockHandler).toBeCalled()
  })

  test('renders correct table when publishTime is null', () => {
    const mockData = [
      {
        generationReferenceNo: 'GEN003',
        jobId: 'JOB003',
        createdAt: '2023-07-03T14:15:00.000Z',
        createdByName: 'Bob Johnson',
        createdByEmail: 'bob.johnson@example.com',
        completedDateTime: null,
        publishTime: null,
        jobStatus: 'Pending',
        logFileUrl: null,
        generationReference:
        {
          referenceNumber: 'GEN002v',
          jobID: 'JOB002v',
        },
      },
    ]
    renderTable({ tableConfig, mockData })

    mockData.forEach((data) => {
      expect(screen.getByText(data?.generationReference?.referenceNumber ? data?.generationReference?.referenceNumber : '-')).toBeInTheDocument()
      expect(screen.getByText(data.jobId)).toBeInTheDocument()
      expect(screen.getByText(`${displayFormatDateTime(data.createdAt)} by ${data.createdByName} (${data.createdByEmail})`)).toBeInTheDocument()
      expect(screen.getByText(data.publishTime ? displayFormatDateTime(data.publishTime) : '-')).toBeInTheDocument()
    })
  })
})

describe('monthEndClosingLogs', () => {
  const tableConfig = tableOptions.monthEndClosingLogs(mockHandleEdit)

  const mockData = [
    {
      jobID: 'JOB001',
      createdAt: '2023-07-01T12:00:00.000Z',
      jobCreatedDateTime: '2023-07-02T12:00:00.000Z',
      status: 'Success',
      logFile: 'https://example.com/logfile.txt',
    },
    {
      jobID: 'JOB002',
      createdAt: '2023-07-05T14:15:00.000Z',
      jobCreatedDateTime: '2023-07-06T14:15:00.000Z',
      status: 'Finalized',
      logFile: 'https://example.com/logfile2.txt',
    },
    {
      jobID: 'JOB003',
      createdAt: '2023-07-10T09:30:00.000Z',
      jobCreatedDateTime: '2023-07-11T09:30:00.000Z',
      status: 'Completed',
      logFile: 'https://example.com/logfile3.txt',
    },
    {
      jobID: 'JOB004',
      createdAt: '2023-07-15T16:20:00.000Z',
      jobCreatedDateTime: '2023-07-16T16:20:00.000Z',
      status: 'Failed',
      logFile: 'https://example.com/logfile4.txt',
    },
    {
      jobID: 'JOB005',
      createdAt: '2023-07-20T11:50:00.000Z',
      jobCreatedDateTime: '2023-07-21T11:50:00.000Z',
      status: 'Pending',
      logFile: 'https://example.com/logfile5.txt',
    },
    {
      jobID: 'JOB006',
      createdAt: '2023-07-25T11:50:00.000Z',
      jobCreatedDateTime: '2023-07-26T11:50:00.000Z',
      status: 'unknown',
      logFile: 'https://example.com/logfile6.txt',
    },
  ]

  test('renders correct table', () => {
    renderTable({ tableConfig, mockData })

    expect(screen.getByText('Job ID | Job created date & by')).toBeInTheDocument()
    expect(screen.getByText('Completed date')).toBeInTheDocument()
    expect(screen.getByText('Status')).toBeInTheDocument()
    expect(screen.getByText('File')).toBeInTheDocument()

    mockData.forEach((data) => {
      expect(screen.getByText(data.jobID)).toBeInTheDocument()
      expect(screen.getByText(data.createdAt)).toBeInTheDocument()
      expect(screen.getByText(data.jobCreatedDateTime)).toBeInTheDocument()
      expect(screen.getByText(data.status)).toBeInTheDocument()
      expect(screen.getByText(data.logFile)).toBeInTheDocument()

      const statusLabel = screen.getByText(data.status)
      expect(statusLabel).toBeInTheDocument()
      if (data.status === 'Completed') {
        expect(statusLabel).toHaveStyle('color: #00701C; background: #EBFFF0')
      } else if (data.status === 'Failed') {
        expect(statusLabel).toHaveStyle('color: #FF0000; background: #FFEAEA')
      } else if (data.status === 'Pending') {
        expect(statusLabel).toHaveStyle('color: #0000FF; background: #EAF0FF')
      } else if (data.status !== 'Success' && data.status !== 'Finalized') {
        expect(statusLabel).toHaveStyle('color: #3B3839; background: #EBEBEB')
      }
    })
  })
})

describe('generationRefColumn', () => {
  const tableConfig = tableOptions.generationRefColumn(mockHandleEdit)

  const mockData = [
    {
      referenceNumber: 'REF001',
      publishTime: '2023-07-01T12:00:00.000Z',
      publishStatus: 'Ready',
    },
    {
      referenceNumber: 'REF002',
      publishTime: '2023-07-05T14:15:00.000Z',
      publishStatus: 'Partially Published',
    },
    {
      referenceNumber: 'REF003',
      publishTime: '2023-07-10T09:30:00.000Z',
      publishStatus: 'Published',
    },
    {
      referenceNumber: 'REF004',
      publishTime: null,
      publishStatus: 'unknown',
    },
  ]

  test('renders correct table', () => {
    renderTable({ tableConfig, mockData })

    expect(screen.getByText('ent_reports_generation_ref')).toBeInTheDocument()
    expect(screen.getByText('ent_reports_generation_date')).toBeInTheDocument()
    expect(screen.getByText('status')).toBeInTheDocument()

    mockData.forEach((data) => {
      expect(screen.getByText(data.referenceNumber)).toBeInTheDocument()
      expect(screen.getByText(data?.publishTime ? displayFormatDateTime(data?.publishTime) : '-')).toBeInTheDocument()
      expect(screen.getByText(data.publishStatus)).toBeInTheDocument()
      const statusLabel = screen.getByText(data.publishStatus)
      if (data.publishStatus === 'Ready') {
        expect(statusLabel).toHaveStyle('color: #3B3839; background: #E8E6E7')
      } else if (data.publishStatus === 'Partially Published') {
        expect(statusLabel).toHaveStyle('color: #3B3839; background: #E8E6E7')
      } else if (data.publishStatus === 'Published') {
        expect(statusLabel).toHaveStyle('color: #00701C; background: #EBFFF0')
      } else {
        expect(statusLabel).toHaveStyle('color: #DA3237; background: #FEF5F8')
      }
    })
  })
})

describe('reportViewColumn', () => {
  const tableConfig = tableOptions.reportViewColumn(mockHandleEdit)

  const mockData = [
    {
      fileName: 'report_001.pdf',
      publishStatus: 'Ready',
      publishTime: '2023-07-01T12:00:00.000Z',
      releaseDate: '2023-07-02T12:00:00.000Z',
      remarks: 'Remarks 1',
      downloadStatus: 'download status 1',
    },
    {
      fileName: 'report_002.pdf',
      publishStatus: 'Partially Published',
      publishTime: '2023-07-05T14:15:00.000Z',
      releaseDate: '2023-07-06T14:15:00.000Z',
      remarks: 'Remarks 2',
      downloadStatus: 'download status 2',
    },
    {
      fileName: 'report_003.pdf',
      publishStatus: 'Published',
      publishTime: '2023-07-10T09:30:00.000Z',
      releaseDate: '2023-07-11T09:30:00.000Z',
      remarks: 'Remarks 3',
      downloadStatus: 'download status 3',
    },
    {
      fileName: 'report_004.pdf',
      publishStatus: 'unknown',
      publishTime: '2023-07-15T16:20:00.000Z',
      releaseDate: '2023-07-16T16:20:00.000Z',
      remarks: 'Remarks 4',
      downloadStatus: 'download status 4',
    },
  ]

  test('renders correct table', () => {
    renderTable({ tableConfig, mockData })

    expect(screen.getByText('bulk_upload_data_first_name')).toBeInTheDocument()
    expect(screen.getByText('publish_status')).toBeInTheDocument()
    expect(screen.getByText('publish_id_date')).toBeInTheDocument()
    expect(screen.getByText('release_date')).toBeInTheDocument()
    expect(screen.getByText('file_remarks')).toBeInTheDocument()
    expect(screen.getByText('download_status')).toBeInTheDocument()

    mockData.forEach((data) => {
      expect(screen.getByText(data.fileName)).toBeInTheDocument()
      expect(screen.getByText(data.publishStatus)).toBeInTheDocument()
      expect(screen.getByText(data.publishTime)).toBeInTheDocument()
      expect(screen.getByText(data.releaseDate)).toBeInTheDocument()
      expect(screen.getByText(data.remarks)).toBeInTheDocument()
      expect(screen.getByText(data.downloadStatus)).toBeInTheDocument()

      const statusLabel = screen.getByText(data.publishStatus)
      if (data.publishStatus === 'Ready') {
        expect(statusLabel).toHaveStyle('color: #3B3839; background: #E8E6E7')
      } else if (data.publishStatus === 'Partially Published') {
        expect(statusLabel).toHaveStyle('color: #3B3839; background: #E8E6E7')
      } else if (data.publishStatus === 'Published') {
        expect(statusLabel).toHaveStyle('color: #00701C; background: #EBFFF0')
      } else {
        expect(statusLabel).toHaveStyle('color: #DA3237; background: #FEF5F8')
      }
    })
  })
})

describe('reportViewEditColumn', () => {
  const viewAcoount = jest.fn()
  const additionalData = {
    releaseDate: '2022-07-01T12:00:00.000Z',
    remarks: 'Remarks additional data',
  }
  const tableConfig = tableOptions.reportViewEditColumn(viewAcoount, additionalData)

  const mockData = [
    {
      fileName: 'report_001.pdf',
      releaseDate: '2023-07-01T12:00:00.000Z',
      remarks: 'Remarks 1',
      downloadStatus: 'download status 1',
    },
    {
      fileName: 'report_002.pdf',
      releaseDate: null,
      remarks: null,
      downloadStatus: 'download status 2',
    },
  ]

  test('renders correct table', () => {
    renderTable({ tableConfig, mockData })

    expect(screen.getByText('bulk_upload_data_first_name')).toBeInTheDocument()
    expect(screen.getByText('release_date')).toBeInTheDocument()
    expect(screen.getByText('file_remarks')).toBeInTheDocument()
    expect(screen.getByText('download_status')).toBeInTheDocument()
    expect(screen.getByText('action')).toBeInTheDocument()

    mockData.forEach((data) => {
      expect(screen.getByText(data.fileName)).toBeInTheDocument()
      expect(screen.getByText(data.releaseDate || additionalData.releaseDate)).toBeInTheDocument()
      expect(screen.getByText(data.remarks || additionalData.remarks)).toBeInTheDocument()
      expect(screen.getByText(data.downloadStatus)).toBeInTheDocument()
    })

    const dropDownButtons = screen.getAllByLabelText('more')
    fireEvent.click(dropDownButtons[0])
    expect(screen.getByText('Edit report file')).toBeInTheDocument()
  })
})

describe('selectFileColumn', () => {
  const tableConfig = tableOptions.selectFileColumn(mockHandleEdit)

  const mockData = [
    {
      fileName: 'file_001.pdf',
    },
  ]

  test('renders correct table', () => {
    renderTable({ tableConfig, mockData })

    mockData.forEach((data) => {
      expect(screen.getByText(data.fileName)).toBeInTheDocument()
    })
  })
})

describe('ACRFileColumn', () => {
  const tableConfig = tableOptions.ACRFileColumn(mockHandleEdit)

  const mockData = [
    {
      fileName: 'file_001.pdf',
    },
  ]

  test('renders correct table', () => {
    renderTable({ tableConfig, mockData })

    mockData.forEach((data) => {
      expect(screen.getByText(data.fileName)).toBeInTheDocument()
    })
  })
})

describe('reviewReport', () => {
  const tableConfig = tableOptions.reviewReport(mockHandleEdit)

  const mockData = [
    {
      batchJob: {
        reportType: {
          name: 'Report 1',
          code: 'RPT001',
        },
      },
      fileName: 'fileName1/file_001.pdf',
      id: '001',
    },
    {
      batchJob: {
        reportType: {
          name: 'Report 2',
          code: null,
        },
      },
      fileName: 'fileName2/file_002.pdf',
      id: '002',
    },
  ]

  const mockData2 = [
    {
      batchJob: {
        reportType: {
          name: null,
          code: 'RPT001',
        },
      },
      fileName: 'fileName1/file_001.pdf',
      id: '001',
    },
    {
      batchJob: {
        reportType: {
          name: 'Report 2',
          code: 'RPT002',
        },
      },
      fileName: 'fileName2/file_002.pdf',
      id: '002',
    },
  ]

  test('renders correct table', () => {
    renderTable({ tableConfig, mockData })

    expect(screen.getByText('Report type')).toBeInTheDocument()
    expect(screen.getByText('Report code')).toBeInTheDocument()
    expect(screen.getByText('File name')).toBeInTheDocument()
    expect(screen.getByText('action')).toBeInTheDocument()

    mockData.forEach((data) => {
      expect(screen.getByText(data.batchJob.reportType.name)).toBeInTheDocument()
      expect(screen.getByText(data.batchJob.reportType.code || '-')).toBeInTheDocument()
      const fileName = data.fileName?.split('/').pop()
      expect(screen.getByText(fileName || data.fileName)).toBeInTheDocument()
    })

    const dropDownButtons = screen.getAllByLabelText('more')
    fireEvent.click(dropDownButtons[0])
    expect(screen.getByText('Export file')).toBeInTheDocument()

    const option = screen.getByText('Export file')
    fireEvent.click(option)
    expect(mockHandleEdit).toBeCalled()
  })

  test('renders correct table when reportType.name is null', () => {
    renderTable({ tableConfig, mockData: mockData2 })

    mockData2.forEach((data) => {
      expect(screen.getByText(data.batchJob.reportType.name || '-')).toBeInTheDocument()
      expect(screen.getByText(data.batchJob.reportType.code)).toBeInTheDocument()
      const fileName = data.fileName?.split('/').pop()
      expect(screen.getByText(fileName || data.fileName)).toBeInTheDocument()
    })
  })
})

describe('reviewReportLogs', () => {
  const tableConfig = tableOptions.reviewReportLogs(mockHandleEdit)

  const mockData = [
    {
      generationReference: {
        referenceNumber: 'GEN001',
      },
      createdAt: '2023-07-01T12:00:00.000Z',
      jobId: 'JOB001',
      createdByName: 'John Doe',
      createdByEmail: 'johndoe@example.com',
      updatedAt: '2023-07-02T15:00:00.000Z',
      jobStatus: 'Success',
    },
    {
      generationReference: {
        referenceNumber: 'GEN002',
      },
      createdAt: '2023-07-05T14:15:00.000Z',
      jobId: 'JOB002',
      createdByName: 'Jane Smith',
      createdByEmail: 'janesmith@example.com',
      updatedAt: '2023-07-06T17:00:00.000Z',
      jobStatus: 'Failed',
    },
    {
      generationReference: {
        referenceNumber: 'GEN003',
      },
      createdAt: '2023-07-10T09:30:00.000Z',
      jobId: 'JOB003',
      createdByName: 'Bob Johnson',
      createdByEmail: 'bobjohnson@example.com',
      updatedAt: '2023-07-11T18:00:00.000Z',
      jobStatus: 'Pending',
    },
  ]

  test('renders correct table', () => {
    renderTable({ tableConfig, mockData })

    expect(screen.getByText('Generation references')).toBeInTheDocument()
    expect(screen.getByText('Job ID | Job created date & by')).toBeInTheDocument()
    expect(screen.getByText('Completed date')).toBeInTheDocument()
    expect(screen.getByText('Status')).toBeInTheDocument()

    mockData.forEach((data) => {
      expect(screen.getByText(data.generationReference.referenceNumber)).toBeInTheDocument()
      expect(screen.getByText(data.jobId)).toBeInTheDocument()

      const formattedDate = (date: any) => `${date.getDate()} ${date.toLocaleString('en', { month: 'short' })} ${date.getFullYear()} ${date.getHours().toString().padStart(2, '0')}:${date.getMinutes().toString().padStart(2, '0')}:${date.getSeconds().toString().padStart(2, '0')}`

      expect(screen.getByText(`${formattedDate(new Date(data.createdAt))} by ${data.createdByName} (${data.createdByEmail})`)).toBeInTheDocument()
      expect(screen.getByText(formattedDate(new Date(data.updatedAt)))).toBeInTheDocument()
      expect(screen.getByText(data.jobStatus)).toBeInTheDocument()
      const statusLabel = screen.getByText(data.jobStatus)
      if (data.jobStatus === 'Success') {
        expect(statusLabel).toHaveStyle('color: #00701C; background: #EBFFF0')
      } else if (data.jobStatus === 'Failed') {
        expect(statusLabel).toHaveStyle('color: #DA3237;')
      } else {
        expect(statusLabel).toHaveStyle('color: #3B3839; background: #E8E6E7')
      }
    })
  })
})

describe('emailTemplateColumn', () => {
  const tableConfig = tableOptions.emailTemplateColumn(mockHandleEdit)

  const mockData = [
    {
      emailTemplateName: 'Template 1',
      emailTemplateCode: 'T001',
      emailTemplateType: {
        code: 'TYPE001',
      },
    },
    {
      emailTemplateName: 'Template 2',
      emailTemplateCode: 'T002',
      emailTemplateType: {
        code: 'TYPE002',
      },
    },
  ]

  test('renders correct table', () => {
    renderTable({ tableConfig, mockData })

    expect(screen.getByText('Email template name | Email template code')).toBeInTheDocument()
    expect(screen.getByText('Type')).toBeInTheDocument()
    expect(screen.getByText('action')).toBeInTheDocument()

    mockData.forEach((data) => {
      expect(screen.getByText(data.emailTemplateName)).toBeInTheDocument()
      expect(screen.getByText(data.emailTemplateCode)).toBeInTheDocument()
      expect(screen.getByText(data.emailTemplateType.code)).toBeInTheDocument()
    })

    const dropDownButtons = screen.getAllByLabelText('more')
    fireEvent.click(dropDownButtons[0])
    expect(screen.getByText('Edit email template')).toBeInTheDocument()
    expect(screen.getByText('Delete email template')).toBeInTheDocument()
  })
})

describe('payrollNoRecurringSearch1', () => {
  const mockSelectedEntity = ['001']
  const mockHandleCheckboxChange = jest.fn()

  const tableConfig = tableOptions.payrollNoRecurringSearch1(
    mockHandleEdit,
    mockSelectedEntity,
    mockHandleCheckboxChange,
  )

  const mockData = [
    {
      id: '001',
      employeeCode: 'E001',
      employeeName: 'John Doe',
      payItemCode: 'Salary',
      payItemName: 'Basic Salary',
      payType: 'Monthly',
      quantity: 22,
      ratePerUnit: 2000,
      transactionAmount: 44000,
      originalCurrency: 'USD',
      coveringStartDate: '2023-01-01T00:00:00.000Z',
    },
    {
      id: '002',
      employeeCode: 'E002',
      employeeName: 'Jane Smith',
      payItemCode: 'Bonus',
      payItemName: 'Performance Bonus',
      payType: 'Yearly',
      quantity: 1,
      ratePerUnit: 5000,
      transactionAmount: 50000,
      originalCurrency: 'HKD',
      coveringStartDate: '2023-02-01T00:00:00.000Z',
    },
  ]

  const formatDate = (creationDate: any) => `${creationDate.getDate()} ${creationDate.toLocaleString('en', { month: 'short' })} ${creationDate.getFullYear()} ${creationDate.getHours()}:${creationDate.getMinutes()}:${creationDate.getSeconds()}`

  test('renders correct table', () => {
    renderTable({ tableConfig, mockData })

    expect(screen.getByText('Employee')).toBeInTheDocument()
    expect(screen.getByText('Pay Item')).toBeInTheDocument()
    expect(screen.getByText(`${t('Quantity')} | ${t('Rate per unit')}`)).toBeInTheDocument()
    expect(screen.getByText('Amount')).toBeInTheDocument()
    expect(screen.getByText('Creation date')).toBeInTheDocument()

    mockData.forEach((data) => {
      expect(screen.getByText(data.employeeCode)).toBeInTheDocument()
      expect(screen.getByText(data.employeeName)).toBeInTheDocument()
      expect(screen.getByText(data.payItemName)).toBeInTheDocument()
      expect(screen.getByText(`${data.payItemCode} (${data.payType})`)).toBeInTheDocument()
      expect(screen.getByText(`${data.quantity} (Day)`)).toBeInTheDocument()
      expect(screen.getByText(data.ratePerUnit)).toBeInTheDocument()
      expect(screen.getByText(data.originalCurrency)).toBeInTheDocument()
      expect(screen.getByText(data.transactionAmount)).toBeInTheDocument()
      expect(screen.getByText(formatDate(new Date(data.coveringStartDate)))).toBeInTheDocument()
    })

    expect(screen.getAllByRole('checkbox')).toHaveLength(2)
    const checkbox1 = screen.getAllByRole('checkbox')[0]
    const checkbox2 = screen.getAllByRole('checkbox')[1]

    expect(checkbox1).toBeChecked()
    expect(checkbox2).not.toBeChecked()
    fireEvent.click(checkbox1)
    expect(mockHandleCheckboxChange).toBeCalled()
  })
})

describe('payrollNoRecurringSearchColumn', () => {
  const tableConfig = tableOptions.payrollNoRecurringSearchColumn(mockHandleEdit)

  const mockData = [
    {
      id: '1234',
      employeeCode: 'EMP-001',
      employeeName: 'John Doe',
      payItemCode: 'PIS-001',
      payItemName: 'Overtime',
      payType: 'Hourly',
      quantity: 80,
      ratePerUnit: 50.0,
      transactionAmount: 4000.0,
      originalCurrency: 'USD',
      creationDate: '2023-06-01T10:30:00.000Z',
    },
    {
      id: '5678',
      employeeCode: 'EMP-002',
      employeeName: 'Jane Smith',
      payItemCode: 'PIS-002',
      payItemName: 'Bonus',
      payType: 'Flat',
      quantity: 1,
      ratePerUnit: null,
      transactionAmount: 1000.0,
      originalCurrency: 'HKD',
      creationDate: '2023-07-15T15:45:00.000Z',
    },
  ]

  test('renders correct table', () => {
    renderTable({ tableConfig, mockData })

    expect(screen.getByText('Employee')).toBeInTheDocument()
    expect(screen.getByText('Pay Item')).toBeInTheDocument()
    expect(screen.getByText(`${t('Quantity')} | ${t('Rate per unit')}`)).toBeInTheDocument()
    expect(screen.getByText('Amount')).toBeInTheDocument()
    expect(screen.getByText('Creation date')).toBeInTheDocument()

    mockData.forEach((data) => {
      expect(screen.getByText(data.employeeName)).toBeInTheDocument()
      expect(screen.getByText(data.employeeCode)).toBeInTheDocument()
      expect(screen.getByText(data.payItemName)).toBeInTheDocument()
      expect(screen.getByText(`${data.payItemCode} (${data.payType})`)).toBeInTheDocument()
      expect(screen.getByText(`${data.quantity} (Day)`)).toBeInTheDocument()
      if (data.ratePerUnit !== null && data.ratePerUnit !== undefined) {
        expect(screen.getByText(data.ratePerUnit)).toBeInTheDocument()
      }
      expect(screen.getByText(data.originalCurrency)).toBeInTheDocument()
      expect(screen.getByText(data.transactionAmount)).toBeInTheDocument()
      const creationDate = new Date(data.creationDate)
      const formattedDate = `${creationDate.getDate()} ${creationDate.toLocaleString('en', { month: 'short' })} ${creationDate.getFullYear()} ${creationDate.getHours()}:${creationDate.getMinutes()}:${creationDate.getSeconds()}`
      expect(screen.getByText(formattedDate)).toBeInTheDocument()
    })

    const dropdownButton = screen.getAllByTestId('MoreVertIcon')[0]
    fireEvent.click(dropdownButton)
    expect(screen.getByText('Edit Payroll Non-recurring')).toBeInTheDocument()
    expect(screen.getByText('Delete Payroll Non-recurring')).toBeInTheDocument()
  })
})

describe('entityCostCenterColumn', () => {
  const tableConfig = tableOptions.entityCostCenterColumn(mockHandleEdit)

  const mockData = [
    {
      costCenterDescription: 'Cost Center 1',
      costCenterCode: 'CC001',
    },
    {
      costCenterDescription: 'Cost Center 2',
      costCenterCode: 'CC002',
    },
  ]

  test('renders correct table', () => {
    renderTable({ tableConfig, mockData })

    expect(screen.getByText(`${t('cost_Center_Description')} | ${t('cost_Center_Code')}`)).toBeInTheDocument()

    mockData.forEach((data) => {
      expect(screen.getByText(data.costCenterDescription)).toBeInTheDocument()
      expect(screen.getByText(data.costCenterCode)).toBeInTheDocument()
    })

    const dropDownButtons = screen.getAllByLabelText('more')
    fireEvent.click(dropDownButtons[0])
    expect(screen.getByText('Edit cost center')).toBeInTheDocument()
    expect(screen.getByText('Delete cost center')).toBeInTheDocument()
  })
})
