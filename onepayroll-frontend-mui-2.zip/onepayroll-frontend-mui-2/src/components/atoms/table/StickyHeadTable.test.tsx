import '@testing-library/jest-dom/extend-expect'

import { createTheme, ThemeProvider } from '@mui/material/styles'
import { fireEvent, render, screen } from '@testing-library/react'

import StickyHeadTable from './index'

const theme = createTheme()

describe('StickyHeadTable Component', () => {
  it('renders the table with headers', () => {
    render(
      <ThemeProvider theme={theme}>
        <StickyHeadTable />
      </ThemeProvider>,
    )

    expect(screen.getByText('Name')).toBeInTheDocument()
    expect(screen.getByText('ISO Code')).toBeInTheDocument()
    expect(screen.getByText('Population')).toBeInTheDocument()
    expect(screen.getByText('Size (km²)')).toBeInTheDocument()
    expect(screen.getByText('Density')).toBeInTheDocument()
    const header = screen.getAllByRole('row')
    expect(header).toHaveLength(1)
  })

  it('renders the correct number of rows per page', () => {
    render(
      <ThemeProvider theme={theme}>
        <StickyHeadTable />
      </ThemeProvider>,
    )

    const rows = screen.getAllByRole('checkbox')
    expect(rows).toHaveLength(10)
  })

  it('changes page when pagination controls are used', () => {
    render(
      <ThemeProvider theme={theme}>
        <StickyHeadTable />
      </ThemeProvider>,
    )

    expect(screen.getByText('India')).toBeInTheDocument()
    expect(screen.queryByText('Brazil')).not.toBeInTheDocument()

    fireEvent.click(screen.getByLabelText('Go to next page'))

    expect(screen.queryByText('India')).not.toBeInTheDocument()
    expect(screen.getByText('Brazil')).toBeInTheDocument()
  })

  it('changes rows per page when the option is selected', () => {
    render(
      <ThemeProvider theme={theme}>
        <StickyHeadTable />
      </ThemeProvider>,
    )

    fireEvent.mouseDown(screen.getByLabelText('Rows per page:'))
    const options = screen.getAllByRole('option')
    const option = options.find((option) => option.textContent === '25')
    if (option) {
      fireEvent.click(option)
    }

    const rows = screen.getAllByRole('checkbox')
    expect(rows).toHaveLength(15)
  })

  it('resets page to 0 when rows per page changes', () => {
    render(
      <ThemeProvider theme={theme}>
        <StickyHeadTable />
      </ThemeProvider>,
    )

    fireEvent.click(screen.getByLabelText('Go to next page'))
    expect(screen.getByText('Brazil')).toBeInTheDocument()

    fireEvent.mouseDown(screen.getByLabelText('Rows per page:'))
    const options = screen.getAllByRole('option')
    const option = options.find((option) => option.textContent === '25')
    if (option) {
      fireEvent.click(option)
    }
    expect(screen.getByText('India')).toBeInTheDocument()

    const rows = screen.getAllByRole('checkbox')
    expect(rows).toHaveLength(15)
  })
})
