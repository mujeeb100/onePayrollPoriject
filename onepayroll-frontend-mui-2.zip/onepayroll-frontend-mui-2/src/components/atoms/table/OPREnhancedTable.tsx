import { Box, Checkbox, TableSortLabel } from '@mui/material'
import Paper from '@mui/material/Paper'
import Table from '@mui/material/Table'
import TableBody from '@mui/material/TableBody'
import TableCell from '@mui/material/TableCell'
import TableContainer from '@mui/material/TableContainer'
import TableHead from '@mui/material/TableHead'
import TableRow from '@mui/material/TableRow'
import { LeftCaretBlue, SerachBar } from 'assets/svg-images/SvgComponents'
import * as React from 'react'
import { useTranslation } from 'react-i18next'

import OPRButton from '../button/OPRButton'
import OPRLabel from '../label/OPRLabel'
import OPRMultiSelectCheckbox from '../multiSelectCheckbox'

function OPRUserSelection({ listOfOptions, item }:any) {
  const [selectedOptions, setSelectedOptions] = React.useState<any>([])
  item.userRole = selectedOptions

  const renderValue = (selected: any[]) => {
    if (selected.length === 0) {
      return (
        <span>
          <Box sx={{
            display: 'flex', flexDirection: 'row', gap: '5px', alignItems: 'center', padding: '0 5px',
          }}
          >
            <SerachBar />
            <OPRLabel data-testid="select-box" label="Select" variant="body2" />
          </Box>
        </span>
      )
    }
    return <span data-testid="roleName-selected">{selected[0].roleName}</span>
  }

  return (
    <OPRMultiSelectCheckbox
      listOfOptions={listOfOptions}
      renderValue={renderValue}
      selectedOptions={selectedOptions || []}
      setSelectedOptions={setSelectedOptions || (() => {})}
    />
  )
}
export default function OPREnhancedTable({
  cols,
  data,
  onRequestSort,
  orderBy,
  sortBy,
  steps,
  isLoader,
  isMovement = false,
  isDuplicate = false,
  isDeactivate = false,
  isReassignment = false,
  isSelected,
  handleClick,
  handleUserClick,
  listOfOptions,
  isEntity = false,
  newPayCycle,
}: any) {
  const { t } = useTranslation()
  const createSortHandler = (property: keyof any) => (event: React.MouseEvent<unknown>) => {
    onRequestSort(event, property)
  }
  const sortData = orderBy ? 'asc' : 'desc'

  return (
    <TableContainer component={Paper} sx={{ boxShadow: 'none', borderBottom: '1px solid #E8E6E7' }}>
      <Table aria-label="simple table">
        {(!isDuplicate || steps > 0) && (
          <TableHead sx={{ borderBottom: '1px solid #E8E6E7' }}>
            <TableRow>
              {cols?.map((headerItem: any, index: any) => (
                <TableCell sx={{ fontWeight: '700' }}>
                  {headerItem.sorting ? (
                    <TableSortLabel
                      active={sortBy === headerItem.key}
                      direction={sortBy === headerItem.key ? sortData : 'asc'}
                      onClick={createSortHandler(headerItem.key)}
                    >
                      {t(headerItem.title)}
                    </TableSortLabel>
                  ) : (
                    t(headerItem.title)
                  )}
                </TableCell>
              ))}
            </TableRow>
          </TableHead>
        )}
        {isLoader ? (
          <div
            style={{
              display: 'flex',
              flex: 1,
              justifyContent: 'center',
              alignItems: 'center',
              margin: 10,
            }}
          >
            Loading...
          </div>
        ) : (
          <TableBody>
            {data?.map((item: any, index: any) => {
              const isItemSelected = isSelected(item.id || item.employeeCode || item.fileName)
              const labelId = `enhanced-table-checkbox-${index}`
              return (
                <TableRow
                  key={item.name}
                  hover
                  role="checkbox"
                  sx={{ '&:last-child td, &:last-child th': { border: 0 }, borderBottom: '1px solid #E8E6E7' }}
                  tabIndex={-1}
                  onClick={(event) => (steps === 1 ? handleClick(event, item, index) : () => {})}
                >
                  {(isDuplicate && steps === 0) ? (
                    <Box
                      sx={{
                        display: 'flex', flexDirection: 'row', margin: '8px 0', cursor: 'pointer',
                      }}
                      onClick={() => {
                        handleUserClick(item)
                      }}
                    >
                      <Box sx={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
                        <OPRLabel label={item.username} />
                        <OPRLabel label={item.emailAddress} variant="body2" />
                      </Box>
                      <OPRButton
                        data-testid="user-button"
                        style={{ marginLeft: 'auto' }}
                        variant="text"
                        // onClick={() => {
                        //   handleUserClick(item)
                        // }}
                      >
                        <LeftCaretBlue />
                      </OPRButton>
                    </Box>
                  ) : (
                    <>
                      <TableCell
                        padding="checkbox"
                        sx={{ pl: '12px' }}
                      >
                        { (steps === 1) ? (
                          <Box sx={{ display: 'flex', flexDirection: 'row', alignItems: 'center' }}>
                            <Checkbox
                              checked={isItemSelected}
                              inputProps={{
                                'aria-labelledby': labelId,
                              }}
                            />
                            <span style={{ wordWrap: 'normal', whiteSpace: 'nowrap' }}>
                              <OPRLabel label={`${item.employeeGivenName || ''}`} />
                              {/* <br /> */}
                              <OPRLabel label={`${item.employeeCode || ''}`} />
                            </span>

                          </Box>
                        ) : (
                          <Box sx={{ display: 'flex', flexDirection: 'column', gap: '5px' }}>
                            <OPRLabel label={item?.entityName || item?.employeeCode || item?.employeeDetail?.employeeCode || item?.fileName} />
                            <OPRLabel label={item?.entityCode || item?.employeeGivenName || item?.employeeDetail?.employeeGivenName} variant="body2" />
                          </Box>
                        )}

                      </TableCell>
                      {!isReassignment
                                            && <TableCell align="left">{ item.entityName || item.employeeWorkEmailAddress || item.terminationDate || item.employeeDetail?.employeeWorkEmailAddress}</TableCell>}
                      {!isReassignment && isEntity
                                            && <TableCell align="left">{item.clientGroupName || item.employeeWorkEmailAddress || item.terminationDate || item.employeeDetail?.employeeWorkEmailAddress}</TableCell>}
                      <TableCell align="left">
                        {steps === 2 && (
                          <OPRUserSelection
                            item={item}
                            listOfOptions={listOfOptions}
                          />
                        )}
                        {steps === 3 && (
                          <OPRLabel label={item.userRole[0]?.roleName} />
                        )}
                        {(isDuplicate || isDeactivate) && (
                          <OPRLabel label={item.userRole} />
                        )}
                        {isMovement && <OPRLabel label={item.commencementDate || item.defaultMainCycleCode || item.fileName} />}
                        <OPRLabel label={item.defaultMainCycleCode} />
                      </TableCell>
                      {isMovement && (
                        <>
                          <TableCell align="left">
                            <OPRLabel label={item.lastEmploymentDate} />
                          </TableCell>
                          <TableCell align="left">{item.employeeStatus}</TableCell>
                        </>
                      )}
                      {isReassignment && (
                        <TableCell align="left">
                          <OPRLabel label={newPayCycle} />
                        </TableCell>
                      )}
                    </>
                  )}
                </TableRow>
              )
            })}
          </TableBody>
        )}
      </Table>
    </TableContainer>
  )
}
