// test cut off at line 2770 (inclusive of employeeProfileColumn)
import '@testing-library/jest-dom/extend-expect'

import { fireEvent, render, screen } from '@testing-library/react'
import { t } from 'i18next'
import { customDateFormate, formatedDate } from 'utils'

import { data as mockMockData } from './mockData'
import OPRTable from './OPRTable'
import * as tableOptions from './OPRTableConstant'

// jest.mock('constants/index', () => ({
//   displayFormatDateTime: () => '01 Jan 2000 00:00:00',
// }))

jest.mock('react-i18next', () => ({
  useTranslation: () => ({
    t: (key: any) => key,
  }),
}))

jest.mock('i18next', () => ({
  t: jest.fn((key) => key),
}))

// jest.mock('utils', () => ({
//   customDateFormate: () => '01 Feb 2000',
//   formatedDate: () => '01 Mar 2000 00:00:00',
// }))

jest.mock('../button/OPRButton', () => function OPRButtonMock({ onClick }: any) {
  return (
    <button data-testid="button" type="button" onClick={onClick}>
      Button
    </button>
  )
})

jest.mock('../checkbox/OPRCheckbox', () => function OPRCheckboxMock() {
  return (
    <div data-testid="checkbox">Checkbox</div>
  )
})

// jest.mock('../chip/OPRStatusChip', () => function OPRStatusChipMock() {
//   return (
//     <div data-testid="status-chip">Chip</div>
//   )
// })

jest.mock('../label/OPRLabel', () => function OPRLabelMock({ label, children, ...props }: any) {
  return (
    <div data-testid="label" style={props.CustomStyles}>{label || children}</div>
  )
})

const mockHandleEdit = jest.fn()
const mockHandleClick = jest.fn()

const renderTable = ({ tableConfig, mockData }: any) => render(
  <OPRTable cols={tableConfig} data={mockData} />,
)

beforeEach(() => {
  (t as unknown as jest.Mock).mockImplementation((key) => key)
})

afterEach(() => {
  jest.clearAllMocks()
})

describe('OPRTableConstant', () => {
  const mockData = mockMockData

  const tableConfig = tableOptions.OPRTableConstant(mockHandleEdit)

  test('renders correct table', () => {
    renderTable({ tableConfig, mockData })
    expect(screen.getByText('ID')).toBeInTheDocument()
    expect(screen.getByText('Name')).toBeInTheDocument()
    expect(screen.getByText('Username')).toBeInTheDocument()
    expect(screen.getByText('Email')).toBeInTheDocument()
    expect(screen.getByText('Action')).toBeInTheDocument()
    mockData.forEach((data) => {
      expect(screen.getByText(data.id)).toBeInTheDocument()
      expect(screen.getByText(data.name)).toBeInTheDocument()
      expect(screen.getByText(data.username)).toBeInTheDocument()
      expect(screen.getByText(data.email)).toBeInTheDocument()
    })
    const dropDown = screen.getAllByLabelText('more')[0]
    fireEvent.click(dropDown)
    expect(screen.getByText('Edit')).toBeInTheDocument()
    expect(screen.getByText('Delete')).toBeInTheDocument()
    expect(screen.getByText('View')).toBeInTheDocument()
    expect(screen.getByText('Add')).toBeInTheDocument()
  })
})

describe('payGroupMasterColumn', () => {
  const tableConfig = tableOptions.payGroupMasterColumn(mockHandleEdit)
  const mockData = [{
    payGroupCode: 'PG001',
    payGroupName: 'Pay Group 1',
    payCycleName: 'Monthly',
    status: {
      label: 'Active',
      value: 'active',
    },
  },
  {
    payGroupCode: 'PG002',
    payGroupName: 'Pay Group 2',
    payCycleName: 'Bi-Weekly',
    status: {
      label: 'Inactive',
      value: 'inactive',
    },
  }]

  test('renders correct table', () => {
    renderTable({ tableConfig, mockData })
    expect(screen.getByText('pay_group_table_code | pay_group_table_name')).toBeInTheDocument()
    expect(screen.getByText('pay_group_table_cycle')).toBeInTheDocument()
    expect(screen.getByText('pay_group_table_status')).toBeInTheDocument()
    expect(screen.getByText('action')).toBeInTheDocument()
    mockData.forEach((data) => {
      expect(screen.getByText(data.payGroupCode)).toBeInTheDocument()
      expect(screen.getByText(data.payGroupName)).toBeInTheDocument()
      expect(screen.getByText(data.payCycleName)).toBeInTheDocument()
      expect(screen.getByText(data.status.label)).toBeInTheDocument()
    })
    const dropDown = screen.getAllByLabelText('more')[0]
    fireEvent.click(dropDown)
    expect(screen.getByText('Generate pay cycle')).toBeInTheDocument()
    expect(screen.getByText('Edit')).toBeInTheDocument()
    expect(screen.getByText('Delete')).toBeInTheDocument()
  })
})

describe('payCycleMasterColumn', () => {
  const tableConfig = tableOptions.payCycleMasterColumn(mockHandleEdit)
  const mockData = [
    {
      payCycleName: 'Pay Cycle 1',
      payCycleYear: '2023',
      payCycleNewType: 'Monthly',
      payCycleStartDate: '01 Jan 2023',
      status: 'Active',
    },
    {
      payCycleName: 'Pay Cycle 2',
      payCycleYear: '2024',
      payCycleNewType: 'Bi-Weekly',
      payCycleStartDate: '15 Jan 2024',
      status: 'Inactive',
    },
  ]

  test('renders correct table', () => {
    renderTable({ tableConfig, mockData })
    expect(screen.getByText('pay_cycle_name')).toBeInTheDocument()
    expect(screen.getByText('pay_cycle_month_year')).toBeInTheDocument()
    expect(screen.getByText('pay_cycle_type')).toBeInTheDocument()
    expect(screen.getByText('payroll_period')).toBeInTheDocument()
    expect(screen.getByText('pay_cycle_status')).toBeInTheDocument()
    expect(screen.getByText('action')).toBeInTheDocument()

    mockData.forEach((data) => {
      expect(screen.getByText(data.payCycleName)).toBeInTheDocument()
      expect(screen.getByText(data.payCycleYear)).toBeInTheDocument()
      expect(screen.getByText(data.payCycleNewType)).toBeInTheDocument()
      expect(screen.getByText(data.payCycleStartDate)).toBeInTheDocument()
      expect(screen.getByText(data.status)).toBeInTheDocument()
    })

    const dropDown = screen.getAllByLabelText('more')[0]
    fireEvent.click(dropDown)
    expect(screen.getByText('Edit')).toBeInTheDocument()
    expect(screen.getByText('Delete')).toBeInTheDocument()
  })
})

describe('payrollMonthEndColumn', () => {
  const tableConfig = tableOptions.payrollMonthEndColumn(mockHandleEdit)

  const mockData = [
    {
      payCycleName: 'Pay Cycle 1',
      payCycleYear: '2023',
      payCycleNewType: 'Monthly',
      payCycleStartDate: '01 Jan 2023',
      status: 'Active',
    },
    {
      payCycleName: 'Pay Cycle 2',
      payCycleYear: '2024',
      payCycleNewType: 'Bi-Weekly',
      payCycleStartDate: '15 Jan 2024',
      status: 'Inactive',
    },
  ]

  test('renders correct table', () => {
    renderTable({ tableConfig, mockData })

    expect(screen.getByText('pay_cycle_title')).toBeInTheDocument()
    expect(screen.getByText('pay_cycle_year')).toBeInTheDocument()
    expect(screen.getByText('payroll_period')).toBeInTheDocument()
    expect(screen.getByText('payroll_run_date')).toBeInTheDocument()
    expect(screen.getByText('run_payroll_status')).toBeInTheDocument()
    expect(screen.getByText('action')).toBeInTheDocument()

    mockData.forEach((data) => {
      expect(screen.queryAllByText(data.payCycleName)).toHaveLength(2)
      expect(screen.queryAllByText(data.payCycleStartDate)).toHaveLength(2)
      expect(screen.getByText(data.status)).toBeInTheDocument()
    })

    const dropDown = screen.getAllByLabelText('more')[0]
    fireEvent.click(dropDown)
    expect(screen.getByText('Edit')).toBeInTheDocument()
    expect(screen.getByText('Delete')).toBeInTheDocument()
  })
})

describe('payItemGroupColumn', () => {
  const tableConfig = tableOptions.payItemGroupColumn(mockHandleEdit)

  const mockData = [
    {
      itemGroupCode: 'GRPCODE1',
      itemGroupName: 'Group 1',
    },
    {
      itemGroupCode: 'GRPCODE2',
      itemGroupName: 'Group 2',
    },
  ]

  test('renders correct table', () => {
    renderTable({ tableConfig, mockData })

    expect(screen.getByText(`${t('payroll_item_group_code')} | ${t('payroll_item_group_name')}`)).toBeInTheDocument()
    expect(screen.getByText('action')).toBeInTheDocument()

    mockData.forEach((data) => {
      expect(screen.getByText(data.itemGroupCode)).toBeInTheDocument()
      expect(screen.getByText(data.itemGroupName)).toBeInTheDocument()
    })

    const dropDown = screen.getAllByLabelText('more')[0]
    fireEvent.click(dropDown)
    expect(screen.getByText('Edit')).toBeInTheDocument()
    expect(screen.getByText('Delete')).toBeInTheDocument()
  })
})

describe('payItemMasterColumn', () => {
  const tableConfig = tableOptions.payItemMasterColumn(mockHandleEdit)

  const mockData = [
    {
      payItemName: 'Basic Salary',
      payItemCode: 'BASIC_SALARY',
      payType: 'Salary',
      incomeType: 'Regular',
      status: true,
    },
    {
      payItemName: 'Overtime',
      payItemCode: 'OVERTIME',
      payType: 'Allowance',
      incomeType: 'Irregular',
      status: false,
    },
  ]

  test('renders correct table', () => {
    renderTable({ tableConfig, mockData })

    expect(screen.getByText('payItem_master_name_id')).toBeInTheDocument()
    expect(screen.getByText('pay_item_pay_type')).toBeInTheDocument()
    expect(screen.getByText('pay_item_income_type')).toBeInTheDocument()
    expect(screen.getByText('status')).toBeInTheDocument()

    mockData.forEach((data) => {
      expect(screen.getByText(data.payItemName)).toBeInTheDocument()
      expect(screen.getByText(data.payItemCode)).toBeInTheDocument()
      expect(screen.getByText(data.payType)).toBeInTheDocument()
      expect(screen.getByText(data.incomeType)).toBeInTheDocument()
      expect(screen.getByText(data.status ? 'Active' : 'Inactive')).toBeInTheDocument()
    })

    const dropDown = screen.getAllByLabelText('more')[0]
    fireEvent.click(dropDown)
    expect(screen.getByText('Edit')).toBeInTheDocument()
    expect(screen.getByText('Delete pay item')).toBeInTheDocument()
  })
})

describe('payrollNonRecurringColumn', () => {
  const tableConfig = tableOptions.payrollNonRecurringColumn(mockHandleEdit)

  const mockData = [
    {
      employeeCode: 'EMP001',
      payItemCode: 'BASIC_SALARY',
      quantity: 80,
      ratePerUnit: 50.0,
      originalCurrency: 'USD',
      transactionAmount: 4000.0,
    },
    {
      employeeCode: 'EMP002',
      payItemCode: 'OVERTIME',
      quantity: 20,
      ratePerUnit: 25.0,
      originalCurrency: 'RMB',
      transactionAmount: 500.0,
    },
  ]

  test('renders correct table', () => {
    renderTable({ tableConfig, mockData })

    expect(screen.getByText('Employee')).toBeInTheDocument()
    expect(screen.getByText('Pay Item')).toBeInTheDocument()
    expect(screen.getByText('Quantity|Rate per unit')).toBeInTheDocument()
    expect(screen.getByText('Amount')).toBeInTheDocument()

    mockData.forEach((data) => {
      expect(screen.getByText(data.employeeCode)).toBeInTheDocument()
      expect(screen.getByText(data.payItemCode)).toBeInTheDocument()
      expect(screen.getByText(data.quantity)).toBeInTheDocument()
      expect(screen.getByText(data.ratePerUnit)).toBeInTheDocument()
      expect(screen.getByText(data.originalCurrency)).toBeInTheDocument()
      expect(screen.getByText(data.transactionAmount)).toBeInTheDocument()
    })
  })
})

describe('runPayRollPayCycleMasterColumn', () => {
  const tableConfig = tableOptions.runPayRollPayCycleMasterColumn(mockHandleEdit)

  const mockData = [
    {
      payCycleCode: 'PAY_CYCLE_001',
      payCycleName: 'January 2023',
      payCycleYear: 2023,
      payCycleMonth: 1,
      payCycleStartDate: '2023-01-01',
      payCycleEndDate: '2023-01-31',
      payCycleLabelTestDate: '01 Jan 2023 - 31 Jan 2023',
      status: { label: 'Completed' },
    },
    {
      payCycleCode: 'PAY_CYCLE_002',
      payCycleName: 'February 2023',
      payCycleYear: 2023,
      payCycleMonth: 2,
      payCycleStartDate: '2023-02-01',
      payCycleEndDate: '2023-02-28',
      payCycleLabelTestDate: '01 Feb 2023 - 28 Feb 2023',
      status: { label: 'Failed' },
    },
    {
      payCycleCode: 'PAY_CYCLE_003',
      payCycleName: 'March 2023',
      payCycleYear: 2023,
      payCycleMonth: 3,
      payCycleStartDate: '2023-03-01',
      payCycleEndDate: '2023-03-31',
      payCycleLabelTestDate: '01 Mar 2023 - 31 Mar 2023',
      status: { label: 'Pending' },
    },
    {
      payCycleCode: 'PAY_CYCLE_004',
      payCycleName: 'April 2024',
      payCycleYear: 2024,
      payCycleMonth: 4,
      payCycleStartDate: '2024-04-01',
      payCycleEndDate: '2024-04-30',
      payCycleLabelTestDate: '01 Apr 2024 - 30 Apr 2024',
      status: { label: 'unknown' },
    },
    {
      payCycleCode: 'PAY_CYCLE_006',
      payCycleName: 'April 2026',
      payCycleYear: 2026,
      payCycleMonth: 4,
      payCycleStartDate: '2026-04-01',
      payCycleEndDate: '2026-04-30',
      payCycleLabelTestDate: '01 Apr 2026 - 30 Apr 2026',
      status: { label: 'Success' },
    },
    {
      payCycleCode: 'PAY_CYCLE_007',
      payCycleName: 'April 2027',
      payCycleYear: 2027,
      payCycleMonth: 4,
      payCycleStartDate: '2027-04-01',
      payCycleEndDate: '2027-04-30',
      payCycleLabelTestDate: '01 Apr 2027 - 30 Apr 2027',
      status: { label: 'Finalized' },
    },
    {
      payCycleCode: 'PAY_CYCLE_005',
      payCycleName: 'April 2025',
      payCycleYear: 2025,
      payCycleMonth: 4,
      payCycleStartDate: '2025-04-01',
      payCycleEndDate: '2025-04-30',
      payCycleLabelTestDate: '01 Apr 2025 - 30 Apr 2025',
    },
  ]

  test('renders correct table', () => {
    renderTable({ tableConfig, mockData })

    expect(screen.getByText('Pay cycle ID|Pay cycle name')).toBeInTheDocument()
    expect(screen.getByText('Payroll period')).toBeInTheDocument()
    expect(screen.getByText('Status')).toBeInTheDocument()

    mockData.forEach((data) => {
      expect(screen.getByText(`${data.payCycleYear}-${data.payCycleMonth} (${data.payCycleCode})`)).toBeInTheDocument()
      expect(screen.getByText(data.payCycleName)).toBeInTheDocument()
      expect(screen.getByText(`${data.payCycleLabelTestDate}`)).toBeInTheDocument()
      if (data.status) {
        const statusLabel = screen.getByText(data.status.label)
        expect(statusLabel).toBeInTheDocument()

        if (data.status.label === 'Completed') {
          expect(statusLabel).toHaveStyle('color: #00701C; background: #EBFFF0')
        } else if (data.status.label === 'Failed') {
          expect(statusLabel).toHaveStyle('color: #FF0000; background: #FFEAEA')
        } else if (data.status.label === 'Pending') {
          expect(statusLabel).toHaveStyle('color: #0000FF; background: #EAF0FF')
        } else if (data.status.label !== 'Success' && data.status.label !== 'Finalized') {
          expect(statusLabel).toHaveStyle('color: #3B3839; background: #EBEBEB')
        }
      }
    })
  })
})

describe('countryColumn', () => {
  const tableConfig = tableOptions.countryColumn(mockHandleEdit)

  const mockData = [
    {
      countryCode: 'USA',
      countryName: 'United States',
      createdAt: '2023-04-15T10:30:00Z',
    },
    {
      countryCode: 'CAN',
      countryName: 'Canada',
      createdAt: '2023-05-01T15:45:00Z',
    },
    {
      countryCode: 'GBR',
      countryName: 'United Kingdom',
      createdAt: '2023-06-20T09:00:00Z',
    },
  ]

  test('renders correct table', () => {
    renderTable({ tableConfig, mockData })

    expect(screen.getByText('Country ID')).toBeInTheDocument()
    expect(screen.getByText('country_name')).toBeInTheDocument()
    expect(screen.getByText('Created At')).toBeInTheDocument()

    mockData.forEach((data) => {
      expect(screen.getByText(data.countryCode)).toBeInTheDocument()
      expect(screen.getByText(data.countryName)).toBeInTheDocument()
      expect(screen.getByText(formatedDate(data.createdAt))).toBeInTheDocument()
    })

    const dropDown = screen.getAllByLabelText('more')[0]
    fireEvent.click(dropDown)
    expect(screen.getByText('Edit country')).toBeInTheDocument()
    expect(screen.getByText('Delete country')).toBeInTheDocument()
  })
})

describe('formulaSetupColumn', () => {
  const tableConfig = tableOptions.formulaSetupColumn(mockHandleEdit)

  const mockData = [
    {
      formulaCode: 'FORMULA001',
      description: 'Basic Salary',
      type: 'Calculation',
    },
    {
      formulaCode: 'FORMULA002',
      description: 'Overtime Pay',
      type: 'Calculation2',
    },
  ]

  test('renders correct table', () => {
    renderTable({ tableConfig, mockData })

    expect(screen.getByText('Formula name | Formula ID')).toBeInTheDocument()
    expect(screen.getByText('Type')).toBeInTheDocument()

    mockData.forEach((data) => {
      expect(screen.getByText(data.description)).toBeInTheDocument()
      expect(screen.getByText(data.formulaCode)).toBeInTheDocument()
      expect(screen.getByText(data.type)).toBeInTheDocument()
    })

    const dropDown = screen.getAllByLabelText('more')[0]
    fireEvent.click(dropDown)
    expect(screen.getByText('Delete formula')).toBeInTheDocument()
  })
})

describe('formulaExpressionColumn', () => {
  const tableConfig = tableOptions.formulaExpressionColumn(mockHandleEdit)

  const mockData = [
    {
      formulaCode: 'FORMULA001',
      description: 'Basic Salary',
      type: 'Calculation',
    },
    {
      formulaCode: 'FORMULA002',
      description: 'Overtime Pay',
      type: 'Calculation2',
    },
  ]

  test('renders correct table', () => {
    renderTable({ tableConfig, mockData })

    expect(screen.getByText('Formula name | Formula ID')).toBeInTheDocument()
    expect(screen.getByText('Type')).toBeInTheDocument()

    mockData.forEach((data) => {
      expect(screen.getByText(data.description)).toBeInTheDocument()
      expect(screen.getByText(data.formulaCode)).toBeInTheDocument()
      expect(screen.getByText(data.type)).toBeInTheDocument()
    })

    const dropDown = screen.getAllByLabelText('more')[0]
    fireEvent.click(dropDown)
    expect(screen.getByText('Delete formula expreesion')).toBeInTheDocument()
  })
})

describe('termsColumn', () => {
  const tableConfig = tableOptions.termsColumn(mockHandleEdit)

  const mockData = [
    {
      termCode: 'TERM001',
      description: 'Salary Term',
      updateSequence: 1,
      expression: 'Calculation',
    },
    {
      termCode: 'TERM002',
      description: 'Overtime Term',
      updateSequence: 2,
      expression: 'Calculation2',
    },
  ]

  test('renders correct table', () => {
    renderTable({ tableConfig, mockData })

    expect(screen.getByText('Term description | Term code')).toBeInTheDocument()
    expect(screen.getByText('Update sequence')).toBeInTheDocument()
    expect(screen.getByText('Type')).toBeInTheDocument()

    mockData.forEach((data) => {
      expect(screen.getByText(data.description)).toBeInTheDocument()
      expect(screen.getByText(data.termCode)).toBeInTheDocument()
      expect(screen.getByText(data.updateSequence.toString())).toBeInTheDocument()
      expect(screen.getByText(data.expression)).toBeInTheDocument()
    })

    const dropdownButtons = screen.getAllByLabelText('more')
    fireEvent.click(dropdownButtons[0])
    expect(screen.getByText('Edit Terms')).toBeInTheDocument()
    expect(screen.getByText('Delete Terms')).toBeInTheDocument()
  })
})

describe('clientGroupProfileColumn', () => {
  const tableConfig = tableOptions.clientGroupProfileColumn(mockHandleEdit)

  const mockData = [
    {
      clientGroupCode: 'CG001',
      clientGroupName: 'Client Group A',
      entitiesCount: 10,
      status: true,
    },
    {
      clientGroupCode: 'CG002',
      clientGroupName: 'Client Group B',
      entitiesCount: 5,
      status: false,
    },
  ]

  test('renders correct table', () => {
    renderTable({ tableConfig, mockData })

    expect(screen.getByText('Client group name | Client group ID')).toBeInTheDocument()
    expect(screen.getByText('Entities')).toBeInTheDocument()
    expect(screen.getByText('Status')).toBeInTheDocument()

    mockData.forEach((data) => {
      expect(screen.getByText(data.clientGroupName)).toBeInTheDocument()
      expect(screen.getByText(data.clientGroupCode)).toBeInTheDocument()
      expect(screen.getByText(data.entitiesCount.toString())).toBeInTheDocument()
      expect(screen.getByText(data.status ? 'Active' : 'Inactive')).toBeInTheDocument()
    })
  })

  test('renders correct action menu when active', () => {
    renderTable({ tableConfig, mockData })

    const dropdownButtons = screen.getAllByLabelText('more')
    fireEvent.click(dropdownButtons[0])
    expect(screen.getByText('Inactive client group')).toBeInTheDocument()
    fireEvent.click(screen.getByText('Inactive client group'))
    expect(mockHandleEdit).toHaveBeenCalledTimes(1)
    expect(screen.getByText('Edit client group')).toBeInTheDocument()
    fireEvent.click(screen.getByText('Edit client group'))
    expect(mockHandleEdit).toHaveBeenCalledTimes(2)
    expect(screen.getByText('Delete client group')).toBeInTheDocument()
    fireEvent.click(screen.getByText('Delete client group'))
    expect(mockHandleEdit).toHaveBeenCalledTimes(3)
  })

  test('renders correct action menu when inactive', () => {
    renderTable({ tableConfig, mockData })

    const dropdownButtons = screen.getAllByLabelText('more')

    fireEvent.click(dropdownButtons[1])
    expect(screen.getByText('Active client group')).toBeInTheDocument()
    fireEvent.click(screen.getByText('Active client group'))
    expect(mockHandleEdit).toHaveBeenCalledTimes(1)
  })
})

describe('clientGroupEntitiesColumn', () => {
  const tableConfig = tableOptions.clientGroupEntitiesColumn(mockHandleEdit)

  const mockData = [
    {
      entityCode: 'E001',
      entityName: 'Entity A',
      countryLocalization: 'United States',
      userCount: 20,
      status: true,
    },
    {
      entityCode: 'E002',
      entityName: 'Entity B',
      countryLocalization: 'United Kingdom',
      userCount: 10,
      status: false,
    },
  ]

  test('renders correct table', () => {
    renderTable({ tableConfig, mockData })

    expect(screen.getByText('Entity name | Entity ID')).toBeInTheDocument()
    expect(screen.getByText('Country')).toBeInTheDocument()
    expect(screen.getByText('Users')).toBeInTheDocument()
    expect(screen.getByText('Status')).toBeInTheDocument()

    mockData.forEach((data) => {
      expect(screen.getByText(data.entityName)).toBeInTheDocument()
      expect(screen.getByText(data.entityCode)).toBeInTheDocument()
      expect(screen.getByText(data.countryLocalization)).toBeInTheDocument()
      expect(screen.getByText(data.userCount.toString())).toBeInTheDocument()
      expect(screen.getByText(data.status ? 'Active' : 'Inactive')).toBeInTheDocument()
    })

    const dropdownButtons = screen.getAllByLabelText('more')
    fireEvent.click(dropdownButtons[0])
    expect(screen.getByText('Edit entity')).toBeInTheDocument()
    fireEvent.click(screen.getByText('Edit entity'))
    expect(mockHandleEdit).toHaveBeenCalledTimes(1)
    expect(screen.getByText('Delete entity')).toBeInTheDocument()
    fireEvent.click(screen.getByText('Delete entity'))
    expect(mockHandleEdit).toHaveBeenCalledTimes(2)
  })
})

describe('clientGroupProfileUserColumn', () => {
  const tableConfig = tableOptions.clientGroupProfileUserColumn(mockHandleEdit)

  const mockData = [
    {
      username: 'user1',
      firstName: 'John',
      lastName: 'Doe',
      entityCount: 1,
    },
    {
      username: 'user2',
      firstName: 'Jane',
      lastName: 'Doed',
      entityCount: 6,
    },
  ]

  test('renders correct table', () => {
    renderTable({ tableConfig, mockData })

    expect(screen.getByText('Name | User ID')).toBeInTheDocument()
    expect(screen.getByText('Entities')).toBeInTheDocument()

    mockData.forEach((data) => {
      expect(screen.getByText(`${`${data.firstName} ${data.lastName}`}`)).toBeInTheDocument()
      expect(screen.getByText(`${data.entityCount} ${data.entityCount > 1 ? t('entities') : t('entity')}`)).toBeInTheDocument()
    })

    const actionMenuButtons = screen.getAllByLabelText('more')
    fireEvent.click(actionMenuButtons[0])
    expect(screen.getByText('Assign entity')).toBeInTheDocument()
    fireEvent.click(screen.getByText('Assign entity'))
    expect(mockHandleEdit).toHaveBeenCalledTimes(1)
    expect(screen.getByText('Remove entity')).toBeInTheDocument()
    fireEvent.click(screen.getByText('Remove entity'))
    expect(mockHandleEdit).toHaveBeenCalledTimes(2)
  })
})

describe('clientGroupEntitiesUserColumn', () => {
  const tableConfig = tableOptions.clientGroupEntitiesUserColumn(mockHandleEdit)

  const mockData = [
    {
      userName: 'user1',
      userId: '001',
      roleName: 'Doe',
    },
    {
      userName: 'user2',
      userId: '002',
      roleName: 'Doed',
    },
  ]

  test('renders correct table', () => {
    renderTable({ tableConfig, mockData })

    expect(screen.getByText('Name/Role Code')).toBeInTheDocument()
    expect(screen.getByText('User Role')).toBeInTheDocument()

    mockData.forEach((data) => {
      expect(screen.getByText(`${`${data.userName}`}`)).toBeInTheDocument()
      expect(screen.getByText(data.roleName)).toBeInTheDocument()
      expect(screen.getByText(data.userId)).toBeInTheDocument()
    })
  })
})

describe('nationalityColumn', () => {
  const tableConfig = tableOptions.nationalityColumn(mockHandleEdit)

  const mockData = [
    {
      nationalityCode: 'N001',
      nationalityName: 'United States',
    },
    {
      nationalityCode: 'N002',
      nationalityName: 'United Kingdom',
    },
  ]

  test('renders correct table', () => {
    renderTable({ tableConfig, mockData })

    expect(screen.getByText('Nationality ID')).toBeInTheDocument()
    expect(screen.getByText('nationality_name')).toBeInTheDocument()

    mockData.forEach((data) => {
      expect(screen.getByText(data.nationalityCode)).toBeInTheDocument()
      expect(screen.getByText(data.nationalityName)).toBeInTheDocument()
    })

    const dropdownButtons = screen.getAllByLabelText('more')
    fireEvent.click(dropdownButtons[0])
    expect(screen.getByText('Edit Nationality')).toBeInTheDocument()
    expect(screen.getByText('Delete Nationality')).toBeInTheDocument()
  })
})

describe('currencyColumn', () => {
  const tableConfig = tableOptions.currencyColumn(mockHandleEdit)

  const mockData = [
    {
      currencyCode: 'USD',
      currencyName: 'United States Dollar',
      currencySymbol: '$',
    },
    {
      currencyCode: 'GBP',
      currencyName: 'British Pound Sterling',
      currencySymbol: '£',
    },
  ]

  test('renders correct table', () => {
    renderTable({ tableConfig, mockData })

    expect(screen.getByText('Currency ID')).toBeInTheDocument()
    expect(screen.getByText('currency_name')).toBeInTheDocument()
    expect(screen.getByText('currency_symbol')).toBeInTheDocument()

    mockData.forEach((data) => {
      expect(screen.getByText(data.currencyCode)).toBeInTheDocument()
      expect(screen.getByText(data.currencyName)).toBeInTheDocument()
      expect(screen.getByText(data.currencySymbol)).toBeInTheDocument()
    })

    const dropdownButtons = screen.getAllByLabelText('more')
    fireEvent.click(dropdownButtons[0])
    expect(screen.getByText('Edit currency')).toBeInTheDocument()
    expect(screen.getByText('Delete currency')).toBeInTheDocument()
  })
})

describe('holidayCalenderDateColumn', () => {
  const tableConfig = tableOptions.holidayCalenderDateColumn(mockHandleEdit)

  const mockData = [
    {
      date: '2023-01-01',
      holidayType: 'New Year\'s Day',
    },
    {
      date: '2023-07-04',
      holidayType: 'Independence Day',
    },
  ]

  test('renders correct table', () => {
    renderTable({ tableConfig, mockData })

    expect(screen.getByText('Date')).toBeInTheDocument()
    expect(screen.getByText('Holiday Type')).toBeInTheDocument()
    expect(screen.getByText('action')).toBeInTheDocument()

    mockData.forEach((data) => {
      expect(screen.getByText(data.date)).toBeInTheDocument()
      expect(screen.getByText(data.holidayType)).toBeInTheDocument()
    })

    const dropdownButtons = screen.getAllByLabelText('more')
    fireEvent.click(dropdownButtons[0])
  })
})

describe('holidayCalenderColumn', () => {
  const tableConfig = tableOptions.holidayCalenderColumn(mockHandleEdit)

  const mockData = [
    {
      holidayCalendarCode: 'HOLIDAY001',
      holidayCalendarName: 'US Holiday',
      remarks: 'United States',
      status: true,
    },
    {
      holidayCalendarCode: 'HOLIDAY002',
      holidayCalendarName: 'UK Holiday',
      remarks: 'United Kingdom',
      status: false,
    },
  ]

  test('renders correct table', () => {
    renderTable({ tableConfig, mockData })

    expect(screen.getByText('Holiday Calender ID | Holiday Calender Name')).toBeInTheDocument()
    expect(screen.getByText('bulk_upload_data_status')).toBeInTheDocument()
    expect(screen.getByText('holiday_calender_remarks')).toBeInTheDocument()
    expect(screen.getByText('action')).toBeInTheDocument()

    mockData.forEach((data) => {
      expect(screen.getByText(data.holidayCalendarCode)).toBeInTheDocument()
      expect(screen.getByText(data.holidayCalendarName)).toBeInTheDocument()
      expect(screen.getByText(data.remarks)).toBeInTheDocument()
      expect(screen.getByText(data.status ? 'Active' : 'Inactive')).toBeInTheDocument()

      const statusLabel = screen.getByText(data.status ? 'Active' : 'Inactive')
      if (data.status) {
        expect(statusLabel).toHaveStyle('color: #00701C; background: #EBFFF0')
      } else {
        expect(statusLabel).toHaveStyle('color: #3B3839; background: #E8E6E7')
      }
    })

    const dropdownButtons = screen.getAllByLabelText('more')
    fireEvent.click(dropdownButtons[0])
    expect(screen.getByText('Edit')).toBeInTheDocument()
    expect(screen.getByText('Delete')).toBeInTheDocument()
  })
})

describe('paymentmethodColumn', () => {
  const tableConfig = tableOptions.paymentmethodColumn(mockHandleEdit)

  const mockData = [
    {
      countryLocalization: 'United States',
      paymentMethodCode: 'VISA',
      paymentMethodName: 'Visa',
    },
    {
      countryLocalization: 'United Kingdom',
      paymentMethodCode: 'MASTERCARD',
      paymentMethodName: 'Mastercard',
    },
  ]

  test('renders correct table', () => {
    renderTable({ tableConfig, mockData })

    expect(screen.getByText('country_localization')).toBeInTheDocument()
    expect(screen.getByText('Payment Method ID')).toBeInTheDocument()
    expect(screen.getByText('payment_method_name')).toBeInTheDocument()

    mockData.forEach((data) => {
      expect(screen.getByText(data.countryLocalization)).toBeInTheDocument()
      expect(screen.getByText(data.paymentMethodCode)).toBeInTheDocument()
      expect(screen.getByText(data.paymentMethodName)).toBeInTheDocument()
    })

    const dropdownButtons = screen.getAllByLabelText('more')
    fireEvent.click(dropdownButtons[0])
    expect(screen.getByText('Edit Payment method')).toBeInTheDocument()
    expect(screen.getByText('Delete Payment method')).toBeInTheDocument()
  })
})

describe('settingtemplateColumn', () => {
  const tableConfig = tableOptions.settingtemplateColumn(mockHandleEdit)

  const mockData = [
    {
      settingName: 'Global Settings',
      settingCode: 'GLOBAL_SETTINGS',
      countryLocalization: 'United States',
      settingLevel: 'Global',
    },
    {
      settingName: 'US Settings',
      settingCode: 'US_SETTINGS',
      countryLocalization: 'United States2',
      settingLevel: 'Country',
    },
  ]

  test('renders correct table', () => {
    renderTable({ tableConfig, mockData })

    expect(screen.getByText(`${t('Setting Name')} | ${t('Setting ID')}`)).toBeInTheDocument()
    expect(screen.getByText('country_localization')).toBeInTheDocument()
    expect(screen.getByText('setting_level')).toBeInTheDocument()

    mockData.forEach((data) => {
      expect(screen.getByText(data.settingName)).toBeInTheDocument()
      expect(screen.getByText(data.settingCode)).toBeInTheDocument()
      expect(screen.getByText(data.countryLocalization)).toBeInTheDocument()
      expect(screen.getByText(data.settingLevel)).toBeInTheDocument()
    })

    const dropdownButtons = screen.getAllByLabelText('more')
    fireEvent.click(dropdownButtons[0])
    expect(screen.getByText('Edit setting')).toBeInTheDocument()
    expect(screen.getByText('Delete setting')).toBeInTheDocument()
  })
})

describe('pensionFundColumn', () => {
  const tableConfig = tableOptions.pensionFundColumn(mockHandleEdit)

  const mockData = [
    {
      countryLocalization: 'United States',
      pensionFundSchemeRuleType: 'Defined Benefit Plan',
      effectiveStartDate: '2022-01-01',
      effectiveEndDate: '2023-12-31',
    },
    {
      countryLocalization: 'United Kingdom',
      pensionFundSchemeRuleType: 'Defined Contribution Plan',
      effectiveStartDate: '2021-03-15',
      effectiveEndDate: '2024-06-30',
    },
  ]

  test('renders correct table', () => {
    renderTable({ tableConfig, mockData })

    expect(screen.getByText(`${'country_localization_title'}`)).toBeInTheDocument()
    expect(screen.getByText(`${'pension_fund_scheme'}`)).toBeInTheDocument()
    expect(screen.getByText(`${'pension_fund_start_date'}`)).toBeInTheDocument()
    expect(screen.getByText(`${'pension_fund_end_date'}`)).toBeInTheDocument()
    expect(screen.getByText('action')).toBeInTheDocument()

    mockData.forEach((data) => {
      expect(screen.getByText(data.countryLocalization)).toBeInTheDocument()
      expect(screen.getByText(data.pensionFundSchemeRuleType)).toBeInTheDocument()
      expect(screen.getByText(formatedDate(data.effectiveStartDate))).toBeInTheDocument()
      expect(screen.getByText(formatedDate(data.effectiveEndDate))).toBeInTheDocument()
    })

    const dropdownButtons = screen.getAllByLabelText('more')
    fireEvent.click(dropdownButtons[0])
    expect(screen.getByText('Edit')).toBeInTheDocument()
    expect(screen.getByText('Delete')).toBeInTheDocument()
  })
})

describe('clientGroupProfileCalenderColumn', () => {
  const tableConfig = tableOptions.clientGroupProfileCalenderColumn(mockHandleEdit)

  const mockData = [
    {
      clientGroupCode: 'CG001',
      clientGroupName: 'Client Group 1',
      status: 'Active',
      approveStatus: 'Approved',
      remarks: 'This is a sample client group profile',
    },
    {
      clientGroupCode: 'CG002',
      clientGroupName: 'Client Group 2',
      status: 'Inactive',
      approveStatus: 'Pending',
      remarks: 'This is another sample client group profile',
    },
  ]

  test('renders correct table', () => {
    renderTable({ tableConfig, mockData })

    expect(screen.getByText(`${'client_profile_code'}`)).toBeInTheDocument()
    expect(screen.getByText(`${'client_profile_name'}`)).toBeInTheDocument()
    expect(screen.getByText(`${'client_profile_status'}`)).toBeInTheDocument()
    expect(screen.getByText(`${'client_aproove'}`)).toBeInTheDocument()
    expect(screen.getByText(`${'client_profile_remarks'}`)).toBeInTheDocument()
    expect(screen.getByText('action')).toBeInTheDocument()

    mockData.forEach((data) => {
      expect(screen.getByText(data.clientGroupCode)).toBeInTheDocument()
      expect(screen.getByText(data.clientGroupName)).toBeInTheDocument()
      expect(screen.getByText(data.status)).toBeInTheDocument()
      expect(screen.getByText(data.approveStatus)).toBeInTheDocument()
      expect(screen.getByText(data.remarks)).toBeInTheDocument()
    })

    const dropdownButtons = screen.getAllByLabelText('more')
    fireEvent.click(dropdownButtons[0])
    expect(screen.getByText('Edit')).toBeInTheDocument()
    expect(screen.getByText('Delete')).toBeInTheDocument()
  })
})

describe('userAdministrationColumn', () => {
  const tableConfig = tableOptions.userAdministrationColumn(mockHandleEdit)

  const mockData = [
    {
      username: 'user1',
      firstName: 'John',
      lastName: 'Doe',
      emailAddress: 'john.doe@example.com',
      userType: 'Admin',
    },
    {
      username: 'user2',
      firstName: 'Jane',
      lastName: 'Doed',
      emailAddress: 'jane.doe@example.com',
      userType: 'User',
    },
  ]

  test('renders correct table', () => {
    renderTable({ tableConfig, mockData })

    expect(screen.getByText('user_administration_user_name')).toBeInTheDocument()
    expect(screen.getByText('user_administration_first_name')).toBeInTheDocument()
    expect(screen.getByText('user_administration_last_name')).toBeInTheDocument()
    expect(screen.getByText('user_administration_email')).toBeInTheDocument()
    expect(screen.getByText('user_administration_type')).toBeInTheDocument()
    expect(screen.getByText('action')).toBeInTheDocument()

    mockData.forEach((data) => {
      expect(screen.getByText(data.username)).toBeInTheDocument()
      expect(screen.getByText(data.firstName)).toBeInTheDocument()
      expect(screen.getByText(data.lastName)).toBeInTheDocument()
      expect(screen.getByText(data.emailAddress)).toBeInTheDocument()
      expect(screen.getByText(data.userType)).toBeInTheDocument()
    })

    const dropdownButtons = screen.getAllByLabelText('more')
    fireEvent.click(dropdownButtons[0])
  })
})

describe('pensionFundTerminationColumn', () => {
  const tableConfig = tableOptions.pensionFundTerminationColumn(mockHandleEdit)

  const mockData = [
    {
      terminationCode: 'TER001',
      countryLocalization: 'United States',
    },
    {
      terminationCode: 'TER002',
      countryLocalization: 'Canada',
    },
  ]

  test('renders correct table', () => {
    renderTable({ tableConfig, mockData })

    expect(screen.getByText('termination_code')).toBeInTheDocument()
    expect(screen.getByText('country_localization_title')).toBeInTheDocument()
    expect(screen.getByText('action')).toBeInTheDocument()

    mockData.forEach((data) => {
      expect(screen.getByText(data.terminationCode)).toBeInTheDocument()
      expect(screen.getByText(data.countryLocalization)).toBeInTheDocument()
    })

    const dropdownButtons = screen.getAllByLabelText('more')
    fireEvent.click(dropdownButtons[0])
    expect(screen.getByText('Edit')).toBeInTheDocument()
    expect(screen.getByText('Delete')).toBeInTheDocument()
  })
})

describe('userroleColumn', () => {
  const tableConfig = tableOptions.userroleColumn(mockHandleEdit)

  const mockData = [
    {
      userRoleCode: 'ADMIN',
      userRoleName: 'Administrator',
      remarks: 'This is the admin role',
    },
    {
      userRoleCode: 'USER',
      userRoleName: 'Regular User',
      remarks: 'This is the user role',
    },
  ]

  test('renders correct table', () => {
    renderTable({ tableConfig, mockData })

    expect(screen.getByText('user_role_code')).toBeInTheDocument()
    expect(screen.getByText('user_role_name')).toBeInTheDocument()
    expect(screen.getByText('user_role_remarks')).toBeInTheDocument()
    expect(screen.getByText('action')).toBeInTheDocument()

    mockData.forEach((data) => {
      expect(screen.getByText(data.userRoleCode)).toBeInTheDocument()
      expect(screen.getByText(data.userRoleName)).toBeInTheDocument()
      expect(screen.getByText(data.remarks)).toBeInTheDocument()
    })

    const dropdownButtons = screen.getAllByLabelText('more')
    fireEvent.click(dropdownButtons[0])
  })
})

describe('bulkUploadColumn', () => {
  let failCounter = 0
  const mockHandler = jest.fn()
  const tableConfig = tableOptions.bulkUploadColumn(mockHandler)

  const mockData = [
    {
      requestFileName: 'upload_1.csv',
      operationType: 'Pension Fund Termination',
      jobId: '123456',
      createdAt: '2023-04-15T12:34:56.789Z',
      createdBy: 'John Doe',
      completedDate: '2023-04-15T12:35:00.789Z',
      jobStatus: 'Successful',
      errorFilePath: null,
    },
    {
      requestFileName: 'upload_2.csv',
      operationType: 'User Role Management',
      jobId: '654321',
      createdAt: '2023-04-16T08:45:12.345Z',
      createdBy: 'Jane Smith',
      completedDate: null,
      jobStatus: 'Failed',
      errorFilePath: 'error_log_2.txt',
    },
  ]

  test('renders correct table', () => {
    renderTable({ tableConfig, mockData })

    expect(screen.getByText('bulk_upload_data_first_name')).toBeInTheDocument()
    expect(screen.getByText('bulk_upload_data_type')).toBeInTheDocument()
    expect(screen.getByText('job_id_created_date_by')).toBeInTheDocument()
    expect(screen.getByText('bulk_upload_data_created_date')).toBeInTheDocument()
    expect(screen.getByText('bulk_upload_data_status')).toBeInTheDocument()
    expect(screen.getByText('bulk_upload_data_file_name')).toBeInTheDocument()

    mockData.forEach((data) => {
      expect(screen.getByText(data.requestFileName)).toBeInTheDocument()
      expect(screen.getByText(data.operationType)).toBeInTheDocument()
      expect(screen.getByText(data.jobId)).toBeInTheDocument()
      expect(screen.getByText(data.createdBy)).toBeInTheDocument()
      expect(screen.getByText(data.jobStatus)).toBeInTheDocument()

      if (data.completedDate) {
        const date = new Date(data.completedDate)
        const formateDate = date.toLocaleDateString('en-GB', {
          day: '2-digit',
          month: 'short',
          year: 'numeric',
          hour: '2-digit',
          minute: '2-digit',
          second: '2-digit',
        })

        expect(screen.getByText(formateDate)).toBeInTheDocument()
      }

      if (data.jobStatus === 'Failed' && data.errorFilePath) {
        failCounter += 1
      }
    })
    expect(screen.queryAllByText('Button')).toHaveLength(failCounter)
    const button = screen.queryAllByText('Button')[0]
    fireEvent.click(button)
    expect(mockHandler).toBeCalled()
  })
})

describe('clientGroupEntityColumn', () => {
  const tableConfig = tableOptions.clientGroupEntityColumn(mockHandleEdit)

  const mockData = [
    {
      clientGroupCode: 'CG001',
      clientGroupName: 'Client Group 1',
      entityCode: 'E001',
      entityName: 'Entity 1',
      countryLocalization: 'United States',
      Url: 'https://www.example.com',
      Region: 'North America',
      status: 'Active',
    },
    {
      clientGroupCode: 'CG002',
      clientGroupName: 'Client Group 2',
      entityCode: 'E002',
      entityName: 'Entity 2',
      countryLocalization: 'United Kingdom',
      Url: 'https://www.example.co.uk',
      Region: 'Europe',
      status: 'Inactive',
    },
  ]

  test('renders correct table', () => {
    renderTable({ tableConfig, mockData })

    expect(screen.getByText('client_profile_code')).toBeInTheDocument()
    expect(screen.getByText('client_profile_name')).toBeInTheDocument()
    expect(screen.getByText('entity_code')).toBeInTheDocument()
    expect(screen.getByText('entity_name')).toBeInTheDocument()
    expect(screen.getByText('country_localization')).toBeInTheDocument()
    expect(screen.getByText('client_entity_url')).toBeInTheDocument()
    expect(screen.getByText('region')).toBeInTheDocument()
    expect(screen.getByText('client_profile_status')).toBeInTheDocument()
    expect(screen.getByText('action')).toBeInTheDocument()

    mockData.forEach((data) => {
      expect(screen.getByText(data.clientGroupCode)).toBeInTheDocument()
      expect(screen.getByText(data.clientGroupName)).toBeInTheDocument()
      expect(screen.getByText(data.entityCode)).toBeInTheDocument()
      expect(screen.getByText(data.entityName)).toBeInTheDocument()
      expect(screen.getByText(data.countryLocalization)).toBeInTheDocument()
      expect(screen.getByText(data.Url)).toBeInTheDocument()
      expect(screen.getByText(data.Region)).toBeInTheDocument()
      expect(screen.getByText(data.status)).toBeInTheDocument()
    })
  })
})

describe('logsColumn', () => {
  const tableConfig = tableOptions.logsColumn(mockHandleEdit)

  const mockData = [
    {
      payCycleCode: 'PC001',
      payCycleName: 'Pay Cycle 1',
      jobId: 'JOB001',
      createdAt: '2023-06-01 10:00:00',
      completedDate: '2023-06-01 11:00:00',
      jobStatus: 'Completed',
      download: 'file_name.csv',
    },
    {
      payCycleCode: 'PC002',
      payCycleName: 'Pay Cycle 2',
      jobId: 'JOB002',
      createdAt: '2023-06-02 14:30:00',
      completedDate: '2023-06-02 15:00:00',
      jobStatus: 'In Progress',
      download: 'file_name_2.csv',
    },
  ]

  test('renders correct table', () => {
    renderTable({ tableConfig, mockData })

    expect(screen.getByText('run_Payroll_Cycle_Code')).toBeInTheDocument()
    expect(screen.getByText('run_payroll_cycle_name')).toBeInTheDocument()
    expect(screen.getByText('bulk_upload_data_job_id')).toBeInTheDocument()
    expect(screen.getByText('bulk_upload_data_job_created_and_by')).toBeInTheDocument()
    expect(screen.getByText('bulk_upload_data_created_date')).toBeInTheDocument()
    expect(screen.getByText('bulk_upload_data_status')).toBeInTheDocument()
    expect(screen.getByText('bulk_upload_data_file_name')).toBeInTheDocument()
    expect(screen.getByText('action')).toBeInTheDocument()

    mockData.forEach((data) => {
      expect(screen.getByText(data.payCycleCode)).toBeInTheDocument()
      expect(screen.getByText(data.payCycleName)).toBeInTheDocument()
      expect(screen.getByText(data.jobId)).toBeInTheDocument()
      expect(screen.getByText(data.createdAt)).toBeInTheDocument()
      expect(screen.getByText(data.completedDate)).toBeInTheDocument()
      expect(screen.getByText(data.jobStatus)).toBeInTheDocument()
      expect(screen.getByText(data.download)).toBeInTheDocument()
    })
  })
})

describe('monthLogsColumn', () => {
  const tableConfig = tableOptions.monthLogsColumn(mockHandleEdit)

  const mockData = [
    {
      payCycleCode: '2023-06',
      jobId: 'JOB001',
      createdAt: '2023-06-01 10:00:00',
      completedDate: '2023-06-01 11:00:00',
      jobStatus: 'Completed',
      download: 'file_name.csv',
    },
    {
      payCycleCode: '2023-07',
      jobId: 'JOB002',
      createdAt: '2023-07-01 14:30:00',
      completedDate: '2023-07-01 15:00:00',
      jobStatus: 'In Progress',
      download: 'file_name_2.csv',
    },
  ]

  test('renders correct table', () => {
    renderTable({ tableConfig, mockData })

    expect(screen.getByText('pay_cycle_month_year')).toBeInTheDocument()
    expect(screen.getByText('bulk_upload_data_job_id')).toBeInTheDocument()
    expect(screen.getByText('bulk_upload_data_job_created_and_by')).toBeInTheDocument()
    expect(screen.getByText('bulk_upload_data_created_date')).toBeInTheDocument()
    expect(screen.getByText('bulk_upload_data_status')).toBeInTheDocument()
    expect(screen.getByText('bulk_upload_data_file_name')).toBeInTheDocument()
    expect(screen.getByText('action')).toBeInTheDocument()

    mockData.forEach((data) => {
      expect(screen.getByText(data.payCycleCode)).toBeInTheDocument()
      expect(screen.getByText(data.jobId)).toBeInTheDocument()
      expect(screen.getByText(data.createdAt)).toBeInTheDocument()
      expect(screen.getByText(data.completedDate)).toBeInTheDocument()
      expect(screen.getByText(data.jobStatus)).toBeInTheDocument()
      expect(screen.getByText(data.download)).toBeInTheDocument()
    })
  })
})

describe('entityIrdColumn', () => {
  const tableConfig = tableOptions.entityIrdColumn(mockHandleEdit)

  const mockData = [
    {
      corporateTitleName: 'Vice President',
      corporateTitleCode: 'VP',
    },
    {
      corporateTitleName: 'Manager',
      corporateTitleCode: 'MGR',
    },
  ]

  test('renders correct table', () => {
    renderTable({ tableConfig, mockData })

    expect(screen.getByText(`${t('ent_ird_corporate_title_view_name')}|${t('ent_ird_corporate_title_view_code')}`)).toBeInTheDocument()

    mockData.forEach((data) => {
      expect(screen.getByText(data.corporateTitleName)).toBeInTheDocument()
      expect(screen.getByText(data.corporateTitleCode)).toBeInTheDocument()
    })

    const dropdownButtons = screen.getAllByLabelText('more')
    fireEvent.click(dropdownButtons[0])
    expect(screen.getByText('Edit Ird')).toBeInTheDocument()
    expect(screen.getByText('Delete Ird')).toBeInTheDocument()
  })
})

describe('entityDepartmentColumn', () => {
  const tableConfig = tableOptions.entityDepartmentColumn(mockHandleEdit)

  const mockData = [
    {
      departmentDescription: 'Human Resources',
      departmentCode: 'HR',
    },
    {
      departmentDescription: 'Finance',
      departmentCode: 'FIN',
    },
  ]

  test('renders correct table', () => {
    renderTable({ tableConfig, mockData })

    expect(screen.getByText(`${t('ent_dept_view_description')}|${t('ent_dept_view_code')}`)).toBeInTheDocument()

    mockData.forEach((data) => {
      expect(screen.getByText(data.departmentDescription)).toBeInTheDocument()
      expect(screen.getByText(data.departmentCode)).toBeInTheDocument()
    })

    const dropdownButtons = screen.getAllByLabelText('more')
    fireEvent.click(dropdownButtons[0])
    expect(screen.getByText('Edit department')).toBeInTheDocument()
    expect(screen.getByText('Delete department')).toBeInTheDocument()
  })
})

describe('entityDivisionColumn', () => {
  const tableConfig = tableOptions.entityDivisionColumn(mockHandleEdit)

  const mockData = [
    {
      divisionDescription: 'North America',
      divisionCode: 'NA',
    },
    {
      divisionDescription: 'Europe',
      divisionCode: 'EU',
    },
  ]

  test('renders correct table', () => {
    renderTable({ tableConfig, mockData })

    expect(screen.getByText(`${t('division_description')}|${t('division_code')}`)).toBeInTheDocument()

    mockData.forEach((data) => {
      expect(screen.getByText(data.divisionDescription)).toBeInTheDocument()
      expect(screen.getByText(data.divisionCode)).toBeInTheDocument()
    })

    const dropdownButtons = screen.getAllByLabelText('more')
    fireEvent.click(dropdownButtons[0])
    expect(screen.getByText('Edit division')).toBeInTheDocument()
    expect(screen.getByText('Delete division')).toBeInTheDocument()
  })
})

describe('entityRegionColumn', () => {
  const tableConfig = tableOptions.entityRegionColumn(mockHandleEdit)

  const mockData = [
    {
      regionDescription: 'North America',
      regionCode: 'NA',
    },
    {
      regionDescription: 'Europe',
      regionCode: 'EU',
    },
  ]

  test('renders correct table', () => {
    renderTable({ tableConfig, mockData })

    expect(screen.getByText(`${t('regionDescription')}|${t('regionCode')}`)).toBeInTheDocument()

    mockData.forEach((data) => {
      expect(screen.getByText(data.regionDescription)).toBeInTheDocument()
      expect(screen.getByText(data.regionCode)).toBeInTheDocument()
    })

    const dropdownButtons = screen.getAllByLabelText('more')
    fireEvent.click(dropdownButtons[0])
    expect(screen.getByText('Edit region')).toBeInTheDocument()
    expect(screen.getByText('Delete region')).toBeInTheDocument()
  })
})

describe('entityTeamColumn', () => {
  const tableConfig = tableOptions.entityTeamColumn(mockHandleEdit)

  const mockData = [
    {
      teamDescription: 'Sales Team',
      teamCode: 'ST',
    },
    {
      teamDescription: 'Marketing Team',
      teamCode: 'MT',
    },
  ]

  test('renders correct table', () => {
    renderTable({ tableConfig, mockData })

    expect(screen.getByText(`${t('team_Description')}|${t('team_Code')}`)).toBeInTheDocument()

    mockData.forEach((data) => {
      expect(screen.getByText(data.teamDescription)).toBeInTheDocument()
      expect(screen.getByText(data.teamCode)).toBeInTheDocument()
    })

    const dropdownButtons = screen.getAllByLabelText('more')
    fireEvent.click(dropdownButtons[0])
    expect(screen.getByText('Edit Team')).toBeInTheDocument()
    expect(screen.getByText('Delete Team')).toBeInTheDocument()
  })
})

describe('entityServiceProviderColumn', () => {
  const tableConfig = tableOptions.entityServiceProviderColumn(mockHandleEdit)

  const mockData = [
    {
      providerName: 'ABC Provider',
      providerCode: 'ABC',
    },
    {
      providerName: 'XYZ Provider',
      providerCode: 'XYZ',
    },
  ]

  test('renders correct table', () => {
    renderTable({ tableConfig, mockData })

    expect(screen.getByText('Service Provider Name')).toBeInTheDocument()
    expect(screen.getByText('Provider_type')).toBeInTheDocument()

    mockData.forEach((data) => {
      expect(screen.getByText(data.providerName)).toBeInTheDocument()
      expect(screen.getByText(data.providerCode)).toBeInTheDocument()
    })

    const dropdownButtons = screen.getAllByLabelText('more')
    fireEvent.click(dropdownButtons[0])
    expect(screen.getByText('Edit Service Provider')).toBeInTheDocument()
    expect(screen.getByText('Delete Service Provider')).toBeInTheDocument()
  })
})

describe('entitypensionFundSchemeItemColumn', () => {
  const tableConfig = tableOptions.entitypensionFundSchemeItemColumn(mockHandleEdit)

  const mockData = [
    {
      pensionFundSchemeCode: 'PFS001',
      pensionFundSchemeId: 'PFS-001',
      payItemCode: 'PAY001',
      effectiveStartDate: '2023-01-01',
      effectiveEndDate: '2023-12-31',
      status: true,
    },
    {
      pensionFundSchemeCode: 'PFS002',
      pensionFundSchemeId: 'PFS-002',
      payItemCode: 'PAY002',
      effectiveStartDate: '2022-06-01',
      effectiveEndDate: '2023-05-31',
      status: false,
    },
  ]

  test('renders correct table', () => {
    renderTable({ tableConfig, mockData })

    expect(screen.getByText(`${t('Pension fund scheme name')} | ${t('Pension fund scheme ID')}`)).toBeInTheDocument()
    expect(screen.getByText('Pay item')).toBeInTheDocument()
    expect(screen.getByText('pension_fund_schme_item_date')).toBeInTheDocument()
    expect(screen.getByText('status')).toBeInTheDocument()

    mockData.forEach((data) => {
      expect(screen.getByText(data.pensionFundSchemeCode)).toBeInTheDocument()
      expect(screen.getByText(data.pensionFundSchemeId)).toBeInTheDocument()
      expect(screen.getByText(data.payItemCode)).toBeInTheDocument()
      expect(screen.getByText('01 Jan 2023 - 31 Dec 2023')).toBeInTheDocument()
      expect(screen.getByText('01 Jun 2022 - 31 May 2023')).toBeInTheDocument()
      expect(screen.getByText(data.status ? 'Active' : 'Inactive')).toBeInTheDocument()

      const statusLabel = screen.getByText(data.status ? 'Active' : 'Inactive')
      if (data.status) {
        expect(statusLabel).toHaveStyle('color: #00701C; background: #EBFFF0')
      } else {
        expect(statusLabel).toHaveStyle('color: #3B3839; background: #E8E6E7')
      }
    })

    const dropdownButtons = screen.getAllByLabelText('more')
    fireEvent.click(dropdownButtons[0])
    expect(screen.getByText('Edit Pension Fund Scheme Item')).toBeInTheDocument()
    expect(screen.getByText('Delete Pension Fund Scheme Item')).toBeInTheDocument()
  })
})

describe('entityPensionFundSchemeColumn', () => {
  const tableConfig = tableOptions.entityPensionFundSchemeColumn(mockHandleEdit)

  const mockData = [
    {
      pensionFundSchemeCode: 'PFS001',
      schemeDescription: 'Pension Fund Scheme 1',
      schemeFileNumber: 'PFS-001',
      status: 'Active',
    },
    {
      pensionFundSchemeCode: 'PFS002',
      schemeDescription: 'Pension Fund Scheme 2',
      schemeFileNumber: 'PFS-002',
      status: 'Inactive',
    },
  ]

  test('renders correct table', () => {
    renderTable({ tableConfig, mockData })

    expect(screen.getByText('ent_pens_fund_scheme_code_header')).toBeInTheDocument()
    expect(screen.getByText('ent_pens_fund_scheme_code_desc')).toBeInTheDocument()
    expect(screen.getByText('ent_pens_fund_scheme_file_number')).toBeInTheDocument()
    expect(screen.getByText('ent_pens_fund_scheme_status')).toBeInTheDocument()
    expect(screen.getByText('action')).toBeInTheDocument()

    mockData.forEach((data) => {
      expect(screen.getByText(data.pensionFundSchemeCode)).toBeInTheDocument()
      expect(screen.getByText(data.schemeDescription)).toBeInTheDocument()
      expect(screen.getByText(data.schemeFileNumber)).toBeInTheDocument()
      expect(screen.getByText(data.status)).toBeInTheDocument()
    })

    const dropdownButtons = screen.getAllByLabelText('more')
    fireEvent.click(dropdownButtons[0])
    expect(screen.getByRole('presentation')).toBeInTheDocument()
  })
})

describe('entityPositionColumn', () => {
  const tableConfig = tableOptions.entityPositionColumn(mockHandleEdit)

  const mockData = [
    {
      positionDescription: 'Manager',
      positionCode: 'MGR001',
    },
    {
      positionDescription: 'Developer',
      positionCode: 'DEV002',
    },
  ]

  test('renders correct table', () => {
    renderTable({ tableConfig, mockData })

    expect(screen.getByText(`${t('position_Description')}|${t('position_Code')}`)).toBeInTheDocument()

    mockData.forEach((data) => {
      expect(screen.getByText(data.positionDescription)).toBeInTheDocument()
      expect(screen.getByText(data.positionCode)).toBeInTheDocument()
    })

    const dropdownButtons = screen.getAllByLabelText('more')
    fireEvent.click(dropdownButtons[0])
    expect(screen.getByText('Edit Position')).toBeInTheDocument()
    expect(screen.getByText('Delete Position')).toBeInTheDocument()
  })
})

describe('entityCompBankAcctCols', () => {
  const tableConfig = tableOptions.entityCompBankAcctCols(mockHandleEdit)

  const mockData = [
    {
      companyBankAccountCode: 'BANK001',
      companyBankAccountDescription: 'Company Bank Account 1',
      status: 'Active',
      remarks: 'Main company bank account',
    },
    {
      companyBankAccountCode: 'BANK002',
      companyBankAccountDescription: 'Company Bank Account 2',
      status: 'Inactive',
      remarks: 'Backup company bank account',
    },
  ]

  test('renders correct table', () => {
    renderTable({ tableConfig, mockData })

    expect(screen.getByText(t('ent_comp_bank_acct_col_header_code'))).toBeInTheDocument()
    expect(screen.getByText(t('ent_comp_bank_acct_col_header_desc'))).toBeInTheDocument()
    expect(screen.getByText(t('ent_comp_bank_acct_col_header_status'))).toBeInTheDocument()
    expect(screen.getByText(t('remarks'))).toBeInTheDocument()
    expect(screen.getByText('action')).toBeInTheDocument()

    mockData.forEach((data) => {
      expect(screen.getByText(data.companyBankAccountCode)).toBeInTheDocument()
      expect(screen.getByText(data.companyBankAccountDescription)).toBeInTheDocument()
      expect(screen.getByText(data.status)).toBeInTheDocument()
      expect(screen.getByText(data.remarks)).toBeInTheDocument()
    })

    const dropdownButtons = screen.getAllByLabelText('more')
    fireEvent.click(dropdownButtons[0])
  })
})

describe('entitySettingsCulumns', () => {
  const tableConfig = tableOptions.entitySettingsCulumns(mockHandleEdit)

  const mockData = [
    {
      settingCode: 'SETTING001',
      settingName: 'Entity Setting 1',
      category: 'General',
    },
    {
      settingCode: 'SETTING002',
      settingName: 'Entity Setting 2',
      category: 'Advanced',
    },
  ]

  test('renders correct table', () => {
    renderTable({ tableConfig, mockData })

    expect(screen.getByText(`${t('Entity setting name')}|${t('Entity setting id')}`)).toBeInTheDocument()
    expect(screen.getByText('category')).toBeInTheDocument()

    mockData.forEach((data) => {
      expect(screen.getByText(data.settingCode)).toBeInTheDocument()
      expect(screen.getByText(data.settingName)).toBeInTheDocument()
      expect(screen.getByText(data.category)).toBeInTheDocument()
    })

    const dropdownButtons = screen.getAllByLabelText('more')
    fireEvent.click(dropdownButtons[0])
    expect(screen.getByText('Edit Setting')).toBeInTheDocument()
    expect(screen.getByText('Delete Setting')).toBeInTheDocument()
  })
})

describe('entityCurrencyExchangeColumn', () => {
  const tableConfig = tableOptions.entityCurrencyExchangeColumn(mockHandleEdit)

  const mockData = [
    {
      currencyFrom: 'HKD',
      currencyTo: 'EUR',
      effectiveDate: '2023-06-01',
      conversionMethod: 'Direct',
      exchangeRate: '0.91',
    },
    {
      currencyFrom: 'GBP',
      currencyTo: 'USD',
      effectiveDate: '2023-07-15',
      conversionMethod: 'Indirect',
      exchangeRate: '1.25',
    },
  ]

  test('renders correct table', () => {
    renderTable({ tableConfig, mockData })

    expect(screen.getByText(`${t('Currency from')} → ${t('Currency to')}`)).toBeInTheDocument()
    expect(screen.getByText('ent_curr_exch_currency_effective_dt')).toBeInTheDocument()
    expect(screen.getByText('ent_curr_exch_conversion_method')).toBeInTheDocument()
    expect(screen.getByText('ent_curr_exch_rate')).toBeInTheDocument()

    mockData.forEach((data) => {
      expect(screen.getByText(data.currencyFrom)).toBeInTheDocument()
      expect(screen.queryAllByText('→')).toHaveLength(2)
      expect(screen.getByText(data.currencyTo)).toBeInTheDocument()
      expect(screen.getByText(new Date(data.effectiveDate).toLocaleDateString('en-GB', {
        day: '2-digit',
        month: 'long',
        year: 'numeric',
      }))).toBeInTheDocument()
      expect(screen.getByText(data.conversionMethod)).toBeInTheDocument()
      expect(screen.getByText(data.exchangeRate)).toBeInTheDocument()
    })

    const dropdownButtons = screen.getAllByLabelText('more')
    fireEvent.click(dropdownButtons[0])
    expect(screen.getByText('Edit currency exchange')).toBeInTheDocument()
    expect(screen.getByText('Delete currency exchange')).toBeInTheDocument()
  })
})

describe('entityGradeColumn', () => {
  const tableConfig = tableOptions.entityGradeColumn(mockHandleEdit)

  const mockData = [
    {
      gradeDescription: 'Senior Manager',
      gradeCode: 'SM001',
    },
    {
      gradeDescription: 'Junior Analyst',
      gradeCode: 'JA001',
    },
  ]

  test('renders correct table', () => {
    renderTable({ tableConfig, mockData })

    expect(screen.getByText(`${t('ent_grade_description')}|${t('ent_grade_code')}`)).toBeInTheDocument()

    mockData.forEach((data) => {
      expect(screen.getByText(data.gradeDescription)).toBeInTheDocument()
      expect(screen.getByText(data.gradeCode)).toBeInTheDocument()
    })

    const dropdownButtons = screen.getAllByLabelText('more')
    fireEvent.click(dropdownButtons[0])
    expect(screen.getByText('Edit Grade')).toBeInTheDocument()
    expect(screen.getByText('Delete Grade')).toBeInTheDocument()
  })
})

describe('entityEmpMovementConfigurationColumn', () => {
  const tableConfig = tableOptions.entityEmpMovementConfigurationColumn(mockHandleEdit)

  const mockData = [
    {
      movementType: 'Promotion',
      fieldName: 'Job Title',
    },
    {
      movementType: 'Transfer',
      fieldName: 'Department',
    },
  ]

  test('renders correct table', () => {
    renderTable({ tableConfig, mockData })

    expect(screen.getByText('ent_emp_movement_configuration_movement_type')).toBeInTheDocument()
    expect(screen.getByText('ent_emp_movement_configuration_field_name')).toBeInTheDocument()
    expect(screen.getByText('action')).toBeInTheDocument()

    mockData.forEach((data) => {
      expect(screen.getByText(data.movementType)).toBeInTheDocument()
      expect(screen.getByText(data.fieldName)).toBeInTheDocument()
    })

    const dropdownButtons = screen.getAllByLabelText('more')
    fireEvent.click(dropdownButtons[0])
    expect(screen.getByText('Edit')).toBeInTheDocument()
    expect(screen.getByText('Delete')).toBeInTheDocument()
  })
})

describe('entityWorkCalenderColumn', () => {
  const tableConfig = tableOptions.entityWorkCalenderColumn(mockHandleEdit)

  const mockData = [
    {
      workCalendarCode: 'WC001',
      workCalendarName: 'Standard Work Calendar',
    },
    {
      workCalendarCode: 'WC002',
      workCalendarName: 'Shift Work Calendar',
    },
  ]

  test('renders correct table', () => {
    renderTable({ tableConfig, mockData })

    expect(screen.getByText(`${t('ent_work_calendar_code')} | ${t('ent_work_calendar_name')}`)).toBeInTheDocument()
    expect(screen.getByText('action')).toBeInTheDocument()

    mockData.forEach((data) => {
      expect(screen.getByText(data.workCalendarCode)).toBeInTheDocument()
      expect(screen.getByText(data.workCalendarName)).toBeInTheDocument()
    })

    const actionMenuButtons = screen.getAllByLabelText('more')
    fireEvent.click(actionMenuButtons[0])
    expect(screen.getByText(t('Edit work calendar'))).toBeInTheDocument()
    fireEvent.click(screen.getByText(t('Edit work calendar')))
    expect(mockHandleEdit).toHaveBeenCalledTimes(1)
    expect(screen.getByText(t('Delete work calendar'))).toBeInTheDocument()
    fireEvent.click(screen.getByText(t('Delete work calendar')))
    expect(mockHandleEdit).toHaveBeenCalledTimes(2)
  })
})

describe('entityProfileColumn', () => {
  const tableConfig = tableOptions.entityProfileColumn(mockHandleEdit)

  const mockData = [
    {
      entityCode: 'ENT001',
      entityName: 'Entity A',
      status: true,
    },
    {
      entityCode: 'ENT002',
      entityName: 'Entity B',
      status: false,
    },
  ]

  test('renders correct table', () => {
    renderTable({ tableConfig, mockData })

    expect(screen.getByText(`${t('Entity ID')} | ${t('Entity Name')}`)).toBeInTheDocument()
    expect(screen.getByText('entity_profile_status')).toBeInTheDocument()
    expect(screen.getByText('action')).toBeInTheDocument()

    mockData.forEach((data) => {
      expect(screen.getByText(data.entityCode)).toBeInTheDocument()
      expect(screen.getByText(data.entityName)).toBeInTheDocument()

      const statusLabel = screen.getByText(data.status ? 'Active' : 'Inactive')
      expect(statusLabel).toBeInTheDocument()
      expect(statusLabel).toHaveStyle({
        background: data.status ? '#EBFFF0' : '#E8E6E7',
        color: data.status ? '#00701C' : '#3B3839',
      })
    })

    const dropdownButtons = screen.getAllByLabelText('more')
    fireEvent.click(dropdownButtons[0])
  })
})

describe('entityStaffTypeColumn', () => {
  const tableConfig = tableOptions.entityStaffTypeColumn(mockHandleEdit)

  const mockData = [
    {
      staffTypeDescription: 'Full-Time',
      staffTypeCode: 'FT',
    },
    {
      staffTypeDescription: 'Part-Time',
      staffTypeCode: 'PT',
    },
  ]

  test('renders correct table', () => {
    renderTable({ tableConfig, mockData })

    expect(screen.getByText(`${t('staff_Type_Description')} | ${t('staff_Type_Code')}`)).toBeInTheDocument()

    mockData.forEach((data) => {
      expect(screen.getByText(data.staffTypeDescription)).toBeInTheDocument()
      expect(screen.getByText(data.staffTypeCode)).toBeInTheDocument()
    })

    const dropdownButtons = screen.getAllByLabelText('more')
    fireEvent.click(dropdownButtons[0])
    expect(screen.getByText('Edit Staff Type')).toBeInTheDocument()
    expect(screen.getByText('Delete Staff Type')).toBeInTheDocument()
  })
})

describe('entityEmployeeMovementTypeColumn', () => {
  const tableConfig = tableOptions.entityEmployeeMovementTypeColumn(mockHandleEdit)

  const mockData = [
    {
      movementType: 'Promotion',
      movementDescription: 'Promotion to a higher position',
      status: true,
    },
    {
      movementType: 'Transfer',
      movementDescription: 'Transfer to a different department',
      status: false,
    },
  ]

  test('renders correct table', () => {
    renderTable({ tableConfig, mockData })

    expect(screen.getByText('ent_emp_move_type_movement_type')).toBeInTheDocument()
    expect(screen.getByText('ent_emp_move_type_movement_description')).toBeInTheDocument()
    expect(screen.getByText('status')).toBeInTheDocument()

    mockData.forEach((data) => {
      expect(screen.getByText(data.movementType)).toBeInTheDocument()
      expect(screen.getByText(data.movementDescription)).toBeInTheDocument()

      const statusElement = screen.getByText(data.status ? 'Active' : 'Inactive')
      expect(statusElement).toBeInTheDocument()
      expect(statusElement).toHaveStyle({
        background: data.status ? '#E8E6E7' : '#EBFFF0',
      })
    })

    const dropdownButtons = screen.getAllByLabelText('more')
    fireEvent.click(dropdownButtons[0])
    expect(screen.getByText('Edit movement type')).toBeInTheDocument()
    expect(screen.getByText('Delete movement type')).toBeInTheDocument()
  })
})

describe('employeeMovementColumn', () => {
  const tableConfig = tableOptions.employeeMovementColumn(mockHandleEdit)

  const mockData = [
    {
      movementType: 'Promotion',
      effectiveDate: '2023-05-01',
    },
    {
      movementType: 'Transfer',
      effectiveDate: '2023-06-15',
    },
  ]

  test('renders correct table', () => {
    renderTable({ tableConfig, mockData })

    expect(screen.getByText('ent_emp_move_type_movement_type')).toBeInTheDocument()
    expect(screen.getByText('ent_curr_exch_currency_effective_dt')).toBeInTheDocument()

    mockData.forEach((data) => {
      expect(screen.getByText(data.movementType)).toBeInTheDocument()

      const formattedStartDate = new Date(data.effectiveDate).toLocaleDateString('en-GB', {
        day: '2-digit',
        month: 'short',
        year: 'numeric',
      })
      expect(screen.getByText(formattedStartDate)).toBeInTheDocument()
    })

    const dropdownButtons = screen.getAllByLabelText('more')
    fireEvent.click(dropdownButtons[0])
    expect(screen.getByText('Edit Movement')).toBeInTheDocument()
    expect(screen.getByText('Withdraw Movement')).toBeInTheDocument()
  })
})

describe('employeeAverageWageColumn', () => {
  const months = ['January', 'February', 'March', 'April', 'May', 'June',
    'July', 'August', 'September', 'October', 'November', 'December']
  const tableConfig = tableOptions.employeeAverageWageColumn(mockHandleEdit)

  const mockData = [
    {
      year: 2021,
      month: 5,
      regardedWagesStartDate: '2021-05-01',
      regardedWagesEndDate: '2021-05-31',
      coveredDay: 31,
      last12MonthRegardedWages: 40000.0,
      disregardedDays: 5,
      averageDailyWages: 1612.9,
      averageMonthlyWages: 50000.0,
      currency: 'HKD',
    },
    {
      year: 2022,
      month: 6,
      regardedWagesStartDate: '2022-06-01',
      regardedWagesEndDate: '2022-06-30',
      coveredDay: 30,
      last12MonthRegardedWages: 42000.0,
      disregardedDays: 2,
      averageDailyWages: 1733.3,
      averageMonthlyWages: 52000.0,
      currency: 'USD',
    },
  ]

  test('renders correct table', () => {
    renderTable({ tableConfig, mockData })

    expect(screen.getByText('Pay cycle month & year')).toBeInTheDocument()
    expect(screen.getByText('Start - End date | Covered days')).toBeInTheDocument()
    expect(screen.getByText('Last 12 months regarded wages')).toBeInTheDocument()
    expect(screen.getByText('Disregarded days')).toBeInTheDocument()
    expect(screen.getByText('Daily Average | Monthly Average')).toBeInTheDocument()

    mockData.forEach((data) => {
      expect(screen.getByText(months[data.month - 1])).toBeInTheDocument()
      expect(screen.getByText(data.year.toString())).toBeInTheDocument()

      expect(screen.getByText(`${customDateFormate(data.regardedWagesStartDate)} - ${customDateFormate(data.regardedWagesEndDate)} ${data.coveredDay}`)).toBeInTheDocument()
      expect(screen.getByText(data.last12MonthRegardedWages.toString())).toBeInTheDocument()
      expect(screen.getByText(data.disregardedDays.toString())).toBeInTheDocument()
      expect(screen.getByText(`${data.currency} ${data.averageDailyWages.toString()}`)).toBeInTheDocument()
      expect(screen.getByText(`${data.currency} ${data.averageMonthlyWages.toString()}`)).toBeInTheDocument()
    })

    const dropdownButtons = screen.getAllByLabelText('more')
    fireEvent.click(dropdownButtons[0])
    expect(screen.getByText('Edit disregarded day')).toBeInTheDocument()
  })
})

describe('entitypensionFundSchemeRuleCols', () => {
  const tableConfig = tableOptions.entitypensionFundSchemeRuleCols(mockHandleEdit)

  const mockData = [
    {
      pensionFundSchemeRuleType: 'Pension Rule Type 1',
      effectiveStartDate: '2023-01-01',
      effectiveEndDate: '2023-12-31',
      relevantIncomeMinAmount: 1000.0,
      relevantIncomeMaxAmount: 5000.0,
    },
    {
      pensionFundSchemeRuleType: 'Pension Rule Type 2',
      effectiveStartDate: '2024-01-01',
      effectiveEndDate: '2024-12-31',
      relevantIncomeMinAmount: 2000.0,
      relevantIncomeMaxAmount: 6000.0,
    },
  ]

  test('renders correct table columns', () => {
    renderTable({ tableConfig, mockData })

    expect(screen.getByText('ent_pens_fund_scheme_rule_type')).toBeInTheDocument()
    mockData.forEach((data) => {
      expect(screen.getByText(data.pensionFundSchemeRuleType)).toBeInTheDocument()
    })

    expect(screen.getByText('pension_fund_schme_item_date')).toBeInTheDocument()
    mockData.forEach((data) => {
      const startDate = new Date(data.effectiveStartDate)
      const endDate = new Date(data.effectiveEndDate)
      const formattedStartDate = startDate.toLocaleDateString('en-GB', {
        day: '2-digit',
        month: 'short',
        year: 'numeric',
      })
      const formattedEndDate = endDate.toLocaleDateString('en-GB', {
        day: '2-digit',
        month: 'short',
        year: 'numeric',
      })
      expect(screen.getByText(`${formattedStartDate} - ${formattedEndDate}`)).toBeInTheDocument()
    })

    expect(screen.getByText('Relevant income min - max')).toBeInTheDocument()
    mockData.forEach((data) => {
      const minAmount = data.relevantIncomeMinAmount.toFixed(2)
      const maxAmount = data.relevantIncomeMaxAmount.toFixed(2)
      expect(screen.getByText(`${minAmount} - ${maxAmount}`)).toBeInTheDocument()
    })

    const dropdownButtons = screen.getAllByLabelText('more')
    fireEvent.click(dropdownButtons[0])
    expect(screen.getByText('Edit Pension Fund Scheme Rule')).toBeInTheDocument()
    expect(screen.getByText('Delete Pension Fund Scheme Rule')).toBeInTheDocument()
  })
})

describe('costCenterConfigurationColumn', () => {
  const tableConfig = tableOptions.abc(mockHandleEdit)

  const mockData = [
    {
      costCenterDescription: 'Cost Center 1',
      costCenterCode: 'CC001',
    },
    {
      costCenterDescription: 'Cost Center 2',
      costCenterCode: 'CC002',
    },
  ]

  test('renders correct table', () => {
    renderTable({ tableConfig, mockData })

    expect(screen.getByText('cost_Center_Description | cost_Center_Code')).toBeInTheDocument()

    mockData.forEach((data) => {
      expect(screen.getByText(data.costCenterDescription)).toBeInTheDocument()
      expect(screen.getByText(data.costCenterCode)).toBeInTheDocument()
    })

    const dropdownButtons = screen.getAllByLabelText('more')
    fireEvent.click(dropdownButtons[0])
    expect(screen.getByText('Edit cost center')).toBeInTheDocument()
    expect(screen.getByText('Delete cost center')).toBeInTheDocument()
  })
})

describe('personEmployeeColumn', () => {
  const tableConfig = tableOptions.personEmployeeColumn(mockHandleEdit)

  const mockData = [
    {
      id: '1',
      personName: 'John Doe',
      clientGroupProfileId: 'ABCD',
    },
    {
      id: '2',
      personName: 'Jane Smith',
      clientGroupProfileId: 'EFGH',
    },
  ]

  test('renders correct table', () => {
    renderTable({ tableConfig, mockData })

    expect(screen.getByText('person_id')).toBeInTheDocument()
    expect(screen.getByText('person_name')).toBeInTheDocument()
    expect(screen.getByText('current_entity_code')).toBeInTheDocument()
    expect(screen.getByText('action')).toBeInTheDocument()

    mockData.forEach((data) => {
      expect(screen.getByText(data.id)).toBeInTheDocument()
      expect(screen.getByText(data.personName)).toBeInTheDocument()
      expect(screen.getByText(data.clientGroupProfileId)).toBeInTheDocument()
    })

    const dropdownButtons = screen.getAllByLabelText('more')
    fireEvent.click(dropdownButtons[0])
  })
})

describe('standardExpressionColumn', () => {
  const tableConfig = tableOptions.standardExpressionColumn(mockHandleEdit)

  const mockData = [
    {
      expressionCode: 'EXP001',
    },
    {
      expressionCode: 'EXP002',
    },
  ]

  test('renders correct table', () => {
    renderTable({ tableConfig, mockData })

    expect(screen.getByText('expression_code')).toBeInTheDocument()
    expect(screen.getByText('action')).toBeInTheDocument()

    mockData.forEach((data) => {
      expect(screen.getByText(data.expressionCode)).toBeInTheDocument()
    })

    const dropdownButtons = screen.getAllByLabelText('more')
    fireEvent.click(dropdownButtons[0])
  })
})

describe('standardFormulaColumn', () => {
  const tableConfig = tableOptions.standardFormulaColumn(mockHandleEdit)

  const mockData = [
    {
      formulaCode: 'FORM001',
    },
    {
      formulaCode: 'FORM002',
    },
  ]

  test('renders correct table', () => {
    renderTable({ tableConfig, mockData })

    expect(screen.getByText('formula_code')).toBeInTheDocument()
    expect(screen.getByText('action')).toBeInTheDocument()

    mockData.forEach((data) => {
      expect(screen.getByText(data.formulaCode)).toBeInTheDocument()
    })

    const dropdownButtons = screen.getAllByLabelText('more')
    fireEvent.click(dropdownButtons[0])
  })
})

describe('providerTypeColumn', () => {
  const tableConfig = tableOptions.providerTypeColumn(mockHandleEdit)

  const mockData = [
    {
      providerCode: 'PROV001',
      providerName: 'Provider A',
      providerType: 'Hospital',
      countryLocalization: 'USA',
    },
    {
      providerCode: 'PROV002',
      providerName: 'Provider B',
      providerType: 'Clinic',
      countryLocalization: 'Canada',
    },
  ]

  test('renders correct table', () => {
    renderTable({ tableConfig, mockData })

    expect(screen.getByText(`${t('Provider Name')} | ${t('Provider ID')}`)).toBeInTheDocument()
    expect(screen.getByText('provider_type')).toBeInTheDocument()
    expect(screen.getByText('Provider_types_country')).toBeInTheDocument()

    mockData.forEach((data) => {
      expect(screen.getByText(data.providerCode)).toBeInTheDocument()
      expect(screen.getByText(data.providerName)).toBeInTheDocument()
      expect(screen.getByText(data.providerType)).toBeInTheDocument()
      expect(screen.getByText(data.countryLocalization)).toBeInTheDocument()
    })

    const dropdownButtons = screen.getAllByLabelText('more')
    fireEvent.click(dropdownButtons[0])
    expect(screen.getByText('Edit Provider type')).toBeInTheDocument()
    expect(screen.getByText('Delete Provider type')).toBeInTheDocument()
  })
})

describe('userAccountsColumn', () => {
  const tableConfig = tableOptions.userAccountsColumn(mockHandleEdit)

  const mockData = [
    {
      firstName: 'John',
      lastName: 'Doe',
      username: 'johndoe',
      entityCount: 3,
      accountStatus: 'Active',
    },
    {
      firstName: 'Jane',
      lastName: 'Doe',
      username: 'janedoe',
      entityCount: 2,
      accountStatus: 'Inactive',
    },
  ]

  test('renders correct table', () => {
    renderTable({ tableConfig, mockData })

    expect(screen.getByText('name_userid')).toBeInTheDocument()
    expect(screen.getByText('entities')).toBeInTheDocument()
    expect(screen.getByText('status')).toBeInTheDocument()
    expect(screen.getByText('action')).toBeInTheDocument()

    mockData.forEach((data) => {
      expect(screen.getByText(`${data.firstName} ${data.lastName}`)).toBeInTheDocument()
      expect(screen.getByText(data.username)).toBeInTheDocument()
      expect(screen.getByText(`${data.entityCount} entities`)).toBeInTheDocument()
      expect(screen.getByText(data.accountStatus)).toBeInTheDocument()
    })

    const activeUserMenuOptions = screen.getAllByLabelText('more')[0]
    fireEvent.click(activeUserMenuOptions)
    expect(screen.getByText(`${t('Edit user account')}`)).toBeInTheDocument()
    fireEvent.click(screen.getByText(`${t('Edit user account')}`))
    expect(mockHandleEdit).toHaveBeenCalledTimes(1)
    expect(screen.getByText(`${t('Duplicate user access')}`)).toBeInTheDocument()
    fireEvent.click(screen.getByText(`${t('Duplicate user access')}`))
    expect(mockHandleEdit).toHaveBeenCalledTimes(2)
    expect(screen.getByText(`${t('Deactivate user account')}`)).toBeInTheDocument()
    fireEvent.click(screen.getByText(`${t('Deactivate user account')}`))
    expect(mockHandleEdit).toHaveBeenCalledTimes(3)
    expect(screen.getByText(`${t('Delete user account')}`)).toBeInTheDocument()
    fireEvent.click(screen.getByText(`${t('Delete user account')}`))
    expect(mockHandleEdit).toHaveBeenCalledTimes(4)
  })

  test('renders correct table when user is inactive', () => {
    renderTable({ tableConfig, mockData })
    const inactiveUserMenuOptions = screen.getAllByLabelText('more')[1]
    fireEvent.click(inactiveUserMenuOptions)
    expect(screen.getByText(`${t('Activate user account')}`)).toBeInTheDocument()
    fireEvent.click(screen.getByText(`${t('Activate user account')}`))
    expect(mockHandleEdit).toHaveBeenCalledTimes(1)
    expect(screen.getByText(`${t('Edit user account')}`)).toBeInTheDocument()
    fireEvent.click(screen.getByText(`${t('Edit user account')}`))
    expect(mockHandleEdit).toHaveBeenCalledTimes(2)
    expect(screen.getByText(`${t('Duplicate user access')}`)).toBeInTheDocument()
    fireEvent.click(screen.getByText(`${t('Duplicate user access')}`))
    expect(mockHandleEdit).toHaveBeenCalledTimes(3)
    expect(screen.getByText(`${t('Delete user account')}`)).toBeInTheDocument()
    fireEvent.click(screen.getByText(`${t('Delete user account')}`))
    expect(mockHandleEdit).toHaveBeenCalledTimes(4)
  })
})

describe('entityTerminationCodeColumn', () => {
  const tableConfig = tableOptions.entityTerminationCodeColumn(mockHandleEdit)

  const mockData = [
    {
      terminationReason: 'Resignation',
      terminationCode: 'RES001',
    },
    {
      terminationReason: 'Retirement',
      terminationCode: 'RET002',
    },
  ]

  test('renders correct table', () => {
    renderTable({ tableConfig, mockData })

    expect(screen.getByText(`${t('termination_description')}|${t('termination_code')}`)).toBeInTheDocument()

    mockData.forEach((data) => {
      expect(screen.getByText(data.terminationReason)).toBeInTheDocument()
      expect(screen.getByText(data.terminationCode)).toBeInTheDocument()
    })

    const dropdownButtons = screen.getAllByLabelText('more')
    fireEvent.click(dropdownButtons[0])
    expect(screen.getByText('Edit Termination Code')).toBeInTheDocument()
    expect(screen.getByText('Delete Termination Code')).toBeInTheDocument()
  })
})

const getRoleTypDescription = (roleType: boolean) => {
  if (roleType) {
    return 'System Admin'
  }
  return 'Regular User'
}

describe('userRolesColumn', () => {
  const tableConfig = tableOptions.userRolesColumn(mockHandleEdit)

  const mockData = [
    {
      roleCode: 'ADMIN001',
      roleName: 'System Administrator',
      roleType: true,
      userCount: 10,
    },
    {
      roleCode: 'USER001',
      roleName: 'Regular Guy',
      roleType: false,
      userCount: 25,
    },
  ]

  test('renders correct table', () => {
    renderTable({ tableConfig, mockData })

    expect(screen.getByText('user_roles_column_role_name_id')).toBeInTheDocument()
    expect(screen.getByText('user_roles_column_role_type')).toBeInTheDocument()
    expect(screen.getByText('user_roles_column_number_of_users_granted')).toBeInTheDocument()
    expect(screen.getByText('action')).toBeInTheDocument()

    mockData.forEach((data) => {
      expect(screen.getByText(data.roleName)).toBeInTheDocument()
      expect(screen.getByText(data.roleCode)).toBeInTheDocument()
      expect(screen.getByText(getRoleTypDescription(data.roleType))).toBeInTheDocument()
      expect(screen.getByText(`${data.userCount}`)).toBeInTheDocument()
    })

    const dropdownButtons = screen.getAllByLabelText('more')
    fireEvent.click(dropdownButtons[0])
    expect(screen.getByText('Edit user role')).toBeInTheDocument()
    expect(screen.getByText('Delete user role')).toBeInTheDocument()
  })
})

describe('uerRoleSelectColumn', () => {
  const tableConfig = tableOptions.uerRoleSelectColumn(mockHandleClick)

  const mockData = [
    {
      entityName: 'Entity A',
      clientGroupName: 'Client Group 1',
      userRole: 'Admin',
    },
    {
      entityName: 'Entity B',
      clientGroupName: 'Client Group 2',
      userRole: 'User',
    },
  ]

  test('renders correct table', () => {
    renderTable({ tableConfig, mockData })

    expect(screen.getByText('Entity')).toBeInTheDocument()
    expect(screen.getByText('client_group')).toBeInTheDocument()
    expect(screen.getByText('user_role_title')).toBeInTheDocument()

    mockData.forEach((data) => {
      expect(screen.getByText(data.entityName)).toBeInTheDocument()
      expect(screen.getByText(data.clientGroupName)).toBeInTheDocument()
      expect(screen.getByText(data.userRole)).toBeInTheDocument()
    })
  })
})

describe('employeeProfileColumn', () => {
  const tableConfig = tableOptions.employeeProfileColumn(mockHandleEdit)

  const mockData = [
    {
      employeeCode: 'EMP001',
      employeeProfile: {
        givenName: 'John Doe',
        payrollIndicator: 'ActivePayroll',
        employmentStatus: 'ActiveEmployment',
      },
      commencementDate: '2022-01-01',
    },
    {
      employeeCode: 'EMP002',
      employeeProfile: {
        givenName: 'Jane Smith',
        payrollIndicator: 'InactivePayroll',
      },
      commencementDate: '2021-06-15',
    },
  ]

  test('renders correct table', () => {
    renderTable({ tableConfig, mockData })

    expect(screen.getByText('Employee name | Employee ID')).toBeInTheDocument()
    expect(screen.getByText('Commencement date')).toBeInTheDocument()
    expect(screen.getByText('Payroll indicator')).toBeInTheDocument()
    expect(screen.getByText('Employment status')).toBeInTheDocument()
    expect(screen.getByText('action')).toBeInTheDocument()

    mockData.forEach((data) => {
      expect(screen.getByText(data.employeeProfile.givenName)).toBeInTheDocument()
      expect(screen.getByText(data.employeeCode)).toBeInTheDocument()
      expect(screen.getByText(
        new Intl.DateTimeFormat('en-GB', { year: 'numeric', month: 'short', day: '2-digit' }).format(new Date(data.commencementDate)).split(' ').join(' '),
      )).toBeInTheDocument()
      expect(screen.getByText(data.employeeProfile.payrollIndicator)).toBeInTheDocument()
    })

    const statusLabelActive = screen.queryAllByTestId('label')[4]
    const statusLabelInactive = screen.queryAllByTestId('label')[9]
    expect(screen.getByText('ActiveEmployment')).toBeInTheDocument()
    expect(statusLabelActive).toHaveStyle('color: #00701C; background: #EBFFF0')
    expect(statusLabelInactive).toHaveStyle('color: #3B3839; background: #E8E6E7')

    const dropdownButtons = screen.getAllByLabelText('more')
    fireEvent.click(dropdownButtons[0])
    expect(screen.getByText('Delete Employee Profile')).toBeInTheDocument()
  })
})
