// test is incomplete, can't seem to test if listofoptions appear when selectbox is clicked
import '@testing-library/jest-dom/extend-expect'

import { createTheme, ThemeProvider } from '@mui/material/styles'
import { fireEvent, render, screen } from '@testing-library/react'

import OPREnhancedTable from './OPREnhancedTable'

const theme = createTheme()

const mockListOfOptions = [
  { roleName: 'Admin', id: 1 },
  { roleName: 'User', id: 2 },
  { roleName: 'Guest', id: 3 },
]

const mockCols = [
  { key: 'username', title: 'Username', sorting: true },
  { key: 'emailAddress', title: 'Email Address', sorting: false },
  { key: 'userRole', title: 'User Role', sorting: false },
]

const mockData = [
  {
    id: 1, username: 'john_doe', emailAddress: 'john@example.com', employeeCode: 'E001', userRole: [],
  },
  {
    id: 2, username: 'jane_doe', emailAddress: 'jane@example.com', employeeCode: 'E002', userRole: [],
  },
]

const mockOnRequestSort = jest.fn()
const mockHandleClick = jest.fn()
const mockHandleUserClick = jest.fn()
const mockIsSelected = jest.fn().mockReturnValue(false)

jest.mock('react-i18next', () => ({
  useTranslation: () => ({
    t: (key: any) => key,
  }),
}))

describe('OPREnhancedTable Component', () => {
  beforeEach(() => {
    jest.clearAllMocks()
  })

  it('renders the table with headers', () => {
    render(
      <ThemeProvider theme={theme}>
        <OPREnhancedTable
          cols={mockCols}
          data={mockData}
          handleClick={mockHandleClick}
          handleUserClick={mockHandleUserClick}
          isLoader={false}
          isSelected={mockIsSelected}
          listOfOptions={[]}
          orderBy="username"
          sortBy="username"
          steps={0}
          onRequestSort={mockOnRequestSort}
        />
      </ThemeProvider>,
    )

    mockCols.forEach((col) => {
      expect(screen.getByText(col.title)).toBeInTheDocument()
    })
  })

  it('renders the correct number of rows', () => {
    render(
      <ThemeProvider theme={theme}>
        <OPREnhancedTable
          cols={mockCols}
          data={mockData}
          handleClick={mockHandleClick}
          handleUserClick={mockHandleUserClick}
          isLoader={false}
          isSelected={mockIsSelected}
          listOfOptions={[]}
          orderBy="username"
          sortBy="username"
          steps={0}
          onRequestSort={mockOnRequestSort}
        />
      </ThemeProvider>,
    )

    const rows = screen.getAllByRole('checkbox')
    expect(rows).toHaveLength(mockData.length)
  })

  it('calls onRequestSort when a sortable header is clicked', () => {
    render(
      <ThemeProvider theme={theme}>
        <OPREnhancedTable
          cols={mockCols}
          data={mockData}
          handleClick={mockHandleClick}
          handleUserClick={mockHandleUserClick}
          isLoader={false}
          isSelected={mockIsSelected}
          listOfOptions={[]}
          orderBy="username"
          sortBy="username"
          steps={0}
          onRequestSort={mockOnRequestSort}
        />
      </ThemeProvider>,
    )

    fireEvent.click(screen.getByText('Username'))

    expect(mockOnRequestSort).toHaveBeenCalled()
  })

  it('renders correctly with initial state', () => {
    render(
      <ThemeProvider theme={theme}>
        <OPREnhancedTable
          orderBy
          cols={mockCols}
          data={mockData}
          handleClick={mockHandleClick}
          handleUserClick={mockHandleUserClick}
          isLoader={false}
          isSelected={mockIsSelected}
          listOfOptions={mockListOfOptions}
          sortBy="username"
          steps={2}
          onRequestSort={mockOnRequestSort}
        />
      </ThemeProvider>,
    )

    mockCols.forEach((col) => {
      expect(screen.getByText(col.title)).toBeInTheDocument()
    })

    mockData.forEach((item) => {
      expect(screen.getByText(item.employeeCode)).toBeInTheDocument()
    })
  })

  it('renders loading state when isLoader is true', () => {
    render(
      <ThemeProvider theme={theme}>
        <OPREnhancedTable
          isLoader
          cols={mockCols}
          data={mockData}
          handleClick={mockHandleClick}
          handleUserClick={mockHandleUserClick}
          isSelected={mockIsSelected}
          listOfOptions={[]}
          orderBy="username"
          sortBy="username"
          steps={0}
          onRequestSort={mockOnRequestSort}
        />
      </ThemeProvider>,
    )

    expect(screen.getByText('Loading...')).toBeInTheDocument()
  })

  it('calls handleClick when a row is clicked', () => {
    render(
      <ThemeProvider theme={theme}>
        <OPREnhancedTable
          cols={mockCols}
          data={mockData}
          handleClick={mockHandleClick}
          handleUserClick={mockHandleUserClick}
          isLoader={false}
          isSelected={mockIsSelected}
          listOfOptions={[]}
          orderBy="username"
          sortBy="username"
          steps={1}
          onRequestSort={mockOnRequestSort}
        />
      </ThemeProvider>,
    )

    fireEvent.click(screen.getByText(mockData[0].employeeCode))

    expect(mockHandleClick).toHaveBeenCalled()
  })

  it('should call handleUserClick when the button is clicked', () => {
    render(
      <ThemeProvider theme={theme}>
        <OPREnhancedTable
          isDuplicate
          cols={mockCols}
          data={mockData}
          handleClick={mockHandleClick}
          handleUserClick={mockHandleUserClick}
          isLoader={false}
          isSelected={mockIsSelected}
          listOfOptions={[]}
          orderBy="username"
          sortBy="username"
          steps={0}
          onRequestSort={mockOnRequestSort}
        />
      </ThemeProvider>,
    )

    const userButton = screen.getAllByTestId('user-button')[0]
    fireEvent.click(userButton)

    expect(mockHandleUserClick).toHaveBeenCalledWith(mockData[0])
  })
})
