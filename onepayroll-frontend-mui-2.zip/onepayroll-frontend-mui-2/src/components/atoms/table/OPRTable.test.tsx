// jest test is incomplete
// need to test sorting function
import '@testing-library/jest-dom/extend-expect'

import { fireEvent, render, screen } from '@testing-library/react'

import OPRTable from './OPRTable'

const mockData = [
  { id: 1, name: 'John Doe', logFile: 'log1.txt' },
  { id: 2, name: 'Jane Smith', logFile: 'log2.txt' },
]

const mockCols = [
  {
    key: 'name', title: 'Name', sorting: true, render: (item: { name: any }) => item.name,
  },
  {
    key: 'logFile', title: 'Log File', sorting: false, render: (item: { logFile: any }) => item.logFile,
  },
]

const mockHandleEdit = jest.fn()
const mockRowClickHandler = jest.fn()
const mockHandleFileDownload = jest.fn()
const mockOnRequestSort = jest.fn()

const isAscending = () => {
  const firstRow = screen.getByTestId('table-cell 0 0')
  const secondRow = screen.getByTestId('table-cell 1 0')
  if (firstRow.textContent && secondRow.textContent) {
    return firstRow.textContent < secondRow.textContent
  }
  return null
}

jest.mock('react-i18next', () => ({
  useTranslation: () => ({
    t: (key: any) => key,
  }),
}))

describe('OPRTable Component', () => {
  beforeEach(() => {
    jest.clearAllMocks()
  })

  it('renders table headers correctly', () => {
    render(
      <OPRTable
        cols={mockCols}
        data={mockData}
        handleEdit={mockHandleEdit}
        handleFileDownload={mockHandleFileDownload}
        orderBy={false}
        rowClickHandler={mockRowClickHandler}
        sortBy="name"
      />,
    )

    expect(screen.getByText('Name')).toBeInTheDocument()
    expect(screen.getByText('Log File')).toBeInTheDocument()
  })

  it('renders table rows correctly', () => {
    render(
      <OPRTable
        cols={mockCols}
        data={mockData}
        handleEdit={mockHandleEdit}
        handleFileDownload={mockHandleFileDownload}
        orderBy={false}
        rowClickHandler={mockRowClickHandler}
        sortBy="name"
      />,
    )

    expect(screen.getByText('John Doe')).toBeInTheDocument()
    expect(screen.getByText('Jane Smith')).toBeInTheDocument()
  })

  it('handles row click correctly', () => {
    render(
      <OPRTable
        cols={mockCols}
        data={mockData}
        handleEdit={mockHandleEdit}
        handleFileDownload={mockHandleFileDownload}
        orderBy={false}
        rowClickHandler={mockRowClickHandler}
        rowNumber={0}
        sortBy="name"
      />,
    )

    fireEvent.click(screen.getByText('John Doe'))
    expect(mockRowClickHandler).toHaveBeenCalledWith(mockData[0])
  })

  it('handles file download button click correctly', () => {
    render(
      <OPRTable
        cols={mockCols}
        data={mockData}
        handleEdit={mockHandleEdit}
        handleFileDownload={mockHandleFileDownload}
        orderBy={false}
        rowClickHandler={mockRowClickHandler}
        sortBy="name"
      />,
    )

    fireEvent.click(screen.getAllByText('Download Log File')[0])
    expect(mockHandleFileDownload).toHaveBeenCalledWith(mockData[0])
  })

  it('handles sorting correctly', () => {
    render(
      <OPRTable
        cols={mockCols}
        data={mockData}
        handleEdit={mockHandleEdit}
        handleFileDownload={mockHandleFileDownload}
        orderBy={false}
        rowClickHandler={mockRowClickHandler}
        sortBy="name"
        onRequestSort={mockOnRequestSort}
      />,
    )

    fireEvent.click(screen.getByText('Name'))
    expect(mockOnRequestSort).toHaveBeenCalled()
  })

  it('displays "No Data Found" when data is empty', () => {
    render(
      <OPRTable
        cols={mockCols}
        data={[]}
        handleEdit={mockHandleEdit}
        handleFileDownload={mockHandleFileDownload}
        orderBy={false}
        rowClickHandler={mockRowClickHandler}
        sortBy="name"
      />,
    )

    expect(screen.getByText('No Data Found')).toBeInTheDocument()
  })

  it('displays "No matching search results" when isSearchText is true and data is empty', () => {
    render(
      <OPRTable
        isSearchText
        cols={mockCols}
        data={[]}
        handleEdit={mockHandleEdit}
        handleFileDownload={mockHandleFileDownload}
        orderBy={false}
        rowClickHandler={mockRowClickHandler}
        sortBy="name"
      />,
    )

    expect(screen.getByText('No matching search results')).toBeInTheDocument()
  })

  it('displays loading indicator when isLoader is true', () => {
    render(
      <OPRTable
        isLoader
        cols={mockCols}
        data={mockData}
        handleEdit={mockHandleEdit}
        handleFileDownload={mockHandleFileDownload}
        orderBy={false}
        rowClickHandler={mockRowClickHandler}
        sortBy="name"
      />,
    )

    expect(screen.getByText('Loading...')).toBeInTheDocument()
  })

  // it('should sort data in descending order when orderBy is false', () => {
  //   render(
  //     <OPRTable
  //       cols={mockCols}
  //       data={mockData}
  //       handleEdit={mockHandleEdit}
  //       handleFileDownload={mockHandleFileDownload}
  //       orderBy={false}
  //       rowClickHandler={mockRowClickHandler}
  //       sortBy="name"
  //     />,
  //   )
  //   const ascending = isAscending()
  //   expect(ascending).toBe(false)
  // })

  // it('should sort data in ascending order when orderBy is true', () => {
  //   render(
  //     <OPRTable
  //       orderBy
  //       cols={mockCols}
  //       data={mockData}
  //       handleEdit={mockHandleEdit}
  //       handleFileDownload={mockHandleFileDownload}
  //       rowClickHandler={mockRowClickHandler}
  //       sortBy="name"
  //       onRequestSort={mockOnRequestSort}
  //     />,
  //   )
  //   let ascending = isAscending()
  //   console.log(ascending)
  //   const sortButton = screen.getByTestId('table-sort-label')
  //   fireEvent.click(sortButton)
  //   expect(mockOnRequestSort).toHaveBeenCalledWith(expect.any(Object), 'name')
  //   ascending = isAscending()
  //   console.log(ascending)
  //   screen.debug(screen.getByTestId('table-body'))
  // })

  // it('should sort data as per value in sortData if headerItem.key is equal to sortBy', () => {
  //   render(
  //     <OPRTable
  //       cols={mockCols}
  //       data={mockData}
  //       handleEdit={mockHandleEdit}
  //       handleFileDownload={mockHandleFileDownload}
  //       orderBy={false}
  //       rowClickHandler={mockRowClickHandler}
  //       sortBy=""
  //     />,
  //   )

  //   const firstName = screen.getAllByRole('row')[1]
  //   const secondName = screen.getAllByRole('row')[2]
  //   expect(firstName).toHaveTextContent('John Doe')
  //   expect(secondName).toHaveTextContent('Jane Smith')
  // })

  // it('should sort data in ascending order if headerItem.key is not equal to sortBy', () => {
  //   render(
  //     <OPRTable
  //       cols={mockCols}
  //       data={mockData}
  //       handleEdit={mockHandleEdit}
  //       handleFileDownload={mockHandleFileDownload}
  //       orderBy={false}
  //       rowClickHandler={mockRowClickHandler}
  //       sortBy="logFile"
  //     />,
  //   )

  //   const firstName = screen.getAllByRole('row')[1]
  //   const secondName = screen.getAllByRole('row')[2]
  //   expect(firstName).toHaveTextContent('John Doe')
  //   expect(secondName).toHaveTextContent('Jane Smith')
  // })
})
