import { Box, TableSortLabel } from '@mui/material'
import Paper from '@mui/material/Paper'
import Table from '@mui/material/Table'
import TableBody from '@mui/material/TableBody'
import TableCell from '@mui/material/TableCell'
import TableContainer from '@mui/material/TableContainer'
import TableHead from '@mui/material/TableHead'
import TableRow from '@mui/material/TableRow'
import * as React from 'react'
import { useTranslation } from 'react-i18next'

import OPRButton from '../button/OPRButton'
import OPRLabel from '../label/OPRLabel'

const createTableRow = (data: any, cols: any, rowClickHandler:any, rowNumber:any, handleFileDownload: any) => (
  <TableBody data-testid="table-body">

    {data?.map((item: any, i:any) => (
      <TableRow
        key={item.name}
        data-testid="table-row"
        sx={{ '&:last-child td, &:last-child th': { border: 0 } }}
      >
        {cols.map((col: any, key: any) => (
          <TableCell
            component="th"
            data-testid={`table-cell ${i} ${key}`}
            scope="row"
            sx={{ textAlign: cols.length - 1 === key ? 'end' : 'left', cursor: rowNumber === key ? 'pointer' : 'text' }}
            onClick={() => {
              rowNumber === key ? rowClickHandler(item) : null
            }}
          >
            {col.render(item)}

            {/* tesing moto */}

            {col.key === 'logFile' && ( // Assuming 'createdAt' is the key for the file column
              <OPRButton
                color="primary"
                variant="text"
                onClick={() => handleFileDownload(item)} // Call handleFileDownload on button click
              >
                Download Log File
              </OPRButton>
            )}
          </TableCell>
        ))}
      </TableRow>
    ))}
  </TableBody>
)
export default function OPRTable({
  cols,
  data,
  bordered,
  hoverable,
  striped,
  isDark,
  handleEdit,
  isSearchText,
  title,
  onRequestSort,
  orderBy,
  sortBy,
  isLoader,
  rowClickHandler,
  rowNumber,
  handleFileDownload,
}: any) {
  const { t } = useTranslation()
  const createSortHandler = (property: keyof any) => (event: React.MouseEvent<unknown>) => {
    onRequestSort(event, property)
  }
  const sortData = orderBy ? 'asc' : 'desc'

  return (
    <TableContainer component={Paper} sx={{ boxShadow: 'none', borderBottom: '1px solid #E8E6E7', borderTop: '3px solid #E8E6E7' }}>
      <Table aria-label="simple table">
        <TableHead>
          <TableRow>
            {cols?.map((headerItem: any, index: any) => (
              <TableCell sx={{ fontWeight: '700', textAlign: cols.length - 1 === index ? 'end' : 'left' }}>
                {headerItem.sorting ? (
                  <TableSortLabel
                    active={sortBy === headerItem.key}
                    data-testid="table-sort-label"
                    direction={sortBy === headerItem.key ? sortData : 'asc'}
                    onClick={createSortHandler(headerItem.key)}
                  >
                    {t(headerItem.title)}
                  </TableSortLabel>
                ) : (
                  t(headerItem.title)
                )}
              </TableCell>
            ))}
          </TableRow>
        </TableHead>
        {data.length === 0 && (
          <Box sx={{
            display: 'flex', alignItems: 'center', padding: 2,
          }}
          >
            <OPRLabel variant="h5">{isSearchText ? 'No matching search results' : 'No Data Found'}</OPRLabel>
          </Box>
        )}
        {isLoader ? (
          <div
            style={{
              display: 'flex',
              flex: 1,
              justifyContent: 'center',
              alignItems: 'center',
              margin: 10,
            }}
          >
            Loading...
          </div>
        ) : (
          createTableRow(data, cols, rowClickHandler, rowNumber, handleFileDownload)
        )}
      </Table>
    </TableContainer>
  )
}
