import { Checkbox, Chip } from '@mui/material'
import { displayFormatDateTime } from 'constants/index'
import { t } from 'i18next'
import moment from 'moment'
import React from 'react'
import { PayCycleStatus } from 'types'
import { customDateFormate, formatedDate } from 'utils'

import OPRButton from '../button/OPRButton'
import OPRCheckbox from '../checkbox/OPRCheckbox'
import OPRStatusChip from '../chip/OPRStatusChip'
import OPRActionMenu, { OPRActionMenuOption } from '../dropDown/OPRActionMenu'
import OPRDropDown from '../dropDown/OPRDropDown'
import OPRLabel from '../label/OPRLabel'

interface RowData {
  id: string; // Assuming 'id' is the unique identifier for each record
  employeeCode: string;
  employeeName: string;
  jobId: string;
  payItemCode: string;
  incomeType: string;
}

interface PayrollHistoryProps {
  handleCheckboxChange: (event: React.ChangeEvent<HTMLInputElement>, id: string) => void;
  selectedPayrollCodes: string[];
}

// This is the table constant/settings which needed to render table elements
export const OPRTableConstant = (handleEdit: any) => [
  {
    key: 'id',
    sorting: true,
    title: 'ID',
    render: (rowData: any) => <span style={{ color: rowData.id === 1 ? 'red' : 'black' }}>{rowData.id}</span>,
  },
  {
    key: 'name',
    sorting: true,
    title: 'Name',
    render: (rowData: any) => <span>{rowData.name}</span>,
  },
  {
    key: 'username',
    sorting: true,
    title: 'Username',
    render: (rowData: any) => <span>{rowData.username}</span>,
  },
  {

    key: 'email',
    sorting: true,
    title: 'Email',
    render: (rowData: any) => <span>{rowData.email}</span>,
  },
  {
    sorting: false,
    title: 'Action',
    render: (rowData: any) => (
      <OPRDropDown
        data={rowData}
        newOptions={['Add', 'Edit', 'Delete', 'View']}
        onHandleclick={handleEdit}
      />
    ),
  },
]
// Pay group
export const payGroupMasterColumn = (handleEdit: any) => [

  {
    key: 'payGroupCode',
    sorting: true,
    title: `${t('pay_group_table_code')} | ${t('pay_group_table_name')}`,
    render: (rowData: any) => (
      <>
        <OPRLabel color="primary.main" label={rowData.payGroupCode} />
        <OPRLabel color="topAdmin.main" label={rowData.payGroupName} variant="overline" />
      </>
    ),
  },
  {
    title: 'pay_group_table_cycle',
    render: (rowData: any) => <OPRLabel label={rowData.payCycleName} />,
  },
  {
    title: 'pay_group_table_status',
    render: (rowData: any) => <OPRLabel label={rowData.status.label} />,
  },
  {
    title: 'action',
    render: (rowData: any) => (
      <OPRDropDown
        data={rowData}
        newOptions={['Generate pay cycle', 'edit', 'delete']}
        onHandleclick={handleEdit}
      />
    ),
  },
]

// pay cycle
export const payCycleMasterColumn = (handleEdit: any) => [
  {
    key: 'payCycleName',
    sorting: true,
    title: 'pay_cycle_name',
    render: (rowData: any) => <OPRLabel label={rowData.payCycleName} />,
  },

  {
    key: 'payCycleYear',
    title: 'pay_cycle_month_year',
    render: (rowData: any) => <OPRLabel label={rowData.payCycleYear} />,
  },

  {
    key: 'payCycleNewType',
    title: 'pay_cycle_type',
    render: (rowData: any) => <OPRLabel label={rowData.payCycleNewType} />,
  },
  {
    key: 'payCycleStartDate',
    title: 'payroll_period',
    render: (rowData: any) => <OPRLabel label={rowData.payCycleStartDate} />,
  },
  {
    key: 'status',
    title: 'pay_cycle_status',
    render: (rowData: any) => <OPRLabel label={rowData.status} />,
  },
  {
    sorting: false,
    title: 'action',
    render: (rowData: any) => (
      <OPRDropDown
        data={rowData}
        newOptions={['edit', 'delete']}
        onHandleclick={handleEdit}
      />
    ),
  },
]

// month end close
export const payrollMonthEndColumn = (handleEdit: any) => [

  {
    key: 'payCycleName',
    sorting: true,
    title: 'pay_cycle_title',
    render: (rowData: any) => <OPRLabel label={rowData.payCycleName} />,
  },

  {
    key: 'payCycleName',
    title: 'pay_cycle_year',
    render: (rowData: any) => <OPRLabel label={rowData.payCycleName} />,
  },
  {
    key: 'payCycleStartDate',
    title: 'payroll_period',
    render: (rowData: any) => <OPRLabel label={rowData.payCycleStartDate} />, // why reapeted need to cross check
  },
  {
    key: 'payCycleStartDate',
    title: 'payroll_run_date',
    render: (rowData: any) => <OPRLabel label={rowData.payCycleStartDate} />,
  },

  {
    key: 'status',
    title: 'run_payroll_status',
    render: (rowData: any) => <OPRLabel label={rowData.status} />,
  },
  {
    sorting: false,
    title: 'action',
    render: (rowData: any) => (
      <OPRDropDown
        data={rowData}
        newOptions={['edit', 'delete']}
        onHandleclick={handleEdit}
      />
    ),
  },
]

// pay item group
export const payItemGroupColumn = (handleEdit: any) => [

  {
    key: 'itemGroupCode',
    sorting: true,
    title: `${t('payroll_item_group_code')} | ${t('payroll_item_group_name')}`,
    render: (rowData: any) => (
      <>
        <OPRLabel color="primary.main" label={rowData.itemGroupCode} />
        <OPRLabel color="topAdmin.main" label={rowData.itemGroupName} variant="overline" />
      </>
    ),
  },

  {
    sorting: false,
    title: 'action',
    render: (rowData: any) => (
      <OPRDropDown
        data={rowData}
        newOptions={['edit', 'delete']}
        onHandleclick={handleEdit}
      />
    ),
  },
]

// pay item master
export const payItemMasterColumn = (handleEdit: any) => [
  {
    key: 'payItemCode',
    sorting: true,
    title: 'payItem_master_name_id',
    render: (rowData: any) => (
      <>
        <OPRLabel color="primary.main" label={rowData.payItemName} />
        <OPRLabel color="topAdmin.main" label={rowData.payItemCode} variant="overline" />
      </>
    ),
  },
  {
    title: 'pay_item_pay_type',
    render: (rowData: any) => <OPRLabel label={rowData.payType} />,
  },
  {
    title: 'pay_item_income_type',
    render: (rowData: any) => <OPRLabel label={rowData.incomeType} />,
  },
  {
    key: 'status',
    title: 'status',
    render: (rowData: any) => (
      <OPRLabel CustomStyles={{

        paddingLeft: 8,
        paddingRight: 8,
        paddingTop: 4,
        paddingBottom: 4,
        background: rowData.status ? '#EBFFF0' : '#E8E6E7',
        borderRadius: 12,
        overflow: 'hidden',
        justifyContent: 'center',
        alignItems: 'center',
        gap: 8,
        display: 'inline-flex',
        color: rowData.status ? '#00701C' : '#3B3839',
        fontSize: 12,
        fontFamily: 'Lato',
        fontWeight: 700,
      }}
      >
        {rowData.status ? 'Active' : 'Inactive'}
      </OPRLabel>
    ),
  },
  {
    sorting: false,
    title: '',
    render: (rowData: any) => (
      <OPRDropDown
        data={rowData}
        newOptions={['edit', 'Delete pay item']}
        onHandleclick={handleEdit}
      />
    ),
  },
]
// payroll non recurring
export const payrollNonRecurringColumn = (handleEdit: any) => [
  {
    key: 'employeeCode',
    sorting: true,
    title: 'Employee',
    render: (rowData: any) => <OPRLabel label={rowData.employeeCode} />,
  },

  {
    key: 'payItemCode',
    title: 'Pay Item',
    render: (rowData: any) => <OPRLabel label={rowData.payItemCode} />,
  },

  {
    // title: 'Quantity | Rate per unit',
    title: `${t('Quantity')}|${t('Rate per unit')}`,
    render: (rowData: any) => (
      <>
        <OPRLabel label={rowData.quantity} />
        <OPRLabel label={rowData.ratePerUnit} />

      </>
    ),
  },
  {

    title: 'Amount',
    render: (rowData: any) => (
      <>
        <OPRLabel label={rowData.originalCurrency} />
        <OPRLabel label={rowData.transactionAmount} />
      </>
    ),
  },
  {
    sorting: false,
    title: '',
    render: (rowData: any) => (
      <OPRDropDown
        data={rowData}
        newOptions={[' ', ' ']}
        onHandleclick={handleEdit}
      />
    ),
  },
]

// run payroll

export const runPayRollPayCycleMasterColumn = (handleEdit: any) => [

  {
    key: 'payCycleName',
    sorting: true,
    title: `${t('Pay cycle ID')}|${t('Pay cycle name')}`,
    render: (rowData: any) => {
      // const monthYear = new Date(`${rowData?.payCycleYear}-${rowData?.payCycleMonth} (${rowData.payCycleCode})`)
      // const formattedMonthYear = monthYear.toLocaleString('default', { month: 'long', year: 'numeric' })
      // const finalCode = `${formattedMonthYear} (${rowData.payCycleCode})`
      const finalCode = `${rowData.payCycleYear}-${rowData.payCycleMonth} (${rowData.payCycleCode})`

      return (
        <>
          <OPRLabel color="primary.main" label={finalCode} />
          <OPRLabel color="topAdmin.main" label={rowData?.payCycleName} />

        </>
      )
    },
  },
  // payroll period
  {
    key: 'payCycleStartDate',
    title: 'Payroll period',
    render: (rowData: any) => {
      const startDate = new Date(rowData.payCycleStartDate)
      const formattedStartDate = startDate.toLocaleDateString('en-GB', {
        day: '2-digit',
        month: 'short',
        year: 'numeric',
      })

      const endDate = new Date(rowData.payCycleEndDate)
      const formattedEndDate = endDate.toLocaleDateString('en-GB', {
        day: '2-digit',
        month: 'short',
        year: 'numeric',
      })
      return (
        <OPRLabel
          label={`${formattedStartDate} - ${formattedEndDate}`}
        />
      )
    },
  },

  // status
  {
    key: 'status',
    title: 'Status',
    render: (rowData: any) => {
      let color
      let background
      switch (rowData.status?.label) {
        case 'Success':
        case 'Finalized':
        case 'Completed':
          color = '#00701C' // Green for success
          background = '#EBFFF0' // Light green background for success
          break
        case 'Failed':
          color = '#FF0000' // Red for failed
          background = '#FFEAEA' // Light red background for failed
          break
        case 'Pending':
          color = '#0000FF' // Blue for pending
          background = '#EAF0FF' // Light blue background for pending
          break
        default:
          color = '#3B3839' // Default text color
          background = '#EBEBEB' // Default background color
          break
      }
      return (
        <OPRLabel
          CustomStyles={{
            paddingLeft: 8,
            paddingRight: 8,
            paddingTop: 4,
            paddingBottom: 4,
            borderRadius: 12,
            overflow: 'hidden',
            justifyContent: 'center',
            alignItems: 'center',
            gap: 8,
            display: 'inline-flex',
            fontSize: 12,
            fontFamily: 'Lato',
            fontWeight: 700,
            color,
            background,
          }}
        >
          {rowData.status?.label}
        </OPRLabel>
      )
    },
  },

]

//* ********************GLOBAL**********************
// country

export const countryColumn = (handleEdit: any) => [

  {
    key: 'countryCode',
    sorting: true,
    // title: 'country_code',
    title: 'Country ID',
    render: (rowData: any) => <OPRLabel color="primary.main" label={rowData.countryCode} />,
  },

  {
    key: 'countryName',
    title: 'country_name',
    render: (rowData: any) => <OPRLabel label={rowData.countryName} />,
  },
  {
    key: 'createdAt',
    title: 'Created At',
    render: (rowData: any) => <OPRLabel label={formatedDate(rowData.createdAt)} />,
  },
  {
    sorting: false,
    title: '',
    render: (rowData: any) => (
      <OPRDropDown
        data={rowData}
        newOptions={['edit country', 'delete country']}
        onHandleclick={handleEdit}
      />
    ),
  },
]

// formulaSetup

export const formulaSetupColumn = (handleEdit: any) => [

  {
    key: 'formulaCode',
    sorting: true,
    title: 'Formula name | Formula ID',
    render: (rowData: any) => (
      <>
        <OPRLabel color="primary.main" label={rowData.description} />
        <OPRLabel color="topAdmin.main" label={rowData?.formulaCode} />

      </>
    ),
  },

  {
    key: 'type',
    title: 'Type',
    render: (rowData: any) => <OPRLabel label={rowData.type} />,
  },
  {
    sorting: false,
    title: '',
    render: (rowData: any) => (
      <OPRDropDown
        data={rowData}
        newOptions={['Delete formula']}
        onHandleclick={handleEdit}
      />
    ),
  },
]

// formula expression

export const formulaExpressionColumn = (handleEdit: any) => [

  {
    key: 'formulaCode',
    sorting: true,
    title: 'Formula name | Formula ID',
    render: (rowData: any) => (
      <>
        <OPRLabel color="primary.main" label={rowData.description} />
        <OPRLabel color="topAdmin.main" label={rowData?.formulaCode} />

      </>
    ),
  },

  {
    key: 'type',
    title: 'Type',
    render: (rowData: any) => <OPRLabel label={rowData.type} />,
  },
  {
    sorting: false,
    title: '',
    render: (rowData: any) => (
      <OPRDropDown
        data={rowData}
        newOptions={['Delete formula expreesion']}
        onHandleclick={handleEdit}
      />
    ),
  },
]

// Terms Formulation

export const termsColumn = (handleEdit: any) => [

  {
    key: 'termCode',
    sorting: true,
    title: 'Term description | Term code',
    render: (rowData: any) => (
      <>
        <OPRLabel color="primary.main" label={rowData.description} />
        <OPRLabel color="topAdmin.main" label={rowData?.termCode} />

      </>
    ),
  },

  {
    key: 'updateSequence',
    title: 'Update sequence',
    render: (rowData: any) => <OPRLabel label={rowData.updateSequence} />,
  },
  {
    key: 'expression',
    title: 'Type',
    render: (rowData: any) => <OPRLabel label={rowData.expression} />,
  },
  {
    sorting: false,
    title: '',
    render: (rowData: any) => (
      <OPRDropDown
        data={rowData}
        newOptions={['Edit Terms', 'Delete Terms']}
        onHandleclick={handleEdit}
      />
    ),
  },
]
// client group

export const clientGroupProfileColumn = (handleEdit: any) => [

  {
    key: 'clientGroupCode',
    sorting: true,
    title: 'Client group name | Client group ID',
    render: (rowData: any) => (
      <>
        <OPRLabel color="primary.main" label={rowData.clientGroupName} />
        <OPRLabel label={`${rowData.clientGroupCode}`} />
      </>
    ),
  },
  {
    key: 'entitiesCount',
    title: 'Entities',
    render: (rowData: any) => <OPRLabel label={`${rowData?.entitiesCount}`} />,
  },
  {
    key: 'status',
    title: 'Status',
    render: (rowData: any) => <Chip label={rowData.status ? 'Active' : 'Inactive'} size="small" sx={{ color: rowData.status ? '#00701C' : '#3B3839', fontWeight: rowData.status ? '700' : '700' }} />,
  },
  {
    sorting: false,
    title: '',
    render: (rowData: any) => {
      const options: OPRActionMenuOption[] = []

      if (rowData.status) {
        options.push({
          title: t('Inactive client group'),
          value: 'inactive_client_group',
          action: (option) => handleEdit?.(rowData, option),
        })
      } else {
        options.push({
          title: t('Active client group'),
          value: 'active_client_group',
          action: (option) => handleEdit?.(rowData, option),
        })
      }

      options.push({
        title: t('Edit client group'),
        value: 'edit_client_group',
        action: (option) => handleEdit?.(rowData, option),
      })

      options.push({
        title: t('Delete client group'),
        destructive: true,
        value: 'delete_client_group',
        action: (option) => handleEdit?.(rowData, option),
      })

      return (
        <OPRActionMenu
          options={options}
          onClose={() => {
          }}
        />
      )
    },
  },
]

export const clientGroupEntitiesColumn = (handleEdit: any) => [

  {
    key: 'entityCode',
    sorting: true,
    title: 'Entity name | Entity ID',
    render: (rowData: any) => (
      <>
        <OPRLabel color="primary.main" label={`${rowData.entityName}`} />
        <OPRLabel label={rowData.entityCode} />
      </>
    ),
  },

  {
    key: 'clientGroupName',
    title: 'Country',
    render: (rowData: any) => <OPRLabel label={rowData.countryLocalization} />,
  },
  {
    key: 'userCount',
    title: 'Users',
    render: (rowData: any) => <OPRLabel label={`${rowData.userCount}`} />,
  },
  {
    key: 'status',
    title: 'Status',
    render: (rowData: any) => <Chip label={rowData.status ? 'Active' : 'Inactive'} size="small" sx={{ color: rowData.status ? 'green' : '#3B3839' }} />,
  },
  {
    sorting: false,
    title: '',
    render: (rowData: any) => {
      const options: OPRActionMenuOption[] = [
        {
          title: t('Edit entity'),
          value: 'edit_entity',
          action: (option) => handleEdit?.(rowData, option),
        },
        {
          title: t('Delete entity'),
          destructive: true,
          value: 'delete_entity',
          action: (option) => handleEdit?.(rowData, option),
        },
      ]
      return (
        <OPRActionMenu
          options={options}
          onClose={() => {
          }}
        />
      )
    },
  },
]

export const clientGroupProfileUserColumn = (handleEdit: any) => [
  {
    key: 'username',
    sorting: true,
    title: 'Name | User ID',
    render: (rowData: any) => (
      <>
        <OPRLabel color="primary.main" label={`${`${rowData.firstName} ${rowData.lastName}`}`} />
        <OPRLabel label={rowData.username} />
      </>
    ),
  },
  {
    key: 'entities',
    title: 'Entities',
    render: (rowData: any) => <OPRLabel label={`${rowData.entityCount} ${rowData.entityCount > 1 ? t('entities') : t('entity')}`} />,
  },
  {
    sorting: false,
    title: '',
    render: (rowData: any) => {
      const options: OPRActionMenuOption[] = [
        {
          title: 'Assign entity',
          value: 'assign_entity',
          action: (option) => handleEdit?.(rowData, option),
        },
        {
          title: 'Remove entity',
          destructive: true,
          value: 'remove_entity',
          action: (option) => handleEdit?.(rowData, option),
        },
      ]
      return (
        <OPRActionMenu
          options={options}
          onClose={() => {
          }}
        />
      )
    },
  },
]

export const clientGroupEntitiesUserColumn = (handleEdit: any) => [

  {
    key: 'userId',
    sorting: true,
    title: 'Name/Role Code',
    render: (rowData: any) => (
      <>
        <OPRLabel color="primary.main" label={`${`${rowData.userName}`}`} />
        <OPRLabel label={rowData.userId} />
      </>
    ),
  },

  {
    key: 'accountStatus',
    title: 'User Role',
    render: (rowData: any) => <OPRLabel label={rowData.roleName} />,
  },
  // {
  //   sorting: false,
  //   title: '',
  //   render: (rowData: any) => (
  //     <OPRDropDown
  //       data={rowData}
  //       newOptions={['view', 'edit', 'delete', 'change status']}
  //       onHandleclick={handleEdit}
  //     />
  //   ),
  // },
]
// nationality
export const nationalityColumn = (handleEdit: any) => [

  {
    key: 'nationalityCode',
    sorting: true,
    // title: 'nationality_code',
    title: 'Nationality ID',
    render: (rowData: any) => <OPRLabel color="primary.main" label={rowData.nationalityCode} />,
  },

  {
    key: 'nationalityName',
    title: 'nationality_name',
    render: (rowData: any) => <OPRLabel label={rowData.nationalityName} />,
  },
  {
    sorting: false,
    title: '',
    render: (rowData: any) => (
      <OPRDropDown
        data={rowData}
        newOptions={['Edit Nationality', 'Delete Nationality']}
        onHandleclick={handleEdit}
      />
    ),
  },
]

// currency

export const currencyColumn = (handleEdit: any) => [

  {
    key: 'currencyCode',
    sorting: true,
    // title: 'currency_code',
    title: 'Currency ID',
    render: (rowData: any) => <OPRLabel color="primary.main" label={rowData.currencyCode} />,
  },

  {
    key: 'currencyName',
    title: 'currency_name',
    render: (rowData: any) => <OPRLabel label={rowData.currencyName} />,
  },
  {
    key: 'currencySymbol',
    title: 'currency_symbol',
    render: (rowData: any) => <OPRLabel label={rowData.currencySymbol} />,
  },
  {
    sorting: false,
    title: '',
    render: (rowData: any) => (
      <OPRDropDown
        data={rowData}
        newOptions={['edit currency', 'delete currency']}
        onHandleclick={handleEdit}
      />
    ),
  },
]

// holidayCalender

export const holidayCalenderColumn = (handleEdit: any) => [

  {
    key: 'holidayCalendarCode',
    sorting: true,
    // title: 'holiday_calender_code | holiday_calender_name',
    title: 'Holiday Calender ID | Holiday Calender Name',
    render: (rowData: any) => (
      <>
        <OPRLabel color="primary.main" label={rowData.holidayCalendarCode} />
        <OPRLabel color="topAdmin.main" label={rowData.holidayCalendarName} variant="overline" />
      </>
    ),
  },

  // {
  //   key: 'holidayCalendarName',
  //   sorting: true,
  //   title: 'holiday_calender_name',
  //   render: (rowData: any) => <OPRLabel label={rowData.holidayCalendarName} />,
  // },
  {

    key: 'status',
    title: 'bulk_upload_data_status',
    render: (rowData: any) => (
      <OPRLabel CustomStyles={{

        paddingLeft: 8,
        paddingRight: 8,
        paddingTop: 4,
        paddingBottom: 4,
        background: rowData?.status ? '#EBFFF0' : '#E8E6E7',
        borderRadius: 12,
        overflow: 'hidden',
        justifyContent: 'center',
        alignItems: 'center',
        gap: 8,
        display: 'inline-flex',
        color: rowData?.status ? '#00701C' : '#3B3839',
        fontSize: 12,
        fontFamily: 'Lato',
        fontWeight: 700,
      }}
      >
        {rowData?.status ? 'Active' : 'Inactive'}
      </OPRLabel>
    ),
  },
  {
    key: 'remarks',
    title: 'holiday_calender_remarks',
    render: (rowData: any) => <OPRLabel label={rowData.remarks} />,
  },
  {
    sorting: false,
    title: 'action',
    render: (rowData: any) => (
      <OPRDropDown
        data={rowData}
        newOptions={['edit', 'delete']}
        onHandleclick={handleEdit}
      />
    ),
  },
]

// holidayCalenderDate

export const holidayCalenderDateColumn = (handleEdit: any) => [

  {
    key: 'date',
    sorting: true,
    title: 'Date',
    render: (rowData: any) => <OPRLabel label={rowData.date} />,
  },

  {
    key: 'holidayType',
    title: 'Holiday Type',
    render: (rowData: any) => <OPRLabel label={rowData.holidayType} />,
  },
  {
    sorting: false,
    title: 'action',
    render: (rowData: any) => (
      <OPRDropDown
        data={rowData}
        newOptions={[]}
        onHandleclick={handleEdit}
      />
    ),
  },
]

// global payment method

export const paymentmethodColumn = (handleEdit: any) => [

  {
    key: 'countryLocalization',
    sorting: true,
    title: 'country_localization',
    render: (rowData: any) => <OPRLabel color="primary.main" label={rowData.countryLocalization} />,
  },

  {
    key: 'paymentMethodCode',
    // title: 'payment_method_code',
    title: 'Payment Method ID',
    render: (rowData: any) => <OPRLabel label={rowData.paymentMethodCode} />,
  },
  {
    key: 'paymentMethodName',
    title: 'payment_method_name',
    render: (rowData: any) => <OPRLabel label={rowData.paymentMethodName} />,
  },
  {
    sorting: false,
    title: '',
    render: (rowData: any) => (
      <OPRDropDown
        data={rowData}
        newOptions={['Edit Payment method', 'Delete Payment method']}
        onHandleclick={handleEdit}
      />
    ),
  },
]

// Setting template

export const settingtemplateColumn = (handleEdit: any) => [

  {
    key: 'settingName',
    sorting: true,
    // title: 'setting_template_name',
    title: `${t(' Setting Name')} | ${t('Setting ID')}`,
    render: (rowData: any) => (
      <>
        <OPRLabel color="primary.main" label={rowData.settingName} />
        <OPRLabel color="topAdmin.main" label={rowData.settingCode} />
      </>
    ),
  },

  {
    key: 'countryLocalization',
    title: 'country_localization',
    render: (rowData: any) => <OPRLabel label={rowData.countryLocalization} />,
  },
  {
    key: 'settingLevel',
    title: 'setting_level',
    render: (rowData: any) => <OPRLabel label={rowData.settingLevel} />,
  },

  {
    sorting: false,
    title: '',
    render: (rowData: any) => (
      <OPRDropDown
        data={rowData}
        newOptions={['Edit setting', 'Delete setting']}
        onHandleclick={handleEdit}
      />
    ),
  },
]

// pension Fund scheme rule

export const pensionFundColumn = (handleEdit: any) => [

  {
    key: 'countryLocalization',
    sorting: true,
    title: 'country_localization_title',
    render: (rowData: any) => <OPRLabel color="primary.main" label={rowData.countryLocalization} />,
  },

  {
    key: 'pensionFundSchemeRuleType',
    title: 'pension_fund_scheme',
    render: (rowData: any) => <OPRLabel label={rowData.pensionFundSchemeRuleType} />,
  },
  {
    key: 'effectiveStartDate',
    title: 'pension_fund_start_date',
    render: (rowData: any) => <OPRLabel label={formatedDate(rowData.effectiveStartDate)} />,
  },
  {
    key: 'effectiveEndDate',
    title: 'pension_fund_end_date',
    render: (rowData: any) => <OPRLabel label={formatedDate(rowData.effectiveEndDate)} />,
  },

  {
    sorting: false,
    title: 'action',
    render: (rowData: any) => (
      <OPRDropDown
        data={rowData}
        newOptions={['edit', 'delete']}
        onHandleclick={handleEdit}
      />
    ),
  },
]

///  client Group Profile Calender

export const clientGroupProfileCalenderColumn = (handleEdit: any) => [

  {
    key: 'clientGroupCode',
    sorting: true,
    title: 'client_profile_code',
    render: (rowData: any) => <OPRLabel label={rowData.clientGroupCode} />,
  },

  {
    key: 'clientGroupName',
    title: 'client_profile_name',
    render: (rowData: any) => <OPRLabel label={rowData.clientGroupName} />,
  },
  {
    key: 'status',
    title: 'client_profile_status',
    render: (rowData: any) => <OPRLabel label={rowData.status} />,
  },
  {
    key: 'approveStatus',
    title: 'client_aproove',
    render: (rowData: any) => <OPRLabel label={rowData.approveStatus} />,
  },
  {
    key: 'remarks',
    title: 'client_profile_remarks',
    render: (rowData: any) => <OPRLabel label={rowData.remarks} />,
  },
  {
    sorting: false,
    title: 'action',
    render: (rowData: any) => (
      <OPRDropDown
        data={rowData}
        newOptions={['edit', 'delete']}
        onHandleclick={handleEdit}
      />
    ),
  },
]

// user Administration Column

export const userAdministrationColumn = (handleEdit: any) => [

  {

    key: 'username',
    sorting: true,
    title: 'user_administration_user_name',
    render: (rowData: any) => <OPRLabel label={rowData.username} />,
  },

  {

    key: 'firstName',
    title: 'user_administration_first_name',
    render: (rowData: any) => <OPRLabel label={rowData.firstName} />,
  },
  {

    key: 'lastName',
    title: 'user_administration_last_name',
    render: (rowData: any) => <OPRLabel label={rowData.lastName} />,
  },
  {

    key: 'emailAddress',
    title: 'user_administration_email',
    render: (rowData: any) => <OPRLabel label={rowData.emailAddress} />,
  },
  {

    key: 'userType',
    title: 'user_administration_type',
    render: (rowData: any) => <OPRLabel label={rowData.userType} />,
  },
  {
    sorting: false,
    title: 'action',
    render: (rowData: any) => (
      <OPRDropDown
        data={rowData}
        newOptions={[]}
        onHandleclick={handleEdit}
      />
    ),
  },
]

// Pension Fund Termination

export const pensionFundTerminationColumn = (handleEdit: any) => [
  {

    key: 'terminationCode',
    sorting: true,
    title: 'termination_code',
    render: (rowData: any) => <OPRLabel color="primary.main" label={rowData.terminationCode} />,
  },
  {

    key: 'countryLocalization',
    title: 'country_localization_title',
    render: (rowData: any) => <OPRLabel label={rowData.countryLocalization} />,
  },

  {
    sorting: false,
    title: 'action',
    render: (rowData: any) => (
      <OPRDropDown
        data={rowData}
        newOptions={['edit', 'delete']}
        onHandleclick={handleEdit}
      />
    ),
  },
]

// user role
export const userroleColumn = (handleEdit: any) => [
  {

    key: 'userRoleCode',
    sorting: true,
    title: 'user_role_code',
    render: (rowData: any) => <OPRLabel label={rowData.userRoleCode} />,
  },
  {

    key: 'userRoleName',
    title: 'user_role_name',
    render: (rowData: any) => <OPRLabel label={rowData.userRoleName} />,
  },
  {

    key: 'remarks',
    title: 'user_role_remarks',
    render: (rowData: any) => <OPRLabel label={rowData.remarks} />,
  },
  {
    sorting: false,
    title: 'action',
    render: (rowData: any) => (
      <OPRDropDown
        data={rowData}
        newOptions={[]}
        onHandleclick={handleEdit}
      />
    ),
  },
]

// bulk Upload

export const bulkUploadColumn = (handler: any) => [
  {

    key: 'requestFileName',
    sorting: true,
    title: 'bulk_upload_data_first_name',
    render: (rowData: any) => <OPRLabel label={rowData.requestFileName} />,
  },
  {

    key: 'operationType',
    title: 'bulk_upload_data_type',
    render: (rowData: any) => <OPRLabel label={rowData.operationType} />,
  },
  {
    key: 'jobId',
    title: 'job_id_created_date_by',
    render: (rowData: any) => {
      const date = new Date(rowData.createdAt)
      const formateDate = date.toLocaleDateString('en-GB', {
        day: '2-digit',
        month: 'short',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit',
      })
      return (
        <>
          <OPRLabel label={rowData.jobId} />
          <OPRLabel label={formateDate} />
          <OPRLabel label={rowData.createdBy} />
        </>
      )
    },
  },
  {
    key: 'completedDate',
    title: 'bulk_upload_data_created_date',
    render: (rowData: any) => {
      let formateDate = '-'
      if (rowData.completedDate) {
        const date = new Date(rowData.completedDate)
        formateDate = date.toLocaleDateString('en-GB', {
          day: '2-digit',
          month: 'short',
          year: 'numeric',
          hour: '2-digit',
          minute: '2-digit',
          second: '2-digit',
        })
      }
      return (
        <OPRLabel label={formateDate} />
      )
    },
  },
  {
    key: 'jobStatus',
    title: 'bulk_upload_data_status',
    render: (rowData: any) => (
      <OPRLabel CustomStyles={{

        paddingLeft: 8,
        paddingRight: 8,
        paddingTop: 4,
        paddingBottom: 4,
        background: rowData.jobStatus === 'Successful' ? '#EBFFF0' : '#E8E6E7',
        borderRadius: 12,
        overflow: 'hidden',
        justifyContent: 'center',
        alignItems: 'center',
        gap: 8,
        display: 'inline-flex',
        color: rowData.jobStatus === 'Successful' ? '#00701C' : '#3B3839',
        fontSize: 12,
        fontFamily: 'Lato',
        fontWeight: 700,
      }}
      >
        {rowData.jobStatus}
      </OPRLabel>
    ),
  },
  {
    key: 'action',
    title: 'bulk_upload_data_file_name',
    render: (rowData: any) => (
      <>
        {' '}
        {
          rowData.jobStatus === 'Failed' && rowData.errorFilePath
         && <OPRButton color="primary" variant="text" onClick={() => handler(rowData)}>Download Log File</OPRButton>
        }
      </>
    ),
  },
]

// client Group Entity

export const clientGroupEntityColumn = (handleEdit: any) => [
  {

    key: 'clientGroupCode',
    sorting: true,
    title: 'client_profile_code',
    render: (rowData: any) => <OPRLabel label={rowData.clientGroupCode} />,
  },
  {

    key: 'clientGroupName',
    title: 'client_profile_name',
    render: (rowData: any) => <OPRLabel label={rowData.clientGroupName} />,
  },
  {

    key: 'entityCode',
    title: 'entity_code',
    render: (rowData: any) => <OPRLabel label={rowData.entityCode} />,
  },
  {

    key: 'entityName',
    title: 'entity_name',
    render: (rowData: any) => <OPRLabel label={rowData.entityName} />,
  },
  {

    key: 'countryLocalization',
    title: 'country_localization',
    render: (rowData: any) => <OPRLabel label={rowData.countryLocalization} />,
  },
  {

    key: 'Url',
    title: 'client_entity_url',
    render: (rowData: any) => <OPRLabel label={rowData.Url} />,
  },
  {

    key: 'Region',
    title: 'region',
    render: (rowData: any) => <OPRLabel label={rowData.Region} />,
  },
  {

    key: 'status',
    title: 'client_profile_status',
    render: (rowData: any) => <OPRLabel label={rowData.status} />,
  },
  {
    sorting: false,
    title: 'action',
    render: (rowData: any) => (
      <OPRDropDown
        data={rowData}
        newOptions={[]}
        onHandleclick={handleEdit}
      />
    ),
  },
]

// pay cycle logs

export const logsColumn = (handleEdit: any) => [
  {

    key: 'payCycleCode',
    sorting: true,
    title: 'run_Payroll_Cycle_Code',
    render: (rowData: any) => <OPRLabel label={rowData.payCycleCode} />,
  },
  {

    key: 'payCycleName',
    title: 'run_payroll_cycle_name',
    render: (rowData: any) => <OPRLabel label={rowData.payCycleName} />,
  },
  {

    key: 'jobId',
    title: 'bulk_upload_data_job_id',
    render: (rowData: any) => <OPRLabel label={rowData.jobId} />,
  },
  {

    key: 'createdAt',
    title: 'bulk_upload_data_job_created_and_by',
    render: (rowData: any) => <OPRLabel label={rowData.createdAt} />,
  },
  {

    key: 'completedDate',
    title: 'bulk_upload_data_created_date',
    render: (rowData: any) => <OPRLabel label={rowData.completedDate} />,
  },
  {

    key: 'jobStatus',
    title: 'bulk_upload_data_status',
    render: (rowData: any) => <OPRLabel label={rowData.jobStatus} />,
  },
  {

    key: 'download',
    title: 'bulk_upload_data_file_name',
    render: (rowData: any) => <OPRLabel label={rowData.download} />,
  },
  {
    sorting: false,
    title: 'action',
    render: (rowData: any) => (
      <OPRDropDown
        data={rowData}
        newOptions={[]}
        onHandleclick={handleEdit}
      />
    ),
  },
]

// month Logs Column

export const monthLogsColumn = (handleEdit: any) => [
  {

    key: 'payCycleCode',
    sorting: true,
    title: 'pay_cycle_month_year',
    render: (rowData: any) => <OPRLabel label={rowData.payCycleCode} />,
  },
  {

    key: 'jobId',
    title: 'bulk_upload_data_job_id',
    render: (rowData: any) => <OPRLabel label={rowData.jobId} />,
  },
  {

    key: 'createdAt',
    title: 'bulk_upload_data_job_created_and_by',
    render: (rowData: any) => <OPRLabel label={rowData.createdAt} />,
  },
  {

    key: 'completedDate',
    title: 'bulk_upload_data_created_date',
    render: (rowData: any) => <OPRLabel label={rowData.completedDate} />,
  },
  {

    key: 'jobStatus',
    title: 'bulk_upload_data_status',
    render: (rowData: any) => <OPRLabel label={rowData.jobStatus} />,
  },
  {

    key: 'download',
    title: 'bulk_upload_data_file_name',
    render: (rowData: any) => <OPRLabel label={rowData.download} />,
  },
  {
    sorting: false,
    title: 'action',
    render: (rowData: any) => (
      <OPRDropDown
        data={rowData}
        newOptions={[]}
        onHandleclick={handleEdit}
      />
    ),
  },
]
// Entity IRD
export const entityIrdColumn = (handleEdit: any) => [
  {
    key: 'corporateTitleName',
    sorting: true,
    title: `${t('ent_ird_corporate_title_view_name')}|${t('ent_ird_corporate_title_view_code')}`,
    render: (rowData: any) => (
      <>
        <OPRLabel color="primary.main" label={rowData.corporateTitleName} />
        <OPRLabel color="topAdmin.main" label={rowData.corporateTitleCode} />
      </>
    ),
  },

  {
    sorting: false,
    title: '',
    render: (rowData: any) => (
      <OPRDropDown
        data={rowData}
        newOptions={['Edit Ird', 'Delete Ird']}
        onHandleclick={handleEdit}
      />
    ),
  },
]
// Entity department
export const entityDepartmentColumn = (handleEdit: any) => [

  {
    key: 'departmentDescription',
    sorting: true,
    title: `${t('ent_dept_view_description')}|${t('ent_dept_view_code')}`,
    render: (rowData: any) => (
      <>
        <OPRLabel color="primary.main" label={rowData.departmentDescription} />
        <OPRLabel color="topAdmin.main" label={rowData.departmentCode} />
      </>
    ),
  },

  {
    sorting: false,
    title: '',
    render: (rowData: any) => (
      <OPRDropDown
        data={rowData}
        newOptions={['Edit department', 'Delete department']}
        onHandleclick={handleEdit}
      />
    ),
  },
]
// Entity division
export const entityDivisionColumn = (handleEdit: any) => [

  {
    key: 'divisionDescription',
    sorting: true,
    title: `${t('division_description')}|${t('division_code')}`,
    render: (rowData: any) => (
      <>
        <OPRLabel color="primary.main" label={rowData.divisionDescription} />
        <OPRLabel color="topAdmin.main" label={rowData.divisionCode} />
      </>
    ),
  },

  {
    sorting: false,
    title: '',
    render: (rowData: any) => (
      <OPRDropDown
        data={rowData}
        newOptions={['Edit division', 'Delete division']}
        onHandleclick={handleEdit}
      />
    ),
  },
]
// Entity Region
export const entityRegionColumn = (handleEdit: any) => [
  {
    key: 'regionDescription',
    sorting: true,
    title: `${t('regionDescription')}|${t('regionCode')}`,
    render: (rowData: any) => (
      <>
        <OPRLabel color="primary.main" label={rowData.regionDescription} />
        <OPRLabel color="topAdmin.main" label={rowData.regionCode} />
      </>
    ),
  },

  {
    sorting: false,
    title: '',
    render: (rowData: any) => (
      <OPRDropDown
        data={rowData}
        newOptions={['Edit region', 'Delete region']}
        onHandleclick={handleEdit}
      />
    ),
  },
]
// Entity team
export const entityTeamColumn = (handleEdit: any) => [

  {
    key: 'teamDescription',
    sorting: true,
    title: `${t('team_Description')}|${t('team_Code')}`,
    render: (rowData: any) => (
      <>
        <OPRLabel color="primary.main" label={rowData.teamDescription} />
        <OPRLabel color="topAdmin.main" label={rowData.teamCode} />
      </>
    ),
  },

  {
    sorting: false,
    title: '',
    render: (rowData: any) => (
      <OPRDropDown
        data={rowData}
        newOptions={['Edit Team', 'Delete Team']}
        onHandleclick={handleEdit}
      />
    ),
  },
]
// entity service provider
export const entityServiceProviderColumn = (handleEdit: any) => [
  {

    key: 'providerName',
    sorting: true,
    title: 'Service Provider Name',
    render: (rowData: any) => <OPRLabel color="primary.main" label={rowData.providerName} />,
  },
  {

    key: 'providerCode ',
    title: 'Provider_type',
    render: (rowData: any) => <OPRLabel label={rowData.providerCode} />,
  },
  {
    sorting: false,
    title: '',
    render: (rowData: any) => (
      <OPRDropDown
        data={rowData}
        newOptions={['Edit Service Provider', 'Delete Service Provider']}
        onHandleclick={handleEdit}
      />
    ),
  },
]
// Entity Pension Fund scheme Item
export const entitypensionFundSchemeItemColumn = (handleEdit: any) => [
  {

    key: 'pensionFundSchemeCode',
    sorting: true,
    title: `${t('Pension fund scheme name')} | ${t('Pension fund scheme ID')}`,
    render: (rowData: any) => (
      <>
        <OPRLabel color="primary.main" label={rowData.pensionFundSchemeCode} />
        <OPRLabel color="topAdmin.main" label={rowData.pensionFundSchemeId} />
      </>
    ),
  },
  {
    key: 'payItemCode',
    title: 'Pay item',
    render: (rowData: any) => <OPRLabel label={rowData.payItemCode} />,
  },
  {
    key: 'effectiveDates',
    title: 'pension_fund_schme_item_date',
    render: (rowData: any) => {
      const startDate = new Date(rowData.effectiveStartDate)
      const formattedStartDate = startDate.toLocaleDateString('en-GB', {
        day: '2-digit',
        month: 'short',
        year: 'numeric',
      })

      const endDate = new Date(rowData.effectiveEndDate)
      const formattedEndDate = endDate.toLocaleDateString('en-GB', {
        day: '2-digit',
        month: 'short',
        year: 'numeric',
      })
      return (
        <OPRLabel
          label={`${formattedStartDate} - ${formattedEndDate}`}
        />
      )
    },
  },

  {
    key: 'status',
    title: 'status',
    render: (rowData: any) => (
      <OPRLabel CustomStyles={{

        paddingLeft: 8,
        paddingRight: 8,
        paddingTop: 4,
        paddingBottom: 4,
        background: rowData.status ? '#EBFFF0' : '#E8E6E7',
        borderRadius: 12,
        overflow: 'hidden',
        justifyContent: 'center',
        alignItems: 'center',
        gap: 8,
        display: 'inline-flex',
        color: rowData.status ? '#00701C' : '#3B3839',
        fontSize: 12,
        fontFamily: 'Lato',
        fontWeight: 700,
      }}
      >
        {rowData.status ? 'Active' : 'Inactive'}
      </OPRLabel>
    ),
  },
  {
    sorting: false,
    title: '',
    render: (rowData: any) => (
      <OPRDropDown
        data={rowData}
        newOptions={['Edit Pension Fund Scheme Item', 'Delete Pension Fund Scheme Item']}
        onHandleclick={handleEdit}
      />
    ),
  },
]
// Entity Position
export const entityPositionColumn = (handleEdit: any) => [
  {
    key: 'positionDescription',
    sorting: true,
    title: `${t('position_Description')}|${t('position_Code')}`,
    render: (rowData: any) => (
      <>
        <OPRLabel color="primary.main" label={rowData.positionDescription} />
        <OPRLabel color="topAdmin.main" label={rowData.positionCode} />
      </>
    ),
  },
  // {
  //   key: 'positionCode',
  //   sorting: true,
  //   title: 'position_Code',
  //   render: (rowData: any) => <OPRLabel color="primary.main" label={rowData.positionCode} />,
  // },
  // {
  //   key: 'positionDescription',
  //   sorting: true,
  //   title: 'position_Description',
  //   render: (rowData: any) => <OPRLabel label={rowData.positionDescription} />,
  // },
  {
    sorting: false,
    title: '',
    render: (rowData: any) => (
      <OPRDropDown
        data={rowData}
        newOptions={['Edit Position', 'Delete Position']}
        onHandleclick={handleEdit}
      />
    ),
  },
]
// Entity Company Bank Account
export const entityCompBankAcctCols = (handleEdit: any) => [
  {

    key: 'companyBankAccountCode',
    sorting: true,
    title: 'ent_comp_bank_acct_col_header_code',
    render: (rowData: any) => <OPRLabel label={rowData.companyBankAccountCode} />,
  },

  {

    key: 'companyBankAccountDescription',
    title: 'ent_comp_bank_acct_col_header_desc',
    render: (rowData: any) => <OPRLabel label={rowData.companyBankAccountDescription} />,
  },

  {

    key: 'status',
    title: 'ent_comp_bank_acct_col_header_status',
    render: (rowData: any) => <OPRLabel label={rowData.status} />,
  },

  {

    key: 'remarks',
    title: 'remarks',
    render: (rowData: any) => <OPRLabel label={rowData.remarks} />,
  },
  {
    sorting: false,
    title: 'action',
    render: (rowData: any) => (
      <OPRDropDown
        data={rowData}
        newOptions={[]}
        onHandleclick={handleEdit}
      />
    ),
  },
]
// Entity Settings
export const entitySettingsCulumns = (handleEdit: any) => [

  {
    key: 'settingName',
    sorting: true,
    title: `${t('Entity setting name')}|${t('Entity setting id')}`,

    render: (rowData: any) => (
      <>
        <OPRLabel color="primary.main" label={rowData.settingCode} />
        <OPRLabel color="topAdmin.main" label={rowData.settingName} />
      </>
    ),
  },
  {

    key: 'category',
    title: 'category',
    render: (rowData: any) => <OPRLabel label={rowData.category} />,
  },
  {
    sorting: false,
    title: '',
    render: (rowData: any) => (
      <OPRDropDown
        data={rowData}
        newOptions={['Edit Setting', 'Delete Setting']}
        onHandleclick={handleEdit}
      />
    ),
  },
]
// Entity Currency exchange
export const entityCurrencyExchangeColumn = (handleEdit: any) => [

  {
    key: 'currencyFrom',
    sorting: true,
    title: `${t('Currency from')} → ${t('Currency to')}`,

    render: (rowData: any) => (
      <div style={{ display: 'flex', alignItems: 'center' }}>
        <OPRLabel color="primary.main" label={rowData.currencyFrom} />
        <span style={{ margin: '0 4px' }}>→</span>
        <OPRLabel color="primary.main" label={rowData.currencyTo} />
      </div>
    ),
  },
  {
    key: 'effectiveDate',
    title: 'ent_curr_exch_currency_effective_dt',
    render: (rowData: any) => {
      const effectiveDate = new Date(rowData.effectiveDate)
      const formattedDate = effectiveDate.toLocaleDateString('en-GB', {
        day: '2-digit',
        month: 'long',
        year: 'numeric',
      })
      return <OPRLabel label={formattedDate} />
    },
  },
  {
    key: 'conversionMethod',
    title: 'ent_curr_exch_conversion_method',
    render: (rowData: any) => <OPRLabel label={rowData.conversionMethod} />,
  },

  {
    key: 'exchangeRate',
    title: 'ent_curr_exch_rate',
    render: (rowData: any) => <OPRLabel label={rowData.exchangeRate} />,
  },
  {
    sorting: false,
    title: '',
    render: (rowData: any) => (
      <OPRDropDown
        data={rowData}
        newOptions={['Edit currency exchange', 'Delete currency exchange']}
        onHandleclick={handleEdit}
      />
    ),
  },
]
// Entity grade
export const entityGradeColumn = (handleEdit: any) => [

  {
    key: 'gradeDescription',
    sorting: true,
    title: `${t('ent_grade_description')}|${t('ent_grade_code')}`,

    render: (rowData: any) => (
      <>
        <OPRLabel color="primary.main" label={rowData.gradeDescription} />
        <OPRLabel color="topAdmin.main" label={rowData.gradeCode} />
      </>
    ),
  },
  // {
  //   key: 'gradeCode',
  //   sorting: true,
  //   title: 'ent_grade_code',
  //   render: (rowData: any) => <OPRLabel color="primary.main" label={rowData.gradeCode} />,
  // },
  // {
  //   key: 'gradeDescription',
  //   sorting: true,
  //   title: 'ent_grade_description',
  //   render: (rowData: any) => <OPRLabel label={rowData.gradeDescription} />,
  // },

  {
    sorting: false,
    title: '',
    render: (rowData: any) => (
      <OPRDropDown
        data={rowData}
        newOptions={['Edit Grade', 'Delete Grade']}
        onHandleclick={handleEdit}
      />
    ),
  },
]

// entity  emplyee movement configuation
export const entityEmpMovementConfigurationColumn = (handleEdit: any) => [

  {
    key: 'movementType',
    sorting: true,
    title: 'ent_emp_movement_configuration_movement_type',
    render: (rowData: any) => <OPRLabel color="primary.main" label={rowData.movementType} />,
  },
  {
    key: 'fieldName',
    title: 'ent_emp_movement_configuration_field_name',
    render: (rowData: any) => <OPRLabel label={rowData.fieldName} />,
  },

  {
    sorting: false,
    title: 'action',
    render: (rowData: any) => (
      <OPRDropDown
        data={rowData}
        newOptions={['edit', 'delete']}
        onHandleclick={handleEdit}
      />
    ),
  },
]
// entity work calender
export const entityWorkCalenderColumn = (handleEdit: any) => [
  {
    title: `${t('ent_work_calendar_code')} | ${t('ent_work_calendar_name')}`,
    key: 'workCalendarName',
    sorting: true,
    render: (rowData: any) => (
      <>
        <OPRLabel color="primary.main" label={rowData.workCalendarCode} />
        <OPRLabel color="topAdmin.main" label={rowData.workCalendarName} variant="overline" />
      </>
    ),
  },
  {
    sorting: false,
    title: 'action',
    render: (rowData: any) => (
      <OPRActionMenu
        options={[
          {
            title: t('Edit work calendar'),
            value: 'edit_work_calendar',
            action: (option) => handleEdit?.(rowData, option),
          },
          {
            title: t('Delete work calendar'),
            value: 'delete_work_calendar',
            destructive: true,
            action: (option) => handleEdit?.(rowData, option),
          },
        ]}
        onClose={() => {
        }}
      />
    ),
  },
]

// entity Profile
// entity work calender
export const entityProfileColumn = (handleEdit: any) => [

  {
    key: 'entityName',
    sorting: true,
    title: `${t('Entity ID')} | ${t('Entity Name')}`,
    render: (rowData: any) => (
      <>
        <OPRLabel color="primary.main" label={rowData.entityCode} />
        <OPRLabel color="topAdmin.main" label={rowData.entityName} variant="overline" />
      </>
    ),
  },
  {

    key: 'status',
    title: 'entity_profile_status',
    render: (rowData: any) => (
      <OPRLabel CustomStyles={{

        paddingLeft: 8,
        paddingRight: 8,
        paddingTop: 4,
        paddingBottom: 4,
        background: rowData.status ? '#EBFFF0' : '#E8E6E7',
        borderRadius: 12,
        overflow: 'hidden',
        justifyContent: 'center',
        alignItems: 'center',
        gap: 8,
        display: 'inline-flex',
        color: rowData.status ? '#00701C' : '#3B3839',
        fontSize: 12,
        fontFamily: 'Lato',
        fontWeight: 700,
      }}
      >
        {rowData.status ? 'Active' : 'Inactive'}
      </OPRLabel>
    ),
  },
  {
    sorting: false,
    title: 'action',
    render: (rowData: any) => (
      <OPRDropDown
        data={rowData}
        newOptions={[]}
        onHandleclick={handleEdit}
      />
    ),
  },
]
// entity Staff Type
export const entityStaffTypeColumn = (handleEdit: any) => [
  {
    title: `${t('staff_Type_Description')} | ${t('staff_Type_Code')}`,
    key: 'staffTypeDescription',
    sorting: true,
    render: (rowData: any) => (
      <>
        <OPRLabel color="primary.main" label={rowData.staffTypeDescription} />
        <OPRLabel color="topAdmin.main" label={rowData.staffTypeCode} />
      </>
    ),
  },

  {
    sorting: false,
    title: '',
    render: (rowData: any) => (
      <OPRDropDown
        data={rowData}
        newOptions={['Edit Staff Type', 'Delete Staff Type']}
        onHandleclick={handleEdit}
      />
    ),
  },
]

// Entity Employee movement type
export const entityEmployeeMovementTypeColumn = (handleEdit: any) => [
  {
    key: 'movementType',
    sorting: true,
    title: 'ent_emp_move_type_movement_type',
    render: (rowData: any) => <OPRLabel color="primary.main" label={rowData.movementType} />,
  },
  {
    key: 'movementDescription',
    title: 'ent_emp_move_type_movement_description',
    render: (rowData: any) => <OPRLabel label={rowData.movementDescription} />,
  },
  {
    key: 'status',
    title: 'status',
    render: (rowData: any) => (
      rowData.status === true ? (
        <div style={{
          color: '#3B3839',
          fontSize: 12,
          fontFamily: 'Lato',
          fontWeight: 700,
          textAlign: 'center',
        }}
        >
          <div style={{
            background: '#E8E6E7',
            width: '55px',
            borderRadius: '20px',
          }}
          >
            Active
          </div>
        </div>
      ) : (
        <div style={{
          color: '#00701C',
          fontSize: 12,
          fontFamily: 'Lato',
          fontWeight: 700,
          textAlign: 'center',
        }}
        >
          <div style={{
            background: '#EBFFF0',
            width: '55px',
            borderRadius: '20px',
          }}
          >
            Inactive
          </div>
        </div>
      )
    ),
  },
  {
    sorting: false,
    title: '',
    render: (rowData: any) => (
      <OPRDropDown
        data={rowData}
        newOptions={['Edit movement type', 'Delete movement type']}
        onHandleclick={handleEdit}
      />
    ),
  },
]

// employee Movement

export const employeeMovementColumn = (handleEdit: any) => [
  {
    key: 'movementType',
    sorting: true,
    title: 'ent_emp_move_type_movement_type',
    render: (rowData: any) => <OPRLabel color="primary.main" label={rowData.movementType} />,
  },
  {
    key: 'effectiveDate',
    title: 'ent_curr_exch_currency_effective_dt',
    render: (rowData: any) => {
      const startDate = new Date(rowData.effectiveDate)
      const formattedStartDate = startDate.toLocaleDateString('en-GB', {
        day: '2-digit',
        month: 'short',
        year: 'numeric',
      })
      return (
        <OPRLabel
          label={`${formattedStartDate}`}
        />
      )
    },
  },
  {
    sorting: false,
    title: '',
    render: (rowData: any) => (
      <OPRDropDown
        data={rowData}
        newOptions={['Edit Movement', 'Withdraw Movement']}
        onHandleclick={handleEdit}
      />
    ),
  },
]
// Employee Average
const months = ['January', 'February', 'March', 'April', 'May', 'June',
  'July', 'August', 'September', 'October', 'November', 'December']
export const employeeAverageWageColumn = (handleEdit: any) => [
  {
    key: 'year',
    sorting: true,
    title: 'Pay cycle month & year',
    render: (rowData: any) => (
      <>
        <OPRLabel color="primary.main" label={`${months[rowData.month - 1]}`} />
        <OPRLabel label={`${rowData.year || '-'}`} />
      </>
    ),
  },
  {
    key: 'movementDescription',
    title: 'Start - End date | Covered days',
    render: (rowData: any) => (
      <>
        <OPRLabel label={`${customDateFormate(rowData.regardedWagesStartDate) ? customDateFormate(rowData.regardedWagesStartDate) : '-'} - ${customDateFormate(rowData.regardedWagesEndDate) || '-'}  ${rowData.coveredDay || '-'}`} />
        {/* <OPRLabel label={`${rowData.coveredDay}`} /> */}
      </>
    ),
  },
  {
    key: 'movementType',
    title: 'Last 12 months regarded wages',
    render: (rowData: any) => <OPRLabel label={rowData.last12MonthRegardedWages.toString() || '-'} />,
  },
  {
    key: 'movementDescription',
    title: 'Disregarded days',
    render: (rowData: any) => <OPRLabel label={rowData.disregardedDays.toString() || '-'} />,
  },
  {
    key: 'movementDescription',
    title: 'Daily Average | Monthly Average',
    render: (rowData: any) => (
      <>
        <OPRLabel label={`${rowData.currency} ${rowData.averageDailyWages.toString() || '-'}`} />
        <OPRLabel label={`${rowData.currency} ${rowData.averageMonthlyWages.toString() || '-'}`} />
      </>
    ),
  },
  {
    sorting: false,
    title: '',
    render: (rowData: any) => (
      <OPRDropDown
        data={rowData}
        newOptions={['Edit disregarded day']}
        onHandleclick={handleEdit}
      />
    ),
  },
]
// Entity pension fund scheme
export const entityPensionFundSchemeColumn = (handleEdit: any) => [
  {

    key: 'pensionFundSchemeCode',
    sorting: true,
    title: 'ent_pens_fund_scheme_code_header',
    render: (rowData: any) => <OPRLabel label={rowData.pensionFundSchemeCode} />,
  },
  {

    key: 'schemeDescription',
    title: 'ent_pens_fund_scheme_code_desc',
    render: (rowData: any) => <OPRLabel label={rowData.schemeDescription} />,
  },
  {

    key: 'schemeFileNumber',
    title: 'ent_pens_fund_scheme_file_number',
    render: (rowData: any) => <OPRLabel label={rowData.schemeFileNumber} />,
  },
  {

    key: 'status',
    title: 'ent_pens_fund_scheme_status',
    render: (rowData: any) => <OPRLabel label={rowData.status} />,
  },

  {
    sorting: false,
    title: 'action',
    render: (rowData: any) => (
      <OPRDropDown
        data={rowData}
        newOptions={[]}
        onHandleclick={handleEdit}
      />
    ),
  },
]
// Entity Pension Fund scheme rule
export const entitypensionFundSchemeRuleCols = (handleEdit: any) => [
  {

    key: 'pensionFundSchemeRuleType',
    sorting: true,
    title: 'ent_pens_fund_scheme_rule_type',
    render: (rowData: any) => <OPRLabel color="primary.main" label={rowData.pensionFundSchemeRuleType} />,
  },
  {
    key: 'effectiveDates',
    title: 'pension_fund_schme_item_date',
    render: (rowData: any) => {
      const startDate = new Date(rowData.effectiveStartDate)
      const formattedStartDate = startDate.toLocaleDateString('en-GB', {
        day: '2-digit',
        month: 'short',
        year: 'numeric',
      })

      const endDate = new Date(rowData.effectiveEndDate)
      const formattedEndDate = endDate.toLocaleDateString('en-GB', {
        day: '2-digit',
        month: 'short',
        year: 'numeric',
      })
      return (
        <OPRLabel
          label={`${formattedStartDate} - ${formattedEndDate}`}
        />
      )
    },
  },
  {
    key: 'effectiveDates',
    title: 'Relevant income min - max',
    render: (rowData: any) => {
      const minAmount = rowData.relevantIncomeMinAmount.toFixed(2) // Format to two decimal places if needed
      const maxAmount = rowData.relevantIncomeMaxAmount.toFixed(2) // Format to two decimal places if needed

      return (
        <OPRLabel
          label={`${minAmount} - ${maxAmount}`}
        />
      )
    },
  },

  {
    sorting: false,
    title: '',
    render: (rowData: any) => (
      <OPRDropDown
        data={rowData}
        newOptions={['Edit Pension Fund Scheme Rule', 'Delete Pension Fund Scheme Rule']}
        onHandleclick={handleEdit}
      />
    ),
  },
]
// Entity Cost center
export const abc = (handleEdit: any) => [
  // title:"Cost Center Name"
  {
    title: `${t('cost_Center_Description')} | ${t('cost_Center_Code')}`,
    key: 'costCenterDescription',
    sorting: true,
    render: (rowData: any) => (
      <>
        <OPRLabel color="primary.main" label={rowData.costCenterDescription} />
        <OPRLabel color="topAdmin.main" label={rowData.costCenterCode} />
      </>
    ),
  },
  {
    sorting: false,
    title: '',
    render: (rowData: any) => (
      <OPRDropDown
        data={rowData}
        newOptions={['edit cost center', 'delete cost center']}
        onHandleclick={handleEdit}
      />
    ),
  },
]

export const personEmployeeColumn = (handleEdit: any) => [
  {
    key: 'id',
    sorting: true,
    title: 'person_id',
    render: (rowData: any) => (
      <div>{rowData.id}</div>
      // <OPRLabel
      //   color="red"
      //   label={rowData
      //     .id}
      // />
    ),
  },
  {
    key: 'personName',
    title: 'person_name',
    render: (rowData: any) => <OPRLabel label={rowData.personName} />,
  },
  {
    key: 'clientGroupProfileId',
    title: 'current_entity_code',
    render: (rowData: any) => <OPRLabel label={rowData.clientGroupProfileId} />,
  },
  {
    sorting: false,
    title: 'action',
    render: (rowData: any) => (
      <OPRDropDown
        data={rowData}
        newOptions={[]}
        onHandleclick={handleEdit}
      />
    ),
  },
]

export const standardExpressionColumn = (handleEdit: any) => [

  {
    key: 'expressionCode',
    sorting: true,
    title: 'expression_code',
    render: (rowData: any) => <OPRLabel label={rowData.expressionCode} />,
  },
  {
    sorting: false,
    title: 'action',
    render: (rowData: any) => (
      <OPRDropDown
        data={rowData}
        newOptions={[]}
        onHandleclick={handleEdit}
      />
    ),
  },
]

export const standardFormulaColumn = (handleEdit: any) => [

  {

    key: 'formulaCode',
    sorting: true,
    title: 'formula_code',
    render: (rowData: any) => <OPRLabel label={rowData.formulaCode} />,
  },

  {
    sorting: false,
    title: 'action',
    render: (rowData: any) => (
      <OPRDropDown
        data={rowData}
        newOptions={[]}
        onHandleclick={handleEdit}
      />
    ),
  },
]

// provider type
export const providerTypeColumn = (handleEdit: any) => [
  {
    title: `${t('Provider Name')} | ${t('Provider ID')}`,
    key: 'providerName',
    sorting: true,
    render: (rowData: any) => (
      <>
        <OPRLabel color="primary.main" label={rowData.providerCode} />
        <OPRLabel color="topAdmin.main" label={rowData.providerName} />
      </>
    ),
  },
  // {
  //   title: 'provider_code',
  //   sorting: true,
  //   render: (rowData: any) => <OPRLabel color="primary.main" label={rowData.providerCode} />,
  // },
  // {
  //   title: 'Provider Name',
  //   sorting: true,
  //   render: (rowData: any) => <OPRLabel label={rowData.providerName} />,
  // },
  {
    title: 'provider_type',
    render: (rowData: any) => <OPRLabel label={rowData.providerType} />,
  },
  {
    title: 'Provider_types_country',
    render: (rowData: any) => <OPRLabel label={rowData.countryLocalization} />,
  },
  {
    sorting: false,
    title: '',
    render: (rowData: any) => (
      <OPRDropDown
        data={rowData}
        newOptions={['Edit Provider type', 'Delete Provider type']}
        onHandleclick={handleEdit}
      />
    ),

  },
]

// User Accounts
const ActiveUserMenu = (handleEdit: any, rowData: any): OPRActionMenuOption[] => [
  {
    title: t('Edit user account'),
    value: 'edit_user_account',
    action: (option) => handleEdit?.(rowData, option.value),
  },
  {
    title: t('Duplicate user access'),
    value: 'duplicate_user_access',
    divider: true,
    action: (option) => handleEdit?.(rowData, option.value),
  },
  {
    title: t('Deactivate user account'),
    value: 'deactivate_user_account',
    destructive: true,
    action: (option) => handleEdit?.(rowData, option.value),
  },
  {
    title: t('Delete user account'),
    value: 'delete_user_account',
    destructive: true,
    action: (option) => handleEdit?.(rowData, option.value),
  },
]

const InactiveUserMenu = (handleEdit: any, rowData: any): OPRActionMenuOption[] => [
  {
    title: t('Activate user account'),
    value: 'activate_user_account',
    action: (option) => handleEdit?.(rowData, option.value),
  },
  {
    title: t('Edit user account'),
    value: 'edit_user_account',
    action: (option) => handleEdit?.(rowData, option.value),
  },
  {
    title: t('Duplicate user access'),
    value: 'duplicate_user_access',
    divider: true,
    action: (option) => handleEdit?.(rowData, option.value),
  },
  {
    title: t('Delete user account'),
    value: 'delete_user_account',
    destructive: true,
    action: (option) => handleEdit?.(rowData, option.value),
  },
]

export const userAccountsColumn = (handleEdit: any) => [
  {
    key: 'username',
    sorting: true,
    title: 'name_userid',
    render: (rowData: any) => (
      <>
        <OPRLabel color="primary.main" label={`${rowData.firstName} ${rowData.lastName}`} />
        <OPRLabel label={rowData.username} />
      </>
    ),
  },
  {
    title: 'entities',
    render: (rowData: any) => <OPRLabel label={`${rowData.entityCount} entities`} />,
  },
  {
    title: 'status',
    render: (rowData: any) => <OPRLabel label={rowData.accountStatus} />,
  },
  {
    title: 'action',
    render: (rowData: any) => (
      <OPRActionMenu
        options={rowData.accountStatus === 'Active' ? ActiveUserMenu(handleEdit, rowData) : InactiveUserMenu(handleEdit, rowData)}
        onClose={() => {

        }}
      />
    ),
  },
]
// Termination Code
export const entityTerminationCodeColumn = (handleEdit: any) => [
  {
    title: `${t('termination_description')}|${t('termination_code')}`,
    key: 'terminationReason',
    sorting: true,
    render: (rowData: any) => (
      <>
        <OPRLabel color="primary.main" label={rowData.terminationReason} />
        <OPRLabel color="topAdmin.main" label={rowData.terminationCode} />
      </>
    ),
  },

  // {
  //   key: 'terminationCode',
  //   sorting: true,
  //   title: 'division_code',
  //   render: (rowData: any) => <OPRLabel color="primary.main" label={rowData.terminationCode} />,
  // },
  // {
  //   key: 'terminationReason',
  //   sorting: true,
  //   title: 'termination_description',
  //   render: (rowData: any) => <OPRLabel label={rowData.terminationReason} />,
  // },
  {
    sorting: false,
    title: '',
    render: (rowData: any) => (
      <OPRDropDown
        data={rowData}
        newOptions={['Edit Termination Code', 'Delete Termination Code']}
        onHandleclick={handleEdit}
      />
    ),
  },
]

const getRoleTypDescription = (roleType: boolean) => {
  if (roleType) {
    return 'System Admin'
  }
  return 'Regular User'
}

// User Roles
export const userRolesColumn = (handleEdit: any) => [
  {
    key: 'roleCode',
    sorting: true,
    title: 'user_roles_column_role_name_id',
    render: (rowData: any) => (
      <>
        <OPRLabel color="primary.main" label={rowData.roleName} />
        <OPRLabel color="topAdmin.main" label={rowData.roleCode} />
      </>
    ),
  },
  {
    title: 'user_roles_column_role_type',
    render: (rowData: any) => <OPRLabel label={getRoleTypDescription(rowData.roleType)} />,
  },
  {
    title: 'user_roles_column_number_of_users_granted',
    render: (rowData: any) => <OPRLabel label={`${rowData.userCount}`} />,
  },
  {
    sorting: false,
    title: 'action',
    render: (rowData: any) => (
      <OPRDropDown
        data={rowData}
        newOptions={['Edit user role', 'Delete user role']}
        onHandleclick={handleEdit}
      />
    ),
  },
]

export const entitySelectColumn = (handleClick: any) => [
  // {
  //   title: 'Entity ',
  //   render: (rowData: any) => (
  //     <OPRLabel label="" />
  //   ),
  // },
  // {
  //   key: 'entityName',
  //   sorting: true,
  //   title: 'Entity Name',
  //   render: (rowData: any) => (
  //     <OPRLabel label={rowData.entityName} />
  //   ),
  // },
  // {
  //   title: 'group_name',
  //   render: (rowData: any) => <OPRLabel label={rowData.clientGroupName} />,
  // },
]

export const uerRoleSelectColumn = (handleClick?: any) => [
  {
    key: 'entityName',
    sorting: true,
    title: 'Entity',
    render: (rowData: any) => (
      <OPRLabel label={rowData.entityName} />
    ),
  },
  {
    title: 'client_group',
    render: (rowData: any) => <OPRLabel label={rowData.clientGroupName} />,
  },
  {
    title: 'user_role_title',
    render: (rowData: any) => <OPRLabel label={rowData.userRole} />,
  },
]

const statusStyle = (status:any) => {
  const data = {
    paddingLeft: 8,
    paddingRight: 8,
    paddingTop: 4,
    paddingBottom: 4,
    background: status ? '#EBFFF0' : '#E8E6E7',
    borderRadius: 12,
    overflow: 'hidden',
    justifyContent: 'center',
    alignItems: 'center',
    gap: 8,
    display: 'inline-flex',
    color: status ? '#00701C' : '#3B3839',
    fontSize: 12,
    fontFamily: 'Lato',
    fontWeight: 700,
  }
  return data
}

export const employeeProfileColumn = (handleEdit: any) => [
  {
    key: 'employeeCode',
    title: 'Employee name | Employee ID',
    sorting: true,
    render: (rowData: any) => (
      <>
        <OPRLabel color="primary.main" label={`${rowData.employeeProfile.givenName}`} />
        <OPRLabel label={rowData.employeeCode} />
      </>
    ),
  },
  {
    title: ' Commencement date',
    render: (rowData: any) => {
      const date = new Date(rowData.commencementDate)

      const d = new Intl.DateTimeFormat('en-GB', { year: 'numeric', month: 'short', day: '2-digit' }).format(date).split(' ').join(' ')
      return <OPRLabel color="primary.main" label={d} />
    },
  },
  {
    title: 'Payroll indicator',
    render: (rowData: any) => (
      <OPRLabel label={rowData.employeeProfile.payrollIndicator} />
    ),
  },
  {
    title: 'Employment status',
    render: (rowData: any) => <OPRLabel CustomStyles={{ ...statusStyle(rowData.employeeProfile.employmentStatus) }} label={rowData.employeeProfile.employmentStatus} />,
  },
  {
    sorting: false,
    title: 'action',
    render: (rowData: any) => (
      <OPRDropDown
        data={rowData}
        newOptions={['', 'delete Employee Profile']}
        onHandleclick={handleEdit}
      />
    ),
  },
]

// employee bank account

export const employeeBankAccountColumn = (handleEdit: any, arrayList:any) => [
  {
    key: 'accountNumber',
    sorting: true,
    title: 'Beneficiary name | Account number',
    render: (rowData: any) => (
      <>
        <OPRLabel color="primary.main" label={`${rowData?.accountName}`} />
        <OPRLabel label={rowData?.accountNumber} />
      </>
    ),
  },
  {
    title: 'Bank name | Bank code (Branch code)',
    render: (rowData: any) => (
      <>
        <OPRLabel label={rowData?.accountName} />
        <OPRLabel label={rowData?.branchCode} />
      </>
    ),
  },
  {
    title: 'Company bank account',
    render: (rowData: any) => {
      const account = arrayList?.find((account:any) => account?.companyBankAccountCode === rowData?.companyBankAccountCode)
      const description = account ? account?.companyBankAccountDescription : null
      return (
        <OPRLabel label={`${description}(${rowData?.companyBankAccountCode})`} />
      )
    },
  },
  {
    title: 'Effective date',
    render: (rowData: any) => (
      <OPRLabel label={customDateFormate(rowData?.effectiveDate)} />
    ),
  },

  {
    sorting: false,
    title: 'action',
    render: (rowData: any) => (
      <OPRDropDown
        data={rowData}
        newOptions={['Edit Employee Bank']}
        onHandleclick={handleEdit}
      />
    ),
  },
]
// Report
export const standardReportColumn = (handleEdit: any) => [
  {
    key: '',
    sorting: true,
    title: 'Report group',
    render: (rowData: any) => (
      <OPRLabel color="primary.main" label={`${rowData?.jobs[0]?.reportGroup?.name || '-'}`} />
    ),
  },
  {
    title: 'Generation references',
    render: (rowData: any) => <OPRLabel color="primary.main" label={rowData.referenceNumber ? rowData.referenceNumber : '-'} />,
  },
  {

    title: 'Job ID | Job created date & by',
    render: (rowData: any) => {
      const data:any = (rowData?.jobs || []).map((item:any) => item?.jobId)
      const valuesString = data?.join(', ')
      return (
        <>
          <OPRLabel label={valuesString} />
          <OPRLabel
            CustomStyles={{
              color: '#666364',
              fontSize: 12,
              fontFamily: 'Lato',
              fontWeight: '400',
              lineHeight: 2,
              wordWrap: 'break-word',
            }}
            label={`${displayFormatDateTime(rowData?.jobs[0]?.createdAt)} by ${rowData?.createdByName} (${rowData?.createdByEmail})`}
          />
        </>
      )
    },
  },
  {
    title: 'Completed date',
    render: (rowData: any) => <OPRLabel label={rowData?.jobs[0]?.publishTime ? displayFormatDateTime(rowData?.jobs[0]?.publishTime) : '-'} />,
  },
  {
    title: 'Status',
    render: (rowData: any) => (
      <OPRLabel
        CustomStyles={{

          paddingLeft: 8,
          paddingRight: 8,
          paddingTop: 4,
          paddingBottom: 4,
          background: rowData?.jobs[0]?.jobStatus ? '#EBFFF0' : '#E8E6E7',
          borderRadius: 12,
          overflow: 'hidden',
          justifyContent: 'center',
          alignItems: 'center',
          gap: 8,
          display: 'inline-flex',
          // color: rowData?.jobs[0]?.jobStatus ? '#00701C' : '#3B3839',
          fontSize: 12,
          fontFamily: 'Lato',
          fontWeight: 700,
        }}
        label={rowData?.reportJobStatus ? rowData?.reportJobStatus : '-'}
      />
    ),
  },
  // {
  //   key: 'createdAt',
  //   sorting: true,
  //   title: 'File',
  //   render: (rowData: any) => <OPRButton color="primary" variant="text">Download Log File</OPRButton>,
  // },

]

// employee recurring
export const employeeRecurringItemsColumn = (handleEdit: any) => [
  {
    key: 'employeeCode',
    sorting: true,
    title: 'employee_recurring_title_code',
    render: (rowData: any) => (
      <>
        <OPRLabel color="primary.main" label={`${rowData.employeeCode}`} />
        <OPRLabel label={rowData.employeeCode} />
      </>
    ),
  },
  {
    title: 'employee_recurring_title_paycode',
    render: (rowData: any) => <OPRLabel color="primary.main" label={rowData.payItemCode} />,
  },
  {
    title: 'employee_recurring_title_payname',
    render: (rowData: any) => (
      <OPRLabel label={rowData.payItemName} />
    ),
  },
  {
    sorting: false,
    title: 'action',
    render: (rowData: any) => (
      <OPRDropDown
        data={rowData}
        newOptions={['Edit Recurring Item']}
        onHandleclick={handleEdit}
      />
    ),
  },
]
// formateDate
// periodFromDate periodToDate
export const employeeQuarterColumn = (handleEdit: any) => [
  {
    key: '',
    sorting: true,
    title: 'Period (From - To)',
    render: (rowData: any) => {
      const a = 'sandeep'
      return (
        <>
          <OPRLabel color="primary.main" label={`${customDateFormate(rowData?.periodFromDate)} - ${customDateFormate(rowData?.periodToDate)}`} />
          {/* <OPRLabel label={rowData.employeeCode} /> */}
        </>
      )
    },
  },
  {
    title: 'emp_quarters_nature',
    render: (rowData: any) => <OPRLabel color="primary.main" label={rowData.nature} />,
  },
  {
    title: 'emp_quarters_status',
    render: (rowData: any) => (
      <OPRLabel CustomStyles={{

        paddingLeft: 8,
        paddingRight: 8,
        paddingTop: 4,
        paddingBottom: 4,
        background: rowData.status ? '#EBFFF0' : '#E8E6E7',
        borderRadius: 12,
        overflow: 'hidden',
        justifyContent: 'center',
        alignItems: 'center',
        gap: 8,
        display: 'inline-flex',
        color: rowData.status ? '#00701C' : '#3B3839',
        fontSize: 12,
        fontFamily: 'Lato',
        fontWeight: 700,
      }}
      >
        {rowData.status ? 'Active' : 'Inactive'}
      </OPRLabel>
    ),
  },
  {
    sorting: false,
    title: '',
    render: (rowData: any) => (
      <OPRDropDown
        data={rowData}
        newOptions={['Delete employee quarter']}
        onHandleclick={handleEdit}
      />
    ),
  },
]

export const employeePensionFundColumn = (handleEdit: any) => [
  {
    key: 'pensionFundSchemeCode',
    sorting: true,
    title: 'Pension fund scheme name | Pension fund scheme ID',
    render: (rowData: any) => (
      <>
        <OPRLabel color="primary.main" label={`${rowData.pensionFundSchemeCode}`} />
        <OPRLabel label={rowData.entityPensionFundSchemeId} />
      </>
    ),
  },
  {
    title: 'employee_pension_fund_status',
    render: (rowData: any) => (
      <OPRLabel CustomStyles={{

        paddingLeft: 8,
        paddingRight: 8,
        paddingTop: 4,
        paddingBottom: 4,
        background: rowData.status ? '#EBFFF0' : '#E8E6E7',
        borderRadius: 12,
        overflow: 'hidden',
        justifyContent: 'center',
        alignItems: 'center',
        gap: 8,
        display: 'inline-flex',
        color: rowData.status ? '#00701C' : '#3B3839',
        fontSize: 12,
        fontFamily: 'Lato',
        fontWeight: 700,
      }}
      >
        {rowData.status ? 'Active' : 'Inactive'}
      </OPRLabel>
      // <OPRLabel label={rowData.status} />
    ),
  },
  {
    sorting: false,
    title: 'action',
    render: (rowData: any) => (
      <OPRDropDown data={rowData} newOptions={['Edit Pension Fund']} onHandleclick={handleEdit} />
    ),
  },
]

export const entityEmployeePassword = (
  handleEdit: any,
  handleCheckboxChange: any,
  selectedCodes: any,
) => [
  {
    key: 'employeeCode',
    sorting: true,
    title: 'emp_code_name',
    render: (rowData: any) => (
      <div>
        <div style={{ display: 'flex', alignItems: 'center' }}>
          <Checkbox
            checked={selectedCodes.includes(rowData?.employeeCode)} // Assuming 'key' is the unique identifier for each record
            onChange={(event) => handleCheckboxChange(event, rowData?.employeeCode)}
          />
          <OPRLabel
            color="primary.main"
            label={rowData?.employeeCode}
            sx={{ margin: '0px' }}
          />
        </div>
        <div style={{ display: 'block' }}>
          <OPRLabel color="topAdmin.main" label={rowData?.givenName} />
        </div>
      </div>
    ),
  },
  {
    key: 'departmentCode',
    title: 'department_code',
    render: (rowData: any) => <OPRLabel label={rowData.departmentCode} />,
  },
  {
    title: 'cost_Center_Code',
    render: (rowData: any) => <OPRLabel label={rowData.costCenterCode} />,
  },
  {
    key: 'expiryDate',
    title: 'Expiry Date',
    render: (rowData: any) => {
      if (rowData.expiryDate === null) {
        return <OPRLabel label="-" />
      }
      const startDate = new Date(rowData.expiryDate)
      const formattedStartDate = startDate.toLocaleDateString('en-GB', {
        day: '2-digit',
        month: 'short',
        year: 'numeric',
      })
      return (
        <OPRLabel
          label={formattedStartDate}
        />
      )
    },
  },
  {
    title: 'staff_type_code',
    render: (rowData: any) => <OPRLabel label={rowData.staffTypeCode} />,
  },
  {
    sorting: false,
    title: 'action',
    render: (rowData: any) => (
      <OPRDropDown data={rowData} newOptions={['Generate Password']} onHandleclick={handleEdit} />
    ),
  },

]

// entity Company BAnk Account
export const companyBankAccountColumn = (handleEdit: any) => [

  {
    key: 'companyBankAccountCode',
    sorting: true,
    title: 'bank_account_name_id',
    render: (rowData: any) => (
      <>
        <OPRLabel color="primary.main" label={rowData.companyBankAccountDescription} />
        <OPRLabel color="topAdmin.main" label={rowData.companyBankAccountCode} />
      </>
    ),
  },

  {
    key: 'status',
    title: 'status',
    render: (rowData: any) => (
      <OPRLabel CustomStyles={{

        paddingLeft: 8,
        paddingRight: 8,
        paddingTop: 4,
        paddingBottom: 4,
        background: rowData.status ? '#EBFFF0' : '#E8E6E7',
        borderRadius: 12,
        overflow: 'hidden',
        justifyContent: 'center',
        alignItems: 'center',
        gap: 8,
        display: 'inline-flex',
        color: rowData.status ? '#00701C' : '#3B3839',
        fontSize: 12,
        fontFamily: 'Lato',
        fontWeight: 700,
      }}
      >
        {rowData.status ? 'Active' : 'Inactive'}
      </OPRLabel>
    ),
  },

  {
    sorting: false,
    title: '',
    render: (rowData: any) => (
      <OPRDropDown
        data={rowData}
        newOptions={['edit company', 'delete company bank account']}
        onHandleclick={handleEdit}
      />
    ),
  },
]

export const pensionFundSchemeColumn = (handleEdit: any) => [

  {
    key: 'pensionFundSchemeCode',
    sorting: true,
    title: 'pension_fund_scheme_name_id',
    render: (rowData: any) => (
      <>
        <OPRLabel color="primary.main" label={rowData?.pensionFundSchemeCode} />
        <OPRLabel color="topAdmin.main" label={rowData?.schemeDescription} />
      </>
    ),
  },
  {
    title: 'ent_pens_fund_scheme_file_number',
    render: (rowData: any) => <OPRLabel label={rowData?.schemeFileNumber} />,
  },
  {
    key: 'status',
    title: 'status',
    render: (rowData: any) => (
      <OPRLabel CustomStyles={{

        paddingLeft: 8,
        paddingRight: 8,
        paddingTop: 4,
        paddingBottom: 4,
        background: rowData?.status ? '#EBFFF0' : '#E8E6E7',
        borderRadius: 12,
        overflow: 'hidden',
        justifyContent: 'center',
        alignItems: 'center',
        gap: 8,
        display: 'inline-flex',
        color: rowData.status ? '#00701C' : '#3B3839',
        fontSize: 12,
        fontFamily: 'Lato',
        fontWeight: 700,
      }}
      >
        {rowData?.status ? 'Active' : 'Inactive'}
      </OPRLabel>
    ),
  },

  {
    sorting: false,
    title: 'action',
    render: (rowData: any) => (
      <OPRDropDown
        data={rowData}
        newOptions={['Edit pension fund scheme', 'Delete pension fund scheme']}
        onHandleclick={handleEdit}
      />
    ),
  },
]
// pay item master pension fund item filed
export const pensionFundItemPayItemColumn = (handleEdit: any) => [

  {
    key: 'pensionFundSchemeCode',
    sorting: true,
    title: `${t('Pension fund scheme name')} | ${t('Pension fund scheme ID')}`,

    render: (rowData: any) => (
      <>
        <OPRLabel color="primary.main" label={rowData.pensionFundSchemeCode} />
        <OPRLabel color="topAdmin.main" label={rowData.pensionFundSchemeCode} />
      </>
    ),
  },
  // {
  //   key: 'payItemCode',
  //   sorting: true,
  //   title: 'Pay item',
  //   render: (rowData: any) => <OPRLabel label={rowData.payItemCode} />,
  // },
  {
    key: 'effectiveDates',
    title: 'pension_fund_schme_item_date',
    render: (rowData: any) => {
      const startDate = new Date(rowData.effectiveStartDate)
      const formattedStartDate = startDate.toLocaleDateString('en-GB', {
        day: '2-digit',
        month: 'short',
        year: 'numeric',
      })

      const endDate = new Date(rowData.effectiveEndDate)
      const formattedEndDate = endDate.toLocaleDateString('en-GB', {
        day: '2-digit',
        month: 'short',
        year: 'numeric',
      })
      return (
        <OPRLabel
          label={`${formattedStartDate} - ${formattedEndDate}`}
        />
      )
    },
  },

  // {
  //   key: 'status',
  //   sorting: true,
  //   title: 'status',
  //   render: (rowData: any) => (
  //     <OPRLabel CustomStyles={{

  //       paddingLeft: 8,
  //       paddingRight: 8,
  //       paddingTop: 4,
  //       paddingBottom: 4,
  //       background: rowData.status ? '#EBFFF0' : '#E8E6E7',
  //       borderRadius: 12,
  //       overflow: 'hidden',
  //       justifyContent: 'center',
  //       alignItems: 'center',
  //       gap: 8,
  //       display: 'inline-flex',
  //       color: rowData.status ? '#00701C' : '#3B3839',
  //       fontSize: 12,
  //       fontFamily: 'Lato',
  //       fontWeight: 700,
  //     }}
  //     >
  //       {rowData.status ? 'Active' : 'Inactive'}
  //     </OPRLabel>
  //   ),
  // },
  {
    sorting: false,
    title: '',
    render: (rowData: any) => (
      <OPRDropDown
        data={rowData}
        newOptions={['Edit Pension Fund Scheme Item', 'Delete Pension Fund Scheme Item']}
        onHandleclick={handleEdit}
      />
    ),
  },
]

export const entitypensionFundSchemeItemsColumn = (handleEdit?: any) => [
  {
    key: 'payItemCode',
    sorting: true,
    title: 'payItemCode',
    render: (rowData: any) => <OPRLabel label={rowData.payItemCode} />,
  },
  {
    key: 'effectiveDates',
    title: 'pension_fund_schme_item_date',
    render: (rowData: any) => {
      const startDate = new Date(rowData.effectiveStartDate)
      const formattedStartDate = startDate.toLocaleDateString('en-GB', {
        day: '2-digit',
        month: 'short',
        year: 'numeric',
      })

      const endDate = new Date(rowData.effectiveEndDate)
      const formattedEndDate = endDate.toLocaleDateString('en-GB', {
        day: '2-digit',
        month: 'short',
        year: 'numeric',
      })
      return (
        <OPRLabel
          label={`${formattedStartDate} - ${formattedEndDate}`}
        />
      )
    },
  },
  {
    key: 'status',
    title: 'status',
    render: (rowData: any) => (
      <OPRLabel CustomStyles={{

        paddingLeft: 8,
        paddingRight: 8,
        paddingTop: 4,
        paddingBottom: 4,
        background: rowData.status ? '#EBFFF0' : '#E8E6E7',
        borderRadius: 12,
        overflow: 'hidden',
        justifyContent: 'center',
        alignItems: 'center',
        gap: 8,
        display: 'inline-flex',
        color: rowData.status ? '#00701C' : '#3B3839',
        fontSize: 12,
        fontFamily: 'Lato',
        fontWeight: 700,
      }}
      >
        {rowData.status ? 'Active' : 'Inactive'}
      </OPRLabel>
    ),
  },
  {
    sorting: false,
    title: '',
    render: (rowData: any) => (
      <OPRDropDown
        data={rowData}
        newOptions={['Edit Pension Fund Scheme Item', 'Delete Pension Fund Scheme Item']}
        // onHandleclick={handleEdit}
      />
    ),
  },
]
// pensionschemeModal column
export const pensionSchemeModalColumn = (handleClick?: any) => [
  {
    key: 'payItemCode',
    sorting: true,
    title: 'ent_pens_fund_scheme_title',
    render: (rowData: any) => <OPRLabel label={rowData.payItemCode} />,
  },
  {
    key: 'effectiveDates',
    title: 'pension_fund_schme_item_date',
    render: (rowData: any) => {
      const startDate = new Date(rowData.effectiveStartDate)
      const formattedStartDate = startDate.toLocaleDateString('en-GB', {
        day: '2-digit',
        month: 'short',
        year: 'numeric',
      })

      const endDate = new Date(rowData.effectiveEndDate)
      const formattedEndDate = endDate.toLocaleDateString('en-GB', {
        day: '2-digit',
        month: 'short',
        year: 'numeric',
      })
      return (
        <OPRLabel
          label={`${formattedStartDate} - ${formattedEndDate}`}
        />
      )
    },
  },
]

// 'Unfinalized batch'
const FinalizedMenu = (handleEdit: any, rowData: any): OPRActionMenuOption[] => [
  {
    title: t('Unfinalize batch'),
    value: 'unfinalize_batch',
    info: { nextState: 'Unfinalized' },
    action: (option) => handleEdit?.(rowData, option),
  },
]

// 'Finalize batch', 'Unlock batch', 'Edit pay cycle'
const UnfinalizedMenu = (handleEdit: any, rowData: any): OPRActionMenuOption[] => [
  {
    title: t('Deactivate batch'),
    value: 'deactivate_batch',
    info: { nextState: 'Inactive' },
    action: (option) => handleEdit?.(rowData, option),
  },
  {
    title: t('Edit pay cycle'),
    value: 'edit_pay_cycle',
    action: (option) => handleEdit?.(rowData, option),
  },
]

// 'Finalize batch', 'Unlock batch', 'Edit pay cycle'
const LockedMenu = (handleEdit: any, rowData: any): OPRActionMenuOption[] => [
  {
    title: t('Unlock batch'),
    value: 'unlock_batch',
    info: { nextState: 'Unlocked' },
    action: (option) => handleEdit?.(rowData, option),
  },
  {
    title: t('Finalize batch'),
    value: 'finalize_batch',
    info: { nextState: 'Finalized' },
    action: (option) => handleEdit?.(rowData, option),
  },
  {
    title: t('Edit pay cycle'),
    value: 'edit_pay_cycle',
    action: (option) => handleEdit?.(rowData, option),
  },
]

// 'Drop batch on selected employee', 'Drop whole batch', 'Edit pay cycle'
const UnlockedMenu = (handleEdit: any, rowData: any): OPRActionMenuOption[] => [
  {
    title: t('Drop batch on selected employee'),
    value: 'drop_batch_on_selected_employee',
    action: (option) => handleEdit?.(rowData, option),
  },
  {
    title: t('Drop whole batch'),
    value: 'drop_whole_batch',
    info: { nextState: 'PF Dropped' },
    action: (option) => handleEdit?.(rowData, option),
  },
  {
    title: t('Lock batch'),
    value: 'lock_batch',
    info: { nextState: 'Locked' },
    action: (option) => handleEdit?.(rowData, option),
  },
  {
    title: t('Edit pay cycle'),
    value: 'edit_pay_cycle',
    action: (option) => handleEdit?.(rowData, option),
  },
]

// 'Lock batch', 'Edit pay cycle'
const PFDroppedMenu = (handleEdit: any, rowData: any): OPRActionMenuOption[] => [
  {
    title: t('Drop batch on selected employee'),
    value: 'drop_batch_on_selected_employee',
    action: (option) => handleEdit?.(rowData, option),
  },
  {
    title: t('Drop whole batch'),
    value: 'drop_whole_batch',
    info: { nextState: 'PF Dropped' },
    action: (option) => handleEdit?.(rowData, option),
  },
  {
    title: t('Edit pay cycle'),
    value: 'edit_pay_cycle',
    action: (option) => handleEdit?.(rowData, option),
  },
]

// 'Lock batch', 'Deactivate batch', 'Edit pay cycle', 'Delete pay cycle'
const OpenMenu = (handleEdit: any, rowData: any): OPRActionMenuOption[] => [
  {
    title: t('Deactivate batch'),
    value: 'deactivate_batch',
    info: { nextState: 'Inactive' },
    action: (option) => handleEdit?.(rowData, option),
  },
  {
    title: t('Edit pay cycle'),
    value: 'edit_pay_cycle',
    action: (option) => handleEdit?.(rowData, option),
  },
]

// 'Open batch', 'Edit pay cycle', 'Delete pay cycle'
const InactiveMenu = (handleEdit: any, rowData: any): OPRActionMenuOption[] => [
  {
    title: t('Open batch'),
    value: 'open_batch',
    info: { nextState: 'Open' },
    action: (option) => handleEdit?.(rowData, option),
  },
  {
    title: t('Edit pay cycle'),
    value: 'edit_pay_cycle',
    action: (option) => handleEdit?.(rowData, option),
  },
]

const CompletedMenu = (handleEdit: any, rowData: any): OPRActionMenuOption[] => [
  {
    title: t('Drop batch on selected employee'),
    value: 'drop_batch_on_selected_employee',
    action: (option) => handleEdit?.(rowData, option),
  },
  {
    title: t('Drop whole batch'),
    value: 'drop_whole_batch',
    info: { nextState: 'PF Dropped' },
    action: (option) => handleEdit?.(rowData, option),
  },
  {
    title: t('Lock batch'),
    value: 'lock_batch',
    info: { nextState: 'Locked' },
    action: (option) => handleEdit?.(rowData, option),
  },
  {
    title: t('Edit pay cycle'),
    value: 'edit_pay_cycle',
    divider: true,
    action: (option) => handleEdit?.(rowData, option),
  },
]

const PayCycleActionMap: Record<PayCycleStatus, (handleEdit: any, rowData: any) => OPRActionMenuOption[]> = {
  Finalized: FinalizedMenu,
  Unfinalized: UnfinalizedMenu,
  Locked: LockedMenu,
  Unlocked: UnlockedMenu,
  'PF Dropped': PFDroppedMenu,
  Open: OpenMenu,
  Inactive: InactiveMenu,
  Completed: CompletedMenu,
}

// payitem administrators
export const payCycleAdministratorColumn = (handleEdit: any) => [
  {
    key: 'payCycleName',
    sorting: true,
    title: `${t('Pay Cycle')}|${t('Month & Year')}`,
    render: (rowData: any) => {
      const monthYear = new Date(`${rowData?.payCycleYear}-${rowData?.payCycleMonth}`)
      const formattedMonthYear = monthYear.toLocaleString('default', { month: 'long', year: 'numeric' })

      return (
        <>
          <OPRLabel color="primary.main" label={rowData?.payCycleName} />
          <OPRLabel color="topAdmin.main" label={formattedMonthYear} />
        </>
      )
    },
  },
  // payroll period
  {
    key: 'payCycleStartDate',
    title: 'Payroll period',
    render: (rowData: any) => {
      const startDate = new Date(rowData.payCycleStartDate)
      const formattedStartDate = startDate.toLocaleDateString('en-GB', {
        day: '2-digit',
        month: 'short',
        year: 'numeric',
      })

      const endDate = new Date(rowData.payCycleEndDate)
      const formattedEndDate = endDate.toLocaleDateString('en-GB', {
        day: '2-digit',
        month: 'short',
        year: 'numeric',
      })
      return (
        <OPRLabel
          label={`${formattedStartDate} - ${formattedEndDate}`}
        />
      )
    },
  },

  // Type
  {
    key: 'type',
    title: 'Type',
    render: (rowData: any) => <OPRLabel label={rowData?.payCycleType?.label} />,
  },
  // status
  {
    key: 'status',
    title: 'Status',
    render: (rowData: any) => <OPRStatusChip status={rowData?.status?.label} />,
  },
  {
    sorting: false,
    title: '',
    render: (rowData: any) => {
      const callback = PayCycleActionMap[rowData.status.label as PayCycleStatus]
      let options: OPRActionMenuOption[] = []
      if (callback) {
        options = callback(handleEdit, rowData)
      }
      return (
        <OPRActionMenu
          options={options}
          onClose={() => {
          }}
        />
      )
    },
  },
]

// entityCustomReportDesignerColumn
export const entityCustomReportDesignerColumn = (handleEdit: any) => [
  {
    title: `${t('Report Name')} | ${t('Report ID')}`,
    key: 'reportName',
    sorting: true,
    render: (rowData: any) => (
      <>
        <OPRLabel color="primary.main" label={rowData.reportName} />
        <OPRLabel label={rowData.reportCode} />
      </>
    ),
  },
  {
    title: 'Report format',
    render: (rowData: any) => (
      <div>
        {rowData.reportFormats.map((format: string, index: number) => (
          <OPRLabel label={format} />
        ))}
      </div>
    ),
  },
  {
    sorting: false,
    title: '',
    render: (rowData: any) => (
      <OPRDropDown
        data={rowData}
        newOptions={['', 'delete custom report']}
        onHandleclick={handleEdit}
      />
    ),
  },
]
/// payroll month end closing
export const payrollMonthEndClosingColumn = (handleEdit: any) => [
  {
    key: 'payCycleName',
    sorting: true,
    title: `${t('Pay Cycle')}`,
    render: (rowData: any) => (
      <OPRLabel label={`${rowData?.payCycleName} - (${rowData?.payCycleCode})`} />
    ),
  },
  // payroll period
  {
    key: 'payCycleStartDate',
    title: 'Payroll period',
    render: (rowData: any) => {
      const startDate = new Date(rowData.payCycleStartDate)
      const formattedStartDate = startDate.toLocaleDateString('en-GB', {
        day: '2-digit',
        month: 'short',
        year: 'numeric',
      })

      const endDate = new Date(rowData.payCycleEndDate)
      const formattedEndDate = endDate.toLocaleDateString('en-GB', {
        day: '2-digit',
        month: 'short',
        year: 'numeric',
      })
      return (
        <OPRLabel
          label={`${formattedStartDate} - ${formattedEndDate}`}
        />
      )
    },
  },
  // Type
  {
    key: 'type',
    title: 'Type',
    render: (rowData: any) => <OPRLabel label={rowData?.payCycleType?.label} />,
  },
  {
    key: 'status',
    title: 'Status',
    render: (rowData: any) => {
      let backgroundColor
      let textColor

      if (rowData.status.label === 'Finalized') {
        backgroundColor = '#EBFFF0'
        textColor = '#00701C'
      } else if (rowData.status.label === 'Open') {
        backgroundColor = '#EBFFF0'
        textColor = '#9E5A00'
      } else if (rowData.status.label === 'Inactive') {
        backgroundColor = '#F0F0F0'
        textColor = '#808080'
      } else if (rowData.status.label === 'Locked') {
        backgroundColor = '#EBFFF0'
        textColor = '#FF0000'
      } else {
        backgroundColor = '#E8E6E7'
        textColor = '#3B3839'
      }

      return (
        <OPRLabel
          CustomStyles={{
            paddingLeft: 8,
            paddingRight: 8,
            paddingTop: 4,
            paddingBottom: 4,
            background: backgroundColor,
            borderRadius: 12,
            overflow: 'hidden',
            justifyContent: 'center',
            alignItems: 'center',
            gap: 8,
            display: 'inline-flex',
            color: textColor,
            fontSize: 12,
            fontFamily: 'Lato',
            fontWeight: 700,
          }}
          label={rowData?.status?.label}
        />
      )
    },
  },
]

export const logsPaycycle = (handleEdit: any) => [
  {
    key: 'payCycleCode',
    sorting: true,
    title: `${t('Pay cycle name')}|${t('Pay cycle ID')}`,
    render: (rowData: any) => {
      const monthYear = new Date(`${rowData?.payCycleYear}-${rowData?.payCycleMonth}`)
      const formattedMonthYear = monthYear.toLocaleString('default', { month: 'long', year: 'numeric' })

      return (
        <>
          <OPRLabel color="primary.main" label={rowData?.payrollMonth} />
          <OPRLabel color="topAdmin.main" label={rowData?.cycleCode} />
        </>
      )
    },
  },

  {
    title: 'Job ID | Job created date & by',
    render: (rowData: any) => (
      <>
        <OPRLabel color="primary.main" label={rowData?.jobRunId} />
        <OPRLabel color="topAdmin.main" label={rowData?.jobCreatedBy} />
      </>
    ),
  },

  {
    key: 'completedDate',
    title: 'Completed date',
    render: (rowData: any) => <OPRLabel label={rowData.completedDateTime} />,
  },
  {
    key: 'status',
    title: 'Status',
    render: (rowData: any) => {
      let color
      let background
      switch (rowData.status) {
        case 'Success':
        case 'Finalized':
        case 'Completed':
          color = '#00701C' // Green for success
          background = '#EBFFF0' // Light green background for success
          break
        case 'Failed':
          color = '#FF0000' // Red for failed
          background = '#FFEAEA' // Light red background for failed
          break
        case 'Pending':
          color = '#0000FF' // Blue for pending
          background = '#EAF0FF' // Light blue background for pending
          break
        default:
          color = '#3B3839' // Default text color
          background = '#EBEBEB' // Default background color
          break
      }
      return (
        <OPRLabel
          CustomStyles={{
            paddingLeft: 8,
            paddingRight: 8,
            paddingTop: 4,
            paddingBottom: 4,
            borderRadius: 12,
            overflow: 'hidden',
            justifyContent: 'center',
            alignItems: 'center',
            gap: 8,
            display: 'inline-flex',
            fontSize: 12,
            fontFamily: 'Lato',
            fontWeight: 700,
            color,
            background,
          }}
        >
          {rowData.status}
        </OPRLabel>
      )
    },
  },
  // {
  //   sorting: true,
  //   title: 'Intermediate step calculation',
  //   render: (rowData: any) => (
  //     <>

  //       {
  //         rowData.status === 'Failed' && rowData.selectedId
  //      && <OPRButton color="primary" variant="contained" onClick={() => handleEdit({ selectedId: rowData?.jobId })}>abc</OPRButton>
  //       }
  //     </>
  //   ),
  // },

  {
    title: 'Intermediate step calculation',
    render: (rowData: any) => (
      <>
        {' '}
        {
          // rowData.status === 'Failed' && rowData.jobId  &&
          <OPRButton color="primary" variant="text" onClick={() => handleEdit(rowData)}>Download step calculation file</OPRButton>
        }
      </>
    ),
  },

  {
    key: 'logFile',
    title: 'File',
    render: (rowData: any) => <OPRLabel label={rowData.logFile} />,

  },
]

export const payrollSlipColumn = (handleEdit: any) => [
  {
    key: 'referenceNumber',
    sorting: true,
    title: 'Generation references',
    render: (rowData: any) => <OPRLabel color="primary.main" label={rowData.referenceNumber ? rowData.referenceNumber : '-'} />,
  },
  // {
  //   title: 'Job ID | Job created date & by',
  //   render: (rowData: any) => (
  //     <>
  //       <OPRLabel label={rowData?.jobs[0]?.jobId} />
  //       <OPRLabel label={rowData?.jobs[0]?.createdAt} />
  //     </>
  //   ),
  // },
  {
    title: 'Job ID | Job created date & by',
    render: (rowData: any) => {
      const data:any = (rowData?.jobs || []).map((item:any) => item?.jobId)
      const valuesString = data?.join(', ')
      return (
        <>
          <OPRLabel label={valuesString} />
          <OPRLabel
            CustomStyles={{
              color: '#666364',
              fontSize: 12,
              fontFamily: 'Lato',
              fontWeight: '400',
              lineHeight: 2,
              wordWrap: 'break-word',
            }}
            label={`${displayFormatDateTime(rowData?.jobs[0]?.createdAt)} by ${rowData?.createdByName} (${rowData?.createdByEmail})`}
          />
        </>
      )
    },
  },
  {
    title: 'Completed date',
    render: (rowData: any) => <OPRLabel label={rowData?.publishTime ? displayFormatDateTime(rowData?.publishTime) : '-'} />,
  },
  {
    key: 'reportJobStatus',
    title: 'Status',
    render: (rowData: any) => {
      let color
      let background
      switch (rowData.reportJobStatus) {
        case 'Success':
          color = '#00701C' // Green for success
          background = '#EBFFF0' // Light green background for success
          break
        case 'Failed':
          color = '#FF0000' // Red for failed
          background = '#FFEAEA' // Light red background for failed
          break
        case 'Pending':
          color = '#0000FF' // Blue for pending
          background = '#EAF0FF' // Light blue background for pending
          break
        default:
          color = '#3B3839' // Default text color
          background = '#EBEBEB' // Default background color
          break
      }
      return (
        <OPRLabel
          CustomStyles={{
            paddingLeft: 8,
            paddingRight: 8,
            paddingTop: 4,
            paddingBottom: 4,
            borderRadius: 12,
            overflow: 'hidden',
            justifyContent: 'center',
            alignItems: 'center',
            gap: 8,
            display: 'inline-flex',
            fontSize: 12,
            fontFamily: 'Lato',
            fontWeight: 700,
            color,
            background,
          }}
        >
          {rowData.reportJobStatus}
        </OPRLabel>
      )
    },
  },
]

// email notification
export const emailProfileColumn = (handleEdit: any) => [

  {
    key: 'emailProfileName',
    sorting: true,
    title: 'email_profile_name_id',
    render: (rowData: any) => (
      <>
        <OPRLabel color="primary.main" label={rowData?.emailProfileName} />
        <OPRLabel color="topAdmin.main" label={rowData?.emailProfileCode} />
      </>
    ),
  },
  {
    title: 'Default',
    render: (rowData: any) => <OPRLabel label={rowData?.setAsDefaultEmailProfile ? 'Yes' : 'No'} />,
  },
  {
    sorting: false,
    title: 'action',
    render: (rowData: any) => (
      <OPRDropDown
        data={rowData}
        newOptions={['Edit email profile', 'Delete email profile']}
        onHandleclick={handleEdit}
      />
    ),
  },
]
// movement Modal
export const movementModalColumn = (handleEdit: any) => [
  // commencementDate
  // :
  // "1988-12-09T00:00:00"
  // employeeCode
  // :
  // "E01092"
  // employeeGivenName
  // :
  // "TEST E01092"
  // employeeStatus
  // :
  // "Active"
  // employeeSurname
  // :
  // "LIU"
  // employeeWorkEmailAddress
  // :
  // "mujeeb.ansari@hk.tricorglobal.com"
  // lastEmploymentDate 2024-07-12T00:00:00
  // :1988-12-09T00:00:00
  // "2024-07-12T00:00:00"
  {
    key: 'employeeCode',
    sorting: true,
    title: 'employee_name_code',
    render: (rowData: any) => (
      <>
        <OPRLabel color="primary.main" label={rowData?.employeeProfile?.givenName} />
        <OPRLabel color="topAdmin.main" label={rowData?.employeeCode} />
      </>
    ),
  },
  {
    title: 'Provider_Email_Address',
    render: (rowData: any) => <OPRLabel label={rowData?.employeeWorkEmailAddress} />,
  },
  {
    key: 'commencementDate',
    title: 'employee_profile_commencement_date',
    render: (rowData: any) => <OPRLabel label={rowData?.commencementDate} />,
  },
  {
    key: 'lastEmploymentDate',
    title: 'employee_profile_last_working_date',
    render: (rowData: any) => <OPRLabel label={rowData?.lastEmploymentDate} />,
  },
  {
    key: 'status',
    title: 'Employment status',
    render: (rowData: any) => (
      <OPRLabel CustomStyles={{

        paddingLeft: 8,
        paddingRight: 8,
        paddingTop: 4,
        paddingBottom: 4,
        background: rowData.employeeStatus ? '#EBFFF0' : '#E8E6E7',
        borderRadius: 12,
        overflow: 'hidden',
        justifyContent: 'center',
        alignItems: 'center',
        gap: 8,
        display: 'inline-flex',
        color: rowData.employeeStatus ? '#00701C' : '#3B3839',
        fontSize: 12,
        fontFamily: 'Lato',
        fontWeight: 700,
      }}
      >
        {rowData.employeeStatus ? 'Active' : 'Inactive'}
      </OPRLabel>
    ),
  }]

export const sendPaySlipColumn = (handleEdit: any) => [

  {
    key: '',
    sorting: true,
    title: 'employee_name_code',
    render: (rowData: any) => (
      <>
        <OPRLabel color="primary.main" label={rowData?.employeeDetail?.employeeGivenName} />
        <OPRLabel color="topAdmin.main" label={rowData?.employeeDetail?.employeeCode} />
      </>
    ),
  },
  {
    title: 'Provider_Email_Address',
    render: (rowData: any) => <OPRLabel label={rowData?.employeeDetail?.employeeWorkEmailAddress} />,
  },
  {
    key: 'fileName1',
    title: 'File Name 1',
    render: (rowData: any) => <OPRLabel label={rowData?.fileName} />,
  },
  {
    key: 'fileName2',
    title: 'File Name 2',
    render: (rowData: any) => <OPRLabel label={rowData?.fileName} />,
  },
  {
    key: 'fileName3',
    title: 'File Name 3',
    render: (rowData: any) => <OPRLabel label={rowData?.fileName} />,
  }]

export const reassignmentModalColumn = (handleEdit: any) => [

  {
    key: 'employeeCode',
    sorting: true,
    title: 'empl_name_empl_id',
    render: (rowData: any) => (
      <OPRLabel color="topAdmin.main" label={rowData?.employeeCode} />
    ),
  },
  {
    title: 'termination_date',
    render: (rowData: any) => {
      const terminationDate = new Date(rowData.terminationDate)
      const formattedDate = terminationDate.toLocaleDateString('en-GB', {
        day: '2-digit',
        month: 'long',
        year: 'numeric',
      })
      return (<OPRLabel label={formattedDate} />)
    },
  },
  {
    key: 'defaultMainCycleCode',
    title: 'default_main_cycle',
    render: (rowData: any) => <OPRLabel label={rowData.defaultMainCycleCode} />,
  },
  {
    key: 'changeToPayCycleCode',
    title: 'new_pay_cycle',
    render: (rowData: any) => <OPRLabel label="" />,
  }]
export const reassignmentConfirmModalColumn = (handleEdit: any) => [

  {
    key: 'employeeCode',
    sorting: true,
    title: 'empl_name_empl_id',
    render: (rowData: any) => (
      <OPRLabel color="topAdmin.main" label={rowData?.employeeCode} />
    ),
  },
  {
    key: 'defaultMainCycleCode',
    title: 'default_main_cycle',
    render: (rowData: any) => <OPRLabel label={rowData.defaultMainCycleCode} />,
  },
  {
    key: 'changeToPayCycleCode',
    title: 'new_pay_cycle',
    render: (rowData: any) => <OPRLabel label={rowData.changeToPayCycleCode} />,
  }]

export const logsPaycycleData = (handleEdit: any, checked: boolean, indeterminate: boolean, onChange: (event: React.ChangeEvent<HTMLInputElement>) => void) => [
  {
    key: '',
    sorting: true,
    title: `${t('Pay Cycle')}|${t('Month & Year')}`,
    render: (rowData: any) => {
      const monthYear = new Date(`${rowData?.payCycleYear}-${rowData?.payCycleMonth}`)
      const formattedMonthYear = monthYear.toLocaleString('default', { month: 'long', year: 'numeric' })

      return (
        <div>
          <div style={{ display: 'flex', alignItems: 'center' }}>
            <OPRCheckbox
              checked={checked}
              indeterminate={indeterminate}
              label=""
              sx={{ margin: '0px' }} // Set margin-right to 0 for the checkbox
              onChange={onChange}
            />
            <OPRLabel color="primary.main" label={rowData?.payCycleName} sx={{ margin: '0px' }} />
          </div>
          <div style={{ display: 'block' }}>
            <OPRLabel color="topAdmin.main" label={formattedMonthYear} />
          </div>
        </div>

      )
    },
  },

  {
    title: 'Job ID | Job created date & by',
    render: (rowData: any) => (
      <>

        <OPRLabel color="primary.main" label={rowData?.jobId} />
        <OPRLabel color="topAdmin.main" label={rowData?.createdBy} />
      </>
    ),
  },

  {
    key: 'completedDate',
    title: 'Completed date',
    render: (rowData: any) => <OPRLabel label={rowData.completedDate} />,
  },
  {
    key: 'createdAt',
    title: 'Status',
    render: (rowData: any) => <OPRLabel label={rowData.status.label} />,
  },
  {
    sorting: false,
    title: 'action',
    render: (rowData: any) => (
      <OPRDropDown
        data={rowData}
        newOptions={['Generate Password']}
        onHandleclick={handleEdit}
      />
    ),
  },
]

// audit trail logging
export const auditTrailCoulumn = (handleEdit: any) => [

  {
    key: 'referenceNumber',
    sorting: true,
    title: 'Generation references',
    render: (rowData: any) => <OPRLabel color="primary.main" label={rowData.referenceNumber} />,
  },
  {
    title: 'Job ID | Job created date & by',
    render: (rowData: any) => {
      const data:any = (rowData?.jobs || []).map((item:any) => item?.jobId)
      const valuesString = data?.join(', ')
      return (
        <>
          <OPRLabel label={valuesString} />
          <OPRLabel
            CustomStyles={{
              color: '#666364',
              fontSize: 12,
              fontFamily: 'Lato',
              fontWeight: '400',
              lineHeight: 2,
              wordWrap: 'break-word',
            }}
            label={`${displayFormatDateTime(rowData?.jobs[0]?.createdAt)} by ${rowData?.createdByName} (${rowData?.createdByEmail})`}
          />
        </>
      )
    },
  },
  {
    key: 'updatedAt',
    title: 'Completed date',
    render: (rowData: any) => <OPRLabel label={displayFormatDateTime(rowData?.jobs[0]?.updatedAt)} />,
  },
  {
    title: 'Status',
    render: (rowData: any) => (
      <OPRLabel label={rowData?.jobs[0]?.jobStatus} />
    ),
  },

]
export const sendEmailColumn = (handleEdit: any) => [

  {
    key: 'emailSubject',
    sorting: true,
    title: 'email_subject',
    render: (rowData: any) => (
      <OPRLabel color="primary.main" label={rowData?.emailSubject} />
    ),
  },
  {
    title: 'delivered',
    render: (rowData: any) => <OPRLabel label={rowData?.emailsSent} />,
  },
  {
    title: 'not_delivered',
    render: (rowData: any) => <OPRLabel label={rowData?.emailsNotSent === 0 ? '-' : rowData?.emailsNotSent} />,
  },
  {
    key: 'jobId',
    title: 'job_id_created_date_by',
    render: (rowData: any) => {
      const date = new Date(rowData.jobCreatedDateTime)
      const formattedDate = `${date.getDate()} ${date.toLocaleString('en-GB', { month: 'short' })} ${date.getFullYear()} ${date.toTimeString().split(' ')[0]}`
      return (
        <>
          <OPRLabel label={rowData.jobID} />
          <OPRLabel label={formattedDate} />
          <OPRLabel label={rowData.jobCreatedBy} />
        </>
      )
    },
  },
  {

    key: 'completedDate',
    title: 'bulk_upload_data_created_date',
    render: (rowData: any) => {
      const date = new Date(rowData.jobCreatedDateTime)
      const formateDate = date.toLocaleDateString('en-GB', {
        day: '2-digit',
        month: 'short',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit',
      })
      return (
        <OPRLabel label={formateDate} />
      )
    },
  },
  {
    key: 'status',
    title: 'status',
    render: (rowData: any) => (
      <OPRLabel>
        {rowData.status }
      </OPRLabel>
    ),
  },
  // {
  //   key: 'status',
  //   sorting: true,
  //   title: 'status',
  //   render: (rowData: any) => (
  //     <OPRLabel CustomStyles={{

  //       paddingLeft: 8,
  //       paddingRight: 8,
  //       paddingTop: 4,
  //       paddingBottom: 4,
  //       background: rowData.status ? '#EBFFF0' : '#E8E6E7',
  //       borderRadius: 12,
  //       overflow: 'hidden',
  //       justifyContent: 'center',
  //       alignItems: 'center',
  //       gap: 8,
  //       display: 'inline-flex',
  //       color: rowData.status ? '#00701C' : '#3B3839',
  //       fontSize: 12,
  //       fontFamily: 'Lato',
  //       fontWeight: 700,
  //     }}
  //     >
  //       {rowData.status ? 'Active' : 'Inactive'}
  //     </OPRLabel>
  //   ),
  // },
  // {
  //   key: 'action',
  //   sorting: true,
  //   title: 'bulk_upload_data_file_name',
  //   render: (rowData: any) => <OPRButton color="primary" variant="text" onClick={handleEdit}>Download Log File</OPRButton>,
  // },
]

// payroll history
export const payrollHistory = (
  handleEdit: any,
  handleCheckboxChange: any,
  selectedPayrollCodes: any,
) => [
  {
    key: 'employeeCode',
    sorting: true,
    title: 'Employee name | Employee ID',
    render: (rowData: any) => (
      <div>
        <div style={{ display: 'flex', alignItems: 'center' }}>
          <Checkbox
            checked={selectedPayrollCodes.includes(rowData.id)} // Assuming 'key' is the unique identifier for each record
            onChange={(event) => handleCheckboxChange(event, rowData?.id)}
          />
          <OPRLabel color="primary.main" label={rowData.employeeCode} />

        </div>
        <div style={{ display: 'block' }}>
          <OPRLabel color="topAdmin.main" label={rowData.employeeName} variant="overline" />
        </div>
      </div>
    ),
  },

  {
    title: 'Pay item',
    render: (rowData: any) => <OPRLabel label={rowData.payItemCode} />,
  },
  {
    title: 'Pay cycle',
    render: (rowData: any) => {
      const finalCode = `${rowData.payCycleYear}-${rowData.payCycleMonth} (${rowData.payCycleCode})`
      return (
        <OPRLabel label={finalCode} />

      )
    },
  },
]

// payroll history delete

export const logPayrollHistory = (handleEdit: any) => [
  {

    key: '',
    sorting: true,
    title: 'Job ID | Job created date & by',
    render: (rowData: any) => (
      <>
        <OPRLabel label={rowData.jobId} />
        <OPRLabel label={rowData.createdAt} />

      </>
    ),
  },
  {

    key: 'completedDate',
    title: 'Completed date',
    render: (rowData: any) => <OPRLabel label={rowData.completedDate} />,
  },

  {
    key: 'status',
    title: 'status',
    render: (rowData: any) => (
      <OPRLabel CustomStyles={{

        paddingLeft: 8,
        paddingRight: 8,
        paddingTop: 4,
        paddingBottom: 4,
        background: rowData.status ? '#EBFFF0' : '#E8E6E7',
        borderRadius: 12,
        overflow: 'hidden',
        justifyContent: 'center',
        alignItems: 'center',
        gap: 8,
        display: 'inline-flex',
        color: rowData.status ? '#00701C' : '#3B3839',
        fontSize: 12,
        fontFamily: 'Lato',
        fontWeight: 700,
      }}
      >
        {rowData.status ? 'Successful' : 'Failed'}
      </OPRLabel>
    ),
  },
  {

    key: 'logFile',
    sorting: true,
    title: 'File',
    render: (rowData: any) => <OPRLabel label={rowData.logFile} />,
  },

]

// payroll non recurring delete
export const payrollNoRecurringSearch = (handleEdit: any, selectedEntity: any, handleCheckboxChange: any) => [
  {
    key: 'employeeCode',
    sorting: true,
    title: 'Employee',
    render: (rowData: any) => (
      <div style={{ display: 'flex', alignItems: 'center' }}>
        <Checkbox
          checked={selectedEntity.includes(rowData.id)} // Assuming 'key' is the unique identifier for each record
          onChange={(event) => handleCheckboxChange(event, rowData.id)} // Pass the record key to the handler function
        />
        <div>
          <OPRLabel label={rowData.employeeName} />
          <div>
            <OPRLabel label={rowData.employeeCode} />
          </div>
        </div>
      </div>
    ),
  },

  {
    key: 'payItemCode',
    // sorting: true,
    title: 'Pay Item',
    render: (rowData: any) => (
      <>
        <OPRLabel label={rowData.payItemName} />
        <br />
        {' '}
        <OPRLabel label={`${rowData.payItemCode} (${rowData.payType})`} />
      </>
    ),
  },

  {
    // title: 'Quantity | Rate per unit',
    title: `${t('Quantity')} | ${t('Rate per unit')}`,
    render: (rowData: any) => (
      <>
        <OPRLabel label={`${rowData.quantity} (Day)`} />
        {rowData.ratePerUnit != null && rowData.ratePerUnit !== undefined && (
          <OPRLabel label={rowData.ratePerUnit} />
        )}

      </>
    ),
  },
  {
    title: 'Amount',
    render: (rowData: any) => (
      <div style={{ display: 'flex', alignItems: 'center' }}>
        <OPRLabel label={rowData.originalCurrency} />
        <OPRLabel label={rowData.transactionAmount} />
      </div>
    ),
  },
  {
    title: 'Creation date',
    render: (rowData: any) => {
      const creationDate = new Date(rowData.creationDate)
      const formattedDate = `${creationDate.getDate()} ${creationDate.toLocaleString('en', { month: 'short' })} ${creationDate.getFullYear()} ${creationDate.getHours()}:${creationDate.getMinutes()}:${creationDate.getSeconds()}`
      return <OPRLabel label={formattedDate} />
    },
  },
]

// logs payrollnon recurring delete
export const logsPayRollNonRecurring = (handleEdit: any) => [

  {
    key: '',
    sorting: true,
    title: 'Job ID | Job created date & by',
    render: (rowData: any) => {
      const jobCreatedDate = new Date(rowData?.jobCreatedDateTime)
      const formattedDate = jobCreatedDate.toLocaleString('default', {
        day: '2-digit',
        month: 'short',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit',
        hour12: false,
      })

      return (
        <>
          <OPRLabel color="topAdmin.main" label={rowData?.jobID} />
          <div style={{ display: 'flex', alignItems: 'center' }}>
            <OPRLabel color="topAdmin.main" label={formattedDate} />
            <OPRLabel color="topAdmin.main" label="by" sx={{ margin: '0 4px' }} />
            <OPRLabel color="topAdmin.main" label={rowData?.createdBy} />
          </div>
        </>
      )
    },
  },

  {
    key: 'createdAt',
    title: 'Completed date',
    render: (rowData: any) => {
      const jobCreatedDate = new Date(rowData?.jobCreatedDateTime)
      const formattedDate = jobCreatedDate.toLocaleString('default', {
        day: '2-digit',
        month: 'short',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit',
        hour12: false,
      })

      return <OPRLabel label={formattedDate} />
    },
  },

  {
    key: 'status',
    title: 'Status',
    render: (rowData: any) => {
      let displayStatus = rowData.status
      let color
      let background

      switch (rowData.status) {
        case 'Success':
        case 'Finalized':
        case 'Completed':
          color = '#00701C' // Green for success
          background = '#EBFFF0' // Light green background for success
          break
        case 'Delete':
          color = '#00701C' // Green for delete (same as success)
          background = '#EBFFF0' // Light green background for delete (same as success)
          displayStatus = 'Successful' // Display "Successful" for "Delete"
          break
        case 'Failed':
          color = '#FF0000' // Red for failed
          background = '#FFEAEA' // Light red background for failed
          break
        case 'Pending':
          color = '#0000FF' // Blue for pending
          background = '#EAF0FF' // Light blue background for pending
          break
        default:
          color = '#3B3839' // Default text color
          background = '#EBEBEB' // Default background color
          break
      }

      return (
        <OPRLabel
          CustomStyles={{
            paddingLeft: 8,
            paddingRight: 8,
            paddingTop: 4,
            paddingBottom: 4,
            borderRadius: 12,
            overflow: 'hidden',
            justifyContent: 'center',
            alignItems: 'center',
            gap: 8,
            display: 'inline-flex',
            fontSize: 12,
            fontFamily: 'Lato',
            fontWeight: 700,
            color,
            background,
          }}
        >
          {displayStatus}
        </OPRLabel>
      )
    },
  },
]
export const publishReportColumn = (handleFileDownload: (url: string, filename: string) => void) => [
  // generationReferenceNo
  {
    key: 'jobId',
    sorting: true,
    title: 'Generation Reference',
    render: (rowData: any) => {
      const data:any = (rowData?.jobs || []).map((item:any) => item?.generationReferenceNo)
      return (
        <OPRLabel
          color="primary.main"
          label={rowData.generationReferenceNo}
        />
      )
    },
  },

  {
    key: 'jobId',
    sorting: true,
    title: 'Job ID | Job created date & by',
    render: (rowData: any) => {
      const data:any = (rowData?.jobs || []).map((item:any) => item?.jobID)
      const valuesString = data?.join(', ')
      return (
        <>
          <OPRLabel label={rowData.jobID} />
          <OPRLabel
            CustomStyles={{
              color: '#666364',
              fontSize: 12,
              fontFamily: 'Lato',
              fontWeight: '400',
              lineHeight: 2,
              wordWrap: 'break-word',
            }}
            label={`${displayFormatDateTime(rowData?.createdAt)} by ${rowData?.createdByName} (${rowData?.createdByEmail})`}
          />
        </>
      )
    },
  },
  // completed date
  {
    title: 'Completed date',
    render: (rowData: any) => <OPRLabel label={rowData?.completedDateTime ? displayFormatDateTime(rowData?.completedDateTime) : '-'} />,
  },

  // status
  {
    key: 'status',
    title: 'Status',
    render: (rowData:any) => {
      let backgroundColor
      let textColor
      if (rowData.jobStatus === 'Success') {
        backgroundColor = '#EBFFF0'
        textColor = '#00701C'
      } else if (rowData.jobStatus === 'Failed') {
        // backgroundColor = '#EBFFF0'
        textColor = '#DA3237'
      } else {
        backgroundColor = '#E8E6E7'
        textColor = '#3B3839'
      }
      return (
        <OPRLabel
          CustomStyles={{
            paddingLeft: 8,
            paddingRight: 8,
            paddingTop: 4,
            paddingBottom: 4,
            background: backgroundColor,
            borderRadius: 12,
            overflow: 'hidden',
            justifyContent: 'center',
            alignItems: 'center',
            gap: 8,
            display: 'inline-flex',
            color: textColor,
            fontSize: 12,
            fontFamily: 'Lato',
            fontWeight: 700,
          }}
          label={rowData?.status}
        />
      )
    },
  },
  {
    key: 'action',
    sorting: true,
    title: 'bulk_upload_data_file_name',
    render: (rowData: any) => (
      rowData.logFileUrl && (
        <OPRButton
          color="primary"
          variant="text"
          onClick={() => handleFileDownload(rowData.logFileUrl, `logFile_${rowData.jobID}`)}
        >
          Download Log File
        </OPRButton>
      )
    ),
  },

]

export const reportDocuTaxProColumn = (handler: any) => [
  {
    key: '',
    sorting: true,
    title: 'Generation references',
    render: (rowData: any) => <OPRLabel color="primary.main" label={rowData?.generationReference?.referenceNumber ? rowData?.generationReference?.referenceNumber : '-'} />,
  },
  // {
  //   key: 'jobId',
  //   sorting: true,
  //   title: 'job_id_created_date_by',
  //   render: (rowData: any) => {
  //     const date = new Date(rowData.createdAt)
  //     const formateDate = date.toLocaleDateString('en-GB', {
  //       day: '2-digit',
  //       month: 'short',
  //       year: 'numeric',
  //       hour: '2-digit',
  //       minute: '2-digit',
  //       second: '2-digit',
  //     })
  //     return (
  //       <>
  //         <OPRLabel label={rowData.jobId} />
  //         <OPRLabel label={formateDate} />
  //         <OPRLabel label={rowData.createdBy} />
  //       </>
  //     )
  //   },
  // },

  {
    key: 'jobId',
    sorting: true,
    title: 'Job ID | Job created date & by',
    render: (rowData: any) => {
      const data:any = (rowData?.jobs || []).map((item:any) => item?.jobId)
      const valuesString = data?.join(', ')
      return (
        <>
          <OPRLabel label={rowData.jobId} />
          <OPRLabel
            CustomStyles={{
              color: '#666364',
              fontSize: 12,
              fontFamily: 'Lato',
              fontWeight: '400',
              lineHeight: 2,
              wordWrap: 'break-word',
            }}
            label={`${displayFormatDateTime(rowData?.createdAt)} by ${rowData?.createdByName} (${rowData?.createdByEmail})`}
          />
        </>
      )
    },
  },
  // completed date
  {
    title: 'Completed date',
    render: (rowData: any) => <OPRLabel label={rowData?.publishTime ? displayFormatDateTime(rowData?.publishTime) : '-'} />,
  },
  // {

  //   key: 'completedDate',
  //   title: 'Completed date',
  //   render: (rowData: any) => {
  //     const date = new Date(rowData.completedAt)
  //     const formateDate = date.toLocaleDateString('en-GB', {
  //       day: '2-digit',
  //       month: 'short',
  //       year: 'numeric',
  //       hour: '2-digit',
  //       minute: '2-digit',
  //       second: '2-digit',
  //     })
  //     return (
  //       <OPRLabel label={formateDate} />
  //     )
  //   },
  // },

  // status
  {
    key: 'status',
    title: 'Status',
    render: (rowData:any) => {
      let backgroundColor
      let textColor
      if (rowData.jobStatus === 'Success') {
        backgroundColor = '#EBFFF0'
        textColor = '#00701C'
      } else if (rowData.jobStatus === 'Failed') {
        // backgroundColor = '#EBFFF0'
        textColor = '#DA3237'
      } else {
        backgroundColor = '#E8E6E7'
        textColor = '#3B3839'
      }
      return (
        <OPRLabel
          CustomStyles={{
            paddingLeft: 8,
            paddingRight: 8,
            paddingTop: 4,
            paddingBottom: 4,
            background: backgroundColor,
            borderRadius: 12,
            overflow: 'hidden',
            justifyContent: 'center',
            alignItems: 'center',
            gap: 8,
            display: 'inline-flex',
            color: textColor,
            fontSize: 12,
            fontFamily: 'Lato',
            fontWeight: 700,
          }}
          label={rowData?.jobStatus}
        />
      )
    },
  },
  {
    key: 'action',
    sorting: true,
    title: 'bulk_upload_data_file_name',
    render: (rowData: any) => (
      <>
        {' '}
        {
          rowData.jobStatus === 'Failed'
         && <OPRButton color="primary" variant="text" onClick={() => handler(rowData.id)}>Download Log File</OPRButton>
        }
      </>
    ),
  },
]
// logs for the month end closing
export const monthEndClosingLogs = (handleEdit: any) => [

  {
    key: 'jobID',
    sorting: true,
    title: 'Job ID | Job created date & by',
    render: (rowData: any) => (
      <>
        <OPRLabel color="primary.main" label={rowData?.jobID} />
        <OPRLabel color="topAdmin.main" label={rowData?.createdAt} />
      </>
    ),
  },

  {
    key: 'completedDate',
    title: 'Completed date',
    render: (rowData: any) => <OPRLabel label={rowData.jobCreatedDateTime} />,
  },
  {
    key: 'status',
    title: 'Status',
    render: (rowData: any) => {
      let color
      let background
      switch (rowData.status) {
        case 'Success':
        case 'Finalized':
        case 'Completed':
          color = '#00701C' // Green for success
          background = '#EBFFF0' // Light green background for success
          break
        case 'Failed':
          color = '#FF0000' // Red for failed
          background = '#FFEAEA' // Light red background for failed
          break
        case 'Pending':
          color = '#0000FF' // Blue for pending
          background = '#EAF0FF' // Light blue background for pending
          break
        default:
          color = '#3B3839' // Default text color
          background = '#EBEBEB' // Default background color
          break
      }
      return (
        <OPRLabel
          CustomStyles={{
            paddingLeft: 8,
            paddingRight: 8,
            paddingTop: 4,
            paddingBottom: 4,
            borderRadius: 12,
            overflow: 'hidden',
            justifyContent: 'center',
            alignItems: 'center',
            gap: 8,
            display: 'inline-flex',
            fontSize: 12,
            fontFamily: 'Lato',
            fontWeight: 700,
            color,
            background,
          }}
        >
          {rowData.status}
        </OPRLabel>
      )
    },
  },
  {
    key: 'logFile',
    title: 'File',
    render: (rowData: any) => <OPRLabel label={rowData.logFile} />,

  },
]
// publish report
export const generationRefColumn = (handleEdit: any) => [

  {
    key: 'referenceNumber',
    sorting: true,
    title: 'ent_reports_generation_ref',
    render: (rowData: any) => (
      <OPRLabel color="primary.main" label={rowData?.referenceNumber} />
    ),
  },
  {
    title: 'ent_reports_generation_date',
    render: (rowData: any) => <OPRLabel label={rowData?.publishTime ? displayFormatDateTime(rowData?.publishTime) : '-'} />,
  },
  {
    key: 'status',
    title: 'status',
    render: (rowData: any) => {
      let bgColor = ''
      let textColor = ''
      if (rowData?.publishStatus === 'Ready' || rowData?.publishStatus === 'Partially Published') {
        bgColor = '#E8E6E7'
        textColor = '#3B3839'
      } else if (rowData?.publishStatus === 'Published') {
        bgColor = '#EBFFF0'
        textColor = '#00701C'
      } else {
        bgColor = '#FEF5F8'
        textColor = '#DA3237'
      }
      return (
        <OPRLabel CustomStyles={{
          paddingLeft: 8,
          paddingRight: 8,
          paddingTop: 4,
          paddingBottom: 4,
          background: bgColor,
          borderRadius: 12,
          overflow: 'hidden',
          justifyContent: 'center',
          alignItems: 'center',
          gap: 8,
          display: 'inline-flex',
          color: textColor,
          fontSize: 12,
          fontFamily: 'Lato',
          fontWeight: 700,
        }}
        >
          { rowData?.publishStatus}
        </OPRLabel>
      )
    },
  },

  // {
  //   sorting: false,
  //   title: 'action',
  //   render: (rowData: any) => (
  //     <OPRDropDown
  //       data={rowData}
  //       newOptions={['Edit pension fund scheme', 'Delete pension fund scheme']}
  //       onHandleclick={handleEdit}
  //     />
  //   ),
  // },
]

export const reportViewColumn = (handleEdit: any) => [
  {
    key: 'fileName',
    sorting: true,
    title: 'bulk_upload_data_first_name',
    render: (rowData: any) => (
      <OPRLabel label={rowData?.fileName} />
    ),
  },
  {
    key: 'status',
    title: 'publish_status',
    render: (rowData: any) => {
      let bgColor = ''
      let textColor = ''
      if (rowData?.publishStatus === 'Ready' || rowData?.publishStatus === 'Partially Published') {
        bgColor = '#E8E6E7'
        textColor = '#3B3839'
      } else if (rowData?.publishStatus === 'Published') {
        bgColor = '#EBFFF0'
        textColor = '#00701C'
      } else {
        bgColor = '#FEF5F8'
        textColor = '#DA3237'
      }
      return (
        <OPRLabel CustomStyles={{
          paddingLeft: 8,
          paddingRight: 8,
          paddingTop: 4,
          paddingBottom: 4,
          background: bgColor,
          borderRadius: 12,
          overflow: 'hidden',
          justifyContent: 'center',
          alignItems: 'center',
          gap: 8,
          display: 'inline-flex',
          color: textColor,
          fontSize: 12,
          fontFamily: 'Lato',
          fontWeight: 700,
        }}
        >
          {rowData?.publishStatus}
        </OPRLabel>
      )
    },
  },
  {
    title: 'publish_id_date',
    render: (rowData: any) => <OPRLabel label={rowData?.publishTime} />,
  },
  {
    title: 'release_date',
    render: (rowData: any) => <OPRLabel label={rowData?.releaseDate} />,
  },
  {
    title: 'file_remarks',
    render: (rowData: any) => <OPRLabel label={rowData?.remarks} />,
  },
  {
    title: 'download_status',
    render: (rowData: any) => <OPRLabel label={rowData?.downloadStatus} />,
  },
]

export const reportViewEditColumn = (viewAcoount: any, additionalData:any) => [

  {
    key: 'fileName',
    sorting: true,
    title: 'bulk_upload_data_first_name',
    render: (rowData: any) => (
      <OPRLabel label={rowData?.fileName} />
    ),
  },
  {
    title: 'release_date',
    render: (rowData: any) => <OPRLabel label={rowData?.releaseDate || additionalData.releaseDate} />,
  },
  {
    title: 'file_remarks',
    render: (rowData: any) => <OPRLabel label={rowData?.remarks || additionalData.remarks} />,
  },
  {
    title: 'download_status',
    render: (rowData: any) => <OPRLabel label={rowData?.downloadStatus} />,
  },

  {
    sorting: false,
    title: 'action',
    render: (rowData: any) => (
      <OPRDropDown
        data={rowData}
        newOptions={['Edit report file']}
        onHandleclick={viewAcoount}
      />
    ),
  },
]
export const selectFileColumn = (handleEdit: any) => [
  {
    key: 'fileName',
    sorting: true,
    title: '',
    render: (rowData: any) => (
      <OPRLabel color="primary.main" label={rowData?.fileName} />
    ),
  },
]

export const ACRFileColumn = (handleEdit: any) => [
  {
    key: 'fileName',
    sorting: true,
    title: '',
    render: (rowData: any) => (
      <OPRLabel color="primary.main" label={rowData?.fileName} />
    ),
  },
]
// Review Report
export const reviewReport = (handleEdit: any) => [

  {
    key: '',
    sorting: true,
    title: 'Report type',
    render: (rowData: any) => (
      <OPRLabel color="primary.main" label={`${rowData?.batchJob?.reportType?.name || '-'}`} />
    ),
  },
  {
    title: 'Report code',
    render: (rowData: any) => (
      <OPRLabel color="primary.main" label={`${rowData?.batchJob?.reportType?.code || '-'}`} />
    ),
  },

  {
    title: 'File name',
    render: (rowData: any) => (
      <OPRLabel color="primary.main" label={rowData?.fileName?.split('/').pop()} />
    ),
  },
  {
    sorting: false,
    title: 'action',
    render: (rowData: any) => (
      <OPRDropDown
        data={rowData}
        newOptions={['Export file']}
        onHandleclick={() => handleEdit({ selectedId: rowData.id }, 'Export file')}
      />
    ),
  },
]
// review report logs

export const reviewReportLogs = (handleEdit: any) => [
  {
    sorting: true,
    title: 'Generation references',
    render: (rowData: any) => <OPRLabel color="primary.main" label={rowData?.generationReference?.referenceNumber} />,
  },
  {
    title: 'Job ID | Job created date & by',
    render: (rowData: any) => {
      const createdAt = new Date(rowData?.createdAt)
      const formattedDate = `${createdAt.getDate()} ${createdAt.toLocaleString('en', { month: 'short' })} ${createdAt.getFullYear()} ${createdAt.getHours().toString().padStart(2, '0')}:${createdAt.getMinutes().toString().padStart(2, '0')}:${createdAt.getSeconds().toString().padStart(2, '0')}`
      return (
        <>
          <OPRLabel label={rowData?.jobId} />
          <OPRLabel label={`${formattedDate} by ${rowData?.createdByName} (${rowData?.createdByEmail})`} />
        </>
      )
    },
  },

  {
    title: 'Completed date',
    render: (rowData: any) => {
      const updatedAt = new Date(rowData?.updatedAt)
      const formattedDate = `${updatedAt.getDate()} ${updatedAt.toLocaleString('en', { month: 'short' })} ${updatedAt.getFullYear()} ${updatedAt.getHours().toString().padStart(2, '0')}:${updatedAt.getMinutes().toString().padStart(2, '0')}:${updatedAt.getSeconds().toString().padStart(2, '0')}`
      return <OPRLabel label={formattedDate} />
    },
  },
  // {
  //   title: 'Status',
  //   render: (rowData: any) => (
  //     <OPRLabel label={rowData?.jobs[0]?.jobStatus} />
  //   ),
  // },
  {
    key: 'status',
    title: 'Status',
    render: (rowData:any) => {
      let backgroundColor
      let textColor
      if (rowData.jobStatus === 'Success') {
        backgroundColor = '#EBFFF0'
        textColor = '#00701C'
      } else if (rowData.jobStatus === 'Failed') {
        // backgroundColor = '#EBFFF0'
        textColor = '#DA3237'
      } else {
        backgroundColor = '#E8E6E7'
        textColor = '#3B3839'
      }
      return (
        <OPRLabel
          CustomStyles={{
            paddingLeft: 8,
            paddingRight: 8,
            paddingTop: 4,
            paddingBottom: 4,
            background: backgroundColor,
            borderRadius: 12,
            overflow: 'hidden',
            justifyContent: 'center',
            alignItems: 'center',
            gap: 8,
            display: 'inline-flex',
            color: textColor,
            fontSize: 12,
            fontFamily: 'Lato',
            fontWeight: 700,
          }}
          label={rowData?.jobStatus}
        />
      )
    },
  },

]
// email template
export const emailTemplateColumn = (handleEdit: any) => [
  {
    key: 'emailTemplateName',
    sorting: true,
    title: 'Email template name | Email template code',
    render: (rowData: any) => (
      <>
        <OPRLabel color="primary.main" label={rowData?.emailTemplateName} />
        <OPRLabel color="topAdmin.main" label={rowData?.emailTemplateCode} />
      </>
    ),
  },
  {
    title: 'Type',
    render: (rowData: any) => <OPRLabel label={rowData?.emailTemplateType?.code} />,
  },
  {
    sorting: false,
    title: 'action',
    render: (rowData: any) => (
      <OPRDropDown
        data={rowData}
        newOptions={['Edit email template', 'Delete email template']}
        onHandleclick={handleEdit}
      />
    ),
  },
]

// payroll non recurring delete
export const payrollNoRecurringSearch1 = (handleEdit: any, selectedEntity: any, handleCheckboxChange: any) => [
  {
    key: 'employeeCode',
    sorting: true,
    title: 'Employee',
    render: (rowData: any) => (
      <div style={{ display: 'flex', alignItems: 'center' }}>
        <Checkbox
          checked={selectedEntity.includes(rowData.id)} // Assuming 'key' is the unique identifier for each record
          onChange={(event) => handleCheckboxChange(event, rowData.id)} // Pass the record key to the handler function
        />
        <div>
          <OPRLabel label={rowData.employeeName} />
          <div>
            <OPRLabel label={rowData.employeeCode} />
          </div>
        </div>
      </div>
    ),
  },

  {
    key: 'payItemCode',
    title: 'Pay Item',
    render: (rowData: any) => (
      <>
        <OPRLabel label={rowData.payItemName} />
        <br />
        {' '}
        <OPRLabel label={`${rowData.payItemCode} (${rowData.payType})`} />
      </>
    ),
  },

  {
    // title: 'Quantity | Rate per unit',
    title: `${t('Quantity')} | ${t('Rate per unit')}`,
    render: (rowData: any) => (
      <>
        <OPRLabel label={`${rowData.quantity} (Day)`} />
        {rowData.ratePerUnit != null && rowData.ratePerUnit !== undefined && (
          <OPRLabel label={rowData.ratePerUnit} />
        )}

      </>
    ),
  },
  {
    title: 'Amount',
    render: (rowData: any) => (
      <div style={{ display: 'flex', alignItems: 'center' }}>
        <OPRLabel label={rowData.originalCurrency} />
        <OPRLabel label={rowData.transactionAmount} />
      </div>
    ),
  },
  {
    title: 'Creation date',
    render: (rowData: any) => {
      const creationDate = new Date(rowData.coveringStartDate)
      const formattedDate = `${creationDate.getDate()} ${creationDate.toLocaleString('en', { month: 'short' })} ${creationDate.getFullYear()} ${creationDate.getHours()}:${creationDate.getMinutes()}:${creationDate.getSeconds()}`
      return <OPRLabel label={formattedDate} />
    },
  },
]

// payrol non recurring
export const payrollNoRecurringSearchColumn = (
  handleEdit: any,
  // selectedEntity: any,
  // handleCheckboxChange: any,
) => [
  {
    key: 'employeeCode',
    sorting: true,
    title: 'Employee',
    render: (rowData: any) => (
      <div style={{ display: 'flex', alignItems: 'center' }}>
        {/* <Checkbox
          checked={selectedEntity.includes(rowData.id)} // Assuming 'key' is the unique identifier for each record
          onChange={(event) => handleCheckboxChange(event, rowData.id)} // Pass the record key to the handler function
        /> */}
        <div>
          <OPRLabel label={rowData.employeeName} />
          <div>
            <OPRLabel label={rowData.employeeCode} />
          </div>
        </div>
      </div>
    ),
  },

  {
    key: 'payItemCode',
    title: 'Pay Item',
    render: (rowData: any) => (
      <>
        <OPRLabel label={rowData.payItemName} />
        <br />
        {' '}
        <OPRLabel label={`${rowData.payItemCode} (${rowData.payType})`} />
      </>
    ),
  },

  {
    // title: 'Quantity | Rate per unit',
    title: `${t('Quantity')} | ${t('Rate per unit')}`,
    render: (rowData: any) => (
      <>
        <OPRLabel label={`${rowData.quantity} (Day)`} />
        {rowData.ratePerUnit != null && rowData.ratePerUnit !== undefined && (
          <OPRLabel label={rowData.ratePerUnit} />
        )}

      </>
    ),
  },
  {
    title: 'Amount',
    render: (rowData: any) => (
      <div style={{ display: 'flex', alignItems: 'center' }}>
        <OPRLabel label={rowData.originalCurrency} />
        <OPRLabel label={rowData.transactionAmount} />
      </div>
    ),
  },
  {
    title: 'Creation date',
    render: (rowData: any) => {
      const creationDate = new Date(rowData.creationDate)
      const formattedDate = `${creationDate.getDate()} ${creationDate.toLocaleString('en', { month: 'short' })} ${creationDate.getFullYear()} ${creationDate.getHours()}:${creationDate.getMinutes()}:${creationDate.getSeconds()}`
      return <OPRLabel label={formattedDate} />
    },
  },
  {
    sorting: false,
    title: '',
    render: (rowData: any) => (
      <OPRDropDown
        data={rowData}
        newOptions={['edit PayrollNon-recurring', 'delete PayrollNon-recurring']}
        onHandleclick={handleEdit}
      />
    ),
  },
]

export const entityCostCenterColumn = (handleEdit: any) => [
  // title:"Cost Center Name"
  {
    title: `${t('cost_Center_Description')} | ${t('cost_Center_Code')}`,
    key: 'costCenterDescription',
    sorting: true,
    render: (rowData: any) => (
      <>
        <OPRLabel color="primary.main" label={rowData.costCenterDescription} />
        <OPRLabel color="topAdmin.main" label={rowData.costCenterCode} />
      </>
    ),
  },
  {
    sorting: false,
    title: '',
    render: (rowData: any) => (
      <OPRDropDown
        data={rowData}
        newOptions={['edit cost center', 'delete cost center']}
        onHandleclick={handleEdit}
      />
    ),
  },
]

// employee leave transaction
export const employeeLeaveTransaction = (handleEdit: any) => [
  {
    title: `${t('empl_name_empl_id')}`,
    key: 'EmployeeCode',
    sorting: true,
    render: (rowData: any) => (
      <div>
        {/* Display firstName and lastName on the same line */}
        <div style={{ display: 'flex', alignItems: 'center', marginBottom: '4px' }}>
          <OPRLabel color="primary.main" label={rowData.firstName} />
          <span style={{ margin: '0 8px' }} />
          <OPRLabel color="primary.main" label={rowData.lastName} />
        </div>
        {/* Display employeeCode on a new line */}
        <div>
          <OPRLabel color="primary.main" label={rowData.employeeCode} />
        </div>
      </div>
    ),
  },
  {
    title: `${t('pay_cycle_month_year')}`,
    key: 'Month',
    sorting: true,
    render: (rowData: any) => {
      // Assuming rowData.month is in numerical format (e.g., 5 for May)
      const formattedMonthYear = moment(`${rowData.year}-${rowData.month}`, 'YYYY-M').format('MMMM YYYY') // Convert to "May 2024"

      return (
        <OPRLabel color="topAdmin" label={formattedMonthYear} />
      )
    },
  },
  {
    title: `${t('Provider_types')} `,
    key: 'costCenterDescription',
    sorting: true,
    render: (rowData: any) => (
      <OPRLabel color="topAdmin" label={rowData.leaveTransactionType} />
    ),
  },
  {
    title: `${t('employee_leave_unit')}`,
    key: 'costCenterDescription',
    sorting: true,
    render: (rowData: any) => (
      <OPRLabel color="topAdmin" label={rowData.unit} />
    ),
  },
  {
    sorting: false,
    title: '',
    render: (rowData: any) => {
      const options: OPRActionMenuOption[] = []

      options.push({
        title: t('employee_leave_edit'),
        value: 'edit leave transaction',
        action: (option) => handleEdit?.(rowData, option),
      })

      options.push({
        title: t('employee_leave_delete'),
        destructive: true,
        value: 'delete Leave Transaction',
        action: (option) => handleEdit?.(rowData, option),
      })

      return (
        <OPRActionMenu
          options={options}
          onClose={() => {
          }}
        />
      )
    },
  },
]

// employee remark
export const employeeRemark = (handleEdit: any) => [
  {
    title: `${t('emp_remark_name_id')} `,
    key: 'employeeCode',
    sorting: true,
    render: (rowData: any) => (
      <>

        <OPRLabel color="primary.main" label={`${rowData?.employeeProfile?.givenName}`} />
        <OPRLabel color="topAdmin.main" label={rowData.employeeCode} />
      </>
    ),
  },
  {
    title: t('emp_remark_paycyle'),
    render: (rowData: any) => <OPRLabel label={rowData?.payCycle} />,
  },
  {
    title: t('emp_remark_type'),
    render: (rowData: any) => <OPRLabel label={rowData?.type} />,
  },

  {
    sorting: false,
    title: '',
    render: (rowData: any) => {
      const options: OPRActionMenuOption[] = []

      options.push({
        title: t('edit_emp_remark'),
        value: 'edit_emp_remark',
        action: (option) => handleEdit?.(rowData, option),
      })

      options.push({
        title: t('delete_emp_remark'),
        destructive: true,
        value: 'delete_emp_remark',
        action: (option) => handleEdit?.(rowData, option),
      })

      return (
        <OPRActionMenu
          options={options}
          onClose={() => {
          }}
        />
      )
    },
  },
]
