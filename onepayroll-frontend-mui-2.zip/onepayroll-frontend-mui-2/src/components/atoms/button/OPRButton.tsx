import AddIcon from '@mui/icons-material/Add'
import { styled } from '@mui/material'
import Button from '@mui/material/Button'
import { ExportIcon } from 'assets/svg-images/SvgComponents'
import * as React from 'react'

export { }

type CustomProps = {
    buttonText?: string;
    style?: React.CSSProperties;
    icon?: boolean;
    type?: 'button' | 'submit' | 'reset';
    endIcon?: React.ReactNode;
    startIcon?: React.ReactNode;
    handleClick?: (e:any) => void;
    disabled?: boolean;
    [x:string]: any;
    exportIcon?: any;
};

export const OPRButtonStyle = styled(Button)<CustomProps>(({ theme, style }: any) => ({
  ...({
    ...style,
    textTransform: 'none',
    borderRadius: '110px',
    padding: '8px 16px',
  }),
  // customstyle will override the above styles and theme styles for the component
}))

function OPRButton({
  buttonText, style, icon = false, children, disabled = false, endIcon, exportIcon, startIcon, type, variant = 'contained', color, handleClick, ...rest
}:CustomProps) {
  return (
    <OPRButtonStyle
      color={color}
      disabled={disabled}
      endIcon={endIcon && <AddIcon data-testid="end-icon" />}
      startIcon={startIcon && <AddIcon data-testid="start-icon" />}
      style={style}
      type={type}
      variant={variant}
      onClick={handleClick}
      {...rest}
    >
      {exportIcon && <div data-testid="export-icon"><ExportIcon /></div>}
      {children}
    </OPRButtonStyle>
  )
}
export default OPRButton
