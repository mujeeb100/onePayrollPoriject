import '@testing-library/jest-dom/extend-expect'

import { fireEvent, render } from '@testing-library/react'

import OPRButton from './OPRButton'

describe('OPRButton Component', () => {
  test('renders with the correct text', () => {
    const { getByText } = render(<OPRButton>Click Me</OPRButton>)
    expect(getByText('Click Me')).toBeInTheDocument()
  })

  test('renders with correct variant when provided', () => {
    const { getByText } = render(<OPRButton variant="outlined">Click Me</OPRButton>)
    expect(getByText('Click Me')).toHaveClass('MuiButton-outlined')
  })

  test('renders with correct color when provided', () => {
    const { getByText } = render(<OPRButton color="success">Click Me</OPRButton>)
    expect(getByText('Click Me')).toHaveClass('MuiButton-containedSuccess')
  })

  test('renders with correct type when provided', () => {
    const { getByText } = render(<OPRButton type="submit">Click Me</OPRButton>)
    expect(getByText('Click Me')).toHaveAttribute('type', 'submit')
  })

  test('renders with correct style when provided', () => {
    const { getByText } = render(<OPRButton style={{ color: 'red' }}>Click Me</OPRButton>)
    expect(getByText('Click Me')).toHaveStyle('color: red')
  })

  test('renders with startIcon when provided', () => {
    const { getByTestId } = render(<OPRButton startIcon>Click Me</OPRButton>)
    expect(getByTestId('start-icon')).toBeInTheDocument()
  })

  test('renders with endIcon when provided', () => {
    const { getByTestId } = render(<OPRButton endIcon>Click Me</OPRButton>)
    expect(getByTestId('end-icon')).toBeInTheDocument()
  })

  test('renders with exportIcon when provided', () => {
    const { getByTestId } = render(<OPRButton exportIcon>Click Me</OPRButton>)
    expect(getByTestId('export-icon')).toBeInTheDocument()
  })

  test('calls the handleClick handler when clicked', () => {
    const handleClick = jest.fn()
    const { getByText } = render(<OPRButton handleClick={handleClick}>Click Me</OPRButton>)
    fireEvent.click(getByText('Click Me'))
    expect(handleClick).toHaveBeenCalledTimes(1)
  })

  test('is disabled when the disabled prop is true', () => {
    const { getByText } = render(<OPRButton disabled>Click Me</OPRButton>)
    expect(getByText('Click Me')).toBeDisabled()
  })

  test('does not render icon when icon prop is false', () => {
    const { queryByTestId } = render(<OPRButton>Click Me</OPRButton>)
    expect(queryByTestId('end-icon')).toBeNull()
    expect(queryByTestId('start-icon')).toBeNull()
    expect(queryByTestId('export-icon')).toBeNull()
  })
})
