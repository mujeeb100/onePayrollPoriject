import ClearIcon from '@mui/icons-material/Close'
import { Chip, TextField } from '@mui/material'
import Autocomplete from '@mui/material/Autocomplete'
import { useEffect, useState } from 'react'

import { isEmailAddress } from '../../../constants/index'

export type OPREmailInputProps = {
  placeholder: string
  values?: string[]
  setValues?: (values: string[]) => void
}

function OPREmailInput(props: OPREmailInputProps) {
  const { placeholder, values, setValues } = props
  const [inputText, setInputText] = useState<string>('')

  useEffect(() => {
    setInputText('')
  }, [values])

  return (
    <Autocomplete
      freeSolo
      multiple
      className="email-cross"
      clearIcon={false}
      inputValue={inputText}
      options={[]}
      renderInput={(params) => (
        <TextField
          {...params}
          placeholder={placeholder}
          value={inputText}
          variant="outlined"
          onChange={(e) => setInputText(e.target.value)}
        />
      )}
      renderTags={(value: string[], getTagProps) => value.map((option, index) => (
        // eslint-disable-next-line react/jsx-key
        <Chip
          label={option}
          {...getTagProps({ index })}
          deleteIcon={<ClearIcon data-testid="delete-icon" />}
          onDelete={() => {
            const newValues = values?.filter((item) => item !== option)
            if (newValues) {
              setValues?.(newValues)
            }
          }}
        />
      ))}
      sx={{
        borderRadius: '8px',
        '& .MuiAutocomplete-input': {
          borderRadius: '8px',
          height: '12px',
        },
        '& .MuiAutocomplete-tag': {
          height: '25px',
        },
        '& .MuiOutlinedInput-root': {
          borderRadius: '8px',
        },
      }}
      value={values}
      onBlur={(event) => {
        if (values) {
          const { value } = event.target as HTMLInputElement
          if (isEmailAddress(value)) {
            setValues?.([...values, value])
          }
        }
      }}
      onKeyDown={(event) => {
        if (values) {
          const { value } = event.target as HTMLInputElement
          if (event.key === 'Enter' && isEmailAddress(value)) {
            setValues?.([...values, value])
          }
        }
      }}
    />
  )
}

export default OPREmailInput
