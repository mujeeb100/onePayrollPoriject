import { useTheme } from '@emotion/react'
import {
  OutlinedInput,
} from '@mui/material'

type Props = {
  value: number | string;
  onChange?: (item: any) => void;
  disabled?: boolean;
  name?: string;
  isRequired?: boolean;
  max?: number;
  placeholder?: string;
  type?: string;
  maxLength?: number;
  error?: boolean;
  errorName?:string;
  color?:any;
};

function OPRInput({
  value,
  onChange,
  disabled,
  name,
  isRequired = false,
  placeholder = '',
  type = 'text',
  maxLength,
  error = false,
  errorName = '',
  color,
  ...rest
}: Props) {
  const theme:any = useTheme() // Use the Theme type for the theme variable

  return (

    <OutlinedInput
      disabled={disabled}
      id={`outlined-${name}`}
      inputProps={{
        maxLength,
      }}
      name={name}
      notched={false}
      placeholder={placeholder}
      required={isRequired}
      sx={{ width: '100%' }}
      type={type}
      value={value}
      onChange={onChange}

    />
  )
}

export default OPRInput
