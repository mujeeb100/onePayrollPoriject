import '@testing-library/jest-dom/extend-expect'

import { fireEvent, render, screen } from '@testing-library/react'
import React from 'react'

import { isEmailAddress } from '../../../constants/index'
import OPREmailInput, { OPREmailInputProps } from './OPREmailInput'

jest.mock('../../../constants/index', () => ({
  isEmailAddress: jest.fn(),
}))

describe('OPREmailInput Component', () => {
  const setup = (props: Partial<OPREmailInputProps> = {}) => {
    const defaultProps: OPREmailInputProps = {
      placeholder: 'Enter email',
      values: [],
      setValues: jest.fn(),
      ...props,
    }
    return render(<OPREmailInput {...defaultProps} />)
  }

  it('should render the component with placeholder', () => {
    setup()
    expect(screen.getByPlaceholderText('Enter email')).toBeInTheDocument()
  })

  it('should update input text on change', () => {
    setup()
    const input = screen.getByPlaceholderText('Enter email') as HTMLInputElement
    fireEvent.change(input, { target: { value: 'test@example.com' } })
    expect(input.value).toBe('test@example.com')
  })

  it('should call setValues with new email on Enter key press', () => {
    const setValues = jest.fn();
    (isEmailAddress as jest.Mock).mockReturnValue(true)
    setup({ values: [], setValues })

    const input = screen.getByPlaceholderText('Enter email') as HTMLInputElement
    fireEvent.change(input, { target: { value: 'test@example.com' } })
    fireEvent.keyDown(input, { key: 'Enter', code: 'Enter' })

    expect(setValues).toHaveBeenCalledWith(['test@example.com'])
  })

  it('should not call setValues with invalid email on Enter key press', () => {
    const setValues = jest.fn();
    (isEmailAddress as jest.Mock).mockReturnValue(false)
    setup({ values: [], setValues })

    const input = screen.getByPlaceholderText('Enter email') as HTMLInputElement
    fireEvent.change(input, { target: { value: 'invalid-email' } })
    fireEvent.keyDown(input, { key: 'Enter', code: 'Enter' })

    expect(setValues).not.toHaveBeenCalled()
  })

  it('should call setValues with new email on blur', () => {
    const setValues = jest.fn();
    (isEmailAddress as jest.Mock).mockReturnValue(true)
    setup({ values: [], setValues })

    const input = screen.getByPlaceholderText('Enter email') as HTMLInputElement
    fireEvent.change(input, { target: { value: 'test@example.com' } })
    fireEvent.blur(input)

    expect(setValues).toHaveBeenCalledWith(['test@example.com'])
  })

  it('should not call setValues with invalid email on blur', () => {
    const setValues = jest.fn();
    (isEmailAddress as jest.Mock).mockReturnValue(false)
    setup({ values: [], setValues })

    const input = screen.getByPlaceholderText('Enter email') as HTMLInputElement
    fireEvent.change(input, { target: { value: 'invalid-email' } })
    fireEvent.blur(input)

    expect(setValues).not.toHaveBeenCalled()
  })

  it('should not call setValues on blur if values is undefined', () => {
    const setValues = jest.fn();
    (isEmailAddress as jest.Mock).mockReturnValue(true)
    setup({ values: undefined, setValues })

    const input = screen.getByPlaceholderText('Enter email') as HTMLInputElement
    fireEvent.change(input, { target: { value: 'test@example.com' } })
    fireEvent.blur(input)

    expect(setValues).not.toHaveBeenCalled()
  })

  it('should render chips for each email in values', () => {
    setup({ values: ['test1@example.com', 'test2@example.com'] })

    expect(screen.getByText('test1@example.com')).toBeInTheDocument()
    expect(screen.getByText('test2@example.com')).toBeInTheDocument()
  })

  it('should render delete icon if values present', () => {
    const { getByTestId } = render(<OPREmailInput placeholder="test" values={['test1@example.com']} />)
    expect(getByTestId('delete-icon')).toBeInTheDocument()
  })

  it('should call setValues with remaining emails when a chip is deleted', () => {
    const setValues = jest.fn()
    setup({ values: ['test1@example.com', 'test2@example.com'], setValues })
    const deleteIcons = screen.getAllByTestId('delete-icon')
    const deleteIcon = deleteIcons[0]
    fireEvent.click(deleteIcon)

    expect(setValues).toHaveBeenCalledWith(['test2@example.com'])
  })

  it('should not call setValues on Enter key press if values is undefined', () => {
    const setValues = jest.fn();
    (isEmailAddress as jest.Mock).mockReturnValue(true)
    setup({ values: undefined, setValues })

    const input = screen.getByPlaceholderText('Enter email') as HTMLInputElement
    fireEvent.change(input, { target: { value: 'test@example.com' } })
    fireEvent.keyDown(input, { key: 'Enter', code: 'Enter' })

    expect(setValues).not.toHaveBeenCalled()
  })
})
