import '@testing-library/jest-dom/extend-expect'

import { ThemeProvider } from '@emotion/react'
import { createTheme } from '@mui/material/styles'
import { fireEvent, render, screen } from '@testing-library/react'

import OPRInput from './OPRInput'

const theme = createTheme()

describe('OPRInput Component', () => {
  test('renders with default props', () => {
    render(
      <ThemeProvider theme={theme}>
        <OPRInput value="" />
      </ThemeProvider>,
    )

    const inputElement = screen.getByPlaceholderText('')
    expect(inputElement).toBeInTheDocument()
    expect(inputElement).toHaveAttribute('type', 'text')
    expect(inputElement).toHaveAttribute('value', '')
  })

  test('renders with provided props', () => {
    render(
      <ThemeProvider theme={theme}>
        <OPRInput
          isRequired
          maxLength={10}
          name="test-input"
          placeholder="Enter text"
          type="number"
          value="test value"
        />
      </ThemeProvider>,
    )

    const inputElement = screen.getByPlaceholderText('Enter text')
    expect(inputElement).toBeInTheDocument()
    expect(inputElement).toHaveAttribute('type', 'number')
    expect(inputElement).toHaveAttribute('name', 'test-input')
    expect(inputElement).toBeRequired()
    expect(inputElement).toHaveAttribute('maxlength', '10')
    expect(inputElement).toHaveAttribute('value', 'test value')
  })

  test('renders with provided numerical props', () => {
    render(
      <ThemeProvider theme={theme}>
        <OPRInput
          placeholder="Enter text"
          value={123}
        />
      </ThemeProvider>,
    )

    const inputElement = screen.getByPlaceholderText('Enter text')
    expect(inputElement).toBeInTheDocument()
    expect(inputElement).toHaveAttribute('value', '123')
  })

  test('calls onChange handler when value changes', () => {
    const handleChange = jest.fn()
    render(
      <ThemeProvider theme={theme}>
        <OPRInput value="" onChange={handleChange} />
      </ThemeProvider>,
    )

    const inputElement = screen.getByPlaceholderText('')
    fireEvent.change(inputElement, { target: { value: 'new value' } })
    expect(handleChange).toHaveBeenCalledTimes(1)
  })

  test('renders as disabled when disabled prop is true', () => {
    render(
      <ThemeProvider theme={theme}>
        <OPRInput disabled value="" />
      </ThemeProvider>,
    )

    const inputElement = screen.getByPlaceholderText('')
    expect(inputElement).toBeDisabled()
  })

  test('renders with error state when error prop is true', () => {
    render(
      <ThemeProvider theme={theme}>
        <OPRInput error value="" />
      </ThemeProvider>,
    )

    const inputElement = screen.getByPlaceholderText('')
    expect(inputElement).toHaveClass('MuiInputBase-input')
  })
})
