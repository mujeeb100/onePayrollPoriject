import '@testing-library/jest-dom/extend-expect'

import { fireEvent, render, screen } from '@testing-library/react'
import { IOPRCheckbox } from 'interfaces'

import OPRCheckbox from './OPRCheckbox'

describe('OPRCheckbox Component', () => {
  const defaultProps: IOPRCheckbox = {
    label: 'Test Checkbox',
    onChange: jest.fn(),
    checked: false,
    indeterminate: false,
  }

  it('renders the checkbox with the correct label', () => {
    render(<OPRCheckbox {...defaultProps} />)
    const labelElement = screen.getByText(defaultProps.label)
    expect(labelElement).toBeInTheDocument()
  })

  it('renders the checkbox with the correct checked state', () => {
    render(<OPRCheckbox {...defaultProps} checked />)
    const checkboxElement = screen.getByRole('checkbox')
    expect(checkboxElement).toBeChecked()
  })

  it('renders the checkbox with the correct indeterminate state', () => {
    render(<OPRCheckbox {...defaultProps} indeterminate />)
    const checkboxElement = screen.getByRole('checkbox')
    expect(checkboxElement).toHaveAttribute('data-indeterminate', 'true')
  })

  it('does not set the indeterminate attribute when indeterminate is false', () => {
    render(<OPRCheckbox {...defaultProps} indeterminate={false} />)
    const checkboxElement = screen.getByRole('checkbox')
    expect(checkboxElement).toHaveAttribute('data-indeterminate', 'false')
  })

  it('calls the onChange handler when the checkbox is clicked', () => {
    render(<OPRCheckbox {...defaultProps} />)
    const checkboxElement = screen.getByRole('checkbox')
    fireEvent.click(checkboxElement)
    expect(defaultProps.onChange).toHaveBeenCalled()
  })

  it('passes additional props to the checkbox', () => {
    render(<OPRCheckbox {...defaultProps} data-testid="custom-checkbox" />)
    const checkboxElement = screen.getByTestId('custom-checkbox')
    expect(checkboxElement).toBeInTheDocument()
  })
})
