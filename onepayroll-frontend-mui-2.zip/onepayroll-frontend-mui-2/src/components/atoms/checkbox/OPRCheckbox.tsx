import { Checkbox, FormControlLabel } from '@mui/material'
import { IOPRCheckbox } from 'interfaces'

function OPRCheckbox({
  label,
  onChange,
  checked,
  indeterminate,
  ...props
}: IOPRCheckbox) {
  return (
    <FormControlLabel
      control={(
        <Checkbox
          checked={checked}
          indeterminate={indeterminate}
          onChange={onChange}
          {...props}
        />
      )}
      label={label}
    />
  )
}

export default OPRCheckbox
