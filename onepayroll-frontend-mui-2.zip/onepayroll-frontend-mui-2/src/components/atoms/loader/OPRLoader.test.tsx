import '@testing-library/jest-dom/extend-expect'

import { createTheme, ThemeProvider } from '@mui/material/styles'
import { render, screen } from '@testing-library/react'

import CustomLoader from './OPRLoader'

describe('CustomLoader Component', () => {
  const theme = createTheme()

  const renderWithTheme = (ui: any) => render(<ThemeProvider theme={theme}>{ui}</ThemeProvider>)

  it('renders the Typography component with the correct text', () => {
    renderWithTheme(<CustomLoader text="Loading..." />)
    const textElement = screen.getByText('Loading...')
    expect(textElement).toBeInTheDocument()
  })

  it('renders the Typography component without text', () => {
    renderWithTheme(<CustomLoader />)

    const boxElements = document.querySelectorAll('div')
    const boxElement = Array.from(boxElements).find(
      (element) => window.getComputedStyle(element).display === 'flex',
    )

    expect(boxElement).toBeInTheDocument()
    if (boxElement) {
      expect(window.getComputedStyle(boxElement).display).toBe('flex')
    }
  })

  it('applies the correct margin-left to the Typography component', () => {
    renderWithTheme(<CustomLoader text="Loading..." />)
    const textElement = screen.getByText('Loading...')
    expect(textElement).toHaveStyle('margin-left: 8px') // Assuming theme.spacing(1) is 8px
  })
})
