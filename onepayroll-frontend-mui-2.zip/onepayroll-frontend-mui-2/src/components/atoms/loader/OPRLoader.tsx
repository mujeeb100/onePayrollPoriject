import Box from '@mui/material/Box'
import Typography from '@mui/material/Typography'
import React from 'react'

import { Loader } from '../../../assets/svg-images/SvgComponents'

type CustomProps = {
    text?: string;
    [rest: string]: unknown;
  };

function CustomLoader({ text = '', ...rest }: CustomProps): JSX.Element {
  return (
    <Box sx={{ display: 'flex' }}>
      <Loader />
      <Typography gutterBottom sx={{ ml: (theme) => theme.spacing(1) }} variant="h4">
        {text}
      </Typography>
    </Box>
  )
}

export default CustomLoader
