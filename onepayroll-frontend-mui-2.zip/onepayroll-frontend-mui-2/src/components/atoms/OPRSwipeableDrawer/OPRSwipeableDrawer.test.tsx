import '@testing-library/jest-dom/extend-expect'

import { ThemeProvider } from '@mui/material/styles'
import { fireEvent, render, screen } from '@testing-library/react'
import customTheme from 'themes'

import OPRSwipeableDrawer from './index'

// console errors existing in the OPRSwipeableDrawer component
// we cant achieve 100% coverage because borderWidth is always going to be 1.
describe('OPRSwipeableDrawer Component', () => {
  const renderWithTheme = (ui: any) => render(<ThemeProvider theme={customTheme}>{ui}</ThemeProvider>)

  const setup = (props: any) => {
    const onClose = jest.fn()
    const onOpen = jest.fn()
    renderWithTheme(<OPRSwipeableDrawer {...props} onClose={onClose} onOpen={onOpen} />)
    return { onClose, onOpen }
  }

  it('renders the SwipeableDrawer with the correct props', () => {
    const props = {
      anchor: 'left',
      open: true,
      openPosition: 0,
      width: 240,
      constainerWidth: 240,
      children: <div>Drawer Content</div>,
    }
    setup(props)
    const drawerElement = screen.getByRole('presentation', { hidden: true })
    expect(drawerElement).toBeInTheDocument()
    expect(drawerElement).toHaveStyle('width: 240px')
  })

  it('calls onClose when the drawer is closed', () => {
    const props = {
      anchor: 'left',
      open: true,
      openPosition: 0,
      width: 240,
      constainerWidth: 300,
      borderWidth: 10,
      children: <div>Drawer Content</div>,
    }
    const { onClose } = setup(props)
    const drawerElement = screen.getByRole('presentation')
    fireEvent.keyDown(drawerElement, { key: 'Escape' })
    expect(onClose).toHaveBeenCalled()
  })

  it('renders the children correctly', () => {
    const props = {
      anchor: 'left',
      open: true,
      openPosition: 0,
      width: 240,
      constainerWidth: 300,
      children: <div>Drawer Content</div>,
    }
    setup(props)
    const contentElement = screen.getByText('Drawer Content')
    expect(contentElement).toBeInTheDocument()
  })
})
