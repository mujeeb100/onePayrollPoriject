import {
  Box, styled,
  SwipeableDrawer, SwipeableDrawerProps, Toolbar,
} from '@mui/material'
import { OPRSwipeableDrawerProps } from 'interfaces/OPRSwipeableDrawerProps'

type OPRSwipeableDrawerStyleProps = SwipeableDrawerProps | {
  width: number
  openPosition: number
  borderWidth: number
  constainerWidth: number
}

const OPRSwipeableDrawerStyle = styled(
  SwipeableDrawer,
)<OPRSwipeableDrawerStyleProps>(({
  theme, style, width, openPosition, borderWidth = 0, constainerWidth,
}: any) => ({
  ...({
    ...style,
    width: constainerWidth,
    '& .MuiModal-backdrop': {
      backgroundColor: theme.palette.blackBg.main,
      opacity: 0,
    },
    '& .MuiModal-root-MuiDrawer-root .MuiModal-backdrop': {
      left: '18%%',
    },
    '& .MuiDrawer-paper.MuiDrawer-paperAnchorLeft': {
      boxShadow: 'none',
      border: `${borderWidth}px solid ${theme.palette.lightGray.main}`,

    },
    '& .MuiDrawer-paper': {
      boxSizing: 'border-box',
      width,
      position: 'absolute',
      left: openPosition,
      top: 5,
    },
    '& .MuiDrawer-paper::-webkit-scrollbar': {
      display: 'none',
    },
    '& .MuiPaper-root': {
      position: 'absolute',
    },
    '& .MuiDrawer-paper li': {
      listStyleType: 'none',
    },
    '& .MuiDrawer-paper li .css-cveggr-MuiListItemIcon-root': {
      display: 'block!important',
    },
  }),
}))

function OPRSwipeableDrawer({
  anchor, open, onClose, onOpen, children, openPosition, width, onMouseLeave, onMouseOverCapture, constainerWidth, sx,
}: OPRSwipeableDrawerProps) {
  return (
    <OPRSwipeableDrawerStyle
      disableEnforceFocus
      disableScrollLock
      hideBackdrop // This is a boolean to hide the backdrop
      anchor={anchor} // Position of Drawer from where drawer is opening -- 'left', 'right', 'top', 'bottom'
      borderWidth={1} // This is the border width of the drawer
      constainerWidth={constainerWidth} // This is the width of the container
      open={open} // This is Open State -- Boolean
      openPosition={openPosition} // This is the position of the drawer when it is open
      sx={sx}
      width={width} // This is the width of the drawer
      onClose={onClose} // This is a function to close the drawer
      onMouseLeave={onMouseLeave}
      onMouseOverCapture={onMouseOverCapture}
      onOpen={onOpen} // This is a function to open the drawer
    >
      <Toolbar sx={{ pt: 6 }} />
      <Box
        sx={{ width: '100%', height: '100%' }}
      >
        {children}
      </Box>
    </OPRSwipeableDrawerStyle>
  )
}

export default OPRSwipeableDrawer
