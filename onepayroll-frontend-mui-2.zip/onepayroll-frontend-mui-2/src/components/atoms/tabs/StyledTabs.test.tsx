import '@testing-library/jest-dom/extend-expect'

import { createTheme, ThemeProvider } from '@mui/material/styles'
import { fireEvent, render, screen } from '@testing-library/react'

import {
  a11yProps,
  CustomTabPanel, CustomTabPanelSendEmail, StyledTab, StyledTabs,
} from './index'

const theme = createTheme()

describe('StyledTabs Component', () => {
  it('renders StyledTabs with children', () => {
    const handleChange = jest.fn()
    render(
      <ThemeProvider theme={theme}>
        <StyledTabs value={0} onChange={handleChange}>
          <StyledTab label="Tab 1" {...a11yProps(0)} />
          <StyledTab label="Tab 2" {...a11yProps(1)} />
        </StyledTabs>
      </ThemeProvider>,
    )
    expect(screen.getByText('Tab 1')).toBeInTheDocument()
    expect(screen.getByText('Tab 2')).toBeInTheDocument()
  })

  it('calls onChange when a tab is clicked', () => {
    const handleChange = jest.fn()
    render(
      <ThemeProvider theme={theme}>
        <StyledTabs value={0} onChange={handleChange}>
          <StyledTab label="Tab 1" {...a11yProps(0)} />
          <StyledTab label="Tab 2" {...a11yProps(1)} />
        </StyledTabs>
      </ThemeProvider>,
    )
    fireEvent.click(screen.getByText('Tab 2'))
    expect(handleChange).toHaveBeenCalledWith(expect.anything(), 1)
  })
})

describe('CustomTabPanel Component', () => {
  it('renders children when value matches index', () => {
    render(
      <ThemeProvider theme={theme}>
        <CustomTabPanel index={0} value={0}>
          <div>Panel Content</div>
        </CustomTabPanel>
      </ThemeProvider>,
    )
    expect(screen.getByText('Panel Content')).toBeInTheDocument()
  })

  it('does not render children when value does not match index', () => {
    render(
      <ThemeProvider theme={theme}>
        <CustomTabPanel index={0} value={1}>
          <div>Panel Content</div>
        </CustomTabPanel>
      </ThemeProvider>,
    )
    expect(screen.queryByText('Panel Content')).not.toBeInTheDocument()
  })
})

describe('CustomTabPanelSendEmail Component', () => {
  it('renders children when index is in value array', () => {
    render(
      <ThemeProvider theme={theme}>
        <CustomTabPanelSendEmail index={1} value={[0, 1]}>
          <div>Panel Content</div>
        </CustomTabPanelSendEmail>
      </ThemeProvider>,
    )
    expect(screen.getByText('Panel Content')).toBeInTheDocument()
  })

  it('does not render children when index is not in value array', () => {
    render(
      <ThemeProvider theme={theme}>
        <CustomTabPanelSendEmail index={1} value={[0]}>
          <div>Panel Content</div>
        </CustomTabPanelSendEmail>
      </ThemeProvider>,
    )
    expect(screen.queryByText('Panel Content')).not.toBeInTheDocument()
  })
})
