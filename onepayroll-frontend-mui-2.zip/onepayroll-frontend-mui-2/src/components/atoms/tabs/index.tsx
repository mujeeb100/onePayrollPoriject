import {
  Box, styled,
  Tab, Tabs,
} from '@mui/material'

interface StyledTabsProps {
  children?: React.ReactNode;
  value: number;
  onChange: (event: React.SyntheticEvent, newValue: number) => void;
}

export const StyledTabs = styled((props: StyledTabsProps) => (
  <Tabs
    {...props}
    TabIndicatorProps={{ children: <span className="MuiTabs-indicatorSpan" /> }}
  />
))({
  '& .MuiTabs-indicator': {
    display: 'flex',
    justifyContent: 'center',
    backgroundColor: 'transparent',
  },
  '& .MuiTabs-indicatorSpan': {
    width: '100%',
    backgroundColor: '#DA3237',
  },
})

interface StyledTabProps {
  label: string;
}

export const StyledTab = styled((props: StyledTabProps) => (
  <Tab disableRipple {...props} />
))(({ theme }) => ({
  textTransform: 'none',
  fontWeight: theme.typography.fontWeightRegular,
  fontSize: theme.typography.pxToRem(15),
  marginRight: theme.spacing(1),
  color: '#3B3839',
  '&.Mui-selected': {
    color: '#3B3839',
  },
  '&.Mui-focusVisible': {
    backgroundColor: '#3B3839',
  },
}))

interface TabPanelProps {
    children?: React.ReactNode;
    index: number;
    value: number;
  }

export function CustomTabPanel(props: TabPanelProps) {
  const {
    children, value, index, ...other
  } = props

  return (
    <div
      aria-labelledby={`simple-tab-${index}`}
      hidden={value !== index}
      id={`simple-tabpanel-${index}`}
      role="tabpanel"
      {...other}
    >
      {value === index && (
        <Box sx={{ p: 3 }}>
          {children}
        </Box>
      )}
    </div>
  )
}

interface TabPanelPropsSendEmail {
  children?: React.ReactNode;
  index: number;
  value: number[];
}

export function CustomTabPanelSendEmail(props: TabPanelPropsSendEmail) {
  const {
    children, value, index, ...other
  } = props

  // Check if the current index is in the array of selected indices
  const isVisible = value.includes(index)

  return (
    <div
      aria-labelledby={`simple-tab-${index}`}
      hidden={!isVisible}
      id={`simple-tabpanel-${index}`}
      role="tabpanel"
      {...other}
    >
      {isVisible && (
        <Box sx={{ p: 3 }}>
          {children}
        </Box>
      )}
    </div>
  )
}

export function a11yProps(index: number) {
  return {
    id: `simple-tab-${index}`,
    'aria-controls': `simple-tabpanel-${index}`,
  }
}
