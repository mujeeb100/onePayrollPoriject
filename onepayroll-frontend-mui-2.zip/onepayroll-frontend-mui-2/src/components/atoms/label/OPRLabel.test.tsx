import '@testing-library/jest-dom/extend-expect'

import { createTheme, ThemeProvider } from '@mui/material/styles'
import { render, screen } from '@testing-library/react'

import OPRLabel from './OPRLabel'

describe('OPRLabel Component', () => {
  const theme = createTheme()

  const renderWithTheme = (ui: any) => render(<ThemeProvider theme={theme}>{ui}</ThemeProvider>)

  it('renders the label with the correct text', () => {
    renderWithTheme(<OPRLabel label="Test Label" />)
    const labelElement = screen.getByText('Test Label')
    expect(labelElement).toBeInTheDocument()
  })

  it('renders the children when label is not provided', () => {
    renderWithTheme(<OPRLabel>Test Children</OPRLabel>)
    const labelElement = screen.getByText('Test Children')
    expect(labelElement).toBeInTheDocument()
  })

  it('applies custom styles to the label', () => {
    const customStyles = { color: 'red', marginTop: '10px' }
    renderWithTheme(<OPRLabel CustomStyles={customStyles} label="Styled Label" />)
    const labelElement = screen.getByText('Styled Label')
    expect(labelElement).toHaveStyle('color: red')
    expect(labelElement).toHaveStyle('margin-top: 10px')
  })

  it('applies the correct color and background color', () => {
    renderWithTheme(<OPRLabel backgroundColor="yellow" color="blue" label="Colored Label" />)
    const labelElement = screen.getByText('Colored Label')
    expect(labelElement).toHaveStyle('color: blue')
    expect(labelElement).toHaveStyle('background-color: yellow')
  })

  it('applies the correct variant', () => {
    renderWithTheme(<OPRLabel label="Variant Label" variant="h1" />)
    const labelElement = screen.getByText('Variant Label')
    expect(labelElement).toHaveClass('MuiTypography-h1')
  })

  it('applies the correct component', () => {
    renderWithTheme(<OPRLabel component="h2" label="Component Label" />)
    const labelElement = screen.getByText('Component Label')
    expect(labelElement.tagName).toBe('H2')
  })
})
