import { useTheme } from '@emotion/react'
import styled from '@emotion/styled'
import Typography from '@mui/material/Typography'
import React from 'react'

type CustomProps = {
  label?: string;
  CustomStyles?: React.CSSProperties;
  color?:string;
  variant?:any;
  [rest: string]: unknown;
  children?: React.ReactNode;
  component?: any;
  backgroundColor?: string;
};
const OPRLabelStyle = styled(Typography)<CustomProps>(({ theme, style, backgroundColor }: any) => ({
  ...({
    // color: theme.typography.h1.overline.color,
    ...style,
    // marginTop: '15px',
  }),
  // customstyle will override the above styles and theme styles for the component
  ...style,
  backgroundColor,
}))
function OPRLabel({
  label, CustomStyles, color, backgroundColor, variant = 'subtitle2', children, component, ...rest
}: CustomProps): JSX.Element {
  const theme:any = useTheme() // Use the Theme type for the theme variable
  return (
    <OPRLabelStyle
      backgroundColor={backgroundColor}
      color={color}
      component={component}
      style={CustomStyles}
      variant={variant}
      {...rest}
    >
      {/* {label || 'Label name'} */}
      {label || children}
    </OPRLabelStyle>

  )
}

export default OPRLabel
