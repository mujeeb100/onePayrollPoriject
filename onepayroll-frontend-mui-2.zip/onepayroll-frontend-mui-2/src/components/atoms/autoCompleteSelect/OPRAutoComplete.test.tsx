import '@testing-library/jest-dom/extend-expect'

import { fireEvent, render, screen } from '@testing-library/react'

import OPRAutoCompleteSelect from './OPRAutoCompleteSelect'

describe('OPRAutoCompleteSelect Component', () => {
  const defaultProps = {
    name: 'test-autocomplete',
    label: 'Test Autocomplete',
    options: [
      { id: 1, type: 'Option 1' },
      { id: 2, type: 'Option 2' },
    ],
    selectedKey: 'type',
    onChange: jest.fn(),
  }

  it('renders the autocomplete with the correct label', () => {
    render(<OPRAutoCompleteSelect {...defaultProps} />)
    const labelElement = screen.getByLabelText(defaultProps.label)
    expect(labelElement).toBeInTheDocument()
  })

  it('renders the autocomplete with the correct placeholder', () => {
    render(<OPRAutoCompleteSelect {...defaultProps} placeholder="Select an option" />)
    const inputElement = screen.getByPlaceholderText('Select an option')
    expect(inputElement).toBeInTheDocument()
  })

  it('renders the autocomplete with the correct options', () => {
    render(<OPRAutoCompleteSelect {...defaultProps} />)
    const inputElement = screen.getByRole('combobox')
    fireEvent.mouseDown(inputElement)
    defaultProps.options.forEach((option) => {
      expect(screen.getByText(option.type)).toBeInTheDocument()
    })
  })

  it('calls the onChange handler when an option is selected', () => {
    render(<OPRAutoCompleteSelect {...defaultProps} />)
    const inputElement = screen.getByRole('combobox')
    fireEvent.mouseDown(inputElement)
    const optionElement = screen.getByText(defaultProps.options[0].type)
    fireEvent.click(optionElement)
    expect(defaultProps.onChange).toHaveBeenCalledWith(defaultProps.options[0])
  })

  it('works without onChange', () => {
    render(<OPRAutoCompleteSelect
      label="Test Autocomplete"
      name="test-autocomplete"
      options={[
        { id: 1, type: 'Option 1' },
        { id: 2, type: 'Option 2' },
      ]}
      selectedKey="type"
    />)
    const inputElement = screen.getByRole('combobox')
    fireEvent.mouseDown(inputElement)
    const optionElement = screen.getByText(defaultProps.options[0].type)
    fireEvent.click(optionElement)
  })

  it('renders the autocomplete with the correct value', () => {
    render(<OPRAutoCompleteSelect {...defaultProps} multiple value={[defaultProps.options[0]]} />)
    const chipElement = screen.getByText(defaultProps.options[0].type)
    expect(chipElement).toBeInTheDocument()
  })

  it('renders the autocomplete with the correct error state', () => {
    render(<OPRAutoCompleteSelect {...defaultProps} error helperText="Error message" />)
    const errorElement = screen.getByText('Error message')
    expect(errorElement).toBeInTheDocument()
  })

  it('renders the autocomplete with the correct disabled state', () => {
    render(<OPRAutoCompleteSelect {...defaultProps} disabled />)
    const inputElement = screen.getByRole('combobox')
    expect(inputElement).toBeDisabled()
  })

  it('renders correctly when there are no options', () => {
    render(<OPRAutoCompleteSelect {...defaultProps} options={[]} />)
    const inputElement = screen.getByRole('combobox')
    fireEvent.mouseDown(inputElement)
    expect(screen.queryByText('Option 1')).not.toBeInTheDocument()
    expect(screen.queryByText('Option 2')).not.toBeInTheDocument()
  })

  // it('renders the correct label when the option is a string', () => {
  //   const stringOptions = ['Option 1', 'Option 2']
  //   render(<OPRAutoCompleteSelect label="Test Autocomplete" name="test-autocomplete" options={stringOptions} selectedKey="" onChange={defaultProps.onChange} />)
  //   const inputElement = screen.getByRole('combobox')
  //   fireEvent.mouseDown(inputElement)
  //   expect(screen.queryByText('Option 1')).toBeInTheDocument()
  //   expect(screen.queryByText('Option 2')).toBeInTheDocument()
  //   const optionElement = screen.getByText('Option 1')
  //   fireEvent.click(optionElement)
  //   expect(defaultProps.onChange).toHaveBeenCalledWith('Option 1')
  // })

  // it('renders the correct tags when the option is a string', () => {
  //   const stringOptions = ['Option 1', 'Option 2']
  //   render(<OPRAutoCompleteSelect {...defaultProps} multiple options={stringOptions} selectedKey="" value={stringOptions} />)
  //   stringOptions.forEach((option) => {
  //     expect(screen.getByText(option)).toBeInTheDocument()
  //   })
  // })
})
