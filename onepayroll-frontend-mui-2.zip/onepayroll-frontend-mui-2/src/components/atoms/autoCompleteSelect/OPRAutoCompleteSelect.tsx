import {
  Autocomplete, Chip, FormControl,
  TextField,
} from '@mui/material'
import { SyntheticEvent } from 'react'

interface AutoCompleteSelectProps {
  value?: any;
  error?: boolean;
  name: string;
  label?: string;
  placeholder?: string;
  maxWidth?: number;
  minWidth?: number;
  helperText?: string;
  options: any;
  multiple?: boolean;
  onChange?: (event: SyntheticEvent<Element, Event>) => void;
  selectedKey:any;
  disabled?: boolean;
  isRequired?:boolean;
  CustomStyles?: React.CSSProperties; // Add style prop
  className?: string; // Add className prop
}

export default function OPRAutoCompleteSelect({
  value,
  name,
  label,
  disabled = false,
  placeholder,
  error,
  maxWidth,
  CustomStyles,
  minWidth,
  options,
  onChange,
  helperText,
  multiple = false,
  selectedKey,
  isRequired,
  className, // Include className prop in destructured props
  ...props
}: AutoCompleteSelectProps) {
  // to match with the shape of value if multiple or not
  const defaultValue = multiple ? [] : null
  return (
    <FormControl
      error={error}
      sx={{
        m: 0, width: '100%', border: error ? '1px solid red' : '',
      }}
      variant="outlined"
    >
      <Autocomplete
        aria-required={isRequired}
        className={className} // Include className prop
        disabled={disabled}
        id="tags-outlined"
        multiple={multiple}
        options={options}
        style={CustomStyles}
        {...props}
        filterSelectedOptions
        getOptionLabel={(option:any) => option[selectedKey] || ''}
        isOptionEqualToValue={(option: any, value: any) => JSON.stringify(option) === JSON.stringify(value)}
        renderInput={(params:any) => (
          <TextField
            {...params}
            helperText={helperText}
            label={label}
            name={name}
            placeholder={placeholder}
            required={isRequired}
          />
        )}
        renderTags={(tagValue, getTagProps) => tagValue.map((option, index:any) => (
          <Chip
            label={typeof option === 'string' ? option : (option as any)[selectedKey]}
            variant="filled"
            {...getTagProps({ index })}
          />
        ))}
        value={value ?? defaultValue}
        onChange={(event: any, value: any) => {
          if (typeof onChange === 'function') {
            onChange(value)
          }
        }}
      />
    </FormControl>
  )
}
