import axios, { AxiosError, AxiosRequestConfig, AxiosResponse } from 'axios'
import { useEffect, useState } from 'react'
// import { set } from 'lodash'
// import { Toast } from 'components/atoms/dialog/alert'

const useAxios = (axiosParams: AxiosRequestConfig, callBack:any) => {
  const [response, setResponse] = useState<AxiosResponse>()
  const [error, setError]:any = useState<AxiosError>()
  const [loading, setLoading]:any = useState(axiosParams.method === 'GET' || axiosParams.method === 'get')
  const [StatusCode, setStatus]:any = useState(null)
  const fetchData = async (params: AxiosRequestConfig) => {
    try {
      const { data } = await axios.request(params)

      setStatus(data.statusCode)
      if (data.statusCode === 200) {
        setResponse(data.responseData)
      } else {
        setError(data.responseData.Errors)
      }
    } catch (err) {
      const { message }:any = err
      setError(message)
    } finally {
      setLoading(false)
    }
  }

  const sendData = async (params:any, url?:any, message?:any, isMessage = true) => {
    try {
      const { data } = await axios.request(params)
      setStatus(data)

      if (data.statusCode === 200) {
        if (isMessage) {
        //   await Toast.fire({
        //     icon: 'success',
        //     title: message,
        // })
        }
        callBack()
      } else {
        // Toast.fire({
        //   icon: 'error',
        //   title: data.errors.Message,
        // })
        setError(data.responseData.errors)
      }
    } catch (err) {

      // Toast.fire({
      //   icon: 'error',
      //   title: err,
      // })
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    if (axiosParams.method === 'GET' || axiosParams.method === 'get') {
      fetchData(axiosParams)
    }
  }, [])

  return [
    response, error, loading, sendData, StatusCode,
  ]
}

export default useAxios
