import { useOktaAuth } from '@okta/okta-react'
import {
  createContext, useContext, useEffect, useMemo,
  useState,
} from 'react'
import { useNavigate } from 'react-router-dom'

const APIContext = createContext()

export function APIContextProvider({ children }) {
  const [accessToken, setAccessToken] = useState(null)
  const [userInfo, setUserInfo] = useState(null)
  const [isLoading, setIsLoading] = useState(true)
  const { oktaAuth, authState } = useOktaAuth()
  const [entity, setEntity] = useState(JSON.parse(localStorage.getItem('Entity')))
  const navigate = useNavigate()

  const handleLogin = async () => {
    try {
      await oktaAuth.signInWithRedirect({ originalUri: '/' })
    } catch (err) {
      console.log(err)
    }
  }

  const handleLogout = async () => {
    try {
      localStorage.removeItem('Entity')
      await oktaAuth.signOut()
    } catch (err) {
      console.log(err, 'Unable to logout')
      localStorage.clear()
      navigate('/login')
    }
  }

  const handleEntity = (item) => {
    console.log('*****************&&&&&&', item)
    localStorage.setItem('Entity', JSON.stringify(item))
    window.location.reload()
    setEntity(item)
  }

  useEffect(() => {
    if (!authState || !authState.isAuthenticated) {
      // When user isn't authenticated, forget any user info
      setUserInfo(null)
    } else {
      oktaAuth.getUser().then((info) => {
        setIsLoading(false)
        setUserInfo(info)
        setAccessToken(oktaAuth.getAccessToken())
      }).catch((err) => {
        console.error(err)
      })
    }
  }, [authState, oktaAuth])

  const value = useMemo(
    () => ({
      accessToken,
      userInfo,
      handleLogin,
      handleLogout,
      isLoading,
      handleEntity,
      entity,
    }),
    [accessToken, entity],
  )

  return (
    <APIContext.Provider
      value={value}
    >
      {children}
    </APIContext.Provider>
  )
}

export function useAPI() {
  const context = useContext(APIContext)
  if (context === undefined) {
    throw new Error('Context must be used within a Provider')
  }
  return context
}
