import React, { useEffect, useState } from 'react'
import { useSelector } from 'react-redux'
import { useNavigate } from 'react-router-dom'
import { activePermissions } from 'slices/permissionSlice'
import { ProtectedRouteProps } from 'types/protectedRoute'

function ProtectedRoute(props: ProtectedRouteProps) {
  const permissionList = useSelector(activePermissions)
  const [isLoading, setIsLoading] = useState(true)
  const navigate = useNavigate()
  const checkUserPersmission = (props: any) => {
    const { permission } = props
    if (!permissionList.includes(permission)) {
      navigate(props.redirectPath)
      setIsLoading(false)
    } else {
      setIsLoading(false)
    }
  }
  useEffect(() => {
    checkUserPersmission(props)
  }, [props.permission])

  return isLoading ? <div>Loading...</div> : props.children
}
export default ProtectedRoute
