import { Action, configureStore, ThunkAction } from '@reduxjs/toolkit'
import {
  employeeService,
  entityService,
  globalService,
  identityService,
  integrationService,
  loggingService,
  notificationService,
  payrollService,
  reportsService,
} from 'api/api'
import SelectLangReducer from 'slices/select-lang-slice'

import PermissionReducer from '../slices/permissionSlice'
import appConfigReducer from './slices/appConfig'

export const store = configureStore({
  reducer: {
    // proposed slices: entity, payroll, appConfig,...
    appConfig: appConfigReducer,
    [entityService.reducerPath]: entityService.reducer,
    [globalService.reducerPath]: globalService.reducer,
    [payrollService.reducerPath]: payrollService.reducer,
    permissionSlice: PermissionReducer,
    [employeeService.reducerPath]: employeeService.reducer,
    [identityService.reducerPath]: identityService.reducer,
    [integrationService.reducerPath]: integrationService.reducer,
    [loggingService.reducerPath]: loggingService.reducer,
    [notificationService.reducerPath]: notificationService.reducer,
    [reportsService.reducerPath]: reportsService.reducer,
    selectLangSlice: SelectLangReducer,
    selectDateFormateSlice: SelectLangReducer,
  },
  middleware: (getDefaultMiddleware) => getDefaultMiddleware().concat(
    entityService.middleware,
    globalService.middleware,
    payrollService.middleware,
    employeeService.middleware,
    reportsService.middleware,
    identityService.middleware,
    integrationService.middleware,
    notificationService.middleware,
    loggingService.middleware,
  ),
})

export type AppDispatch = typeof store.dispatch
export type RootState = ReturnType<typeof store.getState>
export type AppThunk<ReturnType = void> = ThunkAction<
  ReturnType,
  RootState,
  unknown,
  Action<string>
>
