import { createSlice, PayloadAction } from '@reduxjs/toolkit'
import { allApiSlices } from 'api/api'
import { AppThunk } from 'store/store'
import { getEnv } from 'utils'

export interface AppConfigState {
  baseUrl: Record<keyof typeof allApiSlices, string>
}

const getURL = (key: string): string => {
  const url = getEnv(key, null)
  if (!url) {
    throw new Error(`${key} is not defined in .env file`)
  }
  return url
}

const initialState: AppConfigState = {
  baseUrl: {
    entityService: getURL('REACT_APP_UP_BASE_URL'),
    globalService: getURL('REACT_APP_MP_BASE_URL'),
    payrollService: getURL('REACT_APP_UP_BASE_URL'),
    employeeService: getURL('REACT_APP_UP_BASE_URL'),
    identityService: getURL('REACT_APP_MP_BASE_URL'),
    reportsService: getURL('REACT_APP_MP_BASE_URL'),
    integrationService: getURL('REACT_APP_UP_BASE_URL'),
    notificationService: getURL('REACT_APP_UP_BASE_URL'),
    loggingService: getURL('REACT_APP_UP_BASE_URL'),
  },
}

type SetBaseUrlParams = {
  baseUrl: string
  apiSliceString: keyof typeof allApiSlices
}

export const setBaseUrl = (params: SetBaseUrlParams): AppThunk => (dispatch) => {
  const { apiSliceString } = params
  dispatch(allApiSlices[apiSliceString].util.resetApiState())
  dispatch(setBaseUrlInt(params))
}

export const appConfigSlice = createSlice({
  name: 'appConfig',
  initialState,
  reducers: {
    setBaseUrlInt: (state, action: PayloadAction<SetBaseUrlParams>) => {
      state.baseUrl[action.payload.apiSliceString] = action.payload.baseUrl
    },
  },
})

// Actions that need not be exported (generally used within thunks)
const { setBaseUrlInt } = appConfigSlice.actions

// Actions to be exported (used in the App)
export const {} = appConfigSlice.actions // eslint-disable-line no-empty-pattern

export default appConfigSlice.reducer
