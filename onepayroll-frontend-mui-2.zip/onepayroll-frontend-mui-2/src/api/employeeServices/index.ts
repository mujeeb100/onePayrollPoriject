import { defaultSilce } from 'api'
import { employeeService, payrollService } from 'api/api'

export const {
  useGetAllPersonQuery,
  useLazyGetPersonByIdQuery,
  usePersonDeleteMutation,
  usePersoncreateMutation,
  useLazyGetAllPersonQuery,
  usePersonUpdateMutation,
} = defaultSilce(employeeService, 'person', ['Person'])

export const {
  useGetAllEmployeeProfileQuery,
  useLazyGetEmployeeProfileByIdQuery,
  useEmployeeProfileDeleteMutation,
  useEmployeeProfileCreateMutation,
  useLazyGetAllEmployeeProfileQuery,
  useEmployeeProfileUpdateMutation,
} = defaultSilce(employeeService, 'employeeProfile', ['EmployeeProfile'])

export const {
  useGetAllEmployeeBankAccountQuery,
  useLazyGetEmployeeBankAccountByIdQuery,
  useEmployeeBankAccountDeleteMutation,
  useEmployeeBankAccountCreateMutation,
  useLazyGetAllEmployeeBankAccountQuery,
  useEmployeeBankAccountUpdateMutation,
} = defaultSilce(employeeService, 'employeeBankAccount', ['EmployeeBankAccount'])

export const {
  useGetAllEmployeePensionFundQuery,
  useLazyGetEmployeePensionFundByIdQuery,
  useEmployeePensionFundDeleteMutation,
  useEmployeePensionFundCreateMutation,
  useLazyGetAllEmployeePensionFundQuery,
  useEmployeePensionFundUpdateMutation,
} = defaultSilce(employeeService, 'employeePensionFund', ['EmployeePensionFund'])

export const {
  useGetAllEmployeeRecurringQuery,
  useLazyGetEmployeeRecurringByIdQuery,
  useEmployeeRecurringDeleteMutation,
  useEmployeeRecurringCreateMutation,
  useLazyGetAllEmployeeRecurringQuery,
  useEmployeeRecurringUpdateMutation,
} = defaultSilce(employeeService, 'employeeRecurring', ['EmployeeRecurring'])

export const {
  useGetAllEmployeeQuarterQuery,
  useLazyGetEmployeeQuarterByIdQuery,
  useEmployeeQuarterDeleteMutation,
  useEmployeeQuarterCreateMutation,
  useLazyGetAllEmployeeQuarterQuery,
  useEmployeeQuarterUpdateMutation,
} = defaultSilce(employeeService, 'employeeQuarter', ['EmployeeQuarter'])

export const {
  useGetAllEmployeeMovementFundQuery,
  useLazyGetEmployeeMovementFundByIdQuery,
  useEmployeeMovementDeleteMutation,
  useEmployeeMovementCreateMutation,
  useLazyGetAllEmployeeMovementQuery,
  useEmployeeMovementUpdateMutation,
} = defaultSilce(employeeService, 'employeeMovement', ['EmployeeMovement'])

export const {
  useGetAllEmployeeAverageWageQuery,
  useLazyGetEmployeeAverageWageByIdQuery,
  useEmployeeAverageWageDeleteMutation,
  useEmployeeAverageWageCreateMutation,
  useLazyGetAllEmployeeAverageWageQuery,
  useEmployeeAverageWageUpdateMutation,
} = defaultSilce(employeeService, 'employeeAverageWage', ['EmployeeAverageWage'])
export const {
  usePayRollAverageWageUpdateMutation,
  // usePayRollAverageWageCreateMutation,
} = defaultSilce(payrollService, 'payRollAverageWage', ['PayRollAverageWage'])
export const {
  useAverageWageDisregardedDayUpdateMutation,
} = defaultSilce(employeeService, 'averageWageDisregardedDay', ['EmployeeAverageWage'])
export const {
  useGetAllEmployeePasswordQuery,
  useLazyGetEmployeePasswordByIdQuery,
  useEmployeePasswordDeleteMutation,
  useLazyGetAllEmployeePasswordQuery,
  useEmployeePasswordUpdateMutation,
} = defaultSilce(employeeService, 'employeePassword', ['EmployeePassword'])

export const {
  useGeneratePasswordCreateMutation,

} = defaultSilce(employeeService, 'generatePassword', ['EmployeePassword'])

export const {
  useGetAllEmployeeRecurringDropDownQuery,
} = defaultSilce(employeeService, 'employeeRecurringDropDown', ['EmployeeRecurring'])

export const {
  useGetAllEmpMovementQuery,
  useLazyGetEmpMovementByIdQuery,
  useEmpMovementDeleteMutation,
  useEmpMovementCreateMutation,
  useLazyGetAllEmpMovementQuery,
  useEmpMovementUpdateMutation,
} = defaultSilce(employeeService, 'empMovement', ['EmpMovement'])
export const {
  useGetAllEmployeeMovementActionQuery,
  useLazyGetEmployeeMovementActionByIdQuery,
  useEmployeeMovementActionDeleteMutation,
  useEmployeeMovementActionCreateMutation,
  useLazyGetAllEmployeeMovementActionQuery,
  useEmployeeMovementActionUpdateMutation,
} = defaultSilce(employeeService, 'employeeMovementAction', ['EmployeeMovementAction'])

// Update employee movement
export const {
  useEmpMovement1UpdateMutation,
} = defaultSilce(employeeService, 'empMovement1', ['EmpMovement'])

// exmployee password for export
export const {
  useGetAllEmployeePasswordExportQuery,
} = defaultSilce(employeeService, 'employeePasswordExport', ['EmployeePassword'])

// query params with update
export const {
  useEmpMovement1Update2Mutation,
} = defaultSilce(employeeService, 'empMovement1', ['EmpMovement'])
// employee leave transaction
export const {
  useGetAllEmployeeLeaveTransactionQuery,
  useLazyGetEmployeeLeaveTransactionByIdQuery,
  useEmployeeLeaveTransactionDeleteMutation,
  useEmployeeLeaveTransactionCreateMutation,
  useLazyGetAllEmployeeLeaveTransactionActionQuery,
  useEmployeeLeaveTransactionUpdateMutation,
} = defaultSilce(employeeService, 'employeeLeaveTransaction', ['employeeLeaveTransaction'])

// employee remarks
export const {
  useGetAllEmployeeRemarksQuery,
  useLazyGetEmployeeRemarksByIdQuery,
  useEmployeeRemarksDeleteMutation,
  useEmployeeRemarksCreateMutation,
  useLazyGetAllEmployeeRemarksQuery,
  useEmployeeRemarksUpdateMutation,
} = defaultSilce(employeeService, 'employeeRemarks', ['EmployeeRemarks'])
