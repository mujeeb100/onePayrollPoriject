import { defaultSilce } from 'api'
import { globalService } from 'api/api'
import { mutationBuilder } from 'api/apiUtils'
import apiEndPoint from 'constants/apiEndPoint'
import capitalize from 'lodash/capitalize'
import {
  CreateCountry, UpdateCountry,
} from 'types/api/globalService/currency'

interface Post {
  id: number
  title: string
  body: string
}

const globalSlice:any = (serviceName = globalService, methodName = 'country', tagName = ['Country']) => {
  const countrySlice = serviceName.injectEndpoints({
    endpoints: (builder) => ({
      [`getAll${capitalize(methodName)}`]: builder.query<any, void>({
        query: (url) => `${apiEndPoint[`${methodName}List`]}${url}`,
        transformResponse: (response: any) => response,
        transformErrorResponse: (
          response: { status: string | number },
        ) => response.status,
        providesTags: ['Country'],
        extraOptions: {
          maxRetries: 1,
        },
      }),
      [`get${capitalize(methodName)}ById`]: builder.query<any, string>({
        query: (id: string) => `posts/${id}`,
        providesTags: tagName && ['Country'],
        extraOptions: {
          maxRetries: 1,
        },
      }),
      [`${methodName}create`]: mutationBuilder<CreateCountry>({
        builder,
        query: (params: any) => ({
          url: apiEndPoint[`create${capitalize(methodName)}`],
          method: 'POST',
          body: params,
        }),
        invalidatesTags: tagName && ['Country'],
      }),
      [`${methodName}Update`]: mutationBuilder<UpdateCountry>({
        builder,
        query: (params: any) => ({
          url: apiEndPoint[`update${capitalize(methodName)}`],
          method: 'PUT',
          body: params,
        }),
        invalidatesTags: tagName && ['Country'],
      }),
      [`${methodName}Delete`]: mutationBuilder<string>({
        builder,
        query: (id: string) => ({
          url: `${apiEndPoint[`delete${capitalize(methodName)}`]}?CountryCode=${id}`,
          method: 'DELETE',
        }),
        invalidatesTags: tagName && ['Country'],
      }),

    }),
  })
  return countrySlice
}

export const {
  useGetAllCountryQuery,
  useLazyGetCountryByIdQuery,
  useCountryDeleteMutation,
  useCountryCreateMutation,
  useLazyGetAllCountryQuery,
  useCountryUpdateMutation,
  util,
}:any = defaultSilce(globalService, 'country', ['Country'])

// currency slice
export const {
  useGetAllCurrencyQuery,
  useLazyGetCurrencyByIdQuery,
  useCurrencyDeleteMutation,
  useCurrencyCreateMutation,
  useLazyGetAllCurrencyQuery,
  useCurrencyUpdateMutation,
} = defaultSilce(globalService, 'currency', ['Currency'])

export const {

  useGetAllHolidayCalenderQuery,
  useLazyGetHolidayCalenderByIdQuery,
  useHolidayCalenderDeleteMutation,
  useHolidayCalenderCreateMutation,
  useLazyGetAllHolidayCalenderQuery,
  useHolidayCalenderUpdateMutation,
} = defaultSilce(globalService, 'holidayCalender', ['HolidayCalender'])

export const {
  useGetAllGlobalPensionFundSchemeRuleQuery,
  useLazyGetGlobalPensionFundSchemeRuleByIdQuery,
  useGlobalPensionFundSchemeRuleDeleteMutation,
  useGlobalPensionFundSchemeRuleCreateMutation,
  useLazyGetAllGlobalPensionFundSchemeRuleQuery,
  useGlobalPensionFundSchemeRuleUpdateMutation,
} = defaultSilce(globalService, 'globalPensionFundSchemeRule', ['GlobalPensionFundSchemeRule'])

export const {
  useGetAllStandardExpressionQuery,
  useLazyGetStandardExpressionByIdQuery,
  useStandardExpressionDeleteMutation,
  useStandardExpressioncreateMutation,
  useLazyGetAllStandardExpressionQuery,
  useStandardExpressionUpdateMutation,
} = defaultSilce(globalService, 'standardExpression', ['StandardExpression'])

export const {
  useGetAllStandardFormulaQuery,
  useLazyGetStandardFormulaByIdQuery,
  useStandardFormulaDeleteMutation,
  useStandardFormulacreateMutation,
  useLazyGetAllStandardFormulaQuery,
  useStandardFormulaUpdateMutation,
} = defaultSilce(globalService, 'standardFormula', ['StandardFormula'])

// nationality slice
export const {
  useGetAllNationalityQuery,
  useLazyGetNationalityByIdQuery,
  useNationalityDeleteMutation,
  useNationalityCreateMutation,
  useLazyGetAllNationalityQuery,
  useNationalityUpdateMutation,
} = defaultSilce(globalService, 'nationality', ['Nationality'])

//  payment method slice
export const {
  useGetAllPaymentMethodQuery,
  useLazyGetPaymentMethodByIdQuery,
  usePaymentMethodDeleteMutation,
  usePaymentMethodCreateMutation,
  useLazyGetAllPaymentMethodQuery,
  usePaymentMethodUpdateMutation,
} = defaultSilce(globalService, 'paymentMethod', ['PaymentMethod'])

// provider type slice
export const {
  useGetAllProviderTypeQuery,
  useLazyGetProviderTypeByIdQuery,
  useProviderTypeDeleteMutation,
  useProviderTypeCreateMutation,
  useLazyGetAllProviderTypeQuery,
  useProviderTypeUpdateMutation,
} = defaultSilce(globalService, 'providerType', ['ProviderType'])
// setting template slice
export const {
  useGetAllSettingTemplateQuery,
  useLazyGetSettingTemplateByIdQuery,
  useSettingTemplateDeleteMutation,
  useSettingTemplateCreateMutation,
  useLazyGetAllSettingTemplateQuery,
  useSettingTemplateUpdateMutation,
} = defaultSilce(globalService, 'settingTemplate', ['SettingTemplate'])

// satutory mappingsfs
export const {
  useGetAllSatutoryMappingQuery,
} = defaultSilce(globalService, 'satutoryMapping', ['SettingTemplate'])

// client group entity slice
export const {
  useGetAllClientGroupEntityQuery,
  useLazyGetClientGroupEntityByIdQuery,
  useClientGroupEntityDeleteMutation,
  useClientGroupEntityCreateMutation,
  useLazyGetAllClientGroupEntityQuery,
  useClientGroupEntityUpdateMutation,
} = defaultSilce(globalService, 'clientGroupEntity', ['ClientGroupEntity'])

// currency slice
export const {
  useGetAllPensionFundTerminationQuery,
  useLazyGetPensionFundTerminationByIdQuery,
  usePensionFundTerminationDeleteMutation,
  usePensionFundTerminationCreateMutation,
  useLazyGetAllPensionFundTerminationQuery,
  usePensionFundTerminationUpdateMutation,
} = defaultSilce(globalService, 'pensionFundTermination', ['PensionFundTermination'])

// holiday dates
export const {
  useGetAllHolidayDatesQuery,
  useLazyGetHolidayDatesByIdQuery,
  useHolidayDatesDeleteMutation,
  useHolidayDatesCreateMutation,
  useLazyGetAllHolidayDatesQuery,
  useHolidayDatesUpdateMutation,
} = defaultSilce(globalService, 'holidayDates', ['HolidayDates'])
// get provider type single list
export const {
  useGetAllProviderTypeSingleQuery,
} = defaultSilce(globalService, 'providerTypeSingle', ['ProviderType'])
