import { reportServiceSilce } from 'api'
import { reportsService } from 'api/api'

export const {
  useGetAllReportDesignerQuery,
} = reportServiceSilce(reportsService, 'reportDesigner', ['ReportDesigner'])
