import { globalService } from 'api/api'
import { mutationBuilder } from 'api/apiUtils'
// import { capitalizeTxt } from 'constants/index'
import apiEndPoint from 'constants/apiEndPoint'
import {
  CreateCountry, UpdateCountry,
} from 'types/api/globalService/currency'
import { firstLatterCapital, getAPIWithEntityUrl } from 'utils'

interface Post {
  id: number
  title: string
  body: string
}

export const defaultSilce:any = (serviceName = globalService, methodName = 'country', tagName = ['Country']) => {
  const countrySlice = serviceName.injectEndpoints({
    endpoints: (builder) => ({
      [`getAll${firstLatterCapital(methodName)}`]: builder.query<any, void>({
        query: (url) => getAPIWithEntityUrl(`${apiEndPoint[`${methodName}List`]}${url}`),
        transformResponse: (response: any) => {
          if (methodName === 'reportDesigner') {
            return response
          }
          return response.data || response.responseData
        },
        transformErrorResponse: (
          response: { status: string | number },
        ) => response.status,
        providesTags: ['Country'],
        extraOptions: {
          maxRetries: 1,
        },
      }),
      [`get${firstLatterCapital(methodName)}ById`]: builder.query<any, string>({
        query: (id: string) => getAPIWithEntityUrl(`${apiEndPoint[`${methodName}ListById`]}=${id}`),
        providesTags: tagName && ['Country'],
        extraOptions: {
          maxRetries: 1,
        },
      }),
      [`${methodName}Create`]: mutationBuilder<CreateCountry>({
        builder,
        query: (params: any) => ({
          url: getAPIWithEntityUrl(apiEndPoint[`create${firstLatterCapital(methodName)}`]),
          method: 'POST',
          body: params,
        }),
        invalidatesTags: tagName && ['Country'],
      }),
      [`${methodName}Update`]: mutationBuilder<UpdateCountry>({
        builder,
        query: (params: any) => ({
          url: getAPIWithEntityUrl(apiEndPoint[`update${firstLatterCapital(methodName)}`]),
          method: 'PUT',
          body: params,
        }),
        invalidatesTags: tagName && ['Country'],
      }),
      // update2 with query params
      [`${methodName}Update2`]: mutationBuilder<string>({
        builder,
        query: (url: string) => ({
          url: getAPIWithEntityUrl(`${apiEndPoint[`update${firstLatterCapital(methodName)}`]}?${url}`),
          method: 'PUT',
        }),
        invalidatesTags: tagName && ['Country'],
      }),
      [`${methodName}Delete`]: mutationBuilder<string>({
        builder,
        query: (url: string) => ({
          url: getAPIWithEntityUrl(`${apiEndPoint[`delete${firstLatterCapital(methodName)}`]}?${url}`),
          method: 'DELETE',
        }),
        invalidatesTags: tagName && ['Country'],
      }),
      // delete for bulk pass in the body of the request
      [`${methodName}Delete2`]: mutationBuilder<{ url: string, body: any }>({
        builder,
        query: ({ url, body }) => ({
          url: getAPIWithEntityUrl(`${apiEndPoint[`delete${firstLatterCapital(methodName)}`]}`),
          method: 'DELETE',
          body: JSON.stringify(body), // Convert body to JSON string if necessary
          headers: {
            'Content-Type': 'application/json', // Specify content type if needed
          },
        }),
        invalidatesTags: tagName && ['Country'],
      }),
      // delete for bulk pass in the body of the request
      [`${methodName}ChangeStatus`]: mutationBuilder<CreateCountry>({
        builder,
        query: (params: any) => ({
          url: getAPIWithEntityUrl(apiEndPoint[`changeStatus${firstLatterCapital(methodName)}`]),
          method: 'POST',
          body: params,
        }),
        invalidatesTags: tagName && ['Country'],
      }),
    }),
  })
  return countrySlice
}
// export const invalidateCache = (tags = ['Country']) => {
//   console.log('$$$$$$$$$$$$', defaultSilce().util.invalidateTags(tags))

//   defaultSilce().util.invalidateTags(tags)
// }
export const reportServiceSilce:any = (serviceName = globalService, methodName = 'country', tagName = ['Country']) => {
  const countrySlice:any = serviceName.injectEndpoints({
    endpoints: (builder) => ({
      [`getAll${firstLatterCapital(methodName)}`]: builder.query<any, void>({
        query: (url) => getAPIWithEntityUrl(`${apiEndPoint[`${methodName}List`]}${url}`),

        providesTags: ['Country'],
        extraOptions: {
          maxRetries: 1,
        },
      }),
      [`get${firstLatterCapital(methodName)}ById`]: builder.query<any, string>({
        query: (id: string) => getAPIWithEntityUrl(`${apiEndPoint[`${methodName}ListById`]}=${id}`),
        providesTags: tagName && ['Country'],
        extraOptions: {
          maxRetries: 1,
        },
      }),
      [`${methodName}Create`]: mutationBuilder<CreateCountry>({
        builder,
        query: (params: any) => ({
          url: getAPIWithEntityUrl(apiEndPoint[`create${firstLatterCapital(methodName)}`]),
          method: 'POST',
          body: params,
        }),
        invalidatesTags: tagName && ['Country'],
      }),
      [`${methodName}Update`]: mutationBuilder<UpdateCountry>({
        builder,
        query: (params: any) => ({
          url: getAPIWithEntityUrl(apiEndPoint[`update${firstLatterCapital(methodName)}`]),
          method: 'PUT',
          body: params,
        }),
        invalidatesTags: tagName && ['Country'],
      }),
      [`${methodName}Delete`]: mutationBuilder<string>({
        builder,
        query: (url: string) => ({
          url: getAPIWithEntityUrl(`${apiEndPoint[`delete${firstLatterCapital(methodName)}`]}?${url}`),
          method: 'DELETE',
        }),
        invalidatesTags: tagName && ['Country'],
      }),
      [`${methodName}ChangeStatus`]: mutationBuilder<CreateCountry>({
        builder,
        query: (params: any) => ({
          url: getAPIWithEntityUrl(apiEndPoint[`changeStatus${firstLatterCapital(methodName)}`]),
          method: 'POST',
          body: params,
        }),
        invalidatesTags: tagName && ['Country'],
      }),
    }),
  })
  return countrySlice
}
