import {
  BaseQueryFn, FetchArgs, fetchBaseQuery, FetchBaseQueryError, retry,
} from '@reduxjs/toolkit/dist/query'
import { EndpointBuilder } from '@reduxjs/toolkit/dist/query/endpointDefinitions'
import { getauthToken } from 'utils/index'

export const wrappedDynamicBaseQuery = (apiSlice: string) => {
  const staggeredDynamicBaseQuery: BaseQueryFn<string | FetchArgs,
  unknown,
  FetchBaseQueryError> = async (args, store, extraOptions) => {
    // eslint disable-next-line
    const baseUrl: string = (store.getState() as any).appConfig.baseUrl[apiSlice]
    // ^ Think of better way to handle typing here
    const rawBaseQuery = retry(fetchBaseQuery({
      baseUrl,
      prepareHeaders: (headers, { getState }) => {
        // By default, if we have a token in the store, let's use that for authenticated requests
        const token = getauthToken()
        if (token) {
          headers.set('Authorization', `Bearer ${token}`)
        }
        return headers
      },
    }), {
      maxRetries: 0,
    })
    return rawBaseQuery(args, store, extraOptions)
  }
  return staggeredDynamicBaseQuery
}

export const mutationBuilder = <T>(props: {
  builder: EndpointBuilder<BaseQueryFn<
      string | FetchArgs,
      unknown,
      FetchBaseQueryError
    >,
    string, string>,
  query: (arg: T) => string | FetchArgs,
  invalidatesTags?: string[],
  extraOptions?: object,
  successCallback?: (response: any) => void,
  failureCallback?: (response: any) => void,
}) => props.builder.mutation<any, T>({
  query: props.query,
  transformResponse: (response: any) => {
    if (props.successCallback) {
      return props.successCallback(response)
    }
    return response
  },
  transformErrorResponse: (response: any) => {
    if (props.failureCallback) {
      return props.failureCallback(response)
    }
    return response
  },
  invalidatesTags: props.invalidatesTags,
  extraOptions: {
    ...props.extraOptions,
  },
})

export const queryBuilder = <T>(props: {
  builder: EndpointBuilder<BaseQueryFn<
      string | FetchArgs,
      unknown,
      FetchBaseQueryError
    >,
    string, string>,
  query: (arg: T) => string | FetchArgs,
  providesTags?: string[],
  extraOptions?: object,
  successCallback?: (response: any) => void,
  failureCallback?: (response: any) => void,
}) => props.builder.query<any, T>({
  query: props.query,
  transformResponse: (response: any) => {
    if (props.successCallback) {
      return props.successCallback(response)
    }
    return response
  },
  transformErrorResponse: (response: any) => {
    if (props.failureCallback) {
      return props.failureCallback(response)
    }
    return response
  },
  providesTags: props.providesTags,
  extraOptions: {
    maxRetries: 1,
    ...props.extraOptions,
  },
})
