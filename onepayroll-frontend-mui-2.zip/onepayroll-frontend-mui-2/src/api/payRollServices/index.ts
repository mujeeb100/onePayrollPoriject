import { defaultSilce } from 'api'
import { payrollService } from 'api/api'

export const payItemGroupslice = defaultSilce(payrollService, 'payItemGroup', ['PayItemGroup'])

// pay item group
export const {
  useGetAllPayItemGroupQuery,
  useLazyGetPayItemGroupByIdQuery,
  usePayItemGroupDeleteMutation,
  usePayItemGroupCreateMutation,
  useLazyGetAllPayItemGroupQuery,
  usePayItemGroupUpdateMutation,
} = defaultSilce(payrollService, 'payItemGroup', ['PayItemGroup'])

// pay group

// pay item group
export const {
  useGetAllPayGroupQuery,
  useLazyGetPayGroupByIdQuery,
  usePayGroupDeleteMutation,
  usePayGroupCreateMutation,
  useLazyGetAllPayGroupQuery,
  usePayGroupUpdateMutation,
} = defaultSilce(payrollService, 'payGroup', ['PayGroup'])

export const {
  useGetAllPayGroupDropDownQuery,
  useLazyGetPayGroupDropDownByIdQuery,
} = defaultSilce(payrollService, 'payGroupDropDown', ['PayGroup'])
// PayItemMaster slice
export const {
  useGetAllPayItemMasterQuery,
  useLazyGetPayItemMasterByIdQuery,
  usePayItemMasterDeleteMutation,
  usePayItemMasterCreateMutation,
  useLazyGetAllPayItemMasterQuery,
  usePayItemMasterUpdateMutation,
} = defaultSilce(payrollService, 'payItemMaster', ['PayItemMaster'])

export const {
  useGetAllPensionFundSchemeItemPayItemQuery,
  useLazyGetPensionFundSchemeItemPayItemByIdQuery,
  usePensionFundSchemeItemPayItemUpdateMutation,
  usePensionFundSchemeItemPayItemDeleteMutation,
  usePensionFundSchemeItemPayItemCreateMutation,

} = defaultSilce(payrollService, 'pensionFundSchemeItemPayItem', ['PayItemMaster'])

export const {
  useGetAllFormulaSetupQuery,
  useLazyGetFormulaSetupByIdQuery,
  useFormulaSetupDeleteMutation,
  useFormulaSetupCreateMutation,
  useLazyGetAllFormulaSetupQuery,
  useFormulaSetupUpdateMutation,
} = defaultSilce(payrollService, 'formulaSetup', ['FormulaSetup'])

export const {
  useGetAllFormulaExpressionsQuery,
  useLazyGetFormulaExpressionsByIdQuery,
  useFormulaExpressionsDeleteMutation,
  useFormulaExpressionsCreateMutation,
  useLazyGetAllFormulaExpressionsQuery,
  useFormulaExpressionsUpdateMutation,
} = defaultSilce(payrollService, 'formulaExpressions', ['FormulaExpressions'])

// Terms

export const {
  useGetAllTermQuery,
  useLazyGetTermByIdQuery,
  useTermDeleteMutation,
  useTermCreateMutation,
  useLazyGetAllTermQuery,
  useTermUpdateMutation,
} = defaultSilce(payrollService, 'term', ['Term'])

export const {
  useGetAllTermDropDownQuery,
} = defaultSilce(payrollService, 'termDropDown', ['Term'])

export const {
  useGetAllPayItemMasterDropDownQuery,
  useLazyGetPayItemMasterDropDownByIdQuery,
} = defaultSilce(payrollService, 'payItemMasterDropDown', ['PayItemMaster'])
// pay roll non recurring slice
export const {
  useGetAllPayRollNonRecurringQuery,
  useLazyGetPayRollNonRecurringByIdQuery,
  usePayRollNonRecurringDeleteMutation,
  usePayRollNonRecurringCreateMutation,
  useLazyGetAllPayRollNonRecurringQuery,
  usePayRollNonRecurringUpdateMutation,
} = defaultSilce(payrollService, 'payRollNonRecurring', ['PayRollNonRecurring'])

// paycyle generation
export const {
  useGetAllPayCycleGenerationQuery,
  useLazyGetPayCycleGenerationByIdQuery,
  usePayCycleGenerationMutation,
  usePayCycleGenerationCreateMutation,
  useLazyGetAllPayCycleGenerationQuery,
  usePayCycleGenerationUpdateMutation,
} = defaultSilce(payrollService, 'payCycleGeneration', ['PayCycleGeneration'])

export const {
  useGetAllPayCycleGenerationDropDownQuery,
  useLazyGetPayCycleGenerationDropDownByIdQuery,
} = defaultSilce(payrollService, 'payCycleGenerationDropDown', ['PayCycleGeneration'])

// payroll non rucurring dropdown
export const {
  useGetAllPayRollNonRecurringDropDownQuery,
  useLazyGetPayRollNonRecurringDropDownByIdQuery,
} = defaultSilce(payrollService, 'payRollNonRecurringDropDown', ['PayRollNonRecurring'])

// payroll cycle
export const {
  useGetAllPayrollCycleQuery,
  useLazyGetPayrollCycleByIdQuery,
  usePayrollCycleDeleteMutation,
  usePayrollCycleCreateMutation,
  useLazyGetAllPayrollCycleQuery,
  usePayrollCycleUpdateMutation,
} = defaultSilce(payrollService, 'payrollCycle', ['PayrollCycle'])

// paycycle admin Unfinalized
export const {
  usePayCycleAdministrationUnfinalizedUpdateMutation,
} = defaultSilce(payrollService, 'payCycleAdministrationUnfinalized', ['PayCycleAdministration'])
// Finalized
export const {
  usePayCycleAdministrationFinalizedUpdateMutation,
} = defaultSilce(payrollService, 'payCycleAdministrationFinalized', ['PayCycleAdministration'])
// Open
export const {
  usePayCycleAdministrationOpenUpdateMutation,
} = defaultSilce(payrollService, 'payCycleAdministrationOpen', ['PayCycleAdministration'])
// Locked
export const {
  usePayCycleAdministrationLockedUpdateMutation,
} = defaultSilce(payrollService, 'payCycleAdministrationLocked', ['PayCycleAdministration'])
// Unlocked
export const {
  usePayCycleAdministrationUnlockedUpdateMutation,
} = defaultSilce(payrollService, 'payCycleAdministrationUnlocked', ['PayCycleAdministration'])
// DeactivateBatchAction
export const {
  usePayCycleAdministrationDeactivateUpdateMutation,
} = defaultSilce(payrollService, 'payCycleAdministrationDeactivate', ['PayCycleAdministration'])
// DropBatchAction
export const {
  usePayCycleAdministrationDropUpdateMutation,
} = defaultSilce(payrollService, 'payCycleAdministrationDrop', ['PayCycleAdministration'])
// payCycleMasterDropDowns
export const {
  useGetAllPayCycleMasterDropDownQuery,
  useLazyGetPayCycleMasterDropDownByIdQuery,
} = defaultSilce(payrollService, 'payCycleMasterDropDown', ['PayCycleMaster'])

export const {
  useGetAllPayCycleOptionsQuery,
} = defaultSilce(payrollService, 'payCycleOptions', ['PayCycleMaster'])

// createPayrollMonthEndClosing
export const {
  usePayrollMonthEndClosingCreateMutation,
} = defaultSilce(payrollService, 'PayrollMonthEndClosing', ['MonthEndClosing'])

// paycyle generation
export const {
  useRunPayrollCreateMutation,
} = defaultSilce(payrollService, 'runPayroll', ['RunPayroll'])

// export calculation
export const {
  useGetAllExportCalcQuery,
} = defaultSilce(payrollService, 'exportCalc', ['RunPayroll'])

// download log run
export const {
  useGetAllDownloadRunLogQuery,
} = defaultSilce(payrollService, 'downloadRunLog', ['RunPayroll'])

// canbesubmitted
export const {
  useCanBeSubmittedUpdateMutation,
  useLazyGetAllCanBeSubmittedQuery,
  useCanBeSubmittedChangeStatusMutation,
  useCanBeSubmittedCreateMutation,
  useGetAllCanBeSubmittedQuery,
  useCanBeSubmittedDeleteMutation,

} = defaultSilce(payrollService, 'canBeSubmitted', ['RunPayroll'])

// payroll cycle download file
export const {
  useGetAllLogDownloadQuery,

} = defaultSilce(payrollService, 'logDownload', ['PayCycleMaster'])

export const {
  useGetAllPayCycleMasterLogsQuery,
  useLazyGetPayCycleMasterLogsByIdQuery,
} = defaultSilce(payrollService, 'payCycleMasterLogs', ['PayCycleMaster'])

// monthEndClosingList
export const {
  useGetAllMonthEndClosingQuery,
  // useLazyGetAllMonthEndClosingQuery,
  // useLazyGetAllPayrollCycleQuery,
  useLazyGetMonthEndClosingListByIdQuery,
} = defaultSilce(payrollService, 'monthEndClosing', ['MonthEndClosing'])

// payroll history Logs
export const {
  useGetAllLogPayrollHistoryQuery,
} = defaultSilce(payrollService, 'logPayrollHistory', ['PayrollHistoryUpload'])

// payroll log data

export const {
  usePayrollHistoryCreateMutation,
  usePayrollHistoryDelete2Mutation,
} = defaultSilce(payrollService, 'payrollHistory', ['PayrollHistoryUpload'])
// download payroll history
export const {
  useGetAllPayrollHistoryLogQuery,
} = defaultSilce(payrollService, 'payrollHistoryLog', ['PayrollHistoryUpload'])

// deletePayrollNonRecurringBulk
export const {
  usePayRollBulkNonRecurringDeleteMutation,
  usePayRollBulkNonRecurringDelete2Mutation,
} = defaultSilce(payrollService, 'PayRollBulkNonRecurring', ['PayRollNonRecurring'])
// console.log(defaultSilce(payrollService, 'PayRollBulkNonRecurring', ['PayRollNonRecurring']), 'payrollnoo')

// payRollNonRecurringLogsList
// export const {
//   useGetAllPayRollNonRecurringLogsQuery,
// } = defaultSilce(payrollService, 'payRollNonRecurringLogs', ['PayRollNonRecurring'])
// paycycle reassignment
export const {
  useGetAllPayCycleReassignmentQuery,
  useLazyGetPayCycleReassignmentByIdQuery,
  usePayCycleReassignmentDeleteMutation,
  usePayCycleReassignmentCreateMutation,
  useLazyGetAllPayCycleReassignmentQuery,
  usePayCycleReassignmentUpdateMutation,
} = defaultSilce(payrollService, 'payCycleReassignment', ['PayCycleReassignment'])

// payRollNonRecurringListSearch
export const {
  useGetAllPayRollNonRecurringSearchQuery,
} = defaultSilce(payrollService, 'payRollNonRecurringSearch', ['PayRollNonRecurring'])

// create  post payrollnonRecurring
export const {
  usePayRollNonRecurringSearchCreateMutation,
} = defaultSilce(payrollService, 'payRollNonRecurring', ['PayRollNonRecurring'])

// postRequestPaycycleMaster useGet All Payroll Cycle Query
export const {
  // useGetAllPayrollCycleQuery,
  usePayCycleMasterSearchFilterCreateMutation,
} = defaultSilce(payrollService, 'payCycleMasterSearchFilter', ['PayCycleMaster'])
// usePayrollCycleCreateMutation

export const {
  useGetAllPayCycleMasterQuery,
} = defaultSilce(payrollService, 'payCycleMaster', ['PayCycleMaster'])

export const {
  useFilteredEmployeesCreateMutation,
} = defaultSilce(payrollService, 'filteredEmployees', ['RunPayroll'])
