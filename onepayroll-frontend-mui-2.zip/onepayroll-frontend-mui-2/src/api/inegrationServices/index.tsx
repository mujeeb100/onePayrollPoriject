import { defaultSilce } from 'api'
import { integrationService } from 'api/api'

export const {
  useGetAllUploadDataQuery,
  useLazyGetUploadDataByIdQuery,
  useUploadDataDeleteMutation,
  useUploadDataCreateMutation,
  useLazyGetAllUploadDataQuery,
  useUploadDataUpdateMutation,
} = defaultSilce(integrationService, 'uploadData', ['UploadData'])

export const {
  useGetAllSunshineQuery,
  useLazyGetSunshineByIdQuery,
  useSunshineDeleteMutation,
  useSunshineCreateMutation,
  useLazyGetAllSunshineQuery,
  useSunshineUpdateMutation,
} = defaultSilce(integrationService, 'sunshine', ['Sunshine'])
