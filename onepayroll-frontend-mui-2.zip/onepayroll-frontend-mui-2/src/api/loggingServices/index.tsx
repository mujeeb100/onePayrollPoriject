import { defaultSilce } from 'api'
import { loggingService } from 'api/api'

export const {
  useGetAllPayRollNonRecurringLogsQuery,
} = defaultSilce(loggingService, 'payRollNonRecurringLogs', ['PayRollNonRecurring'])

// month end closing logs
export const {
  useGetAllMonthEndClosingLogsQuery,
} = defaultSilce(loggingService, 'monthEndClosingLogs', ['MonthEndClosing'])

// logs
export const {
  useGetAllViewLogsQuery,
} = defaultSilce(loggingService, 'viewLogs', ['ViewLogs'])

// send Email logs list
export const {
  useGetAllSendEmailLogsQuery,
} = defaultSilce(loggingService, 'sendEmailLogs', ['SendEmail'])

// payroll run logs list
export const {
  useGetAllPayrollRunLogsQuery,
} = defaultSilce(loggingService, 'payrollRunLogs', ['PayrollRun'])

// publish report logs list
export const {
  useGetAllPublishReportLogsQuery,
} = defaultSilce(loggingService, 'publishReportLogs', ['PublishReport'])
