import { defaultSilce } from 'api'
import { reportsService } from 'api/api'

// pay item group
export const {
  useGetAllReportGroupQuery,
  useLazyGetReportGroupByIdQuery,
  useReportGroupDeleteMutation,
  useReportGroupCreateMutation,
  useLazyGetAllReportGroupQuery,
  useReportGroupUpdateMutation,
} = defaultSilce(reportsService, 'reportGroup', ['ReportGroup'])

// Audit Report
export const {
  useGetAllAuditReportQuery,
  useLazyGetAuditReportByIdQuery,
  useAuditReportDeleteMutation,
  useAuditReportCreateMutation,
  useLazyGetAllAuditReportQuery,
  useAuditReportUpdateMutation,
} = defaultSilce(reportsService, 'auditReport', ['AuditReport'])
// docuTax pro reporting
export const {
  useGetAllDocuTaxProReportingQuery,
  useLazyGetDocuTaxProReportingByIdQuery,
  useDocuTaxProReportingDeleteMutation,
  useDocuTaxProReportingCreateMutation,
  useLazyGetAllDocuTaxProReportingQuery,
  useDocuTaxProReportingUpdateMutation,
} = defaultSilce(reportsService, 'docuTaxProReporting', ['DocuTaxPro'])

export const {
  useGetAllPublishReportQuery,
  useLazyGetPublishReportByIdQuery,
  usePublishReportDeleteMutation,
  usePublishReportCreateMutation,
  useLazyGetAllPublishReportQuery,
  usePublishReportUpdateMutation,
} = defaultSilce(reportsService, 'publishReport', ['PublishReport'])
// Review Report
export const {
  useGetAllReviewReportQuery,
  useReviewReportCreateMutation,
} = defaultSilce(reportsService, 'reviewReport', ['ReportGroup'])

// Review Report Logs
export const {
  useGetAllReviewReportLogsFileQuery,
} = defaultSilce(reportsService, 'reviewReportLogsFile', ['ReportGroup'])

// Review Report View
export const {
  useGetAllReviewReportViewQuery,
} = defaultSilce(reportsService, 'reviewReportView', ['ReportGroup'])

// Export review report
export const {
  useReviewReportExportCreateMutation,
} = defaultSilce(reportsService, 'reviewReportExport', ['ReportGroup'])

export const {
  useGetAllGeneratePayrollSlipQuery,
  useLazyGetGeneratePayrollSlipByIdQuery,
  useGeneratePayrollSlipDeleteMutation,
  useGeneratePayrollSlipCreateMutation,
  useLazyGetAllGeneratePayrollSlipQuery,
  useGeneratePayrollSlipUpdateMutation,
} = defaultSilce(reportsService, 'generatePayrollSlip', ['GeneratePayrollSlip'])
// publish Report logs
