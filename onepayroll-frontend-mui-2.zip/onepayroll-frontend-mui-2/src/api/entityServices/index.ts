import { defaultSilce } from 'api'
import { entityService } from 'api/api'

// export const entitySlice = defaultSilce(globalService, 'country', ['Country'])
export const IRDSlice = defaultSilce(entityService, 'IRD', ['IRD'])
export const departmentSlice = defaultSilce(entityService, 'department', ['Department'])
export const costCenterSlice = defaultSilce(entityService, 'costCenter', ['CostCenter'])
export const divisionSlice = defaultSilce(entityService, 'division', ['Diviision'])
export const regionSlice = defaultSilce(entityService, 'region', ['Region'])
export const teamSlice = defaultSilce(entityService, 'team', ['Team'])
export const serviceProviderSlice = defaultSilce(entityService, 'serviceProvider', ['ServiceProvider'])
export const pensionFundSchemeItemSlice = defaultSilce(entityService, 'pensionFundSchemeItem', ['PensionFundSchemeItem'])
export const positionSlice = defaultSilce(entityService, 'position', ['Position'])
export const companyBankAccountSlice = defaultSilce(entityService, 'companyBankAccount', ['CompanyBankAccount'])
export const settingsSlice = defaultSilce(entityService, 'settings', ['Settings'])
export const currencyExchangeSlice = defaultSilce(entityService, 'currencyExchange', ['CurrencyExchange'])
export const pensionFundSchemeSlice = defaultSilce(entityService, 'pensionFundScheme', ['PensionFundScheme'])
export const pensionFundSchemeRuleSlice = defaultSilce(entityService, 'pensionFundSchemeRule', ['PensionFundSchemeRule'])
export const gradeSlice = defaultSilce(entityService, 'grade', ['Grade'])
export const workCalenderSlice = defaultSilce(entityService, 'workCalender', ['WorkCalender'])
export const staffTypeSlice = defaultSilce(entityService, 'staffType', ['StaffType'])
export const employeeMovementTypeSlice = defaultSilce(entityService, 'employeeMovementType', ['EmployeeMovementType'])
export const employeeMovementConfigurationSlice = defaultSilce(entityService, 'employeeMovementConfiguration', ['EmployeeMovementConfiguration'])
export const entityProfileSlice = defaultSilce(entityService, 'entityProfile', ['EntityProfile'])

// cost center slice
export const {
  useGetAllCostCenterQuery,
  useLazyGetCostCenterByIdQuery,
  useCostCenterDeleteMutation,
  useCostCenterCreateMutation,
  useLazyGetAllCostCenterQuery,
  useCostCenterUpdateMutation,
} = defaultSilce(entityService, 'costCenter', ['CostCenter'])

// division slice
export const {
  useGetAllDivisionQuery,
  useLazyGetDivisionByIdQuery,
  useDivisionDeleteMutation,
  useDivisionCreateMutation,
  useLazyGetAllDivisionQuery,
  useDivisionUpdateMutation,
} = defaultSilce(entityService, 'division', ['Division'])
// region slice
export const {
  useGetAllRegionQuery,
  useLazyGetRegionByIdQuery,
  useRegionDeleteMutation,
  useRegionCreateMutation,
  useLazyGetAllRegionQuery,
  useRegionUpdateMutation,
} = defaultSilce(entityService, 'region', ['Region'])
// team slice
export const {
  useGetAllTeamQuery,
  useLazyGetTeamByIdQuery,
  useTeamDeleteMutation,
  useTeamCreateMutation,
  useLazyGetAllTeamQuery,
  useTeamUpdateMutation,
} = defaultSilce(entityService, 'team', ['Team'])
// IRD slice
export const {
  useGetAllIRDQuery,
  useLazyGetIRDByIdQuery,
  useIRDDeleteMutation,
  useIRDCreateMutation,
  useLazyGetAllIRDQuery,
  useIRDUpdateMutation,
} = defaultSilce(entityService, 'ird', ['IRD'])
// department slice
export const {
  useGetAllDepartmentQuery,
  useLazyGetDepartmentByIdQuery,
  useDepartmentDeleteMutation,
  useDepartmentCreateMutation,
  useLazyGetAllDepartmentQuery,
  useDepartmentUpdateMutation,
} = defaultSilce(entityService, 'department', ['Department'])
// position slice
export const {
  useGetAllPositionQuery,
  useLazyGetPositionByIdQuery,
  usePositionDeleteMutation,
  usePositionCreateMutation,
  useLazyGetAllPositionQuery,
  usePositionUpdateMutation,
} = defaultSilce(entityService, 'position', ['Position'])
// Grade slice
export const {
  useGetAllGradeQuery,
  useLazyGetGradeByIdQuery,
  useGradeDeleteMutation,
  useGradeCreateMutation,
  useLazyGetAllGradeQuery,
  useGradeUpdateMutation,
} = defaultSilce(entityService, 'grade', ['Grade'])
// StaffType slice
export const {
  useGetAllStaffTypeQuery,
  useLazyGetStaffTypeByIdQuery,
  useStaffTypeDeleteMutation,
  useStaffTypeCreateMutation,
  useLazyGetAllStaffTypeQuery,
  useStaffTypeUpdateMutation,
} = defaultSilce(entityService, 'staffType', ['StaffType'])
// termination code
export const {
  useGetAllTerminationCodeQuery,
  useLazyGetTerminationCodeByIdQuery,
  useTerminationCodeDeleteMutation,
  useTerminationCodeCreateMutation,
  useLazyGetAllTerminationCodeQuery,
  useTerminationCodeUpdateMutation,
} = defaultSilce(entityService, 'terminationCode', ['TerminationCode'])
// service provider Slice
export const {
  useGetAllServiceProviderQuery,
  useLazyGetServiceProviderByIdQuery,
  useServiceProviderDeleteMutation,
  useServiceProviderCreateMutation,
  useLazyGetAllServiceProviderQuery,
  useServiceProviderUpdateMutation,
} = defaultSilce(entityService, 'serviceProvider', ['ServiceProvider'])

// Entity settings slice
export const {
  useGetAllSettingsQuery,
  useLazyGetSettingsByIdQuery,
  useSettingsDeleteMutation,
  useSettingsCreateMutation,
  useLazyGetAllSettingsQuery,
  useSettingsUpdateMutation,
} = defaultSilce(entityService, 'settings', ['Settings'])

// currency exchange slice
export const {
  useGetAllCurrencyExchangeQuery,
  useLazyGetCurrencyExchangeByIdQuery,
  useCurrencyExchangeDeleteMutation,
  useCurrencyExchangeCreateMutation,
  useLazyGetAllCurrencyExchangeQuery,
  useCurrencyExchangeUpdateMutation,
} = defaultSilce(entityService, 'currencyExchange', ['CurrencyExchange'])
// EmpMovementType slice
export const {
  useGetAllEmployeeMovementQuery,
  useLazyGetEmployeeMovementByIdQuery,
  useEmployeeMovementDeleteMutation,
  useEmployeeMovementCreateMutation,
  useLazyGetAllEmployeeMovementQuery,
  useEmployeeMovementUpdateMutation,
} = defaultSilce(entityService, 'employeeMovement', ['EmployeeMovement'])
// entity PensionFundSchemeItem slice
export const {
  useGetAllPensionFundSchemeItemQuery,
  useLazyGetPensionFundSchemeItemByIdQuery,
  usePensionFundSchemeItemDeleteMutation,
  usePensionFundSchemeItemCreateMutation,
  useLazyGetAllPensionFundSchemeItemQuery,
  usePensionFundSchemeItemUpdateMutation,
} = defaultSilce(entityService, 'pensionFundSchemeItem', ['PensionFundSchemeItem'])
// entity PensionFundScheme slice
export const {
  useGetAllPensionFundSchemeQuery,
  useLazyGetPensionFundSchemeByIdQuery,
  usePensionFundSchemeDeleteMutation,
  usePensionFundSchemeCreateMutation,
  useLazyGetAllPensionFundSchemeQuery,
  usePensionFundSchemeUpdateMutation,
} = defaultSilce(entityService, 'pensionFundScheme', ['PensionFundScheme'])

// entity employee movement configuration
export const {
  useGetAllEmployeeMovementConfigurationQuery,
  useLazyGetEmployeeMovementConfigurationByIdQuery,
  useEmployeeMovementConfigurationDeleteMutation,
  useEmployeeMovementConfigurationCreateMutation,
  useLazyGetAllEmployeeMovementConfigurationQuery,
  useEmployeeMovementConfigurationUpdateMutation,
} = defaultSilce(entityService, 'employeeMovementConfiguration', ['EmployeeMovementConfiguration'])

// entity work calender
export const {
  useGetAllWorkCalenderQuery,
  useLazyGetWorkCalenderByIdQuery,
  useWorkCalenderDeleteMutation,
  useWorkCalenderCreateMutation,
  useLazyGetAllWorkCalenderQuery,
  useWorkCalenderUpdateMutation,
} = defaultSilce(entityService, 'workCalender', ['WorkCalendar'])
// entity PensionFundSchemeRule slice
export const {
  useGetAllPensionFundSchemeRuleQuery,
  useLazyGetPensionFundSchemeRuleByIdQuery,
  usePensionFundSchemeRuleDeleteMutation,
  usePensionFundSchemeRuleCreateMutation,
  useLazyGetAllPensionFundSchemeRuleQuery,
  usePensionFundSchemeRuleUpdateMutation,
} = defaultSilce(entityService, 'pensionFundSchemeRule', ['PensionFundSchemeRule'])
// entity Company bank account
export const {
  useGetAllCompanyBankAccountQuery,
  useLazyGetCompanyBankAccountByIdQuery,
  useCompanyBankAccountDeleteMutation,
  useCompanyBankAccountCreateMutation,
  useLazyGetAllCompanyBankAccountQuery,
  useCompanyBankAccountUpdateMutation,
} = defaultSilce(entityService, 'companyBankAccount', ['PensionFundSchemeRule'])

// entity profile
export const {
  useGetAllEntityProfileQuery,
  useLazyGetEntityProfileByIdQuery,
  useEntityProfileDeleteMutation,
  useEntityProfileCreateMutation,
  useLazyGetAllEntityProfileQuery,
  useEntityProfileUpdateMutation,
} = defaultSilce(entityService, 'entityProfile', ['EntityProfile'])

// entity profile change status
export const {
  useGetAllEntityChangeProfileQuery,
} = defaultSilce(entityService, 'entityChangeProfile', ['EntityProfile'])

// entityProfileSelectedListById
export const {
  useGetAllEntityProfileSelectedListByIdQuery,
} = defaultSilce(entityService, 'entityProfileSelectedListById', ['EntityProfile'])

// company bank account view by id
// export const {
//   useLazyGetCompanyBankAcctByIdQuery,
// } = defaultSilce(entityService, 'companyBankAcct', ['EntityProfile'])
