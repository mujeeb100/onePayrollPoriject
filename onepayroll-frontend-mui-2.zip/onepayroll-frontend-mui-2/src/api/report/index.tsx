import { defaultSilce } from 'api'
import { reportsService } from 'api/api'
// custom report designer slice
export const {
  useGetAllCustomReportDesignerQuery,
  useLazyGetCustomReportDesignerByIdQuery,
  useCustomReportDesignerDeleteMutation,
  useCustomReportDesignerCreateMutation,
  useLazyGetAllCustomReportDesignerQuery,
  useCustomReportDesignerUpdateMutation,
} = defaultSilce(reportsService, 'customReportDesigner', ['CustomReportDesigner'])
