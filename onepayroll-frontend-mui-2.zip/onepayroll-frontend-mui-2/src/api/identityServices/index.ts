import { defaultSilce } from 'api'
import { identityService } from 'api/api'

export const {
  useGetAllUserAdministrationQuery,
  useLazyGetUserAdministrationByIdQuery,
  useUserAdministrationDeleteMutation,
  useUserAdministrationCreateMutation,
  useLazyGetAllUserAdministrationQuery,
  useUserAdministrationUpdateMutation,
} = defaultSilce(identityService, 'userAdministration', ['UserAdministration'])

export const {
  useGetAllUserClientGroupQuery,
} = defaultSilce(identityService, 'userClientGroup', ['UserAdministration'])

export const {
  useGetAllUserRolePermissionQuery,
  useLazyGetUserRolePermissionByIdQuery,
  useUserRolePermissionDeleteMutation,
  useUserRolePermissionCreateMutation,
  useLazyGetAllUserRolePermissionQuery,
  useUserRolePermissionUpdateMutation,
} = defaultSilce(identityService, 'userRolePermission', ['UserRolePermission'])

export const {
  useGetAllUserRolePermissionChangeQuery,
} = defaultSilce(identityService, 'userRolePermissionChange', ['UserRolePermissionChange'])

export const {
  useGetAllUserRoleEntityQuery,
} = defaultSilce(identityService, 'userRoleEntity', ['UserRoleEntity'])

export const {
  useGetAllUserRoleQuery,
  useLazyGetUserRoleByIdQuery,
  useUserRoleDeleteMutation,
  useUserRoleCreateMutation,
  useLazyGetAllUserRoleQuery,
  useUserRoleUpdateMutation,
  util,
} = defaultSilce(identityService, 'userRole', ['UserRole'])
// console.log(defaultSilce(identityService, 'userRole', ['UserRole']).util.invalidateTags('UserRole'), 'dddddddddddddd')
export const {
  useGetAllUserRolesPermissionQuery,
  useLazyGetUserRolesPermissionByIdQuery,
  useUserRolesPermissionDeleteMutation,
  useUserRolesPermissionCreateMutation,
  useLazyGetAllUserRolesPermissionQuery,
  useUserRolesPermissionUpdateMutation,
} = defaultSilce(identityService, 'userRolesPermission', ['UserRolesPermission'])
export const {
  useGetAllUserAdminEntityQuery,
  useLazyGetUserAdminEntityByIdQuery,
  useUserAdminEntityDeleteMutation,
  useUserAdminEntityCreateMutation,
  useLazyGetAllUserAdminEntityQuery,
  useUserAdminEntityUpdateMutation,
} = defaultSilce(identityService, 'userAdminEntity', ['UserAdminEntity'])
// UserClientGroupById
// useGetAllUserClientGroupQuery
export const {
  useGetAllUsersWithRoleQuery,
} = defaultSilce(identityService, 'usersWithRole', ['UserAdministration'])
