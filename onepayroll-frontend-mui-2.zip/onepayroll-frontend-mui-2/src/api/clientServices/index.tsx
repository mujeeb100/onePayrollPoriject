import { defaultSilce } from 'api'
import { globalService } from 'api/api'

export const {
  useGetAllClientGroupProfileQuery,
  useLazyGetClientGroupProfileByIdQuery,
  useClientGroupProfileDeleteMutation,
  useClientGroupProfileCreateMutation,
  useLazyGetAllClientGroupProfileQuery,
  useClientGroupProfileUpdateMutation,
  useClientGroupProfileChangeStatusMutation,
} = defaultSilce(globalService, 'clientGroupProfile', ['ClientGroupProfile'])

export const {
  useGetAllClientGroupEntitiesQuery,
  useLazyGetClientGroupEntitiesByIdQuery,
  useClientGroupEntitiesDeleteMutation,
  useClientGroupEntitiesCreateMutation,
  useLazyGetAllClientEntitiesProfileQuery,
  useClientGroupEntitiesUpdateMutation,
  useClientGroupEntitiesChangeStatusMutation,
} = defaultSilce(globalService, 'clientGroupEntities', ['ClientGroupEntities'])

export const {
  useGetAllClientProfileEntityQuery,
} = defaultSilce(globalService, 'clientProfileEntity', ['ClientProfileEntity'])
