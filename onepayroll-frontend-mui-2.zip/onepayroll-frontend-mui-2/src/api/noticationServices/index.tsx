import { defaultSilce } from 'api'
import { notificationService } from 'api/api'

export const {
  useGetAllEmailProfileQuery,
  useLazyGetEmailProfileByIdQuery,
  useEmailProfileDeleteMutation,
  useEmailProfileCreateMutation,
  useLazyGetAllEmailProfileQuery,
  useEmailProfileUpdateMutation,
} = defaultSilce(notificationService, 'emailProfile', ['EmailProfile'])

export const {
  useGetAllSendEmailProfileDropDownQuery,
  useLazyGetSendEmailProfileDropDownByIdQuery,
} = defaultSilce(notificationService, 'sendEmailProfileDropDown', ['EmailProfile'])

export const {
  useGetAllSendEmailQuery,
  useLazyGetSendEmailByIdQuery,
  useSendEmailDeleteMutation,
  useSendEmailCreateMutation,
  useLazyGetAllSendEmailQuery,
  useSendEmailUpdateMutation,
} = defaultSilce(notificationService, 'sendEmail', ['SendEmail'])

export const {
  useGetAllSendTestEmailQuery,
  useLazyGetSendTestEmailByIdQuery,
  useSendTestEmailDeleteMutation,
  useSendTestEmailCreateMutation,
  useLazyGetAllSendTestEmailQuery,
  useSendTestEmailUpdateMutation,
} = defaultSilce(notificationService, 'sendTestEmail', ['SendTestEmail'])

export const {
  useGetAllSendEmailDropDownQuery,
  useLazyGetSendEmailDropDownByIdQuery,
} = defaultSilce(notificationService, 'sendEmailDropDown', ['SendEmail'])

export const {
  useGetAllGetEmployeesQuery,
  useLazyGetGetEmployeesByIdQuery,
  useGetEmployeesDeleteMutation,
  useGetEmployeesCreateMutation,
  useLazyGetAllGetEmployeesQuery,
  useGetEmployeesUpdateMutation,
} = defaultSilce(notificationService, 'getEmployees', ['GetEmployees'])

export const {
  useGetAllEmailTemplateQuery,
  useLazyGetEmailTemplateByIdQuery,
  useEmailTemplateDeleteMutation,
  useEmailTemplateCreateMutation,
  useLazyGetAllEmailTemplateQuery,
  useEmailTemplateUpdateMutation,
} = defaultSilce(notificationService, 'emailTemplate', ['EmailTemplate'])

export const {
  useGetAllEmailTemplateDropDownQuery,
  useLazyGetEmailTemplateDropDownByIdQuery,
} = defaultSilce(notificationService, 'emailTemplateDropDown', ['EmailTemplate'])

// emailTmplateList
export const {
  useGetAllEmailTmplateQuery,
  useLazyGetEmailTmplateByIdQuery,
  useEmailTmplateDeleteMutation,
  useEmailTmplateCreateMutation,
  useLazyGetAllEmailTmplateQuery,
  useEmailTmplateUpdateMutation,
} = defaultSilce(notificationService, 'emailTmplate', ['EmailTemplate'])

// createSendEmailTemplate
export const {
  useSendEmailTemplateCreateMutation,
} = defaultSilce(notificationService, 'sendEmailTemplate', ['EmailTemplate'])

export const {
  useGetAllSendPaySlipQuery,
  useLazyGetSendPaySlipByIdQuery,
  useSendPaySlipDeleteMutation,
  useSendPaySlipCreateMutation,
  useLazyGetAllSendPaySlipQuery,
  useSendPaySlipUpdateMutation,
} = defaultSilce(notificationService, 'sendPaySlip', ['SendPaySlip'])

export const {
  useGetAllEmailTemplatePlaceHolderQuery,
} = defaultSilce(notificationService, 'emailTemplatePlaceHolder', ['EmailTemplate'])
