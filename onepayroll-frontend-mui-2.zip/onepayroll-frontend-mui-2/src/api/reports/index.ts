import { defaultSilce } from 'api'
import { payrollService, reportsService } from 'api/api'

// pay item group
export const {
  useGetAllStandardReportQuery,
  useLazyGetStandardReportByIdQuery,
  useStandardReportDeleteMutation,
  useStandardReportCreateMutation,
  useLazyGetAllStandardReportQuery,
  useStandardReportUpdateMutation,
} = defaultSilce(reportsService, 'standardReport', ['StandardReport'])

export const {
  useStandardReportDeleteCreateMutation,
} = defaultSilce(reportsService, 'standardReportDelete', ['StandardReport'])

// ARC report type

export const {
  useGetAllARCReportQuery,
  useLazyGetARCReportByIdQuery,
  useARCReportDeleteMutation,
  useARCReportCreateMutation,
  useLazyGetAllARCReportQuery,
  useARCReportUpdateMutation,
} = defaultSilce(reportsService, 'aRCReport', ['ARCReport'])

export const {
  useGetAllStandardReportGroupQuery,
} = defaultSilce(reportsService, 'standardReportGroup', ['StandardReport'])
// Generate Payroll slip
export const {
  useGetAllGeneratePayrollSlipQuery,
  useLazyGetGeneratePayrollSlipByIdQuery,
  useGeneratePayrollSlipDeleteMutation,
  useGeneratePayrollSlipCreateMutation,
  useLazyGetAllGeneratePayrollSlipQuery,
  useGeneratePayrollSlipUpdateMutation,
} = defaultSilce(reportsService, 'generatePayrollSlip', ['PayrollSlip'])
export const {
  useGetAllReportTypeQuery,

} = defaultSilce(reportsService, 'reportType', ['PayrollSlip'])

export const {
  useGetAllReportSlipModalQuery,
  useLazyGetReportSlipModalByIdQuery,

} = defaultSilce(reportsService, 'reportSlipModal', ['PayrollSlip'])
// auditTrailList report
export const {
  useGetAllAuditTrailReportQuery,
  useLazyGetAuditTrailReportByIdQuery,
  useAuditTrailReportDeleteMutation,
  useAuditTrailReportCreateMutation,
  useLazyGetAllAuditTrailReportQuery,
  useAuditTrailReportUpdateMutation,
} = defaultSilce(reportsService, 'auditTrailReport', ['AuditTrail'])

export const {
  usePaymentSummaryCreateMutation,

} = defaultSilce(reportsService, 'paymentSummary', ['PayrollSlip'])

// payroll cycle download file
export const {
  useGetAllReportDownloadQuery,
} = defaultSilce(payrollService, 'reportDownload', ['ReportGroup'])
