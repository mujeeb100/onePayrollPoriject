import { createApi } from '@reduxjs/toolkit/query/react'

import { wrappedDynamicBaseQuery } from './apiUtils'

export const entityService = createApi({
  reducerPath: 'entityService', // optional
  baseQuery: wrappedDynamicBaseQuery('entityService'),
  tagTypes: [
    'CurrencyExchange',
    'Department',
    'IRD',
    'PensionFundScheme',
    'PensionFundSchemeItem',
    'PensionFundSchemeRule',
    'Grade',
    'ServiceProvider',
    'Settings',
    'WorkCalendar',
    'EmployeeMovement',
    'EmployeeMovementConfiguration',
    'CompanyBankAccount',
    'EntityProfile',
    'TerminationCode',
    'Position',
    'StaffType',
  ],
  endpoints: (builder) => ({}),
})

export const globalService = createApi({
  reducerPath: 'globalService', // optional
  baseQuery: wrappedDynamicBaseQuery('globalService'),
  tagTypes: ['Country', 'Currency', 'Nationality', 'GlobalPensionFundSchemeRule',
    'HolidayCalender', 'HolidayCalenderDate', 'UserAdministration', 'ClientGroupProfile', 'ClientProfileEntity',
    'UserAdminEntity', 'SettingTemplate', 'UserRole', 'UserRoleEntity', 'UserRolePermission',
    'ClientGroupEntity', 'PaymentMethod', 'ProviderType', 'StandardExpression', 'StandardFormula', 'PensionFundTermination', 'HolidayDates'],
  endpoints: (builder) => ({}),
})

export const employeeService = createApi({
  reducerPath: 'employeeService', // optional
  baseQuery: wrappedDynamicBaseQuery('employeeService'),
  tagTypes: [
    'EmployeeBankAccount',
    'Person',
    'EmployeeProfile',
    'EmployeePensionFund',
    'EmployeePasword',
    'EmployeeQuarters',
    'UploadData',
    'DownloadedUploadedFileSlice',
    'EmpMovement',
    'EmployeeMovementAction',
    'EmployeeLeaveTransaction',
    'EmployeeRemarks',
  ],
  endpoints: (builder) => ({}),
})

export const payrollService = createApi({
  reducerPath: 'payrollService', // optional
  baseQuery: wrappedDynamicBaseQuery('payrollService'),
  tagTypes: [
    'PayGroup',
    'PayrollNonRecurring',
    'PayItemMaster',
    'PayItemGroup',
    'PayCycleMaster',
    'BatchDrop',
    'MonthEndClosing',
    'EmployeeRecurring',
    'PayCycleGenerate',
    'PayCycleAdministration',
    'PayCycleGenerate',
    'RunPayroll',
    'PayRollAverageWage',
    'FormulaSetup',
    'Term',
    'FormulaExpressions',
    'PayrollHistoryUpload',
    'PayCycleReassignment',
  ],
  endpoints: (builder) => ({}),
})

export const reportsService:any = createApi({
  reducerPath: 'reportsService', // optional
  baseQuery: wrappedDynamicBaseQuery('reportsService'),
  tagTypes: ['PayrollSlip', 'ReportDesigner', 'ReportGroup', 'DocuTaxPro', 'AuditTrail', 'AuditReport', 'PublishReport', 'GeneratePayrollSlip'],
  endpoints: (builder) => ({}),
})

export const identityService = createApi({
  reducerPath: 'identityService', // optional
  baseQuery: wrappedDynamicBaseQuery('identityService'),
  tagTypes: ['UserAdministration', 'UserAdminEntity', 'UserRole', 'UserRolePermission', 'UserRoleEntity', 'UserRolesPermission'],
  endpoints: (builder) => ({}),
})

export const integrationService = createApi({
  reducerPath: 'integrationService', // optional
  baseQuery: wrappedDynamicBaseQuery('integrationService'),
  tagTypes: ['uploadData', 'sunshine'],
  endpoints: (builder) => ({}),
})

export const notificationService = createApi({
  reducerPath: 'notificationService', // optional
  baseQuery: wrappedDynamicBaseQuery('notificationService'),
  tagTypes: ['emailProfile', 'sendEmail', 'getEmployees', 'emailTemplate', 'sendTestEmail', 'sendPaySlip'],
  endpoints: (builder) => ({}),
})
// logging service

export const loggingService = createApi({
  reducerPath: 'loggingService', // optional
  baseQuery: wrappedDynamicBaseQuery('loggingService'),
  tagTypes: ['PayRollNonRecurringLog',
    'MonthEndClosing',
    'ViewLogs',
    'SendEmail',
    'PayrollRun',
    'PublishReport'],
  endpoints: (builder) => ({}),
})

export const allApiSlices = {
  entityService,
  globalService,
  payrollService,
  employeeService,
  reportsService,
  loggingService,
  identityService,
  integrationService,
  notificationService,
}
