// import Routes from 'routes'
import '@fontsource/lato/100-italic.css'
import '@fontsource/lato/100.css'
import '@fontsource/lato/300-italic.css'
import '@fontsource/lato/300.css'
import '@fontsource/lato/400-italic.css'
import '@fontsource/lato/400.css'
import '@fontsource/lato/700-italic.css'
import '@fontsource/lato/700.css'
import '@fontsource/lato/900-italic.css'
import '@fontsource/lato/900.css'
import 'styles/global.css'

import { ThemeProvider } from '@emotion/react'
import { OktaAuth, toRelativeUrl } from '@okta/okta-auth-js'
import {
  LoginCallback,
  Security,
} from '@okta/okta-react'
import LandingPage from 'pages/landing'
import Login from 'pages/login/Login'
import { useState } from 'react'
import { useSelector } from 'react-redux'
import { Route, Routes, useNavigate } from 'react-router-dom'
import { selectLangSelector } from 'slices/select-lang-slice'
import { getDefaultLang } from 'utils'

import config from './config'
import { APIContextProvider } from './services/apiContext'
import customTheme from './themes/index'

const oktaAuth = new OktaAuth(config.oidc)

function App() {
  const [mode, setMode] = useState(true)
  const navigate = useNavigate()
  const language = useSelector(selectLangSelector)

  if (language && language.selectedLang) {
    getDefaultLang(language.selectedLang)
  }

  const customAuthHandler = () => {
    navigate('/login')
  }

  const restoreOriginalUri = async (_oktaAuth: any, originalUri: any) => {
    navigate(toRelativeUrl(originalUri || '', window.location.origin))
  }
  // getDefaultLang(langSelector.selectedLang)
  const url: any = process.env.REACT_APP_UP_BASE_URL || ''

  return (
    <ThemeProvider theme={customTheme}>
      <Security
        oktaAuth={oktaAuth}
        restoreOriginalUri={restoreOriginalUri}
        onAuthRequired={customAuthHandler}
      >
        <APIContextProvider>
          <Routes>
            <Route
              element={<LandingPage />}
              path="/*"
            />
            <Route
              element={<Login />}
              path="/login"
            />
            <Route element={<LoginCallback />} path="/login/callback" />
          </Routes>
        </APIContextProvider>
      </Security>
    </ThemeProvider>
  )
}

export default App
