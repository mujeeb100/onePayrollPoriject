export interface OPRSwipeableDrawerProps {
  anchor: 'top' | 'right' | 'bottom' | 'left'
  open: boolean
  onClose: () => void
  onOpen: () => void
  children: React.ReactNode
  openPosition: number
  width: number
  onMouseLeave?: () => void
  onMouseOverCapture?: () => void
  constainerWidth: number
  sx?: any
}
