import { CheckboxProps, StepperProps, SxProps } from '@mui/material'

export interface IOPRCheckbox extends CheckboxProps{
  label: string
  onChange: (event: React.ChangeEvent<HTMLInputElement>) => void
  checked: boolean
  indeterminate?: boolean
}

export interface IOPRStepperProps extends StepperProps{
  steps: string[];
  alternativeLabel?: boolean
  activeStep: number
}

export type IOPRMultiSelectCheckboxSXProps = SxProps & {
  formSx?: SxProps
}
export interface IOPRMultiSelectCheckboxProps {
  selectedOptions: any[]
  setSelectedOptions: React.Dispatch<React.SetStateAction<any[]>>
  listOfOptions: any[]
  renderValue: (selected: any[]) => React.ReactNode
  value?: number | string;
  onChange?: (item: any) => void;
  disabled?: boolean;
  name?: string;
  isRequired?: boolean;
  max?: number;
  placeholder?: string;
  type?: string;
  maxLength?: number;
  error?: string;
  min?: number
  color?:any;
  label?: string;
  isEditable?: boolean;
  fullWidth?: boolean;
  multiline?: boolean;
  rows?: number;
  optionalText?: string; // New prop for optional text
  sx?: IOPRMultiSelectCheckboxSXProps,
  isSearch?:boolean
}
