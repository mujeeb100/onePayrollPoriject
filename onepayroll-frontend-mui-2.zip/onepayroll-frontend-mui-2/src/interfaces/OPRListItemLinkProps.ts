import { ListItemProps, SxProps } from '@mui/material'

export interface OPRListItemLinkProps extends ListItemProps {
  icon?: React.ReactElement
  primary: string
  to: string
  onClick?: () => void
  hasChild?: boolean
  sx?: SxProps
  open?: boolean
}
