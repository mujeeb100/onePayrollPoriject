const CLIENT_ID = process.env.REACT_APP_CLIENT_ID
const CALLBACK_PATH = process.env.REACT_APP_CALLBACK_PATH
const ISSUER = process.env.REACT_APP_ISSUER
const REDIRECT_URI = `${window.location.origin}/login/callback`
const SCOPES = process.env.REACT_APP_SCOPES

if (!SCOPES || !CLIENT_ID || !CALLBACK_PATH || !ISSUER) {
  throw new Error('All environmental variables must be set')
}

export default {
  oidc: {
    issuer: ISSUER,
    clientId: CLIENT_ID,
    scopes: ['openid', 'profile', 'email', 'offline_access'],
    redirectUri: REDIRECT_URI,
  },
  widget: {
    issuer: ISSUER,
    clientId: CLIENT_ID,
    redirectUri: REDIRECT_URI,
    scopes: ['openid', 'profile', 'email', 'offline_access'],
  },
}
