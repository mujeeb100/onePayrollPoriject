import bkEndValidEn from 'assets/locales/Backend_validation_msgs/en.json'
import bkEndValidZh from 'assets/locales/Backend_validation_msgs/zh-Hans-CN.json'
import uiLabelsEn from 'assets/locales/UI_Label/en.json'
import uiLabelsZh from 'assets/locales/UI_Label/zh-Hans-CN.json'
import i18n from 'i18next'
import { initReactI18next } from 'react-i18next'
// Need translation in zh when we import from locales

const i18nConfig = (defaultLang: string) => {
  const resources = {
    en: {
      translation: {
        ...bkEndValidEn,
        ...uiLabelsEn,
      },
    },
    zh: {
      translation: {
        ...bkEndValidZh,
        ...uiLabelsZh,
      },
    },
  }

  return i18n.use(initReactI18next).init({
    resources,
    lng: defaultLang, // For making changes in default language
    interpolation: {
      escapeValue: false, // not needed for react as it escapes by default
    },
  })
}

export default i18nConfig
