import { useState } from 'react'

export const useModal = () => {
  const [isToggele, setIsShown] = useState<boolean>(false)
  const toggle = () => setIsShown(!isToggele)
  return {
    isToggele,
    toggle,
  }
}
