import { useState } from 'react'

const useForm = (schema:any) => {
  // Form values
  const [values, setValues]: any = useState({})
  // Errors
  const [errors, setErrors]:any = useState({})
  const [isValidating, setIsValidating] = useState(false)
  const validateYup = async (schema: any, data: any, name:any) => {
    if (!isValidating) setIsValidating(true)
    schema
      .validate(data, { abortEarly: false })
      .then(() => {
        setErrors({})
        // successCallback(values)
      })
      .catch(async (err:any) => {
        if (err.name === 'ValidationError') {
          const errs = await schema.validate(data, { abortEarly: false }).catch((err:any) => {
            const errors = err.inner.flatMap((e:any) => ({ [e.path]: e.errors[0] })).reduce((result:any, current:any) => Object.assign(result, current), {})
            return errors[name]
          // Update form errors state:
          })

          setErrors({ ...errors, [name]: errs })
        }
      })
  }
  const handleChange: any = (event: any) => {
    event.persist()
    const { name, value } = event.target
    const rowData = { ...values, [name]: value }
    validateYup(schema, rowData, name)
    setValues({
      ...values,
      [name]: value,
    })
  }

  const handleOnChange = (name:any, value:any) => {
    const rowData = { ...values, [name]: value }

    validateYup(schema, rowData, name)
    setValues({
      ...values,
      [name]: value,
    })
  }

  const handleDatePickerChange = (name:any, value:any) => {
    const rowData = { ...values, [name]: value }

    // only do validation and set values when we have a new valid date or move from valid date to something not valid.
    if (value != null || values[name] != null) {
      validateYup(schema, rowData, name)
      setValues({
        ...values,
        [name]: value,
      })
    }
  }

  const handleFormSubmit:any = (event:any, successCallback:any) => {
    event.preventDefault()

    if (!isValidating) setIsValidating(true)

    schema
      .validate(values, { abortEarly: false })
      .then(() => {
        setErrors({})
        successCallback(values)
      })
      .catch(async (err:any) => {
        if (err.name === 'ValidationError') {
          const errs = await schema.validate(values, { abortEarly: false }).catch((err:any) => {
            const errors = err.inner.flatMap((e:any) => ({ [e.path]: e.errors[0] })).reduce((result:any, current:any) => Object.assign(result, current), {})
            return errors
          // Update form errors state:
          })
          setErrors(errs)
        }
      })
  }

  const resetValidation = () => {
    setIsValidating(false)
    setErrors({})
  }

  return {
    values,
    setValues,
    errors,
    handleChange,
    setErrors,
    handleFormSubmit,
    resetValidation,
    handleOnChange,
    handleDatePickerChange,
  }
}

export default useForm
