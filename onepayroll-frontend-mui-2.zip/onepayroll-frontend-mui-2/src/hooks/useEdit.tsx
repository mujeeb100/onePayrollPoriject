import { useState } from 'react'

export const useEditable = () => {
  const [isEditable, setIsShown]:any = useState<boolean>(false)
  const setEditable:any = (edit:any) => setIsShown(edit && !isEditable)
  return {
    isEditable,
    setEditable,
  }
}
