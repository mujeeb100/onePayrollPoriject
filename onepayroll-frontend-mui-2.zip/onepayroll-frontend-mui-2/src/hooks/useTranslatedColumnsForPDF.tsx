import { useTranslation } from 'react-i18next'
import { getColumnNames } from 'utils'

export const useTranslatedColumnsForPDF = (columnNames: any) => {
  const { t } = useTranslation()
  let columns = getColumnNames(columnNames)
  columns = columns.map((column) => ({ ...column, header: t(column.header) }))
  return columns
}
