import { createSlice } from '@reduxjs/toolkit'
import merge from 'lodash/merge'
import {
  itemList,
  selectLangItemType,
  selectLangStateType,
} from 'types/select-lang-slice-type'

import {
  CHINESE_TITLE,
  ENGLISH_TITLE,
  LOCALE_CHINESE,
  LOCALE_ENGLISH,
} from '../constants'

const lang = localStorage.getItem('lang')
const initialLangListItems:itemList = [
  {
    active: true,
    title: ENGLISH_TITLE,
    locale: LOCALE_ENGLISH,
  },
  {
    active: false,
    title: CHINESE_TITLE,
    locale: LOCALE_CHINESE,
  },
]

const setIntitialTitle = () => {
  if (!lang || lang === LOCALE_ENGLISH) {
    initialLangListItems[0].active = true
    initialLangListItems[1].active = false
    return ENGLISH_TITLE
  }
  initialLangListItems[0].active = false
  initialLangListItems[1].active = true
  return CHINESE_TITLE
}

export const initialState: selectLangStateType = {
  langListItems: initialLangListItems,
  selectedLang: lang || LOCALE_ENGLISH,
  title: setIntitialTitle() || ENGLISH_TITLE,
}

export const SelectLangSlice = createSlice({
  initialState,
  name: 'selectLangSlice',
  reducers: {
    setLangListItems: (state, { payload }) => {
      state.langListItems = payload
    },
    setActiveLang: (state, { payload }) => {
      state.langListItems = state.langListItems.map((langItem: selectLangItemType) => {
        if (langItem.locale === payload.langLocale) {
          return merge(langItem, { active: true })
        }
        return merge(langItem, { active: false })
      })
      state.selectedLang = payload.langLocale
      state.title = payload.langLocale === LOCALE_ENGLISH ? ENGLISH_TITLE : CHINESE_TITLE
      localStorage.setItem('lang', payload.langLocale)
    },
    getActiveLang: (state): any => state.selectedLang,
  },
})

export const {
  setActiveLang, getActiveLang, setLangListItems,
} = SelectLangSlice.actions

export const selectLangSelector = (state: any): selectLangStateType => state.selectLangSlice

export default SelectLangSlice.reducer
