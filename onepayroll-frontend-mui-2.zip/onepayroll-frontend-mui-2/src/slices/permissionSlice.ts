import { createSlice } from '@reduxjs/toolkit'
import merge from 'lodash/merge'
import {
  permissionType,
} from 'types/stateSlices/permissionSlice'

const initialState: permissionType = [
]
export const PermissionSlice = createSlice({
  initialState,
  name: 'permissionSlice',
  reducers: {
    setPermissions: (state, { payload }) => {
      merge(state, payload)
    },
    // setActivePermissions: (state, { payload }) => {
    //   merge(state, payload)
    // },
    getActivePermissions: (state): any => state,
  },
})

export const { getActivePermissions, setPermissions } = PermissionSlice.actions

export const activePermissions = (state: any): permissionType => state.permissionSlice

export default PermissionSlice.reducer
