import { createSlice } from '@reduxjs/toolkit'
import { timezoneList } from 'constants/timeZone'
import merge from 'lodash/merge'

const initialState = timezoneList

export const formateDatelice = createSlice({
  initialState,
  name: 'formateDateSlice',
  reducers: {
    setFormateDate: (state, { payload }) => {
      merge(state, payload)
    },
    getActiveFormateDate: (state): any => state,
  },
})

export const { getActiveFormateDate, setFormateDate } = formateDatelice.actions

export const activeFormateDate = (state: any) => state.formateDatelice

export default formateDatelice.reducer
