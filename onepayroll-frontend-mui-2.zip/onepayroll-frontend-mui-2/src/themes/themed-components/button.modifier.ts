import { Components, Theme } from '@mui/material/styles'

declare module '@mui/material/Button' {
  interface ButtonPropsVariantOverrides {
    primary: true;
    secondary: true;
  }
}

export const MuiButton: Components<Theme>['MuiButton'] = {
  defaultProps: {
    variant: 'primary',
    disableElevation: true,
  },
  // custom styling for button component
  styleOverrides: {
    root: ({ theme }) => {
      const {
        palette: {
          primary: { dark, light, main },
        },
      } = theme
      return {
        borderRadius: 10,

      }
    },
  },
  // defining variants for button component
  variants: [
    {
      props: { variant: 'primary' },
      style: ({ theme }) => {
        const {
          palette: {
            mode,
            primary: { dark, light, main },
            getContrastText,

          },
        } = theme
        return {

        }
      },
    },
  ],
}
