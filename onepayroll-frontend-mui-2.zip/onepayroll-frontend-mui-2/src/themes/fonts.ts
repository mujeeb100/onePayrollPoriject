// Root level font size and family of figuma design
const typography = {
  fontFamily: ['Lato',
    'sans-serif',
  ].join(','),

  h1: {
    fontSize: '1.875em', // 30px   user accounts heading
    fontWeight: '700',
    fontStyle: 'normal',
    fontFamily: 'Lato',
    lineHeight: '2.25em',
    color: '#3B3839',

  },
  h2: {
    fontSize: '1.75em', // 28px
    fontWeight: '700',
    fontStyle: 'normal',
    fontFamily: 'Lato',
    lineHeight: '2.1em',
    color: '#3B3839',

  },
  h3: {
    fontSize: '1.5em', // 24
    fontWeight: '700',
    fontStyle: 'normal',
    fontFamily: 'Lato',
    lineHeight: '1.8em',
    color: '#3B3839',

  },
  h4: {
    fontSize: '1.25em', // 20 use in form inner subheading
    fontWeight: '700',
    fontStyle: 'normal',
    fontFamily: 'Lato',
    lineHeight: '1.5em',
    color: '#3B3839',

  },
  h5: {
    fontSize: '1.125em', // 18
    fontWeight: '700',
    fontStyle: 'normal',
    fontFamily: 'Lato',
    lineHeight: '1.35em',
    color: '#3B3839',
  },
  h6: {
    fontSize: '1em', // 16
    fontWeight: '700',
    fontStyle: 'normal',
    fontFamily: 'Lato',
    lineHeight: '1.2em',
    color: '#3B3839',
  },

  subtitle1: {
    fontSize: '1em',
    fontWeight: '700',
    fontStyle: 'normal',
    fontFamily: 'Lato',
    lineHeight: '1.2em',
    color: '#3B3839',
  },
  subtitle2: {
    fontSize: '0.875em', // 14 use in menu bar n form label
    fontWeight: '700',
    fontStyle: 'normal',
    fontFamily: 'Lato',
    lineHeight: '1.05em',
    color: '#3B3839',

  },

  body1: {
    fontSize: '1em', // 16 use in sidebar  Dashboard
    fontWeight: '700',
    fontStyle: 'normal',
    fontFamily: 'Lato',
    lineHeight: '1.2em',
    color: '#3B3839',

  },
  body2: {
    fontSize: '0.875em', // 14 used as p tag  All fields are mandatory except those marked optional.
    fontWeight: '400',
    fontStyle: 'normal',
    fontFamily: 'Lato',
    lineHeight: '1.05em',
    color: '#3B3839',
  },
  button: {
    fontSize: '0.875em',
    fontWeight: '700',
    fontStyle: 'normal',
    fontFamily: 'Lato',
    lineHeight: '1.05em',
    color: '#7D7B7C',
  },
  caption: {
    fontSize: '1em', //
    fontWeight: '700',
    fontStyle: 'normal',
    fontFamily: 'Lato',
    lineHeight: '1.2em',
    color: '#3B3839',
  },
  overline: {
    fontSize: '0.75em',
    fontWeight: '400',
    fontStyle: 'normal',
    fontFamily: 'Lato',
    lineHeight: '0.9em', // 1.2 * 0.75
    color: 'red',
    marginTop: '5px',
    display: 'block',
  },
}

export default typography
