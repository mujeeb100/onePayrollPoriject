// Root level background color of figuma design
const palette:any = {
  background: {
    default: '#FFFFFF',
  },
  primary: {
    light: '',
    main: '#0049DB', // blue gray-'#7D7B7C',
    dark: '',
    contrastText: '#FFF', // white
  },
  secondary: {
    light: '',
    main: '#FFF',
    dark: '',
    contrastText: '#0049DB', // '#7D7B7C',
  },
  info: {
    light: '',
    main: '#0049DB', // blue
    dark: '',
    contrastText: '#0049DB',

  },
  warning: {
    light: '#F7F5F6', // use when pop up background and user type background
    main: '#E8E6E7', // light gray-for status..active,inactive
    dark: '',
    contrastText: '#3B3839',
  },
  error: {
    light: '',
    main: '#FEF5F8',
    dark: '',
    contrastText: '#DA3237',
  },

  success: {
    light: '',
    main: '#EBFFF0',
    dark: '',
    contrastText: '#00701C',
  },
  // custom button
  customStatus: {
    light: '',
    main: '#0037A4',
    dark: '',
    contrastText: '#FFF',
  },

  // status color code
  pending: {
    main: '#E9F4FF',
    contrastText: '#0049DB',
  },

  Awaiting: {
    main: '#FAEDFF',
    contrastText: '  #FAEDFF',
  },

  Invite: {
    main: '#FFF7EB',
    contrastText: '#9E5A00',
  },

  blackBg: {
    main: 'rgba(125, 123, 124, 0)',
  },

  borderColor: {
    main: '#E8E6E7',
  },

  // topBarBorder: {
  //   main: '#D4D2D3',
  // },
  lightGray: {
    main: '#D4D2D3',
  },
  doubleLightGray: {
    main: '#B5B3B4',
  },

  darkGray: {
    main: '#B5B3B4',
  },

  topAdmin: {
    main: '#666364',
  },

}
export default palette
