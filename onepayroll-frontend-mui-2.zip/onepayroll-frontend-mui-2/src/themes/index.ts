// confugure theme for the app with the default style
import { createTheme } from '@mui/material/styles'
import { PaletteOptions } from '@mui/material/styles/createPalette'

import palette from './colors'
import typography from './fonts'
import spacing from './spacing'

interface ExtendedPaletteOptions1 extends PaletteOptions {
  addEditButton: {
    borderRadius: string,
  },
}

const customPalette: ExtendedPaletteOptions1 = {
  ...palette,

}

const initialColorMode: any = 'light'
const customTheme: any = createTheme({
  palette: {

    ...customPalette,
    ...palette,

  },

  typography: {
    ...typography,
  },

  ...spacing,

  unstable_sxConfig: {
    initialColorMode,
  },

})

export type Theme = typeof customTheme;
export default customTheme
