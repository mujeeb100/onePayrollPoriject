const spacing = {
  space1: 1,
  space2: 2,
  space3: 3,
  space6: 6,
  space8: 8, // eg. sx={{ p: (theme) => theme.spacing(7, 8) }} 56px , 64px
  space7: 7,

}

export default spacing
