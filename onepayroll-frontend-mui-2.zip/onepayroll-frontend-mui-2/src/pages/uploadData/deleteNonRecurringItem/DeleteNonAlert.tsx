import {
  Box,
  Button, DialogActions, DialogContent, DialogTitle,
  useTheme,
} from '@mui/material'
import { Info } from 'assets/svg-images/SvgComponents'
import OPRLabel from 'components/atoms/label/OPRLabel'
import { CustomDialog } from 'components/atoms/modal/OPRModal'
import React from 'react'

// interface ConfirmationModalProps extends Omit<ModalProps, 'children'> {
//   open: boolean;
//   onClose: () => void;
//   // children: any; // Update children prop type
//   children?: React.ReactNode;
//   onBulkDelete: () => void;
// }

function YourDialogModal({
  open, handleClose, onBulkDelete, selectedCount,
}: { open: boolean, handleClose: () => void, onBulkDelete: () => void, selectedCount : number}) {
  const theme:any = useTheme() // Use the Theme type for the theme variable

  return (
    <Box>
      <CustomDialog isOpen={open} type="loader">
        <DialogTitle>
          Are you sure you want to delete the selected items?
        </DialogTitle>
        <DialogContent sx={{
          display: 'flex',
          padding: '12px',
          gap: '12px',
          alignItems: 'flex-start',
          borderRadius: '4px',
          alignSelf: 'stretch',
          backgroundColor: `${theme.palette.Invite.main}`,
          marginTop: 1,
        }}
        >
          <Info />
          <OPRLabel
            CustomStyles={{
              backgroundColor: `${theme.palette.Invite.main}`,
            }}
            backgroundColor={theme.palette.Invite.main}
            variant="body2"
          >
            You’ve chosen to delete
            {' '}
            {selectedCount}
            {' '}
            non-recurring
            {selectedCount === 1 ? 'item' : 'items'}
            {/* . If
            {selectedCount === 1 ? 'it' : 'they'} */}
            {' '}
            If it is deleted, you will not be able to revert it.
            {/* You’ve chosen to delete 10 non-recurring items. If they are deleted, you will not be able to revert it. */}
          </OPRLabel>
        </DialogContent>
        <DialogActions sx={{
          display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: 5,
        }}
        >
          <Button color="info" variant="text" onClick={handleClose}>
            Cancel
          </Button>
          <Button
            style={{
              color: 'var(--red-red-500-da-3237, #DA3237)',
              borderRadius: '110px',
              border: '1px solid var(--red-red-500-da-3237, #DA3237)',
            }}
            variant="text"
            onClick={onBulkDelete}
          >
            Delete
          </Button>
        </DialogActions>
      </CustomDialog>
    </Box>

  )
}

export default YourDialogModal
