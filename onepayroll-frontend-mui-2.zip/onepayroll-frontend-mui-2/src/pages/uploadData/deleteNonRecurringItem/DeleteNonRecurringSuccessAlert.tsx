import {
  Box,
  Button,
  Dialog,
} from '@mui/material'
import { Tick } from 'assets/svg-images/SvgComponents'

function DeleteNonRecurringSuccessAlert({ open, onClose, onGoToLog }: { open: boolean, onClose: () => void, onGoToLog: () => void }) {
  const handleGoToLog = () => {
    window.location.reload()
    onGoToLog()
  }
  return (
    <Dialog fullWidth maxWidth="sm" open={open} onClose={onClose}>
      <Box sx={{
        backgroundColor: 'white',
        boxShadow: '0px 3px 4px #D4D2D3',
        borderRadius: 2,
        color: '#3B3839',
        fontFamily: 'Lato',
      }}
      >
        <Box sx={{
          pt: 5,
          pb: 2,
          paddingRight: '90px',
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          gap: 2,
        }}
        >
          <Box sx={{
            display: 'flex',
            alignItems: 'center',
            gap: 1,
          }}
          >
            <Box sx={{
              width: 24,
              height: 24,
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
            }}
            >
              <Tick />
            </Box>
            <Box sx={{
              fontSize: 24,
              fontWeight: 700,
              wordWrap: 'break-word',
              display: 'flex',
              alignItems: 'center',
            }}
            >
              Bulk delete non-recurring items submitted
            </Box>
          </Box>
        </Box>
        <Box sx={{
          height: 64,
          pl: 5,
          pr: 5,
          display: 'flex',
          flexDirection: 'column',
          // gap: 2.5,
        }}
        >
          <Box sx={{
            fontSize: 16,
            fontWeight: 400,
            // lineHeight: '24px',
            wordWrap: 'break-word',
            marginBottom: '10px', // Added margin bottom to create space
          }}
          >
            Bulk delete non-recurring items has been submitted.
          </Box>
          {/* <br /> */}
          <Box sx={{
            fontSize: 16,
            fontWeight: 400,
            lineHeight: '24px',
            wordWrap: 'break-word',
          }}
          >
            Please refer to the log file for more information.
          </Box>
        </Box>
        <Box sx={{
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          borderTop: '1px solid #E8E6E7',
          height: 80,
          pl: 5,
          pr: 5,
        }}
        >
          <Button
            sx={{
              color: '#0049DB',
              fontWeight: 700,
            }}
            onClick={handleGoToLog}
          >
            Go to log
          </Button>
          <Button
            sx={{
              backgroundColor: '#0049DB',
              color: 'white',
              '&:hover': {
                backgroundColor: '#0049DB',
              },
            }}
            variant="contained"
            onClick={onClose}
          >
            Close
          </Button>
        </Box>
      </Box>
    </Dialog>
  )
}

export default DeleteNonRecurringSuccessAlert
