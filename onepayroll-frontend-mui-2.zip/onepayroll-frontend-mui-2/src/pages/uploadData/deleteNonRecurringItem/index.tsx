import {
  Box,
} from '@mui/material'
import { useGetAllEmployeeProfileQuery } from 'api/employeeServices'
import { useGetAllEntityProfileSelectedListByIdQuery } from 'api/entityServices'
import { useGetAllPayRollNonRecurringLogsQuery } from 'api/loggingServices'
import {
  useGetAllPayItemMasterQuery, usePayCycleMasterSearchFilterCreateMutation, usePayRollBulkNonRecurringDelete2Mutation,
  usePayRollNonRecurringSearchCreateMutation,
} from 'api/payRollServices'
import { TrashIcon } from 'assets/svg-images/SvgComponents'
import OPRButton from 'components/atoms/button/OPRButton'
import OPRCheckbox from 'components/atoms/checkbox/OPRCheckbox'
import OPRLabel from 'components/atoms/label/OPRLabel'
import MultipleSelectCheckmarks from 'components/atoms/multiSelectCheckbox'
import OPRSelectCheckbox from 'components/atoms/multiSelectCheckbox/OPRSelectCheckbox'
import {
  logsPayRollNonRecurring,
  payrollNoRecurringSearch,
} from 'components/atoms/table/OPRTableConstant'
import { CustomTabPanel, StyledTab, StyledTabs } from 'components/atoms/tabs'
import OPRDatePickerControl from 'components/molecules/OPRDatePickerControl/OPRDatePickerControl'
import { OPRInnerListLayout } from 'components/organism/OPRInnerLayoutList'
import { t } from 'i18next'
import React, { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { routes } from 'routes/routes'
import {
  formatedYearDate,
  generateFilterUrl,
} from 'utils'

import DeleteNonAlert from './DeleteNonAlert'
import DeleteNonRecurringSuccessAlert from './DeleteNonRecurringSuccessAlert'

function a11yProps(index: number) {
  return {
    id: `simple-tab-${index}`,
    'aria-controls': `simple-tabpanel-${index}`,
  }
}

interface Option {
  roleCode: string
  roleName: string
}

interface SelectedOptions {
  PayCycleYearMonth: Option[]
  EmployeeCode: Option[]
  PayItemCode: Option[]
  EmployeeName: Option[]
  PayCycleCode: Option[]
  PayCycleYear: Option[]
  PayCycleMonth: Option[]
}

function PayRollNonRecurringList() {
  const [deleteNonRecurringSuccessAlertOpen, setDeleteNonRecurringSuccessAlertOpen]:any = useState(false)
  const [selectedEntity, setSelectEntity]:any = useState([])
  const navigate: any = useNavigate()
  const [selectedOptions1, setSelectedOptions1]:any = useState({})
  const [selectedRows, setSelectedRows]:any = useState([])
  const [selectAll, setSelectAll] = useState(false)
  const [value, setValue] = useState(0)
  const handleTabChange = (event: React.SyntheticEvent, newValue: number) => {
    setValue(newValue)
  }
  const [selectedDate, setSelectedDate]:any = useState(null) // State to hold the selected date
  const [selectedOptions, setSelectedOptions]:any = useState<SelectedOptions>(
    {
      PayCycleYearMonth: [],
      EmployeeCode: [],
      PayItemCode: [],
      EmployeeName: [], // Add EmployeeName option
      PayCycleCode: [],
      PayCycleYear: [],
      PayCycleMonth: [],
    },
    // [],
  )
  const [listOfOptions, setListOfOptions]:any = useState<any>({
    PayCycleYearMonth: [],
    EmployeeCode: [],
    PayItemCode: [],
    // EmployeeName: [], // Add EmployeeName option
    PayCycleCode: [],
  })
  const [selelctedDeleteItem, setSelelctedDeleteItem]:any = useState({
    data: {},
    isDelete: false,
    name: '',
  })

  // const
  const [filterData, setFilterData]:any = useState({
    pageNumber: 1,
    pageSize: 50,
    totalItems: 0,
    orderByAsc: true,
    sortBy: '',
    SearchText: '',
    PayCycleYear: '', // 2024
    PayCycleMonth: '', // 03
    PayCycleCode: '', // 01
    EmployeeCode: null, // Add Employee E01099
    // EmployeeCode: [''],
    PayItemCode: '', // null default
    createdDate: null,
  })

  const {
    data: allPostsLogs,
    isLoading: isLoadingAllPostsLogs,
    isSuccess: isSuccessAllPostsLogs,
    isError: isErrorAllPostsLogs,
    error: errorAllPostsLogs,
    refetch: refetchAllPostsLogs,
  } = useGetAllPayRollNonRecurringLogsQuery('')

  const {
    data: EntityProfileByIdResponse,
    error: EntityProfileByIdError,
    isLoading: EntityProfileByIdLoading,
    isSuccess: EntityProfileByIdSuccess,
    isError: EntityProfileByIdIsError,
  } = useGetAllEntityProfileSelectedListByIdQuery('')

  const
    [createPayrollNonRecurringSearch,
      {
        data: allPosts,
        isLoading: isLoadingAllSearchPosts,
        isSuccess: isSuccessAllSearchPosts,
        isError: isErrorAllSearchPosts,
        error: errorAllSearchPosts,
        refetch: refetchAllSearchPosts,
      },
    ] = usePayRollNonRecurringSearchCreateMutation()

  // employe profile
  const {
    data: allPostEmployeeData,
    isLoading: isLoadingAllPostsEmployeeData,
    isSuccess: isSuccessAllPostsEmployeeData,
    isError: isErrorAllPostsEmployeeData,
    error: errorAllPostsEmployeeData,
  } = useGetAllEmployeeProfileQuery(generateFilterUrl({ pageNumber: 1, pageSize: 1000 }))

  // PayItemMaster
  const {
    data: allPayItemMasterData,
    isLoading: isLoadingAllPayItemMasterData,
    isSuccess: isSuccessAllPayItemMasterData,
    isError: isErrorAllPayItemMasterData,
    error: errorAllPayItemMasterData,
  } = useGetAllPayItemMasterQuery(generateFilterUrl({ pageNumber: 1, pageSize: 1000 }))

  // // entityProfile get by id

  // const {
  //   data: EntityProfileByIdResponse,
  //   error: EntityProfileByIdError,
  //   isLoading: EntityProfileByIdLoading,
  //   isSuccess: EntityProfileByIdSuccess,
  //   isError: EntityProfileByIdIsError,
  // } = useGetAllEntityProfileSelectedListByIdQuery('')

  // PayCycle Master data
  const
    [createPayCycleMasterData,
      {
        data: payCycleYearData,
      },
    ] = usePayCycleMasterSearchFilterCreateMutation()

  useEffect(() => {
    // Define the request body
    const requestBody = {
      pageSize: 1000,
      pageNumber: 1,
      sortBy: '',
      orderByAsc: true,
      // "payCycleType": [2]
    }

    // Call the API
    createPayCycleMasterData(requestBody)
  }, [createPayCycleMasterData])

  // usePayCycleMasterSearchFilterCreateMutation
  // onsole.log(EntityProfileByIdResponse.currentPayrollMonthYear, 'year')
  // console.log(EntityProfileByIdResponse.currentPayrollMonth, 'month')c

  // console.log(allPostEmployeeData?.records?.employeeProfile.givenName, 'allPostEmployeeData12345')

  // usePayRollNonRecurringBulkDeleteMutation
  const [
    deletePayRollNonRecurringBulkDeleteMutation,
    {
      data: deletePayRollNonRecurringBulkResponse,
      error: deletePayRollNonRecurringBulkError,
      isLoading: deletePayRollNonRecurringBulkLoading,
      isSuccess: deletePayRollNonRecurringBulkSuccess,
      isError: deletePayRollNonRecurringBulkIsError,
    }] = usePayRollBulkNonRecurringDelete2Mutation()

  useEffect(() => {
    if (allPosts?.data?.totalItems !== undefined) {
      setFilterData((prev:any) => ({ ...prev, totalItems: allPosts?.data?.totalItems }))
    }
  }, [allPosts])

  useEffect(() => {
    fetchData()
  }, [])

  useEffect(() => {
    if (selectedOptions.EmployeeCode.length > 0) {
      fetchData()
    }
  }, [selectedOptions.EmployeeCode])
  // console.log(selectedOptions.PayCycleYear.map((item:any) => item.roleCode), 'paycyclecodepaycyclecodepaycyclecode')
  const fetchData = async (pageNumber = filterData.pageNumber, pageSize = filterData.pageSize) => {
    const employeeCodes = selectedOptions.EmployeeCode.map((item:any) => item.roleCode)
    const payCycleCodes = selectedOptions.PayCycleCode.map((item:any) => item.roleCode)
    const payCycleYear = selectedOptions?.PayCycleYear?.map((item:any) => item?.roleCode)
    const payItemCode = selectedOptions?.PayItemCode?.map((item:any) => item?.roleCode)
    const createdDate = selectedDate ? formatedYearDate(selectedDate) : null
    // const createdDate = formatedYearDate(selectedDate) || new Date()

    await createPayrollNonRecurringSearch({
      payCycleSearch: {
        payCycleYear: filterData.PayCycleYear,
        // payCycleYear: payCycleYear?.length > 0 ? payCycleYear[0] : '',
        payCycleMonth: filterData.PayCycleMonth,
        payCycleCode: payCycleCodes.length > 0 ? payCycleCodes[0] : null, // Take the first selected code or empty string if none selected
        // employeeCode: null,
        employeeCode: employeeCodes.length > 0 ? employeeCodes : null,
        payItemCode: payItemCode.length > 0 ? payItemCode : null,
        createdDate, // Pass the selected date
        // employeeCode: employeeCodes.length > 0 ? employeeCodes : [''],
      },
      pageNumber,
      pageSize,
      orderByAsc: filterData.orderByAsc,
    })
  }

  // payitem master data
  useEffect(() => {
    if (allPostEmployeeData && allPayItemMasterData && payCycleYearData) {
      const uniquePayCycleYears = Array.from(new Set(payCycleYearData?.data?.records?.map((item: any) => item.payCycleYear) || []))
      const uniquePayCycleMonths = Array.from(new Set(payCycleYearData?.data?.records?.map((item: any) => item.payCycleMonth) || []))

      const payCycleYearOptions = uniquePayCycleYears.map((year) => ({
        roleCode: year,
        roleName: year,
      }))

      const payCycleMonthOptions = uniquePayCycleMonths.map((month) => ({
        roleCode: month,
        roleName: month,
      }))

      // Create combined options
      const payCycleYearMonthOptions = uniquePayCycleYears.flatMap((year) => uniquePayCycleMonths.map((month) => ({
        roleCode: `${year}${month}`,
        roleName: `${year}-${month}`,
      })))

      const employeeNameOption = allPostEmployeeData?.records?.map((item: any) => ({
        roleCode: item.employeeCode, // Assuming employeeCode is unique
        roleName: `${item.employeeCode} - ${item.employeeProfile?.givenName || ''}`, // Concatenate employeeCode and givenName
      }))

      const payItemCodeOption = allPayItemMasterData?.records?.map((item: any) => ({
        roleCode: item.payItemCode,
        roleName: `${item.payItemCode} - ${item?.payItemName || ''}`,
      }))

      const payCycleCodeOption = payCycleYearData?.data?.records?.map((item: any) => ({
        roleCode: item.payCycleCode, // Assuming employeeCode is unique
        roleName: `${item.payCycleCode} - ${item?.payCycleName || ''}`, // Concatenate employeeCode and givenName
      }))

      setListOfOptions((prev: any) => ({
        ...prev,
        PayCycleYearMonth: payCycleYearMonthOptions,
        PayCycleMonth: payCycleMonthOptions,
        // PayCycleYearMonth: formattedOptions,
        EmployeeCode: employeeNameOption, // Add EmployeeName option
        PayItemCode: payItemCodeOption,
        PayCycleCode: payCycleCodeOption,
      }))
    }
  }, [allPostEmployeeData,
    allPayItemMasterData, payCycleYearData])

  // update filter options
  // useEffect(() => {
  const updateFilterData = () => {
    selectedOptions.EmployeeName.forEach((item:any) => {
      setFilterData((prev:any) => ({ ...prev, EmployeeCode: item.roleCode }))
    })

    selectedOptions.PayItemCode.forEach((item:any) => {
      setFilterData((prev:any) => ({ ...prev, PayItemCode: item.roleCode }))
    })

    selectedOptions.PayCycleCode.forEach((item:any) => {
      setFilterData((prev:any) => ({ ...prev, PayCycleCode: item.roleCode }))
    })

    if (selectedOptions.PayCycleYearMonth.length > 0) {
      const [firstSelected] = selectedOptions.PayCycleYearMonth
      const year = firstSelected.roleCode.substring(0, 4)
      const month = firstSelected.roleCode.substring(4, 6)

      setFilterData((prev:any) => ({ ...prev, PayCycleYear: year, PayCycleMonth: month }))
    }
  }

  useEffect(() => {
    if (EntityProfileByIdResponse) {
      const { currentPayrollMonthYear, currentPayrollMonth } = EntityProfileByIdResponse
      // start
      const monthNames = ['January', 'February', 'March', 'April', 'May', 'June', 'July',
        'August', 'September', 'October', 'November', 'December']
      const monthIndex = monthNames.indexOf(currentPayrollMonth)
      const monthNumber = (monthIndex + 1).toString().padStart(2, '0')
      // lll
      const formattedMonthNumber = currentPayrollMonth?.padStart(2, '0')
      const formattedYearMonth = `${currentPayrollMonthYear}-${monthNumber}`

      const defaultSelectedOptions: Partial<SelectedOptions> = {}

      if (currentPayrollMonthYear && currentPayrollMonth) {
        defaultSelectedOptions.PayCycleYearMonth = [
          { roleCode: formattedYearMonth, roleName: formattedYearMonth },
        ]
      }

      setSelectedOptions((prevSelectedOptions: SelectedOptions) => ({
        ...prevSelectedOptions,
        ...defaultSelectedOptions,
      }))

      // Include currentPayrollMonthYear and currentPayrollMonth in the payload
      const payload = {
        payCycleSearch: {
          payCycleYear: currentPayrollMonthYear,
          payCycleMonth: monthNumber,
          // Include other properties from filterData as needed
        },
        pageNumber: filterData.pageNumber,
        pageSize: filterData.pageSize,
        orderByAsc: filterData.orderByAsc,
      }

      // Call the function to fetch data with the updated payload
      fetchData(payload.pageNumber, payload.pageSize)
    }
  }, [EntityProfileByIdResponse])

  useEffect(() => {
    if (selectedOptions.PayCycleYearMonth.length > 0) {
      const [firstSelected] = selectedOptions.PayCycleYearMonth
      const year = firstSelected.roleCode.substring(0, 4)
      const month = firstSelected.roleCode.substring(4, 6)
      setFilterData((prev: any) => ({
        ...prev,
        PayCycleYear: year,
        PayCycleMonth: month,
      }))
      updateFilterData()
    }
  }, [selectedOptions.PayCycleYearMonth])

  useEffect(() => {
    fetchData()
  }, [
    filterData.PayCycleYear,
    filterData.PayCycleMonth,
    selectedOptions.EmployeeCode,
    selectedOptions.PayCycleCode,
    selectedOptions.PayCycleYear,
    selectedOptions.PayItemCode,
    selectedOptions.PayCycleYearMonth,
  ])

  // updateFilterData()
  // }, [selectedOptions])

  useEffect(() => {
    if (EntityProfileByIdResponse) {
      const { currentPayrollMonthYear, currentPayrollMonth } = EntityProfileByIdResponse
      if (currentPayrollMonthYear && currentPayrollMonth) {
        const monthNames = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December']
        const monthIndex = monthNames.indexOf(currentPayrollMonth)
        const monthNumber = (monthIndex + 1).toString().padStart(2, '0')
        setFilterData((prev: any) => ({
          ...prev,
          PayCycleYear: currentPayrollMonthYear,
          PayCycleMonth: monthNumber,
        }))
        setSelectedOptions((prevSelectedOptions: any) => ({
          ...prevSelectedOptions,
          PayCycleYearMonth: [
            {
              roleCode: `${currentPayrollMonthYear}${monthNumber}`,
              roleName: `${currentPayrollMonthYear}-${monthNumber}`,
            },
          ],
        }))
        updateFilterData()
      }
    }
  }, [EntityProfileByIdResponse])

  useEffect(() => {
    updateFilterData()
  }, [selectedOptions])

  // Function to handle date selection change filterarion part for date
  const handleDateChange = (date: Date | null) => {
    setSelectedDate(date)
    if (date) {
      // const formattedDate = date.toISOString().split('T')[0]
      // setFilterData((prev: any) => ({ ...prev, CreatedDate: formattedDate }))
      setFilterData((prev: any) => ({ ...prev, CreatedDate: formatedYearDate(date.toString()) }))
      // fetchData()
    }
  }

  // date picker
  useEffect(() => {
    if (selectedDate) {
      // const formattedDate = selectedDate.toISOString().split('T')[0]
      setFilterData((prev: any) => ({ ...prev, CreatedDate: formatedYearDate(selectedDate.toString()) }))
      fetchData()
    }
  }, [selectedDate])

  useEffect(() => {
    // Update filterData state with selectedDate whenever it changes
    if (selectedDate) {
      const formattedDate = selectedDate?.toISOString()?.split('T')[0]
      setFilterData((prev: any) => ({
        ...prev,
        CreatedDate: formattedDate,
      }))
    }
  }, [selectedDate])

  const handleTagRemove = (value: string, filterName: string) => {
    setSelectedOptions((prevSelectedOptions: any) => ({
      ...prevSelectedOptions,
      [filterName]: prevSelectedOptions[filterName].filter((item: any) => item !== value),
    }))
  }

  const handleFilterChange = (filterName: string, values: any) => {
    setSelectedOptions((prevSelectedOptions: any) => ({
      ...prevSelectedOptions,
      [filterName]: values,
    }))
    if (filterName === 'PayCycleYearMonth') {
      const [firstSelected] = values
      const year = firstSelected.roleCode.substring(0, 4)
      const month = firstSelected.roleCode.substring(4, 6)
      setFilterData((prev: any) => ({
        ...prev,
        PayCycleYear: year,
        PayCycleMonth: month,
      }))
    }

    fetchData()
  }

  const handlePayCycleCodeChange = (filterName: string, values: any) => {
    setSelectedOptions((prevSelectedOptions: any) => ({
      ...prevSelectedOptions,
      [filterName]: values,
    }))
    // Check if any PayCycleCode is selected
    if (values.length > 0) {
      fetchData()
    }
  }
  // const handleDeleteButtonClick = () => {
  //   // Call the bulk delete mutation with selected entity IDs
  //   deletePayRollNonRecurringBulkDeleteMutation({ ids: selectedEntity })
  // }

  const sorting = (
    event: React.MouseEvent<unknown>,
    property: keyof any,
  ) => {
    const isAsc = filterData.sortBy === property && filterData.orderByAsc === true
    setFilterData({ ...filterData, orderByAsc: !isAsc, sortBy: property })
  }

  useEffect(() => {
    setFilterData({ ...filterData, totalItems: allPosts?.data?.totalItems ? allPosts?.data?.totalItems : 0 })
  }, [allPosts?.data?.pageNumber, filterData.sortBy, filterData.orderByAsc, allPosts?.data?.totalItems])

  const handlePagination = (pageNumber: number, pageSize: number) => {
    // setFilterData((prev:any) => ({ ...prev, pageNumber, pageSize }))
    setFilterData({ ...filterData, pageNumber })
    fetchData(pageNumber, pageSize)
  }

  const renderValue = (selected: any[], filterName: string) => {
    if (selected.length === 0) {
      return <span>{t(`${filterName}`)}</span>
    }

    return (
      <span style={{ display: 'flex', justifyContent: 'space-between' }}>
        <span style={{ }}>
          {t(`${filterName}`)}
          {' '}
        </span>
        <span>
          {selected.length}
        </span>
      </span>
    )
  }

  // const renderValue = (selected:any, filterName:any) => selected.map((item:any) => item.roleName || item.roleCode).join(', ')

  // Function to handle checkbox change
  const handleCheckboxChange = (event:any, id:any) => {
    // Check if the checkbox is checked or unchecked

    if (event.target.checked) {
      // Add the key to the selectedRows state if checked
      setSelectEntity((prev:any) => [...prev, id])
    } else {
      // Remove the key from the selectedEntity state if unchecked
      setSelectEntity((prev:any) => prev.filter((key:any) => key !== id))
    }
  }

  // success
  useEffect(() => {
    if (deletePayRollNonRecurringBulkSuccess) {
      setSelelctedDeleteItem({ ...selelctedDeleteItem, isDelete: false })
      //     // Show the success alert modal
      setDeleteNonRecurringSuccessAlertOpen(true)
    }
  }, [deletePayRollNonRecurringBulkSuccess])

  // useEffect(() => {
  //   if (deletePayRollNonRecurringBulkSuccess) {
  //     setSelelctedDeleteItem({ ...selelctedDeleteItem, isDelete: false })
  //     // Show the success alert modal
  //     setDeleteNonRecurringSuccessAlertOpen(true)
  //   }
  // }, [deleteNonRecurringSuccessAlertOpen])

  // Function to handle the "Select All" checkbox toggle
  const handleSelectAllChange = (event:any) => {
    const isChecked = event.target.checked

    // If "Select All" is checked, set all row keys to selectedRows state
    if (isChecked) {
      const allRowKeys = allPosts?.records.map((row:any) => row.key)
      setSelectedRows(allRowKeys)
    } else {
      // If "Select All" is unchecked, clear the selectedRows state
      setSelectedRows([])
    }
  }

  const handleDeleteButtonClick = () => {
    setSelelctedDeleteItem({ isDelete: true })
  }

  const handleSubmit:any = async () => {
    const deleteItems = selectedEntity.map((id:any) => ({ payrollNonRecurringItemId: id }))
    await deletePayRollNonRecurringBulkDeleteMutation(
      { body: deleteItems },
    )
    setSelelctedDeleteItem({ ...selelctedDeleteItem, isDelete: false })
    // deletePayRollNonRecurringBulkDeleteMutation({ ids: deleteItems })
  }

  const handleSelectChange = (event:any) => {
    const { name, value } = event.target
    setSelectedOptions((prev:any) => ({
      ...prev,
      [name]: value,
    }))
    fetchData()
  }

  // payCycleYearandMonth
  const renderValueYearMonth = (selected: any) => {
    if (selected.length === 0) {
      return 'Year & Month'
    }
    return (
      <span style={{ display: 'flex', justifyContent: 'space-between' }}>
        <span style={{ fontSize: '13px' }}>
          {selected.map((item: any) => (
            <span key={item.roleName}>
              {/* {item.roleCode.substring(0, 4)} */}
              {item.roleName.padStart(2, '0')}
            </span>
          ))}
        </span>
      </span>
    )
  }

  // payCycleCode
  const renderValuePayCycleCode = (selected: any) => {
    if (selected.length === 0) {
      return <span>Pay Cycle</span>
    }
    return (
      <span style={{
        display: 'flex',
        justifyContent: 'space-between',
        // wordWrap: 'break-word',
        // overflowWrap: 'break-word',
        // whiteSpace: 'nowrap',
      }}
      >
        <span style={{ fontSize: '13px' }}>
          {selected.map((item: any) => (
            <span
              key={item.roleCode}
            >
              {/* {item.roleCode}
              - */}
              {item.roleName}
            </span>
          ))}
        </span>
      </span>
    )
  }

  const filterLayout = () => (
    <>

      <OPRSelectCheckbox
        listOfOptions={listOfOptions.PayCycleYearMonth}
        renderValue={renderValueYearMonth}
        selectedOptions={selectedOptions.PayCycleYearMonth}
        setSelectedOptions={(values: any) => handleFilterChange('PayCycleYearMonth', values)}
      />

      <OPRSelectCheckbox
        listOfOptions={listOfOptions.PayCycleCode}
        renderValue={renderValuePayCycleCode}
        selectedOptions={selectedOptions.PayCycleCode}
        setSelectedOptions={(selected) => handlePayCycleCodeChange('PayCycleCode', selected)}
      />

      <MultipleSelectCheckmarks
        listOfOptions={listOfOptions?.EmployeeCode}
        renderValue={(selected:any) => renderValue(selected, 'Employee')}
        selectedOptions={selectedOptions?.EmployeeCode}
        setSelectedOptions={(EmployeeCode:any) => {
          setSelectedOptions((prev: any) => ({ ...prev, EmployeeCode }))
          fetchData()
        }}
        sx={{
          backgroundColor: selectedOptions?.EmployeeCode?.length > 0 ? '#0037A4' : 'default',
          color: selectedOptions?.EmployeeCode?.length > 0 ? '#FFF' : '#000',
        }}
      />
      {/* Pay Items */}
      <MultipleSelectCheckmarks
        listOfOptions={listOfOptions?.PayItemCode}
        renderValue={(selected:any) => renderValue(selected, 'Pay Item')}
        selectedOptions={selectedOptions?.PayItemCode}
        setSelectedOptions={(PayItemCode:any) => {
          setSelectedOptions((prev: any) => ({ ...prev, PayItemCode }))
          fetchData()
        }}
        sx={{
          backgroundColor: selectedOptions?.PayItemCode?.length > 0 ? '#0037A4' : 'default',
          color: selectedOptions?.PayItemCode?.length > 0 ? '#FFFFFF' : '#000',
        }}
      />
      {/* creation date */}
      <OPRDatePickerControl
        // label="Select Date"
        placeholder="Creation Date"
        value={selectedDate} // Pass selectedDate as the value
        onChange={handleDateChange} // Handle date selection change

      />
    </>
  )
  // <OPRLabel>Select ALL</OPRLabel>
  const handleGoToLogTab = () => {
    setValue(1) // 1 is the index of the "Logs" tab
  }

  // Delete button
  const selectedCount = selectedEntity.length

  const isDeleteButtonDisabled = selectedEntity?.length <= 0

  const hasData = allPosts?.data?.records?.length > 0

  const renderTopButtons = () => (
    <Box
      sx={{
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'center',
        marginTop: 5,
      }}
    >
      {/* select all checkbox */}
      <OPRCheckbox
        checked={selectedEntity.length === allPosts?.data?.records.length} // Check if all rows are selected
        disabled={!hasData}
        label="Select All"
        onChange={(event: any) => {
          if (event.target.checked) {
            setSelectEntity(allPosts?.data?.records.map((row: any) => row.id))
          } else {
            setSelectEntity([])
          }
        }} // Handle "Select All" checkbox change
      />
      <Box
        sx={{
          borderRadius: 110,
          overflow: 'hidden',
          justifyContent: 'center',
          alignItems: 'center',
          marginLeft: 4,
          display: 'inline-flex',
        }}
      >
        {selectedCount > 0 && allPosts?.data?.records && (
          <Box
            sx={{
              color: '#3B3839',
              fontSize: 14,
              fontFamily: 'Lato',
              fontWeight: 700,
              wordWrap: 'break-word',
              marginRight: 1, // Add margin to separate from button
            }}
          >
            {selectedCount}
            {' '}
            Selected
          </Box>
        )}

        <OPRButton
          color="primary"
          disabled={!hasData || isDeleteButtonDisabled} // Disable if no data
          sx={{
            color: '#DA3237',
            fontSize: 14,
            fontFamily: 'Lato',
            fontWeight: 700,
            wordWrap: 'break-word',
            border: '1px #DA3237 solid',
            display: 'flex',
            alignItems: 'center',
            margin: '0 4px',
          }}
          variant="text"
          onClick={handleDeleteButtonClick}
        >
          <Box sx={{ marginRight: 1 }}>
            <TrashIcon />
          </Box>
          Delete selected
        </OPRButton>
      </Box>
    </Box>
  )
  return (
    <Box sx={{ display: 'flex', flexDirection: 'column' }}>
      <OPRLabel label={t('Delete non-recurring items')} variant="h2" />
      <Box sx={{ borderBottom: 1, borderColor: 'divider' }}>
        <StyledTabs aria-label="basic tabs example" value={value} onChange={handleTabChange}>
          <StyledTab label="Non-recurring items" {...a11yProps(0)} />
          <StyledTab label="Logs" {...a11yProps(1)} />
        </StyledTabs>
      </Box>
      {value === 0 && (
        <OPRLabel label="Start your listing by selecting a pay cycle." sx={{ marginTop: '12px' }} />
      )}

      <DeleteNonAlert
        handleClose={() => setSelelctedDeleteItem({ isDelete: false })}
        open={selelctedDeleteItem.isDelete}
        selectedCount={selectedCount}
        onBulkDelete={handleSubmit}
      />
      <DeleteNonRecurringSuccessAlert
        open={deleteNonRecurringSuccessAlertOpen}
        onClose={() => setDeleteNonRecurringSuccessAlertOpen(false)}
        onGoToLog={handleGoToLogTab}
      />
      <CustomTabPanel index={0} value={value}>
        <OPRInnerListLayout
          addHandleClick={() => navigate(routes.createPayRollNonRecurring)}
          columns={payrollNoRecurringSearch('', selectedEntity, handleCheckboxChange)}
          dataList={JSON.parse(JSON.stringify(allPosts?.data?.records || []))}
          error={deletePayRollNonRecurringBulkError}
          filterData={filterData}
          filterLayout={filterLayout}
          handlePagination={handlePagination}
          isAdd={false}
          isError={deletePayRollNonRecurringBulkIsError}
          isExport={false}
          isSearch={false}
          loading={deletePayRollNonRecurringBulkLoading || isLoadingAllSearchPosts}
          renderTopButtons={renderTopButtons}
          rowNumber={0}
          selectedEntity={selectedEntity}
          sortHandleClick={sorting}
          // success={deletePayRollNonRecurringBulkSuccess}
          title={t('')}
        />
      </CustomTabPanel>

      <CustomTabPanel index={1} value={value}>
        <OPRInnerListLayout
          Search={filterData.SearchText}
          columns={logsPayRollNonRecurring('')}
          dataList={(JSON.parse(JSON.stringify(allPostsLogs?.records || [])))}
          deleteCallBack=""
          // error={errorAllPostsLogs}
          filterData={filterData}
          // handleFileDownload={handleFileDownload}
          handlePagination={handlePagination}
          isAdd={false}
          // isError={isErrorAllPostsLogs}
          loading={isLoadingAllPostsLogs}
          // rowClickHandler=""
          // rowNumber={0}
          sortHandleClick={sorting}
          success=""
          title={t('')}
        />
      </CustomTabPanel>
    </Box>
  )
}

export default PayRollNonRecurringList
