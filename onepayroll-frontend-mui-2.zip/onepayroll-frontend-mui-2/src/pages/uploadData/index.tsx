import {
  Box,
} from '@mui/material'
import { useGetAllUploadDataQuery, useLazyGetUploadDataByIdQuery } from 'api/inegrationServices'
import axios from 'axios'
import { bulkUploadColumn } from 'components/atoms/table/OPRTableConstant'
import { OPRInnerListLayout } from 'components/organism/OPRInnerLayoutList'
import apiEndPoint from 'constants/apiEndPoint'
import saveAs from 'file-saver'
import { t } from 'i18next'
import React, { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { routes } from 'routes/routes'
import {
  generateFilterUrl, getAPIWithEntityUrl, getauthToken,
} from 'utils'

function UploadDataList() {
  const navigate: any = useNavigate()
  const [isSkip, setIsSkip]:any = useState(true)
  const [filterData, setFilterData]:any = useState({
    pageNumber: 1,
    pageSize: 20,
    totalItems: 0,
    orderByAsc: false,
    sortBy: '',
    SearchText: '',
  })
  const [filterLogData, setfilterLogData]:any = useState({
    id: '',
  })
  const {
    data: allPosts,
    isLoading: isLoadingAllPosts,
    isSuccess: isSuccessAllPosts,
    isError: isErrorAllPosts,
    error: errorAllPosts,
    refetch: refetchAllPosts,
  } = useGetAllUploadDataQuery(generateFilterUrl(filterData))

  const [deownloadFileById,
    {
      data: deletedeownloadFileResponse,
      error: deletedeownloadFileError,
      isLoading: deletedeownloadFileLoading,
      isSuccess: deletedeownloadFileSuccess,
      isError: deletedeownloadFileIsError,
    }] = useLazyGetUploadDataByIdQuery()

  const sorting = (
    event: React.MouseEvent<unknown>,
    property: keyof any,
  ) => {
    const isAsc = filterData.sortBy === property && filterData.orderByAsc === true
    setFilterData({ ...filterData, orderByAsc: !isAsc, sortBy: property })
  }

  useEffect(() => {
    const interval = setInterval(() => {
      refetchAllPosts()
    }, 5000)

    return () => clearInterval(interval)
  }, [])

  useEffect(() => {
    setFilterData({ ...filterData, totalItems: allPosts?.totalItems ? allPosts?.totalItems : 0 })
  }, [allPosts?.pageNumber, filterData.sortBy, filterData.orderByAsc, allPosts?.totalItems])

  const onSearch = (e: any, data: any) => {
    setFilterData({ ...filterData, ...data })
  }
  const handlePagination = (pageNumber: number, pageSize: number) => {
    setFilterData({ ...filterData, pageNumber })
  }
  const getDownloadfile = async (item: any) => {
    const urldownload = `${process.env.REACT_APP_UP_BASE_URL}/${apiEndPoint.uploadDataListById}`
    const token = getauthToken()
    const regExpFilename = /filename=(?<filename>[^;]*)/
    axios
      .get(
        `${getAPIWithEntityUrl(urldownload)}?fileName=${item.errorFilePath}`,
        {
          responseType: 'blob',
          headers: {
            Authorization: `Bearer ${token}`,
          },
        },
      )
      .then(({ data, headers, status }) => {
        if (status === 200) {
          const filename = regExpFilename.exec(headers['content-disposition'] ?? '')?.groups
            ?.filename ?? null
          if (filename !== null) {
            saveAs(
              new Blob([data], { type: headers['content-type'] }),
              filename,
            )
          }
        }
      })
      .catch((error:any) => {
        console.log(error)
      })
  }
  const viewAcoount = (data: any) => {
    getDownloadfile(data)
  }
  const handleView = (data: any) => {
    // navigate(
    //   setRouteValues(`${routes.viewCompanyBankAccount}`, {
    //     id: data.id,
    //     view: true,
    //   }),
    // )
  }
  // handle Delete
  //   const handleDelete = (data:any) => {
  //     deleteCostCenterById(`Id=${data.id}`)
  //   }
  return (
    <Box sx={{ display: 'flex' }}>
      <OPRInnerListLayout
        addHandleClick={() => navigate(routes.createDataUpload)}
        columns={bulkUploadColumn(getDownloadfile)}
        customAdd="Bulk add & edit"
        dataList={allPosts?.records || []}
        deleteCallBack={() => {}}
        error={errorAllPosts}
        filterData={filterData}
        handlePagination={handlePagination}
        handleSearch={onSearch}
        isError={isErrorAllPosts}
        isSearch={false}
        loading={isLoadingAllPosts}
        rowClickHandler={handleView}
        rowNumber={0}
        // selelctedUser={selelctedDelete}
        // setSelelctedUser={setSelelctedDelete}
        // Search={filterData.SearchText}
        sortHandleClick={sorting}
        // success={deleteCostCenterSuccess}
        title={t('Data upload')}
      />
    </Box>
  )
}

export default UploadDataList
