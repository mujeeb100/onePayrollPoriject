import { Box } from '@mui/material'
import { useLazyGetUploadDataByIdQuery, useUploadDataCreateMutation } from 'api/inegrationServices'
import { ExcelIcon, FilesImg, RedCross } from 'assets/svg-images/SvgComponents'
import OPRButton from 'components/atoms/button/OPRButton'
import OPRLabel from 'components/atoms/label/OPRLabel'
import OPRStepper from 'components/atoms/stepper'
import OPRAlertControl from 'components/organism/OPRAlertControl'
import { OPRInnerFormLayout } from 'components/organism/OPRInnerFormLayout'
import { validationSchemaPensionfundscheme } from 'constants/validate'
import { useEditable } from 'hooks/useEdit'
import useForm from 'hooks/useForm'
import { useEffect, useRef, useState } from 'react'
import { FileWithPath } from 'react-dropzone'
import { useTranslation } from 'react-i18next'
import { useLocation, useNavigate } from 'react-router-dom'
import { routes } from 'routes/routes'
import { getParamsValue } from 'utils'

import FileUpload from './FileUpload'

export default function UploadDataForm() {
  const [Entity, setEntityFile]: any = useState<File | FileWithPath[] | any>(
    [],
  )
  const [Payroll, setPayrollFile]: any = useState<File | FileWithPath[] | any>(
    [],
  )
  const [Notification, setNotificationFile]: any = useState<File | FileWithPath[] | any>(
    [],
  )
  const [Employee, setEmployeeFile]: any = useState<
        File | FileWithPath[] | any
      >([])
  const [fileList, setFileList]: any = useState([Entity?.path,
    Employee?.path, Payroll?.path, Notification?.path])
  const myRef:any = useRef()
  const location: any = useLocation()
  const { id, viewUrl } = getParamsValue(location, routes.createUserRole)
  const [activeState, setActiveState] = useState(0)
  const { t } = useTranslation()
  const { isEditable, setEditable } = useEditable()
  const {
    values,
    setValues,
    errors,
    handleChange,
    setErrors,
    handleFormSubmit,
    handleOnChange,
  } = useForm(validationSchemaPensionfundscheme)

  const navigate = useNavigate()
  const [
    createuploadData,
    {
      data: createdUserRoleData,
      error: createdUserRoleError,
      isLoading: createdUserRoleLoading,
      isSuccess: createdUserRoleSuccess,
      isError: createdUserRoleIsError,
    },
  ] = useUploadDataCreateMutation()

  const [
    getTemplate,
    {
      data: updatedUserRoleByIdResponse,
      error: updatedUserRoleByIdError,
      isLoading: updatedUserRoleByIdLoading,
      isSuccess: updatedUserRoleByIdSuccess,
      isError: updatedUserRoleByIdIsError,
    },
  ] = useLazyGetUploadDataByIdQuery()
  //   useEffect(() => {
  //     if (id) {
  //       setValues(updatedUserRoleByIdResponse?.responseData)
  //     } else {
  //       setValues({})
  //       // setEditable(false)
  //     }
  //   }, [updatedUserRoleByIdResponse?.responseData,
  //   ])

  useEffect(() => {
    setFileList([Entity?.path, Employee?.path, Payroll?.path, Notification?.path])
  }, [Entity, Employee, Payroll, Notification])

  const handleSubmit: any = async () => {
    const formData = new FormData()
    formData.append('entity', Entity)
    formData.append('employee', Employee)
    formData.append('payroll', Payroll)
    formData.append('notification', Notification)
    createuploadData(formData)
  }
  useEffect(() => {
    if (id) {
    //   updateUserRoleById(id)
      setEditable(viewUrl)
    }
  }, [])

  useEffect(() => {
    if (createdUserRoleSuccess) {
      // Reset form values after successful add operation
      setValues({})
      setErrors({})
    }
  }, [createdUserRoleSuccess])

  const handlePermissionSubmit: any = async () => {
    if (activeState === 1) {
      setActiveState(activeState + 1)
    } else {
      myRef.current.childMethod()
    }
    // myRef.current.childMethod()
  }

  useEffect(() => {
    const createdUserRoleSuccessStatus = createdUserRoleSuccess || false
    if (createdUserRoleSuccessStatus) {
      if (activeState <= 1) {
        setActiveState(activeState + 1)
      }
    }
  }, [createdUserRoleSuccess])

  const downloadTemplateUrl: any = process.env.REACT_APP_DOWNLOAD_TEMPLATE_URL

  return (
    <Box sx={{ display: 'flex' }}>
      <div
        style={{ display: 'flex', width: '100% ' }}
        // onSubmit={(e) => {
        //   activeState === 0 ? handleFormSubmit(e, handleSubmit) : handlePermissionSubmit()
        // }}
      >
        <OPRAlertControl
          customMessage={`
            The files below has been submitted for bulk add and edit data.</br>
            </br>
            1. ENTITY - ${fileList[0] || ''}</br>
          2. EMPLOYEE - ${fileList[1] || ''}</br>
          3. PAYROLL - ${fileList[2] || ''}</br>
          4. NOTIFICATION - ${fileList[3] || ''}
          </br>
          </br>
          `}
          customTitle={t('Bulk add & edit data submitted')}
          handleEditable={setEditable}
          handleSetValue={setValues}
          handleSubmit={handleSubmit}
          isError={createdUserRoleIsError}
          isLoading={createdUserRoleLoading || updatedUserRoleByIdLoading}
          isSuccess={createdUserRoleSuccess}
          name=""
          previousUrl={routes.dataUpload}
          title={t('Bulk add & edit')}
          type={id ? 'Update' : 'New'}
        />
        <OPRInnerFormLayout
          isHandleContinueClick
          isStepper
          // customHeader={(
          //   <OPRLabel label={t('Bulk add & edit')} variant="h2" />
          // )}
          error={createdUserRoleError}
          handleBack={() => { setActiveState(activeState - 1) }}
          handleCancelClick={(e:any) => navigate(-1)}
          handleContinueClick={(e:any) => {
            let canSubmit = false
            for (let i = 0; i < fileList.length; i += 1) {
              if (fileList[i]) {
                canSubmit = true
                break
              }
            }
            if (activeState === 2) {
              if (canSubmit) {
                handleSubmit()
              }
            } else if (activeState === 1) {
              if (canSubmit) {
                setActiveState(activeState + 1)
              }
            } else {
              setActiveState(activeState + 1)
            }
          }}
          handleEditable={setEditable}
          isBackButton={activeState > 0}
          isConfirm={activeState === 3}
          isLoading={createdUserRoleLoading || updatedUserRoleByIdLoading}
          pageType="detailsPage"
          previousPageUrl={routes.dataUpload}
          subtitle={
            isEditable
              ? 'Please check the user details below.'
              : ''
          }
          title={t('Bulk add & edit')}
        >
          <Box>
            <OPRStepper
              activeStep={activeState}
              steps={[
                t('Download template'),
                t('bulk_upload_data_Upload'),
                t('pensionfund_scheme_step_confirmation'),
              ]}
            />
            {activeState === 0 && (
              <Box sx={{ mt: '30px' }}>
                <Box sx={{
                  padding: '24px', display: 'flex', flexDirection: 'row', gap: '6px', border: '1px solid #D4D2D3', borderRadius: '10px',
                }}
                >
                  <OPRLabel variant="body1">
                    {t('bulk_upload_data_first_note_title')}
                  </OPRLabel>
                  <OPRLabel variant="body2">{t('bulk_upload_data_first_note')}</OPRLabel>
                </Box>
                <Box sx={{
                  display: 'flex', flexDirection: 'row', gap: '10px', border: '1px solid #D4D2D3', borderRadius: '10px', mt: '24px', minHeight: '196px',
                }}
                >
                  <Box sx={{ backgroundColor: '#F7F5F6', padding: '40px 20px 0px' }}>
                    <FilesImg />
                  </Box>
                  <Box sx={{
                    display: 'flex', flexDirection: 'column', gap: '10px', padding: '40px 20px 0px', alignItems: 'flex-start',
                  }}
                  >
                    <OPRLabel CustomStyles={{ marginLeft: '14px' }} variant="body1">{t('bulk_upload_data_title')}</OPRLabel>
                    <OPRLabel CustomStyles={{ marginLeft: '14px' }} variant="body2">{t('bulk_upload_template_note')}</OPRLabel>
                    <OPRButton
                      variant="text"
                      onClick={() => {
                      // window.open(downloadTemplateUrl, '_blank')
                        // handleTemplate()
                      }}
                    >
                      {/* {t('bulk_upload_data_download_template_title')} */}
                      <a download href={downloadTemplateUrl}>{t('bulk_upload_data_download_template_title')}</a>
                    </OPRButton>
                  </Box>
                </Box>
              </Box>
            )}
            {activeState === 1 && (
              <Box sx={{ mt: '30px' }}>
                <Box sx={{
                  padding: '24px', display: 'flex', flexDirection: 'row', gap: '6px', border: '1px solid #D4D2D3', borderRadius: '10px',
                }}
                >
                  <OPRLabel variant="body1">
                    {t('bulk_upload_data_first_note_title')}
                  </OPRLabel>
                  <OPRLabel variant="body2">{t('bulk_upload_files_note')}</OPRLabel>
                </Box>
                <Box sx={{
                  mt: '24px',
                }}
                >
                  <OPRLabel variant="body1">{t('Entity')}</OPRLabel>
                  <FileUpload onFileUpload={(files) => {
                    setEntityFile(files)
                  }}
                  />
                  {fileList[0] && (
                    <Box sx={{
                      display: 'flex', flexDirection: 'row', justifyContent: 'space-between',
                    }}
                    >
                      <Box sx={{
                        display: 'flex', flexDirection: 'row', marginTop: '5px',
                      }}
                      >
                        <ExcelIcon />
                        <OPRLabel variant="body2">{fileList[0]}</OPRLabel>
                      </Box>
                      <OPRButton
                        variant="text"
                        onClick={() => {
                          setEntityFile(null)
                        }}
                      >
                        <RedCross />
                      </OPRButton>
                    </Box>
                  )}
                </Box>
                <Box sx={{
                  mt: '24px',
                }}
                >
                  <OPRLabel variant="body1">{t('Employee')}</OPRLabel>
                  <FileUpload onFileUpload={(files) => {
                    setEmployeeFile(files)
                  }}
                  />
                  {fileList[1] && (
                    <Box sx={{
                      display: 'flex', flexDirection: 'row', justifyContent: 'space-between',
                    }}
                    >
                      <Box sx={{
                        display: 'flex', flexDirection: 'row', marginTop: '5px',
                      }}
                      >
                        <ExcelIcon />
                        <OPRLabel variant="body2">
                          {fileList[1]}
                        </OPRLabel>
                      </Box>
                      <OPRButton
                        variant="text"
                        onClick={() => {
                          setEmployeeFile(null)
                        }}
                      >
                        <RedCross />
                      </OPRButton>
                    </Box>
                  )}
                </Box>
                <Box sx={{
                  mt: '24px',
                }}
                >
                  <OPRLabel variant="body1">{t('Payroll')}</OPRLabel>
                  <FileUpload onFileUpload={(files) => {
                    setPayrollFile(files)
                  }}
                  />
                  {fileList[2] && (
                    <Box sx={{
                      display: 'flex', flexDirection: 'row', justifyContent: 'space-between',
                    }}
                    >
                      <Box sx={{
                        display: 'flex', flexDirection: 'row', marginTop: '5px',
                      }}
                      >
                        <ExcelIcon />
                        <OPRLabel variant="body2">{fileList[2]}</OPRLabel>
                      </Box>
                      <OPRButton
                        variant="text"
                        onClick={() => {
                          setPayrollFile(null)
                        }}
                      >
                        <RedCross />
                      </OPRButton>
                    </Box>
                  )}
                </Box>
                <Box sx={{
                  mt: '24px',
                }}
                >
                  <OPRLabel variant="body1">{t('Notification')}</OPRLabel>
                  <FileUpload onFileUpload={(files) => {
                    setNotificationFile(files)
                  }}
                  />
                  {fileList[3] && (
                    <Box sx={{
                      display: 'flex', flexDirection: 'row', justifyContent: 'space-between',
                    }}
                    >
                      <Box sx={{
                        display: 'flex', flexDirection: 'row', marginTop: '5px',
                      }}
                      >
                        <ExcelIcon />
                        <OPRLabel variant="body2">{fileList[3]}</OPRLabel>
                      </Box>
                      <OPRButton
                        variant="text"
                        onClick={() => {
                          setNotificationFile(null)
                        }}
                      >
                        <RedCross />
                      </OPRButton>
                    </Box>
                  )}
                </Box>
              </Box>
            )}
            {activeState === 2 && (
              <Box sx={{ mt: '30px' }}>
                <Box sx={{
                  padding: '24px', display: 'flex', flexDirection: 'row', gap: '6px', border: '1px solid #D4D2D3', borderRadius: '10px',
                }}
                >
                  <OPRLabel variant="body1">
                    {t('bulk_upload_data_first_note_title')}
                  </OPRLabel>
                  <OPRLabel variant="body2">{t('bulk_upload_data_second_notes')}</OPRLabel>
                </Box>
                <Box sx={{
                  // display: 'flex', flexDirection: 'column', gap: '10px', padding: '40px 20px 0px', alignItems: 'flex-start',
                }}
                >
                  <OPRLabel CustomStyles={{ margin: '14px 0px' }} variant="body2">{t('bulk_upload_data_modal_heading')}</OPRLabel>
                  <ol>
                    {fileList[0] && (
                      <li>
                        <OPRLabel CustomStyles={{ marginTop: '2px', marginLeft: '14px' }} variant="body2">
                          {`ENTITY - ${fileList[0]}`}
                        </OPRLabel>
                      </li>
                    )}
                    {fileList[1] && (
                      <li>
                        <OPRLabel CustomStyles={{ marginTop: '2px', marginLeft: '14px' }} variant="body2">
                          {`EMPLOYEE - ${fileList[1]}`}
                        </OPRLabel>
                      </li>
                    )}
                    {fileList[2] && (
                      <li>
                        <OPRLabel CustomStyles={{ marginTop: '2px', marginLeft: '14px' }} variant="body2">
                          {`PAYROLL - ${fileList[2]}`}
                        </OPRLabel>
                      </li>
                    )}
                    {fileList[3] && (
                      <li>
                        <OPRLabel CustomStyles={{ marginTop: '2px', marginLeft: '14px' }} variant="body2">
                          {`NOTIFICATION - ${fileList[3]}`}
                        </OPRLabel>
                      </li>
                    )}
                  </ol>
                </Box>
              </Box>
            )}
          </Box>
        </OPRInnerFormLayout>
      </div>
    </Box>
  )
}
