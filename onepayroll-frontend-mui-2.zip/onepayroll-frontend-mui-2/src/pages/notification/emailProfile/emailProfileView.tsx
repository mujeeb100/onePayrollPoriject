import 'styles/style.css'

import { useTheme } from '@emotion/react'
import { Box, Grid } from '@mui/material'
import { useEmailProfileCreateMutation, useEmailProfileUpdateMutation, useLazyGetEmailProfileByIdQuery } from 'api/noticationServices'
import OPRButton from 'components/atoms/button/OPRButton'
import OPREmailInput from 'components/atoms/input/OPREmailInput'
import OPRLabel from 'components/atoms/label/OPRLabel'
import OPRInputControl from 'components/molecules/OPRInputControl'
import OPRResponsiveGrid from 'components/molecules/OPRResponsiveGrid'
import OPRAlertControl from 'components/organism/OPRAlertControl'
import { OPRInnerFormLayout } from 'components/organism/OPRInnerFormLayout'
import { validationSchemaEmail } from 'constants/validate'
import { useEditable } from 'hooks/useEdit'
import useForm from 'hooks/useForm'
import { t } from 'i18next'
import { useEffect, useState } from 'react'
import { useLocation, useNavigate } from 'react-router-dom'
import { routes } from 'routes/routes'
import { getParamsValue } from 'utils'

interface EmailProfileViewProps {
  // other props
  type: string;
}
export default function EmailProfileView() {
  const location: any = useLocation()
  const [recipientTOList, setRecipientTOList] = useState<string[]>([])
  const theme:any = useTheme()
  const { id, viewUrl } = getParamsValue(location, routes.viewEmailProfile)
  console.log(id, 'idididid', viewUrl)
  const { isEditable, setEditable } = useEditable()
  const [ccList, setCcList] = useState<string[]>([])
  const [bccList, setBccList] = useState<string[]>([])
  const {
    values,
    setValues,
    errors,
    handleChange,
    setErrors,
    handleFormSubmit,
  } = useForm(validationSchemaEmail)

  const navigate = useNavigate()
  const [
    createEmailProfile,
    {
      data: createdEmailProfileData,
      error: createdEmailProfileError,
      isLoading: createdEmailProfileLoading,
      isSuccess: createdEmailProfileSuccess,
      isError: createdEmailProfileIsError,
    },
  ] = useEmailProfileCreateMutation()

  const [
    updateEmailProfile,
    {
      data: updatedEmailProfileData,
      error: updatedEmailProfileError,
      isLoading: updatedEmailProfileLoading,
      isSuccess: updatedEmailProfileSuccess,
      isError: updatedEmailProfileIsError,
    },
  ] = useEmailProfileUpdateMutation()

  const [
    fetchEmailProfileById,
    {
      data: fetchedEmailProfileData,
      error: fetchedEmailProfileError,
      isLoading: fetchedEmailProfileLoading,
      isSuccess: fetchedEmailProfileSuccess,
      isError: fetchedEmailProfileIsError,
    },
  ] = useLazyGetEmailProfileByIdQuery()

  useEffect(() => {
    if (id) {
      fetchEmailProfileById(id)
      setEditable(viewUrl)
    }
  }, [])

  useEffect(() => {
    if (id && fetchedEmailProfileData) {
      const profileData = fetchedEmailProfileData.data
      setValues({
        emailProfileCode: profileData.emailProfileCode || '',
        emailProfileName: profileData.emailProfileName || '',
        sender: profileData.sender || '',
        recipientTOList: profileData.recipientTOList || [],
        recipientCCList: profileData.recipientCCList || [],
        recipientBCCList: profileData.recipientBCCList || [],
        setAsDefaultEmailProfile: profileData.setAsDefaultEmailProfile || false, // Include this line
      })
      setRecipientTOList(profileData.recipientTOList || [])
      setCcList(profileData.recipientCCList || [])
      setBccList(profileData.recipientBCCList || [])
    }
  }, [fetchedEmailProfileData])

  useEffect(() => {
    if (id) {
      setValues(fetchedEmailProfileData?.data)
    } else {
      setValues(location.state ? location.state : {})
    }
  }, [fetchedEmailProfileData?.data])

  const handleSubmit: any = async () => {
    // alert('click ')
    if (!isEditable) {
      // alert('is editable')
      if (id !== null) {
        await updateEmailProfile({
          id: fetchedEmailProfileData?.data?.id,
          emailProfileCode: values.emailProfileCode,
          emailProfileName: values.emailProfileName,
          setAsDefaultEmailProfile: values.setAsDefaultEmailProfile || false,
          sender: values.sender,
          recipientTOList,
          recipientCCList: ccList,
          recipientBCCList: bccList, // Include this line

        })
      } else {
        setEditable(true)
      }
    }
  }

  const onScreenClose:any = (item: any) => {
    setEditable(item)
    setValues({})
  }
  const handleEditClick = () => {
    setEditable(true)
  }

  return (
    <Box sx={{ display: 'flex', flexDirection: 'column', width: '100%' }}>
      {/* Conditionally render the Edit button */}
      {isEditable && fetchedEmailProfileSuccess && (
        <Box
          sx={{
            display: 'flex',
            justifyContent: 'flex-end',
            alignItems: 'center',
            padding: '16px', // Optional: Adjust padding as needed
          }}
        >
          <OPRButton
            color="primary"
            variant="contained" // or "outlined" depending on the style you want
            onClick={handleEditClick} // Set the form to editable mode
          >
            Edit email profile
          </OPRButton>
        </Box>
      )}
      <form
        style={{ display: 'flex', width: '100% ' }}
        onSubmit={(e) => handleFormSubmit(e, handleSubmit)}
      >
        <OPRAlertControl
          error={createdEmailProfileError || updatedEmailProfileError}
          handleEditable={setEditable}
          handleSetValue={setValues}
          handleSubmit={handleSubmit}
          isError={createdEmailProfileError || updatedEmailProfileError}
          isLoading={
            createdEmailProfileLoading
          || updatedEmailProfileLoading
          || fetchedEmailProfileLoading
          }
          isSuccess={updatedEmailProfileSuccess || createdEmailProfileSuccess}
          name={values?.profileDescription}
          title={t('emailProfile')}
          type={id ? 'Update' : 'New'}
        />

        <OPRInnerFormLayout
          error={createdEmailProfileError || updatedEmailProfileError}
          handleCancelClick={false}
          handleContinueClick={false}
          isEditable={isEditable}
          isLoading={
            createdEmailProfileLoading
          || updatedEmailProfileLoading
          || fetchedEmailProfileLoading
          }
          pageType="detailsPage"
          subtitle={
            isEditable
              ? 'Please check the profile details below.'
              : 'All fields are mandatory except those marked optional'
          }
          title={(viewUrl) ? values?.emailProfileCode : false || ((id) ? values?.emailProfileName : t('email profile'))} // Set title based on mode
          onScreenClose={onScreenClose}
        >
          <Box>
            <OPRResponsiveGrid>
              {/* header */}
              <Grid item xs={12}>
                <div className="ServiceProvider">
                  General information
                </div>
              </Grid>
              <Grid item md={2} sm={1} xs={1}>
                <OPRInputControl
                  disabled={!!id}
                  error={t(errors?.emailProfileCode)}
                  isEditable={isEditable}
                  label="email_ProfileCode"
                  name="emailProfileCode"
                  value={values?.emailProfileCode}
                  onChange={handleChange}
                />
              </Grid>
              <Grid item md={2} sm={1} xs={1}>
                <OPRInputControl
                  error={t(errors?.emailProfileName)}
                  isEditable={isEditable}
                  label="email_profileName"
                  name="emailProfileName"
                  value={values?.emailProfileName}
                  onChange={handleChange}
                />
              </Grid>
              <Grid item md={2} sm={1} xs={1}>
                <OPRLabel>Set as default email profile</OPRLabel>

                {isEditable ? (
                  <input
                    checked={values?.setAsDefaultEmailProfile}
                    name="setAsDefaultEmailProfile"
                    type="checkbox"
                    onChange={handleChange}
                  />
                ) : (
                  <div>{values?.setAsDefaultEmailProfile ? 'Yes' : 'No'}</div>
                )}
              </Grid>
              <Grid item md={2} sm={1} xs={1}>
                <OPRInputControl
                  error={t(errors?.sender)}
                  isEditable={isEditable}
                  label="Sender email"
                  name="sender"
                  value={values?.sender}
                  onChange={handleChange}
                />
              </Grid>

              <Grid item xs={12}>
                <div className="ServiceProvider">
                  Recipients
                </div>
              </Grid>
              <Grid item md={4} sm={1} xs={1}>
                <OPRLabel
                  CustomStyles={{
                    display: 'flex',
                    alignItems: 'flex-start',
                    gap: '0px',
                    alignSelf: 'stretch',
                    marginBottom: '10px',
                  }}
                >
                  {t('recipient_TOList')}
                  <span style={{ fontWeight: 'lighter' }}>
                      &nbsp;(Optional)
                  </span>
                </OPRLabel>
                <OPREmailInput
                  placeholder="recipients"
                  setValues={setRecipientTOList}
                  values={recipientTOList}
                />
                <OPRLabel color={errors?.recipient ? theme.palette.error.contrastText : ''} variant="body2">
                  {errors?.recipient}
                </OPRLabel>
              </Grid>

              <Grid item md={4} sm={1} xs={1}>
                <OPRLabel
                  CustomStyles={{
                    display: 'flex',
                    alignItems: 'flex-start',
                    gap: '0px',
                    alignSelf: 'stretch',
                    marginBottom: '10px',
                  }}
                >
                  {t('recipient_CCList')}
                  <span style={{ fontWeight: 'lighter' }}>
                      &nbsp;(Optional)
                  </span>
                </OPRLabel>
                <OPREmailInput
                  placeholder="cc"
                  setValues={setCcList}
                  values={ccList}
                />
                <OPRLabel color={errors?.cc ? theme.palette.error.contrastText : ''} variant="body2">
                  {errors?.cc}
                </OPRLabel>
              </Grid>

              <Grid item md={4} sm={1} xs={1}>
                <OPRLabel
                  CustomStyles={{
                    display: 'flex',
                    alignItems: 'flex-start',
                    gap: '0px',
                    alignSelf: 'stretch',
                    marginBottom: '10px',
                  }}
                >
                  {t('recipient_BCCList')}
                  <span style={{ fontWeight: 'lighter' }}>
                      &nbsp;(Optional)
                  </span>
                </OPRLabel>
                <OPREmailInput
                  placeholder="bcc"
                  setValues={setBccList}
                  values={bccList}
                />
                <OPRLabel color={errors?.bcc ? theme.palette.error.contrastText : ''} variant="body2">
                  {errors?.bcc}
                </OPRLabel>
              </Grid>

            </OPRResponsiveGrid>

            {/* Submit and Cancel buttons */}
            {viewUrl ? (
              <Box
                sx={{
                  display: 'flex',
                  justifyContent: 'space-between',
                  alignItems: 'center',
                  marginTop: 5,
                }}
              >
                { !isEditable && fetchedEmailProfileSuccess && (
                  <>
                    <OPRButton
                      color="info"
                      sx={{ marginRight: '16px' }}
                      variant="text"
                      onClick={() => navigate(-1)}
                    >
                      Cancel
                    </OPRButton>
                    <OPRButton
                      color="primary"
                      type="submit" // Set the type as "submit" to trigger form submission
                      variant="contained"
                      onClick={handleSubmit}
                    >
                      Continue
                    </OPRButton>
                  </>
                )}
              </Box>
            ) : (<div />)}
          </Box>
        </OPRInnerFormLayout>
      </form>
    </Box>
  )
}
