import {
  Box,
} from '@mui/material'
import { useEmailProfileDeleteMutation, useGetAllEmailProfileQuery } from 'api/noticationServices'
import { emailProfileColumn } from 'components/atoms/table/OPRTableConstant'
import { OPRDeleteControl } from 'components/molecules/OPRAlertControl/OPRDeleteControl'
import { OPRInnerListLayout } from 'components/organism/OPRInnerLayoutList'
import apiEndPoint from 'constants/apiEndPoint'
import { emailProfileColumnMappings } from 'constants/exportColumnMappings'
import { useTranslatedColumnsForPDF } from 'hooks/useTranslatedColumnsForPDF'
import React, { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { routes } from 'routes/routes'
import {
  generateFilterUrl, getAPIWithEntityUrl, getEnv, setRouteValues,
} from 'utils'

function EmailProfileList() {
  const navigate: any = useNavigate()
  const [selelctedDelete, setSelelctedDelete]:any = useState({
    data: {},
    isDelete: false,
    name: '',
  })
  const [filterData, setFilterData]:any = useState({
    pageNumber: 1,
    pageSize: 20,
    totalItems: 0,
    orderByAsc: true,
    sortBy: '',
    SearchText: '',
  })
  const {
    data: allPosts,
    isLoading: isLoadingAllPosts,
    isSuccess: isSuccessAllPosts,
    isError: isErrorAllPosts,
    error: errorAllPosts,
    refetch: refetchAllPosts,
  } = useGetAllEmailProfileQuery(generateFilterUrl(filterData))

  const [deleteEmailProfileById,
    {
      data: deleteEmailProfileResponse,
      error: deleteEmailProfileError,
      isLoading: deleteEmailProfileLoading,
      isSuccess: deleteEmailProfileSuccess,
      isError: deleteEmailProfileIsError,
    }] = useEmailProfileDeleteMutation()

  const sorting = (
    event: React.MouseEvent<unknown>,
    property: keyof any,
  ) => {
    const isAsc = filterData.sortBy === property && filterData.orderByAsc === true
    setFilterData({ ...filterData, orderByAsc: !isAsc, sortBy: property })
  }

  useEffect(() => {
    setFilterData({ ...filterData, totalItems: allPosts?.totalItems ? allPosts?.totalItems : 0 })
  }, [allPosts?.pageNumber, filterData.sortBy, filterData.orderByAsc, allPosts?.totalItems])

  const onSearch = (e: any, data: any) => {
    setFilterData({ ...filterData, ...data })
  }
  const handlePagination = (pageNumber: number, pageSize: number) => {
    setFilterData({ ...filterData, pageNumber })
  }
  const deleteRole = (data:any) => {
    deleteEmailProfileById(`emailProfileId=${data.id}`)
  }
  const viewAcoount = (data: any, type:string) => {
    if (type === 'Delete email profile') {
      setSelelctedDelete({ data, isDelete: true, name: data.emailProfileName })
    } else if (type === 'Edit email profile') {
      navigate(
        setRouteValues(`${routes.editEmailProfile}`, {
          id: data.id,
        }),
      )
    }
  }
  const handleView = (data: any) => {
    navigate(
      setRouteValues(`${routes.viewEmailProfile}`, {
        id: data.id,
        view: true,
      }),
    )
  }
  // handle Delete
  const handleDelete = (data:any) => {
    deleteEmailProfileById(`Id=${data.id}`)
  }
  return (
    <Box sx={{ display: 'flex' }}>
      <OPRDeleteControl
        deleteCallBack={deleteRole}
        selelctedUser={selelctedDelete}
        setSelelctedUser={setSelelctedDelete}
        title="User role"
      />
      <OPRInnerListLayout
        isExport
        Search={filterData.SearchText}
        addHandleClick={() => navigate(routes.createEmailProfile)}
        columns={emailProfileColumn(viewAcoount)}
        dataList={JSON.parse(JSON.stringify(allPosts?.records || []))}
        deleteCallBack={handleDelete}
        error={errorAllPosts || deleteEmailProfileError}
        exportProps={{
          data: allPosts?.records,
          fileName: 'emailProfile',
          columns: useTranslatedColumnsForPDF(emailProfileColumnMappings),
          pdf: {
            orientation: 'landscape',
          },
          allRecords: {
            baseURL: getEnv('REACT_APP_UP_BASE_URL', null),
            endpoint: getAPIWithEntityUrl(apiEndPoint.emailProfileList),
            filterData,
          },
        }}
        filterData={filterData}
        handlePagination={handlePagination}
        handleSearch={onSearch}
        isError={isErrorAllPosts || deleteEmailProfileIsError}
        loading={isLoadingAllPosts || deleteEmailProfileLoading}
        rowClickHandler={handleView}
        rowNumber={0}
        selelctedUser={selelctedDelete}
        setSelelctedUser={setSelelctedDelete}
        sortHandleClick={sorting}
        success={deleteEmailProfileSuccess}
        // title={t('email_profile')}
        title="Email profiles"
      />
    </Box>
  )
}

export default EmailProfileList
