import '../../../styles/style.css'

import {
  Box, Chip, Grid,
  useTheme,
} from '@mui/material'
import { useEmailProfileCreateMutation, useEmailProfileUpdateMutation, useLazyGetEmailProfileByIdQuery } from 'api/noticationServices'
import OPRCheckbox from 'components/atoms/checkbox/OPRCheckbox'
import OPREmailInput from 'components/atoms/input/OPREmailInput'
import OPRLabel from 'components/atoms/label/OPRLabel'
import OPRStepper from 'components/atoms/stepper'
import OPRInputControl from 'components/molecules/OPRInputControl'
import OPRResponsiveGrid from 'components/molecules/OPRResponsiveGrid'
import OPRAlertControl from 'components/organism/OPRAlertControl'
import { OPRInnerFormLayout } from 'components/organism/OPRInnerFormLayout'
import { validationSchemaEmail, validationSchemaEmail1 } from 'constants/validate'
import { useEditable } from 'hooks/useEdit'
import useForm from 'hooks/useForm'
import { useEffect, useRef, useState } from 'react'
import { useTranslation } from 'react-i18next'
import { useLocation, useNavigate } from 'react-router-dom'
import { routes } from 'routes/routes'
import { getParamsValue } from 'utils'

const validationSchema = (activeStep:any) => {
  switch (activeStep) {
    case 0:
      return validationSchemaEmail
    case 1:
      return validationSchemaEmail1
    default:
      return validationSchemaEmail
  }
}

export default function EmailProfileForm() {
  const myRef:any = useRef()
  const location: any = useLocation()
  const { id, viewUrl } = getParamsValue(location, routes.createEmailProfile)
  const [activeState, setActiveState] = useState(0)
  const { t } = useTranslation()
  const [recipientTOList, setRecipientTOList] = useState<string[]>([])
  const [ccList, setCcList] = useState<string[]>([])
  const [bccList, setBccList] = useState<string[]>([])
  const [defaultEmail, setDefaultEmail] = useState(false)
  const [recipienttext, setrecipienttext] = useState('')
  const { isEditable, setEditable } = useEditable()
  const theme:any = useTheme()
  const {
    values,
    setValues,
    errors,
    handleChange,
    setErrors,
    handleFormSubmit,
    handleOnChange,
  } = useForm(validationSchema(activeState))
  // } = useForm(activeState === 0 ? validationSchemaEmail : validationSchemaEmail1)

  const navigate = useNavigate()
  const [
    createemailProfile,
    {
      data: createdUserRoleData,
      error: createdUserRoleError,
      isLoading: createdUserRoleLoading,
      isSuccess: createdUserRoleSuccess,
      isError: createdUserRoleIsError,
    },
  ] = useEmailProfileCreateMutation()

  const [
    getEmailProfilById,
    {
      data: updatedUserRoleByIdResponse,
      error: updatedUserRoleByIdError,
      isLoading: updatedUserRoleByIdLoading,
      isSuccess: updatedUserRoleByIdSuccess,
      isError: updatedUserRoleByIdIsError,
    },
  ] = useLazyGetEmailProfileByIdQuery()

  const [
    updateEmailProfile,
    {
      data: updateEmailProfileResponse,
      error: updateEmailProfileError,
      isLoading: updateEmailProfileLoading,
      isSuccess: updateEmailProfileSuccess,
      isError: updateEmailProfileIsError,
    },
  ] = useEmailProfileUpdateMutation()

  const handleSubmit: any = async () => {
    if (id === null) {
      await createemailProfile({
        emailProfileCode: values.emailProfileCode,
        emailProfileName: values.emailProfileName,
        setAsDefaultEmailProfile: defaultEmail || false,
        sender: values.sender,
        recipientTOList,
        recipientCCList: ccList,
        recipientBCCList: bccList,
      })
    } else {
      await updateEmailProfile({
        id: updatedUserRoleByIdResponse?.data?.id,
        emailProfileCode: values.emailProfileCode,
        emailProfileName: values.emailProfileName,
        setAsDefaultEmailProfile: defaultEmail || false,
        sender: values.sender,
        recipientTOList,
        recipientCCList: ccList,
        recipientBCCList: bccList,
      })
    }
  }

  useEffect(() => {
    if (id) {
      setRecipientTOList(updatedUserRoleByIdResponse?.data?.recipientTOList)
      setBccList(updatedUserRoleByIdResponse?.data?.recipientBCCList)
      setCcList(updatedUserRoleByIdResponse?.data?.recipientCCList)
      setValues(updatedUserRoleByIdResponse?.data)
      setDefaultEmail(updatedUserRoleByIdResponse?.data?.setAsDefaultEmailProfile)
      setEditable(viewUrl)
    } else {
      setValues({})
      // setEditable(false)
    }
  }, [updatedUserRoleByIdResponse?.data])
  useEffect(() => {
    if (id) {
      getEmailProfilById(id)
      setEditable(viewUrl)
    }
  }, [])

  useEffect(() => {
    const createdUserRoleSuccessStatus = createdUserRoleSuccess || false
    if (createdUserRoleSuccessStatus) {
      if (activeState <= 1) {
        setActiveState(activeState + 1)
      }
    }
  }, [createdUserRoleSuccess])
  // Reset the Values
  // useEffect(() => {
  //   if (createdUserRoleSuccess) {
  //     // Reset form values after successful add operation
  //     setValues({})
  //     setErrors({})
  //   }
  // }, [createdUserRoleSuccess])
  const handleCancelClick = () => {
    setValues({})
    window.location.reload() // Reload the page
    setActiveState(0)
    // navigate((-1)) // Replace '/starting-page' with your desired route
  }
  return (
    <Box sx={{ display: 'flex' }}>
      <div
        style={{ display: 'flex', width: '100% ' }}
        // onSubmit={(e) => {
        //   activeState === 0 ? handleFormSubmit(e, handleSubmit) : handlePermissionSubmit()
        // }}
      >
        <OPRAlertControl
          customMessage={updateEmailProfileSuccess ? `${values?.emailProfileCode}-${values?.emailProfileName} has been Updated` : `${values?.emailProfileCode}-${values?.emailProfileName} has been added`}
          customTitle={updateEmailProfileSuccess ? 'Email profile updated' : 'New email profile added'}
          error={createdUserRoleError || updateEmailProfileError}
          handleEditable={setEditable}
          handleSetValue={handleCancelClick}
          handleSubmit={handleSubmit}
          isError={createdUserRoleIsError || updateEmailProfileIsError}
          isLoading={createdUserRoleLoading || updateEmailProfileLoading}
          isSuccess={createdUserRoleSuccess || updateEmailProfileSuccess}
          name={`${values?.emailProfileCode} - ${values?.emailProfileName}`}
          // previousUrl={routes.emailProfile}
          title={t('email_profile')}
          type={id ? 'Update' : 'New'}
        />
        <OPRInnerFormLayout
          isHandleContinueClick
          isStepper
          error={createdUserRoleError}
          // customHeader={(
          //   <OPRLabel label="email_profile" variant="h2" />
          // )}
          handleBack={() => {
            setErrors({})
            setActiveState(activeState - 1)
          }}
          handleCancelClick={(e:any) => navigate(-1)}
          handleContinueClick={(e:any) => {
            if (activeState === 0) {
              handleFormSubmit(e, () => setActiveState(activeState + 1))
              return
            }
            if (activeState === 2) {
              handleSubmit()
            }
            //  else if ((Object.keys(errors).length === 0 || Object.values(errors).every((value) => value === undefined))
            // && values?.sender && values?.emailProfileCode && values?.emailProfileName) {
            //   setActiveState(activeState + 1)
            // }
            setActiveState(activeState + 1)
          }}
          handleEditable={setEditable}
          isBackButton={activeState > 0}
          isConfirm={activeState === 2}
          isLoading={createdUserRoleLoading}
          pageType="detailsPage"
          // previousPageUrl={routes.emailProfile}
          step={activeState}
          subtitle={
            isEditable
              ? 'Please check the user details below.'
              : ''
          }
          // title={t('email_profile')}
          title="Add email profile"
        >
          <Box>
            <OPRStepper
              activeStep={activeState}
              steps={[
                t('gen_info'),
                t('Recipients'),
                t('pensionfund_scheme_step_confirmation'),
              ]}
            />
            {activeState === 0 && (
              <Box>
                <OPRLabel sx={{ marginTop: '20px', marginBottom: '30px' }} variant="body2">
                  {`  ${t('All fields are mandatory except those marked optional.')}`}
                </OPRLabel>
                <OPRResponsiveGrid>
                  <Grid item md={2} sm={1} xs={1}>
                    <OPRInputControl
                      error={t(errors?.emailProfileCode)}
                      isEditable={isEditable}
                      label="email_ProfileCode"
                      name="emailProfileCode"
                      value={values?.emailProfileCode}
                      onChange={handleChange}
                    />
                  </Grid>
                  <Grid item md={2} sm={1} xs={1}>
                    <OPRInputControl
                      error={t(errors?.emailProfileName)}
                      isEditable={isEditable}
                      label="email_profileName"
                      name="emailProfileName"
                      value={values?.emailProfileName}
                      onChange={handleChange}
                    />
                  </Grid>
                  <Grid item md={4} sm={1} xs={1}>
                    <OPRCheckbox
                      checked={defaultEmail}
                      label="Set as default email profile"
                      name="setAsDefaultEmailProfile"
                      onChange={() => setDefaultEmail(!defaultEmail)}
                    />
                  </Grid>
                  <Grid item md={4} sm={1} xs={1}>
                    <OPRInputControl
                      error={t(errors?.sender)}
                      isEditable={isEditable}
                      label="sender"
                      name="sender"
                      value={values?.sender}
                      onChange={handleChange}
                    />
                  </Grid>
                </OPRResponsiveGrid>
              </Box>
            )}
            {activeState === 1 && (
              <Box>
                <OPRLabel sx={{ marginTop: '20px', marginBottom: '30px' }} variant="body2">
                  {`  ${t('All fields are mandatory except those marked optional.')}`}
                </OPRLabel>
                <OPRResponsiveGrid>
                  <Grid item md={4} sm={1} xs={1}>
                    <OPRLabel
                      CustomStyles={{
                        display: 'flex',
                        alignItems: 'flex-start',
                        gap: '0px',
                        alignSelf: 'stretch',
                        marginBottom: '10px',
                      }}
                    >
                      {t('recipient_TOList')}
                      <span style={{ fontWeight: 'lighter' }}>
                      &nbsp;(Optional)
                      </span>
                    </OPRLabel>
                    <OPREmailInput
                      placeholder="recipients"
                      setValues={setRecipientTOList}
                      values={recipientTOList}
                    />
                    <OPRLabel color={errors?.recipient ? theme.palette.error.contrastText : ''} variant="body2">
                      {errors?.recipient}
                    </OPRLabel>
                  </Grid>

                  <Grid item md={4} sm={1} xs={1}>
                    <OPRLabel
                      CustomStyles={{
                        display: 'flex',
                        alignItems: 'flex-start',
                        gap: '0px',
                        alignSelf: 'stretch',
                        marginBottom: '10px',
                      }}
                    >
                      {t('recipient_CCList')}
                      <span style={{ fontWeight: 'lighter' }}>
                      &nbsp;(Optional)
                      </span>
                    </OPRLabel>
                    <OPREmailInput
                      placeholder="cc"
                      setValues={setCcList}
                      values={ccList}
                    />
                    <OPRLabel color={errors?.cc ? theme.palette.error.contrastText : ''} variant="body2">
                      {errors?.cc}
                    </OPRLabel>
                  </Grid>

                  <Grid item md={4} sm={1} xs={1}>
                    <OPRLabel
                      CustomStyles={{
                        display: 'flex',
                        alignItems: 'flex-start',
                        gap: '0px',
                        alignSelf: 'stretch',
                        marginBottom: '10px',
                      }}
                    >
                      {t('recipient_BCCList')}
                      <span style={{ fontWeight: 'lighter' }}>
                      &nbsp;(Optional)
                      </span>
                    </OPRLabel>
                    <OPREmailInput
                      placeholder="bcc"
                      setValues={setBccList}
                      values={bccList}
                    />
                    <OPRLabel color={errors?.bcc ? theme.palette.error.contrastText : ''} variant="body2">
                      {errors?.bcc}
                    </OPRLabel>
                  </Grid>
                </OPRResponsiveGrid>
              </Box>
            )}
            {activeState === 2 && (
              <Box>
                <OPRLabel sx={{ marginTop: '20px', marginBottom: '30px' }} variant="body2">
                  {`  ${t('Please check the details below.')}`}
                </OPRLabel>
                <OPRResponsiveGrid>
                  <div style={{ display: 'block', width: '100%', margin: '30px 18px 0' }}>
                    <OPRLabel variant="h2">{t('gen_info')}</OPRLabel>
                  </div>
                  <Grid item md={2} sm={1} xs={1}>
                    <OPRInputControl
                      isEditable
                      error={t(errors?.emailProfileCode)}
                      label="email_ProfileCode"
                      name="emailProfileCode"
                      value={values?.emailProfileCode}
                      onChange={handleChange}
                    />
                  </Grid>
                  <Grid item md={2} sm={1} xs={1}>
                    <OPRInputControl
                      isEditable
                      error={t(errors?.emailProfileName)}
                      label="email_profileName"
                      name="emailProfileName"
                      value={values?.emailProfileName}
                      onChange={handleChange}
                    />
                  </Grid>
                  <Grid item md={2} sm={1} xs={1}>
                    <OPRInputControl
                      isEditable
                      // error={t(errors?.emailProfileCode)}
                      label="setAs_DefaultEmail_Profile"
                      name="setAsDefaultEmailProfile"
                      value={defaultEmail ? 'Yes' : 'No'}
                      onChange={handleChange}
                    />
                  </Grid>
                  <Grid item md={2} sm={1} xs={1}>
                    <OPRInputControl
                      isEditable
                      error={t(errors?.sender)}
                      label="sender"
                      name="sender"
                      value={values?.sender}
                      onChange={handleChange}
                    />
                  </Grid>
                  <div style={{ display: 'block', width: '100%', margin: '30px 18px 0' }}>
                    <OPRLabel variant="h2">{t('recipients')}</OPRLabel>
                  </div>
                  <Grid item md={4} sm={1} xs={1}>
                    <OPRLabel
                      CustomStyles={{
                        display: 'flex',
                        alignItems: 'flex-start',
                        gap: '0px',
                        alignSelf: 'stretch',
                        marginBottom: '10px',
                      }}
                    >
                      {t('recipient_TOList')}
                    </OPRLabel>
                    {recipientTOList.map((option, index) => (
                      <Chip
                        label={option}
                        sx={{ margin: '3px' }}
                      />
                    ))}
                  </Grid>
                  <Grid item md={4} sm={1} xs={1}>
                    <OPRLabel
                      CustomStyles={{
                        display: 'flex',
                        alignItems: 'flex-start',
                        gap: '0px',
                        alignSelf: 'stretch',
                        marginBottom: '10px',
                      }}
                    >
                      {t('recipient_CCList')}
                    </OPRLabel>
                    {ccList.map((option, index) => (
                      <Chip
                        label={option}
                        sx={{ margin: '3px' }}
                      />
                    ))}
                  </Grid>
                  <Grid item md={4} sm={1} xs={1}>
                    <OPRLabel
                      CustomStyles={{
                        display: 'flex',
                        alignItems: 'flex-start',
                        gap: '0px',
                        alignSelf: 'stretch',
                        marginBottom: '10px',
                      }}
                    >
                      {t('recipient_BCCList')}
                    </OPRLabel>
                    {bccList.map((option, index) => (
                      <Chip
                        label={option}
                        sx={{ margin: '3px' }}
                      />
                    ))}
                  </Grid>
                </OPRResponsiveGrid>
              </Box>
            )}
          </Box>
        </OPRInnerFormLayout>
      </div>
    </Box>
  )
}
