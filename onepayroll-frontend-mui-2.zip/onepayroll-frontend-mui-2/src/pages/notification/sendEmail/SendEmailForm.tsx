import 'styles/style.css'

import { useTheme } from '@emotion/react'
import {
  Box,
  Button,
  Checkbox,
  Chip, Grid,
  MenuItem,
  Select,
} from '@mui/material'
import { useGetAllEmployeeProfileQuery } from 'api/employeeServices'
import {
  useGetAllEmailTemplateDropDownQuery, useGetAllEmailTemplatePlaceHolderQuery, useGetAllSendEmailDropDownQuery, useGetAllSendEmailProfileDropDownQuery, useGetEmployeesCreateMutation,
  useLazyGetEmailProfileByIdQuery,
  useLazyGetEmailTemplateByIdQuery,
  useSendEmailCreateMutation,
  useSendTestEmailCreateMutation,
} from 'api/noticationServices'
import {
  ExcelIcon, FilesImg, RedCross,
  RedInfo,
} from 'assets/svg-images/SvgComponents'
import OPRButton from 'components/atoms/button/OPRButton'
import OPRLabel from 'components/atoms/label/OPRLabel'
import OPRStepper from 'components/atoms/stepper'
import OPREnhancedTable from 'components/atoms/table/OPREnhancedTable'
import { movementModalColumn } from 'components/atoms/table/OPRTableConstant'
import { OPRSuccesControl } from 'components/molecules/OPRAlertControl/OPRSuccesControl'
import OPRDatePickerControl from 'components/molecules/OPRDatePickerControl/OPRDatePickerControl'
import OPRInputControl from 'components/molecules/OPRInputControl'
import OPRResponsiveGrid from 'components/molecules/OPRResponsiveGrid'
import OPRSelectorControl from 'components/molecules/OPRSelectorControl/OPRSelectorControl'
import OPRAlertControl from 'components/organism/OPRAlertControl'
import { OPRInnerFormLayout } from 'components/organism/OPRInnerFormLayout'
import {
  validationSchemaSendEmail,
  validationSchemaSendEmail1,
  validationSchemaSendEmailSteps2,
  validationSchemaSendEmailSteps3,
  validationSchemaSendEmailSteps4,
} from 'constants/validate'
import { useEditable } from 'hooks/useEdit'
import useForm from 'hooks/useForm'
import FileUpload from 'pages/uploadData/FileUpload'
import { useEffect, useRef, useState } from 'react'
import { FileWithPath } from 'react-dropzone'
import { useTranslation } from 'react-i18next'
import ReactQuill from 'react-quill'
import { useLocation, useNavigate } from 'react-router-dom'
import { routes } from 'routes/routes'
import { generateFilterUrl, getParamsValue } from 'utils'

import RichTextEditor from './TextEditor'

const validationSchema = (activeStep:any) => {
  switch (activeStep) {
    case 0:
      return validationSchemaSendEmail
    case 1:
      return validationSchemaSendEmail1
    case 2:
      return validationSchemaSendEmailSteps2
    case 3:
      return validationSchemaSendEmailSteps3
    case 4:
      return validationSchemaSendEmailSteps4
    default:
      return validationSchemaSendEmail
  }
}

export default function SendEmailForm() {
  const [emailFile, setEmailFile]: any = useState<File | FileWithPath[] | any>(
    [],
  )
  const [Payroll, setPayrollFile]: any = useState<File | FileWithPath[] | any>(
    [],
  )
  const [commonFile, setCommonFile]: any = useState<
        File | FileWithPath[] | any
      >([])
  // const [fileList, setFileList]: any = useState([Entity?.path,
  //   Employee?.path, Payroll?.path])
  const myRef:any = useRef()
  const richTextEditorRef = useRef<ReactQuill>(null)
  const location: any = useLocation()
  const { id, viewUrl } = getParamsValue(location, routes.createUserRole)
  const [activeState, setActiveState] = useState(0)
  const [employeeData, setEmployeeData] = useState([])
  const [checkedValue, setCheckedValue] = useState<any[]>([])
  const [selected, setSelected] = useState<readonly number[]>([])
  const { t } = useTranslation()
  const [emailContent, setEmailContent] = useState('')
  // for keyword
  const [cursorPosition, setCursorPosition] = useState<number | null>(null)
  const [showKeywordDropdown, setShowKeywordDropdown] = useState(false)
  const [selectedKeyword, setSelectedKeyword] = useState('')
  const [placeholderData, setPlaceholderData] = useState([])
  const [initialEmployeeData, setInitialEmployeeData]:any = useState([])
  const { isEditable, setEditable } = useEditable()
  const theme:any = useTheme() // Use the Theme type for the theme variable

  const {
    values,
    setValues,
    errors,
    handleChange,
    setErrors,
    handleFormSubmit,
    handleOnChange,
  // } = useForm(validationSchemaSendEmail)
  } = useForm(validationSchema(activeState))

  const {
    data: allData,
    error: createAllDatasBankAccountError,
    isLoading: isLoadingAllData,
    isSuccess: isSuccessAllData,
    isError: isErrorAllData,
    error: errorAllData,
  } = useGetAllSendEmailDropDownQuery('')

  const {
    data: emailProfileData,
    error: createAllEmailProfileError,
    isLoading: isLoadingEmailProfile,
    isSuccess: isSuccessEmailProfile,
    isError: isErrorEmailProfile,
    error: errorEmailProfile,
  } = useGetAllSendEmailProfileDropDownQuery('')

  const {
    data: emailTemplateData,
    error: createAllTemplateError,
    isLoading: isLoadingTemplate,
    isSuccess: isSuccessTemplate,
    isError: isErrorTemplate,
    error: errorTemplate,
  } = useGetAllEmailTemplateDropDownQuery('')

  const {
    data: employeeDataList,
    isLoading: isLoadingEmployeeDataList,
    isSuccess: isSuccessEmployeeDataList,
    isError: isErrorEmployeeDataList,
    error: errorEmployeeDataList,
  } = useGetAllEmployeeProfileQuery(generateFilterUrl({
    EffectiveDate: '10/10/2040',
  }))

  const navigate = useNavigate()
  const [
    createGetEmployees,
    {
      data: createdGetEmployeesData,
      error: createdGetEmployeesError,
      isLoading: createdGetEmployeesLoading,
      isSuccess: createdGetEmployeesSuccess,
      isError: createdGetEmployeesIsError,
    },
  ] = useGetEmployeesCreateMutation()

  const [
    createSendEmail,
    {
      data: createdSendEmailData,
      error: createdSendEmailError,
      isLoading: createdSendEmailLoading,
      isSuccess: createdSendEmailSuccess,
      isError: createdSendEmailIsError,
    },
  ] = useSendEmailCreateMutation()

  const [
    createSendTestEmail,
    {
      data: createdSendTestEmailData,
      error: createdSendTestEmailError,
      isLoading: createdSendTestEmailLoading,
      isSuccess: createdSendTestEmailSuccess,
      isError: createdSendTestEmailIsError,
    },
  ] = useSendTestEmailCreateMutation()

  const [getEmailTemplateById, {
    data: updatedEmailTemplateByIdResponse,
    error: updatedEmailTemplateByIdError,
    isLoading: updatedEmailTemplateByIdLoading,
    isSuccess: updatedEmailTemplateByIdSuccess,
    isError: updatedEmailTemplateByIdIsError,
  }] = useLazyGetEmailTemplateByIdQuery()

  const [
    getEmailProfileById,
    {
      data: getEmailProfileByIdResponse,
      error: getEmailProfileByIdError,
      isLoading: getEmailProfileByIdLoading,
      isSuccess: getEmailProfileByIdSuccess,
      isError: getEmailProfileByIdIsError,
    },
  ] = useLazyGetEmailProfileByIdQuery()

  // keyword email Template place holder
  const {
    data: AllRecordskeyWordPlaceHolderData,
    isLoading: isLoadingkeyWordPlaceHolderData,
    isSuccess: isSuccesskeyWordPlaceHolderData,
    isError: isErrorkeyWordPlaceHolderData,
    error: errorkeyWordPlaceHolderData,
  } = useGetAllEmailTemplatePlaceHolderQuery('')

  const handleSubmit: any = async () => {
    const formData = new FormData()
    checkedValue?.forEach((val, i) => {
      formData.append(`EmployeeDetails[${i}].EmployeeCode`, val?.employeeCode)
      // formData.append(`EmployeeProfileCodes[${i}]`, val?.employeeProfileCode);
    })
    formData.append('EmailProfileCodes[0]', values?.emailProfile?.label)
    // formData.append('EmailTemplateCode', values?.emailTemplate?.label);
    formData.append('EmailSubject', values?.emailSubject)
    formData.append('EmailContent', emailContent)
    formData.append('EmailDomainId', values?.emailDomain?.id)
    formData.append('FileAttachments', values?.commonFile)
    createSendEmail(formData)
  }

  const handleTestSubmit: any = async () => {
    const formData = new FormData()
    checkedValue?.forEach((val, i) => {
      formData.append(`EmployeeDetails[${i}].EmployeeCode`, val?.employeeCode)
      // formData.append(`EmployeeProfileCodes[${i}]`, val?.employeeProfileCode)
    })
    if (commonFile?.length > 0) {
      formData.append('CommonFileAttachments', commonFile)
    }
    formData.append('EmailProfileCodes[0]', values?.emailProfile?.label)
    formData.append('EmailSubject', values?.emailSubject)
    formData.append('EmailContent', emailContent)
    formData.append('TestEmailBox', values?.testEmailBox)
    formData.append('EmailDomainId', values?.emailDomain?.id)
    // logic for the not a valid email
    const selectedEmployeeCodes = checkedValue.map((item) => item.employeeCode).join(',')
    formData.append('employeeCodes', selectedEmployeeCodes)
    createSendTestEmail(formData)
  }

  const handleGetEmployees: any = async () => {
    const formData = new FormData()
    const formatDate = (date:any) => {
      const d = new Date(date)
      return `${d.getFullYear()}-${(`0${d.getMonth() + 1}`).slice(-2)}-${(`0${d.getDate()}`).slice(-2)}`
    }
    if (values?.emplFiltering?.id === 3) {
      if (!emailFile.path) {
        setErrors({ ...errors, emailFile: 'Please attach at least one file before proceeding.' })
      } else {
        formData.append('EmployeeFilterId', values?.emplFiltering?.id)
        formData.append('UploadEmployeeData', emailFile)
        createGetEmployees(formData)
      }
    } else if (values?.emplFiltering?.id === 2) {
      formData.append('EmployeeFilterId', values?.emplFiltering?.id)
      // formData.append('FromDate', formatDate(values?.FromDate))
      // formData.append('ToDate', formatDate(values?.ToDate))
      // new field has been added
      // selectedCodes.forEach((code:any) => formData.append('EmployeeCodes', code))
      createGetEmployees(formData)
    } else if (values?.emplFiltering?.id === 1) {
      formData.append('EmployeeFilterId', values?.emplFiltering?.id)
      if (values?.FromDate) {
        formData.append('FromDate', formatDate(values?.FromDate))
      }
      if (values?.ToDate) {
        formData.append('ToDate', formatDate(values?.ToDate))
      }
      createGetEmployees(formData)
    }
  }
  useEffect(() => {
    if (id) {
    //   updateUserRoleById(id)
      setEditable(viewUrl)
    }
  }, [])
  useEffect(() => {
    if (updatedEmailTemplateByIdSuccess) {
      setValues((prevValues:any) => ({
        ...prevValues,
        emailSubject: updatedEmailTemplateByIdResponse?.data?.emailSubject,
      }))
      // setValues({ ...values, emailSubject: updatedEmailTemplateByIdResponse?.data?.emailSubject })
      setEmailContent(updatedEmailTemplateByIdResponse?.data?.emailContent)
    }
  }, [updatedEmailTemplateByIdSuccess, updatedEmailTemplateByIdResponse])

  useEffect(() => {
    if (createdGetEmployeesSuccess) {
      setActiveState(activeState + 1)
      if (!employeeData.length) {
        setEmployeeData(createdGetEmployeesData?.data)
      }
    }
  }, [createdGetEmployeesSuccess, createdGetEmployeesError])

  const handlePermissionSubmit: any = async () => {
    if (activeState === 1) {
      setActiveState(activeState + 1)
    } else {
      myRef.current.childMethod()
    }
    // myRef.current.childMethod()
  }

  useEffect(() => {
    if (values?.emailProfile) {
      getEmailProfileById(values?.emailProfile?.id)
    }
  }, [values?.emailProfile])

  const handleSelectAllClick = (event: React.ChangeEvent<HTMLInputElement>) => {
    if ((event.target as HTMLInputElement).checked) {
      setSelected(JSON.parse(JSON.stringify(employeeData || []))?.map((n:any) => n.employeeCode))
      setCheckedValue(JSON.parse(JSON.stringify(employeeData || [])))
      return
    }
    setSelected([])
    setCheckedValue([])
  }

  const handleClick = (event: React.MouseEvent<unknown>, item: any) => {
    const selectedIndex = selected.indexOf(item.employeeCode)
    let newSelected: readonly number[] = []
    if (selectedIndex === -1) {
      newSelected = newSelected.concat(selected, item.employeeCode)
      setCheckedValue([
        ...checkedValue,
        item,
      ])
    } else if (selectedIndex === 0) {
      newSelected = newSelected.concat(selected.slice(1))
      setCheckedValue(checkedValue.filter((val) => val.employeeCode !== item.employeeCode))
    } else if (selectedIndex === selected.length - 1) {
      newSelected = newSelected.concat(selected.slice(0, -1))
      setCheckedValue(checkedValue.filter((val) => val.employeeCode !== item.employeeCode))
    } else if (selectedIndex > 0) {
      newSelected = newSelected.concat(
        selected.slice(0, selectedIndex),
        selected.slice(selectedIndex + 1),
      )
      setCheckedValue(checkedValue.filter((val) => val.employeeCode !== item.employeeCode))
    }
    setSelected(newSelected)
  }
  const isSelected = (employeeCode:any) => selected.indexOf(employeeCode) !== -1
  const downloadTemplateUrl: any = process.env.REACT_APP_DOWNLOAD_TEMPLATE_URL_EMAIL
  // useEffect(() => {
  //   if (employeeDataList && employeeDataList.records && employeeData.length === 0) {
  //     const initialData = employeeDataList.records.map((employee:any) => ({
  //       ...employee,
  //       selected: selected.includes(employee.employeeCode),
  //     }))
  //     setInitialEmployeeData(initialData)
  //     setEmployeeData(initialData)
  //   }
  // }, [employeeDataList, selected, employeeData.length])

  const handleBack = () => {
    setErrors({})
    if (activeState > 0) {
      if (activeState === 2) {
        // setEmployeeData(initialEmployeeData)
        setActiveState(activeState - 1)
      }
      setActiveState(activeState - 1)
    }
  }

  useEffect(() => {
    if (isSuccesskeyWordPlaceHolderData && AllRecordskeyWordPlaceHolderData) {
      setPlaceholderData(AllRecordskeyWordPlaceHolderData.emailTemplatePlaceholders)
    }
  }, [isSuccesskeyWordPlaceHolderData, AllRecordskeyWordPlaceHolderData])

  const handleKeywordButtonClick = () => {
    setShowKeywordDropdown(true)
  }

  const handleKeywordSelect = (event: any) => {
    const selected = event.target.value
    // const updatedEmailContent = `${values?.emailContent || ''} ${selected}`
    // setValues({ ...values, emailContent: updatedEmailContent }) // Update the form values
    // // setEmailContent(updatedEmailContent); // You might not need this line if emailContent is managed through form state
    // setShowKeywordDropdown(false)
    setSelectedKeyword(selected)
    const contentEditor = richTextEditorRef.current?.getEditor()
    if (contentEditor) {
      if (cursorPosition) {
        contentEditor.insertText(cursorPosition, selected)
        contentEditor.setSelection(cursorPosition + selected.length, 0)
      } else {
        contentEditor.insertText(0, selected)
        contentEditor.setSelection(selected.length, 0)
      }
    }
    setShowKeywordDropdown(false)
    setSelectedKeyword('')
  }
  return (
    <Box sx={{ display: 'flex' }}>
      <div
        style={{ display: 'flex', width: '100% ' }}
        // onSubmit={(e) => {
        //   activeState === 0 ? handleFormSubmit(e, handleSubmit) : handlePermissionSubmit()
        // }}
      >
        <OPRAlertControl
          isCustom
          customMessage={`
            </br>
            ${values?.emailSubject} email has been submitted.</br></br>
          Please allow some time for delivery to all intended recipients.</br></br>
          For more detailed information, please refer to the log file.
          `}
          customTitle="Send email notification submitted"
          error={createdGetEmployeesError || createdSendEmailError}
          handleEditable={setEditable}
          handleSetValue={setValues}
          handleSubmit={handleSubmit}
          isError={createdGetEmployeesIsError || createdSendEmailIsError || createdGetEmployeesError}
          isLoading={createdGetEmployeesLoading || createdSendEmailLoading || createdSendTestEmailLoading}
          isSuccess={createdSendEmailSuccess}
          name={t('email')}
          // previousUrl={routes.sendEmail}
          title={t('email')}
          type={id ? 'Update' : 'New'}
        />
        <OPRSuccesControl
          isEntity
          customMessage="Test Email notification submitted successfully"
          customTitle="Test Email notification submitted"
          error={createdGetEmployeesError}
          isError={createdGetEmployeesIsError}
          isSuccess={createdSendTestEmailSuccess}
          name={t('email')}
          title={t('Send email notification')}
          type="update"
        />
        <OPRInnerFormLayout
          isHandleContinueClick
          isStepper
          // customHeader={(
          //   <OPRLabel label="Send email notification" variant="h2" />
          // )}
          error={createdGetEmployeesError}
          handleBack={handleBack}
          handleCancelClick={(e:any) => navigate(-1)}
          handleContinueClick={(e:any) => {
            if (activeState === 0) {
              // Validate the form fields for the current step
              handleFormSubmit(e, () => {
                // If validation succeeds, proceed to the next step
                // setActiveState(activeState + 1)
                // Additional logic for fetching employees
                handleGetEmployees()
              })
            } else if (activeState === 1) {
              if (checkedValue.length > 0) {
                const formData = new FormData()
                checkedValue.forEach((val, i) => {
                  formData.append('EmployeeCodes', val.employeeCode)
                })
                formData.append('EmployeeFilterId', values?.emplFiltering?.id)
                if (commonFile?.length > 0) {
                  formData.append('CommonFileAttachments', commonFile)
                }
                // if (values?.emplFiltering?.id === 2) {
                //   const formatDate = (date:any) => {
                //     const d = new Date(date)
                //     return `${d.getFullYear()}-${(`0${d.getMonth() + 1}`).slice(-2)}-${(`0${d.getDate()}`).slice(-2)}`
                //   }
                //   formData.append('FromDate', formatDate(values?.FromDate))
                //   formData.append('ToDate', formatDate(values?.ToDate))
                // }

                createGetEmployees(formData)
                // setActiveState(activeState + 1)
              }
            } else if (activeState === 2) {
              handleFormSubmit(e, () => {
                if (values?.emailSubject && emailContent && values?.emailProfile) {
                  const formData = new FormData()
                  checkedValue?.forEach((val, i) => {
                    formData.append(`EmployeeDetails[${i}].EmployeeCode`, val?.employeeCode)
                  // formData.append(`EmployeeProfileCodes[${i}]`, val?.employeeProfileCode);
                  })
                  formData.append('EmailProfileCodes[0]', values?.emailProfile?.label)
                  // formData.append('EmailTemplateCode', values?.emailTemplate?.label);
                  formData.append('EmailSubject', values?.emailSubject)
                  formData.append('EmailContent', emailContent)
                  formData.append('EmailDomainId', values?.emailDomain?.id)
                  formData.append('FileAttachments', values?.commonFile)
                  // createSendEmail(formData)
                  setActiveState(activeState + 1)
                }
              })
            } else if (activeState === 5) {
              handleSubmit()
            } else {
              setActiveState(activeState + 1)
            }
          }}
          handleEditable={setEditable}
          isBackButton={activeState > 0}
          isConfirm={activeState === 5}
          isLoading={createdGetEmployeesLoading}
          pageType="detailsPage"
          // previousPageUrl={routes.sendEmail}
          step={activeState}
          subtitle={
            isEditable
              ? 'Please check the user details below.'
              : ''
          }
          title={t('Send email notification')}
        >
          <Box>
            <OPRStepper
              activeStep={activeState}
              steps={[
                t('Filtering'),
                t('Select employees'),
                t('Design email'),
                t('Attach file'),
                t('Test email'),
                t('Confirmation'),
              ]}
            />
            {activeState === 0 && (
              <Box>
                <Box sx={{
                  padding: '24px',
                  display: 'flex',
                  flexDirection: 'row',
                  gap: '6px',
                  border: '1px solid #D4D2D3',
                  borderRadius: '10px',
                  marginTop: '24px',
                  marginBottom: '24px',
                }}
                >
                  <OPRLabel variant="body1">{t('bulk_upload_data_first_note_title')}</OPRLabel>
                  <OPRLabel sx={{
                    marginTop: '2px',
                    fontSize: '0.875em',
                    fontWeight: 400,
                    fontStyle: 'normal',
                    fontFamily: 'Lato',
                    color: '#3B3839',
                  }}
                  >
                    {t('select_employee_filtering')}
                  </OPRLabel>
                </Box>

                <OPRResponsiveGrid>
                  <Grid item md={2} sm={1} xs={1}>
                    <OPRSelectorControl
                      error={errors?.emplFiltering}
                      isEditable={isEditable}
                      keyName="label"
                      label={t('empl_Filtering')}
                      multiple={false}
                      name="emplFiltering"
                      options={allData?.employeeTypes || []}
                      placeholder="Select"
                      value={values?.emplFiltering}
                      valueKey="id"
                      onChange={(text:any) => {
                        handleOnChange('emplFiltering', text)
                      }}
                    />
                  </Grid>
                  <Grid item md={2} sm={1} xs={1} />
                  {(values?.emplFiltering?.id === 1) && (
                    <>
                      <Grid item md={2} sm={1} xs={1}>

                        <OPRDatePickerControl
                          error={errors?.FromDate}
                          isEditable={isEditable}
                          label={t('commencement_FromDate')}
                          name="FromDate"
                          optionalText="optional"
                          // placeholder="DD/MM/YYYY"
                          value={values?.FromDate || null}
                          onChange={(date) => {
                            handleOnChange('FromDate', date)
                          }}
                        />
                      </Grid>
                      <Grid item md={2} sm={1} xs={1}>

                        <OPRDatePickerControl
                          error={errors?.ToDate}
                          isEditable={isEditable}
                          label={t('commencement_ToDate')}
                          name="ToDate"
                          optionalText="optional"
                          // placeholder="DD/MM/YYYY"
                          value={values?.ToDate || null}
                          onChange={(date) => {
                            handleOnChange('ToDate', date)
                          }}
                        />
                      </Grid>
                    </>
                  )}

                  {/* {(values?.emplFiltering?.id === 2) && (
                    <>
                      <Grid item md={2} sm={1} xs={1}>

                        <OPRDatePickerControl
                          error={errors?.FromDate}
                          isEditable={isEditable}
                          label={t('commencement_FromDate')}
                          name="FromDate"
                          value={values?.FromDate || null}
                          onChange={(date) => {
                            handleOnChange('FromDate', date)
                          }}
                        />
                      </Grid>
                      <Grid item md={2} sm={1} xs={1}>

                        <OPRDatePickerControl
                          error={errors?.ToDate}
                          isEditable={isEditable}
                          label={t('commencement_ToDate')}
                          name="ToDate"
                          value={values?.ToDate || null}
                          onChange={(date) => {
                            handleOnChange('ToDate', date)
                          }}
                        />
                      </Grid>
                    </>
                  )} */}
                  {values?.emplFiltering?.id === 3 && (
                    <>
                      <Box sx={{
                        display: 'flex',
                        flexDirection: 'row',
                        gap: '10px',
                        border: '1px solid #D4D2D3',
                        borderRadius: '10px',
                        mt: '24px',
                        minHeight: '196px',
                        marginLeft: '16px',
                      }}
                      >
                        <Box sx={{ backgroundColor: '#F7F5F6', padding: '40px 20px 0px' }}>
                          <FilesImg />
                        </Box>
                        <Box sx={{
                          display: 'flex', flexDirection: 'column', gap: '10px', padding: '40px 20px 0px', alignItems: 'flex-start',
                        }}
                        >
                          <OPRLabel CustomStyles={{ marginLeft: '14px' }} variant="body1">{t('upload_employees')}</OPRLabel>
                          <OPRLabel CustomStyles={{ marginLeft: '14px' }} variant="body2">{t('bulk_upload_template_note')}</OPRLabel>
                          <OPRButton
                            variant="text"
                            onClick={() => {
                              window.open(downloadTemplateUrl, '_blank')
                            }}
                          >
                            {t('bulk_upload_data_download_template_title')}
                          </OPRButton>
                        </Box>
                      </Box>
                      <Box sx={{
                        mt: '24px', marginLeft: '16px', width: '100%',
                      }}
                      >
                        <OPRLabel variant="body1">{t('email_records')}</OPRLabel>
                        <FileUpload onFileUpload={(files) => {
                          setEmailFile(files)
                        }}
                        />
                        {errors?.emailFile && (
                          <Box sx={{
                            display: 'flex', flexDirection: 'row', justifyContent: 'flex-start', gap: '10px', marginTop: '10px', backgroundColor: '#FEF5F8', width: '100%', padding: '10px',
                          }}
                          >
                            <RedInfo />
                            <OPRLabel variant="body2">{errors?.emailFile}</OPRLabel>
                          </Box>
                        )}
                        {emailFile?.path && (
                          <Box sx={{
                            display: 'flex', flexDirection: 'row', justifyContent: 'space-between',
                          }}
                          >
                            <Box sx={{
                              display: 'flex', flexDirection: 'row', marginTop: '5px',
                            }}
                            >
                              <ExcelIcon />
                              <OPRLabel variant="body2">{emailFile?.path}</OPRLabel>
                            </Box>
                            <OPRButton
                              variant="text"
                              onClick={() => {
                                setEmailFile(null)
                              }}
                            >
                              <RedCross />
                            </OPRButton>
                          </Box>
                        )}
                      </Box>
                    </>
                  )}
                </OPRResponsiveGrid>
              </Box>
            )}
            {activeState === 1 && (
              <Box>
                <Box sx={{
                  padding: '24px',
                  display: 'flex',
                  flexDirection: 'row',
                  gap: '6px',
                  border: '1px solid #D4D2D3',
                  borderRadius: '10px',
                  marginTop: '24px',
                  marginBottom: '24px',
                }}
                >
                  <OPRLabel variant="body1">
                    {t('bulk_upload_data_first_note_title')}
                  </OPRLabel>
                  <OPRLabel sx={{
                    marginTop: '2px',
                    fontSize: '0.875em',
                    fontWeight: 400,
                    fontStyle: 'normal',
                    fontFamily: 'Lato',
                    color: '#3B3839',
                  }}
                  >
                    {t('select_email_rec_note')}
                  </OPRLabel>
                </Box>
                <div style={{ display: 'block', width: '100%', margin: '30px 20px 20px' }}>
                  <OPRLabel variant="h2">Email Records</OPRLabel>
                </div>
                <OPRResponsiveGrid>
                  <Box sx={{
                    display: 'flex',
                    flexDirection: 'row',
                    alignItems: 'center',
                  }}
                  >
                    <Checkbox
                      checked={selected.length === employeeData?.length}
                      indeterminate={selected.length > 0 && selected.length < employeeData?.length}
                      onChange={handleSelectAllClick}
                    />
                    <OPRLabel variant="body2">Select All</OPRLabel>
                  </Box>
                  <OPREnhancedTable
                    isMovement
                    cols={movementModalColumn(handleClick)}
                    data={JSON.parse(JSON.stringify(employeeData || []))}
                    handleClick={handleClick}
                    isSelected={isSelected}
                    steps={1}
                  />
                  <div style={{
                    width: '100%',
                    padding: 12,
                    background: '#E9F4FF',
                    borderRadius: 4,
                    justifyContent: 'flex-start',
                    alignItems: 'flex-start',
                    gap: 12,
                    display: 'inline-flex',
                  }}
                  >
                    <div style={{
                      flex: '1 1 0',
                      flexDirection: 'column',
                      justifyContent: 'flex-start',
                      alignItems: 'flex-start',
                      display: 'inline-flex',
                    }}
                    >
                      <div style={{
                        alignSelf: 'stretch',
                        color: '#3B3839',
                        fontSize: 16,
                        fontFamily: 'Lato',
                        fontWeight: '700',
                        wordWrap: 'break-word',
                      }}
                      >
                        Total selected employees:
                        {' '}
                        {selected.length}
                      </div>
                    </div>
                  </div>

                </OPRResponsiveGrid>
              </Box>
            )}
            {activeState === 2 && (
              <Box>
                <Box sx={{
                  padding: '24px',
                  display: 'flex',
                  flexDirection: 'row',
                  gap: '6px',
                  border: '1px solid #D4D2D3',
                  borderRadius: '10px',
                  marginTop: '24px',
                  marginBottom: '24px',
                }}
                >
                  <OPRLabel variant="body1">
                    {t('bulk_upload_data_first_note_title')}
                  </OPRLabel>
                  <OPRLabel variant="body2">{t('select_email_template_note')}</OPRLabel>
                </Box>
                <OPRLabel sx={{ marginTop: '20px' }} variant="body2">
                  {`  ${t('All fields are mandatory except those marked optional')}`}
                </OPRLabel>
                <div style={{ display: 'block', width: '100%', margin: '30px 20px 20px' }}>
                  <OPRLabel variant="h2">Email</OPRLabel>
                </div>
                <OPRResponsiveGrid>
                  <Grid item md={4} sm={1} xs={1}>
                    <OPRSelectorControl
                      error={errors?.emailTemplate}
                      isEditable={isEditable}
                      keyName="label"
                      label={t('email_template')}
                      multiple={false}
                      name="emailTemplate"
                      optionalText={t('optional')}
                      options={emailTemplateData?.emailTemplates || []}
                      placeholder="Select"
                      value={values?.emailTemplate}
                      valueKey="id"
                      onChange={(text:any) => {
                        handleOnChange('emailTemplate', text)
                        getEmailTemplateById(text?.id)
                      }}
                    />
                  </Grid>
                  {/* keyword feature */}
                  <Grid item md={4} sm={1} xs={1}>
                    <Box
                      style={{
                        width: '100%',
                        height: '100%',
                        borderRadius: 110,
                        overflow: 'hidden',
                        justifyContent: 'flex-start',
                        alignItems: 'center',
                        gap: 12,
                        display: 'inline-flex',
                        textAlign: 'left',
                      }}
                    >
                      <div
                        style={{
                          width: 16,
                          height: 16,
                          position: 'relative',
                        }}
                      >
                        <div style={{
                          width: 12,
                          height: 12,
                          left: 2,
                          top: 2,
                          position: 'absolute',
                          background: '#0049DB',
                        }}
                        />

                      </div>
                      <div>
                        <Button
                          className="ServiceProvider"
                          style={{
                            color: '#0049DB',
                            fontSize: 16,
                            fontFamily: 'Lato',
                            fontWeight: '700',
                            wordWrap: 'break-word',
                          }}
                          onClick={handleKeywordButtonClick}
                        >
                          Keyword
                        </Button>
                        {showKeywordDropdown && (
                          <Select
                            autoFocus
                            displayEmpty
                            value={selectedKeyword}
                            onChange={handleKeywordSelect}
                          >
                            {placeholderData.map((placeholder: any) => (
                              <MenuItem key={placeholder.label} value={placeholder.label}>
                                {placeholder.label}
                              </MenuItem>
                            ))}
                          </Select>
                        )}
                      </div>
                    </Box>
                  </Grid>
                  <Grid item md={4} sm={1} xs={1}>
                    <OPRInputControl
                      error={t(errors?.emailSubject)}
                      isEditable={isEditable}
                      label="email_subject"
                      name="emailSubject"
                      value={values?.emailSubject}
                      onChange={handleChange}
                    />
                  </Grid>
                  <Grid item md={4} sm={1} xs={1}>
                    <OPRLabel
                      CustomStyles={{
                        display: 'flex',
                        alignItems: 'flex-start',
                        gap: '0px',
                        alignSelf: 'stretch',

                      }}
                    >
                      {t('email_content')}
                    </OPRLabel>
                    <RichTextEditor
                      ref={richTextEditorRef}
                      getSelection={setCursorPosition}
                      isEditable={!isEditable}
                      setValue={(e:any) => setEmailContent(e)}
                      value={emailContent}
                    />

                    {/* <OPRLabel color={theme.palette.error.contrastText} variant="body2">{errors.emailContent}</OPRLabel> */}
                  </Grid>
                  <Grid item xs={12}>
                    <div
                      className="ServiceProvider"
                    >
                      Email profile
                    </div>
                  </Grid>
                  <Grid item md={2} sm={1} xs={1}>
                    <OPRSelectorControl
                      error={errors?.emailProfile}
                      isEditable={isEditable}
                      keyName="label"
                      label={t('email_profile')}
                      multiple={false}
                      name="emailProfile"
                      options={emailProfileData?.emailProfiles || []}
                      placeholder="Select"
                      value={values?.emailProfile}
                      valueKey="id"
                      onChange={(text:any) => {
                        handleOnChange('emailProfile', text)
                      }}
                    />
                  </Grid>
                  <Grid item md={2} sm={1} xs={1} />
                  {(values?.emailProfile?.id && getEmailProfileByIdResponse) && (
                    <>
                      <Grid item md={2} sm={1} xs={1}>
                        <OPRInputControl
                          isEditable
                          error={t(errors?.sender)}
                          label="sender"
                          name="sender"
                          value={getEmailProfileByIdResponse?.data?.sender}
                          onChange={handleChange}
                        />
                      </Grid>
                      <Grid item md={4} sm={1} xs={1}>
                        <OPRLabel
                          CustomStyles={{
                            display: 'flex',
                            alignItems: 'flex-start',
                            gap: '0px',
                            alignSelf: 'stretch',
                            marginBottom: '10px',
                          }}
                        >
                          {t('recipient_TOList')}
                        </OPRLabel>
                        {getEmailProfileByIdResponse?.data?.recipientTOList.map((option:any, index:any) => (
                          <Chip
                            label={option}
                            sx={{ margin: '3px' }}
                          />
                        ))}
                      </Grid>
                      <Grid item md={4} sm={1} xs={1}>
                        <OPRLabel
                          CustomStyles={{
                            display: 'flex',
                            alignItems: 'flex-start',
                            gap: '0px',
                            alignSelf: 'stretch',
                            marginBottom: '10px',
                          }}
                        >
                          {t('recipient_CCList')}
                        </OPRLabel>
                        {getEmailProfileByIdResponse?.data?.recipientCCList.map((option:any, index:any) => (
                          <Chip
                            label={option}
                            sx={{ margin: '3px' }}
                          />
                        ))}
                      </Grid>
                      <Grid item md={4} sm={1} xs={1}>
                        <OPRLabel
                          CustomStyles={{
                            display: 'flex',
                            alignItems: 'flex-start',
                            gap: '0px',
                            alignSelf: 'stretch',
                            marginBottom: '10px',
                          }}
                        >
                          {t('recipient_BCCList')}
                        </OPRLabel>
                        {getEmailProfileByIdResponse?.data?.recipientBCCList.map((option:any, index:any) => (
                          <Chip
                            label={option}
                            sx={{ margin: '3px' }}
                          />
                        ))}
                      </Grid>
                    </>
                  )}
                </OPRResponsiveGrid>
              </Box>
            )}
            {activeState === 3 && (
              <Box>
                <Box sx={{
                  padding: '24px',
                  display: 'flex',
                  flexDirection: 'row',
                  gap: '6px',
                  border: '1px solid #D4D2D3',
                  borderRadius: '10px',
                  marginTop: '24px',
                  marginBottom: '24px',
                }}
                >
                  <OPRLabel variant="body1">
                    {t('bulk_upload_data_first_note_title')}
                  </OPRLabel>
                  <OPRLabel variant="body2">{t('attach_file_recipients')}</OPRLabel>
                </Box>
                <OPRResponsiveGrid>
                  <Box sx={{
                    mt: '24px', marginLeft: '16px', width: '100%',
                  }}
                  >
                    <OPRLabel variant="body1">{t('attach_common_file')}</OPRLabel>
                    <FileUpload onFileUpload={(files:any) => {
                      setCommonFile([...commonFile, files])
                    }}
                    />
                    {commonFile[0]?.path && (
                      commonFile.map((file:any) => (
                        <Box sx={{
                          display: 'flex', flexDirection: 'row', justifyContent: 'space-between',
                        }}
                        >
                          <Box sx={{
                            display: 'flex', flexDirection: 'row', marginTop: '5px',
                          }}
                          >
                            <ExcelIcon />
                            <OPRLabel variant="body2">{file?.path}</OPRLabel>
                          </Box>
                          <OPRButton
                            variant="text"
                            onClick={() => {
                              setCommonFile(commonFile.filter((val:any) => val?.path !== file?.path))
                            }}
                          >
                            <RedCross />
                          </OPRButton>
                        </Box>
                      ))
                    )}
                  </Box>
                </OPRResponsiveGrid>
              </Box>
            )}
            {activeState === 4 && (
              <Box>
                <Box sx={{
                  padding: '24px',
                  display: 'flex',
                  flexDirection: 'row',
                  gap: '6px',
                  border: '1px solid #D4D2D3',
                  borderRadius: '10px',
                  marginTop: '24px',
                  marginBottom: '24px',
                }}
                >
                  <OPRLabel variant="body1">
                    {t('bulk_upload_data_first_note_title')}
                  </OPRLabel>
                  <OPRLabel variant="body2">{t('select_employee_test_email_note')}</OPRLabel>
                </Box>
                <div style={{ display: 'block', width: '100%', margin: '30px 20px 20px' }}>
                  <OPRLabel variant="h2">Test email recipient</OPRLabel>
                </div>
                <OPRResponsiveGrid>
                  <Grid item md={2} sm={1} xs={1}>
                    <OPRInputControl
                      error={t(errors?.testEmailBox)}
                      isEditable={isEditable}
                      label="email_box"
                      name="testEmailBox"
                      value={values?.testEmailBox}
                      onChange={handleChange}
                    />
                  </Grid>
                  <Grid item md={2} sm={1} xs={1}>
                    <OPRSelectorControl
                      error={errors?.emailDomain}
                      isEditable={isEditable}
                      keyName="label"
                      label={t('email_domain')}
                      multiple={false}
                      name="emailDomain"
                      options={[{ id: '4094fce4-51a4-45bf-a7ae-3dbef5d02cc5', label: 'my.tricorglobal.com' }, { id: 'efe289aa-2abd-4100-8b2c-a34b61208843', label: 'hk.tricorglobal.com' }]}
                      placeholder="Select"
                      value={[{ id: '4094fce4-51a4-45bf-a7ae-3dbef5d02cc5', label: 'my.tricorglobal.com' }, { id: 'efe289aa-2abd-4100-8b2c-a34b61208843', label: 'hk.tricorglobal.com' }].find((o:any) => o?.id === values?.emailDomain?.id)}
                      valueKey="id"
                      onChange={(text:any) => {
                        handleOnChange('emailDomain', text)
                      }}
                    />
                  </Grid>
                  <div style={{ display: 'block', width: '100%', margin: '30px 20px 20px' }}>
                    <OPRLabel variant="h2">Email Records</OPRLabel>
                  </div>
                  <Box sx={{
                    display: 'flex',
                    flexDirection: 'row',
                    alignItems: 'center',
                  }}
                  >
                    <Checkbox
                      checked={selected.length === checkedValue?.length}
                      indeterminate={selected.length > 0 && selected.length < checkedValue?.length}
                      onChange={handleSelectAllClick}
                    />
                    <OPRLabel variant="body2">Select All</OPRLabel>
                  </Box>
                  <OPREnhancedTable
                    isMovement
                    cols={movementModalColumn(handleClick)}
                    data={checkedValue || []}
                    handleClick={handleClick}
                    isSelected={isSelected}
                    steps={1}
                  />
                  <Box sx={{
                    display: 'flex', flexDirection: 'row', justifyContent: 'space-between', gap: '10px', marginTop: '10px', backgroundColor: '#E9F4FF', width: '100%',
                  }}
                  >
                    <div style={{
                      width: '100%',
                      padding: 12,
                      background: '#E9F4FF',
                      borderRadius: 4,
                      justifyContent: 'flex-start',
                      alignItems: 'flex-start',
                      gap: 12,
                      display: 'inline-flex',
                    }}
                    >
                      <div style={{
                        flex: '1 1 0',
                        flexDirection: 'column',
                        justifyContent: 'flex-start',
                        alignItems: 'flex-start',
                        display: 'inline-flex',
                      }}
                      >
                        <div style={{
                          alignSelf: 'stretch',
                          color: '#3B3839',
                          fontSize: 16,
                          fontFamily: 'Lato',
                          fontWeight: '700',
                          wordWrap: 'break-word',
                        }}
                        >
                          Total selected employees:
                          {' '}
                          {checkedValue.length}
                        </div>
                      </div>
                    </div>
                    {/* <OPRLabel label={`Total selected employees:${checkedValue?.length}`} variant="body2" /> */}
                    <OPRButton
                      variant="text"
                      onClick={(e:any) => {
                        handleFormSubmit(e, () => {
                          handleTestSubmit()
                        })
                      }}
                    >
                      Send test email
                    </OPRButton>
                  </Box>
                </OPRResponsiveGrid>
              </Box>
            )}
            {activeState === 5 && (
              <Box>
                <OPRLabel sx={{ marginTop: '20px' }} variant="body2">
                  {`  ${t('please_check_details_below')}`}
                </OPRLabel>
                <div style={{ display: 'block', width: '100%', margin: '30px 0px 10px' }}>
                  <OPRLabel variant="h2">Email Information</OPRLabel>
                </div>
                <OPRResponsiveGrid>
                  <Grid item md={4} sm={1} xs={1}>
                    <OPRSelectorControl
                      isEditable
                      error={errors?.emailTemplate}
                      keyName="label"
                      label={t('email_template')}
                      multiple={false}
                      name="emailTemplate"
                      options={emailTemplateData?.emailTemplates || []}
                      placeholder="Select"
                      value={values?.emailTemplate}
                      valueKey="label"
                      onChange={(text:any) => {
                        handleOnChange('emailTemplate', text)
                      }}
                    />
                  </Grid>
                  <Grid item md={4} sm={1} xs={1}>
                    <OPRInputControl
                      isEditable
                      error={t(errors?.emailSubject)}
                      label="email_subject"
                      name="emailSubject"
                      value={values?.emailSubject}
                      onChange={handleChange}
                    />
                  </Grid>
                  <Grid item md={4} sm={1} xs={1}>
                    <OPRLabel
                      CustomStyles={{
                        display: 'flex',
                        alignItems: 'flex-start',
                        gap: '0px',
                        alignSelf: 'stretch',

                      }}
                    >
                      {t('email_content')}
                    </OPRLabel>
                    <RichTextEditor
                      setValue={(e:any) => setEmailContent(e)}
                      showToolbar={false}
                      style={{ border: '0px none #FFFFFF !important' }}
                      value={emailContent}
                    />
                  </Grid>
                  <div style={{ display: 'block', width: '100%', margin: '30px 0px 10px' }}>
                    <OPRLabel variant="h2">Email Profile</OPRLabel>
                  </div>
                  <Grid item md={4} sm={1} xs={1}>
                    <OPRSelectorControl
                      isEditable
                      error={errors?.emailProfile}
                      keyName="label"
                      label={t('email_profile')}
                      multiple={false}
                      name="emailProfile"
                      options={emailProfileData?.emailProfiles || []}
                      placeholder="Select"
                      value={values?.emailProfile}
                      valueKey="label"
                      onChange={(text:any) => {
                        handleOnChange('emailProfile', text)
                      }}
                    />
                  </Grid>
                  <Grid item md={2} sm={1} xs={1}>
                    <OPRInputControl
                      isEditable
                      error={t(errors?.sender)}
                      label="sender"
                      name="sender"
                      value={getEmailProfileByIdResponse?.data?.sender}
                      onChange={handleChange}
                    />
                  </Grid>
                  <Grid item md={4} sm={1} xs={1}>
                    <OPRLabel
                      CustomStyles={{
                        display: 'flex',
                        alignItems: 'flex-start',
                        gap: '0px',
                        alignSelf: 'stretch',
                        marginBottom: '10px',
                      }}
                    >
                      {t('recipient_TOList')}
                    </OPRLabel>
                    {getEmailProfileByIdResponse?.data?.recipientTOList.map((option:any, index:any) => (
                      <Chip
                        label={option}
                        sx={{ margin: '3px' }}
                      />
                    ))}
                  </Grid>
                  <Grid item md={4} sm={1} xs={1}>
                    <OPRLabel
                      CustomStyles={{
                        display: 'flex',
                        alignItems: 'flex-start',
                        gap: '0px',
                        alignSelf: 'stretch',
                        marginBottom: '10px',
                      }}
                    >
                      {t('recipient_CCList')}
                    </OPRLabel>
                    {getEmailProfileByIdResponse?.data?.recipientCCList.map((option:any, index:any) => (
                      <Chip
                        label={option}
                        sx={{ margin: '3px' }}
                      />
                    ))}
                  </Grid>
                  <Grid item md={4} sm={1} xs={1}>
                    <OPRLabel
                      CustomStyles={{
                        display: 'flex',
                        alignItems: 'flex-start',
                        gap: '0px',
                        alignSelf: 'stretch',
                        marginBottom: '10px',
                      }}
                    >
                      {t('recipient_BCCList')}
                    </OPRLabel>
                    {getEmailProfileByIdResponse?.data?.recipientBCCList.map((option:any, index:any) => (
                      <Chip
                        label={option}
                        sx={{ margin: '3px' }}
                      />
                    ))}
                  </Grid>
                  <div style={{ display: 'block', width: '100%', margin: '30px 0px 10px' }}>
                    <OPRLabel variant="h2">Attached common file</OPRLabel>
                  </div>
                  {commonFile[0]?.path && (
                    commonFile.map((file:any) => (
                      <Box sx={{
                        display: 'flex', flexDirection: 'row', justifyContent: 'space-between',
                      }}
                      >
                        <Box sx={{
                          display: 'flex', flexDirection: 'row', marginTop: '5px',
                        }}
                        >
                          <ExcelIcon />
                          <OPRLabel variant="body2">{file?.path}</OPRLabel>
                        </Box>
                      </Box>
                    ))
                  )}
                  <div style={{ display: 'block', width: '100%', margin: '30px 0px 10px' }}>
                    <OPRLabel variant="h2">Email records</OPRLabel>
                  </div>
                  <OPREnhancedTable
                    isMovement
                    cols={movementModalColumn(handleClick)}
                    data={checkedValue || []}
                    handleClick={handleClick}
                    isSelected={isSelected}
                  />
                </OPRResponsiveGrid>
              </Box>
            )}
          </Box>
        </OPRInnerFormLayout>
      </div>
    </Box>
  )
}
