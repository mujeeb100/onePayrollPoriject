import {
  Box,
  Button,
  Chip,
  Grid,
  MenuItem,
  Select,
  Tab,
  Tabs,
} from '@mui/material'
import { useGetAllEmployeeProfileQuery } from 'api/employeeServices'
import {
  useGetAllEmailTemplateDropDownQuery, useGetAllEmailTemplatePlaceHolderQuery, useGetAllSendEmailDropDownQuery, useGetAllSendEmailProfileDropDownQuery, useGetEmployeesCreateMutation,
  useLazyGetEmailProfileByIdQuery,
  useLazyGetEmailTemplateByIdQuery,
  useLazyGetSendEmailByIdQuery,
  useSendPaySlipCreateMutation,
  useSendTestEmailCreateMutation,
} from 'api/noticationServices'
import { useGetAllPayCycleMasterDropDownQuery } from 'api/payRollServices'
import { useGetAllPublishReportQuery, useLazyGetPublishReportByIdQuery } from 'api/reportingServices'
import { useGetAllReportTypeQuery } from 'api/reports'
import {
  ExcelIcon, RedCross,
} from 'assets/svg-images/SvgComponents'
import OPRButton from 'components/atoms/button/OPRButton'
import OPRLabel from 'components/atoms/label/OPRLabel'
import OPRMultiSelect from 'components/atoms/multiSelectCheckbox/OPRMultiSelectCheckbox'
import OPRStepper from 'components/atoms/stepper'
import OPREnhancedTable from 'components/atoms/table/OPREnhancedTable'
import { ACRFileColumn, selectFileColumn, sendPaySlipColumn } from 'components/atoms/table/OPRTableConstant'
import { a11yProps, CustomTabPanel } from 'components/atoms/tabs'
import { OPRSuccesControl } from 'components/molecules/OPRAlertControl/OPRSuccesControl'
import OPRInputControl from 'components/molecules/OPRInputControl'
import OPRResponsiveGrid from 'components/molecules/OPRResponsiveGrid'
import OPRSelectorControl from 'components/molecules/OPRSelectorControl/OPRSelectorControl'
import OPRAlertControl from 'components/organism/OPRAlertControl'
import { OPRInnerFormLayout } from 'components/organism/OPRInnerFormLayout'
import { validationSchemaSendEmailPayroll, validationSchemaSendEmailPayroll3, validationSchemaSendEmailSteps3 } from 'constants/validate'
import { useEditable } from 'hooks/useEdit'
import useForm from 'hooks/useForm'
import FileUpload from 'pages/uploadData/FileUpload'
import { useEffect, useRef, useState } from 'react'
import { FileWithPath } from 'react-dropzone'
import { useTranslation } from 'react-i18next'
import ReactQuill from 'react-quill'
import { useLocation, useNavigate } from 'react-router-dom'
import { routes } from 'routes/routes'
import { generateFilterUrl, getParamsValue } from 'utils'

import ACRTab from './ACRTabTax'
import SendPaySlip from './payRollSlipTab'
import TaxReturnTab from './TaxReturn'
import RichTextEditor from './TextEditor'

const validationSchema = (activeStep:any) => {
  switch (activeStep) {
    case 0:
      return validationSchemaSendEmailPayroll
    case 1:
      return validationSchemaSendEmailSteps3
    case 2:
      return validationSchemaSendEmailSteps3
    case 3:
      return validationSchemaSendEmailPayroll3
    default:
      return validationSchemaSendEmailPayroll
  }
}

export default function SendPaySlipForm() {
  const richTextEditorRef = useRef<ReactQuill>(null)
  const [cursorPosition, setCursorPosition] = useState<number | null>(null)
  const [paySlipFile, setPaySlipFile]:any = useState([])
  const [taxFile, setTaxFile] = useState<any[]>([])
  const [acrFile, setAcrFile]:any = useState([])
  const [paySlipData, setPaySlipData] = useState([])
  const [commonFile, setCommonFile]: any = useState<
          File | FileWithPath[] | any
        >([])
  // const [fileList, setFileList]: any = useState([Entity?.path,
  //   Employee?.path, Payroll?.path])
  const myRef:any = useRef()
  const location: any = useLocation()
  const [showKeywordDropdown, setShowKeywordDropdown] = useState(false)
  const { id, viewUrl } = getParamsValue(location, routes.createUserRole)
  const [activeState, setActiveState] = useState(0)
  const [employeeData, setEmployeeData] = useState<any[]>([])
  const [checkedValue, setCheckedValue] = useState<any[]>([])
  const [placeholderData, setPlaceholderData] = useState([])
  const [selectedKeyword, setSelectedKeyword] = useState('')

  const [selected, setSelected] = useState<readonly number[]>([])
  const { t } = useTranslation()
  const [value, setValue]:any = useState(0)
  const [reportValues, setreportValues]:any = useState({
    reprortType: [],
    // other state variables
  })
  const [emailContent, setEmailContent] = useState('')
  const { isEditable, setEditable } = useEditable()
  const [genRefDropdown, setGenRefDropdown] = useState([])
  const [genRefDropdownTax, setGenRefDropdownTax] = useState([])
  const [genRefDropdownACR, setGenRefDropdownACR] = useState([])
  const [selectedReportType, setSelectedReportType] = useState()
  const [reportType, setReportType] = useState<any[]>([])

  const [filterData, setFilterData]:any = useState({
    jobStatus: 'Success',
    actionStatus: 'Finalized',
    payCycleYear: '',
    payCycleMonth: '',
    reportTypeId: '',
    // reportTypeCode: reportCodeType.PASP,
  })
  const {
    values,
    setValues,
    errors,
    handleChange,
    setErrors,
    handleFormSubmit,
    handleOnChange,
  // } = useForm(validationSchemaSendEmailPayroll)
  } = useForm(validationSchema(activeState))
  console.log(errors, 'errors')
  const {
    data: allData,
    error: createAllDatasBankAccountError,
    isLoading: isLoadingAllData,
    isSuccess: isSuccessAllData,
    isError: isErrorAllData,
    error: errorAllData,
  } = useGetAllSendEmailDropDownQuery('')
  const {
    data: emailProfileData,
    error: createAllEmailProfileError,
    isLoading: isLoadingEmailProfile,
    isSuccess: isSuccessEmailProfile,
    isError: isErrorEmailProfile,
    error: errorEmailProfile,
  } = useGetAllSendEmailProfileDropDownQuery('')
  const {
    data: reportTypeData,
    error: createAllreportTypeeError,
    isLoading: isLoadingreportType,
    isSuccess: isSuccessreportType,
    isError: isErrorreportType,
    error: errorreportType,
  } = useGetAllReportTypeQuery('')

  const {
    data: emailTemplateData,
    error: createAllTemplateError,
    isLoading: isLoadingTemplate,
    isSuccess: isSuccessTemplate,
    isError: isErrorTemplate,
    error: errorTemplate,
  } = useGetAllEmailTemplateDropDownQuery('')

  const {
    data: employeeDataList,
    isLoading: isLoadingEmployeeDataList,
    isSuccess: isSuccessEmployeeDataList,
    isError: isErrorEmployeeDataList,
    error: errorEmployeeDataList,
  } = useGetAllEmployeeProfileQuery(generateFilterUrl({
    EffectiveDate: '10/10/2040',
  }))

  const navigate = useNavigate()
  const [
    createGetEmployees,
    {
      data: createdGetEmployeesData,
      error: createdGetEmployeesError,
      isLoading: createdGetEmployeesLoading,
      isSuccess: createdGetEmployeesSuccess,
      isError: createdGetEmployeesIsError,
    },
  ] = useGetEmployeesCreateMutation()

  const [
    createSendEmail,
    {
      data: createdSendEmailData,
      error: createdSendEmailError,
      isLoading: createdSendEmailLoading,
      isSuccess: createdSendEmailSuccess,
      isError: createdSendEmailIsError,
    },
  ] = useSendPaySlipCreateMutation()

  const [
    createSendTestEmail,
    {
      data: createdSendTestEmailData,
      error: createdSendTestEmailError,
      isLoading: createdSendTestEmailLoading,
      isSuccess: createdSendTestEmailSuccess,
      isError: createdSendTestEmailIsError,
    },
  ] = useSendTestEmailCreateMutation()

  const [getEmailTemplateById, {
    data: updatedEmailTemplateByIdResponse,
    error: updatedEmailTemplateByIdError,
    isLoading: updatedEmailTemplateByIdLoading,
    isSuccess: updatedEmailTemplateByIdSuccess,
    isError: updatedEmailTemplateByIdIsError,
  }] = useLazyGetEmailTemplateByIdQuery()

  // keyword email Template place holder
  const {
    data: AllRecordskeyWordPlaceHolderData,
    isLoading: isLoadingkeyWordPlaceHolderData,
    isSuccess: isSuccesskeyWordPlaceHolderData,
    isError: isErrorkeyWordPlaceHolderData,
    error: errorkeyWordPlaceHolderData,
  } = useGetAllEmailTemplatePlaceHolderQuery('')

  const [
    getEmailProfileById,
    {
      data: getEmailProfileByIdResponse,
      error: getEmailProfileByIdError,
      isLoading: getEmailProfileByIdLoading,
      isSuccess: getEmailProfileByIdSuccess,
      isError: getEmailProfileByIdIsError,
    },
  ] = useLazyGetEmailProfileByIdQuery()
  const [getReportsById, {
    data: updatedReportsResponse,
    error: updatedReportsError,
    isLoading: updatedReportsLoading,
    isSuccess: updatedReportsSuccess,
    isError: updatedReportsIsError,
  }] = useLazyGetSendEmailByIdQuery()
  const {
    data: allPosts,
    isLoading: isLoadingAllPosts,
    isSuccess: isSuccessAllPosts,
    isError: isErrorAllPosts,
    error: errorAllPosts,
    refetch: refetchAllPosts,
  } = useGetAllPublishReportQuery(generateFilterUrl(filterData))

  const [getPublishReportById, {
    data: allPublishReport,
    error: isErrorAllPublishReport,
    isLoading: isLoadingAllPublishReport,
    isSuccess: isSuccessAllPublishReport,
    isError: errorAllPublishReport,
  }] = useLazyGetPublishReportByIdQuery()

  const {
    data: payCycleMonthDropdown,
  } = useGetAllPayCycleMasterDropDownQuery('')
  const handleTabChange = (event: React.SyntheticEvent, newValue: number) => {
    setValue(newValue)
  }
  useEffect(() => {
    if (isSuccessreportType) {
      const reportTypeId = JSON.parse(JSON.stringify(reportTypeData?.records || [])).filter((item:any) => item?.code === 'PASP' || item?.code === 'HKTR' || item?.code === 'ACR')
      setReportType(reportTypeId)
    }
  }, [isSuccessreportType])

  useEffect(() => {
    if (values?.reprortType?.length > 0) {
      if (values?.reprortType.includes('Payroll Slip')) {
        const payprollSlipReportTypeId = reportType.find((item) => item?.code === 'PASP')?.id
        setFilterData({
          ...filterData,
          payCycleYear: values?.payCycleYear,
          payCycleMonth: values?.payCycleMonth?.label,
          reportTypeId: payprollSlipReportTypeId,
        })
      }
      if (values?.reprortType.includes('Tax Return')) {
        const taxReturnReportTypeId = reportType.find((item) => item?.code === 'HKTR')?.id
        setFilterData({
          ...filterData,
          payCycleYear: values?.payCycleYearTax,
          payCycleMonth: values?.payCycleMonthTax?.label,
          reportTypeId: taxReturnReportTypeId,
        })
      }
      if (values?.reprortType.includes('Annual Compensation Report')) {
        const acrReportTypeId = reportType.find((item) => item?.code === 'ACR')?.id
        setFilterData({
          ...filterData,
          payCycleYear: values?.payCycleYearReport,
          payCycleMonth: values?.payCycleMonthReport?.label,
          reportTypeId: acrReportTypeId,
        })
      }
    }
  }, [
    values?.reprortType,
    values?.payCycleMonth,
    values?.payCycleYear,
    values?.payCycleMonthTax,
    values?.payCycleYearTax,
    values?.payCycleMonthReport,
    values?.payCycleYearReport,
  ])
  console.log(values?.reprortType, 'reportType')

  // another useUeffect
  // useEffect(() => {
  //   if (values?.reprortType?.length > 0 && values?.reprortType.includes('Tax Return')) {
  //     setFilterData({
  //       ...filterData,
  //       payCycleYear: values?.payCycleYearTax,
  //       payCycleMonth: values?.payCycleMonthTax?.label,
  //       reportTypeId: reportType[2]?.id,
  //     })
  //   }
  //   if (values?.reprortType?.length > 0 && values?.reprortType.includes('Annual Compensation Report')) {
  //     setFilterData({
  //       ...filterData,
  //       payCycleYear: values?.payCycleYearReport,
  //       payCycleMonth: values?.payCycleMonthReport?.label,
  //       reportTypeId: reportType[0]?.id,
  //     })
  //   }
  // }, [
  //   values?.payCycleMonthTax,
  //   values?.payCycleYearTax,
  //   values?.payCycleMonthReport,
  //   values?.payCycleYearReport,
  //   values?.reprortType])

  useEffect(() => {
    if (isSuccessAllPosts) {
      const dorpItems = JSON.parse(JSON.stringify(allPosts?.records || [])).map((item: any) => ({ label: item?.referenceNumber, id: item?.id }))
      if (selectedReportType === 'Payroll Slip') {
        setGenRefDropdown(dorpItems)
      }
      if (selectedReportType === 'Tax Return') {
        setGenRefDropdownTax(dorpItems)
      }
      if (selectedReportType === 'Annual Compensation Report') {
        setGenRefDropdownACR(dorpItems)
      }
    }
  }, [isSuccessAllPosts, allPosts?.records])

  const handleSubmit: any = async () => {
    const formData = new FormData()
    checkedValue?.forEach((val, i) => {
      formData.append(`EmployeeDetails[${i}].EmployeeCode`, val?.employeeDetail?.employeeCode)
      // formData.append(`EmployeeProfileCodes[${i}]`, val?.employeeProfileCode)
    })
    formData.append('EmailProfileCodes[0]', values?.emailProfile?.label)
    // formData.append('EmailTemplateCode', values?.emailTemplate?.label)
    formData.append('EmailSubject', values?.emailSubject)
    formData.append('EmailContent', emailContent)
    formData.append('EmailDomainId', values?.emailDomain?.id)
    formData.append('FileAttachments', values?.commonFile)
    createSendEmail(formData)
  }

  const handleTestSubmit: any = async () => {
    const formData = new FormData()
    checkedValue?.forEach((val, i) => {
      formData.append(`EmployeeDetails[${i}].EmployeeCode`, val?.employeeDetail?.employeeCode)
      // formData.append(`EmployeeProfileCodes[${i}]`, val?.employeeProfileCode)
    })
    if (commonFile?.length > 0) {
      formData.append('CommonFileAttachments', commonFile)
    }
    formData.append('EmailProfileCodes[0]', values?.emailProfile?.label)
    formData.append('EmailSubject', values?.emailSubject)
    formData.append('EmailContent', emailContent)
    formData.append('TestEmailBox', values?.testEmailBox)
    formData.append('EmailDomainId', values?.emailDomain?.id)
    createSendTestEmail(formData)
  }

  const handleGetEmployees = async () => {
    if (values?.reprortType?.includes('Payroll Slip')) {
      await getReportsById(`${reportType.find((item) => item?.code === 'PASP')?.id}&GenerationReferenceId=${values?.genRefId}`)
    }
    if (values?.reprortType?.includes('Tax Return')) {
      await getReportsById(`${reportType.find((item) => item?.code === 'HKTR')?.id}&GenerationReferenceId=${values?.genRefIdTax}`)
    }
    if (values?.reprortType?.includes('Annual Compensation Report')) {
      await getReportsById(`${reportType.find((item) => item?.code === 'ACR')?.id}&GenerationReferenceId=${values?.genRefIdTaxACR}`)
    }
  }
  console.log(employeeData, 'employeeData')
  useEffect(() => {
    if (createdGetEmployeesSuccess) {
      setActiveState(activeState + 1)
      if (!employeeData.length) {
        setEmployeeData(createdGetEmployeesData?.data)
      }
    }
  }, [createdGetEmployeesSuccess, createdGetEmployeesError])

  useEffect(() => {
    if (id) {
      //   updateUserRoleById(id)
      setEditable(viewUrl)
    }
  }, [])
  useEffect(() => {
    if (isSuccessAllPublishReport) {
      setPaySlipData(allPublishReport?.data?.records || [])
      // setAcrFile(allPublishReport?.data?.records || [])
    }
  }, [isSuccessAllPublishReport])
  useEffect(() => {
    if (updatedEmailTemplateByIdSuccess) {
      setValues((prevValues:any) => ({
        ...prevValues,
        emailSubject: updatedEmailTemplateByIdResponse?.data?.emailSubject,
      }))
      setEmailContent(updatedEmailTemplateByIdResponse?.data?.emailContent)
    }
  }, [updatedEmailTemplateByIdSuccess, updatedEmailTemplateByIdResponse])

  useEffect(() => {
    if (updatedReportsSuccess) {
      const files = updatedReportsResponse?.data?.map((item:any) => ({
        fileName: item.fileName,
        reportTypeId: item.reportTypeId,
      }))

      files?.forEach((item:any) => {
        if (item.reportTypeId === reportType.find((type) => type?.code === 'PASP')?.id) {
          setPaySlipFile((prevFiles:any) => [...prevFiles, item])
        } else if (item.reportTypeId === reportType.find((type) => type?.code === 'HKTR')?.id) {
          setTaxFile((prevFiles) => [...prevFiles, item])
        } else if (item.reportTypeId === reportType.find((type) => type?.code === 'ACR')?.id) {
          setAcrFile((prevFiles:any) => [...prevFiles, item])
        }
      })

      setEmployeeData(updatedReportsResponse?.data)
    }
  }, [updatedReportsSuccess, updatedReportsResponse, reportType])

  // useEffect(() => {
  //   if (updatedReportsSuccess) {
  //     const files = updatedReportsResponse?.data?.reduce((acc: any, item: any) => {
  //       const reportTypeId = reportType.find((type) => type?.code === 'ACR')?.id
  //       if (item.reportTypeId === reportTypeId) {
  //         acc.push({
  //           fileName: item.fileName,
  //           reportTypeId: item.reportTypeId,
  //         })
  //       }
  //       return acc
  //     }, [])

  //     setAcrFile(files)
  //     setEmployeeData(updatedReportsResponse?.data)
  //   }
  // }, [updatedReportsSuccess, updatedReportsResponse, reportType])

  const handlePermissionSubmit: any = async () => {
    if (activeState === 1) {
      setActiveState(activeState + 1)
    } else {
      myRef.current.childMethod()
    }
    // myRef.current.childMethod()
  }

  useEffect(() => {
    if (values?.emailProfile) {
      getEmailProfileById(values?.emailProfile?.id)
    }
  }, [values?.emailProfile])

  // default select all
  // useEffect(() => {
  //   if (activeState === 1) {
  //     setSelected(JSON.parse(JSON.stringify(employeeData || []))?.map((n:any) => n.fileName))
  //     setCheckedValue(employeeData || [])
  //   }
  // }, [activeState, employeeData])

  useEffect(() => {
    if (activeState === 1) {
      setSelected(JSON.parse(JSON.stringify(employeeData || []))?.map((n:any) => n.fileName))

      setCheckedValue(employeeData || [])
    }
  }, [activeState, employeeData])

  useEffect(() => {
    if (activeState === 5) {
      setSelected([])
      setCheckedValue([])
    }
  }, [activeState])

  const handleSelectAllClick = (event: React.ChangeEvent<HTMLInputElement>) => {
    if ((event.target as HTMLInputElement).checked) {
      setSelected(JSON.parse(JSON.stringify(employeeData || []))?.map((n:any) => n.fileName))
      setCheckedValue(employeeData || [])
      return
    }
    setSelected([])
    setCheckedValue([])
  }
  // console.log(selected, 'selectedValue')
  // console.log(checkedValue, 'checkedValue')
  const handleClick = (event: React.MouseEvent<unknown>, item: any) => {
    const selectedIndex = selected.indexOf(item.fileName)
    console.log(selectedIndex, 'selectedIndexselectedIndexselectedIndex')
    let newSelected: readonly number[] = []
    if (selectedIndex === -1) {
      newSelected = newSelected.concat(selected, item.fileName)
      setCheckedValue([
        ...checkedValue,
        item,
      ])
    } else if (selectedIndex === 0) {
      newSelected = newSelected.concat(selected.slice(1))
      setCheckedValue(checkedValue.filter((val) => val.fileName !== item.fileName))
    } else if (selectedIndex === selected.length - 1) {
      newSelected = newSelected.concat(selected.slice(0, -1))
      setCheckedValue(checkedValue.filter((val) => val.fileName !== item.fileName))
    } else if (selectedIndex > 0) {
      newSelected = newSelected.concat(
        selected.slice(0, selectedIndex),
        selected.slice(selectedIndex + 1),
      )
      setCheckedValue(checkedValue.filter((val) => val.fileName !== item.fileName))
    }
    setSelected(newSelected)
  }

  const isSelected = (employeeCode:any) => selected.indexOf(employeeCode) !== -1
  // console.log(paySlipFile, 'paySlipFile')
  // console.log(acrFile, 'acrFile')
  // console.log(isSelected, 'isSelectedisSelected')
  // console.log(value, 'valuevaluevaluevaluevalue')

  useEffect(() => {
    if (isSuccesskeyWordPlaceHolderData && AllRecordskeyWordPlaceHolderData) {
      setPlaceholderData(AllRecordskeyWordPlaceHolderData.emailTemplatePlaceholders)
    }
  }, [isSuccesskeyWordPlaceHolderData, AllRecordskeyWordPlaceHolderData])

  const handleKeywordButtonClick = () => {
    setShowKeywordDropdown(true)
  }
  console.log(values?.reprortType, 'values?.reprortType')

  const handleKeywordSelect = (event: any) => {
    const selected = event.target.value
    setSelectedKeyword(selected)
    const contentEditor = richTextEditorRef.current?.getEditor()
    if (contentEditor) {
      if (cursorPosition) {
        contentEditor.insertText(cursorPosition, selected)
        contentEditor.setSelection(cursorPosition + selected.length, 0)
      } else {
        contentEditor.insertText(0, selected)
        contentEditor.setSelection(selected.length, 0)
      }
    }
    setShowKeywordDropdown(false)
    setSelectedKeyword('')
  }
  // console.log(taxFile, 'taxFile')

  const borderStyle = activeState === 6 ? { background: 'blue' } : { background: 'red' } // Set border style conditionally
  return (
    <Box sx={{ display: 'flex' }}>
      <div
        style={{ display: 'flex', width: '100% ' }}
        // onSubmit={(e) => {
        //   activeState === 0 ? handleFormSubmit(e, handleSubmit) : handlePermissionSubmit()
        // }}
      >
        <OPRAlertControl
          isCustom
          customMessage="Send payroll slip/report submitted"
          customTitle="Send payroll slip/report submitted"
          error={createdSendEmailError}
          handleEditable={setEditable}
          handleSetValue={setValues}
          handleSubmit={handleSubmit}
          isError={createdGetEmployeesIsError || createdSendEmailIsError}
          isLoading={createdGetEmployeesLoading || isLoadingAllPublishReport
            || createdSendTestEmailLoading || updatedReportsLoading || createdSendEmailLoading}
          isSuccess={createdSendEmailSuccess}
          name={t('email')}
          title={t('email')}
          type="update"
        />
        <OPRSuccesControl
          isEntity
          customMessage="Test Email notification submitted successfully"
          customTitle="Test Email notification submitted"
          isSuccess={createdSendTestEmailSuccess}
          name={t('email')}
          title={t('email')}
          type="update"
        />
        <OPRInnerFormLayout
          isHandleContinueClick
          isStepper
          // customHeader={(
          //   <OPRLabel label="Send payroll slip/report" variant="h2" />
          // )}
          error={createdGetEmployeesError}
          handleBack={() => { setActiveState(activeState - 1) }}
          handleCancelClick={(e:any) => navigate(-1)}
          handleContinueClick={(e:any) => {
            if (activeState === 0) {
              // Validate the form fields for the current step
              handleFormSubmit(e, () => {
                // If validation succeeds, proceed to the next step
                // setActiveState(activeState + 1)
                // Additional logic for fetching employees
                handleGetEmployees()
                setActiveState(activeState + 1)
              })
            } else if (activeState === 1) {
              // setActiveState(activeState + 1)
              if (checkedValue.length > 0) {
                setActiveState(activeState + 1)
              }
            } else if (activeState === 3) {
              handleFormSubmit(e, () => {
                if (values?.emailSubject && emailContent && values?.emailProfile) {
                  setActiveState(activeState + 1)
                }
              })
            } else if (activeState === 6) {
              handleSubmit()
            } else {
              setActiveState(activeState + 1)
            }
          }}
          handleEditable={setEditable}
          isBackButton={activeState > 0}
          isConfirm={activeState === 5}
          isLoading={createdGetEmployeesLoading}
          pageType="detailsPage"
          // previousPageUrl={routes.sendEmail}
          step={activeState}
          subtitle={
            isEditable
              ? 'Please check the user details below.'
              : ''
          }
          title={t('Send payroll slip/report')}
        >
          <Box>
            <OPRStepper
              activeStep={activeState}
              steps={[
                t('filtering'),
                t('Report files'),
                t('Email Records'),
                t('Design email'),
                t('Attach file'),
                t('Test email'),
                t('pensionfund_scheme_step_confirmation'),
              ]}
            />
            {activeState === 0 && (
              <Box>
                <OPRLabel sx={{ marginTop: '20px', marginBottom: '20px' }} variant="body2">
                  {`  ${t('modal_mandatory_note')}`}
                </OPRLabel>
                <div style={{ display: 'block', width: '100%', margin: '30px 20px 20px' }}>
                  <OPRLabel variant="h2">Select report type</OPRLabel>
                </div>
                <OPRResponsiveGrid>
                  <Grid item md={2} sm={1} xs={1}>
                    <OPRMultiSelect
                      error={errors?.reprortType}
                      label={t('ent_reports_report_type')}
                      name="reprortType"
                      options={[
                        { name: 'Payroll Slip', value: 'Payroll Slip' },
                        { name: 'Tax Return', value: 'Tax Return' },
                        { name: 'Annual Compensation Report', value: 'Annual Compensation Report' },
                      ]}
                      placeholder="Select"
                      value={values?.reprortType}
                      onChange={(reprortType:any) => {
                        setSelectedReportType(reprortType[reprortType.length - 1])
                        setValues({ ...values, reprortType })
                      }}
                    />
                  </Grid>
                  {(values?.reprortType?.includes('Payroll Slip')) && (
                    <>
                      <div style={{ display: 'block', width: '100%', margin: '30px 20px 20px' }}>
                        <OPRLabel variant="h2">{t('ent_reports_payroll_slip_type')}</OPRLabel>
                      </div>
                      <Grid item md={2} sm={1} xs={1}>
                        <OPRInputControl
                          error={t(errors?.payCycleYear)}
                          isEditable={isEditable}
                          label="ent_reports_filtering_opt_pay_cycle_year"
                          name="payCycleYear"
                          value={values?.payCycleYear}
                          onChange={handleChange}
                        />
                      </Grid>
                      <Grid item md={2} sm={1} xs={1}>
                        <OPRSelectorControl
                          error={errors?.payCycleMonth}
                          isEditable={isEditable}
                          keyName="label"
                          label="Pay Cycle Month"
                          multiple={false}
                          name="payCycleMonth"
                          options={(payCycleMonthDropdown?.months || [])}
                          placeholder="Select an option"
                          value={values?.payCycleMonth}
                          valueKey="id"
                          onChange={(text:any) => {
                            handleOnChange('payCycleMonth', text)
                          }}
                        />
                      </Grid>
                      <Grid item md={2} sm={1} xs={1}>
                        <OPRSelectorControl
                          error={errors?.genRefId}
                          isEditable={isEditable}
                          keyName="label"
                          label={t('ent_reports_generation_ref')}
                          multiple={false}
                          name="genRefId"
                          options={(genRefDropdown || [])}
                          placeholder="Select"
                          value={(genRefDropdown || []).find((o:any) => o?.id === values?.genRefId)}
                          valueKey="id"
                          onChange={(text:any) => {
                            handleOnChange('genRefId', text?.id)
                          }}
                        />
                      </Grid>
                    </>
                  )}
                  {(values?.reprortType?.includes('Tax Return')) && (
                    <>
                      <div style={{ display: 'block', width: '100%', margin: '30px 20px 20px' }}>
                        <OPRLabel variant="h2">Tax return</OPRLabel>
                      </div>
                      <Grid item md={2} sm={1} xs={1}>
                        <OPRInputControl
                          error={t(errors?.payCycleYearTax)}
                          isEditable={isEditable}
                          label="ent_reports_filtering_opt_pay_cycle_year"
                          name="payCycleYearTax"
                          value={values?.payCycleYearTax}
                          onChange={handleChange}
                        />
                      </Grid>
                      <Grid item md={2} sm={1} xs={1}>
                        <OPRSelectorControl
                          error={errors?.payCycleMonthTax}
                          isEditable={isEditable}
                          keyName="label"
                          label="Pay Cycle Month"
                          multiple={false}
                          name="payCycleMonthTax"
                          options={(payCycleMonthDropdown?.months || [])}
                          placeholder="Select an option"
                          value={values?.payCycleMonthTax}
                          valueKey="id"
                          onChange={(text:any) => {
                            handleOnChange('payCycleMonthTax', text)
                          }}
                        />
                      </Grid>
                      <Grid item md={2} sm={1} xs={1}>
                        <OPRSelectorControl
                          error={errors?.genRefIdTax}
                          isEditable={isEditable}
                          keyName="label"
                          label={t('ent_reports_generation_ref')}
                          multiple={false}
                          name="genRefIdTax"
                          options={(genRefDropdownTax || [])}
                          placeholder="Select"
                          value={(genRefDropdownTax || [])?.find((o:any) => o?.id === values?.genRefIdTax)}
                          valueKey="id"
                          onChange={(text:any) => {
                            handleOnChange('genRefIdTax', text?.id)
                          }}
                        />
                      </Grid>
                    </>
                  )}
                  {(values?.reprortType?.includes('Annual Compensation Report')) && (
                    <>
                      <div style={{ display: 'block', width: '100%', margin: '30px 20px 20px' }}>
                        <OPRLabel variant="h2">Annual Compensation Report</OPRLabel>
                      </div>
                      <Grid item md={2} sm={1} xs={1}>
                        <OPRInputControl
                          error={t(errors?.payCycleYearReport)}
                          isEditable={isEditable}
                          label="ent_reports_filtering_opt_pay_cycle_year"
                          name="payCycleYearReport"
                          value={values?.payCycleYearReport}
                          onChange={handleChange}
                        />
                      </Grid>
                      <Grid item md={2} sm={1} xs={1}>
                        <OPRSelectorControl
                          error={errors?.payCycleMonthReport}
                          isEditable={isEditable}
                          keyName="label"
                          label="Pay Cycle Month"
                          multiple={false}
                          name="payCycleMonthReport"
                          options={(payCycleMonthDropdown?.months || [])}
                          placeholder="Select an option"
                          value={values?.payCycleMonthReport}
                          valueKey="id"
                          onChange={(text:any) => {
                            handleOnChange('payCycleMonthReport', text)
                          }}
                        />
                      </Grid>
                      <Grid item md={2} sm={1} xs={1}>
                        <OPRSelectorControl
                          error={errors?.genRefIdTaxACR}
                          isEditable={isEditable}
                          keyName="label"
                          label={t('ent_reports_generation_ref')}
                          multiple={false}
                          name="genRefIdTaxACR"
                          options={(genRefDropdownACR || [])}
                          placeholder="Select"
                          value={(genRefDropdownACR || []).find((o:any) => o?.id === values?.genRefIdTaxACR)}
                          valueKey="id"
                          onChange={(text:any) => {
                            handleOnChange('genRefIdTaxACR', text?.id)
                          }}
                        />
                      </Grid>
                    </>
                  )}
                </OPRResponsiveGrid>
              </Box>
            )}
            {activeState === 1 && (
              <Box>
                <Box sx={{
                  padding: '24px',
                  display: 'flex',
                  flexDirection: 'row',
                  gap: '6px',
                  border: '1px solid #D4D2D3',
                  borderRadius: '10px',
                  marginTop: '24px',
                  marginBottom: '24px',
                }}
                >
                  <OPRLabel variant="body1">
                    {t('bulk_upload_data_first_note_title')}
                  </OPRLabel>
                  <OPRLabel variant="body2">{t('select_report_files_and_continue')}</OPRLabel>
                </Box>
                <Box sx={{ display: 'flex', flexDirection: 'column' }}>
                  <Box>
                    <Tabs aria-label="basic tabs example" value={value} onChange={handleTabChange}>
                      {values?.reprortType?.includes('Payroll Slip') && (
                        <Tab label="Payroll slip" {...a11yProps(0)} />
                      )}
                      {values?.reprortType?.includes('Tax Return') && (
                        <Tab label="Tax return" {...a11yProps(0)} />
                      )}
                      {values?.reprortType?.includes('Annual Compensation Report') && (
                        <Tab label="Annual Compensation Report" {...a11yProps(2)} />

                      )}
                    </Tabs>
                  </Box>
                  {/* payroll slip  */}
                  {
                    values?.reprortType?.map((item:any, i:any) => (
                      <CustomTabPanel index={i} value={value}>
                        {
                          item === 'Payroll Slip' && (
                            <SendPaySlip
                              handleClick={handleClick}
                              handleSelectAllClick={handleSelectAllClick}
                              isSelected={isSelected}
                              paySlipFile={paySlipFile}
                              selectFileColumn={selectFileColumn}
                              selected={selected}
                            />
                          )
                        }
                        {
                          item === 'Tax Return' && (
                            <TaxReturnTab
                              ACRFileColumn={ACRFileColumn}
                              handleClick={handleClick}
                              handleSelectAllClick={handleSelectAllClick}
                              isSelected={isSelected}
                              selected={selected}
                              taxFile={taxFile}
                            />
                          )
                        }

                        {
                          item === 'Annual Compensation Report' && (
                            <ACRTab
                              ACRFileColumn={ACRFileColumn}
                              acrFile={acrFile}
                              handleClick={handleClick}
                              handleSelectAllClick={handleSelectAllClick}
                              isSelected={isSelected}
                              selected={selected}
                            />
                          )
                        }

                      </CustomTabPanel>
                    ))
                  }

                </Box>
              </Box>
            )}
            {activeState === 2 && (
              <Box>
                <Box sx={{
                  padding: '24px',
                  display: 'flex',
                  flexDirection: 'row',
                  gap: '6px',
                  border: '1px solid #D4D2D3',
                  borderRadius: '10px',
                  marginTop: '24px',
                  marginBottom: '24px',
                }}
                >
                  <OPRLabel variant="body1">
                    {t('bulk_upload_data_first_note_title')}
                  </OPRLabel>
                  <OPRLabel variant="body2">{t('select_email_rec_note')}</OPRLabel>
                </Box>
                <div style={{ display: 'block', width: '100%', margin: '30px 20px 20px' }}>
                  <OPRLabel variant="h2">Email Records</OPRLabel>
                </div>
                <OPRResponsiveGrid>
                  <OPREnhancedTable
                    isMovement
                    cols={sendPaySlipColumn(handleClick)}
                    data={employeeData || []}
                    handleClick={handleClick}
                    isSelected={isSelected}
                    // steps={1}
                  />
                  {/* total employee selected */}
                  <div style={{
                    width: '100%',
                    padding: 12,
                    background: '#E9F4FF',
                    borderRadius: 4,
                    justifyContent: 'flex-start',
                    alignItems: 'flex-start',
                    gap: 12,
                    display: 'inline-flex',
                  }}
                  >
                    <div style={{
                      flex: '1 1 0',
                      flexDirection: 'column',
                      justifyContent: 'flex-start',
                      alignItems: 'flex-start',
                      display: 'inline-flex',
                    }}
                    >
                      <div style={{
                        alignSelf: 'stretch',
                        color: '#3B3839',
                        fontSize: 16,
                        fontFamily: 'Lato',
                        fontWeight: '700',
                        wordWrap: 'break-word',
                      }}
                      >
                        Total selected employees:
                        {' '}
                        {selected.length}
                      </div>
                    </div>
                  </div>
                </OPRResponsiveGrid>
              </Box>
            )}
            {activeState === 3 && (
              <Box>
                <Box sx={{
                  padding: '24px',
                  display: 'flex',
                  flexDirection: 'row',
                  gap: '6px',
                  border: '1px solid #D4D2D3',
                  borderRadius: '10px',
                  marginTop: '24px',
                  marginBottom: '24px',
                }}
                >
                  <OPRLabel variant="body1">
                    {t('bulk_upload_data_first_note_title')}
                  </OPRLabel>
                  <OPRLabel variant="body2">{t('select_email_template_note')}</OPRLabel>
                </Box>
                <OPRLabel sx={{ marginTop: '20px' }} variant="body2">
                  {`  ${t('All fields are mandatory except those marked optional')}`}
                </OPRLabel>
                <div style={{ display: 'block', width: '100%', margin: '30px 20px 20px' }}>
                  <OPRLabel variant="h2">Email</OPRLabel>
                </div>
                <OPRResponsiveGrid>
                  <Grid item md={4} sm={1} xs={1}>
                    <OPRSelectorControl
                      error={errors?.emailTemplate}
                      isEditable={isEditable}
                      keyName="label"
                      label={t('email_template')}
                      multiple={false}
                      name="emailTemplate"
                      optionalText={t('optional')}
                      options={emailTemplateData?.emailTemplates || []}
                      placeholder="Select"
                      value={values?.emailTemplate}
                      valueKey="id"
                      onChange={(text:any) => {
                        handleOnChange('emailTemplate', text)
                        getEmailTemplateById(text?.id)
                      }}
                    />
                  </Grid>
                  <Grid item md={4} sm={1} xs={1}>
                    <Box
                      style={{
                        width: '100%',
                        height: '100%',
                        borderRadius: 110,
                        overflow: 'hidden',
                        justifyContent: 'flex-start',
                        alignItems: 'center',
                        gap: 12,
                        display: 'inline-flex',
                        textAlign: 'left',
                      }}
                    >
                      <div
                        style={{
                          width: 16,
                          height: 16,
                          position: 'relative',
                        }}
                      >
                        <div style={{
                          width: 12,
                          height: 12,
                          left: 2,
                          top: 2,
                          position: 'absolute',
                          background: '#0049DB',
                        }}
                        />

                      </div>
                      <div>
                        <Button
                          className="ServiceProvider"
                          style={{
                            color: '#0049DB',
                            fontSize: 16,
                            fontFamily: 'Lato',
                            fontWeight: '700',
                            wordWrap: 'break-word',
                          }}
                          onClick={handleKeywordButtonClick}
                        >
                          Keyword
                        </Button>
                        {showKeywordDropdown && (
                          <Select
                            autoFocus
                            displayEmpty
                            value={selectedKeyword}
                            onChange={handleKeywordSelect}
                          >
                            {placeholderData.map((placeholder: any) => (
                              <MenuItem key={placeholder.label} value={placeholder.label}>
                                {placeholder.label}
                              </MenuItem>
                            ))}
                          </Select>
                        )}
                      </div>
                    </Box>
                  </Grid>

                  <Grid item md={4} sm={1} xs={1}>
                    <OPRInputControl
                      error={t(errors?.emailSubject)}
                      isEditable={isEditable}
                      label="email_subject"
                      name="emailSubject"
                      value={values?.emailSubject}
                      onChange={handleChange}
                    />
                  </Grid>
                  {/* email Content */}
                  <Grid item md={4} sm={1} xs={1}>
                    <OPRLabel
                      CustomStyles={{
                        display: 'flex',
                        alignItems: 'flex-start',
                        gap: '0px',
                        alignSelf: 'stretch',

                      }}
                    >
                      {t('email_content')}
                    </OPRLabel>
                    <RichTextEditor
                      ref={richTextEditorRef}
                      getSelection={setCursorPosition}
                      isEditable={!isEditable}
                      setValue={(e: any) => setEmailContent(e)}
                      value={emailContent}
                    />
                  </Grid>
                  <Grid item md={2} sm={1} xs={1}>
                    <OPRSelectorControl
                      error={errors?.emailProfile}
                      isEditable={isEditable}
                      keyName="label"
                      label={t('email_profile')}
                      multiple={false}
                      name="emailProfile"
                      options={emailProfileData?.emailProfiles || []}
                      placeholder="Select"
                      sx={{ marginTop: '50px' }}
                      value={values?.emailProfile}
                      valueKey="id"
                      onChange={(text:any) => {
                        handleOnChange('emailProfile', text)
                      }}
                    />
                  </Grid>
                  <Grid item md={2} sm={1} xs={1} />
                  {(values?.emailProfile?.id && getEmailProfileByIdResponse) && (
                    <>
                      <Grid item md={2} sm={1} xs={1}>
                        <OPRInputControl
                          isEditable
                          error={t(errors?.sender)}
                          label="sender"
                          name="sender"
                          value={getEmailProfileByIdResponse?.data?.sender}
                          onChange={handleChange}
                        />
                      </Grid>
                      <Grid item md={4} sm={1} xs={1}>
                        <OPRLabel
                          CustomStyles={{
                            display: 'flex',
                            alignItems: 'flex-start',
                            gap: '0px',
                            alignSelf: 'stretch',
                            marginBottom: '10px',
                          }}
                        >
                          {t('recipient_TOList')}
                        </OPRLabel>
                        {getEmailProfileByIdResponse?.data?.recipientTOList.map((option:any, index:any) => (
                          <Chip
                            label={option}
                            sx={{ margin: '3px' }}
                          />
                        ))}
                      </Grid>
                      <Grid item md={4} sm={1} xs={1}>
                        <OPRLabel
                          CustomStyles={{
                            display: 'flex',
                            alignItems: 'flex-start',
                            gap: '0px',
                            alignSelf: 'stretch',
                            marginBottom: '10px',
                          }}
                        >
                          {t('recipient_CCList')}
                        </OPRLabel>
                        {getEmailProfileByIdResponse?.data?.recipientCCList.map((option:any, index:any) => (
                          <Chip
                            label={option}
                            sx={{ margin: '3px' }}
                          />
                        ))}
                      </Grid>
                      <Grid item md={4} sm={1} xs={1}>
                        <OPRLabel
                          CustomStyles={{
                            display: 'flex',
                            alignItems: 'flex-start',
                            gap: '0px',
                            alignSelf: 'stretch',
                            marginBottom: '10px',
                          }}
                        >
                          {t('recipient_BCCList')}
                        </OPRLabel>
                        {getEmailProfileByIdResponse?.data?.recipientBCCList.map((option:any, index:any) => (
                          <Chip
                            label={option}
                            sx={{ margin: '3px' }}
                          />
                        ))}
                      </Grid>
                    </>
                  )}
                </OPRResponsiveGrid>
              </Box>
            )}
            {activeState === 4 && (
              <Box>
                <Box sx={{
                  padding: '24px',
                  display: 'flex',
                  flexDirection: 'row',
                  gap: '6px',
                  border: '1px solid #D4D2D3',
                  borderRadius: '10px',
                  marginTop: '24px',
                  marginBottom: '24px',
                }}
                >
                  <OPRLabel variant="body1">
                    {t('bulk_upload_data_first_note_title')}
                  </OPRLabel>
                  <OPRLabel variant="body2">{t('attach_file_recipients')}</OPRLabel>
                </Box>
                <OPRResponsiveGrid>
                  <Box sx={{
                    mt: '24px', marginLeft: '16px', width: '100%',
                  }}
                  >
                    <OPRLabel variant="body1">{t('attach_common_file')}</OPRLabel>
                    <FileUpload onFileUpload={(files:any) => {
                      setCommonFile([...commonFile, files])
                    }}
                    />
                    {commonFile[0]?.path && (
                      commonFile.map((file:any) => (
                        <Box sx={{
                          display: 'flex', flexDirection: 'row', justifyContent: 'space-between',
                        }}
                        >
                          <Box sx={{
                            display: 'flex', flexDirection: 'row', marginTop: '5px',
                          }}
                          >
                            <ExcelIcon />
                            <OPRLabel variant="body2">{file?.path}</OPRLabel>
                          </Box>
                          <OPRButton
                            variant="text"
                            onClick={() => {
                              setCommonFile(commonFile.filter((val:any) => val?.path !== file?.path))
                            }}
                          >
                            <RedCross />
                          </OPRButton>
                        </Box>
                      ))
                    )}
                  </Box>
                </OPRResponsiveGrid>
              </Box>
            )}
            {activeState === 5 && (
              <Box>
                <Box sx={{
                  padding: '24px',
                  display: 'flex',
                  flexDirection: 'row',
                  gap: '6px',
                  border: '1px solid #D4D2D3',
                  borderRadius: '10px',
                  marginTop: '24px',
                  marginBottom: '24px',
                }}
                >
                  <OPRLabel variant="body1">
                    {t('bulk_upload_data_first_note_title')}
                  </OPRLabel>
                  <OPRLabel variant="body2">{t('select_employee_test_email_note')}</OPRLabel>
                </Box>
                <div style={{ display: 'block', width: '100%', margin: '30px 20px 20px' }}>
                  <OPRLabel variant="h2">Test email recipient</OPRLabel>
                </div>
                <OPRResponsiveGrid>
                  <Grid item md={2} sm={1} xs={1}>
                    <OPRInputControl
                      error={t(errors?.testEmailBox)}
                      isEditable={isEditable}
                      label="email_box"
                      name="testEmailBox"
                      value={values?.testEmailBox}
                      onChange={handleChange}
                    />
                  </Grid>
                  <Grid item md={2} sm={1} xs={1}>
                    <OPRSelectorControl
                      error={errors?.emailDomain}
                      isEditable={isEditable}
                      keyName="label"
                      label={t('email_domain')}
                      multiple={false}
                      name="emailDomain"
                      options={[{ id: '4094fce4-51a4-45bf-a7ae-3dbef5d02cc5', label: 'my.tricorglobal.com' }, { id: 'efe289aa-2abd-4100-8b2c-a34b61208843', label: 'hk.tricorglobal.com' }]}
                      placeholder="Select"
                      value={[{ id: '4094fce4-51a4-45bf-a7ae-3dbef5d02cc5', label: 'my.tricorglobal.com' }, { id: 'efe289aa-2abd-4100-8b2c-a34b61208843', label: 'hk.tricorglobal.com' }].find((o:any) => o?.id === values?.emailDomain?.id)}
                      valueKey="id"
                      onChange={(text:any) => {
                        handleOnChange('emailDomain', text)
                      }}
                    />
                  </Grid>
                  <div style={{ display: 'block', width: '100%', margin: '30px 20px 20px' }}>
                    <OPRLabel variant="h2">Email Records</OPRLabel>
                  </div>
                  <OPREnhancedTable
                    isMovement
                    cols={sendPaySlipColumn(handleClick)}
                    // data={employeeData || []}
                    data={JSON.parse(JSON.stringify(employeeData || []))}
                    handleClick={handleClick}
                    isSelected={isSelected}
                    steps={1}
                  />
                  <Box sx={{
                    display: 'flex', flexDirection: 'row', justifyContent: 'space-between', gap: '10px', marginTop: '10px', backgroundColor: '#E9F4FF', width: '100%',
                  }}
                  >
                    <OPRLabel label={`Total selected employees:${checkedValue?.length}`} variant="body2" />
                    <OPRButton
                      variant="text"
                      onClick={() => {
                        handleTestSubmit()
                      }}
                    >
                      Send test email
                    </OPRButton>
                  </Box>
                </OPRResponsiveGrid>
              </Box>
            )}
            {activeState === 6 && (
              <Box>
                <OPRLabel sx={{ marginTop: '20px' }} variant="body2">
                  {`  ${t('please_check_details_below')}`}
                </OPRLabel>
                <div style={{ display: 'block', width: '100%', margin: '30px 0px 10px' }}>
                  <OPRLabel variant="h2">Email Information</OPRLabel>
                </div>
                <OPRResponsiveGrid>
                  <Grid item md={4} sm={1} xs={1}>
                    <OPRSelectorControl
                      isEditable
                      error={errors?.emailTemplate}
                      keyName="label"
                      label={t('email_template')}
                      multiple={false}
                      name="emailTemplate"
                      options={emailTemplateData?.emailTemplates || []}
                      placeholder="Select"
                      value={values?.emailTemplate}
                      valueKey="label"
                      onChange={(text:any) => {
                        handleOnChange('emailTemplate', text)
                      }}
                    />
                  </Grid>
                  <Grid item md={4} sm={1} xs={1}>
                    <OPRInputControl
                      isEditable
                      error={t(errors?.emailSubject)}
                      label="email_subject"
                      name="emailSubject"
                      value={values?.emailSubject}
                      onChange={handleChange}
                    />
                  </Grid>
                  <Grid item md={4} sm={1} xs={1}>
                    <OPRLabel
                      CustomStyles={{
                        display: 'flex',
                        alignItems: 'flex-start',
                        gap: '0px',
                        alignSelf: 'stretch',

                      }}
                    >
                      {t('email_content')}
                    </OPRLabel>
                    <RichTextEditor
                      isEditable={isEditable}
                      setValue={(e:any) => setEmailContent(e)}
                      value={emailContent}
                    />
                  </Grid>
                  <div style={{ display: 'block', width: '100%', margin: '30px 0px 10px' }}>
                    <OPRLabel variant="h2">Email Profile</OPRLabel>
                  </div>
                  <Grid item md={4} sm={1} xs={1}>
                    <OPRSelectorControl
                      isEditable
                      error={errors?.emailProfile}
                      keyName="label"
                      label={t('email_profile')}
                      multiple={false}
                      name="emailProfile"
                      options={emailProfileData?.emailProfiles || []}
                      placeholder="Select"
                      value={values?.emailProfile}
                      valueKey="label"
                      onChange={(text:any) => {
                        handleOnChange('emailProfile', text)
                      }}
                    />
                  </Grid>
                  <Grid item md={2} sm={1} xs={1}>
                    <OPRInputControl
                      isEditable
                      error={t(errors?.sender)}
                      label="sender"
                      name="sender"
                      value={getEmailProfileByIdResponse?.data?.sender}
                      onChange={handleChange}
                    />
                  </Grid>
                  <Grid item md={4} sm={1} xs={1}>
                    <OPRLabel
                      CustomStyles={{
                        display: 'flex',
                        alignItems: 'flex-start',
                        gap: '0px',
                        alignSelf: 'stretch',
                        marginBottom: '10px',
                      }}
                    >
                      {t('recipient_TOList')}
                    </OPRLabel>
                    {getEmailProfileByIdResponse?.data?.recipientTOList.map((option:any, index:any) => (
                      <Chip
                        label={option}
                        sx={{ margin: '3px' }}
                      />
                    ))}
                  </Grid>
                  <Grid item md={4} sm={1} xs={1}>
                    <OPRLabel
                      CustomStyles={{
                        display: 'flex',
                        alignItems: 'flex-start',
                        gap: '0px',
                        alignSelf: 'stretch',
                        marginBottom: '10px',
                      }}
                    >
                      {t('recipient_CCList')}
                    </OPRLabel>
                    {getEmailProfileByIdResponse?.data?.recipientCCList.map((option:any, index:any) => (
                      <Chip
                        label={option}
                        sx={{ margin: '3px' }}
                      />
                    ))}
                  </Grid>
                  <Grid item md={4} sm={1} xs={1}>
                    <OPRLabel
                      CustomStyles={{
                        display: 'flex',
                        alignItems: 'flex-start',
                        gap: '0px',
                        alignSelf: 'stretch',
                        marginBottom: '10px',
                      }}
                    >
                      {t('recipient_BCCList')}
                    </OPRLabel>
                    {getEmailProfileByIdResponse?.data?.recipientBCCList.map((option:any, index:any) => (
                      <Chip
                        label={option}
                        sx={{ margin: '3px' }}
                      />
                    ))}
                  </Grid>
                  <div style={{ display: 'block', width: '100%', margin: '30px 0px 10px' }}>
                    <OPRLabel variant="h2">Attached common file</OPRLabel>
                  </div>
                  {commonFile[0]?.path && (
                    commonFile.map((file:any) => (
                      <Box sx={{
                        display: 'flex', flexDirection: 'row', justifyContent: 'space-between',
                      }}
                      >
                        <Box sx={{
                          display: 'flex', flexDirection: 'row', marginTop: '5px',
                        }}
                        >
                          <ExcelIcon />
                          <OPRLabel variant="body2">{file?.path}</OPRLabel>
                        </Box>
                      </Box>
                    ))
                  )}
                  <div style={{ display: 'block', width: '100%', margin: '30px 0px 10px' }}>
                    <OPRLabel variant="h2">Email records</OPRLabel>
                  </div>
                  <OPREnhancedTable
                    isMovement
                    cols={sendPaySlipColumn(handleClick)}
                    data={checkedValue || []}
                    handleClick={handleClick}
                    isSelected={isSelected}
                  />
                </OPRResponsiveGrid>
              </Box>
            )}
          </Box>
        </OPRInnerFormLayout>
      </div>
    </Box>
  )
}
