import { Box, Checkbox } from '@mui/material'
import OPRLabel from 'components/atoms/label/OPRLabel'
import OPREnhancedTable from 'components/atoms/table/OPREnhancedTable'
import OPRResponsiveGrid from 'components/molecules/OPRResponsiveGrid'

export default function SendPaySlip({
  selected,
  paySlipFile,
  handleSelectAllClick,
  selectFileColumn,
  handleClick,
  isSelected,
}:any) {
  return (
    <>
      <OPRLabel
        label="Files"
        sx={{
          marginBottom: '15px',
        }}
        variant="body1"
      />
      <OPRResponsiveGrid>
        <Box sx={{
          display: 'flex',
          flexDirection: 'row',
          alignItems: 'center',
        }}
        >
          <Checkbox
            checked={selected.length === paySlipFile?.length}
            indeterminate={selected.length > 0 && selected.length < paySlipFile?.length}
            onChange={handleSelectAllClick}
          />
          <OPRLabel variant="body2">Select All</OPRLabel>
        </Box>
        <OPREnhancedTable
          isMovement
          cols={selectFileColumn(handleClick)}
          // data={JSON.parse(JSON.stringify(paySlipFile || []))}
          data={(paySlipFile || [])}
          handleClick={handleClick}
          isSelected={isSelected}
          steps={1}
        />
        {/* total employee selected */}
        <div style={{
          width: '100%',
          padding: 12,
          background: '#E9F4FF',
          borderRadius: 4,
          justifyContent: 'flex-start',
          alignItems: 'flex-start',
          gap: 12,
          display: 'inline-flex',
        }}
        >
          <div style={{
            flex: '1 1 0',
            flexDirection: 'column',
            justifyContent: 'flex-start',
            alignItems: 'flex-start',
            display: 'inline-flex',
          }}
          >
            <div style={{
              alignSelf: 'stretch',
              color: '#3B3839',
              fontSize: 16,
              fontFamily: 'Lato',
              fontWeight: '700',
              wordWrap: 'break-word',
            }}
            >
              Total selected files:
              {' '}
              {selected.length}
            </div>
          </div>
        </div>
      </OPRResponsiveGrid>
    </>
  )
}
