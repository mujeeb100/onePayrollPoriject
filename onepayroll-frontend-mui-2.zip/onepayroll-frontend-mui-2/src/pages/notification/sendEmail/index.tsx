import {
  Box,
  FormControlLabel,
  Radio,
  RadioGroup,
} from '@mui/material'
import { useGetAllSendEmailLogsQuery } from 'api/loggingServices'
import { LeftCaret } from 'assets/svg-images/SvgComponents'
import OPRButton from 'components/atoms/button/OPRButton'
import OPRLabel from 'components/atoms/label/OPRLabel'
import { CustomDialog } from 'components/atoms/modal/OPRModal'
import { sendEmailColumn } from 'components/atoms/table/OPRTableConstant'
import { OPRInnerListLayout } from 'components/organism/OPRInnerLayoutList'
import { t } from 'i18next'
import React, { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { routes } from 'routes/routes'

function SendEmailList() {
  const navigate: any = useNavigate()
  const [openMadal, setModal]:any = React.useState(false)
  const [userRoleOperation, setRoleOperation]:any = React.useState('')
  const [filterData, setFilterData]:any = useState({
    pageNumber: 1,
    pageSize: 20,
    totalItems: 0,
    orderByAsc: true,
    sortBy: '',
    SearchText: '',
  })
  const {
    data: allPosts,
    isLoading: isLoadingAllPosts,
    isSuccess: isSuccessAllPosts,
    isError: isErrorAllPosts,
    error: errorAllPosts,
    refetch: refetchAllPosts,
  } = useGetAllSendEmailLogsQuery('')

  //   const [deleteCostCenterById,
  //     {
  //       data: deleteCostCenterResponse,
  //       error: deleteCostCenterError,
  //       isLoading: deleteCostCenterLoading,
  //       isSuccess: deleteCostCenterSuccess,
  //       isError: deleteCostCenterIsError,
  //     }] = useCostCenterDeleteMutation()

  const sorting = (
    event: React.MouseEvent<unknown>,
    property: keyof any,
  ) => {
    const isAsc = filterData.sortBy === property && filterData.orderByAsc === true
    setFilterData({ ...filterData, orderByAsc: !isAsc, sortBy: property })
  }

  useEffect(() => {
    setFilterData({ ...filterData, totalItems: allPosts?.totalItems ? allPosts?.totalItems : 0 })
  }, [allPosts?.pageNumber, filterData.sortBy, filterData.orderByAsc, allPosts?.totalItems])

  const onSearch = (e: any, data: any) => {
    setFilterData({ ...filterData, ...data })
  }
  const handlePagination = (pageNumber: number, pageSize: number) => {
    setFilterData({ ...filterData, pageNumber })
  }

  const viewAcoount = (data: any, type:string) => {
    // if (type === 'edit cost center') {
    //   navigate(
    //     setRouteValues(`${routes.editCostCenter}`, {
    //       id: data.id,
    //     }),
    //   )
    // } else if (type === 'delete cost center') {
    //   // deleteCostCenterById(`Id=${data.id}`)
    //   setSelelctedDelete({ data, isDelete: true, name: data.costCenterCode })
    // } else {
    //   navigate(
    //     setRouteValues(`${routes.viewCostCenter}`, {
    //       id: data.id,
    //     }),
    //   )
    // }
  }
  const handleView = (data: any) => {
    // navigate(
    //   setRouteValues(`${routes.viewPensionFundScheme}`, {
    //     id: data.id,
    //     view: true,
    //   }),
    // )
  }
  return (
    <Box sx={{ display: 'flex' }}>
      <CustomDialog
        CustomStyles={{ borderRadius: '16px' }}
        isOpen={openMadal}
        type="loader"
      >
        <OPRLabel variant="h4">Send Email</OPRLabel>
        <RadioGroup
          row
          aria-labelledby="demo-row-radio-buttons-group-label"
          name="row-radio-buttons-group"
          sx={{ display: 'flex', flexDirection: 'column' }}
          value={userRoleOperation}
          onChange={(e) => {
            setRoleOperation(e.target.value)
          }}
        >
          <FormControlLabel control={<Radio />} label="Email notification" value="Email notification" />
          <FormControlLabel control={<Radio />} label="Payroll slip/report" value="Payroll slip/report" />
          {/* <FormControlLabel control={<Radio />} label="Remove entity" value="Delete Entity" /> */}
        </RadioGroup>
        <Box sx={{
          display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: 5,
        }}
        >
          <OPRButton
            color="info"
            variant="text"
            onClick={() => {
              setModal(false)
            }}
          >
            Cancel
          </OPRButton>
          <OPRButton
            variant="contained"
            onClick={() => {
              if (userRoleOperation === 'Email notification') {
                navigate(routes.createSendEmail)
              } else if (userRoleOperation === 'Payroll slip/report') {
                navigate(routes.createSendPaySlip)
              }
              // else {
              //   navigate(
              //     setRouteValues(`${routes.createClientGroupEntities}`, {
              //       id,
              //       view: false,
              //     }),
              //   )
              // }
            }}
          >
            Continue
            <LeftCaret />
          </OPRButton>
        </Box>
      </CustomDialog>
      <OPRInnerListLayout
        Search={filterData.SearchText}
        addHandleClick={() => setModal(true)}
        columns={sendEmailColumn(viewAcoount)}
        customAdd="Send email"
        dataList={JSON.parse(JSON.stringify(allPosts?.records || []))}
        deleteCallBack={() => {}}
        error={errorAllPosts}
        filterData={filterData}
        handlePagination={handlePagination}
        handleSearch={onSearch}
        isError={isErrorAllPosts}
        isExport={false}
        loading={isLoadingAllPosts}
        rowClickHandler={handleView}
        rowNumber={0}
        // selelctedUser={selelctedDelete}
        // setSelelctedUser={setSelelctedDelete}
        sortHandleClick={sorting}
        // success={deleteCostCenterSuccess}
        title={t('Emails')}
      />
    </Box>
  )
}

export default SendEmailList
