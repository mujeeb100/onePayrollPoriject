import 'react-quill/dist/quill.snow.css'
import '../../../styles/style.css'

import { CSSProperties, forwardRef } from 'react'
import ReactQuill from 'react-quill'

type RichTextEditorProps = {
  value: string;
  setValue: (value: string) => void;
  showToolbar?: boolean;
  isEditable?: boolean;
  style?: CSSProperties;
  getSelection?: (index: number) => void;
  activeState?: any; // Add this line
};

const RichTextEditor = forwardRef<ReactQuill, RichTextEditorProps>(
  (
    {
      value,
      setValue,
      showToolbar = true,
      isEditable,
      style = {},
      getSelection,
      activeState, // Add this line
    },
    ref,
  ) => {
    const handleBlur = (previousSelection: any) => {
      if (previousSelection !== null && getSelection) {
        const index = previousSelection.index || 0
        getSelection(index)
      }
    }
    // Override border when activeState is 6
    // const editorStyle = activeState === 6
    //   ? { border: 'none', height: '485px' }
    //   : { height: '485px', border: '0px solid #ccc' }
    // Conditional className for no-border
    const editorClass = activeState === 6 ? 'no-border' : ''

    return (
      <ReactQuill
        ref={ref}
        className={editorClass} // Apply the conditional class
        modules={{
          toolbar: showToolbar
            ? [
              [{ font: [] }],
              [{ size: ['small', false, 'large', 'huge'] }],
              ['bold', 'italic', 'underline', 'strike'],
              [{ color: [] }, { background: [] }],
              [{ script: 'sub' }, { script: 'super' }],
              [{ header: '1' }, { header: '2' }, 'blockquote', 'code-block'],
              [{ list: 'ordered' }, { list: 'bullet' }, { indent: '-1' }, { indent: '+1' }],
              [{ direction: 'rtl' }, { align: [] }],
              ['link', 'image', 'video', 'formula'],
              ['clean'],
            ]
            : false,
        }}
        placeholder="Compose an epic..."
        readOnly={!isEditable}
        style={{
          height: 'fit-content',
          maxHeight: '350px',
          overflowY: 'auto',
          ...style,
        }}
        theme="snow"
        value={value}
        onBlur={handleBlur}
        onChange={setValue}
      />
    )
  },
)

export default RichTextEditor
