import 'styles/style.css'

import { useTheme } from '@emotion/react'
import AddIcon from '@mui/icons-material/Add'
import {
  Box, Button, Grid, MenuItem, Select,
  SelectChangeEvent,
} from '@mui/material'
import {
  useEmailTemplateUpdateMutation,
  useGetAllEmailTemplateDropDownQuery, useGetAllEmailTemplatePlaceHolderQuery, useLazyGetEmailTemplateByIdQuery,
  useSendEmailTemplateCreateMutation,
} from 'api/noticationServices'
import { CrossIcon, TickIcon } from 'assets/svg-images/SvgComponents'
import OPRLabel from 'components/atoms/label/OPRLabel'
import { OPRConfirmationDialog, OPRConfirmationDialogProps } from 'components/molecules/OPRAlertControl/OPRConfirmationDialog'
import OPRInputControl from 'components/molecules/OPRInputControl'
import OPRResponsiveGrid from 'components/molecules/OPRResponsiveGrid'
import OPRSelectorControl from 'components/molecules/OPRSelectorControl/OPRSelectorControl'
import OPRErrorDialogFlow from 'components/organism/OPRErrorDialogFlow'
import { OPRInnerFormLayout } from 'components/organism/OPRInnerFormLayout'
import { validationSchemaEmailTemplate } from 'constants/validate'
import { useEditable } from 'hooks/useEdit'
import useForm from 'hooks/useForm'
import { t } from 'i18next'
import { useEffect, useRef, useState } from 'react'
import ReactQuill from 'react-quill'
import { useLocation, useNavigate } from 'react-router-dom'
import { routes } from 'routes/routes'
import { getParamsValue } from 'utils'

import RichTextEditor from '../sendEmail/TextEditor'

interface MessageProps {
  text?: string;
  important?: boolean;
}

export default function EmailTemplateForm() {
  const richTextEditorRef = useRef<ReactQuill>(null)
  const [cursorPosition, setCursorPosition] = useState<number | null>(null)
  const location: any = useLocation()
  // const id = getParamsValue(location, routes.createSendEmail)
  const { id, viewUrl } = getParamsValue(location, routes.createSendEmail)
  const [mode, setMode] = useState('view') // Default mode is edit
  const { isEditable, setEditable } = useEditable()
  // const [emailTemplateData1, setEmailTemplateData]:any = useState(null)
  const [emailContent, setEmailContent] = useState('')
  const [showKeywordDropdown, setShowKeywordDropdown] = useState(false)
  const [selectedKeyword, setSelectedKeyword] = useState('')
  const [placeholderData, setPlaceholderData] = useState([])
  const theme:any = useTheme() // Use the Theme type for the theme variable

  const {
    values,
    setValues,
    errors,
    handleChange,
    setErrors,
    handleOnChange,
    handleFormSubmit,
  } = useForm(validationSchemaEmailTemplate)

  const [successDialog, setSuccessDialog] = useState<OPRConfirmationDialogProps>({
    open: false,
    icon: <TickIcon />,
    buttonLayout: 'confirm',
    title: '',
  })

  const [errorDialog, setErrorDialog] = useState<OPRConfirmationDialogProps>({
    open: false,
    title: '',
    message: '',
    icon: <CrossIcon />,
    buttonLayout: 'try-again',
  })

  const navigate = useNavigate()

  const [
    createSendEmail,
    {
      data: createdSendEmailData,
      error: createdSendEmailError,
      isLoading: createdSendEmailLoading,
      isSuccess: createdSendEmailIsSuccess,
      isError: createdSendEmailIsError,
    },
  ] = useSendEmailTemplateCreateMutation()

  useEffect(() => {
    if (createdSendEmailIsSuccess) {
      setSuccessDialog({
        ...successDialog,
        open: true,
        buttonLayout: 'add-another',
        title: t('New email template added'),
        addAnotherButtonTitle: t('Add another email template'),
        message: `${values?.emailTemplateName} ${t('has been added.')}`,
        onClose: () => {
          setSuccessDialog({ ...successDialog, open: false })
          navigate(routes.emailTemplate)
        },
        onAddAnother: () => {
          setSuccessDialog({ ...successDialog, open: false })
          setEditable(true)
          setValues({})
        },
      })
    }

    if (createdSendEmailIsError) {
      const dismiss = () => setErrorDialog({ ...errorDialog, open: false })
      setErrorDialog({
        ...errorDialog,
        open: true,
        error: createdSendEmailError,
        title: t('Failed to add email template'),
        onTryAgain: () => {
          dismiss()
          createEmailTemplate()
        },
        onBack: () => {
          dismiss()
        },
      })
    }
  }, [createdSendEmailIsSuccess, createdSendEmailIsError])

  const {
    data: emailTemplateData,
    error: createAllTemplateError,
    isLoading: isLoadingTemplate,
    isSuccess: isSuccessTemplate,
    isError: isErrorTemplate,
    error: errorTemplate,
  } = useGetAllEmailTemplateDropDownQuery('')

  const [
    updateEmailTemplateUpdate,
    {
      data: updatedEmailTemplateByResponse,
      error: updatedEmailTemplateByError,
      isLoading: updatedEmailTemplateByLoading,
      isSuccess: updatedEmailTemplateIsSuccess,
      isError: updatedEmailTemplateByIsError,
    },
  ] = useEmailTemplateUpdateMutation()

  const {
    data: AllRecordskeyWordPlaceHolderData,
    isLoading: isLoadingkeyWordPlaceHolderData,
    isSuccess: isSuccesskeyWordPlaceHolderData,
    isError: isErrorkeyWordPlaceHolderData,
    error: errorkeyWordPlaceHolderData,
  } = useGetAllEmailTemplatePlaceHolderQuery('')

  useEffect(() => {
    if (updatedEmailTemplateIsSuccess) {
      setSuccessDialog({
        ...successDialog,
        open: true,
        buttonLayout: 'close',
        title: t('Email template udpatd'),
        message: `${values?.emailTemplateName} ${t('has been updated.')}`,
        onClose: () => {
          setSuccessDialog({ ...successDialog, open: false })
          navigate(routes.emailTemplate)
        },
      })
    }

    if (updatedEmailTemplateByIsError) {
      const dismiss = () => setErrorDialog({ ...errorDialog, open: false })
      setErrorDialog({
        ...errorDialog,
        open: true,
        error: createdSendEmailError,
        title: t('Failed to update email template'),
        onTryAgain: () => {
          dismiss()
          updateEmailTemplate()
        },
        onBack: () => {
          dismiss()
        },
      })
    }
  }, [updatedEmailTemplateIsSuccess, updatedEmailTemplateByIsError])

  const {
    data: emailPlaceholderData,
    error: createAllPlaceholderError,
    isLoading: isLoadingPlaceholder,
    isSuccess: isSuccessPlaceholder,
    isError: isErrorPlaceholder,
    error: errorPlaceholder,
  } = useGetAllEmailTemplatePlaceHolderQuery('')

  // email template place holder
  const [
    updateEmailTemplateBId,
    {
      data: updatedEmailTemplate1ByIdResponse,
      error: updatedEmailTemplate1ByIdError,
      isLoading: updatedEmailTemplate1ByIdLoading,
      isSuccess: updatedEmailTemplate1ByIdSuccess,
      isError: updatedEmailTemplate1ByIdIsError,
    },
  ] = useLazyGetEmailTemplateByIdQuery()

  useEffect(() => {
    if (updatedEmailTemplate1ByIdResponse?.data) {
      const {
        emailTemplateCode, emailTemplateName, emailTemplateType, emailSubject, emailContent,
      } = updatedEmailTemplate1ByIdResponse.data
      setValues({
        id: updatedEmailTemplate1ByIdResponse.data.id,
        emailTemplateCode,
        emailTemplateName,
        emailTemplateTypeId: updatedEmailTemplate1ByIdResponse.data.emailTemplateType.id,
        emailSubject,
        emailContent,
        // emailContent: updatedEmailTemplate1ByIdResponse.data.emailContent, // please remove this line if this is not work
      })
      setEmailContent(emailContent)
    } else {
      setValues(location.state ? location.state : {})
    }
  }, [updatedEmailTemplate1ByIdResponse?.data])

  // console.log(updatedEmailTemplate1ByIdResponse.data, 'updatedEmailTemplate1ByIdResponse')

  useEffect(() => {
    if (id) {
      updateEmailTemplateBId(id)
      setEditable(viewUrl)
    }
  }, [])

  const createEmailTemplate = () => {
    createSendEmail({
      emailTemplateCode: values?.emailTemplateCode,
      emailTemplateName: values?.emailTemplateName,
      emailTemplateTypeId: values?.emailTemplateTypeId,
      //   emailTemplateTypeId: 2,
      emailSubject: values?.emailSubject,
      emailContent: emailContent || '',
    })
  }

  const updateEmailTemplate = () => {
    const selectedTemplateType = (emailTemplateData?.emailTemplateTypes || []).find((type:any) => type.id === values?.emailTemplateTypeId)
    updateEmailTemplateUpdate({
      id: values?.id,
      emailTemplateCode: values?.emailTemplateCode,
      emailTemplateName: values?.emailTemplateName,
      emailTemplateTypeId: values?.emailTemplateTypeId,
      emailTemplateType: null,
      emailSubject: values?.emailSubject,
      emailContent: values?.emailContent || '',
    })
  }

  const handleSubmit: any = async () => {
    if (isEditable) {
      if (id === null || id === 'emailTemplate') {
        createEmailTemplate()
      } else {
        updateEmailTemplate()
      }
    } else {
      setEditable(true)
    }
  }

  const onScreenClose:any = (item: any) => {
    setEditable(item)
    setValues({})
  }

  const handleKeywordButtonClick = () => {
    setShowKeywordDropdown(true)
  }

  const handleKeywordSelect = (event: SelectChangeEvent<string>) => {
    const selected = event.target.value
    setSelectedKeyword(selected)
    const contentEditor = richTextEditorRef.current?.getEditor()
    if (contentEditor) {
      if (cursorPosition) {
        contentEditor.insertText(cursorPosition, selected)
        contentEditor.setSelection(cursorPosition + selected.length, 0)
      } else {
        contentEditor.insertText(0, selected)
        contentEditor.setSelection(selected.length, 0)
      }
    }
    setShowKeywordDropdown(false)
    setSelectedKeyword('')
  }

  useEffect(() => {
    if (isSuccesskeyWordPlaceHolderData && AllRecordskeyWordPlaceHolderData) {
      setPlaceholderData(AllRecordskeyWordPlaceHolderData.emailTemplatePlaceholders)
    }
  }, [isSuccesskeyWordPlaceHolderData, AllRecordskeyWordPlaceHolderData])
  return (
    <Box sx={{ display: 'flex' }}>
      <form
        style={{ display: 'flex', width: '100% ' }}
        onSubmit={(e) => handleFormSubmit(e, handleSubmit)}
      >
        <OPRConfirmationDialog
          key="confirmation-dialog"
          {...successDialog}
        />

        <OPRErrorDialogFlow
          key="error-dialog"
          dialogProps={errorDialog}
          setDialogProps={setErrorDialog}
        />

        <OPRInnerFormLayout
          error={createdSendEmailError}
          handleCancelClick={() => navigate(-1)}
          handleContinueClick={handleSubmit}
          handleEditable={() => {
            setEditable(true)
          }}
          isBackButton={isEditable}
          isLoading={
            createdSendEmailLoading || updatedEmailTemplateByLoading || updatedEmailTemplate1ByIdLoading
          }
          pageType="detailsPage"
          subtitle={
            isEditable
              ? 'Please check the user details below.'
              : 'All fields are mandatory except those marked optional'
          }
          title={id ? t('Add email template') : false || ((id) ? values?.SendEmailDescription : `${t('add')} ${t('email template')}`)} // Set title based on mode
          onScreenClose={onScreenClose}
        >
          <Box>
            <OPRResponsiveGrid>
              <Grid item xs={12}>
                <div className="ServiceProvider">
                  General information
                </div>
              </Grid>
              {/* Email Template ID */}
              <Grid item md={2} sm={1} xs={1}>
                <OPRInputControl
                  error={errors?.emailTemplateCode}
                  isEditable={isEditable}
                  label={t('Email template ID')}
                  name="emailTemplateCode"
                  value={values?.emailTemplateCode}
                  onChange={handleChange}
                />
              </Grid>
              {/* Email template name */}
              <Grid item md={2} sm={1} xs={1}>
                <OPRInputControl
                  error={errors?.emailTemplateName}
                  isEditable={isEditable}
                  label={t('Email template name')}
                  name="emailTemplateName"
                  value={values?.emailTemplateName}
                  onChange={handleChange}
                />
              </Grid>
              {/* Email template type */}
              <Grid item md={2} sm={1} xs={1}>
                <OPRSelectorControl
                  error={errors?.emailTemplateTypeId}
                  isEditable={isEditable}
                  keyName="label"
                  label={t('Email template type')}
                  multiple={false}
                  name="emailTemplateTypeId"
                  options={emailTemplateData?.emailTemplateTypes || []}
                  placeholder="Select"
                  // value={values?.emailTemplateTypeId}
                  value={(emailTemplateData?.emailTemplateTypes || []).find((o:any) => (o.id === values?.emailTemplateTypeId))}
                  valueKey="label"
                  onChange={(text:any) => {
                    handleOnChange('emailTemplateTypeId', text?.id)
                    // getEmailTemplateById(text?.id)
                  }}
                />
              </Grid>
              <Grid item xs={12}>
                <div className="ServiceProvider">
                  Email
                </div>
              </Grid>
              {/* keyword feature */}
              <Grid item md={4} sm={1} xs={1}>
                <Box
                  style={{
                    width: '100%',
                    height: '100%',
                    borderRadius: 110,
                    overflow: 'hidden',
                    justifyContent: 'flex-start',
                    alignItems: 'center',
                    display: 'inline-flex',
                    textAlign: 'left',
                  }}
                >
                  <div>
                    <Button
                      className="ServiceProvider"
                      style={{
                        color: '#0049DB',
                        fontSize: 16,
                        fontFamily: 'Lato',
                        fontWeight: '700',
                        wordWrap: 'break-word',
                      }}
                      onClick={handleKeywordButtonClick}
                    >
                      <AddIcon />
                      {' '}
                      Keyword
                    </Button>
                    {showKeywordDropdown && (
                      <Select
                        autoFocus
                        displayEmpty
                        value={selectedKeyword}
                        onChange={handleKeywordSelect}
                      >
                        {placeholderData.map((placeholder: any) => (
                          <MenuItem key={placeholder.label} value={placeholder.label}>
                            {placeholder.label}
                          </MenuItem>
                        ))}
                      </Select>
                    )}
                  </div>
                </Box>
              </Grid>
              {/* Email Subject */}
              <Grid item md={4} sm={1} xs={1}>
                <OPRInputControl
                  error={t(errors?.emailSubject)}
                  isEditable={isEditable}
                  label="email_subject"
                  name="emailSubject"
                  value={values?.emailSubject}
                  onChange={handleChange}
                />
              </Grid>
              {/* email content */}
              <Grid item md={4} sm={1} xs={1}>
                <OPRLabel
                  CustomStyles={{
                    display: 'flex',
                    alignItems: 'flex-start',
                    gap: '0px',
                    alignSelf: 'stretch',
                  }}
                >
                  {t('email_content')}
                </OPRLabel>
                <RichTextEditor
                  ref={richTextEditorRef}
                  getSelection={setCursorPosition}
                  isEditable={!isEditable}
                  setValue={(e: any) => setEmailContent(e)}
                  value={emailContent}
                />
                {/* <OPRLabel color={theme.palette.error.contrastText} variant="body2">{errors.emailContent}</OPRLabel> */}
              </Grid>
            </OPRResponsiveGrid>
          </Box>
        </OPRInnerFormLayout>
      </form>
    </Box>
  )
}
