import { Box } from '@mui/material'
import OPRPageHeader from 'components/molecules/OPRPageHeader'

function DataUploadForm() {
  return (
    <Box sx={{ display: 'fled' }}>
      <OPRPageHeader
        subTitle="lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua." // prettier-ignore
        subTitleComponent="p"
        subTitleVariant="subtitle1"
        title="Data Upload"
        titleComponent="h1"
        titleVariant="h3"
      />
    </Box>
  )
}

export default DataUploadForm
