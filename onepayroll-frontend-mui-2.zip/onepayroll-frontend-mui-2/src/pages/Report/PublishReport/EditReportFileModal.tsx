import {
  Box,
  Button, Dialog, DialogActions, DialogContent, DialogTitle,
  Grid,
  TextField,
} from '@mui/material'
import OPRLabel from 'components/atoms/label/OPRLabel'
import OPRDatePickerControl from 'components/molecules/OPRDatePickerControl/OPRDatePickerControl'
import OPRInputControl from 'components/molecules/OPRInputControl'
import OPRResponsiveGrid from 'components/molecules/OPRResponsiveGrid'
import OPRSelectorControl from 'components/molecules/OPRSelectorControl/OPRSelectorControl'
import OPRAlertControl from 'components/organism/OPRAlertControl'
import { validationSchemaPaycyclegeneration } from 'constants/validate'
import useForm from 'hooks/useForm'
import moment from 'moment'
import { useEffect, useState } from 'react'
import { formatedYearDate } from 'utils'

interface FileData {
  id: number;
  fileName: string;
  releaseDate: string; // Ensure this is a string
  remarks: string;
  downloadStatus: string;
}

interface EditReportFileModalProps {
  open: boolean;
  onClose: () => void;
  fileData: FileData | null;
  onSave: (data: FileData) => void;
}

function EditReportFileModal({
  open, onClose, fileData, onSave,
}: EditReportFileModalProps) {
  const [formData, setFormData] = useState<FileData | null>(fileData)
  const [isEditable, setIsEditable] = useState(false)
  const {
    values,
    setValues,
    errors,
    handleChange,
    setErrors,
    handleFormSubmit,
    handleOnChange,
  } = useForm(validationSchemaPaycyclegeneration)

  useEffect(() => {
    if (fileData) {
      // Convert date string to a formatted string if needed
      const formattedFileData = {
        ...fileData,
        releaseDate: formatedYearDate(fileData.releaseDate || ''), // Store as string directly
        // releaseDate: values?.releaseDate ? new Date(values.releaseDate).toLocaleDateString() : '', // Adjust format if needed
      }
      setFormData(formattedFileData)
      setValues(formattedFileData)
    }
  }, [fileData, setValues])

  const handleInputChange = (name: string, value: any) => {
    setFormData((prev) => (prev ? { ...prev, [name]: value } : null))
    handleOnChange(name, value)
  }

  const handleSave = () => {
    if (formData) {
      onSave(formData)
      onClose()
    }
  }

  if (!fileData) return null

  const downloadStatusOptions = [
    { id: 'active', label: 'Active' },
    { id: 'Inactive', label: 'Inactive' },
    { id: 'Disabled', label: 'Disabled' },
  ]
  console.log(values?.releaseDate ? new Date(values.releaseDate).toLocaleDateString() : '', 'releasedate')
  console.log(values?.downloadStatus, 'downloadstataus')
  return (
    <Box>
      <OPRAlertControl
        isCustom
        type="New"
      />
      <Dialog open={open} onClose={onClose}>
        <DialogTitle>Edit report file</DialogTitle>
        <DialogContent>
          <OPRResponsiveGrid>
            <Grid item md={4} sm={6} xs={12}>
              <OPRLabel CustomStyles={{ marginBottom: '15px' }} variant="body2">File Name</OPRLabel>
              <TextField
                disabled
                fullWidth
                value={fileData.fileName}
                variant="outlined"
              />
            </Grid>
            <Grid item md={4} sm={6} xs={12}>
              <OPRDatePickerControl
                isEditable={isEditable}
                label="Release Date"
                name="releaseDate"
                value={values?.releaseDate ? moment(values.releaseDate).format('MM/DD/YYYY') : ''} // Convert to the correct date format
                onChange={(date) => {
                  if (date) {
                    handleInputChange('releaseDate', moment(date).format('YYYY-MM-DD')) // Store in 'YYYY-MM-DD' format
                  } else {
                    handleInputChange('releaseDate', '') // Handle null date
                  }
                }}
              />
            </Grid>
            <Grid item md={4} sm={6} xs={12}>
              <OPRInputControl
                isEditable={isEditable}
                label="File Remarks"
                name="remarks"
                value={values?.remarks}
                onChange={(e) => handleInputChange('remarks', e.target.value)}
              />
            </Grid>
            <Grid item md={2} sm={1} xs={1} />
            <Grid item md={4} sm={6} xs={12}>
              <OPRSelectorControl
                isEditable={isEditable}
                keyName="label"
                label="Download Status"
                multiple={false}
                name="downloadStatus"
                options={downloadStatusOptions}
                placeholder="Select"
                value={downloadStatusOptions.find((o: any) => o?.id === values?.downloadStatus)}
                valueKey="id"
                onChange={(text: any) => handleInputChange('downloadStatus', text.id)}
              />
            </Grid>
          </OPRResponsiveGrid>
        </DialogContent>
        <DialogActions>
          <Button onClick={onClose}>Cancel</Button>
          <Button color="primary" onClick={handleSave}>Save changes</Button>
        </DialogActions>
      </Dialog>
    </Box>
  )
}

export default EditReportFileModal
