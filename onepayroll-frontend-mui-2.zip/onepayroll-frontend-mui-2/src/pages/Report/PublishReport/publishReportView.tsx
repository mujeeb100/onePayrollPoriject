import {
  Box,
} from '@mui/material'
import { useLazyGetPublishReportByIdQuery } from 'api/reportingServices'
import { reportViewColumn } from 'components/atoms/table/OPRTableConstant'
import { OPRInnerListLayout } from 'components/organism/OPRInnerLayoutList'
import { t } from 'i18next'
import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { routes } from 'routes/routes'
import { getParamsValue, setRouteValues } from 'utils'

function PublishReportView() {
  const navigate: any = useNavigate()
  const [value, setValue] = React.useState(0)
  const { id, referenceNumber, viewUrl } = getParamsValue(window.location, routes.createClientGroupProfile)
  const [filterData, setFilterData]:any = useState({
    actionStatus: 'Draft',
  })
  const [getPublishReportById, {
    data: allPosts,
    error: isErrorAllPosts,
    isLoading: isLoadingAllPosts,
    isSuccess: isSuccessAllPosts,
    isError: errorAllPosts,
  }] = useLazyGetPublishReportByIdQuery()

  React.useEffect(() => {
    if (id) {
      getPublishReportById(`${id}&pageSize=10000`)
      // setEditable(viewUrl)
    }
  }, [])
  // data.totalItems
  //   const [deleteCostCenterById,
  //     {
  //       data: deleteCostCenterResponse,
  //       error: deleteCostCenterError,
  //       isLoading: deleteCostCenterLoading,
  //       isSuccess: deleteCostCenterSuccess,
  //       isError: deleteCostCenterIsError,
  //     }] = useCostCenterDeleteMutation()

  const sorting = (
    event: React.MouseEvent<unknown>,
    property: keyof any,
  ) => {
    const isAsc = filterData.sortBy === property && filterData.orderByAsc === true
    setFilterData({ ...filterData, orderByAsc: !isAsc, sortBy: property })
  }
  // useEffect(() => {
  //   setFilterData({ ...filterData, totalItems: allPosts?.data?.totalItems ? allPosts?.data?.totalItems : 0 })
  // }, [allPosts?.data?.pageNumber, filterData.sortBy, filterData.orderByAsc, allPosts?.data?.totalItems])

  const onSearch = (e: any, data: any) => {
    setFilterData({ ...filterData, ...data })
  }
  const handlePagination = (pageNumber: number, pageSize: number) => {
    setFilterData({ ...filterData, pageNumber })
  }

  const viewAcoount = (data: any, type:string) => {
    // if (type === 'edit cost center') {
    //   navigate(
    //     setRouteValues(`${routes.editCostCenter}`, {
    //       id: data.id,
    //     }),
    //   )
    // } else if (type === 'delete cost center') {
    //   // deleteCostCenterById(`Id=${data.id}`)
    //   setSelelctedDelete({ data, isDelete: true, name: data.costCenterCode })
    // } else {
    //   navigate(
    //     setRouteValues(`${routes.viewCostCenter}`, {
    //       id: data.id,
    //     }),
    //   )
    // }
  }
  const handleView = (data: any) => {
    navigate(
      setRouteValues(`${routes.viewCompanyBankAccount}`, {
        id: data.id,
        view: true,
      }),
    )
  }
  // handle Delete
  //   const handleDelete = (data:any) => {
  //     deleteCostCenterById(`Id=${data.id}`)
  //   }
  return (
    <Box sx={{ display: 'flex' }}>
      <OPRInnerListLayout
        isBack
        addHandleClick={() => {
          navigate(routes.createpublishReport, {
            state: {
              id,
              referenceNumber,
            },
          })
        }}
        columns={reportViewColumn(viewAcoount)}
        customAdd="Publish reports"
        dataList={JSON.parse(JSON.stringify(allPosts?.data?.records || []))}
        deleteCallBack={() => {}}
        error={errorAllPosts}
        filterData={filterData}
        // handlePagination={handlePagination}
        handleSearch={onSearch}
        // isError={isErrorAllPosts}
        isSearch={false}
        loading={isLoadingAllPosts}
        // rowClickHandler={handleView}
        rowNumber={0}
        // selelctedUser={selelctedDelete}
        // setSelelctedUser={setSelelctedDelete}
        // Search={filterData.SearchText}
        sortHandleClick={sorting}
        // success={deleteCostCenterSuccess}
        title={t('report_files_title')}
      />
    </Box>
  )
}

export default PublishReportView
