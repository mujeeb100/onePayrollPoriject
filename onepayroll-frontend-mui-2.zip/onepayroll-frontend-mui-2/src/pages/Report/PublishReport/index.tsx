import {
  Box,
  Dialog,
  DialogActions,
  DialogContent,
  DialogContentText,
  DialogTitle,
} from '@mui/material'
import { useGetAllPublishReportLogsQuery } from 'api/loggingServices'
import { useGetAllPublishReportQuery } from 'api/reportingServices'
import OPRButton from 'components/atoms/button/OPRButton'
import OPRLabel from 'components/atoms/label/OPRLabel'
import { generationRefColumn, publishReportColumn } from 'components/atoms/table/OPRTableConstant'
import {
  a11yProps,
  CustomTabPanel, StyledTab, StyledTabs,
} from 'components/atoms/tabs'
import OPRSearchIcon from 'components/molecules/OPRSearchIcon'
import { OPRInnerListLayout } from 'components/organism/OPRInnerLayoutList'
import { t } from 'i18next'
import React, { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { routes } from 'routes/routes'
import {
  generateFilterUrl, setRouteValues,
} from 'utils'

function PublishReportList() {
  const navigate: any = useNavigate()
  const [noRecordsMessage, setNoRecordsMessage] = useState('')
  const [openDialog, setOpenDialog] = useState(false)
  const [value, setValue] = React.useState(0)
  const [jobs, setJobs] = React.useState([])
  const [selelctedDelete, setSelelctedDelete]:any = useState({
    data: {},
    isDelete: false,
    name: '',
  })
  const [filterData, setFilterData]:any = useState({
    pageNumber: 1,
    pageSize: 10000,
    totalItems: 0,
    orderByAsc: false,
    sortBy: '',
    SearchText: '',
    // actionStatus: 'Draft',
  })
  const [isDialogOpen, setIsDialogOpen] = useState(false)
  const [dialogContent, setDialogContent] = useState('')

  const [filterDataPayrollLogs, setFilterDataPayrollLogs]:any = useState({
    pageNumber: 1,
    pageSize: 1000,
    logFunction: 'PublishReport',
  })
  const handleTabChange = (event: React.SyntheticEvent, newValue: number) => {
    setValue(newValue)
  }
  const {
    data: allPosts,
    isLoading: isLoadingAllPosts,
    isSuccess: isSuccessAllPosts,
    isError: isErrorAllPosts,
    error: errorAllPosts,
    refetch: refetchAllPosts,
  } = useGetAllPublishReportQuery(`${generateFilterUrl(filterData)}&actionStatus=Void%2CFinalized`)

  const {
    data: allPostsLogs,
    isLoading: isLoadingAllPostsLogs,
    isSuccess: isSuccessAllPostsLogs,
    isError: isErrorAllPostsLogs,
    error: errorAllPostsLogs,
    refetch: refetchAllPostsLogs,
  } = useGetAllPublishReportLogsQuery(generateFilterUrl(filterDataPayrollLogs))

  //   const [deleteCostCenterById,
  //     {pollingInterval: 5000,
  //       data: deleteCostCenterResponse,
  //       error: deleteCostCenterError,
  //       isLoading: deleteCostCenterLoading,
  //       isSuccess: deleteCostCenterSuccess,
  //       isError: deleteCostCenterIsError,
  //     }] = useCostCenterDeleteMutation()

  const sorting = (
    event: React.MouseEvent<unknown>,
    property: keyof any,
  ) => {
    const isAsc = filterData.sortBy === property && filterData.orderByAsc === true
    setFilterData({ ...filterData, orderByAsc: !isAsc, sortBy: property })
  }

  useEffect(() => {
    setFilterData({ ...filterData, totalItems: allPosts?.totalItems ? allPosts?.totalItems : 0 })
  }, [allPosts?.pageNumber, filterData.sortBy, filterData.orderByAsc, allPosts?.totalItems])

  useEffect(() => {
    if (isSuccessAllPosts) {
      const jobItems:any = []
      JSON.parse(JSON.stringify(allPosts?.records || [])).forEach((item: any) => {
        item.jobs.forEach((job: any) => {
          jobItems.push(job)
        })
      })
      setJobs(jobItems)
    }
  }, [isSuccessAllPosts])

  const onSearch = (e: any) => {
    setFilterData({ ...filterData, SearchText: e.target.value })
  }
  const handlePagination = (pageNumber: number, pageSize: number) => {
    setFilterData({ ...filterData, pageNumber })
  }

  const viewAcoount = (data: any, type:string) => {
    // if (type === 'edit cost center') {
    //   navigate(
    //     setRouteValues(`${routes.editCostCenter}`, {
    //       id: data.id,
    //     }),
    //   )
    // } else if (type === 'delete cost center') {
    //   // deleteCostCenterById(`Id=${data.id}`)
    //   setSelelctedDelete({ data, isDelete: true, name: data.costCenterCode })
    // } else {
    //   navigate(
    //     setRouteValues(`${routes.viewCostCenter}`, {
    //       id: data.id,
    //     }),
    //   )
    // }
  }
  const handleView = (data: any) => {
    navigate(
      setRouteValues(`${routes.viewpublishReport}`, {
        state: { id: data.id, filterData, referenceNumber: data.referenceNumber },
        id: data.id,
        // view: true,
        referenceNumber: data.referenceNumber,
      }),
    )
  }
  // handle Delete
  //   const handleDelete = (data:any) => {
  //     deleteCostCenterById(`Id=${data.id}`)
  //   }

  const handleCloseDialog = () => {
    setOpenDialog(false)
  }

  const handleRowClick = (data: any) => {
    // Replace with the desired action, e.g., opening a modal with details
    setDialogContent(`Details for Job ID: ${data.jobID}`) // Example
    setIsDialogOpen(true)
  }

  const handleFileDownload = (jsonString: string, filename: string) => {
    try {
      // Parse the JSON string
      const jsonData = JSON.parse(jsonString)

      // Convert JSON data to a Blob
      const blob = new Blob([JSON.stringify(jsonData, null, 2)], { type: 'application/json' })

      // Create a link element and click it to start the download
      const link = document.createElement('a')
      link.href = URL.createObjectURL(blob)
      link.download = `${filename}.json`
      document.body.appendChild(link)
      link.click()
      document.body.removeChild(link)
    } catch (error) {
      console.error('Error parsing or downloading the file:', error)
    }
  }

  return (
    <>
      {/* Dialog component for no records message */}
      <Dialog
        aria-describedby="alert-dialog-description"
        aria-labelledby="alert-dialog-title"
        open={isDialogOpen}
        onClose={() => setIsDialogOpen(false)}
      >
        <DialogTitle id="alert-dialog-title">Details</DialogTitle>
        <DialogContent>
          <DialogContentText id="alert-dialog-description">
            {dialogContent}
          </DialogContentText>
        </DialogContent>
        <DialogActions>
          <OPRButton color="primary" onClick={() => setIsDialogOpen(false)}>
            OK
          </OPRButton>
        </DialogActions>
      </Dialog>
      <Box sx={{
        display: 'flex', justifyContent: 'space-between', flexDirection: 'row',
      }}
      >
        <Box sx={{
          display: 'flex', justifyContent: 'flex-start', alignItems: 'center', gap: '25px',
        }}
        >
          <OPRLabel variant="h2">
            {t('publish_report_title')}
          </OPRLabel>
        </Box>
        <Box sx={{
          display: 'flex', justifyContent: 'flex-start', height: 'fit-content',
        }}
        >
          {/* <OPRButton
            color="primary"
            handleClick={handleEditClick}
            style={{ borderRadius: '110px' }}
            variant="outlined"
          >
            Edit pension fund scheme
          </OPRButton> */}
        </Box>
      </Box>
      <Box sx={{ width: '100%' }}>
        <Box sx={{ borderBottom: 1, borderColor: 'divider' }}>
          <StyledTabs aria-label="basic tabs example" value={value} onChange={handleTabChange}>
            <StyledTab label={t('generation_list_title')} {...a11yProps(0)} />
            <StyledTab label={t('pay_cycle_logs')} {...a11yProps(1)} />
          </StyledTabs>
        </Box>
        <CustomTabPanel index={0} value={value}>
          <Box sx={{ display: 'flex', flexDirection: 'column', alignItems: 'flex-end' }}>
            <Box sx={{
              width: '280px',
            }}
            >
              <OPRSearchIcon
                placeholder={`Search By ${t('generation_reference_title')}`}
                value={filterData.SearchText}
                onChange={onSearch}
              />
            </Box>
            <OPRInnerListLayout
              Search={filterData.SearchText}
              // addHandleClick={() => navigate(routes.createCompanyBankAccount)}
              columns={generationRefColumn(viewAcoount)}
              dataList={JSON.parse(JSON.stringify(allPosts?.records || []))}
              deleteCallBack={() => {}}
              error={errorAllPosts}
              filterData={filterData}
              handlePagination={handlePagination}
              handleSearch={onSearch}
              isAdd={false}
              isError={isErrorAllPosts}
              isHeader={false}
              loading={isLoadingAllPosts}
              rowClickHandler={handleView}
              rowNumber={0}
              // selelctedUser={selelctedDelete}
              // setSelelctedUser={setSelelctedDelete}
              sortHandleClick={sorting}
              // success={deleteCostCenterSuccess}
              title={t('Publish reports')}
            />
          </Box>
        </CustomTabPanel>
        <CustomTabPanel index={1} value={value}>
          <Box sx={{ display: 'flex', flexDirection: 'column', alignItems: 'flex-end' }}>
            <Box sx={{
              width: '280px',
            }}
            >
              <OPRSearchIcon placeholder={`Search By ${t('bulk_upload_data_job_id')}`} value={filterData.SearchText} onChange={onSearch} />
            </Box>
            <OPRInnerListLayout
              Search={filterData.SearchText}
              columns={publishReportColumn(handleFileDownload)}
              dataList={(allPostsLogs?.records || [])}
              deleteCallBack={() => {}}
              error={errorAllPosts}
              filterData={filterData}
              // handleFileDownload={handleFileDownload}
              handlePagination={handlePagination}
              handleSearch={onSearch}
              isAdd={false}
              isError={isErrorAllPosts}
              isHeader={false}
              loading={isLoadingAllPosts}
              rowClickHandler={handleRowClick}
              rowNumber={0}
              sortHandleClick={sorting}
            />
          </Box>
        </CustomTabPanel>
      </Box>
    </>
  )
}

export default PublishReportList
