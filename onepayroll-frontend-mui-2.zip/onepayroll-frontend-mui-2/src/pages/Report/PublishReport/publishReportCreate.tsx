import {
  Box, Checkbox, Grid,
} from '@mui/material'
import { useSunshineCreateMutation } from 'api/inegrationServices'
import { useLazyGetPublishReportByIdQuery } from 'api/reportingServices'
import OPRLabel from 'components/atoms/label/OPRLabel'
import OPRStepper from 'components/atoms/stepper'
import OPREnhancedTable from 'components/atoms/table/OPREnhancedTable'
import { reportViewColumn, reportViewEditColumn, selectFileColumn } from 'components/atoms/table/OPRTableConstant'
import { OPRSuccesControl } from 'components/molecules/OPRAlertControl/OPRSuccesControl'
import OPRDatePickerControl from 'components/molecules/OPRDatePickerControl/OPRDatePickerControl'
import OPRInputControl from 'components/molecules/OPRInputControl'
import OPRResponsiveGrid from 'components/molecules/OPRResponsiveGrid'
import OPRTextArea from 'components/molecules/OPRTextArea/OPRTextArea'
import OPRAlertControl from 'components/organism/OPRAlertControl'
import { OPRInnerFormLayout } from 'components/organism/OPRInnerFormLayout'
import { OPRInnerListLayout } from 'components/organism/OPRInnerLayoutList'
import { validationSchemaSunshineIntegration } from 'constants/validate'
import { useEditable } from 'hooks/useEdit'
import useForm from 'hooks/useForm'
import React, { useEffect, useState } from 'react'
import { useTranslation } from 'react-i18next'
import { useLocation, useNavigate } from 'react-router-dom'
import { routes } from 'routes/routes'
import { formatedYearDate } from 'utils'

import EditReportFileModal from './EditReportFileModal'

// import { EditReportFileModal } from '../../EditReportFileModal'

export default function PublishReportCreate() {
  const location: any = useLocation()
  const { state } = useLocation()
  const [activeState, setActiveState] = useState(0)
  const [employeeData, setEmployeeData]:any = useState([])
  const [checkedValue, setCheckedValue]:any = useState([])
  const [selected, setSelected] = useState<readonly number[]>([])
  const { t } = useTranslation()
  const [editModalOpen, setEditModalOpen] = useState(false)
  const [editFileData, setEditFileData] = useState(null)
  const { isEditable, setEditable } = useEditable()
  const [referenceNumber, setReferenceNumber] = useState(location.state?.referenceNumber || '')
  const {
    values,
    setValues,
    errors,
    handleChange,
    setErrors,
    handleFormSubmit,
    handleOnChange,
  } = useForm(validationSchemaSunshineIntegration)

  const navigate = useNavigate()

  const [
    createSunshine,
    {
      data: createdSunshineData,
      error: createdSunshineError,
      isLoading: createdSunshineLoading,
      isSuccess: createdSunshineSuccess,
      isError: createdSunshineIsError,
    },
  ] = useSunshineCreateMutation()

  const handleSubmit: any = async () => {
    const files = checkedValue.map((item: any) => ({
      fileName: item.fileName || '',
      filePath: item.filePath || '',
      releaseDate: item.releaseDate || formatedYearDate(values?.releaseDate || ''),
      remarks: item.remarks || values?.remarks || '',
    }))

    const entity = JSON.parse(localStorage.getItem('Entity') || '{}')
    const userId = checkedValue.length > 0 ? checkedValue[0].id : ''
    const entityId = entity.id || 'defaultEntityId'
    const referenceNumber = (checkedValue.length > 0 && checkedValue[0].batchJob?.generationReference?.referenceNumber) || ''

    const data = {
      userId,
      entityId,
      referenceNumber,
      generationDate: formatedYearDate(values?.releaseDate),
      files,
    }
    await createSunshine(data)
  }
  // [3].batchJob.generationReference.referenceNumber
  // console.log(employeeData?.batchJob?.generationReference?.referenceNumber, 'checkedValuecheckedValue')
  // console.log(checkedValue.batchJob, 'checkedValue')
  const [getPublishReportById, {
    data: allPosts,
    error: isErrorAllPosts,
    isLoading: isLoadingAllPosts,
    isSuccess: isSuccessAllPosts,
    isError: errorAllPosts,
  }] = useLazyGetPublishReportByIdQuery()
  // console.log(employeeData, 'employeeData')
  useEffect(() => {
    if (state?.id) {
      getPublishReportById(`${state?.id}&pageSize=1000`)
      // setEditable(viewUrl)
    }
  }, [getPublishReportById])

  useEffect(() => {
    if (isSuccessAllPosts) {
      setEmployeeData(allPosts?.data?.records || [])
    }
  }, [isSuccessAllPosts])

  const handleSelectAllClick = (event: React.ChangeEvent<HTMLInputElement>) => {
    if ((event.target as HTMLInputElement).checked) {
      setSelected(JSON.parse(JSON.stringify(employeeData || []))?.map((n:any) => n.id))
      setCheckedValue(JSON.parse(JSON.stringify(employeeData || [])))
      return
    }
    setSelected([])
    setCheckedValue([])
  }

  const handleClick = (event: React.MouseEvent<unknown>, item: any) => {
    const selectedIndex = selected.indexOf(item.id)
    let newSelected: readonly number[] = []
    if (selectedIndex === -1) {
      newSelected = newSelected.concat(selected, item.id)
      setCheckedValue([
        ...checkedValue,
        item,
      ])
    } else if (selectedIndex === 0) {
      newSelected = newSelected.concat(selected.slice(1))
      setCheckedValue(checkedValue.filter((val:any) => val.id !== item.id))
    } else if (selectedIndex === selected.length - 1) {
      newSelected = newSelected.concat(selected.slice(0, -1))
      setCheckedValue(checkedValue.filter((val:any) => val.id !== item.id))
    } else if (selectedIndex > 0) {
      newSelected = newSelected.concat(
        selected.slice(0, selectedIndex),
        selected.slice(selectedIndex + 1),
      )
      setCheckedValue(checkedValue.filter((val:any) => val.employeeCode !== item.employeeCode))
    }
    setSelected(newSelected)
  }
  const isSelected = (employeeCode:any) => selected.indexOf(employeeCode) !== -1
  // #edit functionality in the stepper 2
  const viewAcoount = (data: any, type: string) => {
    if (type === 'Edit report file') {
      const formattedReleaseDate = formatedYearDate(values?.releaseDate)

      setEditFileData({
        ...data,
        releaseDate: formattedReleaseDate, // Store formatted releaseDate
        remarks: values.remarks,
      })
      setEditModalOpen(true)
    }
  }
  const handleEditModalClose = () => {
    setEditModalOpen(false)
    setEditFileData(null)
  }

  const additionalData = () => {

  }

  const handleEditSave = (updatedData: any) => {
    // Update the checkedValue with the updatedData
    const updatedFiles = checkedValue.map((file: any) => (file.id === updatedData.id ? { ...file, ...updatedData } : file))
    setCheckedValue(updatedFiles)
  }

  const formattedReleaseDate = formatedYearDate(values?.releaseDate ? new Date(values.releaseDate).toLocaleDateString() : '')
  const formattedCheckedValue = checkedValue.map((item: any) => ({
    ...item,
    releaseDate: item.releaseDate ? new Date(item.releaseDate).toLocaleDateString() : '',
  }))

  return (
    <Box sx={{ display: 'flex' }}>
      <div
        style={{ display: 'flex', width: '100% ' }}
        // onSubmit={(e) => {
        //   activeState === 0 ? handleFormSubmit(e, handleSubmit) : handlePermissionSubmit()
        // }}
      >
        {/* Render the EditReportFileModal */}
        {editModalOpen && (
          <EditReportFileModal
            fileData={editFileData}
            open={editModalOpen}
            onClose={handleEditModalClose}
            onSave={handleEditSave}
          />
        )}
        <OPRAlertControl
          isCustom
          customMessage="Publish report submitted"
          customTitle="Publish report submitted"
          handleEditable={setEditable}
          handleSetValue={setValues}
          handleSubmit={handleSubmit}
          isError={createdSunshineIsError}
          isLoading={createdSunshineLoading}
          isSuccess={createdSunshineSuccess}
          name={t('email')}
          previousUrl={routes.dataUpload}
          title={t('email')}
          type="update"
        />
        <OPRSuccesControl
          isEntity
          customMessage="Publish report submitted successfully"
          customTitle="Publish report submitted submitted"
          // isSuccess={createdSendTestEmailSuccess}
          name={t('email')}
          title={t('email')}
          type="update"
        />
        <OPRInnerFormLayout
          isHandleContinueClick
          isStepper
          // customHeader={(
          //   <OPRLabel label="Publish reports" variant="h2" />
          // )}
          error={createdSunshineError}
          handleBack={() => { setActiveState(activeState - 1) }}
          handleCancelClick={(e:any) => navigate(-1)}
          handleContinueClick={(e:any) => {
            if (activeState === 0) {
              // if (checkedValue.length > 0) {
              setActiveState(activeState + 1)
              // }
            } else if (activeState === 1) {
              if (values?.releaseDate && values?.remarks) {
                setActiveState(activeState + 1)
              }
            } else if (activeState === 2) {
              // Optionally handle transitions or actions for state 2
              // If no additional actions needed, you can just transition to state 3 or perform actions
              setActiveState(activeState + 1)
            } else if (activeState === 3) {
              handleSubmit()
            } else {
              setActiveState(activeState + 1)
              // handleSubmit()
            }
          }}
          handleEditable={setEditable}
          isBackButton={activeState > 0}
          isConfirm={activeState === 3}
          isLoading={createdSunshineLoading}
          pageType="detailsPage"
          // previousPageUrl={routes.publishReport}
          step={activeState}
          subtitle={
            isEditable
              ? 'Please check the user details below.'
              : 'All field to mandatory expect those mark optional'
          }
          title={t('publish_reports_title')}
        >
          <Box>
            <OPRStepper
              activeStep={activeState}
              steps={[
                t('select_files'),
                t('publish_information'),
                t('modify_files'),
                t('pensionfund_scheme_step_confirmation'),
              ]}
            />
            {activeState === 0 && (
              <Box>
                <Box sx={{
                  padding: '24px',
                  display: 'flex',
                  flexDirection: 'row',
                  gap: '6px',
                  //   border: '1px solid #D4D2D3',
                  borderRadius: '10px',
                  marginTop: '24px',
                  marginBottom: '24px',
                }}
                >
                  <OPRLabel variant="body2">{t('start_selecting_file_note')}</OPRLabel>
                </Box>
                <OPRResponsiveGrid>
                  <Box sx={{
                    display: 'flex',
                    flexDirection: 'row',
                    alignItems: 'center',
                  }}
                  >
                    <Checkbox
                      checked={selected.length === employeeData?.length}
                      indeterminate={selected.length > 0 && selected.length < employeeData?.length}
                      onChange={handleSelectAllClick}
                    />
                    <OPRLabel variant="body2">Select All</OPRLabel>
                  </Box>
                  <OPREnhancedTable
                    isMovement
                    cols={selectFileColumn(handleClick)}
                    data={JSON.parse(JSON.stringify(employeeData || []))}
                    handleClick={handleClick}
                    isSelected={isSelected}
                    steps={1}
                  />
                </OPRResponsiveGrid>
              </Box>
            )}
            {activeState === 1 && (
              <>
                <Box>
                  <Box sx={{
                    padding: '24px',
                    display: 'flex',
                    flexDirection: 'row',
                    gap: '6px',
                    // border: '1px solid #D4D2D3',
                    // borderRadius: '10px',
                    marginTop: '24px',
                    marginBottom: '24px',
                  }}
                  >
                    <OPRLabel variant="body2">{t('modal_mandatory_note')}</OPRLabel>
                  </Box>
                </Box>
                <OPRResponsiveGrid>
                  <Grid item md={2} sm={1} xs={1}>
                    <OPRDatePickerControl
                      isRequired
                      error={errors?.releaseDate}
                      label="release_date"
                      name="releaseDate"
                      // value={values?.effectiveStartDate ? values?.effectiveStartDate?.toISOString() : null}
                      value={values?.releaseDate ? new Date(values.releaseDate).toLocaleDateString() : ''}
                      onChange={(date) => {
                        handleOnChange('releaseDate', date)
                      }}
                    />
                  </Grid>
                  <Grid item md={2} sm={1} xs={1}>
                    <OPRInputControl
                      error={errors?.userFolderName}
                      isEditable={isEditable}
                      label={t('User Folder Name')}
                      name="userFolderName"
                      optionalText="optional"
                      value={values?.userFolderName}
                      onChange={handleChange}
                    />
                  </Grid>
                  <Grid item md={4} sm={6} xs={12}>
                    <OPRTextArea
                      error={t(errors?.remarks)}
                      isEditable={isEditable}
                      label="Publish remarks"
                      name="remarks"
                      value={values?.remarks}
                      onChange={handleChange}
                    />
                  </Grid>
                </OPRResponsiveGrid>
              </>
            )}
            {activeState === 2 && (
              <Box>
                <OPRLabel sx={{ marginTop: '20px' }} variant="body2">
                  {`  ${t('all_fields_are_mandatory_except_marked_optional')}`}
                </OPRLabel>
                <div style={{ display: 'block', width: '100%', margin: '30px 20px 20px' }}>
                  <OPRLabel variant="h2">Report files</OPRLabel>
                </div>
                <OPRInnerListLayout
                  columns={reportViewEditColumn(viewAcoount, {
                    releaseDate: formattedReleaseDate,
                    remarks: values.remarks || '',
                  })}
                  dataList={formattedCheckedValue}
                  deleteCallBack={() => {}}
                  // error={errorAllPosts}
                  filterData={{ totalItmes: '' }}
                  // handlePagination={handlePagination}
                  // handleSearch={onSearch}
                  // isAdd={false}
                  isError={isErrorAllPosts}
                  isHeader={false}
                  loading={isLoadingAllPosts}
                  // rowClickHandler={handleView}
                  rowNumber={0}
                />
                {/* <OPRLabel sx={{ marginTop: '20px' }} variant="body2">
                  {`  ${t('all_fields_are_mandatory_except_marked_optional')}`}
                </OPRLabel>
                <div style={{ display: 'block', width: '100%', margin: '30px 20px 20px' }}>
                  <OPRLabel variant="h2">Report files</OPRLabel>
                </div>
                <OPREnhancedTable
                  isMovement
                  cols={reportViewColumn(handleClick)}
                  data={(checkedValue || [])}
                  handleClick={handleClick}
                  isSelected={isSelected}
                /> */}
              </Box>
            )}
            {activeState === 3 && (
              <Box>
                <OPRLabel style={{ margin: '30px 20px 20px' }} variant="body2">{t('please_check_details_below')}</OPRLabel>
                <div style={{ display: 'block', width: '100%', margin: '30px 20px 20px' }}>
                  <OPRLabel variant="h2">{t('publish_information')}</OPRLabel>
                </div>
                <OPRResponsiveGrid>
                  <Grid item md={2} sm={1} xs={1}>
                    <OPRDatePickerControl
                      isEditable
                      isRequired
                      error={errors?.releaseDate}
                      label="release_date"
                      name="releaseDate"
                      // value={values?.effectiveStartDate ? values?.effectiveStartDate?.toISOString() : null}
                      value={values?.releaseDate || null}
                      onChange={(date) => {
                        handleOnChange('releaseDate', date)
                      }}
                    />
                  </Grid>
                  <Grid item md={2} sm={1} xs={1}>
                    <OPRInputControl
                      isEditable
                      error={errors?.userFolderName}
                      label={t('User Folder Name')}
                      name="userFolderName"
                      optionalText="optional"
                      value={values?.userFolderName}
                      onChange={handleChange}
                    />
                  </Grid>
                  <Grid item md={2} sm={6} xs={12}>
                    <OPRTextArea
                      isEditable
                      error={t(errors?.remarks)}
                      label="Publish remarks"
                      name="remarks"
                      value={values?.remarks}
                      onChange={handleChange}
                    />
                  </Grid>
                </OPRResponsiveGrid>
                <div style={{ display: 'block', width: '100%', margin: '30px 20px 20px' }}>
                  <OPRLabel variant="h2">Report files</OPRLabel>
                </div>
                <OPREnhancedTable
                  isMovement
                  cols={reportViewColumn(handleClick)}
                  data={(checkedValue || []).map((item:any) => ({
                    ...item,
                    releaseDate: values.releaseDate,
                    remarks: item.remarks || '', // Ensure remarks are passed
                  }))}
                  handleClick={handleClick}
                  isSelected={isSelected}
                />
              </Box>
            )}
          </Box>
        </OPRInnerFormLayout>
      </div>
    </Box>
  )
}
