import {
  Box,
} from '@mui/material'
import { useGetAllAuditTrailReportQuery } from 'api/reports'
import {
  auditTrailCoulumn,
} from 'components/atoms/table/OPRTableConstant'
import { OPRInnerListLayout } from 'components/organism/OPRInnerLayoutList'
import { reportCodeType } from 'constants/index'
import { t } from 'i18next'
import React, { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { routes } from 'routes/routes'
import {
  generateFilterUrl,
} from 'utils'

function UploadDataList() {
  const navigate: any = useNavigate()
  const [selelctedDelete, setSelelctedDelete]:any = useState({
    data: {},
    isDelete: false,
    name: '',
  })
  const [filterData, setFilterData]:any = useState({
    pageNumber: 1,
    pageSize: 20,
    totalItems: 0,
    orderByAsc: false,
    sortBy: '',
    SearchText: '',
    reportTypeCode: reportCodeType.AUTRA,
  })
  const {
    data: allPosts,
    isLoading: isLoadingAllPosts,
    isSuccess: isSuccessAllPosts,
    isError: isErrorAllPosts,
    error: errorAllPosts,
    refetch: refetchAllPosts,
  } = useGetAllAuditTrailReportQuery(generateFilterUrl(filterData), {
    pollingInterval: 5000,
  })

  const sorting = (
    event: React.MouseEvent<unknown>,
    property: keyof any,
  ) => {
    const isAsc = filterData.sortBy === property && filterData.orderByAsc === true
    setFilterData({ ...filterData, orderByAsc: !isAsc, sortBy: property })
  }

  useEffect(() => {
    setFilterData({ ...filterData, totalItems: allPosts?.totalItems ? allPosts?.totalItems : 0 })
  }, [allPosts?.pageNumber, filterData.sortBy, filterData.orderByAsc, allPosts?.totalItems])

  const onSearch = (e: any, data: any) => {
    setFilterData({ ...filterData, ...data })
  }
  const handlePagination = (pageNumber: number, pageSize: number) => {
    setFilterData({ ...filterData, pageNumber })
  }

  const viewAcoount = (data: any, type:string) => {
    // if (type === 'edit cost center') {
    //   navigate(
    //     setRouteValues(`${routes.editCostCenter}`, {
    //       id: data.id,
    //     }),
    //   )
    // } else if (type === 'delete cost center') {
    //   // deleteCostCenterById(`Id=${data.id}`)
    //   setSelelctedDelete({ data, isDelete: true, name: data.costCenterCode })
    // } else {
    //   navigate(
    //     setRouteValues(`${routes.viewCostCenter}`, {
    //       id: data.id,
    //     }),
    //   )
    // }
  }
  const handleView = (data: any) => {
    // navigate(
    //   setRouteValues(`${routes.viewCompanyBankAccount}`, {
    //     id: data.id,
    //     view: true,
    //   }),
    // )
  }
  // handle Delete
  //   const handleDelete = (data:any) => {
  //     deleteCostCenterById(`Id=${data.id}`)
  //   }
  return (
    <Box sx={{ display: 'flex' }}>
      <OPRInnerListLayout
        addHandleClick={() => navigate(routes.createAuditTrail)}
        columns={auditTrailCoulumn(viewAcoount)}
        customAdd="Generate report"
        dataList={JSON.parse(JSON.stringify(allPosts?.records || []))}
        deleteCallBack={() => {}}
        error={errorAllPosts}
        filterData={filterData}
        handlePagination={handlePagination}
        handleSearch={onSearch}
        isError={isErrorAllPosts}
        isSearch={false}
        loading={isLoadingAllPosts}
        rowClickHandler={handleView}
        rowNumber={0}
        sortHandleClick={sorting}
        title={t('Audit trails report')}
      />
    </Box>
  )
}

export default UploadDataList
