import '../../../styles/style.css'

import { Box, Grid, Typography } from '@mui/material'
import { useGetAllUserAdministrationQuery } from 'api/identityServices'
import { useGetAllAuditReportQuery } from 'api/reportingServices'
import { EmpIcon, MenuKebab } from 'assets/svg-images/SvgComponents'
import OPRButton from 'components/atoms/button/OPRButton'
import OPRLabel from 'components/atoms/label/OPRLabel'
import { CustomDialog } from 'components/atoms/modal/OPRModal'
import OPRMultiSelect from 'components/atoms/multiSelectCheckbox/OPRMultiSelectCheckbox'
import OPRDatePickerControl from 'components/molecules/OPRDatePickerControl/OPRDatePickerControl'
import OPRResponsiveGrid from 'components/molecules/OPRResponsiveGrid'
import { t } from 'i18next'
import React, { useEffect, useState } from 'react'
import { generateFilterUrl } from 'utils'

import { DbTableModal, DbTableModal2 } from './DbTableModal'
import CustomCheckbox from './EmployeeCheckbox'

export function AuditTrailInformation({
  errors, isEditable, values, handleChange, handleOnChange, handleClose, setValues, isOpen,
  isFinalComponent, isFinalDBComponent, selectedCodes, selectedDBCode, handleRemoveDBTable, handleRemoveEmployee,
  handleCheckboxChange, handleSelectAllDBChange, handleCheckboxDBChange, handleSelectAllChange, handleCheckboxDBColumnChange, selectAll, selectDBAll, employees, DBTable, handleChildSubmit,
}: any) {
  const [selected, setSelected] = React.useState<readonly number[]>([])
  const [checkedValue, setCheckedValue] = React.useState<any[]>([])
  const [userEntityData, setUserEntityData] = useState({
    SearchText: '',
  })
  const [isSkip, setIsSkip] = useState(true)
  const [selectedDbSelected, setSelectedDbSelected] = useState<string[]>([])
  const [selectedColumn, setSelectedColumn] = useState<string[]>([])
  const [isRemove, setIsRemove] = useState(false)
  const [selectedEmployeeCodes, setSelectedEmployeeCodes] = useState<string[]>([])
  const [isOpenSecondModal, setIsOpenSecondModal] = useState(false)
  // const [multiValues, setMultiValues]:any = useState([])
  // const [multiSelectValues, setMultiSelectValues]:any = useState<string[]>([])
  const [userOptions, setUserOptions]: any = useState([])
  const [filterData, setFilterData]: any = useState({
    pageNumber: 1,
    pageSize: 20,
    totalItems: 0,
    orderByAsc: true,
    sortBy: '',
    SearchText: '',
  })

  // Audti Report useGetAllAuditReportQuery
  const {
    data: allAuditReport,
  } = useGetAllAuditReportQuery('')

  const {
    data: allPostsUserAdministrator,
    isLoading: isLoadingAllPosts,
    isSuccess: isSuccessAllPosts,
    isError: isErrorAllPosts,
    error: errorAllPosts,
    refetch: refetchAllPosts,
  } = useGetAllUserAdministrationQuery(generateFilterUrl(filterData))

  const [isEmployeeModalOpen, setIsEmployeeModalOpen] = useState(false)
  const [isDBModalOpen, setIsDBModalOpen] = useState(false)
  const [steps, setSteps] = useState(0)
  const [isEditables, setIsEditables] = useState(false)

  // Function to handle opening the employee modal
  const handleEmployeeModalOpen = () => {
    setIsEmployeeModalOpen(true)
  }
  // Effect to update the user options when data is fetched
  useEffect(() => {
    if (isSuccessAllPosts) {
      // Transform the user data into the format required by OPRMultiSelect
      const transformedUserOptions = allPostsUserAdministrator?.data?.map((user: any) => ({
        name: `${user.username} - ${user.firstName} ${user.lastName}`,
        value: user.id,
      }))
      setUserOptions(transformedUserOptions)
    }
  }, [isSuccessAllPosts, allPostsUserAdministrator])

  const handleDBTbaleModalOepn = () => {
    setIsDBModalOpen(true)
  }

  // Function to handle closing the employee modal
  const handleEmployeeModalClose = () => {
    setIsEmployeeModalOpen(false)
  }

  // emplloyyee code display name
  const selectedDBTable = selectedDBCode?.map((code: any) => {
    const table = DBTable?.find((emp: any) => emp?.tableName === code)
    if (table) {
      return (

        <Box
          key={code}
          style={{
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between',
            margin: '5px 20px',
          }}
        >
          <div>{table?.tableName}</div>
          {/* Mapping over columns array */}
          {/* need to be changed here */}
          {/* <div>{table.columns[0]?.columnName}</div> */}
          {/* {table.columns.map((column: any, index: number) => (
            <div key={code}>{column?.columnName}</div>
          ))} */}
          <div>
            <OPRButton
              variant="text"
              onClick={() => handleRemoveDBTable(code)}
            >
              <MenuKebab />
            </OPRButton>
          </div>

        </Box>

      )
    }

    return null
  })

  const handleDbSelection = (selectedColumnCode: string[]) => {
    setSelectedColumn(selectedColumnCode)
  }

  // handle Coulm
  const handleColumnSelection = (selectedDBCode: string[]) => {
    setSelectedDbSelected(selectedDBCode)
  }

  // handleDBModalClose
  const handleDBModalClose = () => {
    setIsDBModalOpen(false)
  }

  const handleUserClick = (item: any) => {
    // setDuplicateItem(item)
    setUserEntityData({ ...filterData, SearchText: item?.firstName })
    setIsSkip(false)
    setSteps((prev) => prev + 1)
  }

  const isSelected = (id: any) => selected.indexOf(id) !== -1

  const handleEmployeeSelection = (selectedCodes: string[]) => {
    setSelectedEmployeeCodes(selectedCodes)
  }

  const handleContinue = () => {
    // Handle continue button click, e.g., save data or perform any action
    handleEmployeeModalClose()
  }

  const handleDBContinued = () => {
    setIsOpenSecondModal(true)
    // Handle continue button click, e.g., save data or perform any action
    handleDBModalClose()
  }

  const handleConfirm = async () => {
    setIsOpenSecondModal(false)
  }
  const selectedEmployees = selectedCodes?.map((code: any) => {
    const employee = employees.find((emp: any) => emp.employeeCode === code)
    if (employee) {
      return (
        <Box
          key={code}
          style={{
            display: 'flex', alignItems: 'center', justifyContent: 'space-between', margin: '5px 20px',
          }}
        >
          <Box>
            <OPRLabel
              label={`${employee.employeeProfile.givenName} 
            ${employee.employeeProfile.surname}`}
              variant="subtitle2"
            />

            <OPRLabel label={employee.employeeCode} variant="body2" />
          </Box>

          <Box>
            <OPRButton variant="text" onClick={() => handleRemoveEmployee(code)}><MenuKebab /></OPRButton>
          </Box>
        </Box>
      )
    }

    return null
  })
  // console.log(isFinalDBComponent, 'isFinalDBComponent')
  // console.log(isFinalComponent, 'isFinalComponent')
  // console.log(selectedDbSelected, 'selectedDbSelected')
  // console.log(selectedEmployeeCodes, 'selectedEmployeeCodes')
  // console.log(selectedEmployees, 'selectedEmployeesselectedEmployees')
  return (
    <Box>
      {isFinalComponent ? (
        <div style={{ display: 'block', width: '100%', margin: '40px 0px 20px' }}>
          <OPRLabel variant="h3">Filtering criteria</OPRLabel>
        </div>
      ) : (
        <OPRLabel sx={{ marginTop: '20px', marginBottom: '40px' }} variant="body2">
          {`  ${t('Select specific group of employees to run payroll processing. All fields are mandatory except those marked optional.')}`}
        </OPRLabel>
      )}
      <OPRResponsiveGrid>

        {/* <Grid item md={2} sm={1} xs={1}> */}

        <Grid item md={2} sm={1} xs={1}>
          <OPRMultiSelect
            error={errors?.ActionTypes}
            label="Change action"
            name="ActionTypes"
            options={[
              { name: 'Insert', value: '2' },
              { name: 'Update', value: '4' },
              { name: 'Delete', value: '1' },
            ]}
            placeholder="Select an option"
            value={values?.ActionTypes || []} // Ensure value is initialized as an array
            onChange={(selectedFormat) => {
              setValues({ ...values, ActionTypes: selectedFormat })
            }}
          />
        </Grid>
        <Grid item md={2} sm={1} xs={1}>
          <OPRMultiSelect
            error={errors?.UpdatedByUsers}
            label="Change by"
            name="UpdatedByUsers"
            optionalText="Optional"
            options={userOptions}
            placeholder="Select an option"
            value={values?.UpdatedByUsers}
            onChange={(selectedFormat) => {
              setValues({ ...values, UpdatedByUsers: selectedFormat })
            }}
          />

        </Grid>
        <Grid item md={2} sm={1} xs={1}>
          {/* Action start date */}
          <OPRDatePickerControl
            error={t(errors?.DateFrom)}
            isEditable={isEditable}
            label="Action start date"
            name="DateFrom"
            value={values?.DateFrom || null}
            onChange={(date:any) => {
              handleOnChange('DateFrom', new Date(date))
            }}
          />
        </Grid>
        {/* Action end date */}
        <Grid item md={2} sm={1} xs={1}>
          <OPRDatePickerControl
            error={t(errors?.DateTo)}
            isEditable={isEditable}
            label="Action end date"
            name="DateTo"
            value={values?.DateTo}
            onChange={(date:any) => {
              handleOnChange('DateTo', new Date(date))
            }}
          />
        </Grid>

        {/* DB table & columnn */}
        <div style={{ display: 'block', width: '100%', margin: '40px 20px 20px' }}>
          {isFinalDBComponent ? (
            <OPRLabel variant="h3">Employee</OPRLabel>

          ) : (
            <>
              <OPRLabel variant="h3">
                DB table & column
              </OPRLabel>
              <OPRLabel variant="body2">Ensure that a DB table name is chosen.</OPRLabel>
            </>
          )}
          <Box
            sx={{
              width: '100%',
              display: 'inline-flex',
              justifyContent: 'flex-start',
              alignItems: 'flex-start',
            }}
          >
            <Box
              sx={{
                flex: '1 1 0',
                paddingY: 1,
                display: 'flex',
                justifyContent: 'flex-start',
                alignItems: 'center',
              }}
            >
              <Box
                sx={{
                  padding: 1,
                  display: 'flex',
                  justifyContent: 'flex-start',
                  alignItems: 'center',
                  gap: 1,
                }}
              >
                <Typography
                  sx={{
                    color: '#3B3839',
                    fontSize: 12,
                    fontFamily: 'Lato',
                    fontWeight: '700',
                    wordWrap: 'break-word',
                  }}
                >
                  DB table name
                </Typography>
              </Box>
            </Box>
            <Box
              sx={{
                flex: '1 1 0',
                height: 48,
                paddingY: 1,
                display: 'flex',
                justifyContent: 'flex-start',
                alignItems: 'center',
              }}
            >
              <Box
                sx={{
                  padding: 1,
                  display: 'flex',
                  justifyContent: 'flex-start',
                  alignItems: 'center',
                  gap: 1,
                }}
              >
                <Typography
                  sx={{
                    color: '#3B3839',
                    fontSize: 12,
                    fontFamily: 'Lato',
                    fontWeight: '700',
                    // lineHeight: '16px',
                    wordWrap: 'break-word',
                  }}
                >
                  DB column name
                </Typography>
              </Box>
            </Box>
          </Box>
          {/* Check if selectedEmployees array has any selected employees */}
          {selectedDBTable?.length > 0 ? (
            // Render only if there are selected employees
            selectedDBTable
          ) : (
            // Render the buttons if no employees are selected
            <Box sx={{
              display: 'block',
              justifyContent: 'space-between',
              marginTop: '80px',
            }}
            >
              <Box
                className="pop-up"
                sx={{
                  display: 'flex',
                  gap: '12px',
                  alignItems: 'center',
                  borderRadius: '4px',
                  alignSelf: 'stretch',
                  justifyContent: 'center',
                  marginTop: 1,
                }}
              >
                <EmpIcon />
                <OPRLabel variant="body2">

                  No DB table & column is selected

                </OPRLabel>
              </Box>

              {!isFinalDBComponent && ( // Render the button only if it's not the third component
                <OPRButton
                  disabled={isFinalDBComponent && (selectedDbSelected.length === 0 || selectedDBCode.length > 0)}
                  sx={{ margin: '0px auto', display: 'flex' }}
                  variant="text"
                  onClick={handleDBTbaleModalOepn}
                >
                  Select DB table & column
                </OPRButton>
              )}

              <Box sx={{ display: 'flex', justifyContent: 'space-between', marginTop: '50px' }} />
            </Box>
          )}
        </div>
        {/* DB table modal */}
        <CustomDialog
          isResume
          closeTitle="Cancel"
          handleClose={handleDBModalClose}
          handleResume={handleDBContinued} // Pass handleContinue here
          isOpen={isDBModalOpen}
          resumeTitle="Continue"
          title="Select DB table name"
          onSelection={handleDbSelection}
        >
          <Box sx={{}}>
            <Box>
              <div>
                {/* Display selected employee codes */}
                {selectedDbSelected.length > 0 && (
                  <div>
                    <p>
                      Selected Employee Codes:
                      {selectedDbSelected.join(', ')}

                    </p>
                  </div>
                )}
                {/* Pass handleEmployeeSelection as a prop to CustomCheckbox */}
                <DbTableModal
                  dataTable={DBTable}
                  handleCheckboxDBChange={handleCheckboxDBChange}
                  handleRemoveDBTable={handleRemoveDBTable}
                  handleSelectAllDBChange={handleSelectAllDBChange}
                  selectDBAll={selectDBAll}
                  selectedDBTable={selectedDBTable}
                  onChange={handleDbSelection}
                />
              </div>
            </Box>
          </Box>
        </CustomDialog>

        <CustomDialog
          isResume
          closeTitle="Cancel"
          handleClose={() => setIsOpenSecondModal(false)} // Ensure handleClose is correctly mapped
          // handleClose={handleDBModalClose}
          handleResume={handleConfirm} // Pass handleContinue here
          isOpen={isOpenSecondModal}
          resumeTitle="Continue"
          title="Select DB column"
        // onSelection={handleDbSelection}
        >
          <Box sx={{}}>
            <Box>
              <div>

                <DbTableModal2
                  dataTable={DBTable}
                  handleCheckboxDBColumnChange={handleCheckboxDBColumnChange}
                  handleRemoveDBTable={handleRemoveDBTable}
                  handleSelectAllDBChange={handleSelectAllDBChange}
                  selectDBAll={selectDBAll}
                  selectedDBTable={selectedDbSelected}
                  onChange={handleColumnSelection}
                />
              </div>
            </Box>
          </Box>
        </CustomDialog>

        {/* Emplloyee */}
        <div style={{ display: 'block', width: '100%', margin: '40px 20px 20px' }}>
          {isFinalComponent ? (
            <OPRLabel variant="h3">Employee</OPRLabel>

          ) : (
            <>
              <OPRLabel variant="h3">Employee</OPRLabel>
              <OPRLabel variant="body2">If no employee is selected, the system will process payroll for all employees for the selected pay cycles.</OPRLabel>
            </>
          )}
          <div style={{
            width: '100%',
            paddingTop: 8,
            paddingBottom: 8,
            justifyContent: 'flex-start',
            alignItems: 'center',
            display: 'inline-flex',
          }}
          >
            <div style={{
              padding: 8,
              justifyContent: 'flex-start',
              alignItems: 'center',
              gap: 8,
              display: 'flex',
            }}
            >
              <div style={{
                color: '#3B3839',
                fontSize: 12,
                fontFamily: 'Lato',
                fontWeight: '700',
                wordWrap: 'break-word',
              }}
              >
                Employee name | Employee code
              </div>
            </div>
          </div>
          {/* Check if selectedEmployees array has any selected employees */}
          {selectedEmployees.length > 0 ? (
            // Render only if there are selected employees
            selectedEmployees
          ) : (
            // Render the buttons if no employees are selected
            <Box sx={{ display: 'block', justifyContent: 'space-between', marginTop: '80px' }}>
              <Box
                className="pop-up"
                sx={{
                  display: 'flex',

                  gap: '12px',
                  alignItems: 'center',
                  borderRadius: '4px',
                  alignSelf: 'stretch',
                  justifyContent: 'center',
                  marginTop: 1,
                }}
              >
                <EmpIcon />
                <OPRLabel variant="body2">

                  No employee is selected

                </OPRLabel>
              </Box>

              {!isFinalComponent && ( // Render the button only if it's not the third component
                <OPRButton
                  disabled={isFinalComponent && (selectedEmployeeCodes.length === 0 || selectedCodes.length > 0)}
                  sx={{ margin: '0px auto', display: 'flex' }}
                  variant="text"
                  onClick={handleEmployeeModalOpen}
                >
                  Select Employee
                </OPRButton>
              )}

              <Box sx={{ display: 'flex', justifyContent: 'space-between', marginTop: '50px' }}>
                {/* <OPRButton
                  sx={{ marginLeft: '10px' }}
                  variant="outlined"
                  onClick={handleEmployeeModalClose} // Close the modal if cancel is clicked
                >
                  Cancel
                </OPRButton> */}
                {/* Conditional rendering based on whether skip button should be shown */}
                {/* {selectedCodes.length === 0 ? (
                // Render the skip button if no employees are selected
                  <OPRButton
                    variant="outlined"
                    onClick={handleContinue} // If skip is clicked, handle it as continue
                  >
                    Skip
                  </OPRButton>
                ) : null} */}
              </Box>
            </Box>
          )}
        </div>

        <CustomDialog
          isResume
          closeTitle="Cancel"
          handleClose={handleEmployeeModalClose}
          handleResume={handleContinue} // Pass handleContinue here
          isOpen={isEmployeeModalOpen}
          resumeTitle="Continue"
          title="Employee Selection"
          onSelection={handleEmployeeSelection}
        >
          <Box sx={{}}>
            <Box>
              <div>
                {/* Display selected employee codes */}
                {selectedEmployeeCodes.length > 0 && (
                  <div>
                    <p>
                      Selected Employee Codes:
                      {selectedEmployeeCodes.join(', ')}

                    </p>
                  </div>
                )}
                {/* Pass handleEmployeeSelection as a prop to CustomCheckbox */}
                <CustomCheckbox
                  employees={employees}
                  handleCheckboxChange={handleCheckboxChange}
                  handleRemoveEmployee={handleRemoveEmployee}
                  handleSelectAllChange={handleSelectAllChange}
                  selectAll={selectAll}
                  selectedCodes={selectedCodes}
                  onChange={handleEmployeeSelection}
                />
              </div>
            </Box>
          </Box>
        </CustomDialog>

      </OPRResponsiveGrid>
    </Box>
  )
}
