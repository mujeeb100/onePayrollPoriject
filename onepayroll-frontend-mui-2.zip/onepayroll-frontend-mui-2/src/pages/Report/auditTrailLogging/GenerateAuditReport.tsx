import { Box, Grid } from '@mui/material'
import { useGetAllEmployeeProfileQuery } from 'api/employeeServices'
import { useLazyGetUploadDataByIdQuery, useUploadDataCreateMutation } from 'api/inegrationServices'
import { useGetAllAuditReportQuery } from 'api/reportingServices'
import { useAuditTrailReportCreateMutation } from 'api/reports'
import OPRStepper from 'components/atoms/stepper'
import OPRResponsiveGrid from 'components/molecules/OPRResponsiveGrid'
import OPRSelectorControl from 'components/molecules/OPRSelectorControl/OPRSelectorControl'
import OPRAlertControl from 'components/organism/OPRAlertControl'
import { OPRInnerFormLayout } from 'components/organism/OPRInnerFormLayout'
import { validationSchemeAuditTrail } from 'constants/validate'
import { useEditable } from 'hooks/useEdit'
import useForm from 'hooks/useForm'
import { useEffect, useRef, useState } from 'react'
import { FileWithPath } from 'react-dropzone'
import { useTranslation } from 'react-i18next'
import { useLocation, useNavigate } from 'react-router-dom'
import { generateFilterUrl, getSelectedEntity } from 'utils'

import { AuditTrailInformation } from './AuditTrailInfo'

const defaultValues = {
  exportFormetName: 'PDF',

}

export default function GenerateAuditReport({
  id,
}:any) {
  const [isEmployeeModalOpen, setIsEmployeeModalOpen] = useState(false)

  const [selectedEmployeeCodes, setSelectedEmployeeCodes] = useState<string[]>([])
  const [Entity, setEntityFile]: any = useState<File | FileWithPath[] | any>(
    [],
  )
  const [Payroll, setPayrollFile]: any = useState<File | FileWithPath[] | any>(
    [],
  )
  const [selectedCodes, setSelectedCodes] = useState<string[]>([])

  const [employees, setEmployees]:any = useState([])
  const [DBTable, setDBTable]:any = useState([])
  const [Employee, setEmployeeFile]: any = useState<
        File | FileWithPath[] | any
      >([])
  const [fileList, setFileList]: any = useState([Entity?.path,
    Employee?.path, Payroll?.path])
  const myRef:any = useRef()

  const [selectAll, setSelectAll]:any = useState(false)
  const [selectDBAll, setSelectDBAll]:any = useState(false)
  const [selectedDBCode, setSelectedDBCode] = useState<string[]>([])
  const [selectedDbSelected, setSelectedDbSelected] = useState<string[]>([])
  const location: any = useLocation()
  // const { id, viewUrl } = getParamsValue(location, routes.createUserRole)
  const [activeState, setActiveState] = useState(0)
  const { t } = useTranslation()
  const { isEditable, setEditable } = useEditable()
  const [filterData, setFilterData]:any = useState({
    pageNumber: 1,
    pageSize: 1000,
    totalItems: 0,
    // orderByAsc: true,
    // sortBy: '',
    columnSearchText: '',
    tableSearchText: '',
  })
  const {
    values,
    setValues,
    errors,
    handleChange,
    setErrors,
    handleFormSubmit,
    handleOnChange,
  } = useForm(validationSchemeAuditTrail)

  const navigate = useNavigate()
  const [
    createuploadData,
    {
      data: createdUserRoleData,
      error: createdUserRoleError,
      isLoading: createdUserRoleLoading,
      isSuccess: createdUserRoleSuccess,
      isError: createdUserRoleIsError,
    },
  ] = useUploadDataCreateMutation()
  const [
    getTemplate,
    {
      data: updatedUserRoleByIdResponse,
      error: updatedUserRoleByIdError,
      isLoading: updatedUserRoleByIdLoading,
      isSuccess: updatedUserRoleByIdSuccess,
      isError: updatedUserRoleByIdIsError,
    },
  ] = useLazyGetUploadDataByIdQuery()

  const {
    data: employeeDataList,
    isLoading: isLoadingEmployeeDataList,
    isSuccess: isSuccessEmployeeDataList,
    isError: isErrorEmployeeDataList,
    error: errorEmployeeDataList,
    refetch: refetchEmployeeDataList,
  } = useGetAllEmployeeProfileQuery(generateFilterUrl({
    EffectiveDate: '10/10/2040',
    pageSize: 1000,
  }))

  // useGetAllAuditReportQuery
  const {
    data: auditReportDataList,
    isLoading: isLoadingAuditReportDataList,
    isSuccess: isSuccessAuditReportDataList,
    isError: isErrorAuditReportDataList,
    error: errorAuditReportDataList,
    refetch: refetchAuditReportDataList,
  } = useGetAllAuditReportQuery(generateFilterUrl(filterData))
  // create useAuditTrailReportCreateMutation
  const [
    createAuditTrailReport,
    {
      data: createdAuditTrailReportData,
      error: createdAuditTrailReportError,
      isLoading: createdAuditTrailReportLoading,
      isSuccess: createdAuditTrailReportSuccess,
      isError: createdAuditTrailReportIsError,
    },
  ] = useAuditTrailReportCreateMutation()

  useEffect(() => {
    if (id === null) {
      setValues(defaultValues)
    }
  }, [])

  // useEffect(() => {
  //   console.log('auditReportDataList', auditReportDataList)
  // }, [auditReportDataList])

  // Use getSelectedEntity function to retrieve selected entity
  const selectedEntity = getSelectedEntity()

  useEffect(() => {
    if (isSuccessAuditReportDataList) {
      setDBTable(JSON.parse(JSON.stringify(auditReportDataList?.records || [])))
    }
  }, [isSuccessAuditReportDataList])
  // console.log(DBTable, 'DBTable')

  useEffect(() => {
    setFileList([Entity?.path, Employee?.path, Payroll?.path])
  }, [Entity, Employee, Payroll])

  useEffect(() => {
    if (isSuccessEmployeeDataList) {
      setEmployees(JSON.parse(JSON.stringify(employeeDataList?.records || [])))
    }
  }, [isSuccessEmployeeDataList])

  const onSearch = (e: any, data: any) => {
    setFilterData({ ...filterData, ...data })
  }
  // Db table useEffect
  // useEffect(() => {
  //   if (isSuccessEmployeeDataList) {
  //     setDBTable(JSON.parse(JSON.stringify(employeeDataList?.records || [])))
  //   }
  // }, [isSuccessEmployeeDataList])
  const handleSubmit: any = async () => {
    const entityId = selectedEntity ? selectedEntity.id : ''
    const data = {
      reportRequirements: [
        {
          entityId,
          reportType: 'Audit Trail',
          reportDesignId: null,
          exportOptionsDto: {
            exportFileFormat: values?.exportOptionsDto?.exportFileFormat ?? 0, // Default to 0 (PDF) if not set
          },
          auditTrail: {
            ActionTypes: values?.ActionTypes || [],
            UpdatedByUsers: values?.UpdatedByUsers || [],
            Tables: selectedDBCode || [],
            Columns: selectedDbSelected || [],
            EmployeeCodes: selectedCodes || [],
            DateFrom: values?.DateFrom,
            DateTo: values?.DateTo,
          },
        },
      ],
    }
    await createAuditTrailReport(data)
  }
  // useEffect(() => {
  //   if (createdUserRoleSuccess) {
  //     // Reset form values after successful add operation
  //     setValues({})
  //     setErrors({})
  //   }
  // }, [createdUserRoleSuccess])

  const handlePermissionSubmit: any = async () => {
    if (activeState === 1) {
      setActiveState(activeState + 1)
    } else {
      myRef.current.childMethod()
    }
    // myRef.current.childMethod()
  }

  useEffect(() => {
    const createdUserRoleSuccessStatus = createdUserRoleSuccess || false
    if (createdUserRoleSuccessStatus) {
      if (activeState <= 1) {
        setActiveState(activeState + 1)
      }
    }
  }, [createdUserRoleSuccess])

  // Function to handle opening the employee modal
  const handleEmployeeModalOpen = () => {
    setIsEmployeeModalOpen(true)
  }

  const handleEmployeeModalClose = () => {
    setIsEmployeeModalOpen(false)
  }

  const handleTemplate = async () => {
    await getTemplate
  }
  const handleEmployeeSelection = (selectedCodes: string[]) => {
    setSelectedEmployeeCodes(selectedCodes)
  }
  const handleRemoveEmployee = (codeToRemove: string) => {
    // Filter out the selected employee code to remove it from the selectedCodes state
    setSelectedCodes(selectedCodes.filter((code) => code !== codeToRemove))
  }
  // db table remove

  const handleRemoveDBTable = (codeToRemove: string) => {
    // setSelectedDBCode(false)
    setSelectedDBCode(selectedDBCode.filter((tabelName:any) => tabelName !== codeToRemove))
  }
  const handleContinue = () => {
    // Handle continue button click, e.g., save data or perform any action
    handleEmployeeModalClose()
  }

  // employee Table modal
  const handleSelectAllChange = (event: React.ChangeEvent<HTMLInputElement>, code:string) => {
    const { checked } = event.target
    if (checked) {
      setSelectedCodes(employees.map((employee: any) => employee.employeeCode))
    } else {
      setSelectedCodes([])
    }
    setSelectAll(checked)
  }

  // employee
  const handleCheckboxChange = (event: React.ChangeEvent<HTMLInputElement>, code: string) => {
    const { checked } = event.target
    if (checked) {
      setSelectedCodes([...selectedCodes, code])
    } else {
      setSelectedCodes(selectedCodes.filter((selectedCode) => selectedCode !== code))
    }
  }

  // Db table name
  const handleCheckboxDBChange = (event: any, code: string) => {
    const { checked } = event.target
    if (checked) {
      setSelectedDBCode([...selectedDBCode, code])
    } else {
      setSelectedDBCode(selectedDBCode.filter((key:any) => key !== code))
    }
  }

  // db Column Name
  const handleCheckboxDBColumnChange = (event: React.ChangeEvent<HTMLInputElement>, columnName: string) => {
    if (event.target.checked) {
      // setSelectedDbSelected((prevSelected) => [...prevSelected, columnName])
      setSelectedDbSelected([...selectedDbSelected, columnName])
    } else {
      // setSelectedDbSelected((prevSelected) => prevSelected.filter((item) => item !== columnName))
      setSelectedDbSelected(selectedDbSelected.filter((key:any) => key !== columnName))
    }
  }

  const handleSelectAllDBChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const { checked } = event.target
    if (checked) {
      setSelectedDBCode(DBTable.map((dbItem:any) => dbItem.tableName))
    } else {
      setSelectedDBCode([])
    }
    setSelectDBAll(checked)
  }

  // const handleChildSubmit : any = async () => {
  //   if (isEditable) {
  //     if (id === null) {
  //       await createRunPayroll({
  //         costCenterCode: values?.costCenterCode, // Pass the costCenterCode to the API call
  //       })
  //     }
  //   } else {
  //     setEditable(true)
  //   }
  // }

  return (
    <Box sx={{ display: 'flex' }}>
      <div
        style={{ display: 'flex', width: '100% ' }}
        // onSubmit={(e) => {
        //   activeState === 0 ? handleFormSubmit(e, handleSubmit) : handlePermissionSubmit()
        // }}
      >
        <OPRAlertControl
          customTitle={t('Audit trails report generation submitted')}
          error={createdAuditTrailReportError}
          handleEditable={setEditable}
          handleSetValue={setValues}
          handleSubmit={handleSubmit}
          isError={createdUserRoleIsError || createdAuditTrailReportIsError}
          isLoading={createdUserRoleLoading || createdAuditTrailReportLoading}
          isSuccess={createdUserRoleSuccess || createdAuditTrailReportSuccess}
          name={t('Generate audit trails report')}
          // previousUrl={routes.auditTrail}
          title={t('Generate audit trails report')}
          type={id ? 'Update' : 'New'}
        />
        <OPRInnerFormLayout
          isHandleContinueClick
          isStepper
          // customHeader={(
          //   <OPRLabel label="Generate audit trails report" variant="h2" />
          // )}
          error={createdUserRoleError}
          handleBack={() => { setActiveState(activeState - 1) }}
          handleCancelClick={(e:any) => navigate(-1)}
          handleContinueClick={(e:any) => {
            if (activeState === 1) {
              handleSubmit()
            } else {
              setActiveState(activeState + 1)
            }
          }}
          handleEditable={setEditable}
          isBackButton={activeState > 0}
          isConfirm={activeState === 3}
          isLoading={createdUserRoleLoading || updatedUserRoleByIdLoading}
          pageType="detailsPage"
          // previousPageUrl={routes.auditTrail}
          subtitle={
            isEditable
              ? 'Please check the user details below.'
              : ''
          }
          title={t('Generate audit trails report')}
        >
          <Box>
            <OPRStepper
              activeStep={activeState}
              steps={[
                t('Filtering criteria'),
                t('Export criteria'),
              ]}
            />
            {activeState === 0 && (
              <AuditTrailInformation
                isIndividualPage
                DBTable={DBTable}
                employees={employees}
                errors={errors}
                handleChange={handleChange}
                handleCheckboxChange={handleCheckboxChange}
                handleCheckboxDBChange={handleCheckboxDBChange}
                handleCheckboxDBColumnChange={handleCheckboxDBColumnChange}
                handleOnChange={handleOnChange}
                handleRemoveDBTable={handleRemoveDBTable}
                handleRemoveEmployee={handleRemoveEmployee}
                handleSelectAllChange={handleSelectAllChange}
                handleSelectAllDBChange={handleSelectAllDBChange}
                isEditable={isEditable}
                selectAll={selectAll}
                selectDBAll={selectDBAll}
                selectedCodes={selectedCodes}
                selectedDBCode={selectedDBCode}
                selectedDbSelected={selectedDbSelected}
                setValues={setValues}
                values={values}
                // handleChildSubmit={handleChildSubmit}

              />
            )}
            {activeState === 1 && (
              <>
                <div style={{
                  width: '100%',
                  color: '#3B3839',
                  fontSize: 16,
                  fontFamily: 'Lato',
                  fontWeight: '400',
                  marginTop: 30,
                  marginBottom: 30,
                  wordWrap: 'break-word',
                }}
                >
                  All fields are mandatory except those marked optional.
                </div>
                <OPRResponsiveGrid>
                  <Grid item md={2} sm={1} xs={1}>

                    <OPRSelectorControl
                      defaultValue={{ exportFormetName: 'PDF' }}
                      isEditable={isEditable}
                      keyName="exportFormetName"
                      label="Export format"
                      multiple={false}
                      name="exportFileFormat"
                      options={[
                        { exportFormetName: 'PDF', providerTypeValue: 0 },
                        { exportFormetName: 'Excel', providerTypeValue: 1 },
                      ]}
                      placeholder="Select an option"
                      value={{
                        exportFormetName: values?.exportOptionsDto?.exportFileFormat === 1 ? 'Excel' : 'PDF',
                        providerTypeValue: values?.exportOptionsDto?.exportFileFormat ?? 0, // Default to 0 (PDF)
                        exportFileFormat: values?.exportOptionsDto?.exportFileFormat ?? 0, // Default to 0 (PDF)
                      }}
                      valueKey="providerTypeValue"
                      onChange={(text: any) => {
                        // Determine the selected file format
                        const selectedFileFormat = text?.providerTypeValue

                        // Update the exportFileFormat inside exportOptionsDto
                        const updatedExportOptionsDto = {
                          ...values?.exportOptionsDto,
                          exportFileFormat: selectedFileFormat,
                        }

                        // Pass the updated exportOptionsDto to handleOnChange
                        handleOnChange('exportOptionsDto', updatedExportOptionsDto)
                      }}
                    />
                  </Grid>
                </OPRResponsiveGrid>
              </>

            )}

            {/* {activeState === 2 && (
              <div className="div" />

            )} */}
          </Box>
        </OPRInnerFormLayout>
      </div>
    </Box>
  )
}
