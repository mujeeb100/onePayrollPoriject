// export {}
import { Checkbox } from '@mui/material'
import { RightDirection } from 'assets/svg-images/SvgComponents'
import OPRButton from 'components/atoms/button/OPRButton'
import OPRLabel from 'components/atoms/label/OPRLabel'
import React from 'react'

interface CustomCheckboxProps {
  selectedDBTable: string[];
  selectedDBCode:string[];
  selectedDbSelected: string[],
  handleCheckboxDBChange: (event: React.ChangeEvent<HTMLInputElement>, code: string) => void;
  handleRemoveEmployee: (codeToRemove: string) => void;
  handleSelectAllDBChange: (event: React.ChangeEvent<HTMLInputElement>) => void;
  selectAll: boolean;
}

function DbTableModal({
  onChange, selectDBAll, handleSelectAllDBChange, selectedDBCode, dataTable, selectedDBTable, handleCheckboxDBChange, handleRemoveEmployee,
}: any) {
  console.log(selectedDBCode, 'selectedDBCode')
  return (

    <div>

      {/* <OPRLabel>Search for an existing DB table name</OPRLabel>

      {/* search Functionility */}
      {/* <div style={{
        width: '100%', height: '100%', display: 'flex', flexDirection: 'column', justifyContent: 'flex-start', alignItems: 'flex-start', gap: 4,
      }}
      >
        <div style={{
          alignSelf: 'stretch',
          paddingTop: 4,
          paddingBottom: 4,
          paddingLeft: 16,
          paddingRight: 8,
          background: 'white',
          borderRadius: 8,
          border: '1px solid #666364',
          display: 'flex',
          justifyContent: 'flex-start',
          alignItems: 'center',
          gap: 8,
        }}
        >
          <div style={{
            flex: '1 1 0', height: 24, display: 'flex', justifyContent: 'flex-start', alignItems: 'center', gap: 8,
          }}
          >
            <div style={{ width: 16, height: 16, position: 'relative' }}>
              <img
                alt="placeholder"
                src="https://via.placeholder.com/12x12"
                style={{
                  width: 12, height: 12, left: 2, top: 2, position: 'absolute',
                }}
              />
            </div>
            <div style={{
              flex: '1 1 0', color: '#7D7B7C', fontSize: 16, fontFamily: 'Lato', fontWeight: 400, lineHeight: 24, wordWrap: 'break-word',
            }}
            >
              Search
            </div>
          </div>
        </div>
      </div>  */}
      {/* <label style={{ marginBottom: '10px', marginTop: '10px', display: 'block' }}>
        <input
          checked={selectDBAll}
          type="checkbox"
          onChange={handleSelectAllDBChange}
        />
        {' '}
        Select All
      </label> */}
      <hr style={{ borderColor: '#E8E6E7', marginBottom: '10px' }} />
      {dataTable?.map((table:any) => (
        <div key={table.code}>
          <div style={{ display: 'flex', alignItems: 'center', marginBottom: '5px' }}>
            <label style={{ marginRight: '10px', display: 'flex' }}>
              <Checkbox
                checked={selectedDBCode?.includes(table?.tableName)}
                onChange={(event) => {
                  handleCheckboxDBChange(event, table?.tableName)
                }}
              />

              <div style={{ display: 'block' }}>
                <OPRLabel label={` ${table.tableLabel}`} variant="subtitle2" />
                <OPRLabel label={` ${table.tableName}`} variant="subtitle2" />

                {/* <OPRLabel label={`${dbcolumn.personalEmailAddress}`} variant="body2" /> */}
              </div>
            </label>
          </div>
          <hr style={{ borderColor: '#E8E6E7', marginTop: '5px', marginBottom: '5px' }} />
        </div>
      ))}

    </div>
  )
}

function DbTableModal2({
  onChange, selectDBAll, handleSelectAllDBChange, selectedDBCode, selectedDbSelected, dataTable, selectedDBTable, handleCheckboxDBChange, handleRemoveEmployee, handleCheckboxDBColumnChange,
}: any) {
  // Extract unique table names
  const uniqueTableNames = Array.from(new Set(dataTable.map((item:any) => item.tableName)))
  console.log(selectedDbSelected, 'selectedDbSelected')
  return (
    <div>

      <div style={{ height: 400 }}>
        <table style={{ width: '100%' }}>
          <thead>
            <tr>
              <th style={{ textAlign: 'left' }}><OPRLabel style={{ marginBottom: '10px' }} variant="subtitle2">Db Table</OPRLabel></th>
              <th style={{ textAlign: 'left' }}><OPRLabel style={{ marginBottom: '10px' }} variant="subtitle2">Db Column</OPRLabel></th>
              <th />
            </tr>
          </thead>
          <tbody style={{ overflowY: 'scroll', height: 400 }}>
            {dataTable.map((table: any) => table.columns.map((column: any) => (
              <tr key={`${table.tableName}-${column.columnName}`}>
                <td style={{ display: 'flex', alignItems: 'center' }}>
                  {/* <OPRLabel variant="body2">{table.tableName}</OPRLabel> */}
                </td>
                <td style={{ display: 'flex' }}>
                  <Checkbox
                    checked={selectedDbSelected?.includes(column?.columnName)}
                    onChange={(event) => handleCheckboxDBColumnChange(event, column?.columnName)}
                  />
                  <OPRLabel variant="body2">{table.tableName}</OPRLabel>
                </td>
                <td>
                  <OPRLabel variant="body2">{column.columnName}</OPRLabel>
                </td>
                <td>
                  <OPRButton color="secondary" variant="text">
                    <RightDirection />
                  </OPRButton>
                </td>
              </tr>
            )))}
          </tbody>
        </table>
      </div>
    </div>
  )
}

export { DbTableModal, DbTableModal2 }
