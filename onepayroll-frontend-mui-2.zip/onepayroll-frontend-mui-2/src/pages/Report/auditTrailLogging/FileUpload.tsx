import { Box } from '@mui/material'
import { UploadIcon } from 'assets/svg-images/SvgComponents'
import { t } from 'i18next'
import React, { useCallback, useState } from 'react'
import { useDropzone } from 'react-dropzone'

interface FileUploadProps {
  onFileUpload: (file: File) => void;
}
function FileUpload({ onFileUpload }: FileUploadProps) {
// const FileUpload: React.FC<FileUploadProps> = ({ onFileUpload }) => {
  const [selectedFile, setSelectedFile] = useState<File | null>(null)

  const onDrop = useCallback((acceptedFiles: File[]) => {
    const file = acceptedFiles[0]
    setSelectedFile(file)
    onFileUpload(file)
  }, [onFileUpload])

  const { getRootProps, getInputProps, isDragActive } = useDropzone({ onDrop })

  return (
    <div {...getRootProps()} style={dropzoneStyles}>
      <input {...getInputProps()} />
      <Box>
        <UploadIcon />
        <p>
          Drop your file here, or
          {' '}
          {' '}
          <span style={{ color: '#0049DB', fontWeight: 'bold' }}>
            {t('bulk_upload_data_select_file')}
          </span>
        </p>
      </Box>
    </div>
  )
}

const dropzoneStyles: React.CSSProperties = {
  border: '2px dashed #80B7FF',
  borderRadius: '4px',
  padding: '20px',
  textAlign: 'center',
  cursor: 'pointer',
  backgroundColor: '#E9F4FF',
}

export default FileUpload
