import {
  Box,
} from '@mui/material'
// import { useGetAllDocuTaxProReportingQuery } from 'api/reports'
import { useGetAllDocuTaxProReportingQuery } from 'api/reportingServices'
import axios from 'axios'
import { reportDocuTaxProColumn } from 'components/atoms/table/OPRTableConstant'
import { OPRInnerListLayout } from 'components/organism/OPRInnerLayoutList'
import apiEndPoint from 'constants/apiEndPoint'
import saveAs from 'file-saver'
import { t } from 'i18next'
import React, { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { routes } from 'routes/routes'
import {
  generateFilterUrl,
  getAPIWithEntityUrl,
  getauthToken,
} from 'utils'

function DocuTaxProList() {
  const navigate: any = useNavigate()
  const [selelctedDelete, setSelelctedDelete]:any = useState({
    data: {},
    isDelete: false,
    name: '',
  })
  const [filterData, setFilterData]:any = useState({
    pageNumber: 1,
    pageSize: 20,
    totalItems: 0,
    orderByAsc: true,
    sortBy: '',
    SearchText: '',
  })
  const {
    data: allPosts,
    isLoading: isLoadingAllPosts,
    isSuccess: isSuccessAllPosts,
    isError: isErrorAllPosts,
    error: errorAllPosts,
    refetch: refetchAllPosts,
  } = useGetAllDocuTaxProReportingQuery(generateFilterUrl(filterData), {
    pollingInterval: 5000,
  })

  const sorting = (
    event: React.MouseEvent<unknown>,
    property: keyof any,
  ) => {
    const isAsc = filterData.sortBy === property && filterData.orderByAsc === true
    setFilterData({ ...filterData, orderByAsc: !isAsc, sortBy: property })
  }

  useEffect(() => {
    setFilterData({ ...filterData, totalItems: allPosts?.totalItems ? allPosts?.totalItems : 0 })
  }, [allPosts?.pageNumber, filterData.sortBy, filterData.orderByAsc, allPosts?.totalItems])

  const onSearch = (e: any, data: any) => {
    setFilterData({ ...filterData, ...data })
  }
  const handlePagination = (pageNumber: number, pageSize: number) => {
    setFilterData({ ...filterData, pageNumber })
  }

  const getDownloadfile = async (item: any) => {
    const urldownload = `${process.env.REACT_APP_MP_BASE_URL}/${apiEndPoint.downloadLogsDocutaxPro}`
    const token = getauthToken()
    const regExpFilename = /filename=(?<filename>[^;]*)/
    axios
      .get(
        `${getAPIWithEntityUrl(urldownload)}?batchJobId=${item}`,
        {
          responseType: 'blob',
          headers: {
            Authorization: `Bearer ${token}`,
          },
        },
      )
      .then(({ data, headers, status }) => {
        if (status === 200) {
          const filename = regExpFilename.exec(headers['content-disposition'] ?? '')?.groups
            ?.filename ?? null
          if (filename !== null) {
            saveAs(
              new Blob([data], { type: headers['content-type'] }),
              filename,
            )
          }
        }
      })
      .catch((error: any) => {
        console.error('Download Error:', error)
      })
  }

  return (
    <Box sx={{ display: 'flex' }}>
      <OPRInnerListLayout
        Search={filterData.SearchText}
        addHandleClick={() => navigate(routes.createDocutaxPro)}
        columns={reportDocuTaxProColumn(getDownloadfile)}
        customAdd="Upload documents"
        dataList={JSON.parse(JSON.stringify(allPosts?.records || []))}
        error={errorAllPosts}
        filterData={filterData}
        handlePagination={handlePagination}
        handleSearch={onSearch}
        isError={isErrorAllPosts}
        isExport={false}
        rowNumber={0}
        selelctedUser={selelctedDelete}
        setSelelctedUser={setSelelctedDelete}
        sortHandleClick={sorting}
        title={t('Integration Documents')}
      />

    </Box>
  )
}

export default DocuTaxProList
