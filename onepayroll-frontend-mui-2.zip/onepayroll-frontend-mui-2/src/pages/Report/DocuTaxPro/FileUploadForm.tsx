import { useTheme } from '@emotion/react'
import { Box, Grid, Typography } from '@mui/material'
import { BlobReader, ZipReader } from '@zip.js/zip.js'
import { useLazyGetUploadDataByIdQuery } from 'api/inegrationServices'
import { useDocuTaxProReportingCreateMutation } from 'api/reportingServices'
import {
  ExcelIcon, Info, RedCross,
} from 'assets/svg-images/SvgComponents'
import OPRButton from 'components/atoms/button/OPRButton'
import OPRCheckbox from 'components/atoms/checkbox/OPRCheckbox'
import OPRLabel from 'components/atoms/label/OPRLabel'
import OPRStepper from 'components/atoms/stepper'
import OPRSelectorControl from 'components/molecules/OPRSelectorControl/OPRSelectorControl'
import OPRAlertControl from 'components/organism/OPRAlertControl'
import { OPRInnerFormLayout } from 'components/organism/OPRInnerFormLayout'
import { validationSchemaDocuTaxPro } from 'constants/validate'
import { useEditable } from 'hooks/useEdit'
import useForm from 'hooks/useForm'
import { useEffect, useRef, useState } from 'react'
import { FileWithPath } from 'react-dropzone'
import { useTranslation } from 'react-i18next'
import { useLocation, useNavigate } from 'react-router-dom'
import { routes } from 'routes/routes'
import { getParamsValue } from 'utils'

import DocuTaxAlert from './DocuTaxAlert'
import FileUpload from './FileUpload'

function FileUploadForm() {
  const [checked, setChecked] = useState(false)
  const [isConfirmationModalOpen, setConfirmationModalOpen]:any = useState(false)
  const [filterDataTax, setFilterDataTax]:any = useState({
    IRType: '',
    UploadZipFile: true,
    UnzipFile: true,
  })
  // const CreateReader = ZipReader
  const [Entity, setEntityFile]: any = useState<File | FileWithPath[] | any>(
    null,
  )
  const [Payroll, setPayrollFile]: any = useState<File | FileWithPath[] | any>(
    [],
  )
  const [Employee, setEmployeeFile]: any = useState<
            File | FileWithPath[] | any
          >([])
  const [fileList, setFileList]: any = useState([Entity?.path,
    Employee?.path, Payroll?.path])
  const myRef:any = useRef()
  const [fileStore, setFileStore]:any = useState([])
  const location: any = useLocation()
  const { id, viewUrl } = getParamsValue(location, routes.createUserRole)
  // const [dataSet, setDataSet] = useState()
  const [changeChecbox, setChangeChecbox]:any = useState({
    isCheckedUploadZipFile: false,
    isCheckedUnzipFiles: false,
  })
  const [activeState, setActiveState] = useState(0)
  const { t } = useTranslation()
  const theme:any = useTheme() // Use the Theme type for the theme variable
  const [extractedFiles, setExtractedFiles]:any = useState([])
  const { isEditable, setEditable } = useEditable()
  const {
    values,
    setValues,
    errors,
    handleChange,
    setErrors,
    handleFormSubmit,
    handleOnChange,
  } = useForm(validationSchemaDocuTaxPro)

  const navigate = useNavigate()

  // useDocuTaxProReportingCreateMutation
  const [
    createDocuTaxProData,
    {
      data: createdDocuTaxPro,
      error: createdDocuTaxProError,
      isLoading: createdDocuTaxProLoading,
      isSuccess: createdDocuTaxProSuccess,
      isError: createdDocuTaxProIsError,
    },
  ] = useDocuTaxProReportingCreateMutation()

  const [
    getTemplate,
    {
      data: updatedUserRoleByIdResponse,
      error: updatedUserRoleByIdError,
      isLoading: updatedUserRoleByIdLoading,
      isSuccess: updatedUserRoleByIdSuccess,
      isError: updatedUserRoleByIdIsError,
    },
  ] = useLazyGetUploadDataByIdQuery()
  //   useEffect(() => {
  //     if (id) {
  //       setValues(updatedUserRoleByIdResponse?.responseData)
  //     } else {
  //       setValues({})
  //       // setEditable(false)
  //     }
  //   }, [updatedUserRoleByIdResponse?.responseData,
  //   ])

  useEffect(() => {
    setFileList([Entity?.path, Employee?.path, Payroll?.path])
  }, [Entity, Employee, Payroll])

  const handleSubmit: any = async () => {
    // Check if the "Upload zip file" checkbox is unchecked
    if (!changeChecbox.isCheckedUploadZipFile && (Entity)) {
      // Only allow uploading .zip file when the checkbox is unchecked and no other files are selected
      // const params = {} // Declare the 'params' variable

      // if (Entity && Entity.name.endsWith('.zip')) {
      if (Entity && (Entity.name.endsWith('.zip') || Entity.name.endsWith('.pdf'))) {
        const formData = new FormData()
        formData.append('file', Entity)
        formData.append('iRType', values.providerType) // Add IRType directly to the formData
        formData.append('uploadZipFile', changeChecbox.isCheckedUploadZipFile)
        formData.append('unzipFile', changeChecbox.isCheckedUnzipFiles)

        // Add other params from the `params` object into the formData using array iteration
        // Object.entries(params).forEach(([key, value]) => {
        //   formData.append(key, value as string)
        // })
        await createDocuTaxProData(formData)
      } else {
        // Show error message or handle accordingly
        console.error('Please upload a .zip file')
      }
    } else {
      // If checkbox is checked or other files are also selected, proceed with normal submission
      const formData = new FormData()
      formData.append('file', Entity)
      formData.append('iRType', values.providerType) // Add IRType directly to the formData
      formData.append('uploadZipFile', changeChecbox.isCheckedUploadZipFile)
      formData.append('unzipFile', changeChecbox.isCheckedUnzipFiles)

      // const params = {} // Declare the 'params' variable

      // // Add other params from the `params` object into the formData using array iteration
      // Object.entries(params).forEach(([key, value]) => {
      //   formData.append(key, value as string)
      // })

      await createDocuTaxProData(formData)
    }
  }

  const handleFileUpload = async (files:any) => {
    setEntityFile(files)

    const file = files
    if (!file) return
    if (!changeChecbox.isCheckedUnzipFiles) {
      setFileStore([file.name])
      return
    }
    const zipFileReader = new BlobReader(file)
    // Create a new ZipReader
    const zipReader = new ZipReader(zipFileReader)

    // Get entries from the zip file
    const entries = await zipReader.getEntries()

    const textWriters:any = []
    entries.forEach(async (entry) => {
      // const contEntry = entry
      textWriters.push(entry.filename)
    })
    setFileStore(textWriters)
  }

  // const
  // Function to check if a checkbox is checked
  const isCheckboxChecked = (name:any) => changeChecbox[name]
  useEffect(() => {
    if (id) {
      //   updateUserRoleById(id)
      setEditable(viewUrl)
    }
  }, [])

  useEffect(() => {
    if (createdDocuTaxProSuccess) {
      // Reset form values after successful add operation
      setValues({})
      setErrors({})
    }
  }, [createdDocuTaxProSuccess])

  const handlePermissionSubmit: any = async () => {
    if (activeState === 1) {
      setActiveState(activeState + 1)
    } else {
      myRef.current.childMethod()
    }
    // myRef.current.childMethod()
  }

  useEffect(() => {
    const createdUserRoleSuccessStatus = createdDocuTaxProSuccess || false
    if (createdUserRoleSuccessStatus) {
      if (activeState <= 1) {
        setActiveState(activeState + 1)
      }
    }
  }, [createdDocuTaxProSuccess])

  const handleTemplate = async () => {
    await getTemplate
  }
  // Function to handle continue button click
  const handleContinueClick = () => {
    if (activeState === 2) {
      // Upload files only if at least one file is selected and "Unzip files" checkbox is checked
      if ((fileList.length > 0 && checked) || fileList.length === 1) {
        // Check if filterDataTax is correctly updated before calling the mutation
        // createDocuTaxProData(generateFilterUrl(filterDataTax))
        handleSubmit()
      }
      handleConfirmationModalOpen()
    } else {
      setActiveState(activeState + 1)
    }
  }

  const handleChangeCheckbox = (isChecked: boolean, name:string) => {
    setChangeChecbox((prev:any) => ({
      ...prev,
      [name]: isChecked,
    }))
  }

  useEffect(() => {
    if (values.providerType) {
      setChangeChecbox({
        isCheckedUploadZipFile: true,
        isCheckedUnzipFiles: true,
      })
    }
  }, [values.providerType])

  const acceptObj: any = {
    'application/pdf': ['.pdf'],
    'application/zip': ['.zip'],
  }

  useEffect(() => {
    if (Entity) {
      handleFileUpload(Entity)
    }
  }, [changeChecbox.isCheckedUnzipFiles, changeChecbox.isCheckedUploadZipFile])

  const handleConfirmationModalOpen = () => {
    setConfirmationModalOpen(true)
  }

  // const handleProceed = () => {
  //   handleSubmit()
  //   // handleContinueClick()
  //   // navigate(-1)
  // }

  return (
    <Box sx={{ display: 'flex' }}>
      <DocuTaxAlert
        open={isConfirmationModalOpen}
        onClose={handleConfirmationModalOpen}
        onProceed={handleSubmit}
      />

      <div
        style={{ display: 'flex', width: '100% ' }}
      >
        <OPRAlertControl
          customTitle={t('bulk_upload_submitted')}
          error={createdDocuTaxProError}
          handleEditable={setEditable}
          handleSetValue={setValues}
          handleSubmit={handleSubmit}
          isError={createdDocuTaxProIsError}
          isLoading={createdDocuTaxProLoading}
          isSuccess={createdDocuTaxProSuccess}
          name={t('Upload integration documents')}
          // previousUrl={routes.dataUpload}
          title={t('Upload integration documents')}
          type={id ? 'Update' : 'New'}
        />
        <OPRInnerFormLayout
          isHandleContinueClick
          isStepper
          // customHeader={(
          //   <OPRLabel label="Upload integration documents" variant="h2" />
          // )}
          error={createdDocuTaxProError}
          handleBack={() => { setActiveState(activeState - 1) }}
          handleCancelClick={(e:any) => navigate(-1)}
          handleContinueClick={handleContinueClick}
          handleEditable={setEditable}
          isBackButton={activeState > 0}
          isLoading={createdDocuTaxProLoading}
          pageType="detailsPage"
          // previousPageUrl={routes.dataUpload}
          step={activeState}
          subtitle={
            isEditable
              ? 'Please check the user details below.'
              : ''
          }
          title={t('Upload integration documents')}
        >
          <Box>
            <OPRStepper
              activeStep={activeState}
              steps={[
                t('Upload'),
                t('Documents & Files'),
                t('Confirmation'),
              ]}
            />
            {activeState === 0 && (
              <Box sx={{ mt: '30px' }}>

                <OPRLabel variant="body2">{t('All fields are mandatory except those marked optional.')}</OPRLabel>
                {/* </Box> */}
                {/* Select input type IR */}
                <Box sx={{ mt: '30px' }}>
                  <Grid item md={2} sm={1} xs={1}>
                    <OPRSelectorControl
                      error={errors?.providerType}
                      isEditable={isEditable}
                      keyName="providerTypeName"
                      label="IR Form Type"
                      multiple={false}
                      name="providerType"
                      options={[
                        { providerTypeName: 'IR56B', providerTypeValue: 'IR56B' },
                        { providerTypeName: 'IR56M', providerTypeValue: 'IR56M' },
                        { providerTypeName: 'IR56E', providerTypeValue: 'IR56E' },
                        { providerTypeName: 'IR56F', providerTypeValue: 'IR56F' },
                        { providerTypeName: 'IR56G', providerTypeValue: 'IR56G' },
                        { providerTypeName: 'ACRB', providerTypeValue: 'ACRB' },
                        { providerTypeName: 'ACRE', providerTypeValue: 'ACRE' },
                        { providerTypeName: 'ACRF', providerTypeValue: 'ACRF' },
                        { providerTypeName: 'ACRG', providerTypeValue: 'ACRG' },
                      ]}
                      placeholder="Select an option"
                      value={
                        { providerTypeName: values?.providerType, providerTypeValue: values?.providerType }
                      }
                      valueKey="providerTypeValue"
                      onChange={(text:any) => {
                        // handleChange({ target: { name: 'providerType', value: text?.providerTypeValue }, persist: () => {} })
                        // setValues({ ...values, providerType: text })
                        // setFilterDataTax({ ...filterDataTax, IRType: text?.providerTypeValue })
                        handleOnChange('providerType', text?.providerTypeValue)
                      }}
                    />
                  </Grid>
                </Box>
                {/* Select input type IR */}

                {!!values?.providerType && (
                  <>
                    {/* upload a checkbox logic */}

                    <OPRCheckbox
                      checked={changeChecbox.isCheckedUploadZipFile}
                      label="Upload zip file"
                      onChange={(e:any) => {
                        // setFilterDataTax(
                        //   {
                        //     ...filterDataTax,
                        //     UploadZipFile: e.target.checked,
                        //   },
                        // )
                        handleChangeCheckbox(e.target.checked, 'isCheckedUploadZipFile')
                      }}
                    />
                    <OPRLabel variant="body2">{t('Upload 2 or more documents in a zip file format.')}</OPRLabel>

                    <OPRCheckbox
                      checked={changeChecbox.isCheckedUnzipFiles}
                      label="Unzip files"
                      onChange={(e:any) => {
                        // setFilterDataTax(
                        //   {
                        //     ...filterDataTax,
                        //     UnzipFile: e.target.checked,
                        //   },
                        // )
                        handleChangeCheckbox(e.target.checked, 'isCheckedUnzipFiles')
                      }}
                    />
                    <OPRLabel variant="body2">{t('Extract the zip file contents after upload.')}</OPRLabel>
                    {/* upload a checkbox logic */}
                  </>
                )}

                <Box sx={{
                  mt: '24px',
                }}
                >
                  <OPRLabel variant="body1">{t('Integration document')}</OPRLabel>
                  <FileUpload
                    acceptObj={acceptObj}
                    onFileUpload={(files) => {
                      handleFileUpload(files)
                      setEntityFile(files)
                    }}
                  />
                  {fileList[0] && (
                    <Box sx={{
                      display: 'flex',
                      flexDirection: 'row',
                      justifyContent: 'space-between',
                    }}
                    >
                      <Box sx={{
                        display: 'flex',
                        flexDirection: 'row',
                        marginTop: '5px',
                      }}
                      >
                        <ExcelIcon />
                        <OPRLabel variant="body2">{fileList[0]}</OPRLabel>
                      </Box>
                      <OPRButton
                        variant="text"
                        onClick={() => {
                          // handleTemplate()
                          setEntityFile(null)
                        }}
                      >
                        <RedCross />
                      </OPRButton>
                    </Box>
                  )}
                </Box>

              </Box>
            )}
            {activeState === 1 && (
              <Box sx={{ mt: '30px' }}>

                <Box sx={{
                  padding: '24px', display: 'flex', flexDirection: 'row', gap: '6px', border: '1px solid #D4D2D3', borderRadius: '10px',
                }}
                >
                  <OPRLabel variant="body1">
                    {t('bulk_upload_data_first_note_title')}
                  </OPRLabel>
                  <OPRLabel variant="body2">{t('bulk_upload_files_note')}</OPRLabel>
                </Box>
                <Box sx={{ mt: '20px' }}>
                  {fileStore?.map((file:any) => (
                    <Box
                      key={file}
                      sx={{
                        display: 'flex',
                        flexDirection: 'row',
                        justifyContent: 'space-between',
                        width: '100%',
                        padding: '10px 0px',
                        borderBottom: '1px solid #D4D2D3',
                      }}
                    >
                      <Box sx={{
                        display: 'flex',
                        flexDirection: 'row',
                        gap: '10px',
                      }}
                      >
                        <OPRLabel variant="body2">{file}</OPRLabel>
                      </Box>

                    </Box>
                  ))}
                </Box>
                {/* total length of the list item */}
                <Box
                  sx={{
                    marginTop: '10px',
                    width: '100%',
                    height: '100%',
                    background: '#E9F4FF',
                    borderRadius: 4,
                    // padding: 1,
                    justifyContent: 'flex-start',
                    alignItems: 'flex-start',
                    gap: 12,
                    display: 'inline-flex',
                  }}
                >
                  <Box
                    sx={{
                      flex: '1 1 0',
                      flexDirection: 'column',
                      justifyContent: 'flex-start',
                      alignItems: 'flex-start',
                      display: 'inline-flex',
                    }}
                  >
                    <Typography
                      sx={{
                        alignSelf: 'stretch',
                        color: '#3B3839',
                        fontSize: 16,
                        fontFamily: 'Lato',
                        fontWeight: 700,
                        wordWrap: 'break-word',
                      }}
                    >
                      Total uploaded files:
                      {' '}
                      {fileStore?.length}
                    </Typography>
                  </Box>
                </Box>
                {/* Repeat the above structure for other elements */}
              </Box>
            )}
            {activeState === 2 && (
              <Box sx={{ mt: '30px' }}>
                <Box sx={{
                  padding: '24px', display: 'flex', flexDirection: 'row', gap: '6px', border: '1px solid #D4D2D3', borderRadius: '10px',
                }}
                >
                  <OPRLabel variant="body1">
                    {t('bulk_upload_data_first_note_title')}
                  </OPRLabel>
                  <OPRLabel variant="body2">{t('bulk_upload_files_note')}</OPRLabel>
                </Box>
                <Box sx={{ mt: '20px' }}>
                  {fileStore?.map((file:any) => (
                    <Box
                      key={file}
                      sx={{
                        display: 'flex',
                        flexDirection: 'row',
                        justifyContent: 'space-between',
                        width: '100%',
                        padding: '10px 0px',
                        borderBottom: '1px solid #D4D2D3',
                      }}
                    >
                      <Box sx={{
                        display: 'flex',
                        flexDirection: 'row',
                        gap: '10px',
                      }}
                      >
                        <OPRLabel variant="body2">{file}</OPRLabel>
                      </Box>

                    </Box>
                  ))}
                </Box>
                {/* total length of the list item */}
                <Box
                  sx={{
                    marginTop: '10px',
                    width: '100%',
                    height: '100%',
                    background: '#E9F4FF',
                    borderRadius: 4,
                    // padding: 1,
                    justifyContent: 'flex-start',
                    alignItems: 'flex-start',
                    gap: 12,
                    display: 'inline-flex',
                  }}
                >
                  <Box
                    sx={{
                      flex: '1 1 0',
                      flexDirection: 'column',
                      justifyContent: 'flex-start',
                      alignItems: 'flex-start',
                      display: 'inline-flex',
                    }}
                  >
                    <Typography
                      sx={{
                        alignSelf: 'stretch',
                        color: '#3B3839',
                        fontSize: 16,
                        fontFamily: 'Lato',
                        fontWeight: 700,
                        wordWrap: 'break-word',
                      }}
                    >
                      Total uploaded files:
                      {' '}
                      {fileStore?.length}
                    </Typography>
                  </Box>
                </Box>
                <Box
                  className="pop-up"
                  sx={{
                    display: 'flex',
                    padding: '12px',
                    gap: '12px',
                    alignItems: 'flex-start',
                    borderRadius: '4px',
                    alignSelf: 'stretch',
                    backgroundColor: `${theme.palette.Invite.main}`,
                    marginTop: 1,
                  }}
                >
                  <Info />
                  <OPRLabel
                    CustomStyles={{
                      backgroundColor: `${theme.palette.Invite.main}`,
                    }}
                    backgroundColor={theme.palette.Invite.main}
                    variant="body2"
                  >
                    Please note that you won't be able to revert this action.
                  </OPRLabel>
                </Box>

              </Box>
            )}
          </Box>
        </OPRInnerFormLayout>
      </div>
    </Box>
  )
}

export default FileUploadForm
