import { useTheme } from '@emotion/react'
import {
  Box,
  Button, DialogContent, ModalProps,
} from '@mui/material'
import { Info } from 'assets/svg-images/SvgComponents'
import OPRLabel from 'components/atoms/label/OPRLabel'
import { CustomDialog } from 'components/atoms/modal/OPRModal'
import React from 'react'

interface ConfirmationModalProps extends Omit<ModalProps, 'children'> {
    open: boolean;
    onClose: () => void;
    // children: any; // Update children prop type
    children?: React.ReactNode;
    onProceed: () => void;
}

function DocuTaxAlert({ open, onClose, onProceed }:ConfirmationModalProps) {
  const theme:any = useTheme()
  const handleBack = () => {
    // Go back to the previous page
    window.history.back()
  }
  return (
    <Box>
      {/* <Button onClick={handleOpen}>Open DocuTax Alert</Button> */}
      <CustomDialog isOpen={open} type="loader">
        <DialogContent>
          <Box
            sx={{
              width: '100%',
              height: '100%',
              background: 'white',
              flexDirection: 'column',
              justifyContent: 'flex-start',
              display: 'inline-flex',

            }}
          >
            {/* Header */}
            <Box
              style={{ marginBottom: '15px' }}

            >
              <OPRLabel
                sx={{
                  color: '#3B3839',
                  fontWeight: 700,
                  wordWrap: 'break-word',
                }}
                variant="h4"
              >
                Are you sure to upload these documents?
              </OPRLabel>
            </Box>
            {/* Warning */}
            <Box
              sx={{
                alignSelf: 'stretch',
                marginBottom: '16px',
              }}
            >
              <Box
                className="pop-up"
                sx={{
                  display: 'flex',
                  padding: '12px',
                  gap: '12px',
                  alignItems: 'flex-start',
                  borderRadius: '4px',
                  alignSelf: 'stretch',
                  backgroundColor: `${theme.palette.Invite.main}`,
                  marginTop: 1,
                }}
              >
                <Info />
                <OPRLabel
                  CustomStyles={{
                    backgroundColor: `${theme.palette.Invite.main}`,
                  }}
                  backgroundColor={theme.palette.Invite.main}
                  variant="body2"
                >
                  Please note that you won't be able to revert this action.
                </OPRLabel>
              </Box>
            </Box>
            {/* Buttons */}
            <Box
              display="flex"
              justifyContent="space-between"
              mt={4}
            >
              {/* Back Button */}
              <Button
                color="primary"
                variant="text"
                onClick={handleBack}
              >
                Back
              </Button>
              {/* Proceed Button */}

              <Box
                sx={{
                  border: '1px #0049DB solid',
                  borderRadius: '4px',
                  overflow: 'hidden',
                }}
              >
                <Button
                  color="primary"
                  variant="text"
                  onClick={onProceed}
                >
                  Proceed
                </Button>
              </Box>
            </Box>
          </Box>
        </DialogContent>
      </CustomDialog>
    </Box>
  )
}

export default DocuTaxAlert
