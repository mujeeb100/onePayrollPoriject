import {
  Box, DialogActions, DialogContent, Grid,
} from '@mui/material'
import {
  useCustomReportDesignerCreateMutation, useCustomReportDesignerUpdateMutation, useGetAllCustomReportDesignerQuery,
} from 'api/report'
import OPRButton from 'components/atoms/button/OPRButton'
import OPRLabel from 'components/atoms/label/OPRLabel'
import { CustomDialog } from 'components/atoms/modal/OPRModal'
// import ReportDesignerInnerForm from './ReportDesignerInnerForm'
import OPRMultiSelect from 'components/atoms/multiSelectCheckbox/OPRMultiSelectCheckbox'
import OPRInputControl from 'components/molecules/OPRInputControl'
import OPRResponsiveGrid from 'components/molecules/OPRResponsiveGrid'
import OPRSelectorControl from 'components/molecules/OPRSelectorControl/OPRSelectorControl'
import OPRAlertControl from 'components/organism/OPRAlertControl'
import { validationSchemaCustomReportDesigner } from 'constants/validate'
import { useEditable } from 'hooks/useEdit'
import useForm from 'hooks/useForm'
import { t } from 'i18next'
import { useEffect, useState } from 'react'
import { useLocation, useNavigate } from 'react-router-dom'
import { routes } from 'routes/routes'
import { getParamsValue } from 'utils'

import ReportDesignerModal from './ReportDesignerModal'

type Props = {
  title?:string,
  isCancelPayCycleAlert?:boolean
  handleCancelPayCycleAlert?:any
  onClose: () => void,
  isOpen:boolean
  // onEditable ?: (item:any) => void;
  callBack?:any
  name?:string
};
function ReportDesignerAlert(props: Props) {
  const {
    title,
    name,
    onClose,
    isOpen,
    isCancelPayCycleAlert = true,
    handleCancelPayCycleAlert = () => {},
    callBack = () => {},
  } = props
  const location: any = useLocation()
  // const id = getParamsValue(location, routes.createCustomReportDesigner)
  const [isManageReportDesignerAlertOpen, setIsReportDesignerAlertAlertOpen]:any = useState(false)
  const { id, viewUrl } = getParamsValue(location, routes.createReportDesignerCustomReport)
  const [mode, setMode] = useState('view') // Default mode is edit
  const { isEditable, setEditable } = useEditable()
  const [selectedOptions, setSelectedOptions]:any = useState([])
  const [showUnsavedChangesDialogue, setShowUnsavedChangesDialogue]:any = useState(false)
  const {
    values,
    setValues,
    errors,
    handleChange,
    handleOnChange,
    setErrors,
    handleFormSubmit,
  } = useForm(validationSchemaCustomReportDesigner)
  const [filterData, setFilterData]:any = useState({
    pageNumber: 1,
    pageSize: 10000,
    totalItems: 0,
    orderByAsc: true,
    sortBy: '',
    SearchText: '',
  })

  const navigate = useNavigate()
  // view all custom report
  const {
    data: allReportsName,
    isLoading: allReportsNameLoading,
    isSuccess: allReportsNameSuccess,
    isError: allReportsNameIsError,
    error: allReportsNameError,
  } = useGetAllCustomReportDesignerQuery('')

  useEffect(() => {
  }, [allReportsName])

  const [
    createCustomReportDesigner,
    {
      data: createdCustomReportDesignerData,
      error: createdCustomReportDesignerError,
      isLoading: createdCustomReportDesignerLoading,
      isSuccess: createdCustomReportDesignerSuccess,
      isError: createdCustomReportDesignerIsError,
    },
  ] = useCustomReportDesignerCreateMutation()

  const [
    updateCustomReportDesigner,
    {
      data: updatedDataResponse,
      error: updatedCustomReportDesignerError,
      isLoading: updatedCustomReportDesignerLoading,
      isSuccess: updatedCustomReportDesignerSuccess,
      isError: updatedCustomReportDesignerIsError,
    },
  ] = useCustomReportDesignerUpdateMutation()

  useEffect(() => {
    if (id) {
      // updateCustomReportDesignerById(id)
      setEditable(viewUrl)
      // setMode('view') // Set mode to view if id is present
    }
  }, [])

  // reset the values
  useEffect(() => {
    if (createdCustomReportDesignerSuccess) {
      setValues({})
    }
  }, [createdCustomReportDesignerSuccess])

  const handleSubmit: any = async () => {
    // if (isEditable) {
    // if (id === null) {
    await createCustomReportDesigner({
      baseReportId: values?.baseReportId,
      reportName: values?.reportName,
      reportCode: values?.reportCode,
      ReportFormats: values?.ReportFormats,
    })
    onClose()
  }

  async function editCustomReportDesigner() {
    await updateCustomReportDesigner({
      baseReportId: values?.baseReportId,
      reportName: values?.reportName,
      reportCode: values?.reportCode,
      ReportFormats: values?.ReportFormats,
    })
  }
  const onScreenClose:any = (item: any) => {
    setEditable(item)
    setValues({})
  }

  // Function to handle closing the dialogue
  const handleCloseDialogue = () => {
    setShowUnsavedChangesDialogue(false)
  }
  // Define the list of options
  const listOfOptions = [
    { id: 1, roleName: 'Option 1' },
    { id: 2, roleName: 'Option 2' },
    // Add more options as needed
  ]

  useEffect(() => {
    if (createdCustomReportDesignerSuccess) {
      setIsReportDesignerAlertAlertOpen(true)
    }
  }, [createdCustomReportDesignerSuccess])

  // Define a function to render selected options
  const renderValue = (selected: any) => selected.join(', ') // Render selected options as a comma-separated string
  return (
    <Box sx={{ display: 'flex' }}>
      <ReportDesignerModal open={isManageReportDesignerAlertOpen} onClose={() => setIsReportDesignerAlertAlertOpen(false)} />

      <form
        style={{ display: 'flex', width: '100% ' }}
        onSubmit={(e) => handleFormSubmit(e, handleSubmit)}
      >
        <OPRAlertControl
          error={createdCustomReportDesignerError}
          handleEditable={setEditable}
          handleSetValue={setValues}
          handleSubmit={handleSubmit}
          isLoading={
            createdCustomReportDesignerLoading
          }
          name={t('Custom Report Designer')}
          title={t('Custom Report Designer')}
          type={id ? 'Update' : 'New'}
        />

        <CustomDialog
          CustomStyles={{ borderRadius: '16px' }}
          isOpen={isOpen}
          type="loader"

        >
          {/* <DialogTitle>Add Custom Report</DialogTitle> */}
          <div style={{ marginBottom: '15px' }}>
            <OPRLabel variant="h4">
              {`
           Add Custom Report
            `}
            </OPRLabel>
          </div>
          <DialogContent>
            <Box>
              <OPRResponsiveGrid>
                <Grid item md={4} sm={6} xs={12}>
                  <OPRInputControl
                    error={t(errors?.reportCode)}
                    isEditable={isEditable}
                    label="Report ID"
                    name="reportCode"
                    value={values?.reportCode}
                    onChange={handleChange}
                  />
                </Grid>
                <Grid item md={4} sm={6} xs={12}>
                  <OPRInputControl
                    // disabled={!!id}
                    error={t(errors?.reportName)}
                    isEditable={isEditable}
                    label="Report Name"
                    name="reportName"
                    value={values?.reportName}
                    onChange={handleChange}
                  />
                </Grid>
                {/* <Grid item md={2} sm={1} xs={1} /> */}
                <Grid item md={4} sm={6} xs={12}>
                  <OPRMultiSelect
                    error={errors?.ReportFormats}
                    label="Allow export format"
                    name="ReportFormats"
                    options={[
                      { name: 'PDF', value: 'PDF' },
                      { name: 'Excel', value: 'Excel' },
                      { name: 'CSV', value: 'CSV' },
                    ]}
                    placeholder="Select an option"
                    value={values?.ReportFormats}
                    onChange={(selectedFormat) => {
                      setValues({ ...values, ReportFormats: selectedFormat })
                    }}
                  />
                </Grid>
                <Grid item md={4} sm={6} xs={12}>

                  <OPRSelectorControl
                    error={errors?.baseReportId}
                    isEditable={isEditable}
                    keyName="reportName"
                    label="Select base template"
                    multiple={false}
                    name="baseReportId"
                    options={(allReportsName?.records || [])}
                    placeholder="Select an option"
                    value={(allReportsName?.records || []).find((o:any) => o.id === values?.baseReportId)}
                    valueKey="id"
                    onChange={(text:any) => {
                      setValues({ ...values, baseReportId: text?.id })
                    }}
                  />
                </Grid>
              </OPRResponsiveGrid>
            </Box>
          </DialogContent>
          <DialogActions>
            <OPRButton
              color="info"
              variant="text"
              onClick={() => {
                handleCancelPayCycleAlert()
                onClose()
              }}
            >
              Cancel
            </OPRButton>
            <OPRButton
              color="info"
              variant="text"
              onClick={handleSubmit}

            >
              Confirm
            </OPRButton>
          </DialogActions>
        </CustomDialog>
        {' '}
      </form>
    </Box>
  )
}

export default ReportDesignerAlert
