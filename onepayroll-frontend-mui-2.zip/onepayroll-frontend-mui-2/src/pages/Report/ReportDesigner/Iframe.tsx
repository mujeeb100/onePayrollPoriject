import React from 'react'

function Iframe() {
  return (
    <div>
      <iframe
        frameBorder="0"
        height="1000px"
        src="https://hk.mp.dev.onepayroll.net/reporting-designer/9cd7e909-ba68-4fa1-b205-117891f51b64"
        title="Web Designer Active Report"
        width="100%"
      />
    </div>
  )
}

export default Iframe
