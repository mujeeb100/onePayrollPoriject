import {
  Box,
} from '@mui/material'
import { useCustomReportDesignerDeleteMutation, useGetAllCustomReportDesignerQuery } from 'api/report'
import { entityCustomReportDesignerColumn } from 'components/atoms/table/OPRTableConstant'
import { OPRInnerListLayout } from 'components/organism/OPRInnerLayoutList'
import { t } from 'i18next'
import React, { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { routes } from 'routes/routes'
import {
  generateFilterUrl, setRouteValues,
} from 'utils'

import ReportDesignerAlert from './ReportDesignerAlert'
import ReportDesignerModal from './ReportDesignerModal'

function DesignerReportList() {
  const navigate: any = useNavigate()
  const [isReportDesignerAlertOpen, setIsReportDesignerAlertOpen]:any = useState(false)
  const [isManageReportDesignerAlertOpen, setIsReportDesignerAlertAlertOpen]:any = useState(false)
  const [selelctedDelete, setSelelctedDelete]:any = useState({
    data: {},
    isDelete: false,
    name: '',
  })
  const [filterData, setFilterData]:any = useState({
    pageNumber: 1,
    pageSize: 20,
    totalItems: 0,
    orderByAsc: true,
    sortBy: '',
    SearchText: '',
    customOnly: true,
  })
  const {
    data: allPosts,
    isLoading: isLoadingAllPosts,
    isSuccess: isSuccessAllPosts,
    isError: isErrorAllPosts,
    error: errorAllPosts,
    refetch: refetchAllPosts,
  } = useGetAllCustomReportDesignerQuery(generateFilterUrl(filterData))

  const [deleteCustomReportDesignerById,
    {
      data: deleteCustomReportDesignerResponse,
      error: deleteCustomReportDesignerError,
      isLoading: deleteCustomReportDesignerLoading,
      isSuccess: deleteCustomReportDesignerSuccess,
      isError: deleteCustomReportDesignerIsError,
    }] = useCustomReportDesignerDeleteMutation()

  //  payCyclemaster logs slice

  const sorting = (
    event: React.MouseEvent<unknown>,
    property: keyof any,
  ) => {
    const isAsc = filterData.sortBy === property && filterData.orderByAsc === true
    setFilterData({ ...filterData, orderByAsc: !isAsc, sortBy: property })
  }

  useEffect(() => {
    setFilterData({ ...filterData, totalItems: allPosts?.totalItems ? allPosts?.totalItems : 0 })
  }, [allPosts?.pageNumber, filterData.sortBy, filterData.orderByAsc, allPosts?.totalItems])

  const onSearch = (e: any, data: any) => {
    setFilterData({ ...filterData, ...data })
  }
  const handlePagination = (pageNumber: number, pageSize: number) => {
    setFilterData({ ...filterData, pageNumber })
  }

  const viewAcoount = (data: any, type:string) => {
    if (type === 'edit cost center') {
      navigate(
        setRouteValues(`${routes.editReportDesignerCustomReport}`, {
          id: data.id,
        }),
      )
    } else if (type === 'delete custom report') {
      // deleteCustomReportDesignerById(`Id=${data.id}`)
      setSelelctedDelete({ data, isDelete: true, name: data.reportCode })
    } else {
      navigate(
        setRouteValues(`${routes.viewReportDesignerCustomReport}`, {
          id: data.id,
        }),
      )
    }
  }
  const handleView = (data: any) => {
    navigate(
      setRouteValues(`${routes.viewReportDesignerCustomReport}`, {
        id: data.id,
        view: true,
      }),
    )
  }
  // handle Delete
  const handleDelete = (data:any) => {
    deleteCustomReportDesignerById(`Id=${data.id}`)
  }

  return (
    <>

      <ReportDesignerModal open={isManageReportDesignerAlertOpen} onClose={() => setIsReportDesignerAlertAlertOpen(false)} />
      <ReportDesignerAlert isOpen={isReportDesignerAlertOpen} onClose={() => setIsReportDesignerAlertOpen(false)} />
      <Box sx={{ display: 'flex' }}>
        <OPRInnerListLayout
          isManageReport
          Search={decodeURIComponent(filterData.SearchText)}
          addHandleClick={() => setIsReportDesignerAlertOpen(true)}
          addManageReport={() => setIsReportDesignerAlertAlertOpen(true)}
          columns={entityCustomReportDesignerColumn(viewAcoount)}
          dataList={JSON.parse(JSON.stringify(allPosts?.records || []))}
          deleteCallBack={handleDelete}
          error={errorAllPosts || deleteCustomReportDesignerError}
          filterData={filterData}
          handlePagination={handlePagination}
          handleSearch={onSearch}
          isError={isErrorAllPosts || deleteCustomReportDesignerIsError}
          isExport={false}
          loading={isLoadingAllPosts || deleteCustomReportDesignerLoading}
          rowClickHandler={handleView}
          // rowNumber={0}
          selelctedUser={selelctedDelete}
          setSelelctedUser={setSelelctedDelete}
          sortHandleClick={sorting}
          success={deleteCustomReportDesignerSuccess}
          title={t('Custom reports')}
        />
      </Box>
    </>
  )
}

export default DesignerReportList
