// ReportDialog.tsx

import { Box } from '@mui/material'
import { RighCaretBlue } from 'assets/svg-images/SvgComponents'
import OPRButton from 'components/atoms/button/OPRButton'
import OPRLabel from 'components/atoms/label/OPRLabel'
import { CustomDialog } from 'components/atoms/modal/OPRModal'
import { useNavigate } from 'react-router-dom'

// import saveAs from '../../assets/images/saveAs.png'
import saveAs from '../../../assets/images/saveAs.png'

interface ConfirmationModalProps {
  open: boolean;
  onClose: () => void;
}

function ReportDialog({ open, onClose }: ConfirmationModalProps) {
  const navigate = useNavigate()

  const handleBackClick = () => {
    onClose() // Navigate back to the ReportDesignerModal
  }

  const handleProceedClick = () => {
    onClose()
    navigate('/iframe') // Navigate to the /iframe page
    // Close the modal or perform any other necessary actions
  }

  const handleSkipClick = () => {
    onClose() // Close the modal
  }

  return (
    <Box style={{ width: '50%' }}>
      <CustomDialog className="custom-report-change" isOpen={open} type="loader">
        <Box style={{ display: 'flex' }}>
          <Box className="custom-dialog-content">
            <Box className="image-container">
              <img alt="Logo" className="custom-image" src={saveAs} />
            </Box>

            <Box className="text-container">
              <Box className="text-data">
                <OPRLabel CustomStyles={{ marginBottom: '10px' }} variant="h4">Report designer</OPRLabel>
                <OPRLabel CustomStyles={{ marginBottom: '10px' }} variant="h6">How to use save report</OPRLabel>
                <OPRLabel variant="body2">To save the report, please follow these instructions:</OPRLabel>
                <ul className="ul-data">
                  <li>
                    Click on the
                    {' '}
                    <b>Save</b>
                    {' '}
                    dropdown menu next to Preview and choose
                    {' '}
                    <b>Save as.</b>
                  </li>
                  <li>
                    Input the report name, preferably the same as when adding a new custom report earlier, and click
                    {' '}
                    <b>Save Report.</b>
                  </li>
                </ul>
              </Box>
              <Box
                className="button-container"
                sx={{
                  display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: 5,
                }}
              >
                <OPRButton
                  color="primary"
                  variant="text"
                  onClick={handleSkipClick}
                >
                  Skip
                </OPRButton>
                <OPRButton
                  style={{ marginLeft: 'auto' }}
                  variant="text"
                  onClick={handleBackClick}
                >
                  <RighCaretBlue />
                  Back
                </OPRButton>
                <OPRButton
                  color="primary"
                  variant="contained"
                  onClick={handleProceedClick}
                >
                  Proceed
                </OPRButton>
              </Box>
            </Box>
          </Box>
        </Box>
      </CustomDialog>
    </Box>
  )
}

export default ReportDialog
