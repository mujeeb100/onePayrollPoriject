import { Box, Typography } from '@mui/material'
import { useOktaAuth } from '@okta/okta-react'
import { useGetAllUserRoleEntityQuery, useGetAllUserRolePermissionQuery } from 'api/identityServices'
import OPRLayout from 'components/atoms/layout/OPRLayout'
import CustomLoader from 'components/atoms/loader/OPRLoader'
import i18nConfig from 'i18n'
import { t } from 'i18next'
import { useEffect, useState } from 'react'
import { useDispatch } from 'react-redux'
import { useNavigate } from 'react-router-dom'
import Routes from 'routes'
import { routesWithComponents } from 'routes/navigation'
import {
  setPermissions,
} from 'slices/permissionSlice'
import { generateFilterUrl } from 'utils'

import { CustomDialog } from '../../components/atoms/modal/OPRModal'
import { EntitySelectModal } from '../../components/organism/OPREntityModal'
import useIdleTimeout from '../../hooks/useIdleTimeout'
import { useAPI } from '../../services/apiContext'

const IDLE_TIME = (Number(process.env.REACT_APP_AUTO_LOGOUT_TIMER)) * 2 ?? 1800
// const IDLE_TIME = 60

function LandingPage() {
  const context = useAPI()
  const navigate = useNavigate()
  const [isEntity, setIsEntity] = useState(true)
  const [isLoggedin, setisLoggedin] = useState(true)
  const [openModal, setOpenModal] = useState(false)
  const [openEntityModal, setOpenEntityModal] = useState(false)
  const [remaining, setRemaining] = useState<number>(59)
  const seconds = remaining % 60
  const minutes = Math.floor(remaining / 60)
  const handleLogout = () => context?.handleLogout()
  const handleIdle = () => {
    setOpenModal(true)
  }
  const [filterData, setFilterData]:any = useState({
    pageNumber: 1,
    pageSize: 20,
    totalItems: 0,
    orderByAsc: true,
    sortBy: '',
    SearchText: '',
  })
  const { oktaAuth, authState } = useOktaAuth()
  const dispatch = useDispatch()

  const {
    data: getUserRolePermissionResponse,
    error: getUserRolePermissionError,
    isLoading: getUserRolePermissionLoading,
    isSuccess: getUserRolePermissionSuccess,
    isError: getUserRolePermissionIsError,
  } = useGetAllUserRolePermissionQuery(generateFilterUrl(filterData), { skip: isEntity })

  const {
    data: allPosts,
    isLoading: isLoadingAllPosts,
    isSuccess: isSuccessAllPosts,
    isError: isErrorAllPosts,
    error: errorAllPosts,
    refetch: refetchAllPosts,
  } = useGetAllUserRoleEntityQuery(generateFilterUrl(filterData))

  useEffect(() => {
    if (allPosts?.length > 0) {
      if (context?.entity === null) {
        setOpenEntityModal(true)
      }
    } else if (allPosts?.length === 0) {
      navigate(
        '/login',
        {
          state: {
            allPosts,
          },
        },
      )
    }
  }, [isSuccessAllPosts])

  const handleListItemClick = (e:any) => {
    setOpenEntityModal(false)
    context.handleEntity(e)
  }

  const { idleTimer } = useIdleTimeout({
    onIdle: handleIdle,
    idleTime: IDLE_TIME,
  })
  const stay = () => {
    setRemaining(59)
    setOpenModal(false)
    idleTimer.reset()
  }

  const logout = () => {
    handleLogout()
    setOpenModal(false)
  }

  useEffect(() => {
    const timeout = setInterval(() => {
      if (openModal) {
        setRemaining(remaining - 1)
      }
    }, 1000)
    if (remaining === 0) {
      context?.handleLogout()
    }
    return () => {
      clearInterval(timeout)
    }
  }, [remaining, openModal])

  useEffect(() => {
    dispatch(setPermissions(getUserRolePermissionResponse?.permissionList))
    setIsEntity(true)
  }, [getUserRolePermissionSuccess])

  useEffect(() => {
    if (context?.entity !== null && context?.userInfo?.email) {
      setIsEntity(false)
    }
  }, [context?.entity, context?.userInfo?.email])

  useEffect(() => {
    if (authState !== null && !authState?.isAuthenticated) {
      navigate('/login')
    }
  }, [authState])

  return (
    <>
      <CustomDialog
        CustomStyles={{ borderRadius: '16px' }}
        isOpen={getUserRolePermissionLoading}
        type="loader"
      >
        <CustomLoader text="Processing request" />
      </CustomDialog>
      <EntitySelectModal isLoggedin={isLoggedin} isOpen={openEntityModal} onClick={(e) => handleListItemClick(e)} />
      <CustomDialog
        isResume
        CustomStyles={{ borderRadius: '16px' }}
        handleClose={logout}
        handleResume={stay}
        isOpen={openModal}
        title={t('user_idle_title')}
      >
        <Box sx={{ display: 'flex', gap: '10px', flexDirection: 'column' }}>
          <Typography variant="body2">
            {t('user_idle_msg')}
          </Typography>
          <Typography variant="body2">
            {t('user_idle_timeout_msg')}
            :
            {' '}
            {minutes}
            :
            {seconds}
          </Typography>
        </Box>
      </CustomDialog>
      <OPRLayout
        sx={{
          flexGrow: 1,
          ml: {
            xs: 2,
            sm: 41,
          },
          mt: {
            lg: 15,
            xl: 15,
            xs: 23,
            sm: 15,
          },
          mb: 7,
          mr: 8,
        }}
      >
        <Routes routes={routesWithComponents()} />
        {/* Other components or content can be added here */}
      </OPRLayout>
    </>
  )
}
function getDefaultLang(lang: string) {
  i18nConfig(lang)
}

export default LandingPage
