import styled from '@emotion/styled'
import { Box, Container, Grid } from '@mui/material'
import OPRPagination from 'components/atoms/pagination/OPRPagination'
import OPRResponsiveGrid from 'components/molecules/OPRResponsiveGrid'
import OPRSearchIcon from 'components/molecules/OPRSearchIcon'

const TableHeader = styled(Grid)<any>(({ theme, CustomStyles }: any) => ({
  ...{
    ...CustomStyles,
  },
}))

const filterForm = () => (
  <TableHeader
    item
    md={2}
    sm={1}
    sx={{
      alignItems: 'center',
      display: 'flex',
      flexDirection: 'row',
      gap: 2,
    }}
    xs={1}
  />
)

export function OPRCustomSerachFilter({
  handleSearch,
  Search = {},
  filterLayout = filterForm,
  filterData = {},
  handlePagination,
}: any) {
  const { totalItems = 0, pageSize = 10, pageNumber = 1 } = filterData

  return (
    <Container>
      <OPRResponsiveGrid>
        <TableHeader
          item
          md={3}
          sm={1}
          sx={{
            alignItems: 'center',
            display: 'flex',
            flexDirection: 'row',
            gap: '5px',
          }}
          xs={1}
        >
          {filterLayout()}
        </TableHeader>

        <Grid
          item
          md={1}
          sm={1}
          sx={{
            display: 'flex',
            justifyContent: 'end',
            alignItems: 'center',
          }}
        >
          <Box
            sx={{
              width: '280px',
            }}
          >
            <OPRSearchIcon
              placeholder="Search"
              value={Search}
              onChange={handleSearch}
            />
          </Box>
        </Grid>
      </OPRResponsiveGrid>

      {totalItems > 20 && (
        <Box sx={{ display: 'flex', justifyContent: 'center', mt: 2 }}>
          <OPRPagination
            limit={pageSize}
            page={pageNumber}
            setPage={handlePagination}
            total={totalItems}
          />
        </Box>
      )}
    </Container>
  )
}
