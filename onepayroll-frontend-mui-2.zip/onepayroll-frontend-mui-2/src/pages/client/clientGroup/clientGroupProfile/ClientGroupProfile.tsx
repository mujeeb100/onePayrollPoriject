import {
  Box, FormControlLabel, Radio, RadioGroup,
} from '@mui/material'
import Tab from '@mui/material/Tab'
import Tabs from '@mui/material/Tabs'
import {
  useLazyGetClientGroupProfileByIdQuery,
} from 'api/clientServices'
import OPRButton from 'components/atoms/button/OPRButton'
import OPRLabel from 'components/atoms/label/OPRLabel'
import { CustomDialog } from 'components/atoms/modal/OPRModal'
import { OPRInnerFormLayout } from 'components/organism/OPRInnerFormLayout'
import { useEditable } from 'hooks/useEdit'
import { t } from 'i18next'
import * as React from 'react'
import { useEffect } from 'react'
import { useLocation, useNavigate } from 'react-router-dom'
import { routes } from 'routes/routes'
import { getParamsValue, setRouteValues } from 'utils'

import ClientGroupEnitiesList from '../clientGroupEntities/ClientGroupEntitiesList'
import ClientGroupProfileForm from './ClientGroupProfileForm'

interface TabPanelProps {
  children?: React.ReactNode;
  index: number;
  value: number;
}

function CustomTabPanel(props: TabPanelProps) {
  const {
    children, value, index, ...other
  } = props

  return (
    <div
      aria-labelledby={`simple-tab-${index}`}
      hidden={value !== index}
      id={`simple-tabpanel-${index}`}
      role="tabpanel"
      {...other}
    >
      {value === index && (
        <Box sx={{ pt: 5 }}>
          {children}
        </Box>
      )}
    </div>
  )
}
function a11yProps(index: number) {
  return {
    id: `simple-tab-${index}`,
    'aria-controls': `simple-tabpanel-${index}`,
  }
}
interface MessageProps {
    text?: string;
    important?: boolean;
  }

export default function ClientGroupProfile() {
  const myRef:any = React.useRef()
  const location: any = useLocation()
  const navigate = useNavigate()
  const {
    isEditable,
    setEditable,
  } = useEditable()
  const [openMadal, setModal]:any = React.useState(false)
  const [userRoleOperation, setRoleOperation]:any = React.useState('')
  const { id, viewUrl } = getParamsValue(location, routes.createClientGroupProfile)
  const [value, setValue] = React.useState(0)
  const handleTabChange = (event: React.SyntheticEvent, newValue: number) => {
    setValue(newValue)
  }
  useEffect(() => {
    setEditable(viewUrl)
  }, [])
  const [updateClientGroupProfileById, {
    data: updatedClientGroupProfileByIdResponse,
    error: updatedClientGroupProfileByIdError,
    isLoading: updatedClientGroupProfileByIdLoading,
    isSuccess: updatedClientGroupProfileByIdSuccess,
    isError: updatedClientGroupProfileByIdIsError,
  }] = useLazyGetClientGroupProfileByIdQuery()

  React.useEffect(() => {
    if (id) {
      updateClientGroupProfileById(id)
      // setEditable(viewUrl)
    }
  }, [])

  return (
    <Box sx={{ display: 'flex', flexDirection: 'column' }}>

      <CustomDialog
        CustomStyles={{ borderRadius: '16px' }}
        isOpen={openMadal}
        type="loader"
      >
        <OPRLabel variant="h4">Edit client group</OPRLabel>
        <RadioGroup
          row
          aria-labelledby="demo-row-radio-buttons-group-label"
          name="row-radio-buttons-group"
          sx={{ display: 'flex', flexDirection: 'column' }}
          value={userRoleOperation}
          onChange={(e) => {
            setRoleOperation(e.target.value)
          }}
        >
          <FormControlLabel control={<Radio />} label="Edit client group information" value="Edit Entity" />
          <FormControlLabel control={<Radio />} label="Add entity" value="Add Entity" />
          {/* <FormControlLabel control={<Radio />} label="Remove entity" value="Delete Entity" /> */}
        </RadioGroup>
        <Box sx={{
          display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: 5,
        }}
        >
          <OPRButton
            color="info"
            variant="text"
            onClick={() => {
              setModal(false)
            }}
          >
            Cancel
          </OPRButton>
          <OPRButton
            color="info"
            variant="text"
            onClick={() => {
              if (userRoleOperation === 'Edit Entity') {
                navigate(
                  setRouteValues(`${routes.editClientGroupProfile}`, {
                    id,
                  }),
                )
              } else {
                navigate(
                  setRouteValues(`${routes.createClientGroupEntities}`, {
                    id,
                    view: false,
                  }),
                )
              }
            }}
          >
            Confirm
          </OPRButton>
        </Box>
      </CustomDialog>
      <OPRInnerFormLayout
        isHandleContinueClick
        isStepper
        customTitle="Client group"
        error={false}
        handleBack={() => setEditable(false)}
        handleCancelClick={() => navigate(-1)}
        handleContinueClick={(e:any) => {
          myRef.current.handleSumbmit(e)
        }}
        handleUserCreate={
          () => {
            // console.log('handleUserCreate')
            setModal(true)
          }
        }
        isBackButton={isEditable}
        isLoading={false}
        pageType="detailsPage"
        subtitle={isEditable ? t('please_check_the_user role_details_below') : t('form_structure_title_des')}
        title={id ? (updatedClientGroupProfileByIdResponse?.data.clientGroupName) : t('Client Group')}
      >
        <Box>
          {viewUrl && (
            <Box sx={{ borderBottom: 1, borderColor: 'divider' }}>
              <Tabs aria-label="basic tabs example" value={value} onChange={handleTabChange}>
                <Tab label="Overview" {...a11yProps(0)} />
                <Tab label="Entities" {...a11yProps(1)} />
                <Tab label="Users" {...a11yProps(2)} />
              </Tabs>
            </Box>
          )}
          <CustomTabPanel index={0} value={value}>
            {isEditable ? '' : <Box sx={{ marginTop: -5 }} />}

            <ClientGroupProfileForm
              ref={myRef}
              isEditable={isEditable}
              profileId={id}
              setEditable={setEditable}
            />

          </CustomTabPanel>
          <CustomTabPanel index={1} value={value}>
            {isEditable ? '' : <Box sx={{ marginTop: -11 }} />}
            <ClientGroupEnitiesList ProfileId={id} />
          </CustomTabPanel>
          <CustomTabPanel index={2} value={value}>
            {isEditable ? '' : <Box sx={{ marginTop: -11 }} />}
            <ClientGroupEnitiesList ProfileId={id} />
          </CustomTabPanel>
        </Box>
        {/* <ClientGroupEnitiesForm /> */}
      </OPRInnerFormLayout>

    </Box>
  )
}
