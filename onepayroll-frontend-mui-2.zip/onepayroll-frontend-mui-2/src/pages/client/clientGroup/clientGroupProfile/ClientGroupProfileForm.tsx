import { Grid } from '@mui/material'
import Box from '@mui/material/Box'
import { useClientGroupProfileCreateMutation, useClientGroupProfileUpdateMutation, useLazyGetClientGroupProfileByIdQuery } from 'api/clientServices'
import OPRInputControl from 'components/molecules/OPRInputControl'
import OPRResponsiveGrid from 'components/molecules/OPRResponsiveGrid'
import OPRTextArea from 'components/molecules/OPRTextArea/OPRTextArea'
import OPRAlertControl from 'components/organism/OPRAlertControl'
import { clientGropProfilValidationSchema } from 'constants/validate'
import useForm from 'hooks/useForm'
import { t } from 'i18next'
import * as React from 'react'
import { useLocation } from 'react-router-dom'
import { routes } from 'routes/routes'
import { getParamsValue } from 'utils'

const ClientGroupProfileForm = React.forwardRef(({
  isEditable,
  setEditable,
  profileId,
}:any, ref) => {
  const {
    values,
    setValues,
    errors,
    handleChange,
    setErrors,
    handleFormSubmit,
  } = useForm(clientGropProfilValidationSchema)
  const location: any = useLocation()
  const { id, viewUrl } = getParamsValue(location, routes.createClientGroupProfile)

  const [createClientGroupProfile, {
    data: createdClientGroupProfileData,
    error: createdClientGroupProfileError,
    isLoading: createdClientGroupProfileLoading,
    isSuccess: createdClientGroupProfileSuccess,
    isError: createdClientGroupProfileIsError,
  }] = useClientGroupProfileCreateMutation()

  const [updateClientGroupProfile, {
    data: updatedDataResponse,
    error: updatedClientGroupProfileError,
    isLoading: updatedClientGroupProfileLoading,
    isSuccess: updatedClientGroupProfileSuccess,
    isError: updatedClientGroupProfileIsError,
  }] = useClientGroupProfileUpdateMutation()

  const [updateClientGroupProfileById, {
    data: updatedClientGroupProfileByIdResponse,
    error: updatedClientGroupProfileByIdError,
    isLoading: updatedClientGroupProfileByIdLoading,
    isSuccess: updatedClientGroupProfileByIdSuccess,
    isError: updatedClientGroupProfileByIdIsError,
  }] = useLazyGetClientGroupProfileByIdQuery()

  React.useEffect(() => {
    if (id) {
      updateClientGroupProfileById(id)
      // setEditable(viewUrl)
    }
  }, [])
  React.useEffect(() => {
    if (id) {
      setValues(updatedClientGroupProfileByIdResponse?.data)
    } else {
      setValues({})
      // setEditable(false)
    }
  }, [updatedClientGroupProfileByIdResponse?.data])

  const handleSubmit:any = async () => {
    if (isEditable) {
      if (id === null) {
        await createClientGroupProfile({ ...values, clientGroupCode: values?.clientGroupCode?.trim(), status: true })
      } else {
        await updateClientGroupProfile(values)
      }
    } else {
      setEditable(true)
    }
  }
  React.useImperativeHandle(ref, () => ({
    handleSumbmit(e:any) {
      handleFormSubmit(e, handleSubmit)
    },
  }))
  return (
    <Box sx={{ width: '100%' }}>
      <OPRAlertControl
        callBack={(type) => {
          // if (type === 'success') {
          //   navigate(-1)
          // }
        }}
        customMessage={`${values?.clientGroupName} has been added to Tricor Unify.`}
        error={createdClientGroupProfileError || updatedClientGroupProfileError}
        handleEditable={setEditable}
        handleSetValue={setValues}
        handleSubmit={handleSubmit}
        isError={createdClientGroupProfileError || updatedClientGroupProfileError}
        isLoading={createdClientGroupProfileLoading || updatedClientGroupProfileLoading || updatedClientGroupProfileByIdLoading}
        isSuccess={updatedClientGroupProfileSuccess || createdClientGroupProfileSuccess}
        name={values?.clientGroupName}
        previousUrl={routes.clientGroupProfile}
        title="client_group"
        type={id ? 'Update' : 'New Client has been added to Tricor Unify.'}
      />
      <OPRResponsiveGrid>
        <Grid item md={2} sm={1} xs={1}>
          <OPRInputControl
            error={errors?.clientGroupCode}
            isEditable={isEditable}
            label="client_profile_code"
            name="clientGroupCode"
            value={values?.clientGroupCode}
            onChange={handleChange}
          />
        </Grid>
        <Grid item md={2} sm={1} xs={1}>
          <OPRInputControl
            error={errors?.clientGroupName}
            isEditable={isEditable}
            label="client_profile_name"
            name="clientGroupName"
            value={values?.clientGroupName}
            onChange={handleChange}
          />
        </Grid>
        <Grid item md={4} sm={6} xs={12}>
          <OPRTextArea
            error={t(errors?.remarks)}
            isEditable={isEditable}
            label="client_profile_remarks"
            name="remarks"
            optionalText="optional"
            value={values?.remarks}
            onChange={handleChange}
          />
        </Grid>
      </OPRResponsiveGrid>
    </Box>
  )
})
export default ClientGroupProfileForm
