import {
  Box,
} from '@mui/material'
import { useClientGroupEntitiesChangeStatusMutation, useClientGroupEntitiesDeleteMutation } from 'api/clientServices'
import { useGetAllUserClientGroupQuery } from 'api/identityServices'
import { OPRActionMenuOption } from 'components/atoms/dropDown/OPRActionMenu'
import CustomLoader from 'components/atoms/loader/OPRLoader'
import { CustomDialog } from 'components/atoms/modal/OPRModal'
import { clientGroupProfileUserColumn } from 'components/atoms/table/OPRTableConstant'
import { OPRDeleteControl } from 'components/molecules/OPRAlertControl/OPRDeleteControl'
import OPRErrorAlertControl from 'components/molecules/OPRAlertControl/OPRErrorControl'
import { OPRInnerListLayout } from 'components/organism/OPRInnerLayoutList'
import React, { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import {
  generateFilterUrl,
} from 'utils'

function ClientGroupUserList({ ProfileId }:any) {
  const [selelctedUser, setSelelctedUser]:any = useState({
    data: {},
    isDelete: false,
    name: '',
  })
  const navigate: any = useNavigate()
  const [filterData, setFilterData]:any = useState({
    pageNumber: 1,
    pageSize: 20,
    totalItems: 0,
    orderByAsc: true,
    sortBy: '',
    SearchText: '',
    clientGroupId: ProfileId,
  })

  const {
    data: allPosts,
    error: createAllPostsBankAccountError,
    isLoading: isLoadingAllPosts,
    isSuccess: isSuccessAllPosts,
    isError: isErrorAllPosts,
    error: errorAllPosts,
    refetch: refreshAllPosts,
  } = useGetAllUserClientGroupQuery(generateFilterUrl(filterData))

  useEffect(() => {
    if (allPosts) {
      refreshAllPosts()
    }
  }, [filterData])

  const [changeStatusClientGroupEntities, {
    data: createdClientGroupEntitiesData,
    error: createdClientGroupEntitiesError,
    isLoading: createdClientGroupEntitiesLoading,
    isSuccess: createdClientGroupEntitiesSuccess,
    isError: createdClientGroupEntitiesIsError,
  }] = useClientGroupEntitiesChangeStatusMutation()

  const [deleteClientGroupEntitiesById,
    {
      data: deleteClientGroupEntitiesResponse,
      error: deleteClientGroupEntitiesError,
      isLoading: deleteClientGroupEntitiesLoading,
      isSuccess: deleteClientGroupEntitiesSuccess,
      isError: deleteClientGroupEntitiesIsError,
    }] = useClientGroupEntitiesDeleteMutation()

  const sorting = (
    event: React.MouseEvent<unknown>,
    property: keyof any,
  ) => {
    const isAsc = filterData.sortBy === property && filterData.orderByAsc === true
    setFilterData({ ...filterData, orderByAsc: !isAsc, sortBy: property })
  }

  useEffect(() => {
    setFilterData({ ...filterData, totalItems: allPosts?.totalItems ? allPosts?.totalItems : 0 })
  }, [allPosts?.pageNumber, filterData.sortBy, filterData.orderByAsc, allPosts?.totalItems])

  const onSearch = (e: any, data: any) => {
    setFilterData({ ...filterData, ...data })
  }

  const handlePagination = (pageNumber: number, pageSize: number) => {
    setFilterData({ ...filterData, pageNumber })
  }

  const userMenuActions = (data: any, opetion: OPRActionMenuOption) => {
    const type = opetion.value
    if (type === 'assign_entity') {
      console.log('assign_entity')
    } else if (type === 'remove_entity') {
      console.log('remove_entity')
    }
  }

  const handleView = (data: any) => {
  }

  const deleteEntities = (data:any) => {
    deleteClientGroupEntitiesById(`Id=${data.id}`)
  }
  return (
    <Box sx={{ display: 'flex', flexDirection: 'column' }}>
      <CustomDialog
        CustomStyles={{ borderRadius: '16px' }}
        isOpen={isLoadingAllPosts || createdClientGroupEntitiesLoading}
        type="loader"
      >
        <CustomLoader text="Processing request" />
      </CustomDialog>
      <OPRDeleteControl
        deleteCallBack={deleteEntities}
        selelctedUser={selelctedUser}
        setSelelctedUser={setSelelctedUser}
        title="Client Group Entities"
      />
      <OPRErrorAlertControl
        error={deleteClientGroupEntitiesError}
        header="Failed to Delete"
        isBackButton={false}
        isError={deleteClientGroupEntitiesIsError}
        isTry={false}
        name="Client Group Entities"
      />

      <OPRInnerListLayout
        columns={clientGroupProfileUserColumn(userMenuActions)}
        dataList={allPosts?.users || []}
        filterData={filterData}
        handleEdit={userMenuActions}
        handlePagination={(pageNumber: number) => {
          setFilterData({ ...filterData, pageNumber })
        }}
        handleSearch={(e: any) => {
          setFilterData({ ...filterData, SearchText: e.target.value })
        }}
        isError={isErrorAllPosts}
        isLoader={isLoadingAllPosts}
        orderBy={filterData?.orderByAsc}
        recordCount={allPosts?.totalItems || 0}
        rowClickHandler={handleView}
        rowNumber={0}
        showHeaderTitleRow={false}
        sortBy={filterData?.sortBy}
        sortHandleClick={(_: React.MouseEvent<unknown>, property: keyof any) => {
          const isAsc = filterData.sortBy === property && filterData.orderByAsc === true
          setFilterData({ ...filterData, orderByAsc: !isAsc, sortBy: property })
        }}
      />
    </Box>
  )
}

export default ClientGroupUserList
