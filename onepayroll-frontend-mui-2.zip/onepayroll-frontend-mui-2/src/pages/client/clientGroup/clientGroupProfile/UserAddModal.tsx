import { useTheme } from '@emotion/react'
import {
  Box, Checkbox, Divider,
} from '@mui/material'
import { useGetAllClientProfileEntityQuery } from 'api/clientServices'
import { useGetAllUserAdministrationQuery, useGetAllUserRoleQuery, useUserAdminEntityCreateMutation } from 'api/identityServices'
import {
  Info, LeftCaret, RighCaretBlue, TickIcon,
} from 'assets/svg-images/SvgComponents'
import OPRButton from 'components/atoms/button/OPRButton'
import OPRLabel from 'components/atoms/label/OPRLabel'
import OPREnhancedTable from 'components/atoms/table/OPREnhancedTable'
import { entitySelectColumn, uerRoleSelectColumn } from 'components/atoms/table/OPRTableConstant'
import { OPRConfirmationDialog } from 'components/molecules/OPRAlertControl/OPRConfirmationDialog'
import OPRSearchIcon from 'components/molecules/OPRSearchIcon'
import { validationSchemaPensionfundscheme } from 'constants/validate'
import useForm from 'hooks/useForm'
import { t } from 'i18next'
import React, { useEffect, useState } from 'react'
import { routes } from 'routes/routes'
import { generateFilterUrl } from 'utils'

import { CustomDialog } from '../../../../components/atoms/modal/OPRModal'
import OPRAlertControl from '../../../../components/organism/OPRAlertControl'

type UserAddModalProps = {
    onClick?: () => void;
    handleClose: () => void;
    isOpen: boolean;
    handleOpen: () => void;
    entity?: any;
  };

export function UserAddModal({
  onClick, isOpen, entity, handleClose, handleOpen,
}: UserAddModalProps) {
  const theme:any = useTheme()
  const [steps, setSteps] = useState(0)
  const [userCall, setUserCall]:any = useState(true)
  const [selectAll, setSelectAll]:any = useState(false)
  const [userRoleOperation, setRoleOperation]:any = React.useState('')
  const [checkedValue, setCheckedValue] = React.useState<any[]>([])
  const [selected, setSelected] = React.useState<readonly number[]>([])
  const [isCancel, setIsCancel] = useState(false)
  const [isOpenReponse, setOpenReponse] = useState(false)
  const [userItem, setUserItem] = React.useState({
    accountStatus:
'',
    cultureInfo:
'',
    defaultLanguage:
'',
    defaultTimeZone:
'',
    emailAddress:
'',
    entityCount:
0,
    firstName:
'',
    id:
'',
    lastName:
'',
    mobileNumber:
'',
    officeNumber:
'',
    remarks:
'',
    userType:
'',
    username:
'',
  })
  const [filterData, setFilterData]:any = useState({
    pageNumber: 1,
    pageSize: 200,
    totalItems: 0,
    orderByAsc: true,
    sortBy: '',
    SearchText: '',
  })
  const [filterDataEntity, setfilterEntity]:any = useState({
    pageNumber: 1,
    pageSize: 200,
    totalItems: 0,
    orderByAsc: true,
    sortBy: '',
    SearchText: '',
  })
  useEffect(() => {
    if (!isOpen) {
      setFilterData({ ...filterData, SearchText: '' })
    }
  })

  // useEffect(() => {
  //   setUserCall(true)
  // }, [])
  // const onSearch = (e: any) => {
  //   setFilterData({ ...filterData, SearchText: e.target.value })
  // }
  const onSearchEntity = (e: any) => {
    setfilterEntity({ ...filterData, SearchText: e.target.value })
  }
  const {
    values,
    setValues,
    errors,
    handleChange,
    setErrors,
    handleFormSubmit,
    handleOnChange,
  } = useForm(validationSchemaPensionfundscheme)
  const {
    data: allUser,
    isLoading: isLoadingAllUser,
    isSuccess: isSuccessAllUser,
    isError: isErrorAllUser,
    error: errorAllUser,
    refetch: refetchAllUser,
  } = useGetAllUserAdministrationQuery(generateFilterUrl(filterData), { skip: userCall })
  const {
    data: allEntity,
    isLoading: isLoadingAllEntity,
    isSuccess: isSuccessAllEntity,
    isError: isErrorAllEntity,
    error: errorAllEntity,
    refetch: refetchAllEntity,
  } = useGetAllClientProfileEntityQuery(generateFilterUrl({ ProfileId: entity?.id }), { skip: !isOpen })
  const {
    data: userRoleData,
    isLoading: isLoadingUserRole,
    isSuccess: isSuccessUserRole,
    isError: isErrorUserRole,
    error: errorUserRole,
    refetch: refetchUserRole,
  } = useGetAllUserRoleQuery(generateFilterUrl(''), { skip: steps === 1 })
  const [createBulkUserAdminEntity, {
    data: createUserRoleData,
    error: createUserRoleError,
    isLoading: createUserRoleLoading,
    isSuccess: createUserRoleSuccess,
    isError: createUserRoleIsError,
  }] = useUserAdminEntityCreateMutation()
  const clientGroupNames = checkedValue.map((item:any) => item.clientGroupName)

  const handleSubmit = async () => {
    // handleClose()
    const entities = checkedValue.map((item) => {
      const userRoleIds = item.userRole.map((item: any) => item.id)
      const entityId = item.id
      const clientGroupId = item.clientGroupProfileId
      return { entityId, clientGroupId, userRoleIds }
    })
    await createBulkUserAdminEntity({
      userId: userItem.id,
      entities,
    })
    setSelected([])
    setCheckedValue([])
    setSteps(0)
  }
  useEffect(() => {
    if (createUserRoleSuccess) {
      setOpenReponse(createUserRoleSuccess)
    }
  }, [createUserRoleSuccess])
  const handleClick = (event: React.MouseEvent<unknown>, item: any) => {
    const selectedIndex = selected.indexOf(item.id)
    let newSelected: readonly number[] = []
    if (selectedIndex === -1) {
      newSelected = newSelected.concat(selected, item.id)
      setCheckedValue([
        ...checkedValue,
        item,
      ])
    } else if (selectedIndex === 0) {
      newSelected = newSelected.concat(selected.slice(1))
      setCheckedValue(checkedValue.filter((val) => val.id !== item.id))
    } else if (selectedIndex === selected.length - 1) {
      newSelected = newSelected.concat(selected.slice(0, -1))
      setCheckedValue(checkedValue.filter((val) => val.id !== item.id))
    } else if (selectedIndex > 0) {
      newSelected = newSelected.concat(
        selected.slice(0, selectedIndex),
        selected.slice(selectedIndex + 1),
      )
      setCheckedValue(checkedValue.filter((val) => val.id !== item.id))
    }
    setSelected(newSelected)
  }
  const onSearch = (e: any, data: any) => {
    setFilterData({ ...filterData, SearchText: e.target.value })
    setUserCall(false)
  }

  const handleUserClick = (item: any) => {
    setUserItem(item)
    // setUserEntityData({ ...filterData, SearchText: item?.firstName })
    // setIsSkip(false)
    setSteps((prev) => prev + 1)
  }
  const isSelected = (id:any) => selected.indexOf(id) !== -1
  const handleCancelClick = () => {
    handleOpen()
  }

  useEffect(() => {
    if (selectAll) {
      setSelected(JSON.parse(JSON.stringify(allEntity?.records || [])).map((obj:any) => obj.id))
    } else {
      setSelected([])
    }
    // setSelected(JSON.parse(JSON.stringify(allEntity?.records || [])).map((obj:any) => obj.id))
  }, [selectAll])

  const checkAllSelected = () => {
    const objectIds = JSON.parse(JSON.stringify(allEntity?.records || [])).map((obj:any) => obj.id)
    const allExist = objectIds.some((id:any) => !selected.includes(id))
    return !allExist
    console.log(!allExist, 'allExistallExistallExistallExist', selected, objectIds)
  }

  return (
    <Box>
      <OPRConfirmationDialog
        addAnotherButtonTitle="Add another User"
        buttonLayout="add-another"
        icon={<TickIcon />}
        infoMessage=""
        message={(
          <>
            <b>
              {' '}
              {`${userItem?.firstName} ${userItem?.lastName}`}
            </b>
            {' '}
            has been assigned to
            {' '}
            <b>
              {' '}
              {entity?.clientGroupName}
            </b>
            .
          </>
        )}
        open={isOpenReponse}
        title="User Added"
        onAddAnother={() => {
          setFilterData({ ...filterData, SearchText: '' })
          setSteps(0)
          setOpenReponse(false)
        }}
        onClose={() => {
          setOpenReponse(false)
          handleClose()
        }}
      />
      <OPRAlertControl
        isCustom
        isCustomError
        callBack={() => {
          // handleClose()
          // setValues({})
          // setSteps(0)
        }}
        customBack={() => {
          // handleOpen()
        }}
        customMessage={`${userItem?.firstName} ${userItem?.lastName} has been assigned to ${entity?.clientGroupName}`}
        customTitle="User added"
        error={createUserRoleError}
        handleSetValue={handleCancelClick}
        handleSubmit={handleSubmit}
        isError={createUserRoleError}
        isLoading={createUserRoleLoading}
        isSuccess={false}
        name={`${entity?.displayName}`}
        previousUrl={routes?.viewClientGroupProfile}
        title="User"
        type="New"
      />
      <CustomDialog
        CustomStyles={{ borderRadius: '16px' }}
        isOpen={isOpen}
        type="loader"
      >
        {(() => {
          switch (steps) {
            case 0:
              return (
                <>
                  <OPRLabel variant="h4">{t('add_user_to_client')}</OPRLabel>
                  <OPRLabel sx={{ marginTop: '15px', marginBottom: '15px' }} variant="body2">
                    {t('search_existing_user_account')}
                  </OPRLabel>
                  <Box>
                    {/* <OPRLabel CustomStyles={{ marginBottom: '15px' }} variant="body2">{t(subtitle)}</OPRLabel> */}
                    <OPRSearchIcon loading placeholder="Search for name or user id" value={filterData.SearchText} onChange={onSearch} />
                    <Divider />
                  </Box>
                  <OPREnhancedTable
                    isDuplicate
                    cols={entitySelectColumn(handleClick)}
                    data={filterData.SearchText === '' ? [] : JSON.parse(JSON.stringify(allUser?.data || []))}
                    handleClick={handleClick}
                    handleUserClick={handleUserClick}
                    isSelected={isSelected}
                    orderBy={filterData?.orderByAsc}
                    sortBy={filterData?.sortBy}
                    steps={steps}
                  />
                </>
              )
            case 1:
              return (
                <>
                  <OPRLabel variant="h4">{t('select_entity')}</OPRLabel>
                  <Box sx={{
                    display: 'flex',
                    flexDirection: 'row',
                    gap: '5px',
                    alignItems: 'center',
                    padding: '10px 10px',
                    justifyContent: 'space-between',
                  }}
                  >
                    <Box sx={{
                      display: 'flex', flexDirection: 'column', alignItems: 'flex-start',
                    }}
                    >
                      <OPRLabel CustomStyles={{ marginBottom: '15px' }} variant="body2">{t('ent_work_calendar_name')}</OPRLabel>
                      <OPRLabel CustomStyles={{ marginBottom: '15px' }} variant="body2">{`${userItem?.firstName} ${userItem?.lastName}`}</OPRLabel>
                    </Box>
                    <Box sx={{
                      display: 'flex', flexDirection: 'column', alignItems: 'flex-start',
                    }}
                    >
                      <OPRLabel CustomStyles={{ marginBottom: '15px' }} variant="body2">{t('user_id_title')}</OPRLabel>
                      <OPRLabel CustomStyles={{ marginBottom: '15px' }} variant="body2">{userItem?.emailAddress}</OPRLabel>
                    </Box>
                  </Box>
                  <OPRLabel sx={{ marginTop: '15px', marginBottom: '15px' }} variant="body2">
                    {t('select_entitties_assign_to_user')}
                  </OPRLabel>
                  <Box>
                    {/* <OPRLabel CustomStyles={{ marginBottom: '15px' }} variant="body2">{t(subtitle)}</OPRLabel> */}
                    <OPRSearchIcon placeholder="Search for existing entity" value={filterDataEntity.SearchText} onChange={onSearchEntity} />
                    <Divider />
                  </Box>
                  <label style={{ margin: '12px' }}>
                    <Checkbox
                      checked={checkAllSelected()}
                      onChange={(e) => {
                        setSelectAll(!selectAll)
                        // setSelected(JSON.parse(JSON.stringify(allEntity?.records || [])).map((obj:any) => obj.id))
                      }}
                    />
                    Select All
                  </label>
                  <OPREnhancedTable
                    isEntity
                    cols={entitySelectColumn(handleClick)}
                    data={JSON.parse(JSON.stringify(allEntity?.records || []))}
                    handleClick={handleClick}
                    isSelected={isSelected}
                    orderBy={filterData?.orderByAsc}
                    sortBy={filterData?.sortBy}
                    steps={steps}
                  />
                </>
              )
            case 2:
              return (
                <>
                  <OPRLabel variant="h4">{`  ${t('select_user_role')}`}</OPRLabel>
                  <OPRLabel sx={{ marginTop: '15px', marginBottom: '15px' }} variant="body2">
                    {`  ${t('select_user_role_for_entity')}`}
                  </OPRLabel>
                  <OPREnhancedTable
                    cols={uerRoleSelectColumn(handleClick)}
                    data={checkedValue}
                    handleClick={handleClick}
                    isSelected={isSelected}
                    listOfOptions={userRoleData.data}
                    orderBy={filterData?.orderByAsc}
                    sortBy={filterData?.sortBy}
                    steps={steps}
                  />
                </>
              )
            case 3:
              return (
                <>
                  <OPRLabel variant="h4">{t('Confirm user details')}</OPRLabel>
                  <OPRLabel sx={{ marginTop: '15px', marginBottom: '15px' }} variant="body2">
                    {`  ${t('Please check the entities to assign listed below.')}`}
                  </OPRLabel>
                  <Box sx={{
                    display: 'flex',
                    flexDirection: 'row',
                    gap: '80px',
                    alignItems: 'center',
                    padding: '10px 0',
                    // justifyContent: 'space-around',
                  }}
                  >
                    <Box sx={{
                      display: 'flex', flexDirection: 'column', alignItems: 'flex-start',
                    }}
                    >
                      <OPRLabel CustomStyles={{ marginBottom: '15px' }} variant="body2">{t('ent_work_calendar_name')}</OPRLabel>
                      <OPRLabel CustomStyles={{ marginBottom: '15px' }} variant="body2">{`${userItem?.firstName} ${userItem?.lastName}`}</OPRLabel>
                    </Box>
                    <Box sx={{
                      display: 'flex', flexDirection: 'column', alignItems: 'flex-start',
                    }}
                    >
                      <OPRLabel CustomStyles={{ marginBottom: '15px' }} variant="body2">{t('user_id_title')}</OPRLabel>
                      <OPRLabel CustomStyles={{ marginBottom: '15px' }} variant="body2">{userItem?.emailAddress}</OPRLabel>
                    </Box>
                  </Box>
                  <OPRLabel CustomStyles={{ marginLeft: '0px', marginBottom: '15px' }} variant="body2">
                    Entities
                    (
                    {checkedValue.length}
                    )
                  </OPRLabel>
                  <Divider />
                  <OPREnhancedTable
                    cols={uerRoleSelectColumn(handleClick)}
                    data={checkedValue}
                    handleClick={handleClick}
                    // isDuplicate={isDuplicate || isRemove}
                    isSelected={isSelected}
                    orderBy={filterData?.orderByAsc}
                    sortBy={filterData?.sortBy}
                    steps={steps}
                  />
                  <Box
                    className="pop-up"
                    sx={{
                      display: 'flex',
                      padding: '12px',
                      gap: '12px',
                      alignItems: 'flex-start',
                      borderRadius: '4px',
                      alignSelf: 'stretch',
                      backgroundColor: `${theme.palette.Invite.main}`,
                      marginTop: 5,
                    }}
                  >
                    <Info />
                    <OPRLabel
                      CustomStyles={{
                        backgroundColor: `${theme.palette.Invite.main}`,
                      }}
                      backgroundColor={theme.palette.Invite.main}
                      variant="body2"
                    >
                      {'These entities and user roles will be assigned to '}
                      {' '}
                      <b>{`${userItem?.firstName} ${userItem?.lastName}`}</b>
                      . This user will have access to these entities.
                    </OPRLabel>
                  </Box>
                  <Divider />
                </>
              )
            default:
              console.log('No Cases matched , Please Close')
              return null // return null when no other cases match
          }
        })()}
        <Box sx={{
          display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: 5,
        }}
        >
          <OPRButton
            color="info"
            variant="text"
            onClick={() => {
              if (steps > 0) {
                setIsCancel(true)
                handleClose()
              } else {
                handleClose()
                setSelected([])
                setCheckedValue([])
                setValues({})
                setSteps(0)
              }
            }}
          >
            Cancel
          </OPRButton>
          {steps > 0 && (
            <OPRButton
              style={{ marginLeft: 'auto' }}
              variant="text"
              onClick={() => {
                setSteps((prev) => prev - 1)
              }}
            >
              <RighCaretBlue />
              Back
            </OPRButton>
          )}
          {steps > 0 && (
            <OPRButton
              variant="contained"
              onClick={() => {
                if (steps === 1 && checkedValue.length > 0) {
                  setSteps((prev) => prev + 1)
                } else if (steps === 2) {
                  setSteps((prev) => prev + 1)
                } else if (steps === 3) {
                  handleSubmit()
                }
              }}
            >
              {steps === 3 ? 'Confirm' : 'Continue'}
              <LeftCaret />
            </OPRButton>
          )}
        </Box>
      </CustomDialog>
    </Box>
  )
}
