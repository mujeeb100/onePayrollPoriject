import {
  Box, FormControlLabel, Radio, RadioGroup,
} from '@mui/material'
import Tab from '@mui/material/Tab'
import Tabs from '@mui/material/Tabs'
import { useLazyGetClientGroupEntitiesByIdQuery } from 'api/clientServices'
import OPRButton from 'components/atoms/button/OPRButton'
import OPRLabel from 'components/atoms/label/OPRLabel'
import { CustomDialog } from 'components/atoms/modal/OPRModal'
import { OPRInnerFormLayout } from 'components/organism/OPRInnerFormLayout'
import { useEditable } from 'hooks/useEdit'
import * as React from 'react'
import { useEffect } from 'react'
import { useLocation, useNavigate } from 'react-router-dom'
import { routes } from 'routes/routes'
import { getParamsValue, setRouteValues } from 'utils'

import ClientGroupEnitiesForm from './ClientGroupEntitiesForm'

  interface TabPanelProps {
    children?: React.ReactNode;
    index: number;
    value: number;
  }

function CustomTabPanel(props: TabPanelProps) {
  const {
    children, value, index, ...other
  } = props

  return (
    <div
      aria-labelledby={`simple-tab-${index}`}
      hidden={value !== index}
      id={`simple-tabpanel-${index}`}
      role="tabpanel"
      {...other}
    >
      {value === index && (
        <Box sx={{ pt: 5 }}>
          {children}
        </Box>
      )}
    </div>
  )
}
function a11yProps(index: number) {
  return {
    id: `simple-tab-${index}`,
    'aria-controls': `simple-tabpanel-${index}`,
  }
}
  interface MessageProps {
      text?: string;
      important?: boolean;
    }

export default function ClientGroupEntities() {
  const myRef:any = React.useRef()
  const location: any = useLocation()
  const navigate = useNavigate()
  const getParamsNewValue:any = (url: any) => {
    let EntityId:any
    let ProfileId:any
    const viewUrl:any = url?.pathname?.split('/').pop() === 'view'
    const ProfileIdUrl = url?.pathname?.split('/').pop().url?.pathname?.slice(0, url?.pathname?.lastIndexOf('/'))
    if (url?.pathname?.split('/').pop() === 'create') {
      EntityId = null
      ProfileId = url.pathname?.split('/')[3]
    } else {
      const newUrl = url?.pathname?.slice(0, url?.pathname?.lastIndexOf('/'))
      EntityId = newUrl?.split('/').pop()
      ProfileId = url.pathname?.split('/')[3]
    }
    return { EntityId, ProfileId, viewUrl }
  }
  const { EntityId, ProfileId } = getParamsNewValue(location)
  const {
    isEditable,
    setEditable,
  } = useEditable()
  const [openMadal, setModal]:any = React.useState(false)
  const [userRoleOperation, setRoleOperation]:any = React.useState('')
  const { id, viewUrl } = getParamsValue(location, routes.createClientGroupProfile)
  const [value, setValue] = React.useState(0)

  const [updateClientGroupEntitiesById, {
    data: updatedClientGroupEntitiesByIdResponse,
    error: updatedClientGroupEntitiesByIdError,
    isLoading: updatedClientGroupEntitiesByIdLoading,
    isSuccess: updatedClientGroupEntitiesByIdSuccess,
    isError: updatedClientGroupEntitiesByIdIsError,
  }] = useLazyGetClientGroupEntitiesByIdQuery()
  const handleTabChange = (event: React.SyntheticEvent, newValue: number) => {
    setValue(newValue)
  }
  useEffect(() => {
    setEditable(viewUrl)
  }, [])

  useEffect(() => {
    if (EntityId) {
      updateClientGroupEntitiesById(`${ProfileId}&EntityId=${EntityId}`)
      // setEditable(viewUrl)
    }
  }, [])
  console.log(viewUrl, 'TTTTTTTTTTTTTTTTTTTTTTTTTTT')

  return (
    <Box sx={{ display: 'flex', flexDirection: 'column' }}>
      <CustomDialog
        CustomStyles={{ borderRadius: '16px' }}
        isOpen={openMadal}
        type="loader"
      >
        <OPRLabel variant="h4">Edit client group</OPRLabel>
        <RadioGroup
          row
          aria-labelledby="demo-row-radio-buttons-group-label"
          name="row-radio-buttons-group"
          sx={{ display: 'flex', flexDirection: 'column' }}
          value={userRoleOperation}
          onChange={(e) => {
            setRoleOperation(e.target.value)
          }}
        >
          <FormControlLabel control={<Radio />} label="Edit client group Entities information" value="Edit Entity" />
          {/* <FormControlLabel control={<Radio />} label="Add entity" value="Add Entity" /> */}
          {/* <FormControlLabel control={<Radio />} label="Remove entity" value="Delete Entity" /> */}
        </RadioGroup>
        <Box sx={{
          display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: 5,
        }}
        >
          <OPRButton
            color="info"
            variant="text"
            onClick={() => {
              setModal(false)
            }}
          >
            Cancel
          </OPRButton>
          <OPRButton
            color="info"
            variant="text"
            onClick={() => {
              if (userRoleOperation === 'Edit Entity') {
                navigate(
                  setRouteValues(`${routes.editClientGroupEntities}`, {
                    id: ProfileId,
                    profilId: EntityId,
                  }),
                )
              }
            }}
          >
            Confirm
          </OPRButton>
        </Box>
      </CustomDialog>
      <OPRInnerFormLayout
        isEditUser
        isHandleContinueClick
        error={false}
        handleCancelClick={() => navigate(-1)}
        handleContinueClick={(e:any) => myRef?.current?.handleOnSubmit(e)}
        handleUserCreate={
          () => {
            // console.log('handleUserCreate')
            setModal(true)
          }
        }
        isBackButton={isEditable}
        isLoading={false}
        pageType="detailsPage"
        subtitle={isEditable ? 'Please check the user details below.' : 'All field to mandatory expect those mark optional'}
        title={viewUrl ? updatedClientGroupEntitiesByIdResponse?.data?.clientGroupName : 'Add entity'}
      >
        <Box>
          {viewUrl && (
            <Box sx={{ borderBottom: 1, borderColor: 'divider' }}>
              <Tabs aria-label="basic tabs example" value={value} onChange={handleTabChange}>
                <Tab label="Overview" {...a11yProps(0)} />
                <Tab label="Users" {...a11yProps(1)} />
              </Tabs>
            </Box>
          )}
          <CustomTabPanel index={0} value={value}>
            {/* {isEditable ? '' : <Box sx={{ marginTop: -5 }} />} */}

            <ClientGroupEnitiesForm
              ref={myRef}
              id={id}
              isEditable={isEditable}
              setEditable={setEditable}
            />
          </CustomTabPanel>
          <CustomTabPanel index={1} value={value}>
            {/* {isEditable ? '' : <Box sx={{ marginTop: -11 }} />}
            <ClientGroupEnitiesList ProfileId={id} /> */}
          </CustomTabPanel>
        </Box>
      </OPRInnerFormLayout>

    </Box>
  )
}
