import { useTheme } from '@emotion/react'
import {
  Box, Divider,
  Grid,
} from '@mui/material'
import { useGetAllClientGroupEntityQuery } from 'api/globalServices'
import { useGetAllUserAdministrationQuery, useGetAllUserRoleQuery, useUserAdminEntityCreateMutation } from 'api/identityServices'
import {
  Info,
  LeftCaret, RighCaretBlue, SerachBar, TickIcon,
} from 'assets/svg-images/SvgComponents'
import OPRButton from 'components/atoms/button/OPRButton'
import OPRLabel from 'components/atoms/label/OPRLabel'
import OPRMultiSelectCheckbox from 'components/atoms/multiSelectCheckbox'
import OPREnhancedTable from 'components/atoms/table/OPREnhancedTable'
import { entitySelectColumn } from 'components/atoms/table/OPRTableConstant'
import { OPRConfirmationDialog } from 'components/molecules/OPRAlertControl/OPRConfirmationDialog'
import OPRSearchIcon from 'components/molecules/OPRSearchIcon'
import { validationSchemaPensionfundscheme } from 'constants/validate'
import useForm from 'hooks/useForm'
import { t } from 'i18next'
import React, { useEffect, useState } from 'react'
import { routes } from 'routes/routes'
import { generateFilterUrl } from 'utils'

import { CustomDialog } from '../../../../components/atoms/modal/OPRModal'
import OPRAlertControl from '../../../../components/organism/OPRAlertControl'

type UserAddModalProps = {
    onClick?: () => void;
    handleClose: () => void;
    isOpen: boolean;
    handleOpen: () => void;
    entity?: any;
  };

export function UserToEntityAddModal({
  onClick, isOpen, entity, handleClose, handleOpen,
}: UserAddModalProps) {
  const theme:any = useTheme()
  const [steps, setSteps] = useState(0)
  const [userCall, setUserCall] = useState(true)
  const [userRoleOperation, setRoleOperation]:any = React.useState('')
  const [checkedValue, setCheckedValue] = React.useState<any[]>([])
  const [selected, setSelected] = React.useState<readonly number[]>([])
  const [selectedOptions, setSelectedOptions]:any = React.useState<any>([])
  const [isCancel, setIsCancel] = useState(false)
  const [userModal, setUserModal]:any = React.useState(false)
  const [isOpenReponse, setOpenReponse] = useState(false)
  const [loading, setLoading] = useState(false)

  const [userItem, setUserItem] = React.useState({
    accountStatus:
'',
    cultureInfo:
'',
    defaultLanguage:
'',
    defaultTimeZone:
'',
    emailAddress:
'',
    entityCount:
0,
    firstName:
'',
    id:
'',
    lastName:
'',
    mobileNumber:
'',
    officeNumber:
'',
    remarks:
'',
    userType:
'',
    username:
'',
  })
  const [filterData, setFilterData]:any = useState({
    pageNumber: 1,
    pageSize: 200,
    totalItems: 0,
    orderByAsc: true,
    sortBy: '',
    SearchText: '',
  })
  const [filterDataEntity, setfilterEntity]:any = useState({
    pageNumber: 1,
    pageSize: 200,
    totalItems: 0,
    orderByAsc: true,
    sortBy: '',
    SearchText: '',
  })
  const onSearch = (e: any, data: any) => {
    setFilterData({ ...filterData, SearchText: e.target.value })
    setUserCall(false)
    setLoading(true)
  }

  const onSearchEntity = (e: any) => {
    setfilterEntity({ ...filterDataEntity, SearchText: e.target.value })
  }
  const {
    values,
    setValues,
    errors,
    handleChange,
    setErrors,
    handleFormSubmit,
    handleOnChange,
  } = useForm(validationSchemaPensionfundscheme)
  const {
    data: allUser,
    isLoading: isLoadingAllUser,
    isSuccess: isSuccessAllUser,
    isError: isErrorAllUser,
    error: errorAllUser,
    refetch: refetchAllUser,
  } = useGetAllUserAdministrationQuery(generateFilterUrl(filterData), { skip: userCall })

  useEffect(() => {
    if (userCall) {
      setUserCall(false)
    }
  }, [userCall])
  const {
    data: allEntity,
    isLoading: isLoadingAllEntity,
    isSuccess: isSuccessAllEntity,
    isError: isErrorAllEntity,
    error: errorAllEntity,
    refetch: refetchAllEntity,
  } = useGetAllClientGroupEntityQuery(generateFilterUrl(filterDataEntity))
  const {
    data: userRoleData,
    isLoading: isLoadingUserRole,
    isSuccess: isSuccessUserRole,
    isError: isErrorUserRole,
    error: errorUserRole,
    refetch: refetchUserRole,
  } = useGetAllUserRoleQuery(generateFilterUrl(''), { skip: steps === 1 })
  const [createBulkUserAdminEntity, {
    data: createUserRoleData,
    error: createUserRoleError,
    isLoading: createUserRoleLoading,
    isSuccess: createUserRoleSuccess,
    isError: createUserRoleIsError,
  }] = useUserAdminEntityCreateMutation()
  useEffect(() => {
    if (createUserRoleSuccess) {
      setOpenReponse(createUserRoleSuccess)
    }
  }, [createUserRoleSuccess])
  useEffect(() => {
    if (!isOpen) {
      setFilterData({ ...filterData, SearchText: '' })
    }
  })
  const handleSubmit = async () => {
    // handleClose()
    const userRoles = selectedOptions.map((item:any) => item.id)
    await createBulkUserAdminEntity({
      userId: userItem?.id,
      entities: [{
        userRoleIds: userRoles,
        entityId: entity?.id,
        clientGroupId: entity?.clientGroupProfileId,
      }],
    })
    setSelected([])
    setCheckedValue([])
    setSteps(0)
  }
  const handleClick = (event: React.MouseEvent<unknown>, item: any) => {
    const selectedIndex = selected.indexOf(item.id)
    let newSelected: readonly number[] = []
    if (selectedIndex === -1) {
      newSelected = newSelected.concat(selected, item.id)
      setCheckedValue([
        ...checkedValue,
        item,
      ])
    } else if (selectedIndex === 0) {
      newSelected = newSelected.concat(selected.slice(1))
      setCheckedValue(checkedValue.filter((val) => val.id !== item.id))
    } else if (selectedIndex === selected.length - 1) {
      newSelected = newSelected.concat(selected.slice(0, -1))
      setCheckedValue(checkedValue.filter((val) => val.id !== item.id))
    } else if (selectedIndex > 0) {
      newSelected = newSelected.concat(
        selected.slice(0, selectedIndex),
        selected.slice(selectedIndex + 1),
      )
      setCheckedValue(checkedValue.filter((val) => val.id !== item.id))
    }
    setSelected(newSelected)
  }
  const handleUserClick = (item: any) => {
    setUserItem(item)
    // setUserEntityData({ ...filterData, SearchText: item?.firstName })
    // setIsSkip(false)
    setSteps((prev) => prev + 1)
  }
  const isSelected = (id:any) => selected.indexOf(id) !== -1
  const renderValue = (selected: any[]) => {
    if (selected.length === 0) {
      return (
        <span>
          <Box sx={{
            display: 'flex', flexDirection: 'row', gap: '5px', alignItems: 'center', padding: '0 5px',
          }}
          >
            <SerachBar />
            <OPRLabel label="Select" variant="body2" />
          </Box>
        </span>
      )
    }
    return <span>{selected[0].roleName}</span>
  }

  const handleCancelClick = () => {
    handleOpen()
    // setValues({})
  }
  return (
    <Box>
      <OPRConfirmationDialog
        addAnotherButtonTitle="Add another User"
        buttonLayout="add-another"
        icon={<TickIcon />}
        infoMessage=""
        message={(
          <>
            <b>
              {' '}
              {`${userItem?.firstName} ${userItem?.lastName}`}
            </b>
            {' '}
            has been assigned to
            {' '}
            <b>
              {' '}
              {entity?.entityName}
            </b>
            .
          </>
        )}
        open={isOpenReponse}
        title="User Added"
        onAddAnother={() => {
          setFilterData({ ...filterData, SearchText: '' })
          setSteps(0)
          setSelectedOptions([])
          setOpenReponse(false)
        }}
        onClose={() => {
          setOpenReponse(false)
          handleClose()
        }}
      />
      <OPRAlertControl
        isCustom
        isCustomError
        callBack={() => {
          // handleClose()
          // setValues({})
          // setSteps(0)
        }}
        customBack={() => {
          // handleOpen()
        }}
        customMessage={`${userItem?.firstName} ${userItem?.lastName} has been assigned to ${entity?.entityName}`}
        customTitle="User added"
        error={createUserRoleError}
        handleSetValue={handleCancelClick}
        handleSubmit={handleSubmit}
        isError={createUserRoleError}
        isLoading={createUserRoleLoading}
        isSuccess={false}
        name={`${entity?.displayName}`}
        previousUrl={routes?.viewClientGroupProfile}
        title="User"
        type="New"
      />
      <CustomDialog
        CustomStyles={{ borderRadius: '16px' }}
        isOpen={isOpen}
        type="loader"
      >
        {(() => {
          switch (steps) {
            case 0:
              return (
                <>
                  <OPRLabel variant="h4">{t('add_user_to_entity')}</OPRLabel>
                  <OPRLabel sx={{ marginTop: '15px', marginBottom: '15px' }} variant="body2">
                    {t('search_existing_user_account')}
                  </OPRLabel>
                  <Box>
                    {/* <OPRLabel CustomStyles={{ marginBottom: '15px' }} variant="body2">{t(subtitle)}</OPRLabel> */}
                    {/* <OPRSearchIcon loading={isLoadingAllUser} placeholder="Search for name or user id" value={filterData.SearchText} onChange={onSearch} /> */}
                    <OPRSearchIcon loading placeholder="Search for name or user id" value={filterData.SearchText} onChange={onSearch} />

                    <Divider />
                  </Box>
                  <OPREnhancedTable
                    isDuplicate
                    cols={entitySelectColumn(handleClick)}
                    data={filterData.SearchText === '' ? [] : JSON.parse(JSON.stringify(allUser?.data || []))}
                    handleClick={handleClick}
                    handleUserClick={handleUserClick}
                    isSelected={isSelected}
                    orderBy={filterData?.orderByAsc}
                    sortBy={filterData?.sortBy}
                    steps={steps}
                  />
                </>
              )
            case 1:
              return (
                <>
                  <OPRLabel variant="h4">{t('Select user role')}</OPRLabel>
                  <Box sx={{
                    display: 'flex',
                    flexDirection: 'row',
                    gap: '5px',
                    alignItems: 'center',
                    padding: '10px 10px',
                    justifyContent: 'space-between',
                  }}
                  >
                    <Box sx={{
                      display: 'flex', flexDirection: 'column', alignItems: 'flex-start',
                    }}
                    >
                      <OPRLabel CustomStyles={{ marginBottom: '15px' }} variant="body2">{t('ent_work_calendar_name')}</OPRLabel>
                      <OPRLabel CustomStyles={{ marginBottom: '15px' }} variant="body2">{`${userItem?.firstName} ${userItem?.lastName}`}</OPRLabel>
                    </Box>
                    <Box sx={{
                      display: 'flex', flexDirection: 'column', alignItems: 'flex-start',
                    }}
                    >
                      <OPRLabel CustomStyles={{ marginBottom: '15px' }} variant="body2">{t('user_id_title')}</OPRLabel>
                      <OPRLabel CustomStyles={{ marginBottom: '15px' }} variant="body2">{userItem?.emailAddress}</OPRLabel>
                    </Box>
                  </Box>
                  <Box sx={{
                    display: 'flex',
                    flexDirection: 'column',
                    gap: '3px',
                    alignItems: 'flex-start',
                    padding: '10px 10px',
                  }}
                  >
                    <OPRLabel CustomStyles={{ marginBottom: '15px' }} variant="body2">{t('Entity')}</OPRLabel>
                    <OPRLabel CustomStyles={{ marginBottom: '15px' }} variant="body2">{entity?.entityName}</OPRLabel>
                  </Box>
                  <Box sx={{
                    display: 'flex',
                    flexDirection: 'column',
                    alignItems: 'flex-start',
                    padding: '10px 10px',
                  }}
                  >
                    <OPRLabel
                      CustomStyles={{
                        display: 'flex',
                        alignItems: 'flex-start',
                        marginBottom: '8px',
                        alignSelf: 'stretch',
                      }}
                      variant="body2"
                    >
                      {t('user_role_title')}
                    </OPRLabel>
                    <OPRMultiSelectCheckbox
                      fullWidth
                      listOfOptions={userRoleData?.data}
                      renderValue={renderValue}
                      selectedOptions={selectedOptions || []}
                      setSelectedOptions={setSelectedOptions || (() => {})}
                    />
                  </Box>
                </>
              )
            case 2:
              return (
                <>
                  <OPRLabel variant="h4">{t('Confirm user details')}</OPRLabel>
                  <OPRLabel sx={{ marginTop: '15px', marginBottom: '15px' }} variant="body2">
                    {`  ${t('Please check the user details below.')}`}
                  </OPRLabel>
                  <Box sx={{ padding: '10px 10px' }}>
                    <Grid container spacing={2}>
                      <Grid item xs={6}>
                        <Box sx={{ display: 'flex', flexDirection: 'column', alignItems: 'flex-start' }}>
                          <OPRLabel CustomStyles={{ marginBottom: '15px' }} variant="body2">{t('ent_work_calendar_name')}</OPRLabel>
                          <OPRLabel CustomStyles={{ marginBottom: '15px' }} variant="body2">{`${userItem?.firstName} ${userItem?.lastName}`}</OPRLabel>
                        </Box>
                      </Grid>
                      <Grid item xs={6}>
                        <Box sx={{ display: 'flex', flexDirection: 'column', alignItems: 'flex-start' }}>
                          <OPRLabel CustomStyles={{ marginBottom: '15px' }} variant="body2">{t('user_id_title')}</OPRLabel>
                          <OPRLabel CustomStyles={{ marginBottom: '15px' }} variant="body2">{userItem?.emailAddress}</OPRLabel>
                        </Box>
                      </Grid>
                      <Grid item xs={6}>
                        <Box sx={{ display: 'flex', flexDirection: 'column', alignItems: 'flex-start' }}>
                          <OPRLabel CustomStyles={{ marginBottom: '15px' }} variant="body2">{t('Entity')}</OPRLabel>
                          <OPRLabel CustomStyles={{ marginBottom: '15px' }} variant="body2">{entity?.entityName}</OPRLabel>
                        </Box>
                      </Grid>
                      <Grid item xs={6}>
                        <Box sx={{ display: 'flex', flexDirection: 'column', alignItems: 'flex-start' }}>
                          <OPRLabel CustomStyles={{ marginBottom: '15px' }} variant="body2">{t('user_role_title')}</OPRLabel>
                          <OPRLabel CustomStyles={{ marginBottom: '15px' }} variant="body2">{selectedOptions[0].roleName}</OPRLabel>
                        </Box>
                      </Grid>
                    </Grid>
                  </Box>
                  <Divider />
                  <Box
                    className="pop-up"
                    sx={{
                      display: 'flex',
                      padding: '12px',
                      gap: '12px',
                      alignItems: 'flex-start',
                      borderRadius: '4px',
                      alignSelf: 'stretch',
                      backgroundColor: `${theme.palette.Invite.main}`,
                      marginTop: 5,
                    }}
                  >
                    <Info />
                    <OPRLabel
                      CustomStyles={{
                        backgroundColor: `${theme.palette.Invite.main}`,
                      }}
                      backgroundColor={theme.palette.Invite.main}
                      variant="body2"
                    >
                      {'These user roles will be assigned to '}
                      {' '}
                      <b>{`${userItem?.firstName} ${userItem?.lastName}`}</b>
                      . This user will have access to this entity.
                    </OPRLabel>
                  </Box>

                  {/* <OPRLabel CustomStyles={{ marginLeft: '15px', marginBottom: '15px' }} variant="body2">
                    Entities
                    (
                    {checkedValue.length}
                    )
                  </OPRLabel> */}
                </>
              )
            default:
              console.log('No Cases matched , Please Close')
              return null // return null when no other cases match
          }
        })()}
        <Box sx={{
          display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: 5,
        }}
        >
          <OPRButton
            color="info"
            variant="text"
            onClick={() => {
              if (steps > 0) {
                setIsCancel(true)
                handleClose()
              } else {
                setSelected([])
                setCheckedValue([])
                setValues({})
                setSteps(0)
                handleClose()
              }
            }}
          >
            Cancel
          </OPRButton>
          {steps > 0 && (
            <OPRButton
              style={{ marginLeft: 'auto' }}
              variant="text"
              onClick={() => {
                setSteps((prev) => prev - 1)
              }}
            >
              <RighCaretBlue />
              Back
            </OPRButton>
          )}
          {steps > 0 && (
            <OPRButton
              variant="contained"
              onClick={() => {
                if (steps === 1 && selectedOptions.length > 0) {
                  setSteps((prev) => prev + 1)
                } else if (steps === 2) {
                  handleSubmit()
                }
              }}
            >
              {steps === 2 ? 'Confirm' : 'Continue'}
              <LeftCaret />
            </OPRButton>
          )}

        </Box>
      </CustomDialog>
    </Box>
  )
}
