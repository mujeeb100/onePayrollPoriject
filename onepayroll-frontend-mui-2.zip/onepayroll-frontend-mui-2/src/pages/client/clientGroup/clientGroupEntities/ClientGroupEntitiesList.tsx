import {
  Box,
} from '@mui/material'
import {
  useClientGroupEntitiesChangeStatusMutation, useClientGroupEntitiesDeleteMutation, useGetAllClientProfileEntityQuery,
} from 'api/clientServices'
import { useGetAllCountryQuery } from 'api/globalServices'
import { OPRActionMenuOption } from 'components/atoms/dropDown/OPRActionMenu'
import MultipleSelectCheckmarks from 'components/atoms/multiSelectCheckbox'
import { clientGroupEntitiesColumn } from 'components/atoms/table/OPRTableConstant'
import { OPRInnerListLayout } from 'components/organism/OPRInnerLayoutList'
import { t } from 'i18next'
import React, { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { routes } from 'routes/routes'
import {
  generateFilterUrl, setRouteValues,
} from 'utils'

function ClientGroupEnitiesList({ ProfileId }:any) {
  const navigate: any = useNavigate()

  const [selectedOptions, setSelectedOptions]:any = useState<any>(
    {
      status: [],
      countryCode: [],
    },

  )
  const [listOfOptions, setListOfOptions]:any = useState<any>(
    {
      status: [{ roleCode: '1', roleName: 'Active' }, { roleCode: '0', roleName: 'Inactive' }],
      countryCode: [],
    },
  )

  const [filterData, setFilterData] = useState<any>({
    pageNumber: 1,
    pageSize: 20,
    totalItems: 0,
    orderByAsc: true,
    sortBy: '',
    SearchText: '',
    Status: '',
    Country: '',
    ProfileId,
  })
  const {
    data: allPosts,
    error: createAllPostsBankAccountError,
    isLoading: isLoadingAllPosts,
    isSuccess: isSuccessAllPosts,
    isError: isErrorAllPosts,
    error: errorAllPosts,
    refetch: refetchAllPosts,
  } = useGetAllClientProfileEntityQuery(generateFilterUrl(filterData))

  useEffect(() => {
    if (allPosts) {
      console.log('refetching')
      refetchAllPosts()
    }
  }, [filterData])

  const {
    data: allCountry,

  } = useGetAllCountryQuery('')

  const [changeStatusClientGroupEntities, {
    data: createdClientGroupEntitiesData,
    error: createdClientGroupEntitiesError,
    isLoading: createdClientGroupEntitiesLoading,
    isSuccess: createdClientGroupEntitiesSuccess,
    isError: createdClientGroupEntitiesIsError,
  }] = useClientGroupEntitiesChangeStatusMutation()
  // console.log(useClientGroupEntitiesChangeStatusMutation, 'useClientGroupEntitesChangeStatusMutationuseClientGroupEntitesChangeStatusMutation')

  const [deleteClientGroupEntitiesById,
    {
      data: deleteClientGroupEntitiesResponse,
      error: deleteClientGroupEntitiesError,
      isLoading: deleteClientGroupEntitiesLoading,
      isSuccess: deleteClientGroupEntitiesSuccess,
      isError: deleteClientGroupEntitiesIsError,
    }] = useClientGroupEntitiesDeleteMutation()

  useEffect(() => {
    const hardcodedStatusOptions = [
      { roleCode: '1', roleName: 'Active' },
      { roleCode: '0', roleName: 'Inactive' },
    ]

    if (allCountry) {
      const countryCodeOption = allCountry?.records?.map((item: any) => ({
        roleCode: item?.countryCode,
        // roleName: /* Set the roleName based on the item from allPosts */,
      }))

      setListOfOptions((prev: any) => ({
        ...prev,
        status: hardcodedStatusOptions,
        countryCode: countryCodeOption,
      }))
    }
  }, [])
  useEffect(() => {
    const updateFilterData = () => {
      if (selectedOptions.status?.length > 0) {
        setFilterData((prev:any) => ({ ...prev, status: selectedOptions.status.map((item:any) => item.roleCode) }))
      }

      if (selectedOptions.countryCode?.length > 0) {
        setFilterData((prev:any) => ({ ...prev, countryCode: selectedOptions.countryCode.map((item:any) => item.roleCode) }))
      }
    }

    updateFilterData()
  }, [selectedOptions])

  const renderValue = (selected: string[], filterName: string) => {
    if (selected?.length === 0) {
      return <span>{t(`${filterName}`)}</span>
    }

    return (
      <span style={{ }}>
        <span style={{ color: '' }}>
          {t(`${filterName}`)}
          {' '}
        </span>
        {/* <span
          style={{
            backgroundColor: 'white',
            color: '#00308F',
            // width: 'auto',
            // height: '24px',
            // width: '24px',
            borderRadius: '50%',
            textAlign: 'center',
            border: '1px solid',
          }}
        >
          {selected.length}
        </span> */}
      </span>
    )
  }
  const filterLayout = () => (
    <>
      <MultipleSelectCheckmarks
        listOfOptions={listOfOptions?.countryCode}
        renderValue={(selected:any) => renderValue(selected, 'Country')}
        selectedOptions={selectedOptions?.countryCode}
        setSelectedOptions={(countryCode:any) => {
          setSelectedOptions({ ...selectedOptions, countryCode })
        }}
      />
      <MultipleSelectCheckmarks
        listOfOptions={listOfOptions?.status}
        renderValue={(selected:any) => renderValue(selected, 'Status')}
        selectedOptions={selectedOptions?.status}
        setSelectedOptions={(status:any) => {
          setSelectedOptions({ ...selectedOptions, status })
        }}
      />
      {/* <OPRButton color="primary" variant="contained" onClick={handleClearFilters}> Clear</OPRButton> */}
    </>
  )
  const sorting = (
    event: React.MouseEvent<unknown>,
    property: keyof any,
  ) => {
    const isAsc = filterData.sortBy === property && filterData.orderByAsc === true
    setFilterData({ ...filterData, orderByAsc: !isAsc, sortBy: property })
    // setOrder(isAsc ? 'desc' : 'asc')
    // setOrderBy(property)
  }

  useEffect(() => {
    setFilterData({ ...filterData, totalItems: allPosts?.totalItems ? allPosts?.totalItems : 0 })
  }, [allPosts?.pageNumber, filterData.sortBy, filterData.orderByAsc, allPosts?.totalItems])

  const onSearch = (e: any, data: any) => {
    setFilterData({ ...filterData, ...data })
  }

  const handlePagination = (pageNumber: number, pageSize: number) => {
    setFilterData({ ...filterData, pageNumber })
  }
  const entityMenuActions = async (data: any, option: OPRActionMenuOption) => {
    const type = option.value
    if (type === 'edit_entity') {
      navigate(
        setRouteValues(`${routes.editClientGroupEntities}`, {
          id: data.clientGroupProfileId,
          profilId: data.id,
        }),
      )
    } else if (type === 'delete_entity') {
      deleteClientGroupEntitiesById(`Id=${data.id}`)
    }
  }

  const handleView = (data: any) => {
    navigate(
      setRouteValues(`${routes.viewClientGroupEntities}`, {
        id: data.clientGroupProfileId,
        profilId: data.id,
        view: false,
      }),
    )
  }

  return (
    <Box sx={{ display: 'flex', flexDirection: 'column' }}>
      <OPRInnerListLayout
        columns={clientGroupEntitiesColumn(entityMenuActions)}
        dataList={allPosts?.records || []}
        error={errorAllPosts}
        filterData={filterData}
        handleEdit={entityMenuActions}
        handlePagination={(pageNumber: number) => {
          setFilterData({ ...filterData, pageNumber })
        }}
        handleSearch={(e: any) => {
          setFilterData({ ...filterData, SearchText: e.target.value })
        }}
        isError={isErrorAllPosts}
        isLoader={isLoadingAllPosts || deleteClientGroupEntitiesLoading}
        newOptions={[]}
        orderBy={filterData?.orderByAsc}
        recordCount={allPosts?.totalItems || 0}
        rowClickHandler={handleView}
        rowNumber={0}
        showHeaderTitleRow={false}
        sortHandleClick={(_: React.MouseEvent<unknown>, property: keyof any) => {
          const isAsc = filterData.sortBy === property && filterData.orderByAsc === true
          setFilterData({ ...filterData, orderByAsc: !isAsc, sortBy: property })
        }}
      />

    </Box>
  )
}

export default ClientGroupEnitiesList
