import { Box } from '@mui/material'
import { useClientGroupEntitiesChangeStatusMutation, useClientGroupEntitiesDeleteMutation } from 'api/clientServices'
import { useGetAllUsersWithRoleQuery } from 'api/identityServices'
import OPRLabel from 'components/atoms/label/OPRLabel'
import CustomLoader from 'components/atoms/loader/OPRLoader'
import { CustomDialog } from 'components/atoms/modal/OPRModal'
import OPRPagination from 'components/atoms/pagination/OPRPagination'
import OPRTable from 'components/atoms/table/OPRTable'
import { clientGroupEntitiesUserColumn } from 'components/atoms/table/OPRTableConstant'
import { OPRDeleteControl } from 'components/molecules/OPRAlertControl/OPRDeleteControl'
import OPRErrorAlertControl from 'components/molecules/OPRAlertControl/OPRErrorControl'
import React, { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { routes } from 'routes/routes'
import { generateFilterUrl, setRouteValues } from 'utils'

function ClientGroupEntitiesUserList({ EntityId }:any) {
  const [selelctedUser, setSelelctedUser]:any = useState({
    data: {},
    isDelete: false,
    name: '',
  })
  const navigate: any = useNavigate()
  const [filterData, setFilterData]:any = useState({
    pageNumber: 1,
    pageSize: 20,
    totalItems: 0,
    orderByAsc: true,
    sortBy: '',
    SearchText: '',
    EntityId,
  })

  const {
    data: allEntityData,
    error: createAllPostsBankAccountErrorEntity,
    isLoading: isLoadingAllPostsEntity,
    isSuccess: isSuccessAllPostsEntity,
    isError: isErrorAllPostsEntity,
    error: errorAllPostsEntity,
  } = useGetAllUsersWithRoleQuery(generateFilterUrl(filterData))

  const [changeStatusClientGroupEntities, {
    data: createdClientGroupEntitiesData,
    error: createdClientGroupEntitiesError,
    isLoading: createdClientGroupEntitiesLoading,
    isSuccess: createdClientGroupEntitiesSuccess,
    isError: createdClientGroupEntitiesIsError,
  }] = useClientGroupEntitiesChangeStatusMutation()

  const [deleteClientGroupEntitiesById,
    {
      data: deleteClientGroupEntitiesResponse,
      error: deleteClientGroupEntitiesError,
      isLoading: deleteClientGroupEntitiesLoading,
      isSuccess: deleteClientGroupEntitiesSuccess,
      isError: deleteClientGroupEntitiesIsError,
    }] = useClientGroupEntitiesDeleteMutation()

  const sorting = (
    event: React.MouseEvent<unknown>,
    property: keyof any,
  ) => {
    const isAsc = filterData.sortBy === property && filterData.orderByAsc === true
    setFilterData({ ...filterData, orderByAsc: !isAsc, sortBy: property })
  }

  useEffect(() => {
    setFilterData({ ...filterData, totalItems: allEntityData?.totalItems ? allEntityData?.totalItems : 0 })
  }, [allEntityData?.pageNumber, filterData.sortBy, filterData.orderByAsc, allEntityData?.totalItems])

  const onSearch = (e: any, data: any) => {
    setFilterData({ ...filterData, ...data })
  }
  const handlePagination = (pageNumber: number, pageSize: number) => {
    setFilterData({ ...filterData, pageNumber })
  }
  const viewAcoount = (data: any, type:string) => {
    if (type === 'edit') {
      navigate(
        setRouteValues(`${routes.editClientGroupEntities}`, {
          id: data.clientGroupProfileId,
          profilId: data.id,
        }),
      )
    } else if (type === 'delete') {
      setSelelctedUser({ data, isDelete: true, name: data.clientGroupName })
    } else if (type === 'change status') {
      changeStatusClientGroupEntities({
        id: data.id,
        status: !data.status,
      })
    } else {
      navigate(
        setRouteValues(`${routes.viewClientGroupEntities}`, {
          id: data.clientGroupProfileId,
          profilId: data.id,
          view: false,
        }),
      )
    }
  }

  const handleView = (data: any) => {
  }

  const deleteEntities = (data:any) => {
    deleteClientGroupEntitiesById(`Id=${data.id}`)
  }

  const userData = allEntityData?.map((user:any) => ({
    userName: `${user.userName}`,
    userId: user.roleCode,
    roleName: user.roleName,
  })) || []
  return (
    <Box sx={{ display: 'flex', flexDirection: 'column' }}>
      <CustomDialog
        CustomStyles={{ borderRadius: '16px' }}
        isOpen={isLoadingAllPostsEntity || createdClientGroupEntitiesLoading}
        type="loader"
      >
        <CustomLoader text="Processing request" />
      </CustomDialog>
      <OPRDeleteControl
        deleteCallBack={deleteEntities}
        selelctedUser={selelctedUser}
        setSelelctedUser={setSelelctedUser}
        title="Client Group Entities"
      />
      <OPRErrorAlertControl
        error={deleteClientGroupEntitiesError}
        header="Failed to Delete"
        isBackButton={false}
        isError={deleteClientGroupEntitiesIsError}
        isTry={false}
        name="Client Group Entities"
      />
      <OPRLabel CustomStyles={{ marginBottom: 5 }} variant="body2">
        {JSON.parse(JSON.stringify(userData.length || []))}
        {' '}
        items
      </OPRLabel>
      <OPRTable
        cols={clientGroupEntitiesUserColumn(viewAcoount)}
        data={userData}
        handleEdit={viewAcoount}
        isLoader={isLoadingAllPostsEntity}
        newOptions={[]}
        orderBy={filterData?.orderByAsc}
        rowClickHandler={handleView}
        rowNumber={0}
        sortBy={filterData?.sortBy}
        title="title"
        onRequestSort={sorting}
      />
      {
        filterData?.totalItems < 20 ? null : (
          <Box sx={{ display: 'flex', justifyContent: 'center', mt: 2 }}>
            <OPRPagination
              limit={filterData?.pageSize}
              page={filterData?.pageNumber}
              setPage={handlePagination}
              total={filterData?.totalItems}
            />
          </Box>
        )
      }
    </Box>
  )
}

export default ClientGroupEntitiesUserList
