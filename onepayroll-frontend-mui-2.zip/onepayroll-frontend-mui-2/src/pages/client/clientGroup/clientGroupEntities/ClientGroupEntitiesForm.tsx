import { Box, Grid } from '@mui/material'
import {
  useClientGroupEntitiesCreateMutation, useClientGroupEntitiesUpdateMutation, useLazyGetClientGroupEntitiesByIdQuery,
} from 'api/clientServices'
import { useGetAllRegionQuery } from 'api/entityServices'
import { useGetAllCountryQuery } from 'api/globalServices'
import OPRInputControl from 'components/molecules/OPRInputControl'
import OPRResponsiveGrid from 'components/molecules/OPRResponsiveGrid'
import OPRSelectorControl from 'components/molecules/OPRSelectorControl/OPRSelectorControl'
import OPRAlertControl from 'components/organism/OPRAlertControl'
import { defaultPageSize } from 'constants/index'
import { clientGropEntitiesValidationSchema } from 'constants/validate'
import useForm from 'hooks/useForm'
import { forwardRef, useEffect, useImperativeHandle } from 'react'
import { useLocation } from 'react-router-dom'
import { routes } from 'routes/routes'
import { generateFilterUrl, getParamsValue } from 'utils'

interface MessageProps {
    text?: string;
    important?: boolean;
  }

const ClientGroupEnitiesForm = forwardRef(({
  isEditable,
  setEditable,
}:any, ref) => {
  const {
    values,
    setValues,
    errors,
    handleChange,
    setErrors,
    handleFormSubmit,
    handleOnChange,
  } = useForm(clientGropEntitiesValidationSchema)
  const location: any = useLocation()
  const { state } = useLocation()
  const { id, viewUrl } = getParamsValue(location)
  const getParamsNewValue:any = (url: any) => {
    let EntityId:any
    let ProfileId:any
    const viewUrl:any = url?.pathname?.split('/').pop() === 'view'
    const ProfileIdUrl = url?.pathname?.split('/').pop().url?.pathname?.slice(0, url?.pathname?.lastIndexOf('/'))
    if (url?.pathname?.split('/').pop() === 'create') {
      EntityId = null
      ProfileId = url.pathname?.split('/')[3]
    } else {
      const newUrl = url?.pathname?.slice(0, url?.pathname?.lastIndexOf('/'))
      EntityId = newUrl?.split('/').pop()
      ProfileId = url.pathname?.split('/')[3]
    }
    return { EntityId, ProfileId, viewUrl }
  }
  const { EntityId, ProfileId }:any = getParamsNewValue(location)

  const [createClientGroupEntities, {
    data: createdClientGroupEntitiesData,
    error: createdClientGroupEntitiesError,
    isLoading: createdClientGroupEntitiesLoading,
    isSuccess: createdClientGroupEntitiesSuccess,
    isError: createdClientGroupEntitiesIsError,
  }] = useClientGroupEntitiesCreateMutation()

  const {
    data: allPosts,
    error: createAllPostsBankAccountError,
    isLoading: isLoadingAllPosts,
    isSuccess: isSuccessAllPosts,
    isError: isErrorAllPosts,
    error: errorAllPosts,
  } = useGetAllCountryQuery(generateFilterUrl({ ...defaultPageSize }))

  const {
    data: allRegionPosts,
    isLoading: isLoadingAllRegionPosts,
    isSuccess: isSuccessAllRegionPosts,
    isError: isErrorAllRegionPosts,
    error: errorAllRegionPosts,
    refetch: refetchAllPosts,
  } = useGetAllRegionQuery(generateFilterUrl(''))

  const [updateClientGroupEntities, {
    data: uupdatedClientGroupDataResponse,
    error: updatedClientGroupEntitiesError,
    isLoading: updatedClientGroupEntitiesLoading,
    isSuccess: updatedClientGroupEntitiesSuccess,
    isError: updatedClientGroupEntitiesIsError,
  }] = useClientGroupEntitiesUpdateMutation()

  const [updateClientGroupEntitiesById, {
    data: updatedClientGroupEntitiesByIdResponse,
    error: updatedClientGroupEntitiesByIdError,
    isLoading: updatedClientGroupEntitiesByIdLoading,
    isSuccess: updatedClientGroupEntitiesByIdSuccess,
    isError: updatedClientGroupEntitiesByIdIsError,
  }] = useLazyGetClientGroupEntitiesByIdQuery()
  // console.log(updateClientGroupEntitiesById('55c5528c-82bf-4788-82c9-c15698a01157'), '$$$$$$$$$$$$$$$$$$$$$$$4')
  useEffect(() => {
    updateClientGroupEntitiesById(`${ProfileId}&EntityId=${EntityId}`)
  }, [])
  useEffect(() => {
    if (id && updatedClientGroupEntitiesByIdSuccess) {
      setValues({
        ...updatedClientGroupEntitiesByIdResponse?.data,
      })
      // setValues(updatedClientGroupEntitiesByIdResponse?.data)
    } else {
      setValues({
        clientGroupCode: state?.updatedClientGroupProfileByIdResponse?.data.clientGroupCode,
        clientGroupName: state?.updatedClientGroupProfileByIdResponse?.data.clientGroupName,
        entityCode: '',
        entityName: '',
        countryLocalization: 'Hong Kong',
        url: '',
        region: '',
      })
      // setEditable(false)
    }
  }, [updatedClientGroupEntitiesByIdSuccess])

  const handleSubmit:any = async () => {
    if (isEditable) {
      const data = {
        clientGroupCode:
values?.clientGroupCode,
        countryLocalization: JSON.parse(JSON.stringify(allPosts?.records || []))?.find((o:any) => o?.countryName === values?.countryLocalization).countryCode,
        entityCode:
values?.entityCode,
        entityName:
values?.entityName,
        status:
true,
        requestedBy: values?.requestedBy,
        Region: 'East',
        Url: 'www.xyz.com',
      }
      await createClientGroupEntities(data)
    } else {
      setEditable(true)
    }
  }
  useImperativeHandle(ref, () => ({
    handleOnSubmit(e:any) {
      handleFormSubmit(e, handleSubmit)
    },

  }))

  // useEffect(() => {
  //   if (createdClientGroupEntitiesSuccess) {
  //     // Reset form values after successful add operation
  //     setValues({})
  //     setErrors({})
  //   }
  // }, [createdClientGroupEntitiesSuccess])

  return (
    <Box>
      <OPRAlertControl
        callBack={(type) => {
          // if (type === 'success') {
          //   navigate(-1)
          // }
        }}
        customMessage={`${values?.entityName} has been added to ${values?.clienGroupName}`}
        error={createdClientGroupEntitiesError || updatedClientGroupEntitiesError}
        handleEditable={setEditable}
        handleSetValue={setValues}
        handleSubmit={handleSubmit}
        isError={createdClientGroupEntitiesError || updatedClientGroupEntitiesError}
        isLoading={createdClientGroupEntitiesLoading || updatedClientGroupEntitiesLoading}
        isSuccess={updatedClientGroupEntitiesSuccess || createdClientGroupEntitiesSuccess}
        name={values?.ClientGroupEntitiesName}
        previousUrl={routes.clientGroupEntities}
        title="Client Group Entitites"
        type={id ? 'Update' : 'New'}
      />
      <OPRResponsiveGrid>
        <Grid item md={2} sm={1} xs={1}>
          <OPRInputControl
            error={errors?.entityCode}
            isEditable={isEditable}
            label="Entity ID"
            name="entityCode"
            value={values?.entityCode}
            onChange={handleChange}
          />
        </Grid>
        <Grid item md={2} sm={1} xs={1}>
          <OPRInputControl
            error={errors?.entityName}
            isEditable={isEditable}
            label="Entity Name"
            name="entityName"
            value={values?.entityName}
            onChange={handleChange}
          />
        </Grid>
        {
          // JSON.parse(JSON.stringify(allPosts?.records || []))
        }
        <Grid item md={2} sm={1} xs={1}>
          {/* <OPRInputControl
            error={errors?.countryLocalization}
            isEditable={isEditable}
            label="Country Localization"
            name="countryLocalization"
            value={values?.countryLocalization}
            onChange={handleChange}
          /> */}
          <OPRSelectorControl
            isRequired
            error={errors?.countryLocalization}
            isEditable={isEditable}
            keyName="countryName"
            label="country_localization_title"
            multiple={false}
            name="countryLocalization"
            options={JSON.parse(JSON.stringify(allPosts?.records || []))}
            placeholder="Select an option"
            value={JSON.parse(JSON.stringify(allPosts?.records || []))?.find((o:any) => o?.countryName === values?.countryLocalization) || {}}
            valueKey="countryName"
            onChange={(text:any) => {
              handleOnChange('countryLocalization', text?.countryName)
            }}
          />
        </Grid>
        <Grid item md={2} sm={1} xs={1}>
          <OPRInputControl
            error={errors?.region}
            isEditable={isEditable}
            label="Requested by"
            name="requestedBy"
            optionalText="Optional"
            value={values?.requestedBy}
            onChange={handleChange}
          />
        </Grid>
      </OPRResponsiveGrid>
    </Box>
  )
})

export default ClientGroupEnitiesForm
