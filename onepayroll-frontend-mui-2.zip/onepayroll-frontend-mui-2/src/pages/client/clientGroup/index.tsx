import { Box } from '@mui/material'
import { useClientGroupProfileChangeStatusMutation, useClientGroupProfileDeleteMutation, useGetAllClientGroupProfileQuery } from 'api/clientServices'
import { OPRActionMenuOption } from 'components/atoms/dropDown/OPRActionMenu'
import OPRMultiSelectCheckbox from 'components/atoms/multiSelectCheckbox'
import { clientGroupProfileColumn } from 'components/atoms/table/OPRTableConstant'
import { OPRInnerListLayout } from 'components/organism/OPRInnerLayoutList'
import apiEndPoint from 'constants/apiEndPoint'
import { clientGroupProfileColumnMappings } from 'constants/exportColumnMappings'
import { useTranslatedColumnsForPDF } from 'hooks/useTranslatedColumnsForPDF'
import { t } from 'i18next'
import React, { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { routes } from 'routes/routes'
import {
  flattenDropDownOptions,
  generateFilterUrl,
  getAPIWithEntityUrl,
  getEnv,
  setRouteValues,
} from 'utils'

function ClientGroupProfileList() {
  const navigate: any = useNavigate()
  const [selelctedUser, setSelelctedUser]:any = useState({
    data: {},
    isDelete: false,
    name: '',
  })
  const [listOfOptions, setListOfOptions]:any = useState<any>({
    status: [
      { roleCode: '1', roleName: 'Active' },
      { roleCode: '0', roleName: 'Inactive' },
    ],
  })
  const [filterData, setFilterData]:any = useState({
    pageNumber: 1,
    pageSize: 20,
    totalItems: 0,
    orderByAsc: true,
    sortBy: '',
    SearchText: '',
    Status: [],
  })

  const transformData = () => {
    const payload: any = { ...filterData }
    payload.Status = flattenDropDownOptions(filterData.Status)
    return payload
  }

  const {
    data: allPosts,
    error: createAllPostsBankAccountError,
    isLoading: isLoadingAllPosts,
    isSuccess: isSuccessAllPosts,
    isError: isErrorAllPosts,
    error: errorAllPosts,
    refetch: refetchAllPosts,
  } = useGetAllClientGroupProfileQuery(generateFilterUrl(transformData()))

  useEffect(() => {
    if (allPosts) {
      refetchAllPosts()
    }
  }, [filterData])

  const renderValue = (selected: string[], filterName: string) => {
    if (selected.length === 0) {
      return <span>{t(`${filterName}`)}</span>
    }

    return (
      <span style={{ }}>
        <span style={{ color: '' }}>
          {t(`${filterName}`)}
        </span>
      </span>
    )
  }

  const filterLayout = () => (
    <OPRMultiSelectCheckbox
      listOfOptions={listOfOptions?.status}
      renderValue={(selected:any) => renderValue(selected, 'Status')}
      selectedOptions={filterData.Status}
      setSelectedOptions={(status:any) => {
        filterData.Status = status
        setFilterData({ ...filterData })
      }}
    />
  )

  const [deleteClientGroupProfileById,
    {
      data: deleteClientGroupProfileResponse,
      error: deleteClientGroupProfileError,
      isLoading: deleteClientGroupProfileLoading,
      isSuccess: deleteClientGroupProfileSuccess,
      isError: deleteClientGroupProfileIsError,
    }] = useClientGroupProfileDeleteMutation()

  const [changeStatusClientGroupProfile, {
    data: createdClientGroupProfileData,
    error: createdClientGroupProfileError,
    isLoading: createdClientGroupProfileLoading,
    isSuccess: createdClientGroupProfileSuccess,
    isError: createdClientGroupProfileIsError,
  }] = useClientGroupProfileChangeStatusMutation()

  const sorting = (
    event: React.MouseEvent<unknown>,
    property: keyof any,
  ) => {
    const isAsc = filterData.sortBy === property && filterData.orderByAsc === true
    setFilterData({ ...filterData, orderByAsc: !isAsc, sortBy: property })
  }

  useEffect(() => {
    setFilterData({ ...filterData, totalItems: allPosts?.totalItems ? allPosts?.totalItems : 0 })
  }, [allPosts?.pageNumber, filterData.sortBy, filterData.orderByAsc, allPosts?.totalItems])

  const onSearch = (e: any, data: any) => {
    setFilterData({ ...filterData, ...data })
  }

  const handlePagination = (pageNumber: number, pageSize: number) => {
    setFilterData({ ...filterData, pageNumber })
  }

  const viewAcoount = (data: any, option: OPRActionMenuOption) => {
    const type = option.value
    if (type === 'edit_client_group') {
      navigate(
        setRouteValues(`${routes.editClientGroupProfile}`, {
          id: data.id,
        }),
      )
    } else if (type === 'delete_client_group') {
      setSelelctedUser({ data, isDelete: true, name: data.clientGroupName })
    } else if (type === 'inactive_client_group' || type === 'active_client_group') {
      changeStatusClientGroupProfile({
        id: data.id,
        status: !data.status,
      })
    }
  }

  const handleView = (data: any) => {
    navigate(
      setRouteValues(`${routes.viewClientGroupProfile}`, {
        id: data.id,
        view: true,
      }),
    )
  }

  const handleDelete = (data:any) => {
    deleteClientGroupProfileById(`Id=${data.id}`)
  }

  return (
    <Box sx={{ display: 'flex' }}>
      <OPRInnerListLayout
        isExport
        Search={filterData.SearchText}
        addHandleClick={() => navigate(routes.createClientGroupProfile)}
        columns={clientGroupProfileColumn(viewAcoount)}
        dataList={allPosts?.records || []}
        deleteCallBack={handleDelete}
        error={deleteClientGroupProfileError}
        exportProps={{
          data: allPosts?.records,
          fileName: 'ClientGroupProfile',
          columns: useTranslatedColumnsForPDF(clientGroupProfileColumnMappings),
          pdf: {
            orientation: 'landscape',
          },
          allRecords: {
            baseURL: getEnv('REACT_APP_UP_BASE_URL', null),
            endpoint: getAPIWithEntityUrl(apiEndPoint.clientProfileList),
            filterData,
          },
        }}
        filterData={filterData}
        filterLayout={filterLayout}
        handlePagination={handlePagination}
        handleSearch={onSearch}
        isError={deleteClientGroupProfileIsError}
        isSearchText={filterData.SearchText !== ''}
        loading={isLoadingAllPosts || deleteClientGroupProfileLoading || createdClientGroupProfileLoading}
        rowClickHandler={handleView}
        rowNumber={0}
        selelctedUser={selelctedUser}
        setSelelctedUser={setSelelctedUser}
        sortHandleClick={sorting}
        success={deleteClientGroupProfileSuccess}
        title={t('client_groups_menu_title')}
      />
    </Box>
  )
}

export default ClientGroupProfileList
