import './login.css'

import SendIcon from '@mui/icons-material/Send'
import { MenuItem, Tooltip } from '@mui/material'
import Box from '@mui/material/Box'
import Button from '@mui/material/Button'
import Grid from '@mui/material/Grid'
import IconButton from '@mui/material/IconButton'
import { useTheme } from '@mui/material/styles'
import Typography from '@mui/material/Typography'
import OPRMenu from 'components/atoms/menu/OPRMenu'
import { t } from 'i18next'
import React, { useState } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { useLocation } from 'react-router-dom'
import { selectLangSelector, setActiveLang } from 'slices/select-lang-slice'
import { selectLangItemType } from 'types/select-lang-slice-type'

import { GlobeIcon, TricorUnifyLogo } from '../../assets/svg-images/SvgComponents'
import { useAPI } from '../../services/apiContext'

// import LoginButton from 'styles/components/loginButton'
export type HomeLoginProps = {
    config?: any,
    toggleTheme?: () => void
}

function Login(props: HomeLoginProps) {
  // const location: any = useLocation()
  const { state } = useLocation()
  const theme = useTheme()
  const context = useAPI()
  const dispatch = useDispatch()
  const handleLogin = () => context?.handleLogin()
  const languageList = useSelector(selectLangSelector)
  const [anchorEl, setAnchorEl] = useState<null | HTMLElement>(null)
  const handleClick = (event: React.MouseEvent<HTMLElement>) => {
    setAnchorEl(event.currentTarget)
  }
  const handleClose = (event: React.MouseEvent<HTMLElement>) => {
    setAnchorEl(null)
  }
  const selectLanguage = (event: React.MouseEvent<HTMLElement>) => {
    const selectedLocale = event.currentTarget.id
    dispatch(setActiveLang({ langLocale: selectedLocale }))
    setAnchorEl(null)
  }

  return (
    <Grid container>
      <Grid
        item
        xs={6}
      >
        <Box>
          <div className="login-container">
            <TricorUnifyLogo />
            <Typography sx={{
              fontSize: '36px',
              fontWeight: '400',
              lineHeight: '46.8px',
              color: 'white',
              marginTop: '10px',
            }}
            >
              {t('login_banner_msg')}
            </Typography>
          </div>
        </Box>
      </Grid>
      <Grid item xs={6}>
        <Box
          p={5}
          sx={{
            display: 'flex',
            flexDirection: 'row',
            justifyContent: 'space-between',
            minHeight: '30%',
            gap: '24px',
          }}
        >
          <TricorUnifyLogo />
          <Tooltip title="Switch Language">
            <IconButton
              color="primary"
              sx={{
                mx: 1, height: 'fit-content', margin: '0', padding: '0',
              }}
              onClick={handleClick}
            >
              {/* <GlobeLogo /> */}
              <GlobeIcon />
            </IconButton>
          </Tooltip>
          <OPRMenu
            keepMounted
            anchorEl={anchorEl}
            id="simple-menu"
            open={Boolean(anchorEl)}
            onClose={handleClose}
          >
            {languageList
                    && languageList?.langListItems
                    && languageList?.langListItems?.map(
                      (lang: selectLangItemType) => (
                        <MenuItem
                          key={crypto.randomUUID()}
                          id={lang.locale}
                          selected={lang.active}
                          onClick={selectLanguage}
                        >
                          {lang.title}
                        </MenuItem>
                      ),
                    )}
          </OPRMenu>
        </Box>
        <Box
          p={5}
          sx={{
            display: 'flex',
            flexDirection: 'column',
            // justifyContent: 'center',
            gap: '24px',
          }}
        >
          <Typography sx={{
            // fontFamily: 'Lato',
            fontSize: '24px',
            fontWeight: '400',
            lineHeight: '33.6px',
          }}
          >
            {t('login_welcome')}
            ,
            {t('login_pls_sign_in')}
          </Typography>
          <Button
            endIcon={<SendIcon />}
            sx={{
              background: '#0049DB', color: 'white', borderRadius: '110px', maxWidth: '126px',
            }}
            variant="contained"
            onClick={handleLogin}
          >
            {t('login_sign_in')}
          </Button>
        </Box>
      </Grid>
    </Grid>
  )
}

export default Login
