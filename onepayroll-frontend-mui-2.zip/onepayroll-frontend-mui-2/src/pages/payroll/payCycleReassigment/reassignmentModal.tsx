import { useTheme } from '@emotion/react'
import {
  Box, Grid,
} from '@mui/material'
import { usePayCycleReassignmentCreateMutation } from 'api/payRollServices'
import { LeftCaret, RighCaretBlue } from 'assets/svg-images/SvgComponents'
import OPRButton from 'components/atoms/button/OPRButton'
import OPRLabel from 'components/atoms/label/OPRLabel'
import OPREnhancedTable from 'components/atoms/table/OPREnhancedTable'
import { reassignmentConfirmModalColumn } from 'components/atoms/table/OPRTableConstant'
import OPRInputControl from 'components/molecules/OPRInputControl'
import OPRResponsiveGrid from 'components/molecules/OPRResponsiveGrid'
import { validationSchemaPensionfundscheme } from 'constants/validate'
import { useEditable } from 'hooks/useEdit'
import useForm from 'hooks/useForm'
import { t } from 'i18next'
import React, { useState } from 'react'

import { CustomDialog } from '../../../components/atoms/modal/OPRModal'
import OPRAlertControl from '../../../components/organism/OPRAlertControl'

type ReassignmentModalProps = {
    onClick: () => void;
    handleClose: () => void;
    isOpen: boolean;
    handleOpen: () => void;
    user?: any;
    existingPayCycleCode?: string;
  };

export function ReassignmentModal({
  onClick, isOpen, user, handleClose, handleOpen, existingPayCycleCode,
}: ReassignmentModalProps) {
  const theme:any = useTheme()
  const [steps, setSteps] = useState(0)
  const { isEditable, setEditable } = useEditable()
  const {
    values,
    setValues,
    errors,
    handleChange,
    setErrors,
    handleFormSubmit,
    handleOnChange,
  } = useForm(validationSchemaPensionfundscheme)
  const [createPayCycleReassignment, {
    data: createdPayCycleReassignmentData,
    error: createdPayCycleReassignmentError,
    isLoading: createdPayCycleReassignmentLoading,
    isSuccess: createdPayCycleReassignmentSuccess,
    isError: createdPayCycleReassignmentIsError,
  }] = usePayCycleReassignmentCreateMutation()
  const handleSubmit = async () => {
    const empCodes = user?.map((item:any) => item.employeeCode)
    const data = {
      existingPayCycleCode,
      newPayCycleCode: values?.newPayCycle,
      employeeCodes: empCodes,
    }
    handleClose()
    await createPayCycleReassignment(data)
  }
  const handleClick = (data:any) => {

  }
  return (
    <Box>
      <OPRAlertControl
        isCustomError
        callBack={() => {
          handleClose()
          setValues({})
          setSteps(0)
        }}
        customBack={() => {
          handleOpen()
        }}
        customMessage={`${user?.length} employees has been reassigned from default main cycle - ${existingPayCycleCode} to new pay cycle - ${values?.newPayCycle}.`}
        customTitle={t('emp_pay_cycle_reassigned')}
        error={createdPayCycleReassignmentError}
        handleSubmit={handleSubmit}
        isError={createdPayCycleReassignmentIsError}
        isLoading={createdPayCycleReassignmentLoading}
        isSuccess={createdPayCycleReassignmentSuccess}
        name={`${user?.displayName}`}
        title="employee profile"
        type="update"
      />
      <CustomDialog
        CustomStyles={{ borderRadius: '16px' }}
        isOpen={isOpen}
        type="loader"
      >
        {(() => {
          switch (steps) {
            case 0:
              return (
                <>
                  <OPRLabel sx={{ marginBottom: '15px' }} variant="h4">{t('input_new_paycycle')}</OPRLabel>
                  <OPRResponsiveGrid>
                    <Grid item md={4} sm={1} xs={1}>
                      <OPRInputControl
                        error={errors?.newPayCycle}
                        isEditable={isEditable}
                        label={t('new_pay_cycle')}
                        name="newPayCycle"
                        placeholder="YYYYMMDD"
                        value={values?.newPayCycle}
                        onChange={handleChange}
                      />
                    </Grid>
                  </OPRResponsiveGrid>
                </>
              )
            case 1:
              return (
                <>
                  <OPRLabel variant="h4">{t('confirm_change_pay_cycle')}</OPRLabel>
                  <OPRLabel sx={{ marginTop: '15px', marginBottom: '15px' }} variant="body2">
                    {t('check_change_pay_cycle_listed')}
                  </OPRLabel>
                  <OPRLabel sx={{ marginTop: '15px', marginBottom: '15px' }} variant="body2">
                    {t('ent_reports_filtering_opt_employee')}
                    {' '}
                    {user?.length}
                  </OPRLabel>
                  <OPREnhancedTable
                    isReassignment
                    cols={reassignmentConfirmModalColumn(handleClick)}
                    data={user || []}
                    isSelected={handleClick}
                    newPayCycle={values?.newPayCycle}
                  />
                </>
              )
            default:
              console.log('No Cases matched , Please Close')
              return null // return null when no other cases match
          }
        })()}
        <Box sx={{
          display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: 5,
        }}
        >
          <OPRButton
            color="info"
            variant="text"
            onClick={() => {
              handleClose()
              setSteps(0)
              setValues({})
            }}
          >
            Cancel
          </OPRButton>
          {steps > 0 && (
            <OPRButton
              style={{ marginLeft: 'auto' }}
              variant="text"
              onClick={() => {
                setSteps((prev) => prev - 1)
              }}
            >
              <RighCaretBlue />
              Back
            </OPRButton>
          )}
          <OPRButton
            variant="contained"
            onClick={() => {
              if (values?.newPayCycle && steps === 0 && !errors?.newPayCycle) {
                setSteps((prev) => prev + 1)
              } else if (steps === 1) {
                handleSubmit()
              } else {
                setSteps((prev) => prev + 1)
              }
            }}
          >
            {steps === 1 ? 'Confirm' : 'Continue'}
            <LeftCaret />
          </OPRButton>
        </Box>
      </CustomDialog>
    </Box>
  )
}
