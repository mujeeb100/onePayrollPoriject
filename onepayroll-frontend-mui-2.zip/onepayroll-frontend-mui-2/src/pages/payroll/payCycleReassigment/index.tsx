import {
  Box, Checkbox, Grid,
} from '@mui/material'
import {
  useGetAllPayCycleReassignmentQuery,
} from 'api/payRollServices'
import OPRButton from 'components/atoms/button/OPRButton'
import OPRLabel from 'components/atoms/label/OPRLabel'
import OPREnhancedTable from 'components/atoms/table/OPREnhancedTable'
import { reassignmentModalColumn } from 'components/atoms/table/OPRTableConstant'
import OPRDatePickerControl from 'components/molecules/OPRDatePickerControl/OPRDatePickerControl'
import OPRInputControl from 'components/molecules/OPRInputControl'
import OPRResponsiveGrid from 'components/molecules/OPRResponsiveGrid'
import OPRSelectorControl from 'components/molecules/OPRSelectorControl/OPRSelectorControl'
import OPRAlertControl from 'components/organism/OPRAlertControl'
import { OPRInnerFormLayout } from 'components/organism/OPRInnerFormLayout'
import { validationSchemaPayGroup } from 'constants/validate'
import { useEditable } from 'hooks/useEdit'
import useForm from 'hooks/useForm'
import { t } from 'i18next'
import { useEffect, useState } from 'react'
import { useLocation, useNavigate } from 'react-router-dom'
import { routes } from 'routes/routes'
import { generateFilterUrl, getParamsValue } from 'utils'

import { ReassignmentModal } from './reassignmentModal'

interface MessageProps {
  text?: string;
  important?: boolean;
}

export default function PayCycleReassigment() {
  const location: any = useLocation()
  const { id, viewUrl } = getParamsValue(location, routes.createPayGroup)
  const {
    isEditable,
    setEditable,
  } = useEditable()
  const [isOpen, setIsOpen] = useState(false)
  const [isSkip, setIsSkip] = useState(true)
  const [textFiled, setTextFiels] = useState('')
  const [checkedValue, setCheckedValue] = useState<any[]>([])
  const [selected, setSelected] = useState<readonly number[]>([])
  const [employeeData, setEmployeeData] = useState([])
  const [filterData, setFilterData]:any = useState({
    ChangeOption: '',
    TerminationStartDate: '',
    TerminationEndDate: '',
    HireStartDate: '',
    PayCycleCode: '',
  })

  const {
    values,
    setValues,
    errors,
    handleChange,
    setErrors,
    handleFormSubmit,
    handleOnChange,
  } = useForm(validationSchemaPayGroup)

  const navigate = useNavigate()

  const {
    data: getPayCycleReassignmentResponse,
    error: getPayCycleReassignmentError,
    isLoading: getPayCycleReassignmentLoading,
    isSuccess: getPayCycleReassignmentSuccess,
    isError: getPayCycleReassignmentIsError,
  } = useGetAllPayCycleReassignmentQuery(generateFilterUrl(filterData), { skip: isSkip })

  // const formatDate = (input:any) => {
  //   let formattedValue = ''
  //   const inputArray = input.split('')
  //   const placeholder = 'YYYY-MM-DD'.split('')

  //   // Iterate over the input and placeholder characters
  //   // eslint-disable-next-line
  //   for (let i = 0; i < placeholder.length; i++) {
  //     if (inputArray[i]) {
  //       // If input character is available, use it
  //       formattedValue += inputArray[i]
  //     } else {
  //       // Otherwise, use the placeholder character
  //       formattedValue += placeholder[i]
  //     }
  //   }

  //   return formattedValue
  // }

  // const handleTextChange = (event: React.ChangeEvent<HTMLInputElement>) => {
  //   const { value } = event.target
  //   const formattedValue = formatDate(value)
  //   setTextFiels(formattedValue)
  // }

  useEffect(() => {
    if (getPayCycleReassignmentSuccess) {
      setEmployeeData(getPayCycleReassignmentResponse?.records)
    }
  }, [getPayCycleReassignmentSuccess, getPayCycleReassignmentError, getPayCycleReassignmentResponse])

  const handleSelectAllClick = (event: React.ChangeEvent<HTMLInputElement>) => {
    if ((event.target as HTMLInputElement).checked) {
      setSelected(JSON.parse(JSON.stringify(employeeData || []))?.map((n:any) => n.employeeCode))
      setCheckedValue(JSON.parse(JSON.stringify(employeeData || [])))
      return
    }
    setSelected([])
    setCheckedValue([])
  }

  const handleClick = (event: React.MouseEvent<unknown>, item: any) => {
    const selectedIndex = selected.indexOf(item.employeeCode)
    let newSelected: readonly number[] = []
    if (selectedIndex === -1) {
      newSelected = newSelected.concat(selected, item.employeeCode)
      setCheckedValue([
        ...checkedValue,
        item,
      ])
    } else if (selectedIndex === 0) {
      newSelected = newSelected.concat(selected.slice(1))
      setCheckedValue(checkedValue.filter((val) => val.employeeCode !== item.employeeCode))
    } else if (selectedIndex === selected.length - 1) {
      newSelected = newSelected.concat(selected.slice(0, -1))
      setCheckedValue(checkedValue.filter((val) => val.employeeCode !== item.employeeCode))
    } else if (selectedIndex > 0) {
      newSelected = newSelected.concat(
        selected.slice(0, selectedIndex),
        selected.slice(selectedIndex + 1),
      )
      setCheckedValue(checkedValue.filter((val) => val.employeeCode !== item.employeeCode))
    }
    setSelected(newSelected)
  }
  const isSelected = (employeeCode:any) => selected.indexOf(employeeCode) !== -1

  const handleSearchEmp = async () => {
    function formatDate(inputDate:any) {
      const dateObject = new Date(inputDate)

      const year = dateObject.getFullYear()
      const month = String(dateObject.getMonth() + 1).padStart(2, '0') // Months are zero-indexed
      const day = String(dateObject.getDate()).padStart(2, '0')

      return `${day}/${month}/${year}`
    }
    const startDate = values?.terminationStartDate && formatDate(values.terminationStartDate)
    const endDate = values?.terminationEndDate && formatDate(values.terminationEndDate)
    const hireStartDate = values?.hireStartDate && formatDate(values.hireStartDate)
    if (values?.changeOption?.label === 'Termination') {
      setFilterData({
        ...filterData, ChangeOption: Number(values?.changeOption?.id), TerminationStartDate: startDate || '', TerminationEndDate: endDate || '', PayCycleCode: values?.defaultMainCycle,
      })
      // await getPayCycleReassignment()
      setIsSkip(false)
    } else {
      setFilterData({
        ...filterData, ChangeOption: Number(values?.changeOption?.id), HireStartDate: hireStartDate || '', PayCycleCode: values?.defaultMainCycle,
      })
      // await getPayCycleReassignment()
      setIsSkip(false)
    }
  }

  const onScreenClose: any = (item: any) => {
    setEditable(item)
    setValues({})
  }
  return (
    <Box sx={{ display: 'flex' }}>
      <ReassignmentModal
        existingPayCycleCode={values?.defaultMainCycle}
        handleClose={() => {
          // if (reason && reason === 'backdropClick') return
          setIsOpen(false)
        }}
        handleOpen={() => setIsOpen(true)}
        isOpen={isOpen}
        user={checkedValue}
        onClick={() => {
        }}
      />
      <form style={{ display: 'flex', width: '100% ' }} onSubmit={(e) => {}}>
        <OPRAlertControl
          // error={getPayCycleReassignmentError}
          handleEditable={setEditable}
          handleSetValue={setValues}
          // isError={getPayCycleReassignmentError}
          isLoading={getPayCycleReassignmentLoading}
          // isSuccess={getPayCycleReassignmentSuccess}
          name={values?.payGroupName}
          title={t('pay_cycle_reassignment')}
          type={id ? 'Update' : 'New'}
        />
        <OPRInnerFormLayout
          isBack
          handleCancelClick={() => navigate(-1)}
          handleEditable={() => {
            setEditable(true)
          }}
          isBackButton={isEditable}
          pageType="detailsPage"
          subtitle={t('start_listing_select_option')}
          title={t('pay_cycle_reassignment')}
          onScreenClose={onScreenClose}
        >
          <Box>
            <OPRResponsiveGrid>
              <Grid item md={2} sm={1} xs={1}>
                <OPRSelectorControl
                  isEditable={isEditable}
                  keyName="label"
                  label="change_option"
                  multiple={false}
                  name="changeOption"
                  options={[{ id: '1', label: 'Termination' }, { id: '0', label: 'New Hiring or Re-hiring' }]}
                  placeholder="Select an option"
                  // value={(allData?.payGroupStatuses || []).find((o:any) => o?.statusId?.id === values?.status?.id)}
                  value={[{ id: '1', label: 'Termination' }, { id: '0', label: 'New Hiring or Re-hiring' }].find((o:any) => o?.id === values?.changeOption?.id)}
                  valueKey="id"
                  onChange={(text:any) => {
                    handleOnChange('changeOption', text)
                  }}
                />
              </Grid>
              <Grid item md={2} sm={1} xs={1}>
                {/* <TextField
                  label="Date"
                  placeholder="YYYY-MM-DD"
                  value={textFiled}
                  onChange={handleTextChange}
                /> */}
                <OPRInputControl
                  error={errors?.defaultMainCycle}
                  isEditable={isEditable}
                  label={t('default_main_cycle')}
                  name="defaultMainCycle"
                  placeholder="<YYYY><MM><Code>"
                  value={values?.defaultMainCycle}
                  onChange={handleChange}
                />
              </Grid>
              {values?.changeOption?.label === 'Termination' && (
                <>
                  <Grid item md={2} sm={1} xs={1}>
                    <OPRDatePickerControl
                      error={errors?.terminationStartDate}
                      isEditable={isEditable}
                      label="termination_start_date"
                      name="terminationStartDate"
                      optionalText="Optional"
                      value={values?.terminationStartDate || null}
                      onChange={(date) => {
                        handleOnChange('terminationStartDate', date)
                      }}
                    />
                  </Grid>
                  <Grid item md={2} sm={1} xs={1}>
                    <OPRDatePickerControl
                      error={errors?.terminationEndDate}
                      isEditable={isEditable}
                      label="termination_end_date"
                      name="terminationEndDate"
                      optionalText="Optional"
                      value={values?.terminationEndDate || null}
                      onChange={(date) => {
                        handleOnChange('terminationEndDate', date)
                      }}
                    />
                  </Grid>
                </>
              )}
              {values?.changeOption?.label === 'New Hiring or Re-hiring' && (
                <Grid item md={2} sm={1} xs={1}>
                  <OPRDatePickerControl
                    error={errors?.hireStartDate}
                    isEditable={isEditable}
                    label="hire_start_date"
                    name="hireStartDate"
                    optionalText="Optional"
                    value={values?.hireStartDate || null}
                    onChange={(date) => {
                      handleOnChange('hireStartDate', date)
                    }}
                  />
                </Grid>
              )}
              <Box sx={{
                display: 'flex', justifyContent: 'flex-end', width: '100%', marginTop: '10px',
              }}
              >
                <OPRButton
                //   disabled={!(values?.terminationStartDate && values?.terminationEndDate) || !(values?.hireStartDate)}
                  variant="contained"
                  onClick={() => {
                    handleSearchEmp()
                  }}
                >
                  Search
                </OPRButton>
              </Box>
              { getPayCycleReassignmentSuccess && (
                <>
                  <hr />
                  <Box style={{
                    display: 'flex', flexDirection: 'row', width: '100%', margin: '30px 20px 20px', justifyContent: 'space-between',
                  }}
                  >
                    <OPRLabel variant="h2">{t('ent_reports_filtering_opt_employee')}</OPRLabel>
                    <Box sx={{
                      display: 'flex', flexDirection: 'row', alignItems: 'center', gap: '5px',
                    }}
                    >
                      {selected.length > 0 && (<OPRLabel label={`${checkedValue?.length} selected`} variant="body2" />)}
                      <OPRButton
                        variant="outlined"
                        onClick={() => {
                          if (checkedValue.length > 0) {
                            setIsOpen(true)
                          }
                        }}
                      >
                        {t('change_pay_cycle')}
                      </OPRButton>
                    </Box>
                  </Box>
                  <Box sx={{
                    display: 'flex',
                    flexDirection: 'row',
                    alignItems: 'center',
                  }}
                  >
                    <Checkbox
                      checked={selected.length === employeeData?.length}
                      indeterminate={selected.length > 0 && selected.length < employeeData?.length}
                      onChange={handleSelectAllClick}
                    />
                    <OPRLabel variant="body2">Select All</OPRLabel>
                  </Box>
                  <OPREnhancedTable
                    cols={reassignmentModalColumn(handleClick)}
                    data={JSON.parse(JSON.stringify(employeeData || []))}
                    handleClick={handleClick}
                    isSelected={isSelected}
                    steps={1}
                  />
                </>
              )}
            </OPRResponsiveGrid>
          </Box>
        </OPRInnerFormLayout>
      </form>
    </Box>
  )
}
