import { useTheme } from '@emotion/react'
import {
  Box, Button, Divider, Typography,
} from '@mui/material'
import { useFilteredEmployeesCreateMutation } from 'api/payRollServices'
import { Info } from 'assets/svg-images/SvgComponents'
import OPRButton from 'components/atoms/button/OPRButton'
import OPRLabel from 'components/atoms/label/OPRLabel'
import CustomLoader from 'components/atoms/loader/OPRLoader'
import { CustomDialog } from 'components/atoms/modal/OPRModal'
import OPRSearchIcon from 'components/molecules/OPRSearchIcon'
import { t } from 'i18next'
import { useEffect, useState } from 'react'

type DropBatchPayload = {
  employees: string[];
  confirmDropBatch: boolean;
};

type EmployeeSnapshot = {
  surname: string,
  givenName: string,
  displayName: string,
  employeeCode: string,
}

type PayCycleAdministrationDropBatchProps = {
  open: boolean
  selectedPayCycle: any
  dropBatch: (employees: string[], confirmDropBatch: boolean) => void;
  onClose: () => void
}

function PayCycleAdministrationDropBatch(
  {
    open, selectedPayCycle, onClose, dropBatch,
  }: PayCycleAdministrationDropBatchProps,
) {
  const theme:any = useTheme() // Use the Theme type for the theme variable

  const [selectedEmployees, setSelectedEmployees]:any = useState<EmployeeSnapshot[]>([])
  const [employees, setEmployees]:any = useState<EmployeeSnapshot[]>([])
  const [showModal, setShowModal] = useState(false)
  const [showAffectedBatchesModal, setShowAffectedBatchesModal] = useState(false) // State for affected batches modal
  const [affectedBatches, setAffectedBatches]:any = useState([])
  const [employeefilteringOptions, setemployeefilteringOptions] = useState({
    divisions: [],
    departments: [],
    costCenters: [],
    teams: [],
    payCycleCode: '',
    FromBatchDrop: true,
  })
  const [empSearchData, setempSearchData] = useState({
    SearchText: '',
  })
  const [
    getFilteredEmployees,
    {
      data: employeesData, isLoading, isSuccess, isError, error, refetch,
    },
  ] = useFilteredEmployeesCreateMutation('')

  const filteredEmployees = employees?.filter((employee: any) => employee.displayName.toLowerCase().includes(empSearchData.SearchText.toLowerCase()) || employee.employeeCode.toLowerCase().includes(empSearchData.SearchText.toLowerCase()))
  const handleCheckboxChange = (checked: boolean, employee: EmployeeSnapshot) => {
    if (checked) {
      setSelectedEmployees([...selectedEmployees, employee])
    } else {
      setSelectedEmployees(selectedEmployees.filter((item :EmployeeSnapshot) => item.employeeCode !== employee.employeeCode))
    }
  }

  const handleSelectAllChange = (checked: boolean) => {
    if (checked) {
      setSelectedEmployees(employees.map((employee: EmployeeSnapshot) => employee))
    } else {
      setSelectedEmployees([])
    }
  }

  const handleContinue = () => {
    if (selectedEmployees.length > 0) {
      onClose() // Close the employee selection modal
      setShowModal(true) // Open the confirmation modal
    }
  }

  const onSearch = (e: any) => {
    setempSearchData({ ...empSearchData, SearchText: e.target.value })
  }

  useEffect(() => {
    if (selectedPayCycle) {
      const payCycleCodeForEmpFilter = `${selectedPayCycle?.payCycleYear}${selectedPayCycle?.payCycleMonth}${selectedPayCycle?.payCycleCode}`
      setemployeefilteringOptions({ ...employeefilteringOptions, payCycleCode: payCycleCodeForEmpFilter })
    }
  }, [selectedPayCycle])

  useEffect(() => {
    if (employeefilteringOptions.payCycleCode !== '') {
      getFilteredEmployees(employeefilteringOptions)
    }
  }, [employeefilteringOptions, getFilteredEmployees])

  useEffect(() => {
    if (isSuccess) {
      setEmployees(JSON.parse(JSON.stringify(employeesData?.data.employees || [])))
    }
  }, [employeesData, isSuccess])

  useEffect(() => {
    if (employeesData && open) {
      getFilteredEmployees(employeefilteringOptions)
      setSelectedEmployees([])
    }
  }, [open])

  const handleConfirm = async () => {
    try {
      if (selectedEmployees.length > 0) {
        const employeeCodes = selectedEmployees.map((employee: EmployeeSnapshot) => employee.employeeCode)
        await dropBatch(employeeCodes, true)
      }
    } catch (error) {
      console.error('Error:', error)
    }
    setShowModal(false)
  }

  const selectAll = selectedEmployees.length === employees.length

  // Function to toggle affected batches modal visibility
  const toggleAffectedBatchesModal = () => {
    setShowAffectedBatchesModal(!showAffectedBatchesModal)
  }

  const handleShowAffectedBatches = async () => {
    try {
      if (selectedEmployees.length > 0) {
        const employeeCodes = selectedEmployees.map((employee: EmployeeSnapshot) => employee.employeeCode)
        const response:any = await dropBatch(employeeCodes, false)
        // Assuming response.data contains the affected batches
        if (response && response.message === 'Success' && response.data && response.data.length > 0) {
          // Assuming response.data contains the affected batches
          setAffectedBatches(response.data)
          setShowAffectedBatchesModal(true)
        }
      }
    } catch (error) {
      console.error('Error:', error)
    }
  }

  return (
    <>
      {isLoading
        && (
          <CustomDialog
            CustomStyles={{ borderRadius: '16px' }}
            isOpen={isLoading}
            type="loader"
          >
            <CustomLoader text="Processing request" />
          </CustomDialog>
        )}

      {isSuccess && (
        <CustomDialog isOpen={open} type="loader">
          <Box sx={{
            display: 'flex', height: '75vh', flexDirection: 'column', overflow: 'hidden',
          }}
          >
            {/* Header */}
            <Box sx={{ }}>
              <OPRLabel variant="h4">{t('Select employee to drop batch')}</OPRLabel>
              <Box>
                <OPRLabel CustomStyles={{ marginBottom: '15px' }} variant="body2">Search for an existing employee</OPRLabel>
                <OPRSearchIcon placeholder="Search " value={empSearchData.SearchText} onChange={onSearch} />
                <Divider />
              </Box>
              <label style={{ marginBottom: '0px', marginTop: '10px', display: 'block' }}>
                <input
                  checked={selectAll}
                  type="checkbox"
                  onChange={(event) => handleSelectAllChange(event.target.checked)}
                />
                {' '}
                Select All
              </label>
              <hr style={{ borderColor: '#E8E6E7', marginBottom: '10px' }} />
            </Box>
            {/* Data */}
            <Box sx={{ flex: 1, overflow: 'auto' }}>
              {filteredEmployees?.map((employee:any) => (
                <Box
                  key={employee.employeeCode}
                  sx={{
                    display: 'inline-flex',
                    height: '50px',
                    width: '100%',
                  }}
                >
                  <Box sx={{ paddingRight: '10px' }}>
                    <input
                      checked={selectedEmployees.some((item: EmployeeSnapshot) => item.employeeCode === employee.employeeCode)}
                      type="checkbox"
                      value={employee.employeeCode}
                      onChange={(event) => handleCheckboxChange(event.target.checked, employee)}
                    />
                  </Box>
                  <Box>
                    <OPRLabel
                      CustomStyles={{ lineHeight: '22px', fontWeight: '400' }}
                      label={`${employee.givenName}`}
                    />
                    <OPRLabel
                      CustomStyles={{ lineHeight: '22px', fontWeight: '400' }}
                      label={`${employee.employeeCode}`}
                    />
                  </Box>
                </Box>
              ))}
            </Box>
            {/* Footer */}
            <Box sx={{ }}>
              <div style={{
                borderRadius: '4px',
                background: '#E9F4FF',
                width: '100%',
                padding: '10px',
              }}
              >
                <OPRLabel variant="body2">
                  {t('Total selected employees:')}
                  {selectedEmployees.length}
                </OPRLabel>
              </div>
              <Box style={{
                justifyContent: 'space-between',
                alignItems: 'center',
                gap: 10,
                display: 'flex',
                marginTop: '20px',
              }}
              >
                <OPRButton
                  color="primary"
                  variant="text"
                  onClick={onClose}
                >
                  Cancel
                </OPRButton>

                <Box style={{
                  justifyContent: 'flex-end', alignItems: 'center', gap: 24, display: 'flex',
                }}
                >
                  <OPRButton
                    color="primary"
                    variant="contained"
                    onClick={handleContinue}
                  >
                    Continue
                  </OPRButton>
                </Box>
              </Box>
            </Box>
          </Box>
        </CustomDialog>
      )}

      {/* Modal for further action */}
      <CustomDialog CustomStyles={{ borderRadius: '16px' }} isOpen={showModal} type="loader">
        <Box>
          <OPRLabel variant="h4">Are you sure you want to drop batch?</OPRLabel>
          <Box
            className="pop-up"
            sx={{
              display: 'flex',
              padding: '12px',
              gap: '12px',
              alignItems: 'flex-start',
              borderRadius: '4px',
              alignSelf: 'stretch',
              backgroundColor: `${theme.palette.Invite.main}`,
              marginTop: 1,
            }}
          >
            <Info />
            <OPRLabel variant="h6">Dropping this batch will affect the other batches, you won't be able to revert it. </OPRLabel>
          </Box>
          <Box display="flex" justifyContent="space-between" mt={4}>
            <Button
              color="primary"
              variant="text"
              onClick={handleShowAffectedBatches}
            >
              Show affected batches
            </Button>
          </Box>
          <Box display="flex" justifyContent="space-between" mt={4}>
            <Button color="inherit" variant="text" onClick={() => setShowModal(false)}>
              Cancel
            </Button>
            <Button
              color="primary"
              variant="text"
              onClick={handleConfirm}
            >
              Confirm
            </Button>
          </Box>
        </Box>
      </CustomDialog>

      {/* Modal for affected batches */}
      <CustomDialog isOpen={showAffectedBatchesModal} type="loader">
        <Box>
          <Box
            sx={{
              width: '100%',
              height: '100%',
              backgroundColor: 'white',
              boxShadow: '0px 3px 4px #D4D2D3',
              borderRadius: 2,
              display: 'flex',
              flexDirection: 'column',
              justifyContent: 'flex-start',
              alignItems: 'center',
            }}
          >
            <Box
              sx={{
                alignSelf: 'stretch',
                // height: 88,
                pt: 5,
                pb: 2,
                px: 5,
                display: 'flex',
                flexDirection: 'column',
                justifyContent: 'flex-start',
                alignItems: 'flex-start',
                gap: 2,
              }}
            >
              <OPRLabel variant="h4">Affected Batches</OPRLabel>
            </Box>

            <Box
              sx={{
                alignSelf: 'stretch',
                height: 378,
                px: 5,
                display: 'flex',
                flexDirection: 'column',
                justifyContent: 'flex-start',
                alignItems: 'flex-start',
                gap: 2.5,
              }}
            >
              <Box
                sx={{
                  alignSelf: 'stretch',
                  height: 40,
                  display: 'flex',
                  justifyContent: 'flex-start',
                  alignItems: 'flex-end',
                  gap: 2.5,
                }}
              >
                <Box
                  sx={{
                    flex: '1 1 0',
                    py: 1,
                    display: 'flex',
                    justifyContent: 'flex-start',
                    alignItems: 'center',
                  }}
                >
                  <Typography
                    sx={{
                      flex: '1 1 0',
                      color: '#3B3839',
                      fontSize: 16,
                      fontFamily: 'Lato',
                      fontWeight: '400',

                    }}
                  >
                    is associated with the batches below:
                    {' '}
                    <Typography
                      component="span"
                      sx={{
                        fontWeight: '700',
                      }}
                    >
                      {/* {' '}
                      {monthName}
                      {' '}
                      {year} */}
                      {' '}
                      <br />
                      {' '}
                    </Typography>

                  </Typography>
                </Box>
              </Box>

              <Box
                sx={{
                  alignSelf: 'stretch',
                  height: 318,
                  display: 'flex',
                  flexDirection: 'column',
                  justifyContent: 'flex-start',
                  alignItems: 'flex-start',
                  gap: 2,
                }}
              >
                <Box
                  sx={{
                    alignSelf: 'stretch',
                    display: 'flex',
                    justifyContent: 'flex-start',
                    alignItems: 'center',
                    gap: 3,
                  }}
                >
                  <Box
                    sx={{
                      flex: '1 1 0',
                      height: 22,
                      px: 1,
                      display: 'flex',
                      justifyContent: 'flex-start',
                      alignItems: 'flex-start',
                      gap: 1,
                    }}
                  >
                    <Typography
                      sx={{
                        flex: '1 1 0',
                        color: '#3B3839',
                        fontSize: 14,
                        fontFamily: 'Lato',
                        fontWeight: '400',
                        lineHeight: '22px',
                      }}
                    >
                      {/* {data.length} */}
                      {' '}
                      Pay cycle | Month & Year
                    </Typography>
                    <Typography
                      sx={{
                        flex: '1 1 0',
                        color: '#3B3839',
                        fontSize: 14,
                        fontFamily: 'Lato',
                        fontWeight: '400',
                        lineHeight: '22px',
                      }}
                    >
                      {/* {data.length} */}
                      {' '}
                      Status
                      {' '}
                    </Typography>
                  </Box>
                </Box>
                <Box
                  sx={{
                    alignSelf: 'stretch',
                    height: 280,
                    borderTop: '2px solid #E8E6E7',
                    borderBottom: '2px solid #E8E6E7',
                    display: 'flex',
                    flexDirection: 'column',
                    justifyContent: 'flex-start',
                    alignItems: 'flex-start',
                    gap: 2,
                  }}
                >
                  {affectedBatches.map((cycle: any) => (
                    <Box
                      key={cycle.payCycleCode}
                      sx={{
                        alignSelf: 'stretch',
                        display: 'flex',
                        justifyContent: 'flex-start',
                        alignItems: 'center',
                        gap: 2,
                      }}
                    >
                      <Box
                        sx={{
                          flex: '1 1 0',
                          height: 48,
                          py: 1,
                          display: 'flex',
                          justifyContent: 'flex-start',
                          alignItems: 'center',
                        }}
                      >
                        <Typography
                          sx={{
                            color: '#3B3839',
                            fontSize: 12,
                            fontFamily: 'Lato',
                            fontWeight: '700',
                            lineHeight: '16px',
                          }}
                        >
                          {`${cycle.payCycleName} - ${cycle.payCycleYear}${cycle.payCycleMonth}${cycle.payCycleCode}`}
                        </Typography>
                      </Box>

                      <Box
                        sx={{
                          flex: '1 1 0',
                          height: 48,
                          display: 'flex',
                          justifyContent: 'flex-start',
                          alignItems: 'center',
                          gap: 2,
                        }}
                      >

                        <Box
                          sx={{
                            flex: '1 1 0',
                            height: 48,
                            py: 1,
                            display: 'flex',
                            justifyContent: 'flex-start',
                            alignItems: 'center',
                          }}
                        >

                          <Box
                            sx={{
                              p: 1,
                              display: 'flex',
                              justifyContent: 'flex-start',
                              alignItems: 'center',
                              gap: 1,
                            }}
                          >

                            <Typography
                              sx={{
                                color: '#3B3839',
                                fontSize: 12,
                                fontFamily: 'Lato',
                                fontWeight: '700',
                                lineHeight: '16px',
                              }}
                            >
                              {/* {cycle.status} */}
                              {/* {cycle.status.label} */}
                            </Typography>
                          </Box>
                        </Box>
                      </Box>
                    </Box>
                  ))}
                </Box>

              </Box>
            </Box>
            <Box
              sx={{
                alignSelf: 'stretch',
                pt: 5,
                display: 'flex',
                justifyContent: 'flex-start',
                alignItems: 'center',
                gap: 1.25,
              }}
            >
              <Box
                sx={{
                  flex: '1 1 0',
                  height: 80,
                  px: 5,
                  pt: 2.5,
                  pb: 2.5,
                  borderTop: '1px solid #E8E6E7',
                  display: 'flex',
                  justifyContent: 'space-between',
                  alignItems: 'center',
                }}
              >
                <div />
                <Box
                  sx={{
                    display: 'flex',
                    justifyContent: 'flex-end',
                    alignItems: 'center',
                    gap: 3,
                  }}
                >
                  <Button
                    sx={{
                      borderRadius: 55,
                      borderColor: '#0049DB',
                      color: '#0049DB',
                      px: 3,
                      py: 1,
                      textTransform: 'none',
                    }}
                    variant="outlined"
                    onClick={toggleAffectedBatchesModal} // Call handleBackButtonClick on button click
                  >
                    Back
                  </Button>
                </Box>
              </Box>
            </Box>
          </Box>

          {/* <Box
            className="pop-up"
            sx={{
              display: 'flex',
              padding: '12px',
              gap: '12px',
              alignItems: 'flex-start',
              borderRadius: '4px',
              alignSelf: 'stretch',
              backgroundColor: `${theme.palette.Invite.main}`,
              marginTop: 1,
            }}
          >
            <Info />
            <OPRLabel variant="h6">is associated with the batches below:</OPRLabel>
          </Box>
          <Box display="flex" justifyContent="space-between" mt={4}>
            <Button color="primary" variant="text" onClick={toggleAffectedBatchesModal}>
              Back
            </Button>
          </Box> */}
        </Box>
      </CustomDialog>
    </>
  )
}

export default PayCycleAdministrationDropBatch
