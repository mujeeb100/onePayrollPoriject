import { Badge, Box } from '@mui/material'
import { useGetAllEntityProfileSelectedListByIdQuery } from 'api/entityServices'
import {
  useGetAllPayCycleMasterQuery,
  useGetAllPayCycleOptionsQuery,
  usePayCycleAdministrationDeactivateUpdateMutation,
  usePayCycleAdministrationDropUpdateMutation,
  usePayCycleAdministrationFinalizedUpdateMutation,
  usePayCycleAdministrationLockedUpdateMutation,
  usePayCycleAdministrationOpenUpdateMutation,
  usePayCycleAdministrationUnfinalizedUpdateMutation,
  usePayCycleAdministrationUnlockedUpdateMutation,
  usePayrollCycleDeleteMutation,
} from 'api/payRollServices'
import { CrossIcon, TickIcon } from 'assets/svg-images/SvgComponents'
import OPRButton from 'components/atoms/button/OPRButton'
import { OPRActionMenuOption } from 'components/atoms/dropDown/OPRActionMenu'
import OPRMultiSelectCheckbox from 'components/atoms/multiSelectCheckbox'
import { payCycleAdministratorColumn } from 'components/atoms/table/OPRTableConstant'
import { OPRConfirmationDialog, OPRConfirmationDialogProps } from 'components/molecules/OPRAlertControl/OPRConfirmationDialog'
import { OPRInnerListLayout, TableRefInterface } from 'components/organism/OPRInnerLayoutList'
import apiEndPoint from 'constants/apiEndPoint'
import { PayCycleMasterColumnMappings } from 'constants/exportColumnMappings'
import { useTranslatedColumnsForPDF } from 'hooks/useTranslatedColumnsForPDF'
import { t } from 'i18next'
import { IOPRMultiSelectCheckboxSXProps } from 'interfaces'
import moment from 'moment'
import React, { useEffect, useRef, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { routes } from 'routes/routes'
import { DropDownOption } from 'types'
import {
  flattenDropDownOptions,
  generateFilterUrl, getAPIWithEntityUrl, getEnv, setRouteValues,
} from 'utils'

import PayCycleAdministrationDropBatch from './PayCycleAdministrationDropBatch'

type FilterData = {
  pageNumber: number
  pageSize: number
  orderByAsc: boolean
  sortBy: string | number | symbol
  payCycleName: string
  statuses: DropDownOption[]
  payCycleType: DropDownOption[]
  years: DropDownOption[]
  months: DropDownOption[]
}

function PayrollCycleList() {
  const navigate: any = useNavigate()
  const [employeeDropOpen, setEmployeeDropOpen] = useState(false)
  const [selectedPayroll, setSelectedPayroll] = useState<any>(null)
  const tableRef = useRef<TableRefInterface>(null)
  const [confirmDialog, setConfirmDialog] = useState<OPRConfirmationDialogProps>({
    open: false,
    buttonLayout: 'confirm',
    title: '',
    message: '',
  })

  const [actionResultDialog, setActionResultDialog] = useState<OPRConfirmationDialogProps>({
    open: false,
    buttonLayout: 'close',
    title: '',
    message: '',
  })

  const [filteringOptions, setFilteringOptions] = useState({
    payCycleYears: [],
    payCycleMonths: [],
    payCycleTypes: [],
    payCycleStatus: [],
  })

  const defaultFilterData: FilterData = {
    pageNumber: 1,
    pageSize: 20,
    orderByAsc: true,
    sortBy: '',
    payCycleName: '',
    payCycleType: [],
    statuses: [],
    years: [],
    months: [],
  }

  const [filterData, setFilterData] = useState(defaultFilterData)

  // #region API Calls
  // entity profile view by id
  const {
    data: entityProfileByIdResponse,
    error: entityProfileByIdError,
    isLoading: entityProfileByIdLoading,
    isSuccess: entityProfileByIdSuccess,
    isError: entityProfileByIdIsError,
  } = useGetAllEntityProfileSelectedListByIdQuery('')

  const {
    data: payCycleOptions,
    isSuccess: isPayCycleOptionsSuccess,
    isError: isPayCycleOptionsError,
  } = useGetAllPayCycleOptionsQuery('')
  console.log(payCycleOptions, 'payCycleOptions')
  // PayCycle master Post view API

  const transformData = () => {
    const payload: any = { ...filterData }
    payload.months = flattenDropDownOptions(filterData.months)
    payload.years = flattenDropDownOptions(filterData.years)
    payload.statuses = flattenDropDownOptions(filterData.statuses)
    payload.payCycleType = flattenDropDownOptions(filterData.payCycleType)
    return payload
  }

  const {
    data: payCycleData,
    isLoading: isLoadingPayCycleData,
    isUninitialized: isUninitializedPayCycleData,
    isFetching: isFetchingPayCycleData,
    isSuccess: isSuccessPayCycleData,
    isError: isPayCycleDataError,
    error: payCycleDataError,
    refetch: refetchPayCycleData,
  } = useGetAllPayCycleMasterQuery(
    generateFilterUrl(transformData()),
  )

  // #endregion

  // #region Define batch APIs
  // Unfinalized slice
  const [
    unfinalizedBatch,
    {
      data: unfinalizedData,
      error: unfinalizedError,
      isLoading: unfinalizedLoading,
      isSuccess: unfinalizedSuccess,
      isError: unfinalizedIsError,
    },
  ] = usePayCycleAdministrationUnfinalizedUpdateMutation('')

  // Locked slice
  const [
    lockedBatch,
    {
      data: lockedData,
      error: lockedError,
      isLoading: lockedLoading,
      isSuccess: lockedSuccess,
      isError: lockedIsError,
    },
  ] = usePayCycleAdministrationLockedUpdateMutation('')

  // Open Slice
  const [
    openBatch,
    {
      data: openData,
      error: openError,
      isLoading: openLoading,
      isSuccess: openSuccess,
      isError: openIsError,
    },
  ] = usePayCycleAdministrationOpenUpdateMutation('')

  // Daactivete slice

  const [
    deactivateBatch,
    {
      data: deactivateData,
      error: deactivateError,
      isLoading: deactivateLoading,
      isSuccess: deactivateSuccess,
      isError: deactivateIsError,
    },
  ] = usePayCycleAdministrationDeactivateUpdateMutation('')

  // Finalized slice
  const [
    finalizedBatch,
    {
      data: finalizedData,
      error: finalizedError,
      isLoading: finalizedLoading,
      isSuccess: finalizedSuccess,
      isError: finalizedIsError,
    },
  ] = usePayCycleAdministrationFinalizedUpdateMutation('')

  // Unlocked
  const [
    unlockedBatch,
    {
      data: unlockedData,
      error: unlockedError,
      isLoading: unlockedLoading,
      isSuccess: unlockedSuccess,
      isError: unlockedIsError,
    },
  ] = usePayCycleAdministrationUnlockedUpdateMutation('')

  // Drop batch
  const [
    dropBatch,
    {
      data: dropData,
      error: dropError,
      isLoading: dropLoading,
      isSuccess: dropSuccess,
      isError: dropIsError,
    },
  ] = usePayCycleAdministrationDropUpdateMutation('')

  const [
    deletePayrollCycleById,
    {
      data: deletePayrollCycleResponse,
      error: deletePayrollCycleError,
      isLoading: deletePayrollCycleLoading,
      isSuccess: deletePayrollCycleSuccess,
      isError: deletePayrollCycleIsError,
    }] = usePayrollCycleDeleteMutation()

  // #endregion

  // #region Batch API Loading

  const successHandler = (isSuccess: boolean, toStatus: string, title: string | null = null, message: string| null = null) => {
    if (isSuccess) {
      const config = statusUpdateMap[toStatus]
      if (title || message || config) {
        setActionResultDialog({
          open: true,
          icon: <TickIcon />,
          buttonLayout: 'close',
          title: title || t(`${config.title} batch`),
          onClose: () => setActionResultDialog({ ...actionResultDialog, open: false }),
          message: message || `${selectedPayroll?.payCycleName || ''} ${t(`has been ${toStatus.toLowerCase()} successfully.`)}`,
        })
        handleSearch()
      } else {
        console.log('Invalid action', toStatus)
      }
    }
  }

  const errorHandler = (isError: boolean, error: Error, toStatus: string, onRetry?: ()=> void, title: string | null = null) => {
    if (isError) {
      const config = statusUpdateMap[toStatus]
      if (title || config) {
        const dismiss = () => setActionResultDialog({ ...actionResultDialog, open: false })
        setActionResultDialog({
          open: true,
          error,
          icon: <CrossIcon />,
          buttonLayout: 'try-again',
          title: title || t(`Failed to ${config.title} batch`),
          onClose: () => {
            dismiss()
          },
          onTryAgain: () => {
            dismiss()
            onRetry?.()
          },
          onBack: () => {
            dismiss()
          },
        })
        handleSearch()
      } else {
        console.log('Invalid action', toStatus)
      }
    }
  }

  useEffect(() => {
    successHandler(unfinalizedSuccess, 'Unfinalized')
    errorHandler(
      unfinalizedIsError,
      unfinalizedError,
      'Unfinalized',
      () => unfinalizedBatch(statusPayloadBuilder(selectedPayroll)),
    )
  }, [unfinalizedSuccess, unfinalizedIsError])

  useEffect(() => {
    successHandler(finalizedSuccess, 'Finalized')
    errorHandler(
      finalizedIsError,
      finalizedError,
      'Finalized',
      () => finalizedBatch(statusPayloadBuilder(selectedPayroll)),
    )
  }, [finalizedSuccess, finalizedIsError])

  useEffect(() => {
    successHandler(lockedSuccess, 'Locked')
    errorHandler(
      lockedIsError,
      lockedError,
      'Locked',
      () => lockedBatch(statusPayloadBuilder(selectedPayroll)),
    )
  }, [lockedSuccess, lockedIsError])

  useEffect(() => {
    successHandler(unlockedSuccess, 'Unlocked')
    errorHandler(
      unlockedIsError,
      unlockedError,
      'Unlocked',
      () => unlockedBatch(statusPayloadBuilder(selectedPayroll)),
    )
  }, [unlockedSuccess, unlockedIsError])

  useEffect(() => {
    successHandler(openSuccess, 'Open')
    errorHandler(
      openIsError,
      openError,
      'Open',
      () => openBatch(statusPayloadBuilder(selectedPayroll)),
    )
  }, [openSuccess, openIsError])

  useEffect(() => {
    successHandler(deactivateSuccess, 'Deactivated')
    errorHandler(
      deactivateIsError,
      deactivateError,
      'Inactive',
      () => deactivateBatch(statusPayloadBuilder(selectedPayroll)),
    )
  }, [deactivateSuccess, deactivateIsError])

  useEffect(() => {
    successHandler(dropSuccess, 'PF Dropped')
    errorHandler(
      dropIsError,
      dropError,
      'PF Dropped',
      () => dropBatch(statusPayloadBuilder(selectedPayroll)),
    )
  }, [dropSuccess, dropIsError])

  useEffect(() => {
    successHandler(deletePayrollCycleSuccess, '', t('Pay cycle deleted'), `${payCycleMessageNameBuilder(selectedPayroll)} has been deleted.`)
    errorHandler(
      deletePayrollCycleIsError,
      deletePayrollCycleError,
      '',
      () => deletePayrollCycleById(`Id=${selectedPayroll.id}`),
      t('Failed to delete pay cycle'),
    )
  }, [deletePayrollCycleSuccess, deletePayrollCycleIsError])
  // #endregion

  const payCycleMessageNameBuilder = (data: any) => `${data?.payCycleName} (${data?.payCycleCode})`

  const isLoading = () => lockedLoading || openLoading || deactivateLoading || finalizedLoading || unlockedLoading || dropLoading || unfinalizedLoading || deletePayrollCycleLoading || isLoadingPayCycleData || isLoadingPayCycleData

  useEffect(() => {
    handleSearch()
  }, [filterData])

  useEffect(() => {
    if (entityProfileByIdSuccess && isPayCycleOptionsSuccess) {
      const options = filteringOptions.payCycleYears.filter((item: DropDownOption) => (item.roleCode === entityProfileByIdResponse.currentPayrollMonthYear) || (filterData.years.some((year: DropDownOption) => year.roleCode === item.roleCode)))
      filterData.years = options
      setFilterData({ ...filterData })
    }
  }, [entityProfileByIdResponse, filteringOptions])

  // for the default value 1
  const handleSearch = () => {
    if (!isUninitializedPayCycleData) {
      refetchPayCycleData()
    }
  }

  useEffect(() => {
    if (isPayCycleOptionsSuccess) {
      const payCycleYears = payCycleOptions.payCycleYear.map((item: string) => ({
        roleCode: item,
        roleName: item,
      }))

      const payCycleMonths = payCycleOptions.months.map((item: any) => ({
        roleCode: item.label,
        roleName: moment().month(parseInt(item.label, 10) - 1).format('MMMM'),
      }))

      const payCycleTypes = payCycleOptions.payCycleTypes.map((item: any) => ({
        roleCode: item.id,
        roleName: item.label,
      }))

      const payCycleStatus = payCycleOptions.payCycleStatuses.map((item: any) => ({
        roleCode: item.id,
        roleName: item.label,
      }))

      setFilteringOptions({
        payCycleYears,
        payCycleMonths,
        payCycleTypes,
        payCycleStatus,
      })
    }
  }, [payCycleOptions])

  const statusPayloadBuilder = (data: any) => ({
    payCycleId: data.id,
    currentStatus: {
      id: data.status.id,
      label: data.status.label,
    },
  })

  // #region Batch action handlers
  const statusUpdateMap: Record<string, any> = {
    Finalized: { handler: finalizedBatch, title: t('finalize'), message: t('finalized') },
    Unfinalized: { handler: unfinalizedBatch, title: t('unfinalize'), message: t('unfinalized') },
    Locked: { handler: lockedBatch, title: t('lock'), message: t('locked') },
    Unlocked: { handler: unlockedBatch, title: t('unlock'), message: t('unlocked') },
    Open: { handler: openBatch, title: t('open'), message: t('opened') },
    Inactive: { handler: deactivateBatch, title: t('deactivate'), message: t('deactivated') },
    'PF Dropped': { handler: dropBatch, title: t('drop'), message: t('dropped') },
  }

  const payCycleActionHandler = (data: any, option: OPRActionMenuOption) => {
    const type = option.value

    setSelectedPayroll(data)

    if (type === 'edit_pay_cycle') {
      navigate(
        setRouteValues(`${routes.editPayCycleAdministration}`, {
          id: data.id,
        }),
      )
    } else if (type === 'delete_pay_cycle') {
      setConfirmDialog({
        open: true,
        buttonLayout: 'delete',
        title: t('Are you sure you want to delete the pay cycle?'),
        message: `${payCycleMessageNameBuilder(data)} ${t('will be deleted.')}`,
        infoMessage: t('If it is deleted, you will not be able to revert it.'),
        onCancel: () => setConfirmDialog({ ...confirmDialog, open: false }),
        onDelete: () => {
          setConfirmDialog({ ...confirmDialog, open: false })
          deletePayrollCycleById(`Id=${data.id}`)
        },
      })
    } else if (type === 'drop_batch_on_selected_employee') {
      setEmployeeDropOpen(true)
    } else if (
      type === 'finalize_batch'
      || type === 'unfinalize_batch'
      || type === 'lock_batch'
      || type === 'unlock_batch'
      || type === 'open_batch'
      || type === 'deactivate_batch'
      || type === 'drop_whole_batch'
    ) {
      const config = statusUpdateMap[option.info?.nextState]

      if (config) {
        const title = t(`Are you sure you want to ${config.title} batch?`)
        const infoMessage = `${payCycleMessageNameBuilder(data)} ${t(`will be ${config.message}`)}.`

        setConfirmDialog({
          open: true,
          buttonLayout: 'confirm',
          title,
          infoMessage,
          onCancel: () => setConfirmDialog({ ...confirmDialog, open: false }),
          onConfirm: () => {
            setConfirmDialog({ ...confirmDialog, open: false })
            config.handler(statusPayloadBuilder(data))
          },
        })
      } else {
        console.log('Invalid action', option.info?.nextState)
      }
    } else {
      navigate(
        setRouteValues(`${routes.viewPayCycleAdministration}`, {
          id: data.id,
        }),
      )
    }
  }

  const handleView = (data: any) => {
    navigate(
      setRouteValues(`${routes.viewPayCycleAdministration}`, {
        id: data.id,
        view: true,
      }),
    )
  }

  const renderValue = (selected: string[], filterName: string) => (
    <Box key={filterName} style={{ display: 'flex', justifyContent: 'space-between' }}>
      <span style={{ paddingLeft: '10px' }}>
        {t(`${filterName}`)}
      </span>
      <Badge
        badgeContent={selected?.length || 0}
        sx={{
          '& .MuiBadge-badge': {
            color: '#0037A4',
            backgroundColor: 'white',
            fontWeight: '700',
            fontSize: '14px',
          },
          marginTop: '12px',
          marginRight: '10px',
        }}
      />
    </Box>
  )

  // #endregion
  // #region Filter Layout
  const dropdownInputStyle = (selected?: DropDownOption[]) : IOPRMultiSelectCheckboxSXProps => {
    const count = selected?.length || 0
    let result: IOPRMultiSelectCheckboxSXProps = { }
    if (count > 0) {
      result = { ...result, backgroundColor: '#0037A4', color: '#FFFFFF' }
    }
    return result
  }

  const filterLayout = () => (
    <>
      {/* payCycleMonth */}
      <OPRMultiSelectCheckbox
        listOfOptions={filteringOptions?.payCycleMonths || []}
        renderValue={(selected:any) => renderValue(selected, 'Month')}
        selectedOptions={filterData.months}
        setSelectedOptions={(item: any) => {
          filterData.months = item
          setFilterData({ ...filterData })
        }}
        sx={dropdownInputStyle(filterData.months)}
      />
      {/* payCycleYear */}
      <OPRMultiSelectCheckbox
        listOfOptions={filteringOptions?.payCycleYears || []}
        renderValue={(selected:any) => renderValue(selected, 'Year')}
        selectedOptions={filterData.years}
        setSelectedOptions={(item: any) => {
          filterData.years = item
          setFilterData({ ...filterData })
        }}
        sx={dropdownInputStyle(filterData.years)}
      />
      {/* payCycleTypes */}
      <OPRMultiSelectCheckbox
        listOfOptions={filteringOptions?.payCycleTypes || []}
        renderValue={(selected:any) => renderValue(selected, 'Types')}
        selectedOptions={filterData.payCycleType}
        setSelectedOptions={(item: any) => {
          filterData.payCycleType = item
          setFilterData({ ...filterData })
        }}
        sx={dropdownInputStyle(filterData.payCycleType)}
      />
      {/* payCycleStatus */}
      <OPRMultiSelectCheckbox
        listOfOptions={filteringOptions?.payCycleStatus || []}
        renderValue={(selected:any) => renderValue(selected, 'Status')}
        selectedOptions={filterData.statuses}
        setSelectedOptions={(item: any) => {
          filterData.statuses = item
          setFilterData({ ...filterData })
        }}
        sx={dropdownInputStyle(filterData.statuses)}
      />
      <OPRButton
        handleClick={() => {
          setFilterData(defaultFilterData)
          tableRef?.current?.setSearchField('')
        }}
        sx={{
          color: '#DA3237',
          fontWeight: 700,
          fontSize: '16px',
        }}
        variant="text"
      >
        <CrossIcon />
        Clear filter
      </OPRButton>
    </>
  )
  // #endregion
  // #region Page Layout
  return (
    <>
      <OPRConfirmationDialog
        key="confirmation-dialog"
        {...confirmDialog}
      />

      <OPRConfirmationDialog
        key="action-result-dialog"
        titleSx={{
          '&::first-letter': {
            textTransform: 'capitalize',
          },
        }}
        {...actionResultDialog}
      />

      <Box sx={{ display: 'flex' }}>
        <OPRInnerListLayout
          ref={tableRef}
          isExport
          addHandleClick={() => navigate(routes.createPayCycleAdministration)}
          columns={payCycleAdministratorColumn(payCycleActionHandler)}
          dataList={payCycleData?.records || []}
          error={payCycleDataError}
          exportProps={{
            data: payCycleData?.records,
            fileName: 'PayRollNonRecurring',
            columns: useTranslatedColumnsForPDF(PayCycleMasterColumnMappings),
            pdf: {
              orientation: 'landscape',
            },
            allRecords: {
              baseURL: getEnv('REACT_APP_UP_BASE_URL', null),
              endpoint: getAPIWithEntityUrl(apiEndPoint.payrollCycleList),
              filterData,
            },
          }}
          filterData={filterData}
          filterLayout={filterLayout}
          handlePagination={(pageNumber: number) => {
            setFilterData({ ...filterData, pageNumber })
          }}
          handleSearch={(e: any) => {
            const { value } = e.target
            setFilterData({ ...filterData, payCycleName: value })
          }}
          isError={isPayCycleDataError}
          loading={isLoading()}
          recordCount={payCycleData?.totalItems}
          rowClickHandler={handleView}
          rowNumber={0}
          sortHandleClick={(_: React.MouseEvent<unknown>, property: keyof any) => {
            const isAsc = filterData.sortBy === property && filterData.orderByAsc === true
            setFilterData({ ...filterData, orderByAsc: !isAsc, sortBy: property })
          }}
          title={t('Pay cycles')}
        />
      </Box>
      {/* drop batch for employee */}

      <PayCycleAdministrationDropBatch
        dropBatch={(selectedEmployeeCodes, confirmDropBatch) => {
          const payload: any = {
            payCycleId: selectedPayroll.id,
            confirmDropBatch, // Include confirmDropBatch in the payload
            employees: selectedEmployeeCodes,
            currentStatus: {
              id: selectedPayroll.status.id,
              label: selectedPayroll.status.label,
            },
          }
          dropBatch(payload)
          setEmployeeDropOpen(false)
        }}
        open={employeeDropOpen}
        selectedPayCycle={selectedPayroll}
        onClose={() => {
          setEmployeeDropOpen(false)
        }}
      />
    </>
  )
  // #endregion
}

export default PayrollCycleList
