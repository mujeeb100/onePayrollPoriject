// paycycleadministrator form
import { Box, Grid } from '@mui/material'
import { useGetAllPaymentMethodQuery } from 'api/globalServices'
import {
  useGetAllPayCycleMasterDropDownQuery,
  useGetAllPayGroupDropDownQuery,
  useGetAllPayrollCycleQuery,
  useGetAllPayRollNonRecurringDropDownQuery,
  useLazyGetPayrollCycleByIdQuery, usePayrollCycleCreateMutation, usePayrollCycleUpdateMutation,
} from 'api/payRollServices'
import OPRDatePickerControl from 'components/molecules/OPRDatePickerControl/OPRDatePickerControl'
import OPRInputControl from 'components/molecules/OPRInputControl'
import OPRResponsiveGrid from 'components/molecules/OPRResponsiveGrid'
import OPRSelectorControl from 'components/molecules/OPRSelectorControl/OPRSelectorControl'
import OPRTextArea from 'components/molecules/OPRTextArea/OPRTextArea'
import OPRAlertControl from 'components/organism/OPRAlertControl'
import { OPRInnerFormLayout } from 'components/organism/OPRInnerFormLayout'
import { validationSchemaPayrollAdministratorScheme } from 'constants/validate'
import { useEditable } from 'hooks/useEdit'
import useForm from 'hooks/useForm'
import { t } from 'i18next'
import { useEffect } from 'react'
import { useLocation, useNavigate } from 'react-router-dom'
import { routes } from 'routes/routes'
import { generateFilterUrl, getParamsValue } from 'utils'

interface MessageProps {
  text?: string;
  important?: boolean;
}
const defaultValues = {
  payCycleYear: '',
  payCycleMonth: '',
  payCycleCode: '',
  payCycleName: '',
  payCycleStartDate: '',
  payCycleEndDate: '',
  payCycleCutOffDate: null,
  payCyclePayDate: null,
  paymentMethod: '',
  remarks: '',
  status: '',
  // payCycleType: {
  //   id: 1, // Assuming the ID for Off-Cycle is 2
  //   label: 'Main Cycle',
  // },
  companyBankAccount: '',
}

export default function PayRollNonRecurringForm() {
  const location: any = useLocation()
  const { id, viewUrl } = getParamsValue(location, routes.createPayCycleAdministration)
  const {
    isEditable,
    setEditable,
  } = useEditable()

  const {
    values,
    setValues,
    errors,
    handleChange,
    setErrors,
    handleFormSubmit,
    handleOnChange,
  } = useForm(validationSchemaPayrollAdministratorScheme)

  const navigate = useNavigate()

  const [createPayrollCycle, {
    data: createdPayrollCycleData,
    error: createdPayrollCycleError,
    isLoading: createdPayrollCycleLoading,
    isSuccess: createdPayrollCycleSuccess,
    isError: createdPayrollCycleIsError,
  }] = usePayrollCycleCreateMutation()

  const [updatePayrollCycle, {
    data: updatedDataResponse,
    error: updatedPayrollCycleError,
    isLoading: updatedPayrollCycleLoading,
    isSuccess: updatedPayrollCycleSuccess,
    isError: updatedPayrollCycleIsError,
  }] = usePayrollCycleUpdateMutation()

  const [updatePayrollCycleById, {
    data: updatedPayrollCycleByIdResponse,
    error: updatedPayrollCycleByIdError,
    isLoading: updatedPayrollCycleByIdLoading,
    isSuccess: updatedPayrollCycleByIdSuccess,
    isError: updatedPayrollCycleByIdIsError,
  }] = useLazyGetPayrollCycleByIdQuery()

  //   payment method name slice
  const {
    data: paymentmethodname,
  } = useGetAllPaymentMethodQuery(generateFilterUrl({ pageNumber: 1, pageSize: 1000 }))

  // pay cycle master
  const {
    data: paycyclemasterdata,
  } = useGetAllPayrollCycleQuery(generateFilterUrl({ pageNumber: 1, pageSize: 1000 }))

  const {
    data: payCycleMonthDropdown,
  } = useGetAllPayRollNonRecurringDropDownQuery('')

  const {
    data: PayCycleCodeData,

  } = useGetAllPayGroupDropDownQuery('')

  // pay cycle master dropdwon
  const {
    data: payCycleMasterDropdown,
  } = useGetAllPayCycleMasterDropDownQuery('')

  const dataPayCycle = payCycleMasterDropdown?.payCycleYear?.map((item:any) => ({
    label: item,
    value: item,
  }))

  // useEffect(() => {
  //   console.log('Dropdown data', payCycleMasterDropdown.payCycleStatuses)
  // }, [payCycleMasterDropdown])

  useEffect(() => {
    if (id) {
      updatePayrollCycleById(id)
      setEditable(viewUrl)
    }
  }, [])
  useEffect(() => {
    if (id) {
      setValues({
        ...updatedPayrollCycleByIdResponse?.data,
        payGroupId: updatedPayrollCycleByIdResponse?.data?.payGroupId,
      })
    } else {
      setValues(location.state ? location.state : {})
    }
  }, [updatedPayrollCycleByIdResponse?.data])

  // useEffect(() => {
  //   if (createdPayrollCycleSuccess) {
  //     // Reset form values after successful add operation
  //     setValues({})
  //     setErrors({})
  //   }
  // }, [createdPayrollCycleSuccess])

  useEffect(() => {
    if (id === null) {
      setValues(defaultValues)
    }
  }, [])

  const handleSubmit: any = async () => {
    if (isEditable) {
      if (id === null) {
        await createPayrollCycle({
          payCycleYear: values?.payCycleYear,
          payCycleMonth: values?.payCycleMonth,
          payCycleCode: values?.payCycleCode?.toString() || '',
          payCycleName: values?.payCycleName,
          payCycleStartDate: values?.payCycleStartDate,
          payCycleEndDate: values?.payCycleEndDate,
          payCycleCutOffDate: values?.payCycleCutOffDate,
          payCyclePayDate: values?.payCyclePayDate,
          paymentMethod: values?.paymentMethod || '',
          remarks: values?.remarks || '',
          statusId: values?.status?.id, // Include status here
          status: values?.status, // Include status here
          payCycleTypeId: values?.payCycleType?.id,
          payCycleType: values?.payCycleType,
          companyBankAccount: values?.companyBankAccount || '',

        })
      } else {
        await updatePayrollCycle({
          id: values?.id,
          payCycleYear: values?.payCycleYear,
          payCycleMonth: values?.payCycleMonth,
          payCycleCode: values?.payCycleCode?.toString() || '',
          payCycleName: values?.payCycleName,
          payCycleStartDate: values?.payCycleStartDate,
          payCycleEndDate: values?.payCycleEndDate,
          payCycleCutOffDate: values?.payCycleCutOffDate,
          payCyclePayDate: values?.payCyclePayDate,
          paymentMethod: values?.paymentMethod || '',
          remarks: values?.remarks || '',
          statusId: values?.status?.id, // Include status here
          status: values?.status, // Include status here
          payCycleTypeId: values?.payCycleType?.id,
          payCycleType: values?.payCycleType,
          companyBankAccount: values?.companyBankAccount || '',
          payGroupId: updatedPayrollCycleByIdResponse?.data?.payGroupId || null,
        })
      }
    } else {
      setEditable(true)
    }
  }

  async function editPayrollCycle() {
    await updatePayrollCycle({
      id: values?.id,
      payCycleYear: values?.payCycleYear,
      payCycleMonth: values?.payCycleMonth,
      payCycleCode: values?.payCycleCode?.toString() || '',
      payCycleName: values?.payCycleName,
      payCycleStartDate: values?.payCycleStartDate,
      payCycleEndDate: values?.payCycleEndDate,
      payCycleCutOffDate: values?.payCycleCutOffDate,
      payCyclePayDate: values?.payCyclePayDate,
      paymentMethod: values?.paymentMethod,
      remarks: values?.remarks || '',
      status: values?.status, // Include status here

    })
  }

  const onScreenClose: any = (item: any) => {
    setEditable(item)
    setValues({})
  }
  return (
    <Box sx={{ display: 'flex' }}>
      <form style={{ display: 'flex', width: '100% ' }} onSubmit={(e) => handleFormSubmit(e, handleSubmit)}>
        <OPRAlertControl
          error={createdPayrollCycleError || updatedPayrollCycleError}
          handleEditable={setEditable}
          handleSetValue={setValues}
          handleSubmit={handleSubmit}
          isError={createdPayrollCycleError || updatedPayrollCycleError}
          isLoading={createdPayrollCycleLoading || updatedPayrollCycleLoading || updatedPayrollCycleByIdLoading}
          isSuccess={updatedPayrollCycleSuccess || createdPayrollCycleSuccess}
          name={`${values?.payCycleName}- ${values?.payCycleYear}${values?.payCycleMonth} (${values?.payCycleCode})`}
          title={t('pay_item_group_title')}
          type={id ? 'Update' : 'New'}
        />
        <OPRInnerFormLayout
          error={createdPayrollCycleError || updatedPayrollCycleError}
          handleCancelClick={() => navigate(-1)}
          handleContinueClick={handleSubmit}
          handleEditable={() => {
            setEditable(true)
          }}
          isBackButton={isEditable}
          isLoading={createdPayrollCycleLoading || updatedPayrollCycleLoading || updatedPayrollCycleByIdLoading}
          pageType="detailsPage"
          subtitle={isEditable ? 'Please check the user details below.' : 'All field to mandatory expect those marked optional'}
          title={t('Add pay Off Cycle')}
          onScreenClose={onScreenClose}
        >
          <Box>
            <OPRResponsiveGrid>
              {/* paycycleYear  */}
              <Grid item md={2} sm={1} xs={1}>
                <OPRSelectorControl
                  error={errors?.payCycleYear}
                  isEditable={isEditable}
                  keyName="label"
                  label="Pay Cycle - Year"
                  multiple={false}
                  name="payCycleYear"
                  options={dataPayCycle || []}
                  placeholder="Select an option"
                  value={dataPayCycle?.find((year:any) => year.value === values?.payCycleYear)}
                  valueKey="value"
                  onChange={(text:any) => {
                    handleOnChange('payCycleYear', text?.value)
                  }}

                />
              </Grid>

              {/* paycycleMonth */}
              <Grid item md={2} sm={1} xs={1}>
                <OPRSelectorControl
                  error={errors?.payCycleMonth}
                  isEditable={isEditable}
                  keyName="label"
                  label="Pay Cycle Month"
                  multiple={false}
                  name="payCycleMonth"
                  options={(payCycleMonthDropdown?.months || []).map((month:any) => ({
                    label: month.label.padStart(2, '0'), // Pad single-digit months with leading zero
                  }))}
                  placeholder="Select an option"
                  value={(payCycleMonthDropdown?.months || []).find((month:any) => month.label === values?.payCycleMonth)}
                  valueKey="label"
                  onChange={(text:any) => {
                    handleOnChange('payCycleCode', text)
                    setValues({ ...values, payCycleMonth: text?.label })
                  }}
                />
              </Grid>
              {/* paycyclecode */}
              <Grid item md={2} sm={1} xs={1}>
                {/* <OPRInputControl
                  error={errors?.payCycleCode}
                  isEditable={isEditable}
                  label="Pay Cycle Code"
                  name="payCycleCode"
                  value={values?.payCycleCode}
                  onChange={handleChange}
                /> */}

                <OPRSelectorControl
                  error={errors?.payCycleCode}
                  isEditable={isEditable}
                  keyName="providerTypeName"
                  label="Pay Cycle Code"
                  multiple={false}
                  name="payCycleCode"
                  options={[
                    { providerTypeName: '01', providerTypeValue: '01' },
                    { providerTypeName: '02', providerTypeValue: '02' },
                    { providerTypeName: '03', providerTypeValue: '03' },
                    { providerTypeName: '04', providerTypeValue: '04' },
                    { providerTypeName: '04', providerTypeValue: '04' },
                    { providerTypeName: '05', providerTypeValue: '05' },
                    { providerTypeName: '06', providerTypeValue: '06' },
                    { providerTypeName: '07', providerTypeValue: '07' },
                    { providerTypeName: '08', providerTypeValue: '08' },
                    { providerTypeName: '09', providerTypeValue: '09' },
                    { providerTypeName: '10', providerTypeValue: '10' },
                  ]}
                  placeholder="Select an option"
                  value={
                    {
                      providerTypeName: values?.payCycleCode,
                      providerTypeValue: values?.payCycleCode,
                    }
                  }
                  valueKey="providerTypeValue"
                  onChange={(text:any) => {
                    handleOnChange('payCycleCode', text?.providerTypeValue)
                    // setValues({ ...values, payCycleCode: text?.label })
                  }}
                />
              </Grid>
              {/* paycycleName */}
              <Grid item md={2} sm={1} xs={1}>
                <OPRInputControl
                  error={errors?.payCycleName}
                  isEditable={isEditable}
                  label="Pay Cycle Name"
                  name="payCycleName"
                  value={values?.payCycleName}
                  onChange={handleChange}
                />

                {/* <OPRSelectorControl
                  error={errors?.payCycleName}
                  isEditable={isEditable}
                  keyName="payCycleName"
                  label="Pay Cycle - Year"
                  multiple={false}
                  name="payCycleName"
                  options={(paycyclemasterdata?.records || [])}
                  placeholder="Select an option"
                  value={(paycyclemasterdata?.records || []).find((o:any) => o.payCycleName === values?.payCycleName)}
                  valueKey="payCycleName"
                  onChange={(text:any) => {
                    setValues({ ...values, payCycleName: text?.payCycleName })
                  }}
                /> */}
              </Grid>
              {/* paycycleStartDate */}
              <Grid item md={2} sm={1} xs={1}>
                <OPRDatePickerControl
                  error={errors?.payCycleStartDate}
                  isEditable={isEditable}
                  label="Pay Cycle Start Date"
                  name="payCycleStartDate"
                  value={values?.payCycleStartDate}
                  onChange={(text:any) => {
                    setValues({ ...values, payCycleStartDate: text })
                  }}
                />
              </Grid>
              {/* paycycleEndDate */}
              <Grid item md={2} sm={1} xs={1}>
                <OPRDatePickerControl
                  error={errors?.payCycleEndDate}
                  isEditable={isEditable}
                  label="Pay Cycle End Date"
                  name="payCycleEndDate"
                  value={values?.payCycleEndDate}
                  onChange={(text:any) => {
                    setValues({ ...values, payCycleEndDate: text })
                  }}
                />
              </Grid>
              {/* payCycleCutOffDate */}
              <Grid item md={2} sm={1} xs={1}>
                <OPRDatePickerControl
                  error={errors?.payCycleCutOffDate}
                  isEditable={isEditable}
                  label="Cut-Off Date"
                  name="payCycleCutOffDate"
                  optionalText={t('optional')}
                  value={values?.payCycleCutOffDate}
                  onChange={(text:any) => {
                    setValues({ ...values, payCycleCutOffDate: text })
                  }}
                />
              </Grid>
              {/* payCyclePayDate */}
              <Grid item md={2} sm={1} xs={1}>
                <OPRDatePickerControl
                  error={errors?.payCyclePayDate}
                  isEditable={isEditable}
                  label="Pay Date"
                  name="payCyclePayDate"
                  optionalText={t('optional')}
                  value={values?.payCyclePayDate}
                  onChange={(text:any) => {
                    setValues({ ...values, payCyclePayDate: text })
                  }}
                />
              </Grid>
              {/* paymentMethod */}
              <Grid item md={2} sm={1} xs={1}>
                {/* paymentmethodname */}
                <OPRSelectorControl
                  error={errors?.paymentMethod}
                  isEditable={isEditable}
                  keyName="paymentMethodName"
                  label="Payment Method"
                  multiple={false}
                  name="paymentMethod"
                  optionalText={t('optional')}
                  options={(paymentmethodname?.records || [])}
                  placeholder="Select an option"
                  value={(paymentmethodname?.records || []).find((o:any) => o.paymentMethodName === values?.paymentMethod)}
                  valueKey="paymentMethodName"
                  onChange={(text:any) => {
                    setValues({ ...values, paymentMethod: text?.paymentMethodName })
                  }}
                />
              </Grid>
              <Grid item md={2} sm={1} xs={1}>
                {/* Status */}
                <OPRSelectorControl
                  error={errors?.status}
                  isEditable={isEditable}
                  keyName="label" // Assuming 'id' is the unique identifier for each status
                  label="Status"
                  multiple={false}
                  name="status"
                  options={(payCycleMasterDropdown?.payCycleStatuses || [])}
                  placeholder="Select an option"
                  value={(payCycleMasterDropdown?.payCycleStatuses || []).find((option: any) => option?.label === values?.status?.label)}
                  valueKey="id" // Assuming 'id' is the value key
                  onChange={(selectedOption: any) => {
                    handleOnChange('status', selectedOption) // Set status.label in the form values
                  }}
                />
              </Grid>
              {/* payCycleTypes */}
              <Grid item md={2} sm={1} xs={1}>
                <OPRSelectorControl
                  isEditable={isEditable}
                  keyName="label"
                  label="pay_cycle_type_id"
                  multiple={false}
                  name="payCycleType"
                  options={(payCycleMasterDropdown?.payCycleTypes || [])}
                  placeholder="Select an option"
                  value={values?.payCycleType}
                  valueKey="label"
                  onChange={(text:any) => {
                    handleOnChange('payCycleType', text)
                  }}
                />
              </Grid>
              {/* <Grid item md={2} sm={1} xs={1}>
                <OPRSelectorControl
                  error={errors?.payCycleType}
                  isEditable={isEditable}
                  keyName="label"
                  label="Pay Cycle Type"
                  multiple={false}
                  name="payCycleType"
                  options={(payCycleMasterDropdown?.payCycleTypes || [])}
                  placeholder="Select an option"
                  value={(payCycleMasterDropdown?.payCycleTypes || []).find((option: any) => option?.label === values?.payCycleType?.label)}
                  valueKey="id"
                  onChange={(selectedOption: any) => {
                    handleOnChange('payCycleType', selectedOption)
                  }}
                />
              </Grid> */}
              {/* remarks */}
              <Grid item md={4} sm={6} xs={12}>
                <OPRTextArea
                  error={t(errors?.remarks)}
                  isEditable={isEditable}
                  label="remarks"
                  name="remarks"
                  optionalText="optional"
                  value={values?.remarks}
                  onChange={handleChange}
                />
              </Grid>
            </OPRResponsiveGrid>
          </Box>
        </OPRInnerFormLayout>
      </form>
    </Box>
  )
}
