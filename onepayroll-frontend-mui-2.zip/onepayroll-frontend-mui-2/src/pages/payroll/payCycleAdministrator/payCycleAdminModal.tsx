import { useTheme } from '@emotion/react'
import { Box } from '@mui/material'
import { t } from 'i18next'
import React, { useState } from 'react'

import OPRAlertControl from '../../../components/organism/OPRAlertControl'

type DeactivateModalProps = {
    onClick?: (data: any, type: string) => void;
    handleClose: () => void;
    isDelete?: boolean;
    isOpen: boolean;
    user: any;
  };

export function PayCycleModal({
  onClick, isDelete = false, isOpen, user, handleClose,
}: DeactivateModalProps) {
  const theme:any = useTheme()
  const [steps, setSteps] = useState(0)
  const [isEntity, setIsEntity] = useState(user.entityCount > 0)
  const createSubtitle = () => (isDelete ? {
    title: t('unable_delete_user_account'),
  } : {
    title: t('unable_deactivate_user_account'),
  })
  const isSelected = (id:any) => {}

  // const [
  //   updatePayCycleAdministration,
  //   {
  //     data: updatedPayCycleAdministrationData,
  //     error: updatedPayCycleAdministrationError,
  //     isLoading: updatedPayCycleAdministrationLoading,
  //     isSuccess: updatedPayCycleAdministrationSuccess,
  //     isError: updatedPayCycleAdministrationIsError,
  //   },
  // ] = usePayCycleAdministrationUnfinalizedUpdateMutation('')

  const handleResume = () => {
    if (steps === 1) {
      setSteps((prev) => prev - 1)
    } else {
      handleClose()
      setSteps(0)
    }
  }
  return (
    <Box>
      <OPRAlertControl
        // error={updatedPayCycleAdministrationError}
        // handleEditable={setEditable}
        // handleSetValue={setValues}
        // handleSubmit={handleSubmit}
        handleCancel={isOpen}
        // isError={updatedPayCycleAdministrationError}
        // isLoading={
        //   updatedPayCycleAdministrationLoading
        // }
        // isSuccess={updatedPayCycleAdministrationSuccess}
        name={t('PayCycleAdministration')}
        title={t('PayCycleAdministration')}
        // type={id ? 'Update' : 'New'}
      />

    </Box>
  )
}
