import { Box, Grid } from '@mui/material'
import { useGetAllPensionFundSchemeQuery } from 'api/entityServices'
import { useGetAllPaymentMethodQuery, useGetAllSatutoryMappingQuery } from 'api/globalServices'
import {
  useGetAllFormulaSetupQuery, useGetAllPayItemGroupQuery, useGetAllPayItemMasterDropDownQuery, useLazyGetPayItemMasterByIdQuery, usePayItemMasterCreateMutation, usePayItemMasterUpdateMutation,
} from 'api/payRollServices'
import OPRLabel from 'components/atoms/label/OPRLabel'
import OPRMultiSelect from 'components/atoms/multiSelectCheckbox/OPRMultiSelectCheckbox'
import OPRInputControl from 'components/molecules/OPRInputControl'
import OPRResponsiveGrid from 'components/molecules/OPRResponsiveGrid'
import OPRSelectorControl from 'components/molecules/OPRSelectorControl/OPRSelectorControl'
import OPRTextArea from 'components/molecules/OPRTextArea/OPRTextArea'
import OPRAlertControl from 'components/organism/OPRAlertControl'
import { OPRInnerFormLayout } from 'components/organism/OPRInnerFormLayout'
import { defaultPageSize } from 'constants/index'
import { validationSchemaPayItem } from 'constants/validate'
import { useEditable } from 'hooks/useEdit'
import useForm from 'hooks/useForm'
import { t } from 'i18next'
import { useEffect, useState } from 'react'
import { useLocation, useNavigate } from 'react-router-dom'
import { routes } from 'routes/routes'
import { generateFilterUrl, getParamsValue } from 'utils'

const defaultValues = {

  status: 'Active',

}

export default function PayItemMasterForm() {
  const location: any = useLocation()
  const { id, viewUrl } = getParamsValue(location, routes.createPayItemMaster)
  const {
    isEditable,
    setEditable,
  } = useEditable()
  const [initialReportId, setInitialReportId] = useState('')
  const [filterData, setFilterData] = useState({
    pageNumber: 1,
    pageSize: 250,
    totalItems: 0,
    orderByAsc: true,
    sortBy: '',
    SearchText: '',
    reportId: initialReportId, // Set initialReportId as reportId initially
  })

  // useEffect to calculate initialReportId
  useEffect(() => {
    const values = {
      iR56F: '',
      iR56B: '',
      iR56G: '',
      iR56M: '',
    }
    const reportId = `${values.iR56F || ''},${values.iR56B || ''},${values.iR56G || ''},${values.iR56M || ''}`
    setInitialReportId(reportId)
  }, [])

  // useEffect to update filterData when initialReportId changes
  useEffect(() => {
    setFilterData((prev) => ({
      ...prev,
      reportId: initialReportId,
    }))
  }, [initialReportId])
  const {
    values,
    setValues,
    errors,
    handleChange,
    setErrors,
    handleFormSubmit,
    handleOnChange,
  } = useForm(validationSchemaPayItem)
  // Example useEffect to fetch values from somewhere

  const {
    data: payItemGrouprData,
  } = useGetAllPayItemGroupQuery(generateFilterUrl(defaultPageSize))
  const {
    data: paymentMethodData,
  } = useGetAllPaymentMethodQuery(generateFilterUrl(defaultPageSize))

  const {
    data: allFormulatype,
  } = useGetAllFormulaSetupQuery(generateFilterUrl(defaultPageSize))

  const navigate = useNavigate()
  const [createPayItemMaster, {
    data: createdPayItemMasterData,
    error: createdPayItemMasterError,
    isLoading: createdPayItemMasterLoading,
    isSuccess: createdPayItemMasterSuccess,
    isError: createdPayItemMasterIsError,
  }] = usePayItemMasterCreateMutation()

  const [updatePayItemMaster, {
    data: updatedDataResponse,
    error: updatedPayItemMasterError,
    isLoading: updatedPayItemMasterLoading,
    isSuccess: updatedPayItemMasterSuccess,
    isError: updatedPayItemMasterIsError,
  }] = usePayItemMasterUpdateMutation()

  const [updatePayItemMasterById, {
    data: updatedPayItemMasterByIdResponse,
    error: updatedPayItemMasterByIdError,
    isLoading: updatedPayItemMasterByIdLoading,
    isSuccess: updatedPayItemMasterByIdSuccess,
    isError: updatedPayItemMasterByIdIsError,
  }] = useLazyGetPayItemMasterByIdQuery()

  // } = useGetAllSatutoryMappingQuery(generateFilterUrl({ reportId: `${values.iR56F || ''},${values.iR56B || ''},${values.iR56G || ''},${values.iR56M || ''}` }))
  console.log(updatedPayItemMasterByIdResponse, 'updatedPayItemMasterByIdResponse')
  const {
    data: allSatutoryMapping,

  } = useGetAllSatutoryMappingQuery(generateFilterUrl({ reportId: 'iR56F' }))

  const {
    data: allData,

  } = useGetAllPayItemMasterDropDownQuery('')

  const {
    data: allPensionFundScheme,

  } = useGetAllPensionFundSchemeQuery('')
  const pensionfundMasterList = allPensionFundScheme?.records?.map((item:any) => ({
    name: item.pensionFundSchemeCode,
    value: item.pensionFundSchemeCode,
  }))

  useEffect(() => {
    if (id) {
      updatePayItemMasterById(id)
      setEditable(viewUrl)
    }
  }, [])
  useEffect(() => {
    if (id) {
      const data:any = { ...updatedPayItemMasterByIdResponse?.data, ...updatedPayItemMasterByIdResponse?.data.hkPayItemDto }
      delete data.hkPayItemDto
      setValues(data)
    } else {
      setValues(location.state ? location.state : {})
    }
  }, [updatedPayItemMasterByIdResponse?.data])

  // useEffect(() => {
  //   if (id && updatedPayItemMasterByIdResponse) {
  //     setValues({
  //       ...updatedPayItemMasterByIdResponse?.data,
  //       taxableWage: updatedPayItemMasterByIdResponse?.data?.taxableWage ? 'Yes' : 'No',
  //       eaoRegardedWage: updatedPayItemMasterByIdResponse?.data?.eaoRegardedWage ? 'Yes' : 'No',
  //       eaoCawWage: updatedPayItemMasterByIdResponse?.data?.eaoCawWage ? 'Yes' : 'No',
  //       calculationBasedOnCoveringPeriod: updatedPayItemMasterByIdResponse?.data?.calculationBasedOnCoveringPeriod ? 'Yes' : 'No',
  //       pensionFundableWage: updatedPayItemMasterByIdResponse?.data?.pensionFundableWage ? 'Yes' : 'No',

  //     })
  //   } else {
  //     setValues({
  //     })
  //   }
  // }, [updatedPayItemMasterByIdResponse])
  useEffect(() => {
    if (id === null) {
      setValues(defaultValues)
    }
  }, [])

  // useEffect(() => {
  //   if (createdPayItemMasterSuccess) {
  //     // Reset form values after successful add operation
  //     setValues({})
  //     setErrors({})
  //   }
  // }, [createdPayItemMasterSuccess])
  // useEffect(() => {
  //   if (updatedPayItemMasterByIdResponse?.data) {
  //     const {
  //       payItemCode,
  //       payItemName,
  //       payItemLocalName,
  //       status,
  //       payType,
  //       incomeType,
  //       unitBase,
  //       formulaType,
  //       payItemForBackPay,
  //       paymentMethod,
  //       displaySequence,
  //       remarks,
  //       grossNetPay,
  //       itemGroups,
  //       hkPayItemDto: {
  //         paySubType = '',
  //         taxableWage = '',
  //         eaoRegardedWage = '',
  //         eaoCawWage = '',
  //         calculationBasedOnCoveringPeriod = '',
  //         pensionFundableWage = '',
  //         payslipRemarkBackpay = '',
  //       } = {},
  //     } = updatedPayItemMasterByIdResponse.data

  //     setValues({
  //       payItemCode,
  //       payItemName,
  //       payItemLocalName,
  //       status,
  //       payType,
  //       incomeType,
  //       unitBase,
  //       formulaType,
  //       payItemForBackPay,
  //       paymentMethod,
  //       displaySequence,
  //       remarks,
  //       grossNetPay,
  //       itemGroups,
  //       paySubType,
  //       taxableWage,
  //       eaoRegardedWage,
  //       eaoCawWage,
  //       calculationBasedOnCoveringPeriod,
  //       pensionFundableWage,
  //       payslipRemarkBackpay,
  //     })
  //   } else {
  //     setValues(location.state ? location.state : {})
  //   }
  // }, [updatedPayItemMasterByIdResponse])
  const handleSubmit: any = async () => {
    if (isEditable) {
      const payload = {
        payItemCode: values?.payItemCode,
        payItemName: values?.payItemName,
        payItemLocalName: values?.payItemLocalName,
        status: values?.status,
        payType: values?.payType,
        incomeType: values?.incomeType,
        unitBase: values?.unitBase,
        formulaType: values?.formulaType,
        payItemForBackPay: values?.payItemForBackPay,
        paymentMethod: values?.paymentMethod,
        displaySequence: values?.displaySequence,
        remarks: values?.remarks,
        grossNetPay: values?.grossNetPay,
        ItemGroups: values?.ItemGroups ? [values?.ItemGroups] : [],
        dependsOn: [],
        hkPayItemDto: {
          paySubType: values?.paySubType || null,
          taxableWage: values?.taxableWage,
          eaoRegardedWage: values?.eaoRegardedWage,
          eaoCawWage: values?.eaoCawWage,
          calculationBasedOnCoveringPeriod: values?.calculationBasedOnCoveringPeriod,
          pensionFundableWage: values?.pensionFundableWage,
          pensionFundSchemes: values?.pensionFundSchemeCode ? values?.pensionFundSchemeCode : [],
          payslipRemarkBackpay: values?.payslipRemarkBackpay || null,
          iR56B: values?.iR56B,
          iR56F: values?.iR56F || null,
          iR56G: values?.iR56G || null,
          iR56M: values?.iR56M || null,
        },
      }

      if (id === null) {
        await createPayItemMaster(payload)
      } else {
        await updatePayItemMaster({
          id: values?.id,
          ...payload,
        })
      }
    } else {
      setEditable(true)
    }
  }

  const onScreenClose: any = (item: any) => {
    setEditable(item)
    setValues({})
    // setErrors({})
  }
  console.log('ererrererer', errors)

  return (
    <Box sx={{ display: 'flex' }}>
      <form style={{ display: 'flex', width: '100% ' }} onSubmit={(e) => handleFormSubmit(e, handleSubmit)}>
        <OPRAlertControl
          error={createdPayItemMasterError || updatedPayItemMasterError}
          handleEditable={setEditable}
          handleSetValue={setValues}
          handleSubmit={handleSubmit}
          isError={createdPayItemMasterError || updatedPayItemMasterError}
          isLoading={createdPayItemMasterLoading || updatedPayItemMasterLoading || updatedPayItemMasterByIdLoading}
          isSuccess={updatedPayItemMasterSuccess || createdPayItemMasterSuccess}
          name={values?.payItemName}
          title={t('Pay_item_master_title')}
          type={id ? 'Update' : 'New'}
        />
        <OPRInnerFormLayout
          error={createdPayItemMasterError || updatedPayItemMasterError}
          handleCancelClick={() => navigate(-1)}
          handleContinueClick={handleSubmit}
          handleEditable={() => {
            setEditable(true)
          }}
          isBackButton={isEditable}
          isLoading={createdPayItemMasterLoading || updatedPayItemMasterLoading || updatedPayItemMasterByIdLoading}
          pageType="detailsPage"
          subtitle={isEditable ? t('check_the_user__detail_name') : t('all_fields_are_mandatory_except_marked_optional')}
          title={t('Pay_item_master_title')}
          onScreenClose={onScreenClose}
        >
          <Box>
            <OPRResponsiveGrid>
              <div style={{ display: 'block', width: '100%', margin: '30px 18px 0' }}>
                <OPRLabel variant="h2">{t('gen_info')}</OPRLabel>
              </div>
              <Grid item md={2} sm={1} xs={1}>
                <OPRInputControl
                  error={t(errors?.payItemCode)}
                  isEditable={isEditable}
                  label="payItem_Code"
                  name="payItemCode"
                  value={values?.payItemCode}
                  onChange={handleChange}
                />
              </Grid>
              <Grid item md={2} sm={1} xs={1}>
                <OPRInputControl
                  error={t(errors?.payItemName)}
                  isEditable={isEditable}
                  label="pay_item_name"
                  name="payItemName"
                  value={values?.payItemName}
                  onChange={handleChange}
                />
              </Grid>
              <Grid item md={2} sm={1} xs={1}>
                <OPRInputControl
                  error={t(errors?.payItemLocalName)}
                  isEditable={isEditable}
                  label="Pay_item_local_name"
                  name="payItemLocalName"
                  optionalText="Optional"
                  value={values?.payItemLocalName}
                  onChange={handleChange}
                />
              </Grid>
              <Grid item md={2} sm={1} xs={1}>
                <OPRSelectorControl
                  // defaultValue={{ name: 'Active', values: true }}
                  error={errors?.status}
                  isEditable={isEditable}
                  keyName="name"
                  label={t('status')}
                  multiple={false}
                  name="status"
                  options={[{ name: 'Active', values: 'Active' }, { name: 'Inactive', values: 'Inactive' }]}
                  placeholder="Select an option"
                  value={[{ name: 'Active', values: 'Active' }, { name: 'Inactive', values: 'Inactive' }]?.find((o:any) => o?.values === values?.status)}
                  valueKey="name"
                  onChange={(text:any) => {
                    handleOnChange('status', text?.values)
                  }}
                />
              </Grid>
              <Grid item md={4} sm={6} xs={12}>
                <OPRTextArea
                  error={t(errors?.remarks)}
                  isEditable={isEditable}
                  label="remarks"
                  name="remarks"
                  optionalText="optional"
                  value={values?.remarks}
                  onChange={handleChange}
                />
              </Grid>
              <div style={{ display: 'block', width: '100%', margin: '30px 20px 20px' }}>
                <OPRLabel variant="h2">{t('pay_item_info')}</OPRLabel>
              </div>
              <Grid item md={2} sm={1} xs={1}>
                <OPRSelectorControl
                  error={errors?.payType}
                  isEditable={isEditable}
                  keyName="payType"
                  label={t('pay_item_pay_type')}
                  multiple={false}
                  name="payType"
                  options={[{ payType: 'Earning', values: 'Earning' }, { payType: 'Deduction', values: 'Deduction' }, { payType: 'Non-Payable', values: 'Non-Payable' }]}
                  placeholder="Select an option"
                  value={[{ payType: 'Earning', values: 'Earning' }, { payType: 'Deduction', values: 'Deduction' }, { payType: 'Deduction', values: 'Deduction' }, { payType: 'Non-Payable', values: 'Non-Payable' }]?.find((o:any) => o?.values === values?.payType) || {}}
                  valueKey="values"
                  onChange={(text:any) => {
                    handleOnChange('payType', text?.values)
                  }}
                />
              </Grid>
              <Grid item md={2} sm={1} xs={1}>
                <OPRSelectorControl
                  error={errors?.incomeType}
                  isEditable={isEditable}
                  keyName="incomeType"
                  label={t('pay_item_income_type')}
                  multiple={false}
                  name="incomeType"
                  options={[{ incomeType: 'Recurring Income', values: 'Recurring Income' }, { incomeType: 'Non-Recurring Income', values: 'Non-Recurring Income' }]}
                  placeholder="Select an option"
                  value={[{ incomeType: 'Recurring Income', values: 'Recurring Income' }, { incomeType: 'Non-Recurring Income', values: 'Non-Recurring Income' }]?.find((o:any) => o?.values === values?.incomeType) || {}}
                  valueKey="values"
                  onChange={(text:any) => {
                    handleOnChange('incomeType', text?.values)
                  }}
                />
              </Grid>
              <Grid item md={2} sm={1} xs={1}>
                <OPRSelectorControl
                  error={errors?.unitBase}
                  isEditable={isEditable}
                  keyName="unitBase"
                  label={t('pay_item_unit_base')}
                  multiple={false}
                  name="unitBase"
                  options={[{ unitBase: 'Day', values: 'Day' }, { unitBase: 'Hour', values: 'Hour' }, { unitBase: 'Unit', values: 'Unit' }, { unitBase: 'Not Available', values: 'Not Available' }]}
                  placeholder="Select an option"
                  value={[{ unitBase: 'Day', values: 'Day' }, { unitBase: 'Hour', values: 'Hour' }, { unitBase: 'Unit', values: 'Unit' }, { unitBase: 'Not Available', values: 'Not Available' }]?.find((o:any) => o?.values === values?.unitBase) || {}}
                  valueKey="values"
                  onChange={(text:any) => {
                    handleOnChange('unitBase', text?.values)
                  }}
                />
              </Grid>
              <Grid item md={2} sm={1} xs={1}>
                <OPRSelectorControl
                  error={errors?.formulaType}
                  isEditable={isEditable}
                  keyName="formulaCode"
                  label={t('pay_item_formula_type')}
                  multiple={false}
                  name="formulaType"
                  optionalText="optional"
                  options={(allFormulatype?.records || [])}
                  value={(allFormulatype?.records || [])?.find((o:any) => o?.formulaCode === values?.formulaType) || {}}
                  valueKey="formulaCode"
                  onChange={(text:any) => {
                    handleOnChange('formulaType', text?.formulaCode)
                  }}
                />
              </Grid>
              <Grid item md={2} sm={1} xs={1}>
                <OPRSelectorControl
                  error={errors?.ItemGroups}
                  isEditable={isEditable}
                  keyName="itemGroupCode"
                  label={t('pay_item_item_group')}
                  multiple={false}
                  name="ItemGroups"
                  optionalText="optional"
                  options={(payItemGrouprData?.records || [])}
                  placeholder="Select an option"
                  value={(payItemGrouprData?.records || [])?.find((o:any) => o?.itemGroupCode === values?.ItemGroups) || {}}
                  valueKey="itemGroupCode"
                  onChange={(text:any) => {
                    handleOnChange('ItemGroups', text?.itemGroupCode)
                  }}
                />
              </Grid>
              <Grid item md={2} sm={1} xs={1}>
                <OPRSelectorControl
                  error={errors?.payItemForBackPay}
                  isEditable={isEditable}
                  keyName="label"
                  label={t('pay_item_for_backpay')}
                  multiple={false}
                  name="payItemForBackPay"
                  optionalText="optional"
                  options={allData?.payItemForBackpay || []}
                  placeholder="Select an option"
                  //   value={[{ payItemForBackPay: 'Yes', values: 'Yes' }, { payItemForBackPay: 'No', values: 'No' }]?.find((o:any) => o?.values === values?.payItemForBackPay) || {}}
                  value={(allData?.payItemForBackpay || [])?.find((o:any) => o?.label === values?.payItemForBackPay) || {}}
                  valueKey="label"
                  onChange={(text:any) => {
                    handleOnChange('payItemForBackPay', text?.label)
                  }}
                />
              </Grid>
              <Grid item md={2} sm={1} xs={1}>
                <OPRSelectorControl
                  error={errors?.paySlipRemarksForBackPay}
                  isEditable={isEditable}
                  keyName="paySlipRemarksForBackPay"
                  label={t('paySlipRemarks_ForBackPay')}
                  multiple={false}
                  name="paySlipRemarksForBackPay"
                  optionalText="optional"
                  options={[{ paySlipRemarksForBackPay: 'Split to show Backpay Month', values: 'Split to show Backpay Month' }, { paySlipRemarksForBackPay: 'Not required to split', values: 'Not required to split' }]}
                  placeholder="Select an option"
                  value={[{ paySlipRemarksForBackPay: 'Split to show Backpay Month', values: 'Split to show Backpay Month' }, { paySlipRemarksForBackPay: 'Not required to split', values: 'Not required to split' }]?.find((o:any) => o?.values === values?.paySlipRemarksForBackPay) || {}}
                  valueKey="values"
                  onChange={(text:any) => {
                    handleOnChange('paySlipRemarksForBackPay', text?.values)
                  }}
                />
              </Grid>
              <Grid item md={2} sm={1} xs={1}>
                <OPRSelectorControl
                  error={errors?.paymentMethod}
                  isEditable={isEditable}
                  keyName="paymentMethodCode"
                  label={t('pay_item_payment_method')}
                  multiple={false}
                  name="paymentMethod"
                  options={(paymentMethodData?.records || [])}
                  placeholder="Select an option"
                  value={(paymentMethodData?.records || [])?.find((o:any) => o?.paymentMethodCode === values?.paymentMethod) || {}}
                  valueKey="paymentMethodCode"
                  onChange={(text:any) => {
                    handleOnChange('paymentMethod', text?.paymentMethodCode)
                  }}
                />
              </Grid>
              <Grid item md={2} sm={1} xs={1}>
                <OPRInputControl
                  error={t(errors?.displaySequence)}
                  isEditable={isEditable}
                  label="pay_item_display_sequence"
                  name="displaySequence"
                  optionalText="optional"
                  value={values?.displaySequence}
                  onChange={handleChange}
                />
              </Grid>
              <Grid item md={2} sm={1} xs={1}>
                <OPRSelectorControl
                  error={errors?.grossNetPay}
                  isEditable={isEditable}
                  keyName="grossNetPay"
                  label={t('pay_item_gross_net_pay')}
                  multiple={false}
                  name="grossNetPay"
                  options={[{ grossNetPay: 'Gross', values: 'Gross' }, { grossNetPay: 'Net', values: 'Net' }]}
                  placeholder="Select an option"
                  value={[{ grossNetPay: 'Gross', values: 'Gross' }, { grossNetPay: 'Net', values: 'Net' }]?.find((o:any) => o?.values === values?.grossNetPay) || {}}
                  valueKey="values"
                  onChange={(text:any) => {
                    handleOnChange('grossNetPay', text?.values)
                  }}
                />
              </Grid>
              <div style={{ display: 'block', width: '100%', margin: '30px 20px 20px' }}>
                <OPRLabel variant="h2">{t('hong_kong_factors')}</OPRLabel>
              </div>
              <Grid item md={2} sm={1} xs={1}>
                <OPRSelectorControl
                  error={errors?.paySubType}
                  isEditable={isEditable}
                  keyName="paySubType"
                  label={t('pay_item_pay_sub_type')}
                  multiple={false}
                  name="paySubType"
                  optionalText="optional"
                  options={[{ paySubType: 'Base Salary', values: 'Base Salary' }, { paySubType: 'Overtime', values: 'Overtime' }]}
                  placeholder="Select an option"
                  value={[{ paySubType: 'Base Salary', values: 'Base Salary' }, { paySubType: 'Overtime', values: 'Overtime' }]?.find((o:any) => o?.values === values?.paySubType)}
                  valueKey="values"
                  onChange={(text:any) => {
                    console.log(text, 'jjjjjjjj')
                    handleOnChange('paySubType', text?.values)
                  }}
                />
              </Grid>
              <Grid item md={2} sm={1} xs={1}>
                <OPRSelectorControl
                  error={errors?.taxableWage}
                  isEditable={isEditable}
                  keyName="taxableWage"
                  label={t('pay_item_taxable_wage')}
                  multiple={false}
                  name="taxableWage"
                  options={[{ taxableWage: 'Yes', values: true }, { taxableWage: 'No', values: false }]}
                  placeholder="Select an option"
                  value={[{ taxableWage: 'Yes', values: true }, { taxableWage: 'No', values: false }]?.find((o:any) => o?.values === values?.taxableWage) || {}}
                  valueKey="values"
                  onChange={(text:any) => {
                    handleOnChange('taxableWage', text?.values)
                  }}
                />
              </Grid>
              <Grid item md={2} sm={1} xs={1}>
                <OPRSelectorControl
                  error={errors?.eaoRegardedWage}
                  isEditable={isEditable}
                  keyName="eaoRegardedWage"
                  label={t('pay_item_eao_regarded_wage')}
                  multiple={false}
                  name="eaoRegardedWage"
                  options={[{ eaoRegardedWage: 'Yes', values: true }, { eaoRegardedWage: 'No', values: false }]}
                  placeholder="Select an option"
                  value={[{ eaoRegardedWage: 'Yes', values: true }, { eaoRegardedWage: 'No', values: false }]?.find((o:any) => o?.values === values?.eaoRegardedWage) || {}}
                  valueKey="values"
                  onChange={(text:any) => {
                    handleOnChange('eaoRegardedWage', text?.values)
                  }}
                />
              </Grid>
              <Grid item md={2} sm={1} xs={1}>
                <OPRSelectorControl
                  error={errors?.eaoCawWage}
                  isEditable={isEditable}
                  keyName="eaoCawWage"
                  label={t('pay_item_eao_caw_wage')}
                  multiple={false}
                  name="eaoCawWage"
                  options={[{ eaoCawWage: 'Yes', values: true }, { eaoCawWage: 'No', values: false }]}
                  placeholder="Select an option"
                  value={[{ eaoCawWage: 'Yes', values: true }, { eaoCawWage: 'No', values: false }]?.find((o:any) => o?.values === values?.eaoCawWage) || {}}
                  valueKey="values"
                  onChange={(text:any) => {
                    handleOnChange('eaoCawWage', text?.values)
                  }}
                />
              </Grid>
              <Grid item md={2} sm={1} xs={1}>
                <OPRSelectorControl
                  error={errors?.calculationBasedOnCoveringPeriod}
                  isEditable={isEditable}
                  keyName="calculationBasedOnCoveringPeriod"
                  label={t('pay_item_calculation_based_on_covering_period')}
                  multiple={false}
                  name="calculationBasedOnCoveringPeriod"
                  options={[{ calculationBasedOnCoveringPeriod: 'Yes', values: true }, { calculationBasedOnCoveringPeriod: 'No', values: false }]}
                  placeholder="Select an option"
                  value={[{ calculationBasedOnCoveringPeriod: 'Yes', values: true }, { calculationBasedOnCoveringPeriod: 'No', values: false }]?.find((o:any) => o?.values === values?.calculationBasedOnCoveringPeriod) || {}}
                  valueKey="values"
                  onChange={(text:any) => {
                    handleOnChange('calculationBasedOnCoveringPeriod', text?.values)
                  }}
                />
              </Grid>
              <Grid item md={2} sm={1} xs={1}>
                <OPRSelectorControl
                  error={errors?.pensionFundableWage}
                  isEditable={isEditable}
                  keyName="pensionFundableWage"
                  label={t('pay_item_pension_fund_able_wage ')}
                  multiple={false}
                  name="pensionFundableWage"
                  options={[{ pensionFundableWage: 'Yes', values: true }, { pensionFundableWage: 'No', values: false }]}
                  placeholder="Select an option"
                  value={[{ pensionFundableWage: 'Yes', values: true }, { pensionFundableWage: 'No', values: false }]?.find((o:any) => o?.values === values?.pensionFundableWage) || {}}
                  valueKey="values"
                  onChange={(text:any) => {
                    handleOnChange('pensionFundableWage', text?.values)
                  }}
                />
              </Grid>

              {values?.pensionFundableWage === true && (// Display this field only if pensionFundableWage is true
                <Grid item md={2} sm={1} xs={1}>
                  {/* <OPRSelectorControl
                    error={errors?.pensionFundSchemes}
                    isEditable={isEditable}
                    keyName="pensionFundSchemeCode"
                    label={t('pay_item_pension_fund_schemes')}
                    multiple={false}
                    name="pensionFundSchemes"
                    options={(allPensionFundScheme?.records || [])}
                    placeholder="Select an option"
                    value={(allPensionFundScheme?.records || [])?.find((o:any) => o?.pensionFundSchemeCode === values?.pensionFundSchemes)}
                    valueKey="pensionFundSchemeCode"
                    onChange={(text:any) => {
                      handleOnChange('pensionFundSchemes', text?.pensionFundSchemeCode)
                    }}
                  /> */}
                  <OPRMultiSelect
                    error={errors?.pensionFundSchemeCode}
                    isEditable={isEditable}
                    label="ent_pension_fund_scheme_submenu_title"
                    name="pensionFundSchemeCode"
                    optionalText="Optional"
                    options={pensionfundMasterList || []}
                    placeholder="Select an option"
                    value={values?.pensionFundSchemeCode || []} // Ensure value is initialized as an array
                    onChange={(selectedFormat) => {
                      handleOnChange('pensionFundSchemeCode', selectedFormat)
                    }}
                  />
                </Grid>
              )}
              <div style={{ display: 'block', width: '100%', margin: '30px 20px 20px' }}>
                <OPRLabel variant="h2">{t('hong_kong_mapping')}</OPRLabel>
              </div>
              {/* <Grid item md={2} sm={1} xs={1}>
                <OPRSelectorControl
                  error={errors?.iR56B}
                  isEditable={isEditable}
                  keyName="iR56B"
                  label={t('pay_item_ir56b')}
                  multiple={false}
                  name="iR56B"
                  optionalText="optional"
                  options={[{ iR56B: 'Yes', values: 'Yes' }, { iR56B: 'No', values: 'No' }]}
                  placeholder="Select an option"
                  value={[{ iR56B: 'Yes', values: 'Yes' }, { iR56B: 'No', values: 'No' }]?.find((o:any) => o?.values === values?.iR56B) || {}}
                  valueKey="values"
                  onChange={(text:any) => {
                    handleOnChange('iR56B', text?.values)
                  }}
                />
              </Grid> */}

              <Grid item md={2} sm={1} xs={1}>
                <OPRSelectorControl
                  error={errors?.iR56B}
                  isEditable={isEditable}
                  keyName="label"
                  label={t('pay_item_ir56b')}
                  multiple={false}
                  name="iR56B"
                  options={(allSatutoryMapping || []).map((o: any) => ({
                    value: `${o?.lineCode}`,
                    label: `${o?.lineCode} - ${o?.lineName}`,
                  }))}
                  placeholder="Select an option"
                  value={(allSatutoryMapping || [])
                    .map((o: any) => ({
                      value: `${o?.lineCode}`,
                      label: `${o?.lineCode} ${o?.lineName}`,
                    }))
                    .find((o: any) => o.value === values?.iR56B)}
                  valueKey="value"
                  onChange={(text: any) => {
                    handleOnChange('iR56B', text?.value)
                  }}
                />
              </Grid>
              <Grid item md={2} sm={1} xs={1}>
                <OPRSelectorControl
                  error={errors?.iR56F}
                  isEditable={isEditable}
                  keyName="label"
                  label={t('pay_item_ir56f ')}
                  multiple={false}
                  name="iR56F"
                  optionalText="optional"
                  options={(allSatutoryMapping || []).map((o: any) => ({
                    value: `${o?.lineCode}`,
                    label: `${o?.lineCode} - ${o?.lineName}`,
                  }))}
                  placeholder="Select an option"
                  value={(allSatutoryMapping || [])
                    .map((o: any) => ({
                      value: `${o?.lineCode}`,
                      label: `${o?.lineCode} ${o?.lineName}`,
                    }))
                    .find((o: any) => o.value === values?.iR56F)}
                  valueKey="label"
                  onChange={(text:any) => {
                    handleOnChange('iR56F', text?.value)
                  }}
                />
              </Grid>
              <Grid item md={2} sm={1} xs={1}>
                <OPRSelectorControl
                  error={errors?.iR56G}
                  isEditable={isEditable}
                  keyName="label"
                  label={t('pay_item_ir56g ')}
                  multiple={false}
                  name="iR56G"
                  optionalText="optional"
                  options={(allSatutoryMapping || []).map((o: any) => ({
                    value: `${o?.lineCode}`,
                    label: `${o?.lineCode} - ${o?.lineName}`,
                  }))}
                  placeholder="Select an option"
                  value={(allSatutoryMapping || [])
                    .map((o: any) => ({
                      value: `${o?.lineCode}`,
                      label: `${o?.lineCode} ${o?.lineName}`,
                    }))
                    .find((o: any) => o.value === values?.iR56G)}
                  valueKey="label"
                  onChange={(text:any) => {
                    handleOnChange('iR56G', text?.value)
                  }}
                />
              </Grid>
              <Grid item md={2} sm={1} xs={1}>
                <OPRSelectorControl
                  error={errors?.iR56M}
                  isEditable={isEditable}
                  keyName="label"
                  label={t('pay_item_ir56m')}
                  multiple={false}
                  name="iR56M"
                  optionalText="optional"
                  options={(allSatutoryMapping || []).map((o: any) => ({
                    value: `${o?.lineCode}`,
                    label: `${o?.lineCode} - ${o?.lineName}`,
                  }))}
                  placeholder="Select an option"
                  value={(allSatutoryMapping || [])
                    .map((o: any) => ({
                      value: `${o?.lineCode}`,
                      label: `${o?.lineCode} ${o?.lineName}`,
                    }))
                    .find((o: any) => o.value === values?.iR56M)}
                  valueKey="label"
                  onChange={(text:any) => {
                    handleOnChange('iR56M', text?.value)
                  }}
                />
              </Grid>
            </OPRResponsiveGrid>
          </Box>
        </OPRInnerFormLayout>
      </form>
    </Box>
  )
}
