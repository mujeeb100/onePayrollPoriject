import {
  Box,
} from '@mui/material'
import { useGetAllPayItemMasterQuery, usePayItemMasterDeleteMutation } from 'api/payRollServices'
import { payItemMasterColumn } from 'components/atoms/table/OPRTableConstant'
import { OPRInnerListLayout } from 'components/organism/OPRInnerLayoutList'
import apiEndPoint from 'constants/apiEndPoint'
import { payGroupColumnMappings } from 'constants/exportColumnMappings'
import { useTranslatedColumnsForPDF } from 'hooks/useTranslatedColumnsForPDF'
import { t } from 'i18next'
import React, { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { routes } from 'routes/routes'
import {
  generateFilterUrl, getAPIWithEntityUrl, getEnv,
  setRouteValues,
} from 'utils'

function PayItemMasterList() {
  const navigate: any = useNavigate()
  const [selelctedDelete, setSelelctedDelete]:any = useState({
    data: {},
    isDelete: false,
    name: '',
  })
  const [filterData, setFilterData]:any = useState({
    pageNumber: 1,
    pageSize: 20,
    totalItems: 0,
    orderByAsc: true,
    sortBy: '',
    SearchText: '',
  })
  const {
    data: allPosts,
    error: createAllPostsBankAccountError,
    isLoading: isLoadingAllPosts,
    isSuccess: isSuccessAllPosts,
    isError: isErrorAllPosts,
    error: errorAllPosts,
  } = useGetAllPayItemMasterQuery(generateFilterUrl(filterData))
  const [deletePayItemById,
    {
      data: deletePayGroupResponse,
      error: deletePayGroupError,
      isLoading: deletePayGroupLoading,
      isSuccess: deletePayGroupSuccess,
      isError: deletePayGroupIsError,
    }] = usePayItemMasterDeleteMutation()

  const sorting = (
    event: React.MouseEvent<unknown>,
    property: keyof any,
  ) => {
    const isAsc = filterData.sortBy === property && filterData.orderByAsc === true
    setFilterData({ ...filterData, orderByAsc: !isAsc, sortBy: property })
  }

  useEffect(() => {
    setFilterData({ ...filterData, totalItems: allPosts?.totalItems ? allPosts?.totalItems : 0 })
  }, [allPosts?.pageNumber, filterData.sortBy, filterData.orderByAsc, allPosts?.totalItems])

  const onSearch = (e: any, data: any) => {
    setFilterData({ ...filterData, ...data })
  }
  const handlePagination = (pageNumber: number, pageSize: number) => {
    setFilterData({ ...filterData, pageNumber })
  }

  // viewAcoount  spelling mistake
  const viewAcoount = (data: any, type:string) => {
    if (type === 'edit') {
      navigate(
        setRouteValues(`${routes.editPayItemMaster}`, {
          id: data.id,
        }),
      )
    } else if (type === 'Delete pay item') {
      // deletePayItemById(`Id=${data.id}`)
      setSelelctedDelete({ data, isDelete: true, name: data.costCenterDescription })
    } else {
      navigate(
        setRouteValues(`${routes.viewPayItemMaster}`, {
          id: data.id,
          view: true,
        }),
      )
    }
  }

  const handleView = (data: any) => {
    navigate(
      setRouteValues(`${routes.viewPayItemMaster}`, {
        id: data.id,
        view: true,
      }),
    )
  }
  const handleDelete = (data:any) => {
    deletePayItemById(`id=${data.id}`)
  }
  return (
    <Box sx={{ display: 'flex' }}>
      <OPRInnerListLayout
        Search={filterData?.SearchText}
        addHandleClick={() => navigate(routes?.createPayItemMaster)}
        columns={payItemMasterColumn(viewAcoount)}
        dataList={JSON.parse(JSON.stringify(allPosts?.records || []))}
        deleteCallBack={handleDelete}
        error={errorAllPosts || deletePayGroupError}
        exportProps={{
          data: allPosts?.records,
          fileName: 'PayItemMaster',
          columns: useTranslatedColumnsForPDF(payGroupColumnMappings),
          pdf: {
            orientation: 'landscape',
          },
          allRecords: {
            baseURL: getEnv('REACT_APP_UP_BASE_URL', null),
            endpoint: getAPIWithEntityUrl(apiEndPoint.payItemMasterList),
            filterData,
          },
        }}
        filterData={filterData}
        handlePagination={handlePagination}
        handleSearch={onSearch}
        isError={isErrorAllPosts || deletePayGroupIsError}
        loading={isLoadingAllPosts || deletePayGroupLoading}
        rowClickHandler={handleView}
        rowNumber={0}
        selelctedUser={selelctedDelete}
        setSelelctedUser={setSelelctedDelete}
        sortHandleClick={sorting}
        success={deletePayGroupSuccess}
        title={t('Pay_item_master_title')}
      />
    </Box>
  )
}

export default PayItemMasterList
