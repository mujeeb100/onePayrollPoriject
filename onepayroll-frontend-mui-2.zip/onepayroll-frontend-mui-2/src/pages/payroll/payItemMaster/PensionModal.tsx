import { useTheme } from '@emotion/react'
import {
  Box, Divider, Grid,
  Paper,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
} from '@mui/material'
import { useGetAllPensionFundSchemeQuery } from 'api/entityServices'
import { usePensionFundSchemeItemPayItemCreateMutation, usePensionFundSchemeItemPayItemUpdateMutation } from 'api/payRollServices'
import OPRLabel from 'components/atoms/label/OPRLabel'
import OPRMultiSelect from 'components/atoms/multiSelectCheckbox/OPRMultiSelectCheckbox'
import OPRDatePickerControl from 'components/molecules/OPRDatePickerControl/OPRDatePickerControl'
import OPRInputControl from 'components/molecules/OPRInputControl'
import OPRResponsiveGrid from 'components/molecules/OPRResponsiveGrid'
import { clientGropEntitiesValidationSchema } from 'constants/validate'
import { useEditable } from 'hooks/useEdit'
import useForm from 'hooks/useForm'
import { t } from 'i18next'
import { useEffect, useState } from 'react'
import { useLocation, useNavigate } from 'react-router-dom'
import { getParamsValue } from 'utils'

import { CustomDialog } from '../../../components/atoms/modal/OPRModal'
import OPRAlertControl from '../../../components/organism/OPRAlertControl'

type PensionModalProps = {
    onClick?: (data: any, type: string) => void;
    handleClose: () => void;
    isDelete?: boolean;
    isOpen: boolean;
    payItem: any;
    pensionSchemes: any;
    isViewMode :boolean,
    selctedType?:any;
  onSubmit: (data: any) => void;
  };

export function PensionModal({
  onClick, isDelete = false, isOpen, payItem, handleClose, pensionSchemes, isViewMode, selctedType,
  onSubmit,
}: PensionModalProps) {
  const theme:any = useTheme()
  const location: any = useLocation()
  const { id, viewUrl } = getParamsValue(location)
  const navigate = useNavigate()
  const [selectedSchemes, setSelectedSchemes] = useState<any[]>([])
  const [isEditMode, setIsEditMode] = useState(false)
  const [steps, setSteps] = useState(0)
  const [showEditPopup, setShowEditPopup] = useState(false)
  const [filterData, setfilterData]:any = useState({
    pageNumber: 1,
    pageSize: 250,
    totalItems: 0,
    orderByAsc: true,
    sortBy: '',
    SearchText: '',
  })
  const {
    isEditable,
    setEditable,
  } = useEditable()
  const {
    values,
    setValues,
    errors,
    handleChange,
    setErrors,
    handleFormSubmit,
    handleOnChange,
  } = useForm(
    clientGropEntitiesValidationSchema,
  )
  const createSubtitle = () => (isDelete ? {
    title: t('unable_delete_user_account'),
  } : {
    title: t('unable_deactivate_user_account'),
  })
  const isSelected = (id:any) => {}

  const {
    data: allPensionFundScheme,

  } = useGetAllPensionFundSchemeQuery('')
  const pensionfundMasterList = allPensionFundScheme?.records?.map((item:any) => ({
    name: item.pensionFundSchemeCode,
    value: item.pensionFundSchemeCode,
  }))

  const [
    createPensionFundSchemeItem,
    {
      data: createdPensionFundSchemeItemData,
      error: createdPensionFundSchemeItemError,
      isLoading: createdPensionFundSchemeItemLoading,
      isSuccess: createdPensionFundSchemeItemSuccess,
      isError: createdPensionFundSchemeItemIsError,
    },
  ] = usePensionFundSchemeItemPayItemCreateMutation()

  const [
    updatePensionFundSchemeItem,
    {
      data: updatedDataResponse,
      error: updatedPensionFundSchemeItemError,
      isLoading: updatedPensionFundSchemeItemLoading,
      isSuccess: updatedPensionFundSchemeItemSuccess,
      isError: updatedPensionFundSchemeItemIsError,
    },
  ] = usePensionFundSchemeItemPayItemUpdateMutation()

  // usePensionFundSchemeItemPayItemUpdateMutation
  // usePensionFundSchemeItemUpdateMutation
  const onScreenClose:any = (item:any) => {
    setEditable(item)
    setValues({})
  }

  const handleResume = async () => {
    if (steps === 0) {
      if (isViewMode && !isEditMode) {
        setIsEditMode(true)
      } else {
        setSteps((prev) => prev + 1)
      }
    } else {
      // handleClose()
      // setSteps(0)
      await handleSubmit()
    }
  }
  useEffect(() => {
    if (createdPensionFundSchemeItemSuccess) {
      // Reset form values after successful add operation
      setValues({})
      setErrors({})
    }
  }, [createdPensionFundSchemeItemSuccess])
  const handleSubmit = async () => {
    let combinedSchemeCodes

    if (Array.isArray(values?.pensionFundSchemeCode)) {
      combinedSchemeCodes = Array.from(new Set([
        ...(values.pensionFundSchemeCode || []),
        ...(pensionSchemes?.pensionFundSchemeCode || []),
      ]))
    } else {
      combinedSchemeCodes = values?.pensionFundSchemeCode
        ? [values.pensionFundSchemeCode]
        : []
    }

    const payload = {
      pensionFundSchemeCode: combinedSchemeCodes,
      effectiveStartDate: values?.effectiveStartDate,
      effectiveEndDate: values?.effectiveEndDate,
      payItemCode: pensionSchemes?.payItemCode, // Add payItemCode from payItem object
      status: pensionSchemes?.status === 'active', // Convert 'active' to true and any other value to false
      // Add any other fields from payItem as needed
    }

    // If the values have an id, it means it's an update operation
    if (payItem === null) {
      await createPensionFundSchemeItem(payload)
    } else {
      await updatePensionFundSchemeItem({ ...payload })
    }
    // setShowEditPopup(false)
  }

  // useEffect(() => {
  //   if (payItem) {
  //     console.log('zzzz', payItem)
  //     if (selctedType === 'view') {
  //       setIsEditMode(true)
  //     }
  //     // if (payItem !== null && isEditMode === false) {
  //     //   alert('hhi')
  //     //   setIsEditMode(true)
  //     // } else {
  //     //   setIsEditMode(false)
  //     // }

  //     setValues(payItem)
  //   } else {
  //     setValues({})
  //   }
  // }, [payItem])
  useEffect(() => {
    if (payItem) {
      if (selctedType === 'view') {
        setIsEditMode(true)
        setValues(payItem)
      } else if (selctedType === 'edit') {
        setIsEditMode(false)
        setValues(payItem)
      }
    } else if (selctedType === 'add') {
      setIsEditMode(false)
      setValues({})
    } else {
      setValues({})
    }
    // Additional logic based on getResumeTitle and selctedType
    const resumeTitle = getResumeTitle()
    if (selctedType === 'view' && resumeTitle === 'continue') {
      setIsEditMode(true)
    }
  }, [payItem, selctedType])

  const formatEffectiveDates = () => {
    const formatDate = (date:any) => {
      if (!date) return ''
      const d = new Date(date)
      const year = d.getFullYear()
      const month = (`0${d.getMonth() + 1}`).slice(-2) // Adding leading zero
      const day = (`0${d.getDate()}`).slice(-2) // Adding leading zero
      return `${year}-${month}-${day}`
    }

    const startDate = formatDate(values?.effectiveStartDate)
    const endDate = formatDate(values?.effectiveEndDate)
    return `${startDate} - ${endDate}`
  }
  // const getResumeTitle = () => {
  //   if (steps === 0) {
  //     if (payItem === null && !isEditMode) {
  //       return 'continue'
  //     }
  //     if (payItem !== null && isEditMode === true) {
  //       return 'Edit'
  //     }
  //     if (payItem !== null && isEditMode === false) {
  //       return 'continue'
  //     }
  //   } else {
  //     return 'confirm'
  //   }
  //   return 'continue' // Default return value
  // }
  const switchToEditMode = () => {
    setShowEditPopup(true) // Show the edit popup
    setIsEditMode(true)
  }

  const getResumeTitle = () => {
    if (steps === 0) {
      if (selctedType === 'add') {
        return 'continue'
      }
      if (selctedType === 'edit') {
        return 'continue'
      }
      if (selctedType === 'view') {
        // return 'Edit'
        return 'continue'
      }
    } else {
      return 'confirm'
    }
    return 'continue' // Default return value
  }
  // useEffect to call switchToEditMode when selectedType is 'view'
  useEffect(() => {
    if (selctedType === 'view') {
      switchToEditMode()
    }
  }, [selctedType])
  const getTitle = () => {
    if (steps === 0) {
      if (selctedType === 'add') {
        return 'Add Pension Fund Scheme'
      }
      if (selctedType === 'edit') {
        return 'Edit Pension Fund Scheme'
      }
      if (selctedType === 'view') {
        return 'View Pension Fund Scheme'
      }
    } else {
      return 'Confirm Pension Fund Scheme Details'
    }
    return 'Add Pension Fund Scheme' // Default return value
  }

  // const getTitle = () => {
  //   if (steps === 0) {
  //     if (payItem === null && !isEditMode) {
  //       return 'Add Pension Fund Scheme'
  //     }
  //     if (payItem !== null && isEditMode === true) {
  //       return 'View Pension Fund Scheme'
  //     }
  //     if (payItem !== null && isEditMode === false) {
  //       return 'Edit Pension Fund Scheme'
  //     }
  //   } else {
  //     return 'Confirm Pension Fund Scheme Details'
  //   }
  //   return 'Add Pension Fund Scheme' // Default return value
  // }

  console.log('tt', values?.pensionFundSchemeCode)
  const customMessage = Array.isArray(values?.pensionFundSchemeCode)
    ? `${values?.pensionFundSchemeCode.length} pension fund schemes have been assigned to ${pensionSchemes?.payItemCode}`
    : `${values?.pensionFundSchemeCode} has been assigned to ${pensionSchemes?.payItemCode}`

  return (
    <Box>

      <CustomDialog
        isResume
        CustomStyles={{ borderRadius: '16px' }}
        closeTitle="cancel"
        handleBack={() => {
          setSteps((prev) => prev - 1)
        }}
        handleClose={() => {
          // setShowEditPopup(false)
          // setIsEditMode(false)
          handleClose()
          setSteps(0)
        }}
        handleResume={handleResume}
        isBackButton={(steps > 0)}
        isOpen={isOpen}
        resumeTitle={getResumeTitle()}
        subtitle={steps === 0 ? 'All fields are mandatory except those marked optional.' : 'Please check the pension fund schemes added to pay item below.'}
        title={getTitle()}
        // title={steps === 0 ? 'Add Pension fund scheme' : 'Confirm pension fund scheme details'}
      >
        {/* Modal content goes here */}
        {/* {getResumeTitle() === 'Edit' && (
          <OPRButton onClick={switchToEditMode}>Edit</OPRButton>
        )}
        <div>{getResumeTitle()}</div> */}
        <OPRAlertControl
          // customMessage={`${payItem?.pensionFundSchemeCode}  has been assigned to ${pensionSchemes?.payItemCode}`}
          customMessage={customMessage}
          error={createdPensionFundSchemeItemError || updatedPensionFundSchemeItemError}
          handleEditable={setEditable}
          handleSetValue={setValues}
          handleSubmit={handleSubmit}
          isError={createdPensionFundSchemeItemIsError || updatedPensionFundSchemeItemIsError}
          isLoading={createdPensionFundSchemeItemLoading || updatedPensionFundSchemeItemLoading}
          isSuccess={createdPensionFundSchemeItemSuccess || updatedPensionFundSchemeItemSuccess}
          name={t('PensionFundSchemeItem')}
          title={t('PensionFundSchemeItem')}
          type={id ? 'Update' : 'New'}
        />
        {/* <OPRInnerFormLayout
          error={createdPensionFundSchemeItemError || updatedPensionFundSchemeItemError}
          handleCancelClick={() => navigate(-1)}
          handleContinueClick={handleSubmit}
          handleEditable={() => {
            setEditable(true)
          }}
          isBackButton={isEditable}
          isHeader={false}
          isLoading={createdPensionFundSchemeItemLoading || updatedPensionFundSchemeItemLoading}
          pageType="detailsPage"
          subtitle=""
          title=""
          onScreenClose={onScreenClose}
        > */}
        {steps === 0 ? (
          <OPRResponsiveGrid>
            <Grid item md={2} sm={1} xs={1}>
              <OPRDatePickerControl
                error={errors?.effectiveStartDate}
                isEditable={isEditMode}
                label="Effective start date"
                name="effectiveStartDate"
                value={values?.effectiveStartDate || null}
                // isEditable={isEditable}
                // value={values?.effectiveStartDate ? values?.effectiveStartDate?.toISOString() : null}
                onChange={(date) => {
                  handleOnChange('effectiveStartDate', date)
                }}
              />
            </Grid>
            <Grid item md={2} sm={1} xs={1}>
              <OPRDatePickerControl
                error={errors?.effectiveEndDate}
                // isEditable={!isViewMode}
                isEditable={isEditMode}
                label="Effective end date"
                name="effectiveEndDate"
                value={values?.effectiveEndDate || null}
                // value={values?.effectiveEndDate ? values?.effectiveEndDate?.toISOString() : null}
                onChange={(date) => {
                  handleOnChange('effectiveEndDate', date)
                }}
              />
            </Grid>
            { payItem?.pensionFundSchemeCode ? (
              <Grid item md={2} sm={1} xs={1}>
                <OPRInputControl
                  label={t('ent_pension_fund_scheme_submenu_title')}
                  name="payGroupName"
                  value={values?.pensionFundSchemeCode}
                  onChange={handleChange}
                />
              </Grid>
            ) : (
              <Grid item md={4} sm={1} xs={1}>
                <OPRMultiSelect
                  error={errors?.pensionFundSchemeCode}
                  isEditable={isEditMode}
                  label="ent_pension_fund_scheme_submenu_title"
                  name="pensionFundSchemeCode"
                  optionalText="Optional"
                  options={pensionfundMasterList || []}
                  placeholder="Select an option"
                  value={values?.pensionFundSchemeCode || []} // Ensure value is initialized as an array
                  onChange={(selectedFormat) => {
                    handleOnChange('pensionFundSchemeCode', selectedFormat)
                  }}
                />
              </Grid>
            )}

          </OPRResponsiveGrid>
        ) : (
          <>
            <Box sx={{
              display: 'flex',
              flexDirection: 'row',
              gap: '5px',
              alignItems: 'center',
              padding: '10px 10px',
              justifyContent: 'space-between',
            }}
            >
              <Box sx={{
                display: 'flex', flexDirection: 'column', alignItems: 'flex-start',
              }}
              >
                <OPRLabel CustomStyles={{ marginBottom: '15px' }} variant="body2">{t('payItem_Code')}</OPRLabel>
                <OPRLabel CustomStyles={{ marginBottom: '15px' }} variant="body2">{pensionSchemes?.payItemCode}</OPRLabel>
              </Box>
              <Box sx={{
                display: 'flex', flexDirection: 'column', alignItems: 'flex-start',
              }}
              >
                <OPRLabel CustomStyles={{ marginBottom: '15px' }} variant="body2">{t('employee_recurring_title_payname')}</OPRLabel>
                <OPRLabel CustomStyles={{ marginBottom: '15px' }} variant="body2">{pensionSchemes?.payItemName}</OPRLabel>
              </Box>
            </Box>
            <OPRLabel CustomStyles={{ marginLeft: '15px', marginBottom: '8px' }} variant="body2">
              {t('ent_pens_fund_scheme_index_page_title')}
              {/* (
                    {payItem.entityCount}
                    ) */}
            </OPRLabel>
            <Divider />
            <TableContainer component={Paper} sx={{ marginTop: '15px' }}>
              <Table aria-label="pension fund scheme table">
                <TableHead>
                  <TableRow>
                    <TableCell>Pension Fund Scheme</TableCell>
                    <TableCell>Effective Dates</TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {Array.isArray(values?.pensionFundSchemeCode) ? (
                    // Case where pensionFundSchemeCode is an array
                    values?.pensionFundSchemeCode.map((schemeCode: any) => {
                      const scheme = allPensionFundScheme?.records?.find((item: any) => item.pensionFundSchemeCode === schemeCode)
                      return scheme ? (
                        <TableRow key={scheme.pensionFundSchemeCode}>
                          <TableCell>{scheme.pensionFundSchemeCode}</TableCell>
                          <TableCell>{formatEffectiveDates()}</TableCell>
                        </TableRow>
                      ) : null
                    })
                  ) : (
                    // Case where pensionFundSchemeCode is not an array
                    <TableRow key={values?.pensionFundSchemeCode}>
                      <TableCell>{values?.pensionFundSchemeCode}</TableCell>
                      <TableCell>{formatEffectiveDates()}</TableCell>
                    </TableRow>
                  )}
                </TableBody>

                {/* { !values?.pensionFundSchemeCode ? (
                    values?.pensionFundSchemeCode
                  ) : (
                    <TableBody>
                      {values?.allPensionFundScheme?.records?.map((scheme: any, index: any) => (
                        <TableRow key={scheme?.pensionFundSchemeCode}>
                          <TableCell>{scheme}</TableCell>
                          <TableCell>{formatEffectiveDates()}</TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  )} */}
              </Table>
            </TableContainer>
          </>
        )}
        {/* </OPRInnerFormLayout> */}

      </CustomDialog>
    </Box>
  )
}
