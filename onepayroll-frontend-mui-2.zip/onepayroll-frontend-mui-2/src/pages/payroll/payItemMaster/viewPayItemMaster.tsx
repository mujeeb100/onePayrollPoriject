import { Box, Grid } from '@mui/material'
import { useGetAllPensionFundSchemeQuery, useLazyGetPensionFundSchemeItemByIdQuery } from 'api/entityServices'
import { useGetAllPaymentMethodQuery, useGetAllSatutoryMappingQuery } from 'api/globalServices'
import {
  useGetAllFormulaSetupQuery,
  useGetAllPayGroupDropDownQuery, useGetAllPayItemGroupQuery,
  useGetAllPensionFundSchemeItemPayItemQuery, useLazyGetPayItemMasterByIdQuery,
  usePayItemMasterCreateMutation,
  usePayItemMasterUpdateMutation,
  usePensionFundSchemeItemPayItemDeleteMutation,
} from 'api/payRollServices'
import { LeftBack } from 'assets/svg-images/SvgComponents'
import OPRButton from 'components/atoms/button/OPRButton'
import OPRLabel from 'components/atoms/label/OPRLabel'
import { pensionFundItemPayItemColumn } from 'components/atoms/table/OPRTableConstant'
import OPRInputControl from 'components/molecules/OPRInputControl'
import OPRResponsiveGrid from 'components/molecules/OPRResponsiveGrid'
import OPRSelectorControl from 'components/molecules/OPRSelectorControl/OPRSelectorControl'
import OPRTextArea from 'components/molecules/OPRTextArea/OPRTextArea'
import OPRAlertControl from 'components/organism/OPRAlertControl'
import { OPRInnerFormLayout } from 'components/organism/OPRInnerFormLayout'
import { OPRInnerListLayout } from 'components/organism/OPRInnerLayoutList'
import { defaultPageSize } from 'constants/index'
import { validationSchemaPayGroup } from 'constants/validate'
import { useEditable } from 'hooks/useEdit'
import useForm from 'hooks/useForm'
import { t } from 'i18next'
import React, { useEffect, useState } from 'react'
import { useLocation, useNavigate } from 'react-router-dom'
import { routes } from 'routes/routes'
import { generateFilterUrl, getParamsValue, setRouteValues } from 'utils'

import {
  a11yProps,
  CustomTabPanel, StyledTab, StyledTabs,
} from '../../../components/atoms/tabs'
import { PensionModal } from './PensionModal'

export default function ViewPayItemMaster() {
  const navigate = useNavigate()
  const location: any = useLocation()
  const { id, viewUrl } = getParamsValue(location, routes.createUserAccounts)
  const [value, setValue] = React.useState(0)
  const [payItem, setPayItem] = React.useState({})
  const [selectedPayItem, setSelectedPayItem] = useState(null)
  const [modalType, setModalType] = useState('')
  const [filterData, setfilterData]:any = useState({
    pageNumber: 1,
    pageSize: 250,
    totalItems: 0,
    orderByAsc: true,
    sortBy: '',
    SearchText: '',
    // payItemCode: selectedPayItem,
  })
  const [isOpen, setIsOpen] = useState(false)
  // const [selectedPayItemRow, setSelectedPayItemRow] = useState(null)
  const [pensionSchemes, setPensionSchemes] = useState<any[]>([])
  const [modalTitle, setModalTitle] = useState('')

  const handleTabChange = (event: React.SyntheticEvent, newValue: number) => {
    setValue(newValue)
  }
  const {
    isEditable,
    setEditable,
  } = useEditable()
  const [isViewMode, setIsViewMode] = useState(true)
  const {
    values,
    setValues,
    errors,
    handleChange,
    setErrors,
    handleFormSubmit,
    handleOnChange,
  } = useForm(validationSchemaPayGroup)
  console.log(selectedPayItem, 'selectedPayItemselectedPayItemselectedPayItem', values)
  const {
    data: allSatutoryMapping,

  } = useGetAllSatutoryMappingQuery(generateFilterUrl({ reportId: 'iR56B' }))

  const {
    data: payItemGrouprData,
  } = useGetAllPayItemGroupQuery(generateFilterUrl(defaultPageSize))
  const {
    data: paymentMethodData,
  } = useGetAllPaymentMethodQuery(generateFilterUrl(defaultPageSize))

  const [createPayItemMaster, {
    data: createdPayItemMasterData,
    error: createdPayItemMasterError,
    isLoading: createdPayItemMasterLoading,
    isSuccess: createdPayItemMasterSuccess,
    isError: createdPayItemMasterIsError,
  }] = usePayItemMasterCreateMutation()

  const [updatePayItemMaster, {
    data: updatedDataResponse,
    error: updatedPayItemMasterError,
    isLoading: updatedPayItemMasterLoading,
    isSuccess: updatedPayItemMasterSuccess,
    isError: updatedPayItemMasterIsError,
  }] = usePayItemMasterUpdateMutation()

  const {
    data: allFormulatype,
  } = useGetAllFormulaSetupQuery(generateFilterUrl(defaultPageSize))

  console.log('aaaaaa', allFormulatype)

  const [updatePayItemMasterById, {
    data: updatedPayItemMasterByIdResponse,
    error: updatedPayItemMasterByIdError,
    isLoading: updatedPayItemMasterByIdLoading,
    isSuccess: updatedPayItemMasterByIdSuccess,
    isError: updatedPayItemMasterByIdIsError,
  }] = useLazyGetPayItemMasterByIdQuery()

  const {
    data: allData,
    error: createAllDatasBankAccountError,
    isLoading: isLoadingAllData,
    isSuccess: isSuccessAllData,
    isError: isErrorAllData,
    error: errorAllData,
  } = useGetAllPayGroupDropDownQuery('')

  //   JSON.parse(JSON.stringify(allPosts?.records || []))
  const [
    updatePensionFundSchemeItemById,
    {
      data: updatedPensionFundSchemeItemByIdResponse,
      error: updatedPensionFundSchemeItemByIdError,
      isLoading: updatedPensionFundSchemeItemByIdLoading,
      isSuccess: updatedPensionFundSchemeItemByIdSuccess,
      isError: updatedPensionFundSchemeItemByIdIsError,
    },
  ] = useLazyGetPensionFundSchemeItemByIdQuery()

  // useEffect(() => {
  //   if (id) {
  //     updatePensionFundSchemeItemById(id)
  //     setEditable(viewUrl)
  //   }
  // }, [])

  console.log('*****', selectedPayItem)

  useEffect(() => {
    if (isOpen === false) {
      setSelectedPayItem(null)
    }
  }, [])
  useEffect(() => {
    if (id) {
      // setValues(updatedPensionFundSchemeItemByIdResponse?.data)
    } else {
      setValues(location.state ? location.state : {})
    }
  }, [updatedPensionFundSchemeItemByIdResponse?.data])

  const {
    data: allPensionFundScheme,

  } = useGetAllPensionFundSchemeQuery('')
  const {
    data: allPensionFundSchemeItem,

  } = useGetAllPensionFundSchemeItemPayItemQuery(generateFilterUrl(''))
  const [deletePensionFundSchemeItemById,
    {
      data: deletePensionFundSchemeItemResponse,
      error: deletePensionFundSchemeItemError,
      isLoading: deletePensionFundSchemeItemLoading,
      isSuccess: deletePensionFundSchemeItemSuccess,
      isError: deletePensionFundSchemeItemIsError,
    }] = usePensionFundSchemeItemPayItemDeleteMutation()

  // useEffect(() => {
  //   updatedPayItemMasterByIdResponse?.data?.hkPayItemDto?.pensionFundSchemes?.forEach((item: any) => {
  //     const filteredSchemes = allPensionFundSchemeItem?.records?.filter((i: any) => i.pensionFundSchemeCode === item)
  //     console.log('iiiiiiii', filteredSchemes)

  //     if (filteredSchemes?.length > 0) {
  //       setPensionSchemes((prevSchemes) => [...prevSchemes, ...filteredSchemes])
  //     }
  //   })
  // }, [isSuccessAllPosts, updatedPayItemMasterByIdSuccess])

  useEffect(() => {
    if (id) {
      updatePayItemMasterById(id)
      setEditable(viewUrl)
    }
  }, [])
  // leave
  useEffect(() => {
    setPayItem(updatedPayItemMasterByIdResponse?.data)
    if (id) {
      setValues(updatedPayItemMasterByIdResponse?.data)
    } else {
      setValues(location.state ? location.state : {})
    }
  }, [updatedPayItemMasterByIdResponse?.data])

  const handleEditClick = () => {
    navigate(
      setRouteValues(`${routes.editUserAccounts}`, {
        id,
      }),
    )
  }

  const handleSubmit: any = async () => {}
  const onScreenClose:any = (item:any) => {
    setEditable(item)
    setValues({})
  }
  const viewAcoount = (data: any, type: string) => {
    if (type === 'Edit Pension Fund Scheme Item') {
      setSelectedPayItem(data)
      // setIsViewMode(false) // Set edit mode when editing
      setModalType('edit')
      // setModalTitle('Edit Pension Fund Scheme')
      setIsOpen(true)
      updatePensionFundSchemeItemById(data?.id)
    } else if (type === 'Delete Pension Fund Scheme Item') {
      deletePensionFundSchemeItemById(`${data?.payItemCode}`)
    } else {
      setSelectedPayItem(data)
      // setIsViewMode(false) // Set view mode when viewing
      // setModalTitle('View Pension Fund Scheme')
      setIsOpen(true)
      updatePensionFundSchemeItemById(data?.id)
    }
  }
  const handlePagination = (pageNumber: number, pageSize: number) => {
    // setfilterData({ ...filterData, pageNumber })
  }

  const handleCloseModal = () => {
    setIsOpen(false)
  }
  const handleSubmitModal = async (data: any) => {
    // Handle submission of pension fund scheme data here
    console.log('Submitted data:', data)

    // Assuming you may want to update some state or perform further actions
    setIsOpen(false)
  }

  const handleAddClick = () => {
    setModalType('add')
    setSelectedPayItem(null)
    // setIsViewMode(false)
    // setModalTitle('Add Pension Fund Scheme')
    setIsOpen(true)
  }

  const handleView = (data:any) => {
    setValue(data)
    setSelectedPayItem(data)
    setModalType('view')
    setIsOpen(true)
    updatePensionFundSchemeItemById(data?.id)
  }

  // useEffect(() => {
  //   if (selectedPayItem) {
  //     updatePensionFundSchemeItemById(selectedPayItem)
  //   }
  // }, [selectedPayItem])
  console.log('xxx', selectedPayItem)
  useEffect(() => {
    if (updatedPensionFundSchemeItemByIdSuccess && updatedPensionFundSchemeItemByIdResponse) {
      setSelectedPayItem(updatedPensionFundSchemeItemByIdResponse.data)
    }
  }, [updatedPensionFundSchemeItemByIdSuccess, updatedPensionFundSchemeItemByIdResponse])
  return (
    <>
      <PensionModal
        handleClose={handleCloseModal}
        isOpen={isOpen}
        isViewMode={isViewMode} // Pass the view mode state
        payItem={selectedPayItem}
        pensionSchemes={values}
        selctedType={modalType}
        // selctedType="Edit"
        onSubmit={handleSubmitModal}
      />
      <Box sx={{
        display: 'flex', justifyContent: 'space-between', flexDirection: 'row',
      }}
      >
        <Box sx={{
          display: 'flex', justifyContent: 'flex-start', alignItems: 'center', gap: '25px',
        }}
        >
          <Box
            component="div"
            onClick={() => navigate(-1)}
          >
            <LeftBack />
          </Box>
          <OPRLabel variant="h2">
            {` ${updatedPayItemMasterByIdResponse?.records?.payItemCode || ''}`}
          </OPRLabel>
        </Box>
        {/* <Box sx={{
          display: 'flex', justifyContent: 'flex-start', height: 'fit-content',
        }}
        >
          <OPRButton
            color="primary"
            handleClick={handleEditClick}
            style={{ borderRadius: '110px' }}
            variant="outlined"
          >
            Edit User Account
          </OPRButton>
        </Box> */}
      </Box>
      <Box sx={{ width: '100%' }}>
        <Box sx={{ borderBottom: 1, borderColor: 'divider' }}>
          <StyledTabs aria-label="basic tabs example" value={value} onChange={handleTabChange}>
            <StyledTab label="Overview" {...a11yProps(0)} />
            <StyledTab label={t('ent_pens_fund_scheme_index_page_title')} {...a11yProps(1)} />
          </StyledTabs>
        </Box>
        <CustomTabPanel index={0} value={value}>
          <Box sx={{ display: 'flex' }}>
            <form style={{ display: 'flex', width: '100% ' }} onSubmit={(e) => handleFormSubmit(e, handleSubmit)}>
              <OPRAlertControl
                error={createdPayItemMasterError || updatedPayItemMasterError}
                handleEditable={setEditable}
                handleSetValue={setValues}
                handleSubmit={handleSubmit}
                isError={createdPayItemMasterError || updatedPayItemMasterError}
                isLoading={createdPayItemMasterLoading || updatedPayItemMasterLoading || updatedPayItemMasterByIdLoading}
                isSuccess={updatedPayItemMasterSuccess || createdPayItemMasterSuccess || deletePensionFundSchemeItemSuccess}
                name={t('Pay_item_master_title')}
                title={t('Pay_item_master_title')}
                type={id ? 'Update' : 'New'}
              />
              <OPRInnerFormLayout
                error={createdPayItemMasterError || updatedPayItemMasterError}
                handleCancelClick={() => navigate(-1)}
                handleContinueClick={handleSubmit}
                handleEditable={() => {
                  setEditable(true)
                }}
                isBackButton={isEditable}
                isHeader={false}
                isLoading={createdPayItemMasterLoading || updatedPayItemMasterLoading || updatedPayItemMasterByIdLoading}
                pageType="detailsPage"
                subtitle={isEditable ? 'Please check the user details below.' : 'All field to mandatory expect those mark optional'}
                title={t('Pay_item_master_title')}
                onScreenClose={onScreenClose}
              >
                <Box>
                  <OPRResponsiveGrid>
                    <div style={{ display: 'block', width: '100%', margin: '30px 18px 0' }}>
                      <OPRLabel variant="h2">{t('gen_info')}</OPRLabel>
                    </div>
                    <Grid item md={2} sm={1} xs={1}>
                      <OPRInputControl
                        error={t(errors?.payItemCode)}
                        isEditable={isEditable}
                        label="payItem_Code"
                        name="payItemCode"
                        value={values?.payItemCode}
                        onChange={handleChange}
                      />
                    </Grid>
                    <Grid item md={2} sm={1} xs={1}>
                      <OPRInputControl
                        error={t(errors?.payItemName)}
                        isEditable={isEditable}
                        label="pay_item_name"
                        name="payItemName"
                        value={values?.payItemName}
                        onChange={handleChange}
                      />
                    </Grid>
                    <Grid item md={2} sm={1} xs={1}>
                      <OPRInputControl
                        error={t(errors?.payItemLocalName)}
                        isEditable={isEditable}
                        label="Pay_item_local_name"
                        name="payItemLocalName"
                        value={values?.payItemLocalName}
                        onChange={handleChange}
                      />
                    </Grid>
                    <Grid item md={2} sm={1} xs={1}>
                      <OPRSelectorControl
                        // defaultValue={{ name: 'Active', values: true }}
                        error={errors?.status}
                        isEditable={isEditable}
                        keyName="name"
                        label={t('status')}
                        multiple={false}
                        name="status"
                        options={[{ name: 'Active', values: 'Active' }, { name: 'Inactive', values: 'Inactive' }]}
                        placeholder="Select an option"
                        value={[{ name: 'Active', values: 'Active' }, { name: 'Inactive', values: 'Inactive' }]?.find((o:any) => o?.values === values?.status)}
                        valueKey="name"
                        onChange={(text:any) => {
                          handleOnChange('status', text?.values)
                        }}
                      />
                    </Grid>
                    <Grid item md={4} sm={6} xs={12}>
                      <OPRTextArea
                        error={t(errors?.remarks)}
                        isEditable={isEditable}
                        label="remarks"
                        name="remarks"
                        optionalText="optional"
                        value={values?.remarks}
                        onChange={handleChange}
                      />
                    </Grid>
                    <div style={{ display: 'block', width: '100%', margin: '30px 20px 20px' }}>
                      <OPRLabel variant="h2">{t('pay_item_info')}</OPRLabel>
                    </div>
                    <Grid item md={2} sm={1} xs={1}>
                      <OPRSelectorControl
                        error={errors?.payType}
                        isEditable={isEditable}
                        keyName="payType"
                        label={t('pay_item_pay_type')}
                        multiple={false}
                        name="payType"
                        options={[{ payType: 'Earning', values: 'Earning' }, { payType: 'Deduction', values: 'Deduction' }, { payType: 'Non-Payable', values: 'Non-Payable' }]}
                        placeholder="Select an option"
                        value={[{ payType: 'Earning', values: 'Earning' }, { payType: 'Deduction', values: 'Deduction' }, { payType: 'Deduction', values: 'Deduction' }, { payType: 'Non-Payable', values: 'Non-Payable' }]?.find((o:any) => o?.values === values?.payType) || {}}
                        valueKey="values"
                        onChange={(text:any) => {
                          handleOnChange('payType', text?.values)
                        }}
                      />
                    </Grid>
                    <Grid item md={2} sm={1} xs={1}>
                      <OPRSelectorControl
                        error={errors?.incomeType}
                        isEditable={isEditable}
                        keyName="incomeType"
                        label={t('pay_item_income_type')}
                        multiple={false}
                        name="incomeType"
                        options={[{ incomeType: 'Recurring Income', values: 'Recurring Income' }, { incomeType: 'Non-Recurring Income', values: 'Non-Recurring Income' }]}
                        placeholder="Select an option"
                        value={[{ incomeType: 'Recurring Income', values: 'Recurring Income' }, { incomeType: 'Non-Recurring Income', values: 'Non-Recurring Income' }]?.find((o:any) => o?.values === values?.incomeType) || {}}
                        valueKey="values"
                        onChange={(text:any) => {
                          handleOnChange('incomeType', text?.values)
                        }}
                      />
                    </Grid>
                    <Grid item md={2} sm={1} xs={1}>
                      <OPRSelectorControl
                        error={errors?.unitBase}
                        isEditable={isEditable}
                        keyName="unitBase"
                        label={t('pay_item_unit_base')}
                        multiple={false}
                        name="unitBase"
                        options={[{ unitBase: 'Day', values: 'Day' }, { unitBase: 'Hour', values: 'Hour' }, { unitBase: 'Unit', values: 'Unit' }, { unitBase: 'Not Available', values: 'Not Available' }]}
                        placeholder="Select an option"
                        value={[{ unitBase: 'Day', values: 'Day' }, { unitBase: 'Hour', values: 'Hour' }, { unitBase: 'Unit', values: 'Unit' }, { unitBase: 'Not Available', values: 'Not Available' }]?.find((o:any) => o?.values === values?.unitBase) || {}}
                        valueKey="values"
                        onChange={(text:any) => {
                          handleOnChange('unitBase', text?.values)
                        }}
                      />
                    </Grid>
                    <Grid item md={2} sm={1} xs={1}>
                      <OPRSelectorControl
                        error={errors?.formulaType}
                        isEditable={isEditable}
                        keyName="formulaCode"
                        label={t('pay_item_formula_type')}
                        multiple={false}
                        name="formulaType"
                        optionalText="optional"
                        options={(allFormulatype?.records || [])}
                        value={(allFormulatype?.records || [])?.find((o:any) => o?.formulaCode === values?.formulaType) || {}}
                        valueKey="formulaCode"
                        onChange={(text:any) => {
                          handleOnChange('formulaType', text?.formulaCode)
                        }}
                      />
                    </Grid>

                    <Grid item md={2} sm={1} xs={1}>
                      <OPRSelectorControl
                        error={errors?.itemGroups}
                        isEditable={isEditable}
                        keyName="itemGroupCode"
                        label={t('pay_item_item_group')}
                        multiple={false}
                        name="itemGroups"
                        optionalText="optional"
                        options={(payItemGrouprData?.records || [])}
                        placeholder="Select an option"
                        value={(payItemGrouprData?.records || [])?.find((o:any) => o?.itemGroupCode === values?.itemGroups || [])}
                        valueKey="itemGroupCode"
                        onChange={(text:any) => {
                          handleOnChange('itemGroups', text?.itemGroupCode)
                        }}
                      />
                    </Grid>
                    <Grid item md={2} sm={1} xs={1}>
                      <OPRSelectorControl
                        error={errors?.payItemForBackPay}
                        isEditable={isEditable}
                        keyName="label"
                        label={t('pay_item_for_backpay')}
                        multiple={false}
                        name="payItemForBackPay"
                        optionalText="optional"
                        options={JSON.parse(
                          JSON.stringify(allData?.payItemForBackpay || []),
                        )}
                        placeholder="Select an option"
                        value={
                          { name: values?.payItemForBackPay, label: values?.payItemForBackpay }
                        }
                        // value={(allData?.payItemForBackpay || [])?.find((o:any) => o?.label === values?.payItemForBackPay)}
                        valueKey="name"
                        onChange={(text:any) => {
                          handleOnChange('payItemForBackPay', text?.label)
                        }}
                      />
                    </Grid>
                    <Grid item md={2} sm={1} xs={1}>
                      <OPRSelectorControl
                        error={errors?.payslipRemarkBackpay}
                        isEditable={isEditable}
                        keyName="payslipRemarkBackpay"
                        label={t('paySlipRemarks_ForBackPay')}
                        multiple={false}
                        name="payslipRemarkBackpay"
                        optionalText="optional"
                        options={[{ payslipRemarkBackpay: 'Split to show Backpay Month', values: 'Split to show Backpay Month' }, { payslipRemarkBackpay: 'Not required to split', values: 'Not required to split' }]}
                        placeholder="Select an option"
                        value={[{ payslipRemarkBackpay: 'Split to show Backpay Month', values: 'Split to show Backpay Month' }, { payslipRemarkBackpay: 'Not required to split', values: 'Not required to split' }]?.find((o:any) => o?.values === values?.hkPayItemDto?.payslipRemarkBackpay)}
                        valueKey="payslipRemarkBackpay"
                        onChange={(text:any) => {
                          handleOnChange('payslipRemarkBackpay', text?.values)
                        }}
                      />
                    </Grid>
                    <Grid item md={2} sm={1} xs={1}>
                      <OPRSelectorControl
                        error={errors?.paymentMethod}
                        isEditable={isEditable}
                        keyName="paymentMethodCode"
                        label={t('pay_item_payment_method')}
                        multiple={false}
                        name="paymentMethod"
                        options={(paymentMethodData?.records || [])}
                        placeholder="Select an option"
                        value={(paymentMethodData?.records || [])?.find((o:any) => o?.paymentMethodCode === values?.paymentMethod) || {}}
                        valueKey="paymentMethodCode"
                        onChange={(text:any) => {
                          handleOnChange('paymentMethod', text?.paymentMethodCode)
                        }}
                      />
                    </Grid>
                    <Grid item md={2} sm={1} xs={1}>
                      <OPRInputControl
                        error={t(errors?.displaySequence)}
                        isEditable={isEditable}
                        label="pay_item_display_sequence"
                        name="displaySequence"
                        optionalText="optional"
                        value={values?.displaySequence}
                        onChange={handleChange}
                      />
                    </Grid>
                    <Grid item md={2} sm={1} xs={1}>
                      <OPRSelectorControl
                        error={errors?.grossNetPay}
                        isEditable={isEditable}
                        keyName="grossNetPay"
                        label={t('pay_item_gross_net_pay')}
                        multiple={false}
                        name="grossNetPay"
                        options={[{ grossNetPay: 'Gross', values: 'Gross' }, { grossNetPay: 'Net', values: 'Net' }]}
                        placeholder="Select an option"
                        value={[{ grossNetPay: 'Gross', values: 'Gross' }, { grossNetPay: 'Net', values: 'Net' }]?.find((o:any) => o?.values === values?.grossNetPay) || {}}
                        valueKey="values"
                        onChange={(text:any) => {
                          handleOnChange('grossNetPay', text?.values)
                        }}
                      />
                    </Grid>
                    <div style={{ display: 'block', width: '100%', margin: '30px 20px 20px' }}>
                      <OPRLabel variant="h2">{t('hong_kong_factors')}</OPRLabel>
                    </div>
                    <Grid item md={2} sm={1} xs={1}>
                      <OPRSelectorControl
                        error={errors?.paySubType}
                        isEditable={isEditable}
                        keyName="paySubType"
                        label={t('pay_item_pay_sub_type')}
                        multiple={false}
                        name="paySubType"
                        optionalText="optional"
                        options={[{ paySubType: 'Base Salary', values: 'Base Salary' }, { paySubType: 'Overtime', values: 'Overtime' }]}
                        placeholder="Select an option"
                        value={[{ paySubType: 'Base Salary', values: 'Base Salary' }, { paySubType: 'Overtime', values: 'Overtime' }]?.find((o:any) => o?.values === values?.hkPayItemDto?.paySubType || 'Base Salary')}
                        valueKey="paySubType"
                        onChange={(text:any) => {
                          handleOnChange('paySubType', text?.values)
                        }}
                      />
                    </Grid>
                    <Grid item md={2} sm={1} xs={1}>
                      <OPRSelectorControl
                        error={errors?.taxableWage}
                        isEditable={isEditable}
                        keyName="taxableWage"
                        label={t('pay_item_taxable_wage')}
                        multiple={false}
                        name="taxableWage"
                        options={[{ taxableWage: 'Yes', values: true }, { taxableWage: 'No', values: false }]}
                        placeholder="Select an option"
                        value={[{ taxableWage: 'Yes', values: true }, { taxableWage: 'No', values: false }]?.find((o:any) => o?.values === values?.hkPayItemDto?.taxableWage)}
                        valueKey="taxableWage"
                        onChange={(text:any) => {
                          handleOnChange('taxableWage', text?.values)
                        }}
                      />
                    </Grid>
                    <Grid item md={2} sm={1} xs={1}>
                      <OPRSelectorControl
                        error={errors?.eaoRegardedWage}
                        isEditable={isEditable}
                        keyName="eaoRegardedWage"
                        label={t('pay_item_eao_regarded_wage')}
                        multiple={false}
                        name="eaoRegardedWage"
                        options={[{ eaoRegardedWage: 'Yes', values: true }, { eaoRegardedWage: 'No', values: false }]}
                        placeholder="Select an option"
                        value={[{ eaoRegardedWage: 'Yes', values: true }, { eaoRegardedWage: 'No', values: false }]?.find((o:any) => o?.values === values?.hkPayItemDto?.eaoRegardedWage)}
                        valueKey="eaoRegardedWage"
                        onChange={(text:any) => {
                          handleOnChange('eaoRegardedWage', text?.values)
                        }}
                      />
                    </Grid>
                    <Grid item md={2} sm={1} xs={1}>
                      <OPRSelectorControl
                        error={errors?.eaoCawWage}
                        isEditable={isEditable}
                        keyName="eaoCawWage"
                        label={t('pay_item_eao_caw_wage')}
                        multiple={false}
                        name="eaoCawWage"
                        options={[{ eaoCawWage: 'Yes', values: true }, { eaoCawWage: 'No', values: false }]}
                        placeholder="Select an option"
                        value={[{ eaoCawWage: 'Yes', values: true }, { eaoCawWage: 'No', values: false }]?.find((o:any) => o?.values === values?.hkPayItemDto?.eaoCawWage)}
                        valueKey="eaoCawWage"
                        onChange={(text:any) => {
                          handleOnChange('eaoCawWage', text?.values)
                        }}
                      />
                    </Grid>
                    <Grid item md={2} sm={1} xs={1}>
                      <OPRSelectorControl
                        error={errors?.calculationBasedOnCoveringPeriod}
                        isEditable={isEditable}
                        keyName="calculationBasedOnCoveringPeriod"
                        label={t('pay_item_calculation_based_on_covering_period')}
                        multiple={false}
                        name="calculationBasedOnCoveringPeriod"
                        options={[{ calculationBasedOnCoveringPeriod: 'Yes', values: true }, { calculationBasedOnCoveringPeriod: 'No', values: false }]}
                        placeholder="Select an option"
                        value={[{ calculationBasedOnCoveringPeriod: 'Yes', values: true }, { calculationBasedOnCoveringPeriod: 'No', values: false }]?.find((o:any) => o?.values === values?.hkPayItemDto?.calculationBasedOnCoveringPeriod)}
                        valueKey="calculationBasedOnCoveringPeriod"
                        onChange={(text:any) => {
                          handleOnChange('calculationBasedOnCoveringPeriod', text?.values)
                        }}
                      />
                    </Grid>
                    <Grid item md={2} sm={1} xs={1}>
                      <OPRSelectorControl
                        error={errors?.pensionFundableWage}
                        isEditable={isEditable}
                        keyName="pensionFundableWage"
                        label={t('pay_item_pension_fund_able_wage ')}
                        multiple={false}
                        name="pensionFundableWage"
                        options={[{ pensionFundableWage: 'Yes', values: true }, { pensionFundableWage: 'No', values: false }]}
                        placeholder="Select an option"
                        value={[{ pensionFundableWage: 'Yes', values: true }, { pensionFundableWage: 'No', values: false }]?.find((o:any) => o?.values === values?.hkPayItemDto?.pensionFundableWage)}
                        valueKey="pensionFundableWage"
                        onChange={(text:any) => {
                          handleOnChange('pensionFundableWage', text?.values)
                        }}
                      />
                    </Grid>

                    {values?.pensionFundableWage === true && ( // Display this field only if pensionFundableWage is true
                      <Grid item md={2} sm={1} xs={1}>
                        <OPRSelectorControl
                          error={errors?.pensionFundSchemes}
                          isEditable={isEditable}
                          keyName="pensionFundSchemeCode"
                          label={t('pay_item_pension_fund_schemes')}
                          multiple={false}
                          name="pensionFundSchemes"
                          options={(allPensionFundScheme?.records || [])}
                          placeholder="Select an option"
                          value={(allPensionFundScheme?.records || [])?.find((o:any) => o?.pensionFundSchemeCode === values?.pensionFundSchemes)}
                          valueKey="pensionFundSchemeCode"
                          onChange={(text:any) => {
                            handleOnChange('pensionFundSchemes', text?.pensionFundSchemeCode)
                          }}
                        />
                      </Grid>
                    )}
                    <div style={{ display: 'block', width: '100%', margin: '30px 20px 20px' }}>
                      <OPRLabel variant="h2">{t('hong_kong_mapping')}</OPRLabel>
                    </div>
                    <Grid item md={2} sm={1} xs={1}>
                      <OPRSelectorControl
                        error={errors?.IR56B}
                        isEditable={isEditable}
                        keyName="label"
                        label={t('pay_item_ir56b')}
                        multiple={false}
                        name="label"
                        optionalText="optional"
                        options={(allSatutoryMapping || []).map((o: any) => ({
                          value: `${o?.lineCode}`,
                          label: `${o?.lineCode} - ${o?.lineName}`,
                        }))}
                        placeholder="Select an option"
                        value={(allSatutoryMapping || [])
                          .map((o: any) => ({
                            value: `${o?.lineCode}`,
                            label: `${o?.lineCode} ${o?.lineName}`,
                          }))
                          .find((o: any) => o.value === values?.hkPayItemDto?.iR56B)}
                        valueKey="label"
                        onChange={(text: any) => {
                          handleOnChange('iR56B', text?.lineCode)
                        }}
                      />
                    </Grid>
                    <Grid item md={2} sm={1} xs={1}>
                      <OPRSelectorControl
                        error={errors?.iR56F}
                        isEditable={isEditable}
                        keyName="label"
                        label={t('pay_item_ir56f')}
                        multiple={false}
                        name="label"
                        optionalText="optional"
                        options={(allSatutoryMapping || []).map((o: any) => ({
                          value: `${o?.lineCode}`,
                          label: `${o?.lineCode} - ${o?.lineName}`,
                        }))}
                        placeholder="Select an option"
                        value={(allSatutoryMapping || [])
                          .map((o: any) => ({
                            value: `${o?.lineCode}`,
                            label: `${o?.lineCode} ${o?.lineName}`,
                          }))
                          .find((o: any) => o.value === values?.hkPayItemDto?.iR56F)}
                        valueKey="label"
                        onChange={(text:any) => {
                          handleOnChange('iR56F', text?.lineCode)
                        }}
                      />
                    </Grid>
                    <Grid item md={2} sm={1} xs={1}>
                      <OPRSelectorControl
                        error={errors?.iR56G}
                        isEditable={isEditable}
                        keyName="label"
                        label={t('pay_item_ir56g')}
                        multiple={false}
                        name="label"
                        optionalText="optional"
                        options={(allSatutoryMapping || []).map((o: any) => ({
                          value: `${o?.lineCode}`,
                          label: `${o?.lineCode} - ${o?.lineName}`,
                        }))}
                        placeholder="Select an option"
                        value={(allSatutoryMapping || [])
                          .map((o: any) => ({
                            value: `${o?.lineCode}`,
                            label: `${o?.lineCode} ${o?.lineName}`,
                          }))
                          .find((o: any) => o.value === values?.hkPayItemDto?.iR56G)}
                        valueKey="label"
                        onChange={(text:any) => {
                          handleOnChange('iR56G', text?.lineCode)
                        }}
                      />
                    </Grid>
                    <Grid item md={2} sm={1} xs={1}>
                      <OPRSelectorControl
                        error={errors?.iR56M}
                        isEditable={isEditable}
                        keyName="label"
                        label={t('pay_item_ir56m')}
                        multiple={false}
                        name="label"
                        optionalText="optional"
                        options={(allSatutoryMapping || []).map((o: any) => ({
                          value: `${o?.lineCode}`,
                          label: `${o?.lineCode} - ${o?.lineName}`,
                        }))}
                        placeholder="Select an option"
                        value={(allSatutoryMapping || [])
                          .map((o: any) => ({
                            value: `${o?.lineCode}`,
                            label: `${o?.lineCode} ${o?.lineName}`,
                          }))
                          .find((o: any) => o.value === values?.hkPayItemDto?.iR56M)}
                        valueKey="label"
                        onChange={(text:any) => {
                          handleOnChange('iR56M', text?.lineCode)
                        }}
                      />
                    </Grid>
                  </OPRResponsiveGrid>
                </Box>
              </OPRInnerFormLayout>
            </form>
          </Box>
        </CustomTabPanel>
        <CustomTabPanel index={1} value={value}>
          {/* <Box sx={{ display: 'flex' }}> */}
          <Box sx={{ display: 'flex', justifyContent: 'flex-end' }}>
            <OPRButton
              startIcon
              color="primary"
              // handleClick={() => {
              //   setSelectedPayItem(null)
              //   setIsOpen(true)
              // }}
              style={{ borderRadius: '110px' }}
              variant="text"
              onClick={handleAddClick}
            >
              {`Add  ${t('pension_fund_scheme')}`}
            </OPRButton>
          </Box>
          <OPRInnerListLayout
            Search={filterData.SearchText}
            addHandleClick={() => navigate(routes.createPensionFundScheme)}
            columns={pensionFundItemPayItemColumn(viewAcoount)}
            dataList={JSON.parse(JSON.stringify(allPensionFundSchemeItem?.records || []))}
            deleteCallBack={() => {}}
            filterData={filterData}
            isExport={false}
            isHeader={false}
            rowClickHandler={handleView}
            rowNumber={0}
            success={deletePensionFundSchemeItemSuccess}
            title={t('pension_fund_scheme')}

          />
          {/* </Box> */}
        </CustomTabPanel>
      </Box>
    </>
  )
}
