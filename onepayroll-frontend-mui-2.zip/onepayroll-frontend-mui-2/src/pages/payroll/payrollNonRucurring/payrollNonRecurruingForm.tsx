// payrollnonrecurruingform
import 'styles/style.css'

import { Box, Grid } from '@mui/material'
import { useGetAllEmployeeBankAccountQuery, useGetAllEmployeeProfileQuery } from 'api/employeeServices'
import { useGetAllCostCenterQuery } from 'api/entityServices'
import { useGetAllCurrencyQuery, useGetAllPaymentMethodQuery } from 'api/globalServices'
import {
  useGetAllPayItemMasterQuery,
  useGetAllPayrollCycleQuery,
  useGetAllPayRollNonRecurringDropDownQuery,
  useGetAllPayRollNonRecurringQuery,
  useLazyGetPayRollNonRecurringByIdQuery,
  usePayRollNonRecurringCreateMutation,
  usePayRollNonRecurringUpdateMutation,
} from 'api/payRollServices'
import { CrossIcon, TickIcon } from 'assets/svg-images/SvgComponents'
import OPRLabel from 'components/atoms/label/OPRLabel'
import { OPRConfirmationDialog, OPRConfirmationDialogProps } from 'components/molecules/OPRAlertControl/OPRConfirmationDialog'
import OPRDatePickerControl from 'components/molecules/OPRDatePickerControl/OPRDatePickerControl'
import OPRInputControl from 'components/molecules/OPRInputControl'
import OPRResponsiveGrid from 'components/molecules/OPRResponsiveGrid'
import OPRSelectorControl from 'components/molecules/OPRSelectorControl/OPRSelectorControl'
import OPRTextArea from 'components/molecules/OPRTextArea/OPRTextArea'
import { OPRInnerFormLayout } from 'components/organism/OPRInnerFormLayout'
import {
  validationSchemaPayrollNonRecurring,
} from 'constants/validate'
import { useEditable } from 'hooks/useEdit'
import useForm from 'hooks/useForm'
import { t } from 'i18next'
import { useEffect, useState } from 'react'
import { useLocation, useNavigate } from 'react-router-dom'
import { routes } from 'routes/routes'
import { formatedYearDate, generateFilterUrl, getParamsValue } from 'utils'

import MonthName from './monthsName.json'

interface MessageProps {
  text?: string;
  important?: boolean;
}

export default function PayRollNonRecurringForm() {
  const location: any = useLocation()
  const currentRoute = location.pathname
  // values are coming from the index.tsx page
  const { filterData, selectedOptions } = location.state || {}
  const { id, viewUrl } = getParamsValue(location, routes.createPayRollNonRecurring)
  // console.log(id, viewUrl, 'viewUrllllll')
  const [mode, setMode] = useState('view') // Default mode is edit
  const { isEditable, setEditable } = useEditable()
  const [selectedOption, setSelectedOption]:any = useState(null)
  const [selectedEmployeeOption, setSelectedEmployeeOption]:any = useState(null)
  const [selectedPayItemOption, setSelectedPayItemOption]:any = useState(null)
  const [formattedOptions, setFormattedOptions]:any = useState([])
  const {
    values,
    setValues,
    errors,
    handleOnChange,
    handleChange,
    setErrors,
    handleFormSubmit,
  } = useForm(validationSchemaPayrollNonRecurring)
  // console.log('ReceivedData:', filterData, selectedOptions?.PayCycleYearMonth[0].roleName)
  // values for displaying
  const PayCycleYearMonth = selectedOptions?.PayCycleYearMonth?.[0]?.roleName || 'Role name not available'
  const PayCycleCode = selectedOptions?.PayCycleCode?.[0]?.roleName || 'Role name not available'
  // Values for sending
  const PayCycleYear1 = filterData?.PayCycleYear || 'Role name not available'
  const PayCycleMonth1 = filterData?.PayCycleMonth || 'Role name not available'
  const PayCycleCode1 = filterData?.PayCycleCode || 'Role name not available'
  const navigate = useNavigate()
  const [
    createPayRollNonRecurring,
    {
      data: createdPayRollNonRecurringData,
      error: createdPayRollNonRecurringError,
      isLoading: createdPayRollNonRecurringLoading,
      isSuccess: createdPayRollNonRecurringSuccess,
      isError: createdPayRollNonRecurringIsError,
      reset,
    },
  ] = usePayRollNonRecurringCreateMutation()

  // update payrollnon recurring
  // const [
  //   updatePayrollNonrecurringbyId,
  //   {
  //     data: updatedPayrollNonrecurringByIdResponse,
  //     error: updatedPayrollNonrecurringByIdError,
  //     isLoading: updatedPayrollNonrecurringByIdLoading,
  //     isSuccess: updatedPayrollNonrecurringByIdSuccess,
  //     isError: updatedPayrollNonrecurringByIdIsError,
  //   },
  // ] = useLazyGetPayRollNonRecurringByIdQuery()

  // paycycle month
  const {
    data: payCycleMonthDropdown,
  } = useGetAllPayRollNonRecurringDropDownQuery('')

  // useEffect(() => {
  //   console.log(payCycleMonthDropdown, 'paycycle month')
  // }, [payCycleMonthDropdown])
  // payroll cycle query
  const {
    data: payCycleYearData,
  } = useGetAllPayrollCycleQuery(generateFilterUrl({ pageNumber: 1, pageSize: 1000 }))

  useEffect(() => {
    if (payCycleYearData?.records?.length > 0) {
      const initialValue = payCycleYearData.records.find((record:any) => record.payCycleYear === values?.payCycleYear
        && record.payCycleMonth === values?.payCycleMonth
        && record.payCycleCode === values?.payCycleCode)
      if (initialValue) {
        setSelectedOption({
          id: initialValue.id,
          label: `${initialValue.payCycleYear}-${initialValue.payCycleMonth}-${initialValue.payCycleCode}`,
          value: `${initialValue.payCycleYear}-${initialValue.payCycleMonth}-${initialValue.payCycleCode}`,
        })
      }
    }
  }, [payCycleYearData, values?.payCycleYear, values?.payCycleMonth, values?.payCycleCode])

  const options = (payCycleYearData?.records || []).map((record:any) => ({
    id: record.id,
    label: `${record.payCycleYear}-${record.payCycleMonth}-${record.payCycleCode}`,
    value: `${record.payCycleYear}-${record.payCycleMonth}-${record.payCycleCode}`,
  }))

  const handleOptionChange = (selectedOption:any) => {
    const [payCycleYear, payCycleMonth, payCycleCode] = selectedOption.value.split('-')
    setSelectedOption(selectedOption)
    setValues({
      ...values,
      payCycleYear,
      payCycleMonth,
      payCycleCode,
    })
  }

  // console.log(selectedOptions?.PayCycleYearMonth, 'selectedOptions')

  // const options = (payCycleYearData?.records || []).map((record:any) => ({
  //   id: record.id,
  //   value: `${record.payCycleYear}${record.payCycleMonth}${record.payCycleCode}`,
  //   label: `${record.payCycleYear}${record.payCycleMonth}${record.payCycleCode}`, // Combine the fields for display
  //   payCycleYear: record.payCycleYear,
  //   payCycleMonth: record.payCycleMonth,
  //   payCycleCode: record.payCycleCode,
  // }))

  // // Find the selected option based on the combined label
  // const selectedOption = options.find(
  //   (option:any) => option.payCycleYear === values?.payCycleYear
  //     && option.payCycleMonth === values?.payCycleMonth
  //     && option.payCycleCode === values?.payCycleCode,
  // )

  // console.log(payCycleYearData, 'payCycleYearData')

  //   country data
  const {
    data: allData,

  } = useGetAllCurrencyQuery(generateFilterUrl({ pageNumber: 1, pageSize: 1000 }))

  useEffect(() => {
    // Format the options by combining currency code and name
    const formatted = (allData?.records || []).map((option:any) => ({
      ...option,
      label: `${option.currencyCode} - ${option.currencyName}`,
    }))
    setFormattedOptions(formatted)
  }, [allData])
  // cost center data
  const {
    data: costcenterData,
  } = useGetAllCostCenterQuery(generateFilterUrl({ pageNumber: 1, pageSize: 1000 }))

  // employee bank account
  const {
    data: empbankaccountdata,
  } = useGetAllEmployeeBankAccountQuery(generateFilterUrl({ pageNumber: 1, pageSize: 1000 }))

  // useGetAllPaymentMethodQuery
  const {
    data: allDataPaymentMethod,
  } = useGetAllPaymentMethodQuery(generateFilterUrl({ pageNumber: 1, pageSize: 1000 }))

  //   payrollnon recurring
  const {
    data: allDataPayrollNonRecurring,

  } = useGetAllPayRollNonRecurringQuery(generateFilterUrl({ pageNumber: 1, pageSize: 1000 }))

  //   useGetAllEmployeeProfileQuery
  const {
    data: employeeCodeData,
  } = useGetAllEmployeeProfileQuery(generateFilterUrl({ pageNumber: 1, pageSize: 1000 }))

  console.log(employeeCodeData, 'employeeCodeData')

  useEffect(() => {
    if (employeeCodeData?.records?.length > 0) {
      const initialValue = employeeCodeData.records.find((record:any) => record.employeeCode === values?.employeeCode)
      if (initialValue) {
        setSelectedEmployeeOption({
          id: initialValue.id,
          label: `${initialValue.employeeCode} - ${initialValue.employeeProfile.givenName}`,
          value: initialValue.employeeCode,
        })
      }
    }
  }, [employeeCodeData, values?.employeeCode])

  const employeeOptions = (employeeCodeData?.records || []).map((record:any) => ({
    id: record.id,
    label: `${record.employeeCode} - ${record.employeeProfile.givenName}`,
    value: record.employeeCode,
    name: record.employeeProfile.givenName,
  }))

  const handleEmployeeOptionChange = (selectedOption:any) => {
    setSelectedEmployeeOption(selectedOption)
    setValues({
      ...values,
      employeeCode: selectedOption.value,
      employeeName: selectedOption.name,
    })
  }

  //   useGetAllPayItemMasterQuery
  const {
    data: payItemData,
  } = useGetAllPayItemMasterQuery(generateFilterUrl({ pageNumber: 1, pageSize: 1000 }))

  useEffect(() => {
    if (payItemData?.records?.length > 0) {
      const initialValue = payItemData.records.find((record:any) => record.payItemCode === values?.payItemCode)
      if (initialValue) {
        setSelectedPayItemOption({
          id: initialValue.id,
          label: `${initialValue.payItemCode} - ${initialValue.payItemName}`,
          value: initialValue.payItemCode,
        })
      }
    }
  }, [payItemData, values?.payItemCode])

  const payItemOptions = (payItemData?.records || []).map((record:any) => ({
    id: record.id,
    label: `${record.payItemCode} - ${record.payItemName}`,
    value: record.payItemCode,
    name: record.payItemName,
  }))

  const handlePayItemOptionChange = (selectedOption:any) => {
    setSelectedPayItemOption(selectedOption)
    setValues({
      ...values,
      payItemCode: selectedOption.value,
      payItemName: selectedOption.name,
    })
  }

  const [
    updatePayRollNonRecurring,
    {
      data: updatedDataResponse,
      error: updatedPayRollNonRecurringError,
      isLoading: updatedPayRollNonRecurringLoading,
      isSuccess: updatedPayRollNonRecurringSuccess,
      isError: updatedPayRollNonRecurringIsError,
    },
  ] = usePayRollNonRecurringUpdateMutation()

  const [
    updatePayRollNonRecurringById,
    {
      data: updatedPayRollNonRecurringByIdResponse,
      error: updatedPayRollNonRecurringByIdError,
      isLoading: updatedPayRollNonRecurringByIdLoading,
      isSuccess: updatedPayRollNonRecurringByIdSuccess,
      isError: updatedPayRollNonRecurringByIdIsError,
    },
  ] = useLazyGetPayRollNonRecurringByIdQuery(generateFilterUrl({ pageNumber: 1, pageSize: 1000 }))

  const updatePayCycle = updatedPayRollNonRecurringByIdResponse?.data?.payCycle

  const [confirmDialog, setConfirmDialog] = useState<OPRConfirmationDialogProps>({
    open: false,
    buttonLayout: 'confirm',
    title: '',
    message: '',
  })

  // const {
  //   data: payCycleMasterData,

  // } = useGetAllPayrollCycleQuery(generateFilterUrl({ pageNumber: 1, pageSize: 1000 }))

  useEffect(() => {
    if (id) {
      updatePayRollNonRecurringById(id)
      setEditable(viewUrl)
      // setMode('view') // Set mode to view if id is present
    }
  }, [])
  useEffect(() => {
    if (id) {
      setValues(updatedPayRollNonRecurringByIdResponse?.data)
      // navigate(`${routes.editPayRollNonRecurring}`, {
      //   state: { filterData, selectedOptions },
      //   // id: updatedPayRollNonRecurringByIdResponse?.data?.id,
      // })
    } else {
      setValues(location.state ? location.state : {})
    }
  }, [updatedPayRollNonRecurringByIdResponse?.data])

  // reset the values
  // useEffect(() => {
  //   if (createdPayRollNonRecurringSuccess) {
  //     setValues({})
  //   }
  // }, [createdPayRollNonRecurringSuccess])

  const handleSubmit: any = async () => {
    if (isEditable) {
      // Ensure month and day are two digits
      // const payCycleMonth = values.payCycleMonth.toString().padStart(2, '0')
      // const payCycleDay = values.payCycleCode.substr(-2) // Adjust this part if you need a specific day
      // const payCycle = `${values.payCycleYear}${payCycleMonth}${payCycleDay}`
      const payCycle = `${PayCycleYear1}${PayCycleMonth1}${PayCycleCode1}`

      const payload = {
        payCycle,
        employeeCode: values?.employeeCode,
        employeeName: values?.employeeName,
        payItemCode: values?.payItemCode,
        payItemName: values?.payItemName,
        ratePerUnit: values?.ratePerUnit,
        quantity: values?.quantity,
        transactionAmount: values?.transactionAmount,
        originalCurrency: values?.originalCurrency,
        paymentCurrency: values?.paymentCurrency,
        exchangeRate: values?.exchangeRate,
        paymentMethod: values?.paymentMethod,
        employeeBankAccount: values?.employeeBankAccount,
        costCenterCode: values?.costCenterCode,
        coveringStartDate: values?.coveringStartDate ? formatedYearDate(values?.coveringStartDate) : null,
        coveringEndDate: values?.coveringEndDate ? formatedYearDate(values?.coveringEndDate) : null,
        reportingPeriodYear: values?.reportingPeriodYear,
        reportingPeriodMonth: values?.reportingPeriodMonth?.label,
        remarks: values?.remarks || '',
      }
      if (id === null) {
        await createPayRollNonRecurring(payload)
      } else {
        await updatePayRollNonRecurring({
          id: values?.id,
          // payCycleYear: values?.payCycleYear,
          // payCycleMonth: values?.payCycleMonth,
          // payCycleCode: values?.payCycleCode,
          payCycle: updatePayCycle,
          employeeCode: values?.employeeCode,
          employeeName: values?.employeeName,
          payItemCode: values?.payItemCode,
          payItemName: values?.payItemName,
          ratePerUnit: values?.ratePerUnit,
          quantity: values?.quantity,
          transactionAmount: values?.transactionAmount,
          originalCurrency: values?.originalCurrency,
          paymentCurrency: values?.paymentCurrency,
          exchangeRate: values?.exchangeRate,
          paymentMethod: values?.paymentMethod,
          employeeBankAccount: values?.employeeBankAccount,
          costCenterCode: values?.costCenterCode,
          coveringStartDate: values?.coveringStartDate ? formatedYearDate(values?.coveringStartDate) : null,
          coveringEndDate: values?.coveringEndDate ? formatedYearDate(values?.coveringEndDate) : null,
          reportingPeriodYear: values?.reportingPeriodYear,
          reportingPeriodMonth: values?.reportingPeriodMonth?.label,
          remarks: values?.remarks || '',
        })
      }
    } else {
      setEditable(true)
    }
  }
  console.log('hiiiiii', values?.reportingPeriodMonth?.label)

  const handleAddAnotherClick = () => {
    setEditable(true)
    setValues(location.state ? location.state : {})
    setSelectedEmployeeOption(null)
    setSelectedPayItemOption(null)
    reset()
    setConfirmDialog((prevDialog) => ({ ...prevDialog, open: false }))
  }

  const createDialog = () => {
    setConfirmDialog(() => ({
      open: true,
      icon: <CrossIcon />,
      buttonLayout: 'try-again',
      error: (createdPayRollNonRecurringError || updatedPayRollNonRecurringError),
      title: ((id) ? t('Failed to update non-recurring item') : t('Failed to add non-recurring item')),
      onClose: () => {
        setConfirmDialog((prevDialog) => ({
          ...prevDialog,
          open: true,
          buttonLayout: 'confirm',
          infoMessage: t('Are you sure you want to quit without saving your changes? Any unsaved progress will be lost.'),
          title: t('Are you sure you want to quit?'),
          onConfirm: () => {
            setConfirmDialog((prevDialog) => ({ ...prevDialog, open: false }))
            navigate(`/${routes.payRollNonRecurring}`)
          },
          onCancel: () => {
            setConfirmDialog((prevDialog) => ({ ...prevDialog, open: false }))
            createDialog()
          },
        }))
      },
      onTryAgain: () => {
        setConfirmDialog((prevDialog) => ({ ...prevDialog, open: false }))
        handleSubmit()
      },
      onBack: () => {
        setConfirmDialog((prevDialog) => ({ ...prevDialog, open: false }))
      },
    }))
  }

  useEffect(() => {
    if (createdPayRollNonRecurringSuccess || updatedPayRollNonRecurringSuccess) {
      let title: string | null = null
      let message: React.ReactNode | null = null
      let addAnotherButtonTitle: string | null = null
      if (!id) {
        title = 'New non-recurring item added'
        message = (
          <>
            <strong>{values?.payItemName}</strong>
            {' '}
            {t('has been added to')}
            {' '}
            <strong>{values?.employeeName}</strong>
            .
          </>
        )
        addAnotherButtonTitle = t('Add another non-recurring item')
      } else {
        title = 'Non-recurring item updated'
        message = (
          <>
            <strong>{t('Pay Cycle:')}</strong>
            {' '}
            <strong>{values?.payCycle}</strong>
            {' '}
            {t('has been updated.')}
          </>
        )
        addAnotherButtonTitle = null
      }
      setConfirmDialog(() => ({
        open: true,
        icon: <TickIcon />,
        buttonLayout: (id ? 'close' : 'add-another'),
        title,
        message,
        addAnotherButtonTitle,
        onClose: () => {
          setConfirmDialog((prevDialog) => ({ ...prevDialog, open: false }))
          navigate(`/${routes.payRollNonRecurring}`)
        },
        onAddAnother: () => {
          handleAddAnotherClick()
          // window.location.reload()
        },
      }))
    }
    if (createdPayRollNonRecurringError || updatedPayRollNonRecurringError) {
      createDialog()
    }
  }, [
    createdPayRollNonRecurringSuccess,
    updatedPayRollNonRecurringSuccess,
    createdPayRollNonRecurringError,
    updatedPayRollNonRecurringError,
  ])
  async function editPayRollNonRecurring() {
    await updatePayRollNonRecurring({
      id: values?.id,
      // payCycleYear: values?.payCycleYear,
      // payCycleMonth: values?.payCycleMonth,
      // payCycleCode: values?.payCycleCode,
      payCycleCode: `${values.payCycleYear}-${values.payCycleMonth}(${values.payCycleCode.substr(-3, 2)})`,
      employeeCode: values?.employeeCode,
      payItemCode: values?.payItemCode,
      ratePerUnit: values?.ratePerUnit,
      quantity: values?.quantity,
      transactionAmount: values?.transactionAmount,
      originalCurrency: values?.originalCurrency,
      paymentCurrency: values?.paymentCurrency,
      exchangeRate: values?.exchangeRate,
      paymentMethod: values?.paymentMethod,
      employeeBankAccount: values?.employeeBankAccount,
      costCenterCode: values?.costCenterCode,
      coveringStartDate: values?.coveringStartDate ? formatedYearDate(values?.coveringStartDate) : null,
      coveringEndDate: values?.coveringEndDate ? formatedYearDate(values?.coveringEndDate) : null,
      reportingPeriodYear: values?.reportingPeriodYear,
      reportingPeriodMonth: values?.reportingPeriodMonth?.label,
      remarks: values?.remarks || '',
    })
  }

  const onScreenClose:any = (item: any) => {
    setEditable(item)
    setValues({})
  }
  console.log(createdPayRollNonRecurringSuccess, 'createdPayRollNonRecurringSuccess')
  console.log(createPayRollNonRecurring, 'createPayRollNonRecurring')
  console.log(confirmDialog, 'comfirmDialogcomfirmDialogcomfirmDialog')
  // const { selectedPayCycleYearMonth } = location.state
  // const { selectedPayCycleCode } = location.state
  return (
    <Box sx={{ display: 'flex' }}>
      <form
        style={{ display: 'flex', width: '100% ' }}
        onSubmit={(e) => handleFormSubmit(e, handleSubmit)}
      >
        <OPRConfirmationDialog
          key="confirmation-dialog"
          titleSx={{
            '&::first-letter': {
              textTransform: 'capitalize',
            },
          }}
          {...confirmDialog}
        />

        <OPRInnerFormLayout
          error={createdPayRollNonRecurringError || updatedPayRollNonRecurringError}
          handleCancelClick={() => navigate(-1)}
          handleContinueClick={handleSubmit}
          handleEditable={() => {
            setEditable(true)
          }}
          isBackButton={isEditable}
          isLoading={
            createdPayRollNonRecurringLoading
            || updatedPayRollNonRecurringLoading
            || updatedPayRollNonRecurringByIdLoading
          }
          pageType="detailsPage"
          subtitle={
            isEditable
              ? 'Please check the user details below.'
              : 'All fields are mandatory except those marked optional'
          }
          title={(viewUrl) ? t('PayRollNonRecurring') : false || ((id) ? values?.PayRollNonRecurringDescription : t('Add non-recurring item'))} // Set title based on mode
          onScreenClose={onScreenClose}

        >
          <Box>
            <OPRResponsiveGrid>
              <Grid item xs={12}>
                <div className="ServiceProvider">
                  General information
                </div>
              </Grid>
              {/* payCycleYear */}
              <Grid item md={4} sm={6} xs={12}>
                <OPRLabel>
                  {t('Pay cycle')}
                </OPRLabel>
                {
                  id ? (

                    <div>
                      {/* abcd */}
                      {updatePayCycle}
                    </div>

                  ) : (
                    <div>

                      {PayCycleYearMonth}
                      {' '}
                      -
                      {PayCycleCode}
                    </div>
                  )
                }

              </Grid>

              {/* EmployeeCode */}
              <Grid item md={4} sm={6} xs={12}>
                {/* employeeCodeData */}
                <OPRSelectorControl
                  error={errors?.employeeCode}
                  isEditable={isEditable}
                  keyName="label"
                  label="Employee"
                  multiple={false}
                  name="employeeCode"
                  options={employeeOptions}
                  placeholder="Select an option"
                  value={selectedEmployeeOption}
                  valueKey="label"
                  onChange={handleEmployeeOptionChange}
                  // onChange={(text:any) => {
                  //   // handleChange({ target: { name: 'countryLocalization', value: text?.countryCode }, persist: () => {} })
                  //   setValues({ ...values, employeeCode: text.employeeCode })
                  // }}
                />
              </Grid>

              {/* payitem */}
              <Grid item md={4} sm={6} xs={12}>
                {/* payItemCode */}
                <OPRSelectorControl
                  error={errors?.payItemCode}
                  isEditable={isEditable}
                  keyName="label"
                  label="Pay Item"
                  multiple={false}
                  name="payItemCode"
                  options={payItemOptions}
                  placeholder="Select an option"
                  value={selectedPayItemOption}
                  valueKey="label"
                  onChange={handlePayItemOptionChange}
                  // onChange={(text:any) => {
                  //   setValues({ ...values, payItemCode: text?.payItemCode })
                  // }}
                />
              </Grid>
              {/* rate per unit */}
              <Grid item md={2} sm={1} xs={1}>
                <OPRInputControl
                  error={errors?.ratePerUnit}
                  isEditable={isEditable}
                  label={t('Rate per unit')}
                  name="ratePerUnit"
                  optionalText="optional"
                  value={values?.ratePerUnit}
                  onChange={handleChange}
                />
              </Grid>
              {/* Quantity */}
              <Grid item md={2} sm={1} xs={1}>
                <OPRInputControl
                  error={errors?.quantity}
                  isEditable={isEditable}
                  label={t('Quantity')}
                  name="quantity"
                  value={values?.quantity}
                  onChange={handleChange}
                />
              </Grid>
              {/* Transaction Amount */}
              <Grid item md={2} sm={1} xs={1}>
                <OPRInputControl
                  error={errors?.transactionAmount}
                  isEditable={isEditable}
                  label={t('Transaction Amount')}
                  name="transactionAmount"
                  optionalText="optional"
                  value={values?.transactionAmount}
                  onChange={handleChange}
                />
              </Grid>
              {/* original currency */}
              <Grid item md={2} sm={1} xs={1}>
                <OPRSelectorControl
                  error={errors?.originalCurrency}
                  isEditable={isEditable}
                  keyName="label"
                  label="Original Currency"
                  multiple={false}
                  name="originalCurrency"
                  options={formattedOptions}
                  placeholder="Select an option"
                  value={formattedOptions.find((o:any) => o.currencyCode === values?.originalCurrency)}
                  valueKey="label"
                  onChange={(text:any) => handleOnChange('originalCurrency', text?.currencyCode)}
                  // onChange={(text:any) => {
                  //   // handleChange({ target: { name: 'countryLocalization', value: text?.countryCode }, persist: () => {} })
                  //   setValues({ ...values, originalCurrency: text?.currencyCode })
                  // }}
                />

              </Grid>
              {/* remarks */}
              <Grid item md={4} sm={6} xs={12}>
                <OPRTextArea
                  error={errors?.remarks}
                  isEditable={isEditable}
                  label={t('Payslip remarks')}
                  name="remarks"
                  optionalText="optional"
                  value={values?.remarks}
                  onChange={handleChange}
                />
              </Grid>
              {/* covering start date */}
              <Grid item md={2} sm={1} xs={1}>
                <OPRDatePickerControl
                  error={errors?.coveringStartDate}
                  isEditable={isEditable}
                  label={t('Covering start date')}
                  name="coveringStartDate"
                  optionalText="optional"
                  value={values?.coveringStartDate || null}
                  // value={values?.coveringStartDate ? values?.coveringStartDate?.toISOString() : null}
                  onChange={(date) => {
                    handleOnChange('coveringStartDate', date)
                  }}
                />
              </Grid>
              {/* covering end date */}
              <Grid item md={2} sm={1} xs={1}>
                <OPRDatePickerControl
                  error={errors?.coveringEndDate}
                  isEditable={isEditable}
                  label={t('Covering end date')}
                  name="coveringEndDate"
                  optionalText="optional"
                  value={values?.coveringEndDate || null}
                  // value={values?.coveringEndDate ? values?.coveringEndDate?.toISOString() : null}
                  onChange={(date) => {
                    handleOnChange('coveringEndDate', date)
                  }}
                />
              </Grid>
              {/* Reporting period Year */}
              <Grid item md={2} sm={1} xs={1}>
                <OPRInputControl
                  error={errors?.reportingPeriodYear}
                  isEditable={isEditable}
                  label={t('Reporting period - Year')}
                  name="reportingPeriodYear"
                  value={values?.reportingPeriodYear}
                  onChange={handleChange}
                />
              </Grid>
              {/* Reporting Period Month */}
              <Grid item md={2} sm={1} xs={1}>
                {/* reportingPeriodMonth */}
                <OPRSelectorControl
                  isEditable={isEditable}
                  keyName="name"
                  label="Reporting Period - Month"
                  multiple={false}
                  name="reportingPeriodMonth"
                  options={JSON.parse(
                    JSON.stringify(MonthName?.months || []),
                  )}
                  placeholder="Select an option"
                  value={values?.reportingPeriodMonth}
                  valueKey="name"
                  onChange={(text:any) => {
                    handleOnChange('reportingPeriodMonth', text)
                    // handleChange({ target: { name: 'countryLocalization', value: text?.countryCode }, persist: () => {} })
                    // setValues({ ...values, reportingPeriodMonth: text?.label })
                  }}
                />
              </Grid>

              <Grid item xs={12}>
                <div className="ServiceProvider">
                  Payment information
                </div>
              </Grid>

              {/* payment currency */}
              <Grid item md={2} sm={1} xs={1}>
                <OPRSelectorControl
                  error={errors?.paymentCurrency}
                  isEditable={isEditable}
                  keyName="label"
                  label="Payment Currency"
                  multiple={false}
                  name="paymentCurrency"
                  options={formattedOptions}
                  placeholder="Select an option"
                  value={formattedOptions.find((o:any) => o.currencyCode === values?.paymentCurrency)}
                  valueKey="label"
                  onChange={(text:any) => handleOnChange('paymentCurrency', text?.currencyCode)}
                  // onChange={(text:any) => {
                  //   // handleChange({ target: { name: 'countryLocalization', value: text?.currencyCode }, persist: () => {} })
                  //   setValues({ ...values, paymentCurrency: text?.currencyCode })
                  // }}
                />

              </Grid>
              {/* exchange rate */}
              <Grid item md={2} sm={1} xs={1}>
                <OPRInputControl
                  error={errors?.exchangeRate}
                  isEditable={isEditable}
                  label={t('Exchange Rate')}
                  name="exchangeRate"
                  optionalText="optional"
                  value={values?.exchangeRate}
                  onChange={handleChange}
                />
              </Grid>
              {/* payment method */}
              <Grid item md={2} sm={1} xs={1}>
                {isEditable
                  ? (
                    <Box
                      sx={{
                        display: 'flex',
                        flexDirection: 'column',
                        alignItems: 'flex-start',
                        gap: '4px',
                        flex: '1 0 0',
                      }}
                    >
                      <OPRLabel
                        CustomStyles={{
                          display: 'flex',
                          alignItems: 'flex-start',
                          gap: '0px',
                          alignSelf: 'stretch',

                        }}
                      >
                        {t('Payment method')}
                      </OPRLabel>
                      <OPRLabel
                        CustomStyles={{
                          display: 'flex',
                          alignItems: 'flex-start',
                          gap: '8px',
                          alignSelf: 'stretch',
                        }}
                        variant="body2"
                      >
                        <br />
                        {values?.paymentMethod}
                      </OPRLabel>
                    </Box>
                  ) : (
                    <OPRSelectorControl
                      isEditable={isEditable}
                      keyName="paymentMethodCode"
                      label="Payment method"
                      multiple={false}
                      name="paymentMethod"
                      optionalText="optional"
                      options={(allDataPaymentMethod?.records || [])}
                      placeholder="Select an option"
                      value={(allDataPaymentMethod?.records || []).find((o:any) => o.paymentMethodCode === values?.paymentMethod)}
                      valueKey="paymentMethod"
                      onChange={(text:any) => {
                        // setValues({ ...values, paymentMethod: text?.paymentMethodCode })
                        handleOnChange('paymentMethod', text?.paymentMethodCode)
                      }}
                    />
                  )}

              </Grid>
              {/* Employee bank account */}
              <Grid item md={2} sm={1} xs={1}>
                {isEditable ? (
                  <Box
                    sx={{
                      display: 'flex',
                      flexDirection: 'column',
                      alignItems: 'flex-start',
                      gap: '4px',
                      flex: '1 0 0',
                    }}
                  >
                    <OPRLabel
                      CustomStyles={{
                        display: 'flex',
                        alignItems: 'flex-start',
                        gap: '0px',
                        alignSelf: 'stretch',

                      }}
                    >
                      {t('Employee bank account')}
                    </OPRLabel>
                    <OPRLabel
                      CustomStyles={{
                        display: 'flex',
                        alignItems: 'flex-start',
                        gap: '8px',
                        alignSelf: 'stretch',
                      }}
                      variant="body2"
                    >
                      <br />
                      {values?.employeeBankAccount}
                    </OPRLabel>
                  </Box>
                ) : (
                  <OPRSelectorControl
                    isEditable={isEditable}
                    keyName="accountNumber"
                    label="Employee bank account"
                    multiple={false}
                    name="employeeBankAccount"
                    optionalText="optional"
                    options={(empbankaccountdata?.records || [])}
                    placeholder="Select an option"
                    value={(empbankaccountdata?.records || []).find((o:any) => o.accountNumber === values?.employeeBankAccount)}
                    valueKey="accountNumber"
                    onChange={(text:any) => {
                    // handleChange({ target: { name: 'countryLocalization', value: text?.countryCode }, persist: () => {} })
                      // setValues({ ...values, employeeBankAccount: text?.accountNumber })
                      handleOnChange('employeeBankAccount', text?.accountNumber)
                    }}
                  />
                ) }

              </Grid>
              {/* Cost Center */}
              <Grid item md={2} sm={1} xs={1}>
                <OPRSelectorControl
                  isEditable={isEditable}
                  keyName="costCenterCode"
                  label="Cost Center"
                  multiple={false}
                  name="costCenterCode"
                  optionalText="optional"
                  options={(costcenterData?.records || [])}
                  placeholder="Select an option"
                  value={(costcenterData?.records || []).find((o:any) => o.costCenterCode === values?.costCenterCode)}
                  valueKey="costCenterCode"
                  onChange={(text:any) => {
                    // handleChange({ target: { name: 'countryLocalization', value: text?.countryCode }, persist: () => {} })
                    setValues({ ...values, costCenterCode: text?.costCenterCode })
                  }}
                />
              </Grid>
            </OPRResponsiveGrid>

          </Box>
        </OPRInnerFormLayout>
      </form>
    </Box>
  )
}
