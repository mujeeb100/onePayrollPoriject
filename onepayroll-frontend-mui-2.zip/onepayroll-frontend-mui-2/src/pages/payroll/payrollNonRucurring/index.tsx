import {
  Box,
} from '@mui/material'
import { useGetAllEmployeeProfileQuery } from 'api/employeeServices'
import { useGetAllEntityProfileSelectedListByIdQuery } from 'api/entityServices'
import {
  useGetAllPayItemMasterQuery, usePayCycleMasterSearchFilterCreateMutation, usePayRollNonRecurringDeleteMutation,
  usePayRollNonRecurringSearchCreateMutation,
} from 'api/payRollServices'
import { CrossIcon } from 'assets/svg-images/SvgComponents'
import OPRButton from 'components/atoms/button/OPRButton'
import OPRLabel from 'components/atoms/label/OPRLabel'
import MultipleSelectCheckmarks from 'components/atoms/multiSelectCheckbox'
import OPRSelectCheckbox from 'components/atoms/multiSelectCheckbox/OPRSelectCheckbox'
import { payrollNoRecurringSearchColumn } from 'components/atoms/table/OPRTableConstant'
import { OPRInnerListLayout } from 'components/organism/OPRInnerLayoutList'
import apiEndPoint from 'constants/apiEndPoint'
import { PayRollNonRecurringColumnMappings } from 'constants/exportColumnMappings'
import { useTranslatedColumnsForPDF } from 'hooks/useTranslatedColumnsForPDF'
import { t } from 'i18next'
import React, { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { routes } from 'routes/routes'
import {
  generateFilterUrl, getAPIWithEntityUrl, getEnv, setRouteValues,
} from 'utils'

interface Option {
  roleCode: string
  roleName: string
}

interface SelectedOptions {
  PayCycleYearMonth: Option[]
  EmployeeCode: Option[]
  PayItemCode: Option[]
  EmployeeName: Option[]
  PayCycleCode: Option[]
  PayCycleYear: Option[]
  PayCycleMonth: Option[]
}

function PayRollNonRecurringList() {
  const navigate: any = useNavigate()
  // const [employeeCode, setEmployeeCode]:any = useState([])
  const [clearFilters, setClearFilters]:any = useState(false)
  const [selectedEntity, setSelectEntity]:any = useState([])
  // for add and export
  const [isExportVisible, setIsExportVisible] = useState(false)
  const [addHandleClickVisible, setAddHandleClickVisible] = useState(false)
  const [selectedOptions, setSelectedOptions]:any = useState<SelectedOptions>(
    {
      PayCycleYearMonth: [],
      EmployeeCode: [],
      PayItemCode: [],
      EmployeeName: [],
      PayCycleCode: [],
      PayCycleYear: [],
      PayCycleMonth: [],
    },
  )
  const [listOfOptions, setListOfOptions]:any = useState<any>({
    PayCycleYearMonth: [],
    EmployeeCode: [],
    PayItemCode: [],
    // EmployeeName: [], // Add EmployeeName option
    PayCycleCode: [],
  })
  const [selelctedDelete, setSelelctedDelete]:any = useState({
    data: {},
    isDelete: false,
    name: '',
  })
  const [filterData, setFilterData]:any = useState({
    pageNumber: 1,
    pageSize: 50,
    totalItems: 0,
    orderByAsc: true,
    sortBy: '',
    SearchText: '',
    PayCycleYear: '', // 2024
    PayCycleMonth: '', // 03
    PayCycleCode: '', // 01
    EmployeeCode: null, // Add Employee E01099
    // EmployeeCode: [''],
    PayItemCode: '', // null default
  })

  const employeeCodeURl = () => ''

  // const {
  //   data: allPosts,
  //   isLoading: isLoadingAllPosts,
  //   isSuccess: isSuccessAllPosts,
  //   isError: isErrorAllPosts,
  //   error: errorAllPosts,
  //   refetch: refetchAllPosts,
  // } = useGetAllPayRollNonRecurringQuery(generateFilterUrl(filterData))

  // } = useGetAllPayRollNonRecurringSearchQuery(`${generateFilterUrl(filterData)}&${employeeCodeURl}`)
  // entity profile
  const {
    data: EntityProfileByIdResponse,
    error: EntityProfileByIdError,
    isLoading: EntityProfileByIdLoading,
    isSuccess: EntityProfileByIdSuccess,
    isError: EntityProfileByIdIsError,
  } = useGetAllEntityProfileSelectedListByIdQuery('')

  const
    [createPayrollNonRecurringSearch,
      {
        data: allPosts,
        isLoading: isLoadingAllPosts,
        isSuccess: isSuccessAllPosts,
        isError: isErrorAllPosts,
        error: errorAllPosts,
        refetch: refetchAllPosts,
      },
    ] = usePayRollNonRecurringSearchCreateMutation()

  const [deletePayRollNonRecurringById,
    {
      data: deletePayRollNonRecurringResponse,
      error: deletePayRollNonRecurringError,
      isLoading: deletePayRollNonRecurringLoading,
      isSuccess: deletePayRollNonRecurringSuccess,
      isError: deletePayRollNonRecurringIsError,
    }] = usePayRollNonRecurringDeleteMutation()

  // employe profile
  const {
    data: allPostEmployeeData,
    isLoading: isLoadingAllPostsEmployeeData,
    isSuccess: isSuccessAllPostsEmployeeData,
    isError: isErrorAllPostsEmployeeData,
    error: errorAllPostsEmployeeData,
  } = useGetAllEmployeeProfileQuery(generateFilterUrl({ pageNumber: 1, pageSize: 1000 }))

  // PayItemMaster
  const {
    data: allPayItemMasterData,
    isLoading: isLoadingAllPayItemMasterData,
    isSuccess: isSuccessAllPayItemMasterData,
    isError: isErrorAllPayItemMasterData,
    error: errorAllPayItemMasterData,
  } = useGetAllPayItemMasterQuery(generateFilterUrl({ pageNumber: 1, pageSize: 1000 }))

  // PayCycle Master data Post API
  const
    [createPayCycleMasterData,
      {
        data: payCycleYearData,
      },
    ] = usePayCycleMasterSearchFilterCreateMutation()
  // const {
  //   data: payCycleYearData,
  // } = useGetAllPayrollCycleQuery(generateFilterUrl({ pageNumber: 1, pageSize: 1000 }))

  useEffect(() => {
    // Define the request body
    const requestBody = {
      pageSize: 1000,
      pageNumber: 1,
      sortBy: '',
      orderByAsc: true,
      // "payCycleType": [2]
    }

    // Call the API
    createPayCycleMasterData(requestBody)
  }, [createPayCycleMasterData])

  useEffect(() => {
    if (allPosts?.data?.totalItems !== undefined) {
      setFilterData((prev:any) => ({ ...prev, totalItems: allPosts?.data?.totalItems }))
    }
  }, [allPosts])

  useEffect(() => {
    if (allPostEmployeeData && allPayItemMasterData && payCycleYearData) {
      const uniquePayCycleYears = Array.from(new Set(payCycleYearData?.records?.map((item: any) => item.payCycleYear) || []))
      const uniquePayCycleMonths = Array.from(new Set(payCycleYearData?.records?.map((item: any) => item.payCycleMonth) || []))

      const payCycleYearOptions = uniquePayCycleYears.map((year) => ({
        roleCode: year,
        roleName: year,
      }))

      const payCycleMonthOptions = uniquePayCycleMonths.map((month) => ({
        roleCode: month,
        roleName: month,
      }))

      // Create combined options
      const payCycleYearMonthOptions = uniquePayCycleYears.flatMap((year) => uniquePayCycleMonths.map((month) => ({
        roleCode: `${year}${month}`,
        roleName: `${year}-${month}`,
      })))

      const employeeNameOption = allPostEmployeeData?.records?.map((item: any) => ({
        roleCode: item.employeeCode, // Assuming employeeCode is unique
        roleName: item.employeeCode || item?.employeeProfile?.givenName, // Use givenName for the display name, fall back to employeeCode
      }))

      const payItemCodeOption = allPayItemMasterData?.records?.map((item: any) => ({
        roleCode: item.payItemCode,
        roleName: item.payItemCode,
      }))

      // payCycleCode
      const payCycleCodeOption = payCycleYearData?.records?.map((item: any) => ({
        roleCode: item.payCycleCode,
        roleName: item.payCycleCode,
      }))

      setListOfOptions((prev: any) => ({
        ...prev,
        PayCycleYearMonth: payCycleYearMonthOptions,
        PayCycleMonth: payCycleMonthOptions,
        EmployeeName: employeeNameOption, // Add EmployeeName option
        PayItemCode: payItemCodeOption,
        PayCycleCode: payCycleCodeOption,
      }))
    }
  }, [allPostEmployeeData, allPayItemMasterData, payCycleYearData])

  // useEffect(() => {
  //   fetchData()
  // }, [selectedOptions])

  useEffect(() => {
    if (selectedOptions.EmployeeCode.length > 0) {
      fetchData()
    }
  }, [selectedOptions.EmployeeCode])

  const fetchData = async (pageNumber = filterData.pageNumber, pageSize = filterData.pageSize) => {
    const employeeCodes = selectedOptions.EmployeeCode.map((item: any) => item.roleCode)
    const payCycleCodes = selectedOptions.PayCycleCode.map((item: any) => item.roleCode)
    const payCycleYear = selectedOptions?.PayCycleYear?.map((item: any) => item?.roleCode)
    const payItemCode = selectedOptions?.PayItemCode?.map((item: any) => item?.roleCode)

    await createPayrollNonRecurringSearch({
      payCycleSearch: {
        payCycleYear: filterData.PayCycleYear,
        payCycleMonth: filterData.PayCycleMonth,
        payCycleCode: payCycleCodes.length > 0 ? payCycleCodes[0] : null,
        employeeCode: employeeCodes.length > 0 ? employeeCodes : null,
        payItemCode: payItemCode.length > 0 ? payItemCode : null,
        createdDate: null,
      },
      pageNumber,
      pageSize,
      orderByAsc: filterData.orderByAsc,
    })
  }

  useEffect(() => {
    if (selectedOptions.PayCycleYearMonth.length > 0) {
      const [firstSelected] = selectedOptions.PayCycleYearMonth
      const year = firstSelected.roleCode.substring(0, 4)
      const month = firstSelected.roleCode.substring(4, 6)
      setFilterData((prev: any) => ({
        ...prev,
        PayCycleYear: year,
        PayCycleMonth: month,
      }))
      updateFilterData()
    }
  }, [selectedOptions.PayCycleYearMonth])

  useEffect(() => {
    fetchData()
  }, [
    filterData.PayCycleYear,
    filterData.PayCycleMonth,
    selectedOptions.EmployeeCode,
    selectedOptions.PayCycleCode,
    selectedOptions.PayCycleYear,
    selectedOptions.PayItemCode,
    selectedOptions.PayCycleYearMonth,
  ])

  useEffect(() => {
    if (allPostEmployeeData && allPayItemMasterData && payCycleYearData) {
      const uniquePayCycleYears = Array.from(new Set(payCycleYearData?.data?.records?.map((item: any) => item.payCycleYear) || []))
      const uniquePayCycleMonths = Array.from(new Set(payCycleYearData?.data?.records?.map((item: any) => item.payCycleMonth) || []))

      const payCycleYearOptions = uniquePayCycleYears.map((year) => ({
        roleCode: year,
        roleName: year,
      }))

      const payCycleMonthOptions = uniquePayCycleMonths.map((month) => ({
        roleCode: month,
        roleName: month,
      }))

      // Create combined options
      const payCycleYearMonthOptions = uniquePayCycleYears.flatMap((year) => uniquePayCycleMonths.map((month) => ({
        roleCode: `${year}${month}`,
        roleName: `${year}-${month}`,
      })))

      const employeeNameOption = allPostEmployeeData?.records?.map((item: any) => ({
        roleCode: item.employeeCode, // Assuming employeeCode is unique
        roleName: `${item.employeeCode} - ${item.employeeProfile?.givenName || ''}`, // Concatenate employeeCode and givenName
      }))

      const payItemCodeOption = allPayItemMasterData?.records?.map((item: any) => ({
        roleCode: item.payItemCode,
        roleName: `${item.payItemCode} - ${item?.payItemName || ''}`,
      }))

      // Use Set to filter out duplicate payCycleCode
      // const payCycleCodeSet = new Set(payCycleYearData?.data?.records?.map((item: any) => item.payCycleCode))
      // const payCycleCodeOption = Array.from(payCycleCodeSet).map((code) => ({
      //   roleCode: code,
      //   roleName: payCycleYearData?.data?.records.find((item: any) => item.payCycleCode === code)?.payCycleName,
      // }))

      const payCycleCodeOption = payCycleYearData?.data?.records?.map((item: any) => ({
        roleCode: item.payCycleCode, // Assuming employeeCode is unique
        roleName: `${item.payCycleCode} - ${item?.payCycleName || ''}`, // Concatenate employeeCode and givenName
      }))

      setListOfOptions((prev: any) => ({
        ...prev,
        PayCycleYearMonth: payCycleYearMonthOptions,
        PayCycleMonth: payCycleMonthOptions,
        // PayCycleYearMonth: formattedOptions,
        EmployeeCode: employeeNameOption, // Add EmployeeName option
        PayItemCode: payItemCodeOption,
        PayCycleCode: payCycleCodeOption,
      }))
    }
  }, [allPostEmployeeData,
    allPayItemMasterData, payCycleYearData])

  // update filter options
  // useEffect(() => {
  const updateFilterData = () => {
    selectedOptions.EmployeeName.forEach((item:any) => {
      setFilterData((prev:any) => ({ ...prev, EmployeeCode: item.roleCode }))
    })

    selectedOptions.PayItemCode.forEach((item:any) => {
      setFilterData((prev:any) => ({ ...prev, PayItemCode: item.roleCode }))
    })

    selectedOptions.PayCycleCode.forEach((item:any) => {
      setFilterData((prev:any) => ({ ...prev, PayCycleCode: item.roleCode }))
    })

    if (selectedOptions.PayCycleYearMonth.length > 0) {
      const [firstSelected] = selectedOptions.PayCycleYearMonth
      const year = firstSelected.roleCode.substring(0, 4)
      const month = firstSelected.roleCode.substring(4, 6)

      setFilterData((prev:any) => ({ ...prev, PayCycleYear: year, PayCycleMonth: month }))
    }
  }

  //   updateFilterData()
  // }, [selectedOptions])

  useEffect(() => {
    if (EntityProfileByIdResponse) {
      const { currentPayrollMonthYear, currentPayrollMonth } = EntityProfileByIdResponse
      // start
      const monthNames = ['January', 'February', 'March', 'April', 'May', 'June', 'July',
        'August', 'September', 'October', 'November', 'December']
      const monthIndex = monthNames.indexOf(currentPayrollMonth)
      const monthNumber = (monthIndex + 1).toString().padStart(2, '0')
      // lll
      const formattedMonthNumber = currentPayrollMonth?.padStart(2, '0')
      const formattedYearMonth = `${currentPayrollMonthYear}-${monthNumber}`

      const defaultSelectedOptions: Partial<SelectedOptions> = {}

      if (currentPayrollMonthYear && currentPayrollMonth) {
        defaultSelectedOptions.PayCycleYearMonth = [
          { roleCode: formattedYearMonth, roleName: formattedYearMonth },
        ]
      }

      setSelectedOptions((prevSelectedOptions: SelectedOptions) => ({
        ...prevSelectedOptions,
        ...defaultSelectedOptions,
      }))

      // Include currentPayrollMonthYear and currentPayrollMonth in the payload
      const payload = {
        payCycleSearch: {
          payCycleYear: currentPayrollMonthYear,
          payCycleMonth: monthNumber,
          // Include other properties from filterData as needed
        },
        pageNumber: filterData.pageNumber,
        pageSize: filterData.pageSize,
        orderByAsc: filterData.orderByAsc,
      }

      // Call the function to fetch data with the updated payload
      fetchData(payload.pageNumber, payload.pageSize)
    }
  }, [EntityProfileByIdResponse])

  useEffect(() => {
    if (EntityProfileByIdResponse) {
      const { currentPayrollMonthYear, currentPayrollMonth } = EntityProfileByIdResponse
      if (currentPayrollMonthYear && currentPayrollMonth) {
        const monthNames = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December']
        const monthIndex = monthNames.indexOf(currentPayrollMonth)
        const monthNumber = (monthIndex + 1).toString().padStart(2, '0')
        setFilterData((prev: any) => ({
          ...prev,
          PayCycleYear: currentPayrollMonthYear,
          PayCycleMonth: monthNumber,
        }))
        setSelectedOptions((prevSelectedOptions: any) => ({
          ...prevSelectedOptions,
          PayCycleYearMonth: [
            {
              roleCode: `${currentPayrollMonthYear}${monthNumber}`,
              roleName: `${currentPayrollMonthYear}-${monthNumber}`,
            },
          ],
        }))
        updateFilterData()
      }
    }
  }, [EntityProfileByIdResponse])

  useEffect(() => {
    updateFilterData()
  }, [selectedOptions])

  // handle filter change in the payCycleYearMonth
  const handleFilterChange = (filterName: string, values: any) => {
    setSelectedOptions((prevSelectedOptions: any) => ({
      ...prevSelectedOptions,
      [filterName]: values,
    }))

    if (filterName === 'PayCycleYearMonth') {
      const [firstSelected] = values
      const year = firstSelected.roleCode.substring(0, 4)
      const month = firstSelected.roleCode.substring(4, 6)
      setFilterData((prev: any) => ({
        ...prev,
        PayCycleYear: year,
        PayCycleMonth: month,
      }))
    }

    fetchData()
  }

  useEffect(() => {
    if (allPosts?.data?.totalItems) {
      setFilterData((prev:any) => ({ ...prev, totalItems: allPosts?.data?.totalItems }))
    }
  }, [allPosts])

  const sorting = (
    event: React.MouseEvent<unknown>,
    property: keyof any,
  ) => {
    const isAsc = filterData.sortBy === property && filterData.orderByAsc === true
    setFilterData({ ...filterData, orderByAsc: !isAsc, sortBy: property })
    // fetchData() // Trigger data fetch with the updated sorting
  }

  useEffect(() => {
    setFilterData({ ...filterData, totalItems: allPosts?.data?.records?.totalItems ? allPosts?.data?.records?.totalItems : 0 })
  }, [allPosts?.data?.records?.pageNumber, filterData.sortBy, filterData.orderByAsc, allPosts?.data?.records?.totalItems])

  console.log(allPosts?.data?.records, 'totalrecords')
  // const onSearch = (e: any, data: any) => {
  //   setFilterData({ ...filterData, ...data })
  //   fetchData() // Trigger data fetch with the updated sorting
  // }
  const handlePagination = (pageNumber: number, pageSize: number) => {
    // setFilterData((prev:any) => ({ ...prev, pageNumber, pageSize }))
    setFilterData({ ...filterData, pageNumber })
    fetchData(pageNumber, pageSize)
  }

  // Function to handle checkbox change
  const handleCheckboxChange = (event:any, id:any) => {
  // Check if the checkbox is checked or unchecked

    if (event.target.checked) {
    // Add the key to the selectedRows state if checked
      setSelectEntity((prev:any) => [...prev, id])
    } else {
    // Remove the key from the selectedEntity state if unchecked
      setSelectEntity((prev:any) => prev.filter((key:any) => key !== id))
    }
  }

  const viewAcoount = (data: any, type:string) => {
    if (type === 'edit PayrollNon-recurring') {
      navigate(
        setRouteValues(`${routes.editPayRollNonRecurring}`, {
          state: { id: data.id, filterData, selectedOptions },
          id: data.id,
        }),
      )
      // navigate(`${routes.editPayRollNonRecurring}`, {
      //   state: { id: data.id, filterData, selectedOptions },
      //   id: data.id,
      // })
    } else if (type === 'delete PayrollNon-recurring') {
      // deletePayRollNonRecurringById(`Id=${data.id}`)
      setSelelctedDelete({ data, isDelete: true, name: data.PayRollNonRecurringCode })
    } else {
      navigate(
        setRouteValues(`${routes.viewPayRollNonRecurring}`, {
          id: data.id,
          // view: true,
          // state: { id: data.id, filterData, selectedOptions },
        }),
      )
    }
  }
  const handleView = (data: any) => {
    navigate(
      setRouteValues(`${routes.viewPayRollNonRecurring}`, {
        id: data.id,
        view: true,
      }),
    )
  }
  // handle Delete
  const handleDelete = (data:any) => {
    deletePayRollNonRecurringById(`Id=${data.id}`)
  }

  const renderValue = (selected: any[], filterName: string) => {
    if (selected.length === 0) {
      return <span>{t(`${filterName}`)}</span>
    }

    return (
      <span style={{ display: 'flex', justifyContent: 'space-between' }}>
        <span style={{ }}>
          {t(`${filterName}`)}
          {' '}
        </span>
        <span>
          {selected.length}
        </span>
      </span>
    )
  }
  // payCycleYearandMonth
  const renderValueYearMonth = (selected: any) => {
    if (selected.length === 0) {
      return 'Year & Month'
    }
    return (
      <span style={{ display: 'flex', justifyContent: 'space-between' }}>
        <span style={{ fontSize: '13px' }}>
          {selected.map((item: any) => (
            <span key={item.roleName}>
              {/* {item.roleCode.substring(0, 4)} */}
              {item.roleName.padStart(2, '0')}
            </span>
          ))}
        </span>
      </span>
    )
  }

  // payCycleCode
  const renderValuePayCycleCode = (selected: any) => {
    if (selected.length === 0) {
      return <span>Pay Cycle</span>
    }
    return (
      <span style={{
        display: 'flex',
        justifyContent: 'space-between',
        // wordWrap: 'break-word',
        // overflowWrap: 'break-word',
        // whiteSpace: 'nowrap',
      }}
      >
        <span style={{ fontSize: '13px' }}>
          {selected.map((item: any) => (
            <span
              key={item.roleCode}
            >
              {/* {item.roleCode}
              - */}
              {item.roleName}
            </span>
          ))}
        </span>
      </span>
    )
  }

  const handleClearFilters = () => {
    setFilterData({
      pageNumber: 1,
      pageSize: 50,
      totalItems: 0,
      orderByAsc: true,
      sortBy: '',
      SearchText: '',
      PayCycleYear: '',
      PayCycleMonth: '',
      PayCycleCode: '',
      EmployeeCode: null,
      PayItemCode: '',
    })
    setSelectedOptions({
      PayCycleYearMonth: [],
      EmployeeCode: [],
      PayItemCode: [],
      EmployeeName: [],
      PayCycleCode: [],
    })
    setClearFilters(true)
  }

  const filterLayout = () => (
    <>
      <OPRSelectCheckbox
        listOfOptions={listOfOptions.PayCycleYearMonth}
        renderValue={renderValueYearMonth}
        selectedOptions={selectedOptions.PayCycleYearMonth}
        setSelectedOptions={(selected) => handleFilterChange('PayCycleYearMonth', selected)}

      />

      <OPRSelectCheckbox
        listOfOptions={listOfOptions.PayCycleCode}
        renderValue={renderValuePayCycleCode}
        selectedOptions={selectedOptions.PayCycleCode}
        setSelectedOptions={(selected) => handlePayCycleCodeChange('PayCycleCode', selected)}
      />
      <MultipleSelectCheckmarks
        listOfOptions={listOfOptions?.EmployeeCode}
        renderValue={(selected:any) => renderValue(selected, 'Employee')}
        selectedOptions={selectedOptions?.EmployeeCode}
        setSelectedOptions={(EmployeeCode:any) => {
          setSelectedOptions((prev: any) => ({ ...prev, EmployeeCode }))
          fetchData()
        }}
        sx={{
          backgroundColor: selectedOptions?.EmployeeCode?.length > 0 ? '#0037A4' : 'default',
          color: selectedOptions?.EmployeeCode?.length > 0 ? '#FFF' : '#000',
        }}
      />
      {/* Pay Items */}
      <MultipleSelectCheckmarks
        listOfOptions={listOfOptions?.PayItemCode}
        renderValue={(selected:any) => renderValue(selected, 'PayItem')}
        selectedOptions={selectedOptions?.PayItemCode}
        setSelectedOptions={(PayItemCode:any) => {
          setSelectedOptions((prev: any) => ({ ...prev, PayItemCode }))
          fetchData()
        }}
        sx={{
          backgroundColor: selectedOptions?.PayItemCode?.length > 0 ? '#0037A4' : 'default',
          color: selectedOptions?.PayItemCode?.length > 0 ? '#FFFFFF' : '#000',
        }}
      />
      {/* clear button filter */}
      <Box>
        <OPRButton
          sx={{
            color: '#DA3237',
            fontWeight: 700,
            fontSize: '16px',
          }}
          variant="text"
          onClick={handleClearFilters}
        >
          <CrossIcon />
          Clear filter

        </OPRButton>
      </Box>

    </>
  )

  const handleAddClick = () => {
    navigate(routes.createPayRollNonRecurring, {
      state: { filterData, selectedOptions },
    })
  }

  const handlePayCycleCodeChange = (filterName: string, values: any) => {
    setSelectedOptions((prevSelectedOptions: any) => ({
      ...prevSelectedOptions,
      [filterName]: values,
    }))

    // Check if any PayCycleCode is selected
    if (values.length > 0) {
      setIsExportVisible(true)
      setAddHandleClickVisible(true)
      fetchData()
    } else {
      setIsExportVisible(false)
      setAddHandleClickVisible(false)
    }
  }
  return (
    <Box sx={{ display: 'flex', flexDirection: 'column' }}>
      <Box>
        <OPRLabel label={t('Non-recurring items')} variant="h2" />
        <OPRLabel label="Start your listing by selecting a pay cycle." sx={{ marginTop: '6px' }} />

      </Box>
      <OPRInnerListLayout
        addHandleClick={addHandleClickVisible ? handleAddClick : null}
        columns={payrollNoRecurringSearchColumn(viewAcoount)}
        customAdd="Add item"
        dataList={JSON.parse(JSON.stringify(allPosts?.data?.records || []))}
        deleteCallBack={handleDelete}
        error={errorAllPosts || deletePayRollNonRecurringError}
        exportProps={{
          data: allPosts?.data?.records,
          fileName: 'PayRollNonRecurring',
          columns: useTranslatedColumnsForPDF(PayRollNonRecurringColumnMappings),
          pdf: {
            orientation: 'landscape',
          },
          allRecords: {
            baseURL: getEnv('REACT_APP_UP_BASE_URL', null),
            endpoint: getAPIWithEntityUrl(apiEndPoint.payRollNonRecurringList),
            filterData: allPosts?.data?.records,
          },
        }}
        filterData={filterData}
        filterLayout={filterLayout}
        handlePagination={handlePagination}
        isAdd={addHandleClickVisible}
        isError={deletePayRollNonRecurringIsError}
        isExport={isExportVisible}
        isSearch={false}
        loading={isLoadingAllPosts || deletePayRollNonRecurringLoading}
        rowClickHandler={handleView}
        rowNumber={0}
        selelctedUser={selelctedDelete}
        setSelelctedUser={setSelelctedDelete}
        sortHandleClick={sorting}
        success={deletePayRollNonRecurringSuccess}
        title={t('')}
      />
    </Box>
  )
}
export const selectedOptions = {
  PayCycleYearMonth: [],
  EmployeeCode: [],
  PayItemCode: [],
  EmployeeName: [],
  PayCycleCode: [],
  PayCycleYear: [],
  PayCycleMonth: [],
}

export default PayRollNonRecurringList
