import { useTheme } from '@emotion/react'
import {
  Box, Grid,
} from '@mui/material'
import { useGetAllPayCycleGenerationDropDownQuery, usePayCycleGenerationCreateMutation } from 'api/payRollServices'
import OPRLabel from 'components/atoms/label/OPRLabel'
import OPRInputControl from 'components/molecules/OPRInputControl'
import OPRResponsiveGrid from 'components/molecules/OPRResponsiveGrid'
import OPRSelectorControl from 'components/molecules/OPRSelectorControl/OPRSelectorControl'
import OPRAlertControl from 'components/organism/OPRAlertControl'
import { validationSchemaPaycyclegeneration } from 'constants/validate'
import useForm from 'hooks/useForm'
import { t } from 'i18next'
import { useState } from 'react'

import { CustomDialog } from '../../../components/atoms/modal/OPRModal'

type PayCycleModalProps = {
    onClick?: (data: any, type: string) => void;
    handleClose: () => void;
    isDelete?: boolean;
    isOpen: boolean;
    payItem: any;
  };

export function PayCycleModal({
  onClick, isDelete = false, isOpen, payItem, handleClose,
}: PayCycleModalProps) {
  const theme:any = useTheme()
  const [steps, setSteps] = useState(0)
  const [isEditable, setIsEditable] = useState(false)
  const [filterData, setFilterData]:any = useState({
    pageNumber: 1,
    pageSize: 250,
    totalItems: 0,
    orderByAsc: true,
    sortBy: '',
    SearchText: '',
  })
  const {
    values,
    setValues,
    errors,
    handleChange,
    setErrors,
    handleFormSubmit,
    handleOnChange,
  } = useForm(validationSchemaPaycyclegeneration)
  const [
    createPayCycleGeneration,
    {
      data: createdPayCycleGenerationData,
      error: createdPayCycleGenerationError,
      isLoading: createdPayCycleGenerationLoading,
      isSuccess: createdPayCycleGenerationSuccess,
      isError: createdPayCycleGenerationIsError,
    },
  ] = usePayCycleGenerationCreateMutation()
  const handleSubmit = async () => {
    await createPayCycleGeneration({
      payGroupId: payItem?.id,
      year: values?.year,
      monthId: values?.monthId.id,
      recurringId: values?.recurringId.id,
    })
  }
  const createSubtitle = () => (isDelete ? {
    title: t('unable_delete_user_account'),
  } : {
    title: t('unable_deactivate_user_account'),
  })
  const {
    data: allData,
    error: createAllDatasBankAccountError,
    isLoading: isLoadingAllData,
    isSuccess: isSuccessAllData,
    isError: isErrorAllData,
    error: errorAllData,
  } = useGetAllPayCycleGenerationDropDownQuery('')
  const handleResume = () => {
    if (steps === 0) {
      setIsEditable(true)
      setSteps((prev) => prev + 1)
    } else if (steps === 1) {
      handleSubmit()
      handleClose()
    } else {
      handleClose()
      setValues({})
      setSteps(0)
    }
  }
  // for ${payItem.payCycleName}
  return (
    <Box>
      <OPRAlertControl
        isCustom
        customMessage={`${payItem?.payGroupName}  has been generated`}
        customTitle={t('pay_cycle_generated')}
        error={createdPayCycleGenerationError}
        handleSubmit={handleSubmit}
        isError={createdPayCycleGenerationIsError}
        isLoading={createdPayCycleGenerationLoading}
        isSuccess={createdPayCycleGenerationSuccess}
        // name={t('pay_generate_pay_cycle')}
        title={t('pay_generate_pay_cycle')}
        type="New"
      />
      <CustomDialog
        isResume
        CustomStyles={{ borderRadius: '16px' }}
        closeTitle="cancel"
        handleBack={() => {
          setSteps((prev) => prev - 1)
          setIsEditable(false)
        }}
        handleClose={() => {
          handleClose()
          setValues({})
          setIsEditable(false)
          setSteps(0)
        }}
        handleResume={handleResume}
        isBackButton={(steps > 0)}
        isOpen={isOpen}
        resumeTitle={steps === 1 ? 'generate' : 'bulk_upload_data_continue'}
        subtitle={steps === 0 ? 'All fields are mandatory except those marked optional.' : 'Please check the details below.'}
        title={t('pay_generate_pay_cycle')}
      >
        <>
          <Box sx={{
            display: 'flex',
            flexDirection: 'row',
            gap: '5px',
            alignItems: 'center',
            padding: '10px 10px',
            justifyContent: 'space-between',
          }}
          >
            <Box sx={{
              display: 'flex', flexDirection: 'column', alignItems: 'flex-start',
            }}
            >
              <OPRLabel CustomStyles={{ marginBottom: '15px' }} variant="body2">{t('payItem_Code')}</OPRLabel>
              <OPRLabel CustomStyles={{ marginBottom: '15px' }} variant="body2">{payItem?.payGroupCode}</OPRLabel>
            </Box>
            <Box sx={{
              display: 'flex', flexDirection: 'column', alignItems: 'flex-start',
            }}
            >
              <OPRLabel CustomStyles={{ marginBottom: '15px' }} variant="body2">{t('pay_group_name')}</OPRLabel>
              <OPRLabel CustomStyles={{ marginBottom: '15px' }} variant="body2">{payItem?.payGroupName}</OPRLabel>
            </Box>
          </Box>
          <OPRResponsiveGrid>
            <Grid item md={2} sm={1} xs={1}>
              <OPRInputControl
                error={t(errors?.year)}
                isEditable={isEditable}
                label="starting_year_for_recurring"
                name="year"
                value={values?.year}
                onChange={handleChange}
              />
              {/* <OPRSelectorControl
                error={errors?.year}
                isEditable={isEditable}
                keyName="label"
                label={t('starting_year_for_recurring')}
                multiple={false}
                name="year"
                options={allData?.payCycleMonths || []}
                placeholder="Select an option"
                //   value={[{ payItemForBackPay: 'Yes', values: 'Yes' }, { payItemForBackPay: 'No', values: 'No' }]?.find((o:any) => o?.values === values?.payItemForBackPay) || {}}
                value={values?.year}
                valueKey="id"
                onChange={(text:any) => {
                  handleOnChange('year', text)
                }}
              /> */}
            </Grid>
            <Grid item md={2} sm={1} xs={1}>
              <OPRSelectorControl
                error={errors?.monthId}
                isEditable={isEditable}
                keyName="label"
                label={t('starting_month_for_recurring')}
                multiple={false}
                name="monthId"
                options={allData?.payCycleMonths || []}
                placeholder="Select an option"
                //   value={[{ payItemForBackPay: 'Yes', values: 'Yes' }, { payItemForBackPay: 'No', values: 'No' }]?.find((o:any) => o?.values === values?.payItemForBackPay) || {}}
                value={values?.monthId}
                valueKey="id"
                onChange={(text:any) => {
                  handleOnChange('monthId', text)
                }}
              />
            </Grid>
            <Grid item md={2} sm={1} xs={1}>
              <OPRSelectorControl
                error={errors?.recurringId}
                isEditable={isEditable}
                keyName="label"
                label={t('no_of_recurring_months')}
                multiple={false}
                name="recurringId"
                options={allData?.payCycleRecurrings || []}
                placeholder="Select an option"
                //   value={[{ payItemForBackPay: 'Yes', values: 'Yes' }, { payItemForBackPay: 'No', values: 'No' }]?.find((o:any) => o?.values === values?.payItemForBackPay) || {}}
                value={values?.recurringId}
                valueKey="id"
                onChange={(text:any) => {
                  handleOnChange('recurringId', text)
                }}
              />
            </Grid>
          </OPRResponsiveGrid>
        </>
      </CustomDialog>
    </Box>
  )
}
