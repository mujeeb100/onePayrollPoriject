import { Box, Grid } from '@mui/material'
import {
  useGetAllPayGroupDropDownQuery, useLazyGetPayGroupByIdQuery, usePayGroupCreateMutation, usePayGroupUpdateMutation,
} from 'api/payRollServices'
import OPRLabel from 'components/atoms/label/OPRLabel'
import OPRInputControl from 'components/molecules/OPRInputControl'
import OPRResponsiveGrid from 'components/molecules/OPRResponsiveGrid'
import OPRSelectorControl from 'components/molecules/OPRSelectorControl/OPRSelectorControl'
import OPRTextArea from 'components/molecules/OPRTextArea/OPRTextArea'
import OPRAlertControl from 'components/organism/OPRAlertControl'
import { OPRInnerFormLayout } from 'components/organism/OPRInnerFormLayout'
import { validationSchemaPayGroup } from 'constants/validate'
import { useEditable } from 'hooks/useEdit'
import useForm from 'hooks/useForm'
import { t } from 'i18next'
import { useEffect } from 'react'
import { useLocation, useNavigate } from 'react-router-dom'
import { routes } from 'routes/routes'
import { getParamsValue } from 'utils'

const defaultValue = {

  status: { id: 1, label: 'Active' },

  payCycleFrequency: { id: 1, label: 'Monthly' },

  payCycleType: { id: 1, label: 'Main Cycle' },

}

interface MessageProps {
  text?: string;
  important?: boolean;
}

export default function PayGroupForm() {
  const location: any = useLocation()
  const { id, viewUrl } = getParamsValue(location, routes.createPayGroup)
  const {
    isEditable,
    setEditable,
  } = useEditable()

  const {
    values,
    setValues,
    errors,
    handleChange,
    setErrors,
    handleFormSubmit,
    handleOnChange,
  } = useForm(validationSchemaPayGroup)

  const navigate = useNavigate()
  const [createPayGroup, {
    data: createdPayGroupData,
    error: createdPayGroupError,
    isLoading: createdPayGroupLoading,
    isSuccess: createdPayGroupSuccess,
    isError: createdPayGroupIsError,
  }] = usePayGroupCreateMutation()

  const [updatePayGroup, {
    data: updatedDataResponse,
    error: updatedPayGroupError,
    isLoading: updatedPayGroupLoading,
    isSuccess: updatedPayGroupSuccess,
    isError: updatedPayGroupIsError,
  }] = usePayGroupUpdateMutation()

  const [updatePayGroupById, {
    data: updatedPayGroupByIdResponse,
    error: updatedPayGroupByIdError,
    isLoading: updatedPayGroupByIdLoading,
    isSuccess: updatedPayGroupByIdSuccess,
    isError: updatedPayGroupByIdIsError,
  }] = useLazyGetPayGroupByIdQuery()

  const {
    data: allData,
    error: createAllDatasBankAccountError,
    isLoading: isLoadingAllData,
    isSuccess: isSuccessAllData,
    isError: isErrorAllData,
    error: errorAllData,
  } = useGetAllPayGroupDropDownQuery('')

  useEffect(() => {
    if (id) {
      updatePayGroupById(id)
      setEditable(viewUrl)
    }
  }, [])
  useEffect(() => {
    if (id) {
      setValues(updatedPayGroupByIdResponse?.data)
    } else {
      setValues(location.state ? location.state : {})
    }
  }, [updatedPayGroupByIdResponse?.data])

  useEffect(() => {
    if (id === null) {
      setValues(defaultValue)
    }
  }, [])

  // useEffect(() => {
  //   if (createdPayGroupSuccess) {
  //     // Reset form values after successful add operation
  //     setValues({})
  //     setErrors({})
  //   }
  // }, [createdPayGroupSuccess])

  const handleSubmit: any = async () => {
    if (isEditable) {
      if (id === null) {
        await createPayGroup({
          payGroupCode: values?.payGroupCode,
          payGroupName: values?.payGroupName,
          status: values?.status,
          statusId: values?.status?.id,
          remarks: values?.remarks,
          payCycleCode: values?.payCycleCode,
          payCycleCodeId: values?.payCycleCode?.id,
          payCycleName: values?.payCycleName,
          payCycleFrequency: values?.payCycleFrequency,
          payCycleFrequencyId: values?.payCycleFrequency?.id,
          payCycleType: values?.payCycleType,
          payCycleTypeId: values?.payCycleType?.id,
          payrollPeriodStartMonth: values?.payrollPeriodStartMonth,
          payrollPeriodStartMonthId: values?.payrollPeriodStartMonth?.id,
          payrollPeriodStartDay: values?.payrollPeriodStartDay,
          payrollPeriodStartDayId: values?.payrollPeriodStartDay?.id,
          payrollPeriodEndMonth: values?.payrollPeriodEndMonth,
          payrollPeriodEndMonthId: values?.payrollPeriodEndMonth?.id,
          payrollPeriodEndDay: values?.payrollPeriodEndDay,
          payrollPeriodEndDayId: values?.payrollPeriodEndDay?.id,
          cutOffDateMethod: values?.cutOffDateMethod,
          cutOffDateMethodId: values?.cutOffDateMethod?.id,
          cutOffDateDay: values?.cutOffDateDay,
          cutOffDateDayId: values?.cutOffDateDay?.id,
          payDateMethod: values?.payDateMethod,
          payDateMethodId: values?.payDateMethod?.id,
          payDateDay: values?.payDateDay,
          payDateDayId: values?.payDateDay?.id,

        })
      } else {
        await updatePayGroup({
          id: values?.id,
          payGroupCode: values.payGroupCode,
          payGroupName: values.payGroupName,
          status: values?.status,
          statusId: values?.status?.id,
          remarks: values?.remarks,
          payCycleCode: values?.payCycleCode,
          payCycleCodeId: values?.payCycleCode?.id,
          payCycleName: values?.payCycleName,
          payCycleFrequency: values?.payCycleFrequency,
          payCycleFrequencyId: values?.payCycleFrequency?.id,
          payCycleType: values?.payCycleType,
          payCycleTypeId: values?.payCycleType?.id,
          payrollPeriodStartMonth: values?.payrollPeriodStartMonth,
          payrollPeriodStartMonthId: values?.payrollPeriodStartMonth?.id,
          payrollPeriodStartDay: values?.payrollPeriodStartDay,
          payrollPeriodStartDayId: values?.payrollPeriodStartDay?.id,
          payrollPeriodEndMonth: values?.payrollPeriodEndMonth,
          payrollPeriodEndMonthId: values?.payrollPeriodEndMonth?.id,
          payrollPeriodEndDay: values?.payrollPeriodEndDay,
          payrollPeriodEndDayId: values?.payrollPeriodEndDay?.id,
          cutOffDateMethod: values?.cutOffDateMethod,
          cutOffDateMethodId: values?.cutOffDateMethod?.id,
          cutOffDateDay: values?.cutOffDateDay,
          cutOffDateDayId: values?.cutOffDateDay?.id,
          payDateMethod: values?.payDateMethod,
          payDateMethodId: values?.payDateMethod?.id,
          payDateDay: values?.payDateDay,
          payDateDayId: values?.payDateDay?.id,

        })
      }
    } else {
      setEditable(true)
    }
  }

  async function editPayGroup() {
    await updatePayGroup({
      id: values.id,
      payGroupCode: values.payGroupCode,
      payGroupName: values.payGroupName,
      status: values?.status,
      statusId: values?.status?.id,
      remarks: values?.remarks,
      payCycleCode: values?.payCycleCode,
      payCycleCodeId: values?.payCycleCode?.id,
      payCycleName: values?.payCycleName,
      payCycleFrequency: values?.payCycleFrequency,
      payCycleFrequencyId: values?.payCycleFrequency?.id,
      payCycleType: values?.payCycleType,
      payCycleTypeId: values?.payCycleType?.id,
      payrollPeriodStartMonth: values?.payrollPeriodStartMonth,
      payrollPeriodStartMonthId: values?.payrollPeriodStartMonth?.id,
      payrollPeriodStartDay: values?.payrollPeriodStartDay,
      payrollPeriodStartDayId: values?.payrollPeriodStartDay?.id,
      payrollPeriodEndMonth: values?.payrollPeriodEndMonth,
      payrollPeriodEndMonthId: values?.payrollPeriodEndMonth?.id,
      payrollPeriodEndDay: values?.payrollPeriodEndDay,
      payrollPeriodEndDayId: values?.payrollPeriodEndDay?.id,
      cutOffDateMethod: values?.cutOffDateMethod,
      cutOffDateMethodId: values?.cutOffDateMethod?.id,
      cutOffDateDay: values?.cutOffDateDay,
      cutOffDateDayId: values?.cutOffDateDay?.id,
      payDateMethod: values?.payDateMethod,
      payDateMethodId: values?.payDateMethod?.id,
      payDateDay: values?.payDateDay,
      payDateDayId: values?.payDateDay?.id,

    })
  }

  const onScreenClose: any = (item: any) => {
    setEditable(item)
    setValues({})
  }

  console.log('fffffff', values)

  return (
    <Box sx={{ display: 'flex' }}>
      <form style={{ display: 'flex', width: '100% ' }} onSubmit={(e) => handleFormSubmit(e, handleSubmit)}>
        <OPRAlertControl
          error={createdPayGroupError || updatedPayGroupError}
          handleEditable={setEditable}
          handleSetValue={setValues}
          handleSubmit={handleSubmit}
          isError={createdPayGroupError || updatedPayGroupError}
          isLoading={createdPayGroupLoading || updatedPayGroupLoading || updatedPayGroupByIdLoading}
          isSuccess={updatedPayGroupSuccess || createdPayGroupSuccess}
          name={values?.payGroupName}
          title={t('Pay_group_title')}
          type={id ? 'Update' : 'New'}
        />
        <OPRInnerFormLayout
          error={createdPayGroupError || updatedPayGroupError}
          handleCancelClick={() => navigate(-1)}
          handleContinueClick={handleSubmit}
          handleEditable={() => {
            setEditable(true)
          }}
          isBackButton={isEditable}
          isLoading={createdPayGroupLoading || updatedPayGroupLoading || updatedPayGroupByIdLoading}
          pageType="detailsPage"
          subtitle={viewUrl ? `Pay group ID: ${updatedPayGroupByIdResponse?.data?.payGroupCode}` : 'All field to mandatory expect those mark optional'}
          title={id ? `${updatedPayGroupByIdResponse?.data?.payGroupName}` : `${t('add')} ${t('Pay_group_title')}`}
          onScreenClose={onScreenClose}
        >
          <Box>
            <OPRResponsiveGrid>
              <div style={{ display: 'block', width: '100%', margin: '30px 20px 20px' }}>
                <OPRLabel variant="h3">General information</OPRLabel>
              </div>
              <Grid item md={2} sm={1} xs={1}>
                <OPRInputControl
                  disabled={!!id}
                  error={errors?.payGroupCode}
                  isEditable={isEditable}
                  label={t('Pay groups ID')}
                  name="payGroupCode"
                  value={values?.payGroupCode}
                  onChange={handleChange}
                />
              </Grid>
              <Grid item md={2} sm={1} xs={1}>
                <OPRInputControl
                  error={errors?.payGroupName}
                  isEditable={isEditable}
                  label={t('Pay groups name')}
                  name="payGroupName"
                  value={values?.payGroupName}
                  onChange={handleChange}
                />
              </Grid>

              <Grid item md={2} sm={1} xs={1}>
                <OPRSelectorControl
                  isEditable={isEditable}
                  keyName="label"
                  label="pay_group_status"
                  multiple={false}
                  name="status"
                  options={allData?.payGroupStatuses || []}
                  placeholder="Select an option"
                  // value={(allData?.payGroupStatuses || []).find((o:any) => o?.statusId?.id === values?.status?.id)}
                  value={values?.status}
                  valueKey="label"
                  onChange={(text:any) => {
                    handleOnChange('status', text)
                  }}
                />
              </Grid>
              <Grid item md={2} sm={1} xs={1} />

              <Grid item md={4} sm={1} xs={1}>
                <OPRTextArea
                  error={errors?.remarks}
                  isEditable={isEditable}
                  label={t('pay_item_group_remarks')}
                  name="remarks"
                  value={values?.remarks}
                  onChange={handleChange}
                />
              </Grid>
              <div style={{ display: 'block', width: '100%', margin: '30px 20px 20px' }}>
                <OPRLabel variant="h3">Pay cycle details</OPRLabel>
              </div>

              <Grid item md={2} sm={1} xs={1}>
                <OPRSelectorControl
                  disabled={location.pathname !== `${routes.editPayGroup}`}
                  isEditable={isEditable}
                  keyName="label"
                  label="pay_group_pay_cycle_frequency_id"
                  multiple={false}
                  name="payCycleFrequency"
                  // options={(allData?.payCycleFrequencies || [])}
                  options={[
                    { name: 'Monthly', value: 'Monthly' },
                  ]}
                  placeholder="Select an option"
                  value={values?.payCycleFrequency}
                  valueKey="label"
                  onChange={(text:any) => {
                    handleOnChange('payCycleFrequency', text)
                  }}
                />
              </Grid>

              <Grid item md={2} sm={1} xs={1}>
                <OPRSelectorControl
                  isEditable={isEditable}
                  keyName="label"
                  label="pay_cycle_type_id"
                  multiple={false}
                  name="payCycleType"
                  options={(allData?.payCycleTypes || [])}
                  placeholder="Select an option"
                  value={values?.payCycleType || { id: 1, label: 'Main Cycle' }}
                  valueKey="label"
                  onChange={(text:any) => {
                    handleOnChange('payCycleType', text)
                  }}
                />
              </Grid>
              <Grid item md={2} sm={1} xs={1}>
                <OPRSelectorControl
                  error={errors?.payCycleCode}
                  isEditable={isEditable}
                  keyName="label"
                  label="pay_group_pay_cycle_code"
                  multiple={false}
                  name="payCycleCode"
                  options={(allData?.payCycleCodes || [])}
                  placeholder="Select an option"
                  value={values?.payCycleCode}
                  valueKey="id"
                  onChange={(text:any) => {
                    handleOnChange('payCycleCode', text)
                  }}
                />
              </Grid>

              <Grid item md={2} sm={1} xs={1}>
                <OPRInputControl
                  error={errors?.payCycleName}
                  isEditable={isEditable}
                  label={t('pay_group_pay_cycle_name')}
                  name="payCycleName"
                  value={values?.payCycleName}
                  onChange={handleChange}
                />
              </Grid>

              <Grid item md={2} sm={1} xs={1}>
                <OPRSelectorControl
                  error={errors?.payrollPeriodStartMonth}
                  isEditable={isEditable}
                  keyName="label"
                  label="pay_group_payroll_period_start_month_id"
                  multiple={false}
                  name="payrollPeriodStartMonth"
                  options={(allData?.payrollPeriodMonths || [])}
                  placeholder="Select an option"
                  value={values?.payrollPeriodStartMonth || ''}
                  valueKey="label"
                  onChange={(text:any) => {
                    console.log('eee', text)
                    handleOnChange('payrollPeriodStartMonth', text)
                  }}
                />
              </Grid>
              <Grid item md={2} sm={1} xs={1}>
                <OPRSelectorControl
                  error={errors?.payrollPeriodStartDay}
                  isEditable={isEditable}
                  keyName="label"
                  label="pay_group_payroll_period_start_day_id"
                  multiple={false}
                  name="payrollPeriodStartDay"
                  options={(allData?.payrollPeriodDays || [])}
                  placeholder="Select an option"
                  value={values?.payrollPeriodStartDay || ''}
                  valueKey="label"
                  onChange={(text:any) => {
                    handleOnChange('payrollPeriodStartDay', text)
                  }}
                />
              </Grid>

              <Grid item md={2} sm={1} xs={1}>
                <OPRSelectorControl
                  error={errors?.payrollPeriodEndMonth}
                  isEditable={isEditable}
                  keyName="label"
                  label="pay_group_payroll_period_end_month_id"
                  multiple={false}
                  name="payrollPeriodEndMonth"
                  options={(allData?.payrollPeriodMonths || [])}
                  placeholder="Select an option"
                  value={values?.payrollPeriodEndMonth || ''}
                  valueKey="label"
                  onChange={(text:any) => {
                    handleOnChange('payrollPeriodEndMonth', text)
                  }}
                />
              </Grid>

              <Grid item md={2} sm={1} xs={1}>
                <OPRSelectorControl
                  error={errors?.payrollPeriodEndDay}
                  isEditable={isEditable}
                  keyName="label"
                  label="pay_group_payroll_period_end_day_id"
                  multiple={false}
                  name="payrollPeriodEndDay"
                  options={(allData?.payrollPeriodDays || [])}
                  placeholder="Select an option"
                  value={values?.payrollPeriodEndDay || ''}
                  valueKey="label"
                  onChange={(text:any) => {
                    handleOnChange('payrollPeriodEndDay', text)
                  }}
                />
              </Grid>

              <Grid item md={2} sm={1} xs={1}>
                <OPRSelectorControl
                  error={errors?.cutOffDateMethod}
                  isEditable={isEditable}
                  keyName="label"
                  label="pay_group_cut_off_date_method_id"
                  multiple={false}
                  name="cutOffDateMethod"
                  optionalText="Optional"
                  options={(allData?.payrollDateMethods || [])}
                  placeholder="Select an option"
                  value={values?.cutOffDateMethod || ''}
                  valueKey="label"
                  onChange={(text:any) => {
                    handleOnChange('cutOffDateMethod', text)
                  }}
                />
              </Grid>
              {values?.cutOffDateMethod?.id !== 3 && (
                <Grid item md={2} sm={1} xs={1}>
                  <OPRSelectorControl
                    error={errors?.cutOffDateDay}
                    isEditable={isEditable}
                    keyName="label"
                    label="pay_group_cut_off_date_day_id"
                    multiple={false}
                    name="cutOffDateDay"
                    optionalText="Optional"
                    options={(allData?.payrollPeriodDays || [])}
                    placeholder="Select an option"
                    value={values?.cutOffDateDay || ''}
                    valueKey="label"
                    onChange={(text:any) => {
                      handleOnChange('cutOffDateDay', text)
                    }}
                  />
                </Grid>
              )}
              <Grid item md={2} sm={1} xs={1}>
                <OPRSelectorControl
                  error={errors?.payDateMethod}
                  isEditable={isEditable}
                  keyName="label"
                  label="pay_group_pay_date_method_id"
                  multiple={false}
                  name="payDateMethod"
                  optionalText="Optional"
                  options={(allData?.payrollDateMethods || [])}
                  placeholder="Select an option"
                  value={values?.payDateMethod || ''}
                  valueKey="label"
                  onChange={(text:any) => {
                    handleOnChange('payDateMethod', text)
                  }}
                />
              </Grid>

              {values?.payDateMethod?.id !== 3 && (

                <Grid item md={2} sm={1} xs={1}>
                  <OPRSelectorControl
                    error={errors?.payDateDay}
                    isEditable={isEditable}
                    keyName="label"
                    label="pay_group_pay_date_day_id"
                    multiple={false}
                    name="payDateDay"
                    optionalText="Optional"
                    options={(allData?.payrollPeriodDays || [])}
                    placeholder="Select an option"
                    value={values?.payDateDay || ''}
                    valueKey="label"
                    onChange={(text:any) => {
                      handleOnChange('payDateDay', text)
                    }}
                  />
                </Grid>
              )}
            </OPRResponsiveGrid>
          </Box>
        </OPRInnerFormLayout>
      </form>
    </Box>
  )
}
