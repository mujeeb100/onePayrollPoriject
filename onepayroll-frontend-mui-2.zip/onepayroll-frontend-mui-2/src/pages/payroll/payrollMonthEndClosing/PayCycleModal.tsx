import {
  Box, Button, Dialog,
  Typography,
} from '@mui/material'

// Define the props type for the PayCycles component
interface PayCyclesProps {
  open: boolean;
  onClose: () => void;
  monthName?: string;
  year?: string;
  status: string;
  data: any;
  // setPayCycleData: React.Dispatch<React.SetStateAction<any>>; // Add this line

}

function PayCycles({
  open = false,
  onClose,
  monthName,
  year,
  status,
  data,
  // setPayCycleData, // Include setPayCycleData in the function paramete
}: PayCyclesProps) {
  if (!data) {
    return null // Don't render anything if data is null or undefined
  }
  const handleBackButtonClick = () => {
    onClose() // Close the modal
  }

  const getStatusStyles = (statusLabel: string) => {
    let backgroundColor
    let textColor

    if (statusLabel === 'Finalized') {
      backgroundColor = '#EBFFF0'
      textColor = '#00701C'
    } else if (statusLabel === 'Open') {
      backgroundColor = '#FFF7EB'
      textColor = '#9E5A00'
    } else if (statusLabel === 'Inactive') {
      backgroundColor = '#F0F0F0'
      textColor = '#808080'
    } else if (statusLabel === 'Complete') {
      backgroundColor = '#DFF0D8'
      textColor = '#3C763D'
    } else {
      backgroundColor = '#E8E6E7'
      textColor = '#3B3839'
    }

    return { backgroundColor, textColor }
  }
  return (
    <Dialog open={open} onClose={onClose}>
      <Box
        sx={{
          width: '100%',
          height: '100%',
          backgroundColor: 'white',
          boxShadow: '0px 3px 4px #D4D2D3',
          borderRadius: 2,
          display: 'flex',
          flexDirection: 'column',
          justifyContent: 'flex-start',
          alignItems: 'center',
        }}
      >
        <Box
          sx={{
            alignSelf: 'stretch',
            // height: 88,
            pt: 5,
            pb: 2,
            px: 5,
            display: 'flex',
            flexDirection: 'column',
            justifyContent: 'flex-start',
            alignItems: 'flex-start',
            gap: 2,
          }}
        >
          <Typography
            sx={{
              alignSelf: 'stretch',
              color: '#3B3839',
              fontSize: 24,
              fontFamily: 'Lato',
              fontWeight: '700',
              // lineHeight: '32px',
            }}
          >
            Pay cycles
          </Typography>
        </Box>
        <Box
          sx={{
            alignSelf: 'stretch',
            height: 378,
            px: 5,
            display: 'flex',
            flexDirection: 'column',
            justifyContent: 'flex-start',
            alignItems: 'flex-start',
            gap: 2.5,
          }}
        >
          <Box
            sx={{
              alignSelf: 'stretch',
              height: 40,
              display: 'flex',
              justifyContent: 'flex-start',
              alignItems: 'flex-end',
              gap: 2.5,
            }}
          >
            <Box
              sx={{
                flex: '1 1 0',
                // height: 40,
                py: 1,
                display: 'flex',
                justifyContent: 'flex-start',
                alignItems: 'center',
              }}
            >
              <Typography
                sx={{
                  flex: '1 1 0',
                  color: '#3B3839',
                  fontSize: 16,
                  fontFamily: 'Lato',
                  fontWeight: '400',

                }}
              >
                Pay cycles that are still pending finalization for
                {' '}
                <Typography
                  component="span"
                  sx={{
                    fontWeight: '700',
                  }}
                >
                  {' '}
                  {monthName}
                  {' '}
                  {year}
                  ?
                  {' '}
                  <br />
                  {' '}
                </Typography>

              </Typography>
            </Box>
          </Box>
          <Box
            sx={{
              alignSelf: 'stretch',
              height: 318,
              display: 'flex',
              flexDirection: 'column',
              justifyContent: 'flex-start',
              alignItems: 'flex-start',
              gap: 2,
            }}
          >
            <Box
              sx={{
                alignSelf: 'stretch',
                display: 'flex',
                justifyContent: 'flex-start',
                alignItems: 'center',
                gap: 3,
              }}
            >
              <Box
                sx={{
                  flex: '1 1 0',
                  height: 22,
                  px: 1,
                  display: 'flex',
                  justifyContent: 'flex-start',
                  alignItems: 'flex-start',
                  gap: 1,
                }}
              >
                <Typography
                  sx={{
                    flex: '1 1 0',
                    color: '#3B3839',
                    fontSize: 14,
                    fontFamily: 'Lato',
                    fontWeight: '400',
                    lineHeight: '22px',
                  }}
                >
                  {/* {data.length} */}
                  {' '}
                  pay cycles
                </Typography>
                <Typography
                  sx={{
                    flex: '1 1 0',
                    color: '#3B3839',
                    fontSize: 14,
                    fontFamily: 'Lato',
                    fontWeight: '400',
                    lineHeight: '22px',
                  }}
                >
                  {/* {data.length} */}
                  {' '}
                  Status
                  {' '}
                </Typography>
              </Box>
            </Box>
            <Box
              sx={{
                alignSelf: 'stretch',
                height: 280,
                borderTop: '2px solid #E8E6E7',
                borderBottom: '2px solid #E8E6E7',
                display: 'flex',
                flexDirection: 'column',
                justifyContent: 'flex-start',
                alignItems: 'flex-start',
                gap: 2,
              }}
            >
              {data.map((cycle: any) => {
                const { backgroundColor, textColor } = getStatusStyles(cycle.status.label)

                return (
                  <Box
                    key={cycle.id}
                    sx={{
                      alignSelf: 'stretch',
                      display: 'flex',
                      justifyContent: 'flex-start',
                      alignItems: 'center',
                      gap: 2,
                    }}
                  >
                    <Box
                      sx={{
                        flex: '1 1 0',
                        height: 48,
                        py: 1,
                        display: 'flex',
                        justifyContent: 'flex-start',
                        alignItems: 'center',
                      }}
                    >
                      <Typography
                        sx={{
                          color: '#3B3839',
                          fontSize: 12,
                          fontFamily: 'Lato',
                          fontWeight: '700',
                          lineHeight: '16px',
                        }}
                      >
                        {`${cycle.payCycleName}-${cycle.payCycleYear}${cycle.payCycleMonth}${cycle.payCycleCode}`}
                      </Typography>
                    </Box>

                    <Box
                      sx={{
                        flex: '1 1 0',
                        height: 48,
                        display: 'flex',
                        justifyContent: 'flex-start',
                        alignItems: 'center',
                        gap: 2,
                      }}
                    >

                      <Box
                        sx={{
                          flex: '1 1 0',
                          height: 48,
                          py: 1,
                          display: 'flex',
                          justifyContent: 'flex-start',
                          alignItems: 'center',
                        }}
                      >

                        <Box
                          sx={{
                            p: 1,
                            display: 'flex',
                            justifyContent: 'flex-start',
                            alignItems: 'center',
                            gap: 1,
                            backgroundColor, // Apply background color
                            color: textColor, // Apply text color
                            borderRadius: 12,
                          }}
                        >

                          <Typography
                            sx={{
                              color: textColor, // Apply text color
                              fontSize: 12,
                              fontFamily: 'Lato',
                              fontWeight: '700',
                              lineHeight: '16px',
                            }}
                          >
                            {/* {cycle.status} */}
                            {cycle.status.label}
                          </Typography>
                        </Box>
                      </Box>
                    </Box>
                  </Box>
                )
              })}
            </Box>

          </Box>
        </Box>
        <Box
          sx={{
            alignSelf: 'stretch',
            pt: 5,
            display: 'flex',
            justifyContent: 'flex-start',
            alignItems: 'center',
            gap: 1.25,
          }}
        >
          <Box
            sx={{
              flex: '1 1 0',
              height: 80,
              px: 5,
              pt: 2.5,
              pb: 2.5,
              borderTop: '1px solid #E8E6E7',
              display: 'flex',
              justifyContent: 'space-between',
              alignItems: 'center',
            }}
          >
            <div />
            <Box
              sx={{
                display: 'flex',
                justifyContent: 'flex-end',
                alignItems: 'center',
                gap: 3,
              }}
            >
              <Button
                sx={{
                  borderRadius: 55,
                  borderColor: '#0049DB',
                  color: '#0049DB',
                  px: 3,
                  py: 1,
                  textTransform: 'none',
                }}
                variant="outlined"
                onClick={onClose} // Call handleBackButtonClick on button click
              >
                Back
              </Button>
            </Box>
          </Box>
        </Box>
      </Box>
    </Dialog>
  )
}

export default PayCycles
