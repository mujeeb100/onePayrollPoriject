// PayRoll month end closing
import {
  Box,
  Tab,
  Tabs,
} from '@mui/material'
import { useGetAllEntityProfileSelectedListByIdQuery } from 'api/entityServices'
import { useGetAllMonthEndClosingLogsQuery } from 'api/loggingServices'
import {
  useGetAllMonthEndClosingQuery, useGetAllPayrollCycleQuery,
  usePayrollMonthEndClosingCreateMutation,
} from 'api/payRollServices'
import OPRButton from 'components/atoms/button/OPRButton'
import OPRLabel from 'components/atoms/label/OPRLabel'
import { monthEndClosingLogs, payrollMonthEndClosingColumn } from 'components/atoms/table/OPRTableConstant'
import { CustomTabPanel } from 'components/atoms/tabs'
import { OPRInnerListLayout } from 'components/organism/OPRInnerLayoutList'
import { t } from 'i18next'
import React, { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import {
  generateFilterUrl,
} from 'utils'

import CloseMonthConfirmationAlert from './CloseMonthConfirmationAlert'
import MonthEndClosingAlert from './MonthEndClosingAlert'
import PayCycles from './PayCycleModal'

function a11yProps(index: number) {
  return {
    id: `simple-tab-${index}`,
    'aria-controls': `simple-tabpanel-${index}`,
  }
}

function PayrollCycleList() {
  const navigate: any = useNavigate()
  const [value, setValue] = useState(0)
  const [payCycleData, setPayCycleData]:any = useState([])
  const [showPayCycles, setShowPayCycles] = useState(false)
  const [isPayCyclesModalOpen, setIsPayCyclesModalOpen]:any = useState(false) // State to manage PayCycles modal
  const [selelctedDelete, setSelelctedDelete]:any = useState({
    data: {},
    isDelete: false,
    name: '',
  })
  const handleTabChange = (event: React.SyntheticEvent, newValue: number) => {
    setValue(newValue)
  }
  const [IsCancelMonthEndAlert, setIsPayCycleAlertOpen]:any = useState({
    IsButtonClick: false,
    isSuccess: undefined,

  })
  const [filterData, setFilterData]:any = useState({
    pageNumber: 1,
    pageSize: 20,
    totalItems: 0,
    orderByAsc: true,
    sortBy: '',
    SearchText: '',
  })

  const [filterDataEntity, setFilterDataEntity]:any = useState({
    // year: '2024',
    // month: '02',
  })

  const {
    data: allPosts,
    isLoading: isLoadingAllPosts,
    isSuccess: isSuccessAllPosts,
    isError: isErrorAllPosts,
    error: errorAllPosts,
    refetch: refetchAllPosts,
  } = useGetAllPayrollCycleQuery(generateFilterUrl(filterData))

  const {
    data: EntityProfileByIdResponse,
    error: EntityProfileByIdError,
    isLoading: EntityProfileByIdLoading,
    isSuccess: EntityProfileByIdSuccess,
    isError: EntityProfileByIdIsError,
    refetch: refetchEntityProfile,
  } = useGetAllEntityProfileSelectedListByIdQuery('')

  // month end closing logs view

  const {
    data: allDataMonthEndLogs,
    isLoading: isLoadingAllDataMonthEndLogs,
    isSuccess: isSuccessAllDataMonthEndLogs,
    isError: isErrorAllDataMonthEndLogs,
    error: errorAllDataMonthEndLogs,
    refetch: refetchAllDataMonthEndLogs,

  } = useGetAllMonthEndClosingLogsQuery('')
  const
    // getPrecloseChecked,
    {
      data: GetPreCloseCheckStatus,
      refetch: refetchGetPreCloseCheckStatus,
      status: isSuccessGetPreClose,
    } = useGetAllMonthEndClosingQuery(generateFilterUrl(filterDataEntity))

  useEffect(() => {
    if (GetPreCloseCheckStatus?.isPreCloseCheckPassed === false && IsCancelMonthEndAlert?.IsButtonClick) {
      setIsPayCycleAlertOpen((prev:any) => ({
        ...prev,
        isSuccess: false,
      }))
    } else if (GetPreCloseCheckStatus?.isPreCloseCheckPassed === true && IsCancelMonthEndAlert?.IsButtonClick) {
      setIsPayCycleAlertOpen((prev:any) => ({
        ...prev,
        isSuccess: true,
      }))
    }
  }, [GetPreCloseCheckStatus, isSuccessGetPreClose])

  useEffect(() => {
    if (GetPreCloseCheckStatus) {
      const filteredData = GetPreCloseCheckStatus?.unfinalizedPayCycles
        ?.map((record:any) => ({
          ...record,
          displayName: `${record?.payCycleName}-${record?.payCycleYear}${record?.payCycleMonth}${record?.payCycleCode}`,
        }))

      setPayCycleData(filteredData)
    }
  }, [GetPreCloseCheckStatus])

  // very important part
  useEffect(() => {
    if (EntityProfileByIdSuccess) {
      const monthNames = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December']
      const monthIndex = monthNames.indexOf(EntityProfileByIdResponse.currentPayrollMonth)
      const monthNumber = (monthIndex + 1).toString().padStart(2, '0')
      setFilterDataEntity({
        year: EntityProfileByIdResponse.currentPayrollMonthYear,
        month: monthNumber,
      })
    }
  }, [EntityProfileByIdSuccess])

  const {
    data: monthendclosingdata,
  } = usePayrollMonthEndClosingCreateMutation('')

  const sorting = (
    event: React.MouseEvent<unknown>,
    property: keyof any,
  ) => {
    const isAsc = filterData.sortBy === property && filterData.orderByAsc === true
    setFilterData({ ...filterData, orderByAsc: !isAsc, sortBy: property })
  }

  useEffect(() => {
    setFilterData({ ...filterData, totalItems: allPosts?.totalItems ? allPosts?.totalItems : 0 })
  }, [allPosts?.pageNumber, filterData.sortBy, filterData.orderByAsc, allPosts?.totalItems])

  const onSearch = (e: any, data: any) => {
    setFilterData({ ...filterData, ...data })
  }
  const handlePagination = (pageNumber: number, pageSize: number) => {
    setFilterData({ ...filterData, pageNumber })
  }

  const togglePayCycleAlert:any = () => {
    setIsPayCycleAlertOpen((prev:any) => ({
      ...prev,
      IsButtonClick: true,
    }))
    refetchGetPreCloseCheckStatus()
    // getPrecloseChecked()
  }

  const handleConfirmationModalClose = () => {
    setIsPayCycleAlertOpen(false)
    refetchEntityProfile()
    refetchAllPosts()
  }
  // const handleSubmit = (type: string) => {
  //   setIsOpen(false)
  // }
  // Concatenate the default text with values from entity profile
  const getMonthName = (monthNumber:any) => {
    const months = [
      'January', 'February', 'March', 'April', 'May', 'June', 'July',
      'August', 'September', 'October', 'November', 'December',
    ]
    if (monthNumber >= 1 && monthNumber <= 12) {
      return months[monthNumber - 1] // Adjusting index since monthNumber starts from 1
    }
    return '' // Adjusting index since monthNumber starts from 1
  }
  const monthName = EntityProfileByIdResponse?.currentPayrollMonth
  console.log(EntityProfileByIdResponse?.currentPayrollMonth, 'monthNamemonthName')
  const title = `Month end closing - ${monthName} ${EntityProfileByIdResponse?.currentPayrollMonthYear || ''}`
  // const title = `Month end closing - ${EntityProfileByIdResponse?.currentPayrollMonth || ''} ${EntityProfileByIdResponse?.currentPayrollMonthYear || ''}`
  const handleBackToMonthEndClosingAlert = () => {
    setIsPayCyclesModalOpen(false)
    setShowPayCycles(false) // Set showPayCycles state to false to go back to monthendclosingAlert
  }
  return (
    <Box sx={{ display: 'flex', flexDirection: 'column' }}>
      {/* month end closin button */}
      <Box sx={{
        display: 'flex', justifyContent: 'space-between', flexDirection: 'row',
      }}
      >
        {/* Title Month end closing */}
        <OPRLabel label={t('')} variant="h2">{title}</OPRLabel>
        <Box sx={{
          display: 'flex', justifyContent: 'flex-start', alignItems: 'center', gap: '25px',
        }}
        />
        <Box sx={{
          display: 'flex', justifyContent: 'flex-start', height: 'fit-content',
        }}
        >

          <OPRButton
            color="primary"
            handleClick={togglePayCycleAlert}
            style={{ borderRadius: '110px' }}
            variant="contained"
          >
            Close Month
          </OPRButton>
        </Box>
      </Box>

      {/* Tabs */}
      <Box>
        <Tabs aria-label="basic tabs example" value={value} onChange={handleTabChange}>
          <Tab label="Pay cycles" {...a11yProps(0)} />
          <Tab label="Logs" {...a11yProps(1)} />
        </Tabs>
      </Box>
      <CustomTabPanel index={0} value={value}>
        <OPRInnerListLayout
          Search={filterData.SearchText}
          addHandleClick={() => togglePayCycleAlert('')}
          columns={payrollMonthEndClosingColumn('')}
          customAdd="Close Month"
          dataList={JSON.parse(JSON.stringify(allPosts?.records || []))}
          error={errorAllPosts}
          filterData={filterData}
          handlePagination={handlePagination}
          handleSearch={onSearch}
          isAdd={false}
          isError={isErrorAllPosts}
          isExport={false}
          isSearch={false}
          loading={isLoadingAllPosts}
          rowNumber={0}
          selelctedUser={selelctedDelete}
          setSelelctedUser={setSelelctedDelete}
          sortHandleClick={sorting}
          title=""
        />
      </CustomTabPanel>

      {/* month end closing logs */}
      <CustomTabPanel index={1} value={value}>
        <OPRInnerListLayout
          isSearch
          Search={filterData.SearchText}
          addHandleClick={() => togglePayCycleAlert('')}
          columns={monthEndClosingLogs('')}
          dataList={JSON.parse(JSON.stringify(allDataMonthEndLogs?.records || []))}
          error={errorAllPosts}
          filterData={filterData}
          handlePagination={handlePagination}
          handleSearch={onSearch}
          isAdd={false}
          isError={isErrorAllPosts}
          isExport={false}
          loading={isLoadingAllPosts}
          rowNumber={0}
          selelctedUser={selelctedDelete}
          setSelelctedUser={setSelelctedDelete}
          sortHandleClick={sorting}
          title=""
        />
      </CustomTabPanel>

      {/* Paycyles Modal */}
      <PayCycles
        data={payCycleData}
        monthName={monthName}
        open={isPayCyclesModalOpen}
        // setPayCycleData={setPayCycleData}
        status="Open"
        year={EntityProfileByIdResponse?.currentPayrollMonthYear}
        onClose={handleBackToMonthEndClosingAlert}
      />

      {/* Render PayCycleAlert modal */}
      <MonthEndClosingAlert
        IsCancelMonthEndAlert={IsCancelMonthEndAlert?.isSuccess === false && IsCancelMonthEndAlert?.IsButtonClick}
        handleCloseMonthEnd={() => setIsPayCyclesModalOpen(true)}
        modalState={IsCancelMonthEndAlert}
        monthClosingData={filterDataEntity} // Open PayCycles modal
        monthName={monthName}
        name={selelctedDelete.name}
        setIsPayCycleAlertOpen={setIsPayCycleAlertOpen}
        title={t('Month end closing')}
        year={EntityProfileByIdResponse?.currentPayrollMonthYear}
        onClose={handleConfirmationModalClose}
      />
      {/* CloseMonthConfirmationAlert */}
      <CloseMonthConfirmationAlert
        closeMonthAlert={IsCancelMonthEndAlert?.isSuccess === true && IsCancelMonthEndAlert?.IsButtonClick}
        handleCloseMonthEndConfirmation={togglePayCycleAlert}
        monthClosingData={filterDataEntity}
        monthName={monthName}
        title={t('Month end closing')}
        year={EntityProfileByIdResponse?.currentPayrollMonthYear}
        onClose={handleConfirmationModalClose}
      />
    </Box>
  )
}

export default PayrollCycleList
