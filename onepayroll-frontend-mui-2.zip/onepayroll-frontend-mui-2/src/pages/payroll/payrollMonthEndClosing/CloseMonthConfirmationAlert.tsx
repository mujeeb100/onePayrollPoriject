import { useTheme } from '@emotion/react'
import {
  Box, Button,
} from '@mui/material'
import { useGetAllEntityProfileSelectedListByIdQuery } from 'api/entityServices'
import { usePayrollMonthEndClosingCreateMutation } from 'api/payRollServices'
import OPRLabel from 'components/atoms/label/OPRLabel'
// import { Info } from '@mui/icons-material'
import { CustomDialog } from 'components/atoms/modal/OPRModal'
import OPRAlertControl from 'components/organism/OPRAlertControl'
import { t } from 'i18next'

type Props = {
    title?: string;
    name?: string;
    open?: boolean;
    callBack?:any;
    onClose?:() => void;
    monthClosingData?: any;
    closeMonthAlert?:boolean;
    handleCloseMonthEndConfirmation?: any;
    handleConfirmMonthEnd?: () => void;
    monthName?: string;
    year?: string;
  };

function CloseMonthConfirmationAlert({
  title = 'Month-end closing confirmation',
  name = '',
  closeMonthAlert = false,
  open,
  onClose,
  monthClosingData,
  //   handleCloseMonthEnd = () => {
  //   },
  callBack = () => {},
  handleConfirmMonthEnd,
  monthName,
  year,
}: Props) {
  const theme:any = useTheme() // Use the Theme type for the theme variable
  //   const location: any = useLocation()
  //   const { id, viewUrl } = getParamsValue(location, routes.createCostCenter)
  //   const [entityProfileData, setEntityprofileData]:any = useState('')
  // monthe end closing create
  const [
    creaeMonthEndClosing,
    {
      data: createdMonthEndCLosingData,
      error: createdMonthEndCLosingError,
      isLoading: createdMonthEndCLosingLoading,
      isSuccess: createdMonthEndCLosingSuccess,
      isError: createdMonthEndCLosingIsError,
    },
  ] = usePayrollMonthEndClosingCreateMutation()

  const {
    data: EntityProfileByIdResponse,
    error: EntityProfileByIdError,
    isLoading: EntityProfileByIdLoading,
    isSuccess: EntityProfileByIdSuccess,
    isError: EntityProfileByIdIsError,
    refetch: refetchEntityProfile, // Add refetch function
  } = useGetAllEntityProfileSelectedListByIdQuery('')

  //   useEffect(() => {
  //     if (EntityProfileByIdSuccess && createdMonthEndCLosingSuccess) {
  //       // Call the API for month-end closing
  //       creaeMonthEndClosing({
  //         year: EntityProfileByIdResponse?.currentPayrollMonthYear,
  //         month: EntityProfileByIdResponse?.currentPayrollMonth,
  //       })
  //     }
  //   }, [EntityProfileByIdSuccess, createdMonthEndCLosingSuccess, EntityProfileByIdResponse, creaeMonthEndClosing])

  const handleSubmit: any = async () => {
    await creaeMonthEndClosing(monthClosingData)
  }

  return (
    <Box>
      <OPRAlertControl
        error={createdMonthEndCLosingError}
        handleSubmit={handleSubmit}
        isError={createdMonthEndCLosingIsError}
        isLoading={
          createdMonthEndCLosingLoading

        }
        isSuccess={createdMonthEndCLosingSuccess}
        name={t('Month end closing')}
        previousUrl="payroll/payrollmonthclosing"
        title={t('Month end Closing')}
        // type={id ? 'Update' : 'New'}
      />
      <CustomDialog
        CustomStyles={{ borderRadius: '16px' }}
        isOpen={closeMonthAlert}
        type="loader"
      >
        {/* <DialogTitle>{title}</DialogTitle> */}
        <Box style={{ marginBottom: '15px' }}>
          <OPRLabel variant="h4">
            {`
            ${title} Confirmation
            `}
          </OPRLabel>
        </Box>

        <Box style={{ marginBottom: '15px' }}>
          <OPRLabel variant="h6">
            Are you sure you want to proceed with the month-end closing process for
            {' '}
            {monthName}
            {' '}
            {year}
            ?
            {' '}
            <br />
            {' '}

          </OPRLabel>
        </Box>
        <Box style={{ marginBottom: '15px' }}>
          <OPRLabel variant="h6">
            You will not be able to revert it.
          </OPRLabel>
        </Box>

        <Box display="flex" justifyContent="space-between" mt={4}>
          <Button color="inherit" variant="text" onClick={onClose}>
            Cancel
          </Button>
          <Button
            color="primary"
            variant="contained"
            onClick={() => {
              handleSubmit()
              onClose && onClose()
            }}
          >
            Confirm
          </Button>
        </Box>
        {/* </DialogContent> */}
      </CustomDialog>
    </Box>
  )
}

export default CloseMonthConfirmationAlert
