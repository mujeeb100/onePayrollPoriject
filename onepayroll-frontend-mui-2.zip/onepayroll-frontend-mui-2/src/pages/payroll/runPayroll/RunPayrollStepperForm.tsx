import { Box } from '@mui/material'
import {
  useCanBeSubmittedCreateMutation,
  useFilteredEmployeesCreateMutation,
  useLazyGetPayrollCycleByIdQuery,
  useRunPayrollCreateMutation,
} from 'api/payRollServices'
import { ReactComponent as SuccessIcon } from 'assets/svg-icons/Tick.svg'
import OPRButton from 'components/atoms/button/OPRButton'
import OPRLabel from 'components/atoms/label/OPRLabel'
import { CustomDialog } from 'components/atoms/modal/OPRModal'
import OPRStepper from 'components/atoms/stepper'
import OPRAlertControl from 'components/organism/OPRAlertControl'
import { OPRInnerFormLayout } from 'components/organism/OPRInnerFormLayout'
import { validationSchemaRunPayroll } from 'constants/validate'
import { useEditable } from 'hooks/useEdit'
import useForm from 'hooks/useForm'
import React, { useEffect, useRef, useState } from 'react'
import { useTranslation } from 'react-i18next'
import { useLocation, useNavigate } from 'react-router-dom'
import { routes } from 'routes/routes'

import { RunPayrollFinal } from './RunPayrollFinal'
import { RunPayrollInformation } from './RunPayrollInfo'
import { RunPayrollSettings } from './RunPayrollSetting'

const defaultData = (item: any) => {
  const defaultValue = {
    divisionCodes: item.divisionCodes || [], // Updated divisionCodes property
    departmentCodes: [],
    costCenterCodes: item.costCenterCodes || [],
    employeeCodes: item.employeeCodes || [],
    teamCodes: item.teamCodes || [],
    payCycleCode: item.payCycleCode,
    calculatePensionFund: item.calculatePensionFund,
    reportGroupCode: 'test',
    exportProcessLogMessage: item.exportProcessLogMessage,
  }
  return defaultValue
}

export default function RunPayrollStepperForm({ id }:any) {
  const [employees, setEmployees]:any = useState([])
  const [selectedCodes, setSelectedCodes] = useState<string[]>([])
  const [selectAll, setSelectAll] = useState(false)
  const myRef:any = useRef()
  const location: any = useLocation()
  const [activeState, setActiveState] = useState(0)
  const { t } = useTranslation()
  const { isEditable, setEditable } = useEditable()
  const [openModal, setModal] = React.useState(false) // Corrected typo here
  const [showSuccessMessage, setShowSuccessMessage] = React.useState(false)
  const [isSuccess, setIsSuccess]:any = useState(false)
  const [employeefilteringOptions, setemployeefilteringOptions] = useState({
    divisions: [],
    departments: [],
    costCenters: [],
    teams: [],
    payCycleCode: '',
  })

  const {
    values,
    setValues,
    errors,
    handleChange,
    setErrors,
    handleFormSubmit,
    handleOnChange,
  } = useForm(validationSchemaRunPayroll)
  const navigate = useNavigate()
  const [
    canBeSubmitted,
    {
      data: updatedCanBeSubmittedData,
      error: updatedCanBeSubmittedError,
      isLoading: updatedCanBeSubmittedIsLoading,
      isSuccess: updatedCanBeSubmitteIsSuccess,
      isError: updatedCanBeSubmittedIsError,
    },
  ] = useCanBeSubmittedCreateMutation('')

  const [
    getFilteredEmployees,
    {
      data: filteredEmployeeData,
      error: filteredEmployeeDataError,
      isLoading: filteredEmployeeDataLoading,
      isSuccess: filteredEmployeeDataIsSuccess,
      isError: ufilteredEmployeeDataIsError,
    },
  ] = useFilteredEmployeesCreateMutation('')

  const [updatePayrollCycleById, {
    data: updatedPayrollCycleByIdResponse,
    error: updatedPayrollCycleByIdError,
    isLoading: updatedPayrollCycleByIdIsLoading,
    isSuccess: updatedPayrollCycleByIdIsSuccess,
    isError: updatedPayrollCycleByIdIsError,
  }] = useLazyGetPayrollCycleByIdQuery()

  const [
    createRunPayroll,
    {
      data: createdRunPayrollData,
      error: createdRunPayrollError,
      isLoading: createdRunPayrollIsLoading,
      isSuccess: createdRunPayrollIsSuccess,
      isError: createdRunPayrollIsError,
    },
  ] = useRunPayrollCreateMutation()

  useEffect(() => {
    if (location.state) {
      updatePayrollCycleById(location.state)
    }
  }, [location.state]) // Update when ID changes

  useEffect(() => {
    if (updatedPayrollCycleByIdResponse?.data) {
      setValues(updatedPayrollCycleByIdResponse.data)
      const payCycleCodeForEmpFilter = `${updatedPayrollCycleByIdResponse.data?.payCycleYear}${updatedPayrollCycleByIdResponse.data?.payCycleMonth}${updatedPayrollCycleByIdResponse.data?.payCycleCode}`
      setemployeefilteringOptions({ ...employeefilteringOptions, payCycleCode: payCycleCodeForEmpFilter })
    }
  }, [updatedPayrollCycleByIdResponse?.data]) // Update values when response data changes

  useEffect(() => {
    if (employeefilteringOptions.payCycleCode !== '') {
      getFilteredEmployees(employeefilteringOptions)
    }
  }, [employeefilteringOptions, getFilteredEmployees])

  useEffect(() => {
    if (filteredEmployeeDataIsSuccess) {
      setEmployees(JSON.parse(JSON.stringify(filteredEmployeeData?.data.employees || [])))
    }
  }, [filteredEmployeeData, filteredEmployeeDataIsSuccess])

  useEffect(() => {
    if (id) {
      setValues(location.state ? location.state : {})
    }
  }, [updatedPayrollCycleByIdResponse?.data])

  const handleRemoveEmployee = (codeToRemove: string) => {
    // Filter out the selected employee code to remove it from the selectedCodes state
    setSelectedCodes(selectedCodes.filter((code) => code !== codeToRemove))
  }

  const handleCheckboxChange = (event: React.ChangeEvent<HTMLInputElement>, code: string) => {
    const { checked } = event.target

    let updatedSelectedCodes
    if (checked) {
      updatedSelectedCodes = [...selectedCodes, code]
    } else {
      updatedSelectedCodes = selectedCodes.filter((selectedCode) => selectedCode !== code)
    }

    setSelectedCodes(updatedSelectedCodes)

    // Check if all employees are selected
    const allEmployeesSelected = updatedSelectedCodes.length === employees.length
    setSelectAll(allEmployeesSelected)
  }

  const handleSelectAllChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const { checked } = event.target

    let updatedSelectedCodes
    if (checked) {
      updatedSelectedCodes = employees.map((employee: any) => employee.employeeCode)
    } else {
      updatedSelectedCodes = []
    }

    setSelectedCodes(updatedSelectedCodes)
    setSelectAll(checked)
  }
  const handleBack = () => {
    setActiveState(activeState - 1)

    // Check all employee checkboxes when navigating back
    setSelectAll(true)

    // Update the state of individual employee checkboxes
    const updatedSelectedCodes = employees.map((employee: any) => employee?.employeeCode)
    setSelectedCodes(updatedSelectedCodes)
  }
  const handleSubmit = async () => {
    const payCycleCode = `${values?.payCycleYear}${values?.payCycleMonth}${values?.payCycleCode}`
    let employeesToSubmit = selectedCodes
    if (selectedCodes.length === 0) {
      employeesToSubmit = employees.map((employee:any) => employee?.employeeCode)
    }
    const data = {
      payCycleCode,
      Employees: employeesToSubmit,
    }
    await canBeSubmitted(data)
  }

  const handleChildSubmit : any = async () => {
    if (isEditable) {
      if (id === null) {
        await createRunPayroll({
          costCenterCode: values?.costCenterCode, // Pass the costCenterCode to the API call
        })
      }
    } else {
      setEditable(true)
    }
  }

  useEffect(() => {
    if (updatedCanBeSubmitteIsSuccess === true) {
      const payCycleCode = `${values?.payCycleYear}${values?.payCycleMonth}${values?.payCycleCode}`
      let employeesToSubmit = selectedCodes
      if (selectedCodes.length === 0) {
        employeesToSubmit = employees.map((employee:any) => employee?.employeeCode)
      }

      const data = {
        payCycleCode,
        employeeCodes: [...employeesToSubmit],
        departmentCodes: values?.departmentCodes ? [values?.departmentCodes] : [],
        costCenterCodes: values?.costCenterCodes ? [values?.costCenterCodes] : [],
        divisionCodes: values?.divisionCodes ? [values?.divisionCodes] : [],
        teamCodes: values?.teamCodes ? [values?.teamCodes] : [],
        calculatePensionFund: values?.calculatePensionFund,
        exportProcessLogMessage: values?.exportProcessLogMessage,
        reportGroupCode: values?.reportGroupCode,

      }
      createRunPayroll(data)
    }
  }, [updatedCanBeSubmitteIsSuccess]) // This effect will run whenever updatedCanBeSubmittedSuccess changes

  const handlePermissionSubmit: any = async () => {
    if (activeState === 1) {
      setActiveState(activeState + 1)
    } else {
      myRef.current.childMethod()
    }
    // myRef.current.childMethod()
  }

  useEffect(() => {
    if (updatedCanBeSubmitteIsSuccess === true) {
      setIsSuccess(true)
    }
  }, [updatedCanBeSubmitteIsSuccess])

  return (

  // successful diallog box

    <>

      {createdRunPayrollIsSuccess === true ? (
        <CustomDialog
          CustomStyles={{ borderRadius: '16px' }}
          isOpen={isSuccess}
          type="loader"
        >
          <div
            className="AtomPopupTitleStrip"
            style={{
              width: '100%', flexDirection: 'column', justifyContent: 'flex-start', alignItems: 'flex-start', gap: 16, display: 'inline-flex',
            }}
          >
            <div
              className="Header"
              style={{
                alignSelf: 'stretch', justifyContent: 'flex-start', alignItems: 'flex-start', gap: 8, display: 'inline-flex',
              }}
            >
              <div
                className="Icon"
                style={{
                  paddingTop: 5, paddingBottom: 5, justifyContent: 'flex-start', alignItems: 'flex-start', display: 'flex',
                }}
              >
                <div className="Tick" style={{ width: 24, height: 24, position: 'relative' }}>
                  <SuccessIcon />
                </div>
              </div>
              <div
                className="Text"
                style={{
                  flex: '1 1 0', flexDirection: 'column', justifyContent: 'flex-start', alignItems: 'flex-start', display: 'inline-flex',
                }}
              >
                <OPRLabel CustomStyles={{ marginTop: 2 }} variant="h4">
                  Payroll run submitted

                </OPRLabel>
                <OPRLabel
                  CustomStyles={{
                    marginTop: '12px',
                    display: 'flex',
                    alignItems: 'center',
                    gap: '12px',
                  }}
                  variant="body2"
                >

                  {updatedPayrollCycleByIdResponse?.data?.payCycleYear}
                  {values?.payCycleMonth}
                  {' '}
                  (
                  {values?.payCycleCode}
                  )

                  {values?.payCycleName}
                  {' '}
                  has been submitted for payroll run. Please refer to the log file for more information.
                </OPRLabel>

              </div>
            </div>
          </div>

          <Box sx={{
            display: 'flex', justifyContent: 'space-between', marginTop: 5,
          }}
          >

            <OPRButton
              color="info"
              style={{ textAlign: 'left', paddingLeft: '15px' }} // Align button text to the left
              variant="text"
              onClick={() => {
                navigate(-1)
              }}
            >
              Go to log
            </OPRButton>

            <OPRButton
              color="info"
              style={{
                display: 'flex',
                padding: '8px 16px',
                alignItems: 'center',
                gap: '12px',
                color: '#FFF',
                background: 'var(--blue-blue-5000049-db, #0049DB)',
              }}
              variant="text"
              onClick={() => {
                navigate(-1)
              }}
            >
              Close
            </OPRButton>

          </Box>
        </CustomDialog>

      ) : null}

      <Box sx={{ display: 'flex' }}>
        <div
          style={{ display: 'flex', width: '100% ' }}
        // onSubmit={(e) => {
        //   activeState === 0 ? handleFormSubmit(e, handleSubmit) : handlePermissionSubmit()
        // }}
        >
          <OPRAlertControl
            error={createdRunPayrollError || updatedCanBeSubmittedError}
            handleEditable={setEditable}
            handleSetValue={setValues}
            handleSubmit={handleSubmit}
            isError={createdRunPayrollIsError || updatedCanBeSubmittedIsError}
            isLoading={updatedCanBeSubmittedIsLoading || createdRunPayrollIsLoading}
            name=""
            title=""
            type={id ? 'Update' : 'New'}
          />
          <OPRInnerFormLayout
            isHandleContinueClick
            isStepper
            customHeader={(
              <>
                <OPRLabel label={`${t('run_payroll')} - ${updatedPayrollCycleByIdResponse?.data?.payCycleYear}-${values?.payCycleMonth}(${values?.payCycleCode})`} variant="h2" />
                <OPRLabel label={` ${values?.payCycleName}`} variant="body" />
              </>
            )}
            error={createdRunPayrollError || updatedCanBeSubmittedError}
            // handleBack={() => { setActiveState(activeState - 1) }}
            handleBack={handleBack}
            handleCancelClick={(e:any) => navigate(-1)}
            handleContinueClick={(e:any) => {
              if (activeState === 2) {
                handleSubmit()
              } else {
                setActiveState(activeState + 1)
              }
            }}
            handleEditable={setEditable}
            isBackButton={activeState > 0}
            isLoading={updatedCanBeSubmittedIsLoading || createdRunPayrollIsLoading}
            pageType="detailsPage"
            previousPageUrl={routes.runPayroll}
            step={activeState}
            subtitle={
              isEditable
                ? 'Please check the user details below.'
                : 'Select specific group of employees to run payroll processing. All fields are mandatory except those marked optional.'
            }
            title={t('Run payroll')}
          >
            <Box sx={{ margin: '20px 0' }}>
              <OPRStepper
                activeStep={activeState}
                steps={[
                  t('Filtering criteria'),
                  t('Run payroll'),
                  t('Confirmation'),
                ]}

              />
              {activeState === 0 && (
                <RunPayrollInformation
                  isIndividualPage
                  employees={employees}
                  errors={errors}
                  filteredDataLoading={filteredEmployeeDataLoading}
                  filteredDataSuccess={filteredEmployeeDataIsSuccess}
                  handleChange={handleChange}
                  handleCheckboxChange={handleCheckboxChange}
                  handleChildSubmit={handleChildSubmit}
                  handleOnChange={handleOnChange}
                  handleRemoveEmployee={handleRemoveEmployee}
                  handleSelectAllChange={handleSelectAllChange}
                  isEditable={isEditable}
                  selectAll={selectAll}
                  selectedCodes={selectedCodes}
                  values={values}
                />
              )}

              {activeState === 1 && (
                <RunPayrollSettings
                  isIndividualPage
                  errors={errors}
                  handleChange={handleChange}
                  handleOnChange={handleOnChange}
                  isEditable={isEditable}
                  values={values}
                />
              )}

              {activeState === 2 && (
                <RunPayrollFinal
                  isFinalComponent // Set to true to display the OPRLabel
                  employees={employees}
                  errors={errors}
                  handleChange={handleChange}
                  handleCheckboxChange={handleCheckboxChange}
                  handleOnChange={handleOnChange}
                  handleRemoveEmployee={handleRemoveEmployee}
                  handleSelectAllChange={handleSelectAllChange}
                  id={location.state}
                  isEditable={isEditable}
                  isIndividualPage={false} // Set to false to indicate it's not an individual page
                  selectAll={selectAll}
                  selectedCodes={selectedCodes}
                  values={values}
                />
              )}

            </Box>
          </OPRInnerFormLayout>
        </div>
      </Box>
    </>
  )
}
