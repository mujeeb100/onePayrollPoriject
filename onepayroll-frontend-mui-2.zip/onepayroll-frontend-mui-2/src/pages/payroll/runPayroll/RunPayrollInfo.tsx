import { Box, Divider, Grid } from '@mui/material'
import {
  useGetAllCostCenterQuery, useGetAllDepartmentQuery, useGetAllDivisionQuery,
  useGetAllTeamQuery,
} from 'api/entityServices'
import { EmpIcon, MenuKebab } from 'assets/svg-images/SvgComponents'
import OPRButton from 'components/atoms/button/OPRButton'
import OPRLabel from 'components/atoms/label/OPRLabel'
import CustomLoader from 'components/atoms/loader/OPRLoader'
import { CustomDialog } from 'components/atoms/modal/OPRModal'
import OPRResponsiveGrid from 'components/molecules/OPRResponsiveGrid'
import OPRSearchIcon from 'components/molecules/OPRSearchIcon'
import OPRSelectorControl from 'components/molecules/OPRSelectorControl/OPRSelectorControl'
import { t } from 'i18next'
import React, { useState } from 'react'
import { generateFilterUrl } from 'utils'

import CustomCheckbox from './EmployeeCheckbox'

export function RunPayrollInformation({
  errors, isEditable, values, handleChange, handleOnChange, handleClose, setValues, isOpen,
  isFinalComponent, selectedCodes, handleRemoveEmployee, handleCheckboxChange, handleSelectAllChange,
  selectAll, employees, handleChildSubmit, filteredDataSuccess, filteredDataLoading,
}: any) {
  const [selected, setSelected] = React.useState<readonly number[]>([])
  const [checkedValue, setCheckedValue] = React.useState<any[]>([])
  const [userEntityData, setUserEntityData] = useState({
    SearchText: '',
  })
  const [empSearchData, setempSearchData] = useState({
    SearchText: '',
  })
  const [isSkip, setIsSkip] = useState(true)
  const [isRemove, setIsRemove] = useState(false)
  const [selectedEmployeeCodes, setSelectedEmployeeCodes] = useState<string[]>([])
  const [filterData, setFilterData]: any = useState({
    pageNumber: 1,
    pageSize: 1000,
    totalItems: 0,
    orderByAsc: true,
    sortBy: '',
    SearchText: '',
  })

  const {
    data: allDivision,
  } = useGetAllDivisionQuery(generateFilterUrl(filterData))

  const {
    data: allDepartment,
  } = useGetAllDepartmentQuery('')

  const {
    data: allCostCenter,
  } = useGetAllCostCenterQuery('')

  const {
    data: allTeam,
  } = useGetAllTeamQuery('')

  const [isEmployeeModalOpen, setIsEmployeeModalOpen] = useState(false)
  const [isProcessingModalOpen, setProcessingModalOpen] = useState(false)
  const [steps, setSteps] = useState(0)
  const [isEditables, setIsEditables] = useState(false)

  // Function to handle opening the employee modal
  const handleEmployeeModalOpen = () => {
    setIsEmployeeModalOpen(true)
    setProcessingModalOpen(true)
  }

  // Function to handle closing the employee modal
  const handleEmployeeModalClose = () => {
    setIsEmployeeModalOpen(false)
  }

  const handleSubmit: any = () => {

  }

  // const handleResume = () => {
  //   if (steps === 0) {
  //     setIsEditables(true)
  //     setSteps((prev) => prev + 1)
  //   } else if (steps === 1) {
  //     handleSubmit()
  //     handleClose()
  //   } else {
  //     handleClose()
  //     setValues({})
  //     setSteps(0)
  //   }
  // }
  const handleClick = (event: React.MouseEvent<unknown>, item: any) => {
    const selectedIndex = selected.indexOf(item.id)
    let newSelected: readonly number[] = []
    if (selectedIndex === -1) {
      newSelected = newSelected.concat(selected, item.id)
      setCheckedValue([
        ...checkedValue,
        item,
      ])
    } else if (selectedIndex === 0) {
      newSelected = newSelected.concat(selected.slice(1))
      setCheckedValue(checkedValue.filter((val) => val.id !== item.id))
    } else if (selectedIndex === selected.length - 1) {
      newSelected = newSelected.concat(selected.slice(0, -1))
      setCheckedValue(checkedValue.filter((val) => val.id !== item.id))
    } else if (selectedIndex > 0) {
      newSelected = newSelected.concat(
        selected.slice(0, selectedIndex),
        selected.slice(selectedIndex + 1),
      )
      setCheckedValue(checkedValue.filter((val) => val.id !== item.id))
    }
    setSelected(newSelected)
  }
  const handleUserClick = (item: any) => {
    // setDuplicateItem(item)
    setUserEntityData({ ...filterData, SearchText: item?.firstName })
    setIsSkip(false)
    setSteps((prev) => prev + 1)
  }
  const isSelected = (id: any) => selected.indexOf(id) !== -1

  const handleEmployeeSelection = (selectedCodes: string[]) => {
    setSelectedEmployeeCodes(selectedCodes)
  }
  const handleContinue = () => {
    // Handle continue button click, e.g., save data or perform any action
    handleEmployeeModalClose()
  }
  const onSearch = (e: any) => {
    setempSearchData({ ...empSearchData, SearchText: e.target.value })
  }
  // Filter employees based on the search text
  const filteredEmployees = employees?.filter((employee: any) => employee.displayName.toLowerCase().includes(empSearchData.SearchText.toLowerCase()) || employee.employeeCode.toLowerCase().includes(empSearchData.SearchText.toLowerCase()))

  const selectedEmployees = selectedCodes?.map((code:any) => {
    const employee = employees?.find((emp:any) => emp.employeeCode === code)

    if (employee) {
      return (
        <Box
          key={code}
          style={{
            display: 'flex', alignItems: 'center', justifyContent: 'space-between', margin: '5px 20px',
          }}
        >
          <Box>
            <OPRLabel label={`${employee.displayName} `} variant="subtitle2" />
            <OPRLabel label={employee.employeeCode} variant="body2" />
          </Box>

          <Box>
            <OPRButton variant="text" onClick={() => handleRemoveEmployee(code)}><MenuKebab /></OPRButton>
          </Box>
        </Box>
      )
    }
    return null
  })

  return (
    <Box>
      {isFinalComponent ? (
        <div style={{ display: 'block', width: '100%', margin: '40px 0px 20px' }}>
          <OPRLabel variant="h3">Filtering criteria</OPRLabel>
        </div>
      ) : (
        <OPRLabel sx={{ marginTop: '20px', marginBottom: '40px' }} variant="body2">
          {`  ${t('Select specific group of employees to run payroll processing. All fields are mandatory except those marked optional.')}`}
        </OPRLabel>
      )}
      <OPRResponsiveGrid>

        <Grid item md={2} sm={1} xs={1}>

          <OPRSelectorControl
            // multiple
            error={errors?.divisionCode}
            isEditable={isEditable}
            keyName="divisionCode"
            label="Division"
            name="divisionCode"
            optionalText="Optional"
            options={(allDivision?.records || [])}
            placeholder="Select an option"
            value={(allDivision?.records || [])?.find((o:any) => o?.divisionCode === values?.divisionCodes) || {}}
            valueKey="divisionCode"
            onChange={(text:any) => {
              handleOnChange('divisionCodes', text?.divisionCode)
            }}
          />

          {/* <OPRSelectorControl
            error={errors?.divisionCode}
            isEditable={isEditable}
            keyName="divisionCode"
            label="Division"
            multiple={false}
            name="divisionCode"
            optionalText="Optional"
            options={allDivision?.records?.map((item: any) => ({
              ...item,
              label: item.divisionCode,
              value: item.id,
            })) || []}
            placeholder="Select an option"
            value={values.divisionCodes}
            valueKey="divisionCode"
            onChange={(selectedItem: any) => {
              handleOnChange('divisionCodes', selectedItem.divisionCode)
            }}
          /> */}
        </Grid>
        <Grid item md={2} sm={1} xs={1}>
          <OPRSelectorControl
            error={errors?.departmentCode}
            isEditable={isEditable}
            keyName="departmentCode"
            label="Department"
            multiple={false}
            name="departmentCode"
            optionalText="Optional"
            options={(allDepartment?.records || [])}
            placeholder="Select an option"
            value={(allDepartment?.records || [])?.find((o:any) => o?.departmentCode === values?.departmentCodes) || {}}
            valueKey="departmentCode"
            onChange={(text:any) => {
              handleOnChange('departmentCodes', text?.departmentCode)
            }}
          />
        </Grid>
        <Grid item md={2} sm={1} xs={1}>
          <OPRSelectorControl
            error={errors?.costCenterCode}
            isEditable={isEditable}
            keyName="costCenterCode"
            label="Cost Center"
            multiple={false}
            name="costCenterCode"
            optionalText="Optional"
            options={(allCostCenter?.records || [])}
            placeholder="Select an option"
            value={(allCostCenter?.records || [])?.find((o:any) => o?.costCenterCode === values?.costCenterCodes) || {}}
            valueKey="costCenterCode"
            onChange={(text:any) => {
              handleOnChange('costCenterCodes', text?.costCenterCode)
            }}
          />
        </Grid>
        <Grid item md={2} sm={1} xs={1}>
          <OPRSelectorControl
            error={errors?.teamCode}
            isEditable={isEditable}
            keyName="teamCode"
            label="Team"
            multiple={false}
            name="teamCode"
            optionalText="Optional"
            options={(allTeam?.records || [])}
            placeholder="Select an option"
            value={(allTeam?.records || [])?.find((o:any) => o?.teamCode === values?.teamCodes) || {}}
            valueKey="teamCode"
            onChange={(text:any) => {
              handleOnChange('teamCodes', text?.teamCode)
            }}
          />
        </Grid>

        <div style={{ display: 'block', width: '100%', margin: '40px 20px 20px' }}>
          {isFinalComponent ? (
            <OPRLabel variant="h3">Employee</OPRLabel>

          ) : (
            <>
              <OPRLabel variant="h3">Employee</OPRLabel>
              <OPRLabel variant="body2">If no employee is selected, the system will process payroll for all employees for the selected pay cycles.</OPRLabel>
            </>
          )}

          <div style={{
            margin: '20px 0',
            color: '#3B3839',
            fontSize: 12,
            fontFamily: 'Lato',
            fontWeight: '700',
            wordWrap: 'break-word',
          }}
          >
            Employee name | Employee code
          </div>

          {/* Check if selectedEmployees array has any selected employees */}
          {selectedEmployees.length > 0 ? (
          // Render only if there are selected employees
            selectedEmployees
          ) : (
          // Render the buttons if no employees are selected
            <Box sx={{ display: 'block', justifyContent: 'space-between', marginTop: '80px' }}>
              <Box
                className="pop-up"
                sx={{
                  display: 'flex',

                  gap: '12px',
                  alignItems: 'center',
                  borderRadius: '4px',
                  alignSelf: 'stretch',
                  justifyContent: 'center',
                  marginTop: 1,
                }}
              >
                <EmpIcon />
                <OPRLabel variant="body2">

                  No employee is selected

                </OPRLabel>
              </Box>

              {!isFinalComponent && ( // Render the button only if it's not the third component
                <OPRButton
                  disabled={isFinalComponent && (selectedEmployeeCodes.length === 0 || selectedCodes.length > 0)}
                  sx={{ margin: '0px auto', display: 'flex' }}
                  variant="text"
                  onClick={handleEmployeeModalOpen}
                >
                  Select Employee
                </OPRButton>
              )}

            </Box>
          )}
        </div>
        {selectedCodes.length > 0 && (
          <div style={{
            borderRadius: '4px',
            background: '#E9F4FF',
            width: '100%',
            padding: '10px',
          }}
          >
            <OPRLabel
              variant="body2"
            >

              <>
                Total selected employees:
                {' '}
                {selectedCodes.length}
              </>

            </OPRLabel>
          </div>
        )}
        {filteredDataLoading
        && (
          <CustomDialog
            CustomStyles={{ borderRadius: '16px' }}
            isOpen={filteredDataLoading && isProcessingModalOpen}
            type="loader"
          >
            <CustomLoader text="Processing request" />
          </CustomDialog>
        )}
        {filteredDataSuccess
        && (
          <CustomDialog
            isResume
            closeTitle="Cancel"
            handleClose={handleEmployeeModalClose}
            handleResume={handleContinue} // Pass handleContinue here
            isOpen={isEmployeeModalOpen}
            resumeTitle="Continue"
            // subtitle="Search for an existing employee"
            title="Select employee"
            onSelection={handleEmployeeSelection}
          >
            <Box>
              <OPRLabel CustomStyles={{ marginBottom: '15px' }} variant="body2">Search for an existing employee</OPRLabel>
              <OPRSearchIcon placeholder="Search " value={empSearchData.SearchText} onChange={onSearch} />
              <Divider />
            </Box>
            <Box sx={{ }}>
              <Box>
                <div>
                  {/* Display selected employee codes */}
                  {selectedEmployeeCodes.length > 0 && (
                    <div>
                      <p>
                        Selected Employee Codes:
                        {selectedEmployeeCodes.join(', ')}

                      </p>
                    </div>
                  )}
                  {/* Pass handleEmployeeSelection as a prop to CustomCheckbox */}
                  <CustomCheckbox
                    employees={filteredEmployees}
                    handleCheckboxChange={handleCheckboxChange}
                    handleRemoveEmployee={handleRemoveEmployee}
                    handleSelectAllChange={handleSelectAllChange}
                    selectAll={selectAll}
                    selectedCodes={selectedCodes}
                    onChange={handleEmployeeSelection}
                  />
                </div>
              </Box>
            </Box>
          </CustomDialog>
        )}
      </OPRResponsiveGrid>
    </Box>
  )
}
