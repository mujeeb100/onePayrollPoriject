import React, { useState } from 'react'

interface CustomCheckboxProps {
  employees: { code: string; personalEmailAddress: string; surname: string; givenName: string }[];
  selectedCodes: string[];
  handleCheckboxChange: (event: React.ChangeEvent<HTMLInputElement>, code: string) => void;
  handleRemoveEmployee: (codeToRemove: string) => void;
  handleSelectAllChange: (event: React.ChangeEvent<HTMLInputElement>) => void;
  selectAll: boolean;
}
function CustomCheckbox1() {
  const [employees, setEmployees]:any = useState([
    { code: 'EMP001', name: 'John Doe' },
    { code: 'EMP002', name: 'Jane Smith' },
    { code: 'EMP003', name: 'Michael Johnson' },
    // Add more employees as needed
  ])
  const [selectedCodes, setSelectedCodes] = useState<string[]>([])
  const [selectAll, setSelectAll] = useState(false)
  const handleCheckboxChange = (event: React.ChangeEvent<HTMLInputElement>, code: string) => {
    const { checked } = event.target
    if (checked) {
      setSelectedCodes([...selectedCodes, code])
    } else {
      setSelectedCodes(selectedCodes.filter((selectedCode) => selectedCode !== code))
    }
  }
  const handleRemoveEmployee = (codeToRemove: string) => {
    // Filter out the selected employee code to remove it from the selectedCodes state
    setSelectedCodes(selectedCodes.filter((code) => code !== codeToRemove))
  }
  const handleSelectAllChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const { checked } = event.target
    if (checked) {
      setSelectedCodes(employees.map((employee:any) => employee.employeeCode))
    } else {
      setSelectedCodes([])
    }
    setSelectAll(checked)
  }
  return (
    <div>
      <label style={{ marginBottom: '10px', marginTop: '10px', display: 'block' }}>
        <input
          checked={selectAll}
          type="checkbox"
          onChange={handleSelectAllChange}
        />
        {' '}
        Select All
      </label>
      <hr style={{ borderColor: '#E8E6E7', marginBottom: '10px' }} />
      {employees.map((employee:any) => (
        <div key={employee.code}>
          <div style={{ display: 'flex', alignItems: 'center', marginBottom: '5px' }}>
            <label style={{ marginRight: '10px' }}>
              <input
                checked={selectedCodes.includes(employee.employeeCode)}
                type="checkbox"
                value={employee.employeeCode}
                onChange={(event) => handleCheckboxChange(event, employee.employeeCode)}
              />
              {`${employee.personalEmailAddress} (${employee.surname}, ${employee.givenName})`}
            </label>
          </div>
          <hr style={{ borderColor: '#E8E6E7', marginTop: '5px', marginBottom: '5px' }} />
        </div>
      ))}

    </div>
  )
}

export default CustomCheckbox1
