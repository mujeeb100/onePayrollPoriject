import { Box, Grid } from '@mui/material'
import { useGetAllReportGroupQuery } from 'api/reportingServices'
import OPRLabel from 'components/atoms/label/OPRLabel'
import OPRResponsiveGrid from 'components/molecules/OPRResponsiveGrid'
import OPRSelectorControl from 'components/molecules/OPRSelectorControl/OPRSelectorControl'
import { t } from 'i18next'
import { useState } from 'react'
import { generateFilterUrl } from 'utils'

export function RunPayrollSettings({
  errors, isEditable, values, handleChange, handleOnChange, isFinalComponent,
}:any) {
  const [filterData, setFilterData]:any = useState({
    pageNumber: 1,
    pageSize: 20,
    totalItems: 0,
    orderByAsc: true,
    sortBy: '',
    SearchText: '',
  })

  const {
    data: allReport,
  } = useGetAllReportGroupQuery(generateFilterUrl(filterData))

  return (
    <Box>

      {isFinalComponent ? (
        <div style={{ display: 'block', width: '100%', margin: '30px 0px 20px' }}>
          <OPRLabel variant="h3">Run payroll information</OPRLabel>
        </div>
      ) : (
        <OPRLabel sx={{ marginTop: '20px', marginBottom: '40px' }} variant="body2">
          {`  ${t('form_structure_title_des')}`}
        </OPRLabel>
      )}
      <OPRResponsiveGrid>

        <Grid item md={2} sm={1} xs={1}>
          <OPRSelectorControl
            error={errors?.calculatePensionFund}
            isEditable={isEditable}
            keyName="calculatePensionFund"
            label="Calculate pension fund"
            multiple={false}
            name="calculatePensionFund"
            options={[{ calculatePensionFund: 'Yes', values: true }, { calculatePensionFund: 'No', values: false }]}
            placeholder="Select an option"
            value={[{ calculatePensionFund: 'Yes', values: true }, { calculatePensionFund: 'No', values: false }]?.find((o:any) => o?.values === values?.calculatePensionFund) || {}}
            valueKey="calculatePensionFund"
            onChange={(text:any) => {
              handleOnChange('calculatePensionFund', text?.values)
            }}
          />
        </Grid>
        <Grid item md={2} sm={1} xs={1}>
          <OPRSelectorControl
            error={errors?.exportProcessLogMessage}
            isEditable={isEditable}
            keyName="exportProcessLogMessage"
            label="Export process log message"
            multiple={false}
            name="exportProcessLogMessage"
            options={[{ exportProcessLogMessage: 'Yes', values: true }, { exportProcessLogMessage: 'No', values: false }]}
            placeholder="Select an option"
            value={[{ exportProcessLogMessage: 'Yes', values: true }, { exportProcessLogMessage: 'No', values: false }]?.find((o:any) => o?.values === values?.exportProcessLogMessage) || {}}
            valueKey="exportProcessLogMessage"
            onChange={(text:any) => {
              handleOnChange('exportProcessLogMessage', text?.values)
            }}
          />
        </Grid>

        <Grid item md={2} sm={1} xs={1}>

          <OPRSelectorControl
            error={errors?.code}
            isEditable={isEditable}
            keyName="code"
            label="Report group"
            multiple={false}
            name="code"
            optionalText="Optional"
            options={(allReport?.records || [])}
            placeholder="Select an option"
            value={(allReport?.records || [])?.find((o:any) => o?.code === values?.reportGroupCode) || {}}
            valueKey="code"
            onChange={(text:any) => {
              handleOnChange('reportGroupCode', text?.code)
            }}
          />

        </Grid>

        <Grid item md={2} sm={1} xs={1} />

      </OPRResponsiveGrid>
    </Box>
  )
}
