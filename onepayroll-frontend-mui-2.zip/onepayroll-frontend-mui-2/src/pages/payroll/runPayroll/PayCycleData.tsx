import { Box, Grid } from '@mui/material'
import {
  useLazyGetPayrollCycleByIdQuery,
  usePayrollCycleCreateMutation,
  usePayrollCycleUpdateMutation,
} from 'api/payRollServices'
import OPRLabel from 'components/atoms/label/OPRLabel'
import OPRInputControl from 'components/molecules/OPRInputControl'
import OPRResponsiveGrid from 'components/molecules/OPRResponsiveGrid'
import OPRAlertControl from 'components/organism/OPRAlertControl'
import { validationSchemaPayrollAdministratorScheme } from 'constants/validate'
import { useEditable } from 'hooks/useEdit'
import useForm from 'hooks/useForm'
import { t } from 'i18next'
import { useEffect, useState } from 'react'
import { useLocation, useNavigate } from 'react-router-dom'

const defaultValues = {
  payCycleYear: '',
  payCycleMonth: '',
  payCycleCode: '',
  payCycleName: '',
  payCycleStartDate: '',
  payCycleEndDate: '',
  payCycleCutOffDate: null,
  payCyclePayDate: null,
  paymentMethod: '',
  remarks: '',
  status: '',
  payCycleType: '',
  companyBankAccount: '',
}

export function PayCycleData({
  errors, isEditable, values, handleChange, handleOnChange, isFinalComponent, id,
}:any) {
  const location: any = useLocation()
  const [isId, setId] = useState(null)
  const {
    setEditable,
  } = useEditable()

  const {
    setValues,
    setErrors,
    handleFormSubmit,
  } = useForm(validationSchemaPayrollAdministratorScheme)

  const navigate = useNavigate()

  const [createPayrollCycle, {
    data: createdPayrollCycleData,
    error: createdPayrollCycleError,
    isLoading: createdPayrollCycleLoading,
    isSuccess: createdPayrollCycleSuccess,
    isError: createdPayrollCycleIsError,
  }] = usePayrollCycleCreateMutation()

  const [updatePayrollCycle, {
    data: updatedDataResponse,
    error: updatedPayrollCycleError,
    isLoading: updatedPayrollCycleLoading,
    isSuccess: updatedPayrollCycleSuccess,
    isError: updatedPayrollCycleIsError,
  }] = usePayrollCycleUpdateMutation()

  const [updatePayrollCycleById, {
    data: updatedPayrollCycleByIdResponse,
    error: updatedPayrollCycleByIdError,
    isLoading: updatedPayrollCycleByIdLoading,
    isSuccess: updatedPayrollCycleByIdSuccess,
    isError: updatedPayrollCycleByIdIsError,
  }] = useLazyGetPayrollCycleByIdQuery()

  useEffect(() => {
    if (id) {
      updatePayrollCycleById(id)
      // setEditable(viewUrl)
    }
  }, [id]) // Update when ID changes

  useEffect(() => {
    if (updatedPayrollCycleByIdResponse?.data) {
      setValues(updatedPayrollCycleByIdResponse.data)
    }
  }, [updatedPayrollCycleByIdResponse?.data]) // Update values when response data changes

  useEffect(() => {
    if (id) {
      setValues(location.state ? location.state : {})
    }
  }, [updatedPayrollCycleByIdResponse?.data])

  useEffect(() => {
    if (createdPayrollCycleSuccess) {
      // Reset form values after successful add operation
      setValues({})
      setErrors({})
    }
  }, [createdPayrollCycleSuccess])

  useEffect(() => {
    if (id === null) {
      setValues(defaultValues)
    }
  }, [])

  const handleSubmit: any = async () => {
    if (isEditable) {
      if (id === null) {
        await createPayrollCycle({
          payCycleYear: values?.payCycleYear,
          payCycleMonth: values?.payCycleMonth,
          payCycleCode: values?.payCycleCode,
          payCycleName: values?.payCycleName,
          payCycleStartDate: values?.payCycleStartDate,
          payCycleEndDate: values?.payCycleEndDate,
          payCycleCutOffDate: values?.payCycleCutOffDate,
          payCyclePayDate: values?.payCyclePayDate,
          paymentMethod: values?.paymentMethod || '',
          remarks: values?.remarks || '',
          statusId: values?.status?.id, // Include status here
          status: values?.status, // Include status here
          payCycleTypeId: values?.payCycleType?.id || '',
          payCycleType: values?.payCycleType,
          companyBankAccount: values?.companyBankAccount || '',

        })
      } else {
        await updatePayrollCycle({
          id: values?.id,
          payCycleYear: values?.payCycleYear,
          payCycleMonth: values?.payCycleMonth,
          payCycleCode: values?.payCycleCode,
          payCycleName: values?.payCycleName,
          payCycleStartDate: values?.payCycleStartDate,
          payCycleEndDate: values?.payCycleEndDate,
          payCycleCutOffDate: values?.payCycleCutOffDate,
          payCyclePayDate: values?.payCyclePayDate,
          paymentMethod: values?.paymentMethod,
          remarks: values?.remarks || '',
          status: values?.status, // Include status here
        })
      }
    } else {
      setEditable(true)
    }
  }

  async function editPayrollCycle() {
    await updatePayrollCycle({
      id: values?.id,
      payCycleYear: values?.payCycleYear,
      payCycleMonth: values?.payCycleMonth,
      payCycleCode: values?.payCycleCode,
      payCycleName: values?.payCycleName,
      payCycleStartDate: values?.payCycleStartDate,
      payCycleEndDate: values?.payCycleEndDate,
      payCycleCutOffDate: values?.payCycleCutOffDate,
      payCyclePayDate: values?.payCyclePayDate,
      paymentMethod: values?.paymentMethod,
      remarks: values?.remarks || '',
      status: values?.status, // Include status here

    })
  }

  const onScreenClose: any = (item: any) => {
    setEditable(item)
    setValues({})
  }
  const startDate = new Date(values?.payCycleStartDate)
  const formattedStartDate = startDate.toLocaleDateString('en-GB', {
    day: '2-digit',
    month: 'short',
    year: 'numeric',
  })
  const endDate = new Date(values?.payCycleStartDate)
  const formattedEndDate = startDate.toLocaleDateString('en-GB', {
    day: '2-digit',
    month: 'short',
    year: 'numeric',
  })
  return (
    <Box sx={{ display: 'flex' }}>
      <form style={{ display: 'flex', width: '100% ' }} onSubmit={(e) => handleFormSubmit(e, handleSubmit)}>
        <OPRAlertControl
          error={createdPayrollCycleError || updatedPayrollCycleError}
          handleEditable={setEditable}
          handleSetValue={setValues}
          handleSubmit={handleSubmit}
          isError={createdPayrollCycleError || updatedPayrollCycleError}
          isLoading={createdPayrollCycleLoading || updatedPayrollCycleLoading || updatedPayrollCycleByIdLoading}
          isSuccess={updatedPayrollCycleSuccess || createdPayrollCycleSuccess}
          name={values?.itemGroupName}
          title={t('pay_item_group_title')}
          type={id ? 'Update' : 'New'}
        />

        <Box>
          {isFinalComponent && (
            <div style={{ display: 'block', width: '100%', margin: '10px 0px 20px' }}>
              <OPRLabel variant="h3">Pay cycle information</OPRLabel>
            </div>
          )}
          <OPRResponsiveGrid>

            {/* paycycleYear  */}
            <Grid item md={2} sm={1} xs={1}>
              <OPRInputControl
                isEditable
                label="Pay cycle"
                name="payCycleYear"
                value={`${updatedPayrollCycleByIdResponse?.data?.payCycleYear}-${updatedPayrollCycleByIdResponse?.data?.payCycleMonth}`}
                onChange={handleChange}
              />
            </Grid>

            {/* paycyclecode */}
            <Grid item md={2} sm={1} xs={1}>
              <OPRInputControl
                isEditable
                error={errors?.payCycleCode}
                label="Pay Cycle Code"
                name="payCycleCode"
                value={updatedPayrollCycleByIdResponse?.data?.payCycleCode}
                onChange={handleChange}
              />

            </Grid>
            {/* paycycleName */}
            <Grid item md={2} sm={1} xs={1}>
              <OPRInputControl
                isEditable
                error={errors?.payCycleName}
                label="Pay Cycle Name"
                name="payCycleName"
                value={updatedPayrollCycleByIdResponse?.data?.payCycleName}
                onChange={handleChange}
              />
            </Grid>

            <Grid item md={2} sm={1} xs={1}>
              <OPRInputControl
                isEditable
                error={errors?.payCycleName}
                label="Pay period"
                name="payCycleName"
                value={`${updatedPayrollCycleByIdResponse?.data?.payCycleStartDate}-${updatedPayrollCycleByIdResponse?.data?.payCycleEndDate}`}
                onChange={handleChange}
              />
            </Grid>

          </OPRResponsiveGrid>
        </Box>

      </form>
    </Box>
  )
}
