import { Box } from '@mui/material'
import OPRLabel from 'components/atoms/label/OPRLabel'
import { t } from 'i18next'
import React from 'react'

import { PayCycleData } from './PayCycleData'
import { RunPayrollInformation } from './RunPayrollInfo'
import { RunPayrollSettings } from './RunPayrollSetting'

export function RunPayrollFinal({
  errors, isEditable, values, handleChange, handleOnChange,
  isFinalComponent, isIndividualPage,
  handleSelectAllChange,
  handleRemoveEmployee,
  handleCheckboxChange,
  employees,
  selectAll,
  selectedCodes,
  id,
}:any) {
  const handleTabChange = (event: React.SyntheticEvent, newValue: number) => {
    setValue(newValue)
  }

  const [value, setValue] = React.useState(0)

  // change here

  return (
    <Box sx={{ width: '100%' }}>
      {(isFinalComponent && !isIndividualPage) && ( // Display OPRLabel only when isFinalComponent is true and not within an individual page
        <OPRLabel sx={{ marginTop: '20px', marginBottom: '40px' }} variant="body2">
          {`  ${t('please_check_details_below')}`}
        </OPRLabel>
      )}
      {/* <RunPayrollProcess
        isEditable
        errors={errors}
        handleChange={handleChange}
        handleOnChange={handleOnChange}
        values={values}
      /> */}

      <PayCycleData
        errors={errors}
        handleChange={handleChange}
        handleOnChange={handleOnChange}
        id={id}
        isEditable={isEditable}
        isFinalComponent={isFinalComponent}
        values={values}
      />

      <RunPayrollInformation
        isEditable
        isIndividualPage
        employees={employees}
        errors={errors}
        handleChange={handleChange}
        handleCheckboxChange={handleCheckboxChange}
        handleOnChange={handleOnChange}
        handleRemoveEmployee={handleRemoveEmployee}
        handleSelectAllChange={handleSelectAllChange}
        isFinalComponent={isFinalComponent}
        selectAll={selectAll}
        selectedCodes={selectedCodes}
        values={values}
      />

      <RunPayrollSettings
        isEditable
        errors={errors}
        handleChange={handleChange}
        handleOnChange={handleOnChange}
        isFinalComponent={isFinalComponent}
        values={values}
      />

    </Box>
  )
}
