import { Box, Grid } from '@mui/material'
import {
  useGetAllPayCycleMasterDropDownQuery,
  useLazyGetPayrollCycleByIdQuery, usePayrollCycleCreateMutation, usePayrollCycleUpdateMutation,
} from 'api/payRollServices'
import { CustomDialog } from 'components/atoms/modal/OPRModal'
import OPRInputControl from 'components/molecules/OPRInputControl'
import OPRResponsiveGrid from 'components/molecules/OPRResponsiveGrid'
import OPRAlertControl from 'components/organism/OPRAlertControl'
import { validationSchemaPayrollAdministratorScheme } from 'constants/validate'
import { useEditable } from 'hooks/useEdit'
import useForm from 'hooks/useForm'
import React, { useEffect, useState } from 'react'
import { useLocation, useNavigate } from 'react-router-dom'
import { routes } from 'routes/routes'
import { getParamsValue } from 'utils'

type RunPayrollProcessProps = {
  onClick?: (data: any, type: string) => void;
  handleClose: () => void;
  isDelete?: boolean;
  isOpen: boolean;
  payItem: any;
 selectedId:any;

};

function RunPayrollProcess({
  onClick,
  isDelete = false,
  isOpen,
  payItem,
  handleClose,
  selectedId,

}: RunPayrollProcessProps) {
  const [steps, setSteps] = useState(0)
  const [isEditables, setIsEditables] = useState(false)
  // const [selectedId, setSelectedId] = useState()

  const [payGroup, setPayGroup] = React.useState('')

  const location: any = useLocation()
  const { id, viewUrl } = getParamsValue(location, routes.createPayCycleAdministration)
  const {
    isEditable,
    setEditable,
  } = useEditable()

  const {
    values,
    setValues,
    errors,
    handleChange,
    setErrors,
    handleFormSubmit,
    handleOnChange,
  } = useForm(validationSchemaPayrollAdministratorScheme)

  const navigate = useNavigate()

  const [createPayrollCycle, {
    data: createdPayrollCycleData,
    error: createdPayrollCycleError,
    isLoading: createdPayrollCycleLoading,
    isSuccess: createdPayrollCycleSuccess,
    isError: createdPayrollCycleIsError,
  }] = usePayrollCycleCreateMutation()

  const [updatePayrollCycle, {
    data: updatedDataResponse,
    error: updatedPayrollCycleError,
    isLoading: updatedPayrollCycleLoading,
    isSuccess: updatedPayrollCycleSuccess,
    isError: updatedPayrollCycleIsError,
  }] = usePayrollCycleUpdateMutation()

  const [updatePayrollCycleById, {
    data: updatedPayrollCycleByIdResponse,
    error: updatedPayrollCycleByIdError,
    isLoading: updatedPayrollCycleByIdLoading,
    isSuccess: updatedPayrollCycleByIdSuccess,
    isError: updatedPayrollCycleByIdIsError,
  }] = useLazyGetPayrollCycleByIdQuery()

  useEffect(() => {
    if (selectedId) {
      updatePayrollCycleById(selectedId)
      setEditable(viewUrl)
    }
  }, [selectedId])

  useEffect(() => {
    if (id) {
      setValues(updatedPayrollCycleByIdResponse?.data)
    } else {
      setValues(location.state ? location.state : {})
    }
  }, [updatedPayrollCycleByIdResponse?.data])

  // pay cycle master dropdwon
  const {
    data: payCycleMasterDropdown,
  } = useGetAllPayCycleMasterDropDownQuery('')

  const handleSubmit: any = async () => {
    if (isEditable) {
      if (id === null) {
        await createPayrollCycle({
          payCycleYear: values?.payCycleYear,
          payCycleMonth: values?.payCycleMonth,
          payCycleCode: values?.payCycleCode,
          payCycleName: values?.payCycleName,
          payCycleStartDate: values?.payCycleStartDate,
          payCycleEndDate: values?.payCycleEndDate,

        })
      } else {
        await updatePayrollCycle({
          id: values?.id,
          payCycleYear: values?.payCycleYear,
          payCycleMonth: values?.payCycleMonth,
          payCycleCode: values?.payCycleCode,
          payCycleName: values?.payCycleName,
          payCycleStartDate: values?.payCycleStartDate,
          payCycleEndDate: values?.payCycleEndDate,

        })
      }
    } else {
      setEditable(true)
    }
  }

  async function editPayrollCycle() {
    await updatePayrollCycle({
      id: values?.id,
      payCycleYear: values?.payCycleYear,
      payCycleMonth: values?.payCycleMonth,
      payCycleCode: values?.payCycleCode,
      payCycleName: values?.payCycleName,
      payCycleStartDate: values?.payCycleStartDate,
      payCycleEndDate: values?.payCycleEndDate,

    })
  }
  const handleResume = () => {
    if (steps === 0) {
      setIsEditables(true)
      setSteps((prev) => prev + 1)
    } else if (steps === 1) {
      handleSubmit()
      handleClose()
    } else {
      handleClose()
      setValues({})
      setSteps(0)
    }
    navigate(routes.createRunPayroll, {
      state: selectedId,
    })
    // navigate(routes.createRunPayroll)
  }

  const displayFormattedDateRange = (startDate: any, endDate: any) => {
    const formatDate = (date: any) => {
      const d = new Date(date)
      return d.toLocaleDateString('en-GB', {
        day: '2-digit',
        month: 'short',
        year: 'numeric',
      })
    }

    const formattedStartDate = formatDate(startDate)
    const formattedEndDate = formatDate(endDate)

    return `${formattedStartDate} - ${formattedEndDate}`
  }

  return (
    <CustomDialog
      isResume
      CustomStyles={{ borderRadius: '16px' }}
      closeTitle="cancel"
      handleBack={() => {
        setSteps((prev) => prev - 1)
        setIsEditables(false)
      }}
      handleClose={() => {
        handleClose()
        setValues({})
        setIsEditables(false)
        setSteps(0)
      }}
      handleResume={handleResume}
      isBackButton={steps > 0}
      isOpen={isOpen}
      resumeTitle={steps === 1 ? 'bulk_upload_data_continue' : 'Run payroll'}
      subtitle=""
      title={

        `${updatedPayrollCycleByIdResponse?.data?.payCycleYear}-${updatedPayrollCycleByIdResponse?.data?.payCycleMonth} (${updatedPayrollCycleByIdResponse?.data?.payCycleCode})`

      }
    >
      <Box sx={{ display: 'flex' }}>
        {/* <form style={{ display: 'flex', width: '100% ' }} onSubmit={(e) => handleFormSubmit(e, handleSubmit)}> */}
        <OPRAlertControl
          error={createdPayrollCycleError || updatedPayrollCycleError}
          handleEditable={setEditable}
          handleSetValue={setValues}
          handleSubmit={handleSubmit}
          isError={createdPayrollCycleError || updatedPayrollCycleError}
          isLoading={createdPayrollCycleLoading || updatedPayrollCycleLoading || updatedPayrollCycleByIdLoading}
          isSuccess={updatedPayrollCycleSuccess || createdPayrollCycleSuccess}
          name=""
          title=""
          type=""
        />

        <Box>
          <OPRResponsiveGrid>

            <Grid item md={2} sm={1} xs={1}>
              <OPRInputControl
                isEditable
                label="Pay cycle"
                name="payCycleYear"
                value={`${updatedPayrollCycleByIdResponse?.data?.payCycleYear}- ${updatedPayrollCycleByIdResponse?.data?.payCycleMonth}`}
                onChange={handleChange}
              />
            </Grid>

            {/* paycycleYear  */}
            {/* <Grid item md={2} sm={1} xs={1}>
              <OPRInputControl
                isEditable
                label="Pay cycle - Month"
                name="payCycleYear"
                value={`${updatedPayrollCycleByIdResponse?.data?.payCycleMonth}`}
                onChange={handleChange}
              />
            </Grid> */}

            <Grid item md={2} sm={1} xs={1}>
              <OPRInputControl
                isEditable
                // error={errors?.payCycleCode}
                label="Pay Cycle Code"
                name="payCycleCode"
                value={updatedPayrollCycleByIdResponse?.data?.payCycleCode}
                onChange={handleChange}
              />
            </Grid>

            <Grid item md={2} sm={1} xs={1}>
              <OPRInputControl
                isEditable
                // error={errors?.payCycleName}
                label="Pay Cycle Name"
                name="payCycleName"
                value={updatedPayrollCycleByIdResponse?.data?.payCycleName}
                onChange={handleChange}
              />
            </Grid>

            <Grid item md={2} sm={1} xs={1}>
              <OPRInputControl
                isEditable
                // error={errors?.payCycleStartDate}
                label="Pay period"
                name="payCycleStartDate"
                value={displayFormattedDateRange(
                  updatedPayrollCycleByIdResponse?.data?.payCycleStartDate,
                  updatedPayrollCycleByIdResponse?.data?.payCycleEndDate,
                )}
                onChange={handleChange}
              />
            </Grid>

            {/* <Grid item md={2} sm={1} xs={1}>
              <OPRInputControl
                isEditable
                error={errors?.payCycleEndDate}
                label="Pay Cycle End Date"
                name="payCycleEndDate"
                value={`${updatedPayrollCycleByIdResponse?.data?.payCycleEndDate}`}
                onChange={handleChange}
              />
            </Grid> */}

          </OPRResponsiveGrid>
        </Box>
        {/* </OPRInnerFormLayout> */}
        {/* </form> */}
      </Box>
    </CustomDialog>
  )
}

export default RunPayrollProcess
