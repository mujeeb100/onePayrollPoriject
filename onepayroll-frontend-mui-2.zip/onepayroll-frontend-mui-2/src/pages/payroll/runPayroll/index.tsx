import {
  Badge,
  Box,
  Dialog,
  DialogActions,
  DialogContent,
  DialogContentText,
  DialogTitle,
  Tab,
  Tabs,
} from '@mui/material'
import { useGetAllPayrollRunLogsQuery } from 'api/loggingServices'
import {
  useGetAllPayCycleOptionsQuery,
  useGetAllPayrollCycleQuery,
} from 'api/payRollServices'
import axios from 'axios'
import OPRButton from 'components/atoms/button/OPRButton'
import OPRLabel from 'components/atoms/label/OPRLabel'
import OPRMultiSelectCheckbox from 'components/atoms/multiSelectCheckbox'
import { logsPaycycle, runPayRollPayCycleMasterColumn } from 'components/atoms/table/OPRTableConstant'
import { OPRInnerListLayout } from 'components/organism/OPRInnerLayoutList'
import apiEndPoint from 'constants/apiEndPoint'
import { validationSchemaPayrollAdministratorScheme } from 'constants/validate'
import saveAs from 'file-saver'
import { useEditable } from 'hooks/useEdit'
import useForm from 'hooks/useForm'
import { t } from 'i18next'
import { IOPRMultiSelectCheckboxSXProps } from 'interfaces'
import React, { useEffect, useState } from 'react'
import { useLocation, useNavigate } from 'react-router-dom'
import { routes } from 'routes/routes'
import { DropDownOption } from 'types'
import {
  flattenDropDownOptions,
  generateFilterUrl,
  getAPIWithEntityUrl,
  getauthToken,
  getParamsValue,
  setRouteValues,
} from 'utils'

import RunPayrollProcess from './RunPayrollProcess'

interface TabPanelProps {
  children?: React.ReactNode;
  index: number;
  value: number;
}

function CustomTabPanel(props: TabPanelProps) {
  const {
    children, value, index, ...other
  } = props

  return (
    <div
      aria-labelledby={`simple-tab-${index}`}
      hidden={value !== index}
      id={`simple-tabpanel-${index}`}
      role="tabpanel"
      {...other}
    >
      {value === index && (
        <Box sx={{ pt: 5 }}>
          {children}
        </Box>
      )}
    </div>
  )
}

function a11yProps(index: number) {
  return {
    id: `simple-tab-${index}`,
    'aria-controls': `simple-tabpanel-${index}`,
  }
}

type FilterData = {
  statuses: DropDownOption[]

}

export default function RunPayrollList() {
  const [selectedId, setSelectedId] = useState()
  const [payGroup, setPayGroup] = React.useState('')
  const [isOpen, setIsOpen] = useState(false)

  const location = useLocation()
  const navigate = useNavigate()
  const [value, setValue] = useState(0)
  const { id, viewUrl } = getParamsValue(location, routes.createPayCycleAdministration)

  const handleTabChange = (event: React.SyntheticEvent, newValue: number) => {
    setValue(newValue)
  }
  const {
    isEditable,
    setEditable,
  } = useEditable()
  // const navigate: any = useNavigate()
  // const location: any = useLocation()
  // const [value, setValue] = React.useState(0)
  // const { id, viewUrl } = getParamsValue(location, routes.createClientGroupProfile)
  const [selelctedDelete, setSelelctedDelete]:any = useState({
    data: {},
    isDelete: false,
    name: '',
  })
  const [noRecordsMessage, setNoRecordsMessage] = useState('')
  const [openDialog, setOpenDialog] = useState(false)

  const [isDialogOpen, setIsDialogOpen] = useState(false)
  const [dialogContent, setDialogContent] = useState('')
  const {
    values,
    setValues,
    errors,
    handleChange,
    setErrors,
    handleFormSubmit,
    handleOnChange,
  } = useForm(validationSchemaPayrollAdministratorScheme)
  const [filterDataPayrollLogs, setFilterDataPayrollLogs]:any = useState({
    pageNumber: 1,
    pageSize: 1000,
    logFunction: 'PayrollRun',
  })
  const [filteringOptions, setFilteringOptions] = useState({
    payCycleStatus: [],
  })

  const [filterData, setFilterData]:any = useState({
    pageNumber: 1,
    pageSize: 10000,
    totalItems: 0,
    orderByAsc: true,
    sortBy: '',
    SearchText: '',
    payrollRunId: '',
    payCycleName: '',
    id: '',
    statuses: [],
  })
  const transformData = () => {
    const payload: any = { ...filterData }
    payload.statuses = flattenDropDownOptions(filterData.statuses)
    return payload
  }
  const {
    data: allPosts,
    isLoading: isLoadingAllPosts,
    isSuccess: isSuccessAllPosts,
    isError: isErrorAllPosts,
    error: errorAllPosts,
    refetch: refetchAllPosts,
  } = useGetAllPayrollCycleQuery(generateFilterUrl(transformData()))
  const {
    data: payCycleOptions,
    isSuccess: isPayCycleOptionsSuccess,
    isError: isPayCycleOptionsError,
  } = useGetAllPayCycleOptionsQuery('')
  const {
    data: allPostsLog,
    isLoading: isLoadingAllPostsLogs,
    isSuccess: isSuccessAllPostsLogs,
    isError: isErrorAllPostsLogs,
    error: errorAllPostsLogs,
    refetch: refetchAllPostsLogs,
  } = useGetAllPayrollRunLogsQuery(generateFilterUrl(filterDataPayrollLogs))

  useEffect(() => {
    if (isPayCycleOptionsSuccess) {
      const payCycleStatus = payCycleOptions.payCycleStatuses.map((item: any) => ({
        roleCode: item.id,
        roleName: item.label,
      }))

      setFilteringOptions({

        payCycleStatus,
      })
    }
  }, [payCycleOptions])

  const sorting = (
    event: React.MouseEvent<unknown>,
    property: keyof any,
  ) => {
    const isAsc = filterData.sortBy === property && filterData.orderByAsc === true
    setFilterData({ ...filterData, orderByAsc: !isAsc, sortBy: property })
  }

  useEffect(() => {
    setFilterData({ ...filterData, totalItems: allPosts?.totalItems ? allPosts?.totalItems : 0 })
  }, [allPosts?.pageNumber, filterData.sortBy, filterData.orderByAsc, allPosts?.totalItems])

  const onSearch = (e: any, data: any) => {
    const { value } = e.target
    setFilterData({ ...filterData, ...data, payCycleName: value })
  }
  const handlePagination = (pageNumber: number, pageSize: number) => {
    setFilterData({ ...filterData, pageNumber })
  }
  const handleFileDownload = async (item: any) => {
    const urldownload = `${process.env.REACT_APP_UP_BASE_URL}/${apiEndPoint.downloadRunLog}`
    const token = getauthToken()
    const regExpFilename = /filename=(?<filename>[^;]*)/
    try {
      const { data, headers, status } = await axios.get(
        `${getAPIWithEntityUrl(urldownload)}?id=${item?.jobRunId}`,
        {
          responseType: 'blob',
          headers: {
            Authorization: `Bearer ${token}`,
          },
        },
      )

      if (status === 200) {
        const filename = regExpFilename.exec(headers['content-disposition'] ?? '')?.groups?.filename ?? null
        if (filename !== null) {
          saveAs(new Blob([data], { type: headers['content-type'] }), filename)
        } else {
          setDialogContent('No filename specified in response.')
          setIsDialogOpen(true)
        }
      } else {
        setDialogContent('Failed to download file. Please try again later.')
        setIsDialogOpen(true)
      }
    } catch (error: any) {
      console.error('Download Error:', error)
      setDialogContent('Invalid object name processLog.')
      setIsDialogOpen(true)
    }
  }

  // viewAcoount  spelling mistake

  const getDownloadfile = async (item: any) => {
    const urldownload = `${process.env.REACT_APP_UP_BASE_URL}/${apiEndPoint.exportCalcList}`
    const token = getauthToken()
    const regExpFilename = /filename=(?<filename>[^;]*)/

    try {
      const { data, headers, status } = await axios.get(
        `${getAPIWithEntityUrl(urldownload)}?payrollRunId=${item?.jobRunId}&payCycleCode=${item?.cycleCode}`,
        {
          responseType: 'blob',
          headers: {
            Authorization: `Bearer ${token}`,
          },
        },
      )

      if (status === 200) {
        // Check if data is empty or indicates no content
        if (data.size === 0) {
          setNoRecordsMessage('No data exists against this payroll run Id.')
          setOpenDialog(true) // Open the dialog
          return
        }

        const filename = regExpFilename.exec(headers['content-disposition'] ?? '')?.groups?.filename ?? null
        if (filename !== null) {
          saveAs(new Blob([data], { type: headers['content-type'] }), filename)
        } else {
          setNoRecordsMessage('No data exists against this payroll run Id.')
          setOpenDialog(true) // Open the dialog
        }
      }
    } catch (error: any) {
      console.error('Download Error:', error)
      setNoRecordsMessage('An error occurred while downloading the file. Please try again later.')
      setOpenDialog(true) // Open the dialog for other errors
    }
  }

  const viewAcoount = (data: any, type:string) => {
    if (type === 'edit') {
      navigate(
        setRouteValues(`${routes.editRunPayroll}`, {
          id: data?.id,
        }),
      )
    } else if (type === 'delete') {
      // deleteRunPayrollById(`Id=${data.id}`)
      setSelelctedDelete({ data, isDelete: true, name: data?.itemGroupCode })
    } else {
      navigate(
        setRouteValues(`${routes.viewPayCycleAdministration}`, {
          id: data?.id,
          view: true,
        }),
      )
    }
  }

  const handleView = (data: any) => {
    // Set route values
    setRouteValues(`${routes.viewPayCycleAdministration}`, {
      id: data.id,
      view: true,
    })
    setSelectedId(data?.id)
    // Open the dialog and pass necessary props
    setIsOpen(true)
    // setPayGroup(data) // Pass the data to the payItem prop
  }
  const handleCloseDialog = () => {
    setOpenDialog(false)
  }
  const handleCloseDialog1 = () => {
    setIsDialogOpen(false)
  }

  const renderValue = (selected: string[], filterName: string) => (
    <Box key={filterName} style={{ display: 'flex', justifyContent: 'space-between' }}>
      <span style={{ paddingLeft: '10px' }}>
        {t(`${filterName}`)}
      </span>
      <Badge
        badgeContent={selected?.length || 0}
        sx={{
          '& .MuiBadge-badge': {
            color: '#0037A4',
            backgroundColor: 'white',
            fontWeight: '700',
            fontSize: '14px',
          },
          marginTop: '12px',
          marginRight: '10px',
        }}
      />
    </Box>
  )
  // #region Filter Layout
  const dropdownInputStyle = (selected?: DropDownOption[]) : IOPRMultiSelectCheckboxSXProps => {
    const count = selected?.length || 0
    let result: IOPRMultiSelectCheckboxSXProps = { }
    if (count > 0) {
      result = { ...result, backgroundColor: '#0037A4', color: '#FFFFFF' }
    }
    return result
  }

  const filterLayout = () => (
    <>

      {/* payCycleStatus */}
      <OPRMultiSelectCheckbox
        listOfOptions={filteringOptions?.payCycleStatus || []}
        renderValue={(selected:any) => renderValue(selected, 'Status')}
        selectedOptions={filterData.statuses}
        setSelectedOptions={(item: any) => {
          filterData.statuses = item
          setFilterData({ ...filterData })
        }}
        sx={dropdownInputStyle(filterData.statuses)}
      />

    </>
  )
  // #region Page Layout
  return (
    <>
      <RunPayrollProcess
        handleClose={() => setIsOpen(false)}
        isOpen={isOpen}
        payItem={payGroup}
        selectedId={selectedId}

      />
      {/* Dialog component for no records message */}
      <Dialog
        aria-describedby="alert-dialog-description"
        aria-labelledby="alert-dialog-title"
        open={openDialog}
        onClose={handleCloseDialog}
      >
        <DialogTitle id="alert-dialog-title">Error</DialogTitle>
        <DialogContent>
          <DialogContentText id="alert-dialog-description">
            {noRecordsMessage}
          </DialogContentText>
        </DialogContent>
        <DialogActions>
          <OPRButton color="primary" onClick={handleCloseDialog}>
            OK
          </OPRButton>
        </DialogActions>
      </Dialog>

      {/* //2nd maodal */}

      <Dialog
        aria-describedby="alert-dialog-description"
        aria-labelledby="alert-dialog-title"
        open={isDialogOpen}
        onClose={handleCloseDialog1}
      >
        <DialogTitle id="alert-dialog-title">Error</DialogTitle>
        <DialogContent>
          <DialogContentText id="alert-dialog-description">
            {dialogContent}
          </DialogContentText>
        </DialogContent>
        <DialogActions>
          <OPRButton autoFocus color="primary" onClick={handleCloseDialog1}>
            OK
          </OPRButton>
        </DialogActions>
      </Dialog>

      <Box sx={{ display: 'flex', flexDirection: 'column' }}>
        <OPRLabel label={t('run_payroll')} variant="h2" />
        <Box>
          <Tabs aria-label="basic tabs example" value={value} onChange={handleTabChange}>
            <Tab label="Pay cycles" {...a11yProps(0)} />
            <Tab label="Logs" {...a11yProps(1)} />
          </Tabs>
        </Box>
        <CustomTabPanel index={0} value={value}>
          <OPRInnerListLayout
            Search={filterData.SearchText}
            addHandleClick={() => navigate(routes.createRunPayroll)}
            columns={runPayRollPayCycleMasterColumn(viewAcoount)}
            dataList={JSON.parse(JSON.stringify(allPosts?.records || []))}
            deleteCallBack=""
            error={errorAllPosts}
            filterData={filterData}
            filterLayout={filterLayout}
            handlePagination={handlePagination}
            handleSearch={onSearch}
            // handleSearch={(e: any) => {
            //   const { value } = e.target
            //   setFilterData({ ...filterData, payCycleName: value })
            // }}
            isAdd={false}
            isError={isErrorAllPosts}
            loading={isLoadingAllPosts}
            rowClickHandler={handleView}
            rowNumber={0}
            selelctedUser={selelctedDelete}
            setSelelctedUser={setSelelctedDelete}
            sortHandleClick={sorting}
            success=""
            title={t('')}
          />
        </CustomTabPanel>
        <CustomTabPanel index={1} value={value}>
          <OPRInnerListLayout
            Search={decodeURIComponent(filterData.SearchText)}
            addHandleClick={() => navigate(routes.createRunPayroll)}
            columns={logsPaycycle(getDownloadfile)}
            dataList={JSON.parse(JSON.stringify(allPostsLog?.records || []))}
            deleteCallBack=""
            error={errorAllPosts}
            filterData={filterData}
            handleFileDownload={handleFileDownload}
            handlePagination={handlePagination}
            handleSearch={onSearch}
            // handleSearch={(e: any) => {
            //   const { value } = e.target
            //   setFilterData({ ...filterData, SearchText: e.target.value })
            // }}
            isAdd={false}
            isError={isErrorAllPosts}
            loading={isLoadingAllPosts}
            // rowClickHandler=""
            // rowNumber={0}
            selelctedUser={selelctedDelete}
            setSelelctedUser={setSelelctedDelete}
            sortHandleClick={sorting}
            success=""
            title={t('')}
          />

        </CustomTabPanel>

      </Box>
    </>
  )
}
