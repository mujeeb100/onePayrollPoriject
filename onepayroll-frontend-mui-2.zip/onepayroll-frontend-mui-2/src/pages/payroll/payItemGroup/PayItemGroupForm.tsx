import { Box, Grid } from '@mui/material'
import { useLazyGetPayItemGroupByIdQuery, usePayItemGroupCreateMutation, usePayItemGroupUpdateMutation } from 'api/payRollServices'
import OPRInputControl from 'components/molecules/OPRInputControl'
import OPRResponsiveGrid from 'components/molecules/OPRResponsiveGrid'
import OPRTextArea from 'components/molecules/OPRTextArea/OPRTextArea'
import OPRAlertControl from 'components/organism/OPRAlertControl'
import { OPRInnerFormLayout } from 'components/organism/OPRInnerFormLayout'
import { validationSchemaPayItemGroup } from 'constants/validate'
import { useEditable } from 'hooks/useEdit'
import useForm from 'hooks/useForm'
import { t } from 'i18next'
import { useEffect } from 'react'
import { useLocation, useNavigate } from 'react-router-dom'
import { routes } from 'routes/routes'
import { getParamsValue } from 'utils'

interface MessageProps {
  text?: string;
  important?: boolean;
}

export default function PayItemGroupForm() {
  const location: any = useLocation()
  const { id, viewUrl } = getParamsValue(location, routes.createPayItemGroup)
  const {
    isEditable,
    setEditable,
  } = useEditable()

  const {
    values,
    setValues,
    errors,
    handleChange,
    setErrors,
    handleFormSubmit,
    handleOnChange,
  } = useForm(validationSchemaPayItemGroup)

  const navigate = useNavigate()
  const [createPayItemGroup, {
    data: createdPayItemGroupData,
    error: createdPayItemGroupError,
    isLoading: createdPayItemGroupLoading,
    isSuccess: createdPayItemGroupSuccess,
    isError: createdPayItemGroupIsError,
  }] = usePayItemGroupCreateMutation()

  const [updatePayItemGroup, {
    data: updatedDataResponse,
    error: updatedPayItemGroupError,
    isLoading: updatedPayItemGroupLoading,
    isSuccess: updatedPayItemGroupSuccess,
    isError: updatedPayItemGroupIsError,
  }] = usePayItemGroupUpdateMutation()

  const [updatePayItemGroupById, {
    data: updatedPayItemGroupByIdResponse,
    error: updatedPayItemGroupByIdError,
    isLoading: updatedPayItemGroupByIdLoading,
    isSuccess: updatedPayItemGroupByIdSuccess,
    isError: updatedPayItemGroupByIdIsError,
  }] = useLazyGetPayItemGroupByIdQuery()

  useEffect(() => {
    if (id) {
      updatePayItemGroupById(id)
      setEditable(viewUrl)
    }
  }, [])
  useEffect(() => {
    if (id) {
      setValues(updatedPayItemGroupByIdResponse?.data)
    } else {
      setValues(location.state ? location.state : {})
    }
  }, [updatedPayItemGroupByIdResponse?.data])

  useEffect(() => {
    if (createdPayItemGroupSuccess) {
      // Reset form values after successful add operation
      setValues({})
      setErrors({})
    }
  }, [createdPayItemGroupSuccess])

  const handleSubmit: any = async () => {
    if (isEditable) {
      if (id === null) {
        await createPayItemGroup({
          itemGroupCode: values?.itemGroupCode,
          itemGroupName: values?.itemGroupName,
          remarks: values?.remarks,
        })
      } else {
        await updatePayItemGroup({
          id: values.id,
          itemGroupCode: values.itemGroupCode,
          itemGroupName: values.itemGroupName,
          remarks: values?.remarks,
        })
      }
    } else {
      setEditable(true)
    }
  }

  async function editPayItemGroup() {
    await updatePayItemGroup({
      id: values.id,
      itemGroupCode: values.itemGroupCode,
      itemGroupName: values.itemGroupName,
      remarks: values?.remarks,
    })
  }

  const onScreenClose: any = (item: any) => {
    setEditable(item)
    setValues({})
  }

  return (
    <Box sx={{ display: 'flex' }}>
      <form style={{ display: 'flex', width: '100% ' }} onSubmit={(e) => handleFormSubmit(e, handleSubmit)}>
        <OPRAlertControl
          error={createdPayItemGroupError || updatedPayItemGroupError}
          handleEditable={setEditable}
          handleSetValue={setValues}
          handleSubmit={handleSubmit}
          isError={createdPayItemGroupError || updatedPayItemGroupError}
          isLoading={createdPayItemGroupLoading || updatedPayItemGroupLoading || updatedPayItemGroupByIdLoading}
          isSuccess={updatedPayItemGroupSuccess || createdPayItemGroupSuccess}
          name={t('pay_item_group_title')}
          title={t('pay_item_group_title')}
          type={id ? 'Update' : 'New'}
        />
        <OPRInnerFormLayout
          error={createdPayItemGroupError || updatedPayItemGroupError}
          handleCancelClick={() => navigate(-1)}
          handleContinueClick={handleSubmit}
          handleEditable={() => {
            setEditable(true)
          }}
          isBackButton={isEditable}
          isLoading={createdPayItemGroupLoading || updatedPayItemGroupLoading || updatedPayItemGroupByIdLoading}
          pageType="detailsPage"
          subtitle={isEditable ? t('check_the_user__detail_name') : t('all_fields_are_mandatory_except_marked_optional')}
          title={(viewUrl) ? t('pay_item_group_title') : false || ((id) ? values?.itemGroupName : `${t('add')} ${t('pay_item_group_title')}`)}
          onScreenClose={onScreenClose}
        >
          <Box>
            <OPRResponsiveGrid>
              <Grid item md={2} sm={1} xs={1}>
                <OPRInputControl
                  disabled={!!id}
                  error={errors?.itemGroupCode}
                  isEditable={isEditable}
                  label={t('pay_item_group_code')}
                  name="itemGroupCode"
                  value={values?.itemGroupCode}
                  onChange={handleChange}
                />
              </Grid>
              <Grid item md={2} sm={1} xs={1}>
                <OPRInputControl
                  error={errors?.itemGroupName}
                  isEditable={isEditable}
                  label={t('pay_item_group_Name')}
                  name="itemGroupName"
                  value={values?.itemGroupName}
                  onChange={handleChange}
                />
              </Grid>

              <Grid item md={4} sm={6} xs={12}>
                <OPRTextArea
                  error={errors?.remarks}
                  isEditable={isEditable}
                  label={t('pay_item_group_remarks')}
                  name="remarks"
                  optionalText="Optional"
                  value={values?.remarks}
                  onChange={handleChange}
                />
              </Grid>
            </OPRResponsiveGrid>
          </Box>
        </OPRInnerFormLayout>
      </form>
    </Box>
  )
}
