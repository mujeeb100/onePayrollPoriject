import { Box, Grid } from '@mui/material'
import {
  useEmployeeRemarksCreateMutation, useEmployeeRemarksUpdateMutation, useGetAllEmployeeProfileQuery, useLazyGetEmployeeRemarksByIdQuery,
} from 'api/employeeServices'
import { useGetAllPayCycleMasterDropDownQuery } from 'api/payRollServices'
import OPRButton from 'components/atoms/button/OPRButton'
import OPRResponsiveGrid from 'components/molecules/OPRResponsiveGrid'
import OPRSelectorControl from 'components/molecules/OPRSelectorControl/OPRSelectorControl'
import OPRTextArea from 'components/molecules/OPRTextArea/OPRTextArea'
import OPRAlertControl from 'components/organism/OPRAlertControl'
import { OPRInnerFormLayout } from 'components/organism/OPRInnerFormLayout'
import {
  validationSchemaEmployeeRemark,
} from 'constants/validate'
import { useEditable } from 'hooks/useEdit'
import useForm from 'hooks/useForm'
import { t } from 'i18next'
import { template } from 'lodash'
import { useEffect } from 'react'
import { useLocation, useNavigate } from 'react-router-dom'
import { routes } from 'routes/routes'
import { generateFilterUrl, getParamsValue } from 'utils'

interface MessageProps {
  text?: string;
  important?: boolean;
}
const setRouteValues = (str: string, data: any) => {
  const compiled = template(str, { interpolate: /:(\w+)/g })
  return compiled(data)
}
export default function EmployeeRemarksView() {
  const location: any = useLocation()
  // const id = getParamsValue(location, routes.createEmployeeRemarks)
  const { id, viewUrl } = getParamsValue(location, routes?.createEmployeeRemark)
  // const [mode, setMode] = useState('view') // Default mode is edit
  const { isEditable, setEditable } = useEditable()

  const {
    values,
    setValues,
    errors,
    handleChange,
    setErrors,
    handleFormSubmit,
    handleOnChange,
  } = useForm(validationSchemaEmployeeRemark)

  const navigate = useNavigate()
  const [
    createEmployeeRemarks,
    {
      data: createdEmployeeRemarksData,
      error: createdEmployeeRemarksError,
      isLoading: createdEmployeeRemarksLoading,
      isSuccess: createdEmployeeRemarksSuccess,
      isError: createdEmployeeRemarksIsError,
    },
  ] = useEmployeeRemarksCreateMutation()

  // console.log(createdEmployeeRemarksData, 'createdEmployeeRemarksData')

  const [
    updateEmployeeRemarks,
    {
      data: updatedDataResponse,
      error: updatedEmployeeRemarksError,
      isLoading: updatedEmployeeRemarksLoading,
      isSuccess: updatedEmployeeRemarksSuccess,
      isError: updatedEmployeeRemarksIsError,
    },
  ] = useEmployeeRemarksUpdateMutation()

  const [
    updateEmployeeRemarksById,
    {
      data: updatedEmployeeRemarksByIdResponse,
      error: updatedEmployeeRemarksByIdError,
      isLoading: updatedEmployeeRemarksByIdLoading,
      isSuccess: updatedEmployeeRemarksByIdSuccess,
      isError: updatedEmployeeRemarksByIdIsError,
    },
  ] = useLazyGetEmployeeRemarksByIdQuery()
  useEffect(() => {
    if (id) {
      updateEmployeeRemarksById(id)
      setEditable(viewUrl)
      // setMode('view') // Set mode to view if id is present
    }
  }, [])

  useEffect(() => {
    if (id) {
      setValues(updatedEmployeeRemarksByIdResponse?.data)
    } else {
      setValues(location.state ? location.state : {})
    }
  }, [updatedEmployeeRemarksByIdResponse?.data])

  // reset the values
  // useEffect(() => {
  //   if (createdEmployeeRemarksSuccess) {
  //     setValues({})
  //     setErrors({})
  //   }
  // }, [createdEmployeeRemarksSuccess])

  const handleSubmit: any = async () => {
    if (!isEditable) {
      if (id !== null) {
        await updateEmployeeRemarks({
          id: values?.id,
          payCycle: values?.payCycle,
          employeeCode: values?.employeeCode,
          type: values?.type,
          remarks: values?.remarks,
        })
      }
    } else {
      setEditable(true)
    }
  }

  const onScreenClose:any = (item: any) => {
    setEditable(item)
    setValues({})
  }

  const {
    data: payCycleMonthDropdown,
  } = useGetAllPayCycleMasterDropDownQuery('')

  const payCycleList = payCycleMonthDropdown?.payCycleYear?.flatMap((year: any) => payCycleMonthDropdown?.months?.flatMap((month: any) => payCycleMonthDropdown?.payCycleMasterCodeDtos?.map((code: any) => ({
    label: `${year}${month.label}${code.label}`,
    value: `${year}${month.label}${code.label}`,
  }))))

  const {
    data: employeeDataList,
  } = useGetAllEmployeeProfileQuery(generateFilterUrl({
    EffectiveDate: '10/10/2040',
  }))

  const employeeCodeList = employeeDataList?.records?.map((item: any) => ({
    label: `${item?.employeeCode} - ${item?.employeeProfile?.givenName}`,
    value: item?.employeeCode,
  }))

  const typeList = [
    { label: 'Payslip', value: 'payslip' },
  ]
  const handleEditClick = () => {
    // alert('hello')
    navigate(setRouteValues(`${routes.editEmployeeRemark}`, { id })) // alert('success')
    setEditable(true)
  }
  // console.log(values?.EmployeeRemarksDescription, 'EmployeeRemarks')
  return (
    <Box sx={{ display: 'flex', flexDirection: 'column', width: '100%' }}>
      {isEditable && (
        <Box
          sx={{
            display: 'flex',
            justifyContent: 'flex-end',
            alignItems: 'center',
            padding: '16px', // Optional: Adjust padding as needed
          }}
        >
          <OPRButton
            variant="outlined" // or "outlined" depending on the style you want
            onClick={handleEditClick}
          >
            {t('edit_emp_remark')}
          </OPRButton>
        </Box>
      )}
      <form
        style={{ display: 'flex', width: '100% ' }}
        onSubmit={(e) => handleFormSubmit(e, handleSubmit)}
      >
        <OPRAlertControl
          // callBack={(type) => {
          // // if (type === 'success') {
          // //   navigate(-1)
          // // }
          // }}
          error={createdEmployeeRemarksError || updatedEmployeeRemarksError}
          handleEditable={setEditable}
          handleSetValue={setValues}
          handleSubmit={handleSubmit}
          isError={createdEmployeeRemarksError || updatedEmployeeRemarksError}
          isLoading={
            createdEmployeeRemarksLoading
            || updatedEmployeeRemarksLoading
            || updatedEmployeeRemarksByIdLoading
          }
          isSuccess={updatedEmployeeRemarksSuccess || createdEmployeeRemarksSuccess}
          name={updatedEmployeeRemarksByIdResponse?.data?.employeeProfile?.givenName}
          title={t('employee_remark')}
          type={id ? t('cmn_update_heading') : t('cmn_new_heading')}
        />

        <OPRInnerFormLayout
          error={createdEmployeeRemarksError || updatedEmployeeRemarksError}
          handleCancelClick={false}
          handleContinueClick={false}
          isBackButton={isEditable}
          isEditable={isEditable}
          isLoading={
            createdEmployeeRemarksLoading
            || updatedEmployeeRemarksLoading
            || updatedEmployeeRemarksByIdLoading
          }
          pageType="detailsPage"
          subtitle={viewUrl ? `Pay cycle: ${updatedEmployeeRemarksByIdResponse?.data.payCycle}` : 'All field to mandatory expect those mark optional'}
          title={id ? updatedEmployeeRemarksByIdResponse?.data?.employeeProfile?.givenName : 'Pay cycle:'}
          onScreenClose={onScreenClose}

          //   subtitle={
          //     isEditable
          //       ? t('please_check_details_below')
          //       : t('form_structure_title_des')
          //   }

        //   title={(viewUrl) ? values?.EmployeeRemarksDescription : false || ((id) ? values?.EmployeeRemarksDescription : t('add_emp_remark'))} // Set title based on mode
        >
          <Box>
            <OPRResponsiveGrid>
              <Grid item md={2} sm={1} xs={1}>
                <OPRSelectorControl
                  error={errors?.payCycle}
                  isEditable={isEditable}
                  keyName="label"
                  label="emp_remark_paycyle"
                  multiple={false}
                  name="payCycle"
                  options={JSON.parse(JSON.stringify(payCycleList || []))}
                  placeholder="Select an option"
                  value={payCycleList?.find((o: any) => o.value === values?.payCycle)}
                  valueKey="value"
                  onChange={(text: any) => {
                    handleOnChange('payCycle', text?.value)
                  }}
                />
              </Grid>
              <Grid item md={2} sm={1} xs={1}>
                <OPRSelectorControl
                  error={errors?.employeeCode}
                  isEditable={isEditable}
                  keyName="label"
                  label="emp_remark_employee_code"
                  multiple={false}
                  name="employeeCode"
                  options={employeeCodeList || []}
                  placeholder="Select an option"
                  // value={values?.EmployeeCode || null}
                  value={employeeCodeList?.find((o: any) => o.value === values?.employeeCode)}
                  valueKey="label"
                  onChange={(text:any) => {
                    handleOnChange('employeeCode', text?.value)
                  }}
                />

              </Grid>
              <Grid item md={2} sm={1} xs={1}>
                <OPRSelectorControl
                  error={errors?.type}
                  isEditable={isEditable}
                  keyName="label"
                  label="emp_remark_type"
                  multiple={false}
                  name="type"
                  options={typeList}
                  placeholder="Select an option"
                  value={typeList.find((o:any) => o?.value === values?.type)}
                  valueKey="value"
                  onChange={(text:any) => {
                    handleOnChange('type', text?.value)
                  }}
                />
              </Grid>
              <Grid item md={4} sm={6} xs={12}>
                <OPRTextArea
                  error={t(errors?.remarks)}
                  isEditable={isEditable}
                  label="emp_remark_remarks"
                  name="remarks"
                  value={values?.remarks}
                  onChange={handleChange}
                />
              </Grid>

            </OPRResponsiveGrid>

          </Box>
        </OPRInnerFormLayout>
      </form>
    </Box>
  )
}
