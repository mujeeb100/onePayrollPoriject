import { Box, Grid } from '@mui/material'
import {
  useEmployeeRemarksCreateMutation, useEmployeeRemarksUpdateMutation, useGetAllEmployeeProfileQuery, useLazyGetEmployeeRemarksByIdQuery,
} from 'api/employeeServices'
import { useGetAllPayCycleMasterDropDownQuery } from 'api/payRollServices'
import { CrossIcon, TickIcon } from 'assets/svg-images/SvgComponents'
import { OPRConfirmationDialog, OPRConfirmationDialogProps } from 'components/molecules/OPRAlertControl/OPRConfirmationDialog'
import OPRResponsiveGrid from 'components/molecules/OPRResponsiveGrid'
import OPRSelectorControl from 'components/molecules/OPRSelectorControl/OPRSelectorControl'
import OPRTextArea from 'components/molecules/OPRTextArea/OPRTextArea'
import OPRErrorDialogFlow from 'components/organism/OPRErrorDialogFlow'
import { OPRInnerFormLayout } from 'components/organism/OPRInnerFormLayout'
import {
  validationSchemaEmployeeRemark,
} from 'constants/validate'
import { useEditable } from 'hooks/useEdit'
import useForm from 'hooks/useForm'
import { t } from 'i18next'
import { useEffect, useState } from 'react'
import { useLocation, useNavigate } from 'react-router-dom'
import { routes } from 'routes/routes'
import { generateFilterUrl, getParamsValue } from 'utils'

interface MessageProps {
  text?: string;
  important?: boolean;
}

export default function EmployeeRemarksForm() {
  const location: any = useLocation()
  // const id = getParamsValue(location, routes.createEmployeeRemarks)
  const { id, viewUrl } = getParamsValue(location, routes?.createEmployeeRemark)
  // const [mode, setMode] = useState('view') // Default mode is edit
  const { isEditable, setEditable } = useEditable()

  const {
    values,
    setValues,
    errors,
    handleChange,
    setErrors,
    handleFormSubmit,
    handleOnChange,
  } = useForm(validationSchemaEmployeeRemark)

  const [successDialog, setSuccessDialog] = useState<OPRConfirmationDialogProps>({
    open: false,
    icon: <TickIcon />,
    buttonLayout: 'confirm',
    title: '',
  })

  const [errorDialog, setErrorDialog] = useState<OPRConfirmationDialogProps>({
    open: false,
    title: '',
    message: '',
    icon: <CrossIcon />,
    buttonLayout: 'try-again',
  })

  const navigate = useNavigate()
  const [
    createEmployeeRemarks,
    {
      data: createdEmployeeRemarksData,
      error: createdEmployeeRemarksError,
      isLoading: createdEmployeeRemarksLoading,
      isSuccess: createdEmployeeRemarksSuccess,
      isError: createdEmployeeRemarksIsError,
    },
  ] = useEmployeeRemarksCreateMutation()

  // console.log(createdEmployeeRemarksData, 'createdEmployeeRemarksData')

  const [
    updateEmployeeRemarks,
    {
      data: updatedDataResponse,
      error: updatedEmployeeRemarksError,
      isLoading: updatedEmployeeRemarksLoading,
      isSuccess: updatedEmployeeRemarksSuccess,
      isError: updatedEmployeeRemarksIsError,
    },
  ] = useEmployeeRemarksUpdateMutation()

  const [
    updateEmployeeRemarksById,
    {
      data: updatedEmployeeRemarksByIdResponse,
      error: updatedEmployeeRemarksByIdError,
      isLoading: updatedEmployeeRemarksByIdLoading,
      isSuccess: updatedEmployeeRemarksByIdSuccess,
      isError: updatedEmployeeRemarksByIdIsError,
    },
  ] = useLazyGetEmployeeRemarksByIdQuery()
  useEffect(() => {
    if (id) {
      updateEmployeeRemarksById(id)
      setEditable(viewUrl)
      // setMode('view') // Set mode to view if id is present
    }
  }, [])

  useEffect(() => {
    if (id) {
      setValues(updatedEmployeeRemarksByIdResponse?.data)
    } else {
      setValues(location.state ? location.state : {})
    }
  }, [updatedEmployeeRemarksByIdResponse?.data])

  // reset the values
  // useEffect(() => {
  //   if (createdEmployeeRemarksSuccess) {
  //     setValues({})
  //     setErrors({})
  //   }
  // }, [createdEmployeeRemarksSuccess])

  const handleSubmit: any = async () => {
    if (isEditable) {
      if (id === null) {
        await createEmployeeRemarks({
          payCycle: values?.payCycle,
          employeeCode: values?.employeeCode,
          type: values?.type,
          remarks: values?.remarks,
        })
      } else {
        await updateEmployeeRemarks({
          id: values?.id,
          payCycle: values?.payCycle,
          employeeCode: values?.employeeCode,
          type: values?.type,
          remarks: values?.remarks,
        })
      }
    } else {
      setEditable(true)
    }
  }

  const onScreenClose:any = (item: any) => {
    setEditable(item)
    setValues({})
  }

  const {
    data: payCycleMonthDropdown,
  } = useGetAllPayCycleMasterDropDownQuery('')

  const payCycleList = payCycleMonthDropdown?.payCycleYear?.flatMap((year: any) => payCycleMonthDropdown?.months?.flatMap((month: any) => payCycleMonthDropdown?.payCycleMasterCodeDtos?.map((code: any) => ({
    label: `${year}${month.label}${code.label}`,
    value: `${year}${month.label}${code.label}`,
  }))))

  const {
    data: employeeDataList,
  } = useGetAllEmployeeProfileQuery(generateFilterUrl({
    EffectiveDate: '10/10/2040',
  }))

  const employeeCodeList = employeeDataList?.records?.map((item: any) => ({
    label: `${item?.employeeCode} - ${item?.employeeProfile?.givenName}`,
    value: item?.employeeCode,
  }))

  useEffect(() => {
    if (createdEmployeeRemarksSuccess) {
      setSuccessDialog({
        ...successDialog,
        open: true,
        buttonLayout: 'add-another',
        title: t('new_emp_remark'),
        addAnotherButtonTitle: t('Add another employee remark'),
        message: `${t('emp_remark_added')} ${values?.employeeCode}  ${t('emp_remark_for_payCycle')} - ${values?.payCycle} `,
        onClose: () => {
          setSuccessDialog({ ...successDialog, open: false })
          navigate(routes.employeeRemark)
        },
        onAddAnother: () => {
          setSuccessDialog({ ...successDialog, open: false })
          setEditable(true)
          setValues({})
        },
        // message: `${values?.emailTemplateName} ${t('has been added.')}`,

      })
    }

    if (createdEmployeeRemarksIsError) {
      const dismiss = () => setErrorDialog({ ...errorDialog, open: false })
      setErrorDialog({
        ...errorDialog,
        open: true,
        error: createdEmployeeRemarksError,
        title: t('emp_remark_failed'),
        onTryAgain: () => {
          dismiss()
          createEmployeeRemarks()
        },
        onBack: () => {
          dismiss()
        },
      })
    }
  }, [createdEmployeeRemarksSuccess, createdEmployeeRemarksIsError])

  useEffect(() => {
    if (updatedEmployeeRemarksSuccess) {
      setSuccessDialog({
        ...successDialog,
        open: true,
        buttonLayout: 'close',
        title: t('emp_remark_update'),
        // message: 'Employee remark for T00001 - Jane Doe for pay cycle -  20240602 has been updated. ',
        message: `${t('emp_remark_for')} ${values?.employeeCode} -${values?.employeeProfile?.givenName} ${t('emp_remark_for_payCycle')} - ${values?.payCycle}  ${t('employee_leave_updated_message')}`,
        onClose: () => {
          setSuccessDialog({ ...successDialog, open: false })
          navigate(routes.employeeRemark)
        },
      })
    }

    if (updatedEmployeeRemarksIsError) {
      const dismiss = () => setErrorDialog({ ...errorDialog, open: false })
      setErrorDialog({
        ...errorDialog,
        open: true,
        error: createdEmployeeRemarksError,
        title: t('emp_remark_failed'),
        onTryAgain: () => {
          dismiss()
          updateEmployeeRemarks()
        },
        onBack: () => {
          dismiss()
        },
      })
    }
  }, [updatedEmployeeRemarksSuccess, updatedEmployeeRemarksIsError])

  const typeList = [
    { label: 'Payslip', value: 'payslip' },
  ]
  let subtitle

  if (viewUrl) {
    subtitle = `Pay cycle: ${updatedEmployeeRemarksByIdResponse?.data.payCycle}`
  } else if (isEditable) {
    subtitle = t('please_check_details_below')
  } else {
    subtitle = t('form_structure_title_des')
  }

  let title

  if (id) {
    if (viewUrl) {
      const employee = updatedEmployeeRemarksByIdResponse?.data
      title = `${employee?.payCycle}: ${employee?.employeeCode} - ${employee?.employeeProfile?.givenName}`
    } else {
      title = ` ${updatedEmployeeRemarksByIdResponse?.data.employeeProfile?.givenName}`
    }
  } else {
    title = t('edit_emp_remark')
  }

  // console.log(values?.EmployeeRemarksDescription, 'EmployeeRemarks')
  return (
    <Box sx={{ display: 'flex' }}>
      <form
        style={{ display: 'flex', width: '100% ' }}
        onSubmit={(e) => handleFormSubmit(e, handleSubmit)}
      >

        <OPRConfirmationDialog
          key="confirmation-dialog"
          {...successDialog}
        />

        <OPRErrorDialogFlow
          key="error-dialog"
          dialogProps={errorDialog}
          setDialogProps={setErrorDialog}
        />
        {/* <OPRAlertControl
          callBack={(type) => {
          // if (type === 'success') {
          //   navigate(-1)
          // }
          }}
          customMessage={updatedEmployeeRemarksSuccess ? `${values?.emailProfileCode}-${values?.emailProfileName} has been Updated` : `${values?.emailProfileCode}-${values?.emailProfileName} has been added`}
          customTitle={updatedEmployeeRemarksSuccess ? 'Email profile updated' : 'New email profile added'}
          error={createdEmployeeRemarksError || updatedEmployeeRemarksError}
          handleEditable={setEditable}
          handleSetValue={setValues}
          handleSubmit={handleSubmit}
          isError={createdEmployeeRemarksError || updatedEmployeeRemarksError}
          isLoading={
            createdEmployeeRemarksLoading
            || updatedEmployeeRemarksLoading
            || updatedEmployeeRemarksByIdLoading
          }
          isSuccess={updatedEmployeeRemarksSuccess || createdEmployeeRemarksSuccess}
          name={values?.EmployeeRemarksDescription}
          title={t('employee_remark')}
          type={id ? t('cmn_update_heading') : t('cmn_new_heading')}
        /> */}

        <OPRInnerFormLayout
          isHandleContinueClick
          error={createdEmployeeRemarksError || updatedEmployeeRemarksError}
          handleCancelClick={() => navigate(-1)}
          handleContinueClick={handleSubmit}
          handleEditable={() => {
            setEditable(true)
          }}
          isBackButton={isEditable}
          isLoading={
            createdEmployeeRemarksLoading
            || updatedEmployeeRemarksLoading
            || updatedEmployeeRemarksByIdLoading
          }
          pageType="detailsPage"
          subtitle={subtitle}
          title={title}
          onScreenClose={onScreenClose}

        >
          <Box>
            <OPRResponsiveGrid>
              <Grid item md={2} sm={1} xs={1}>
                <OPRSelectorControl
                  error={errors?.payCycle}
                  isEditable={isEditable}
                  keyName="label"
                  label="emp_remark_paycyle"
                  multiple={false}
                  name="payCycle"
                  options={JSON.parse(JSON.stringify(payCycleList || []))}
                  placeholder="Select an option"
                  value={payCycleList?.find((o: any) => o.value === values?.payCycle)}
                  valueKey="value"
                  onChange={(text: any) => {
                    handleOnChange('payCycle', text?.value)
                  }}
                />
              </Grid>
              <Grid item md={2} sm={1} xs={1}>
                <OPRSelectorControl
                  error={errors?.employeeCode}
                  isEditable={isEditable}
                  keyName="label"
                  label="emp_remark_employee_code"
                  multiple={false}
                  name="employeeCode"
                  options={employeeCodeList || []}
                  placeholder="Select an option"
                  // value={values?.EmployeeCode || null}
                  value={employeeCodeList?.find((o: any) => o.value === values?.employeeCode)}
                  valueKey="label"
                  onChange={(text:any) => {
                    handleOnChange('employeeCode', text?.value)
                  }}
                />

              </Grid>
              <Grid item md={2} sm={1} xs={1}>
                <OPRSelectorControl
                  error={errors?.type}
                  isEditable={isEditable}
                  keyName="label"
                  label="emp_remark_type"
                  multiple={false}
                  name="type"
                  options={typeList}
                  placeholder="Select an option"
                  value={typeList.find((o:any) => o?.value === values?.type)}
                  valueKey="value"
                  onChange={(text:any) => {
                    handleOnChange('type', text?.value)
                  }}
                />
              </Grid>
              <Grid item md={4} sm={6} xs={12}>
                <OPRTextArea
                  error={t(errors?.remarks)}
                  isEditable={isEditable}
                  label="emp_remark_remarks"
                  name="remarks"
                  value={values?.remarks}
                  onChange={handleChange}
                />
              </Grid>

            </OPRResponsiveGrid>

          </Box>
        </OPRInnerFormLayout>
      </form>
    </Box>
  )
}
