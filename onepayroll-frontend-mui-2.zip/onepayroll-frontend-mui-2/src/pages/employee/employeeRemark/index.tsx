import {
  Box,
} from '@mui/material'
import { useEmployeeRemarksDeleteMutation, useGetAllEmployeeRemarksQuery } from 'api/employeeServices'
import { CrossIcon, TickIcon } from 'assets/svg-images/SvgComponents'
import { OPRActionMenuOption } from 'components/atoms/dropDown/OPRActionMenu'
import { employeeRemark } from 'components/atoms/table/OPRTableConstant'
import { OPRConfirmationDialog, OPRConfirmationDialogProps } from 'components/molecules/OPRAlertControl/OPRConfirmationDialog'
import { OPRInnerListLayout } from 'components/organism/OPRInnerLayoutList'
import apiEndPoint from 'constants/apiEndPoint'
import { employeeRemarksColumnMappings } from 'constants/exportColumnMappings'
import { useTranslatedColumnsForPDF } from 'hooks/useTranslatedColumnsForPDF'
import { t } from 'i18next'
import React, { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { routes } from 'routes/routes'
import {
  generateFilterUrl, getAPIWithEntityUrl, getEnv, setRouteValues,
} from 'utils'

function EmployeeRemarksList() {
  const navigate: any = useNavigate()
  const [selelctedDelete, setSelelctedDelete]:any = useState({
    data: {},
    isDelete: false,
    name: '',
  })
  const [filterData, setFilterData]:any = useState({
    pageNumber: 1,
    pageSize: 20,
    totalItems: 0,
    orderByAsc: true,
    sortBy: '',
    SearchText: '',
  })

  const [confirmDialog, setConfirmDialog] = useState<OPRConfirmationDialogProps>({
    open: false,
    buttonLayout: 'confirm',
    title: '',
    message: '',
    subtitleMessage: '',
  })

  const [actionResultDialog, setActionResultDialog] = useState<OPRConfirmationDialogProps>({
    open: false,
    buttonLayout: 'close',
    title: '',
    message: '',
  })
  const [selectedId, setSelectedId] = useState<any>(null)

  const {
    data: allPosts,
    isLoading: isLoadingAllPosts,
    isSuccess: isSuccessAllPosts,
    isError: isErrorAllPosts,
    error: errorAllPosts,
    refetch: refetchAllPosts,
  } = useGetAllEmployeeRemarksQuery(generateFilterUrl(filterData))

  const [deleteEmployeeRemarksById,
    {
      data: deleteEmployeeRemarksResponse,
      error: deleteEmployeeRemarksError,
      isLoading: deleteEmployeeRemarksLoading,
      isSuccess: deleteEmployeeRemarksSuccess,
      isError: deleteEmployeeRemarksIsError,
      refetch: refetchEmployeeRemarks,
    }] = useEmployeeRemarksDeleteMutation()

  const sorting = (
    event: React.MouseEvent<unknown>,
    property: keyof any,
  ) => {
    const isAsc = filterData.sortBy === property && filterData.orderByAsc === true
    setFilterData({ ...filterData, orderByAsc: !isAsc, sortBy: property })
  }

  useEffect(() => {
    setFilterData({ ...filterData, totalItems: allPosts?.totalItems ? allPosts?.totalItems : 0 })
  }, [allPosts?.pageNumber, filterData.sortBy, filterData.orderByAsc, allPosts?.totalItems])

  const onSearch = (e: any, data: any) => {
    setFilterData({ ...filterData, ...data })
  }

  const handlePagination = (pageNumber: number, pageSize: number) => {
    setFilterData({ ...filterData, pageNumber })
  }

  // succsees and error handler

  // #region Batch API Loading

  const successHandler = (isSuccess: boolean, toStatus: string, title: string | null = null, message: string| null = null) => {
    if (isSuccess) {
      if (title || message) {
        setActionResultDialog({
          open: true,
          icon: <TickIcon />,
          buttonLayout: 'close',
          title: t('emp_remark_title_deleted'),
          onClose: () => setActionResultDialog({ ...actionResultDialog, open: false }),
          message,
        })
      }
    }
  }

  const errorHandler = (
    isError: boolean,
    error: Error,
    toStatus: string,
    onRetry?: () => void,
    title: string | null = null,
  ) => {
    if (isError) {
      const dismiss = () => setActionResultDialog({ ...actionResultDialog, open: false })

      setActionResultDialog({
        open: true,
        error,
        icon: <CrossIcon />,
        buttonLayout: 'try-again', // Ensure this is set correctly
        title: title || t('emp_remark_failed'),
        onClose: dismiss,
        onTryAgain: () => {
          dismiss()
          onRetry?.() // This should trigger the retry logic
        },
        onBack: dismiss, // This should handle the back action
      })
    }
  }

  useEffect(() => {
    successHandler(deleteEmployeeRemarksSuccess, '', '', `${t('emp_remark_for')} ${selectedId?.employeeCode} -${selectedId?.employeeProfile?.givenName} ${t('emp_remark_for_payCycle')} - ${selectedId?.payCycle} ${t('emp_remark_deleted')}`)
    errorHandler(
      deleteEmployeeRemarksIsError,
      deleteEmployeeRemarksError,
      '',
    )
  }, [deleteEmployeeRemarksSuccess, deleteEmployeeRemarksIsError])

  // close sucsees and error

  const viewAcoount = (data: any, option: OPRActionMenuOption) => {
    const type = option.value
    setSelectedId(data)

    if (type === 'edit_emp_remark') {
      navigate(
        setRouteValues(`${routes.editEmployeeRemark}`, {
          id: data.id,
        }),
      )
    } else if (type === 'delete_emp_remark') {
      setConfirmDialog({
        open: true,
        buttonLayout: 'delete',
        title: t('emp_remark_are_you_sure'),
        message: `${t('emp_remark_for')} ${data?.employeeCode} -${data?.employeeProfile?.givenName} ${t('emp_remark_for_payCycle')} - ${data?.payCycle} ${t('emp_remark_deleted')} `,
        infoMessage: t('employee_leave_main_title'),
        onCancel: () => setConfirmDialog({ ...confirmDialog, open: false }),
        onDelete: () => {
          setConfirmDialog({ ...confirmDialog, open: false })
          deleteEmployeeRemarksById(`Id=${data.id}`)
        },
      })

      // deleteEmployeeRemarksById(`Id=${data.id}`)
      // setSelelctedDelete({ data, isDelete: true, name: data.EmployeeRemarksDescription })
    } else {
      navigate(
        setRouteValues(`${routes.viewEmployeeRemark}`, {
          id: data.id,
        }),
      )
    }
  }
  const handleView = (data: any) => {
    navigate(
      setRouteValues(`${routes.viewEmployeeRemark}`, {
        id: data.id,
        view: true,
      }),
    )
  }
  // handle Delete
  const handleDelete = (data:any) => {
    deleteEmployeeRemarksById(`Id=${data.id}`)
  }
  return (
    <>
      <OPRConfirmationDialog
        key="confirmation-dialog"
        {...confirmDialog}
      />

      <OPRConfirmationDialog
        key="action-result-dialog"
        titleSx={{
          '&::first-letter': {
            textTransform: 'capitalize',
          },
        }}
        {...actionResultDialog}
      />

      <Box sx={{ display: 'flex' }}>
        <OPRInnerListLayout
          isExport
          Search={decodeURIComponent(filterData.SearchText)}
          addHandleClick={() => navigate(routes.createEmployeeRemark)}
          columns={employeeRemark(viewAcoount)}
          dataList={JSON.parse(JSON.stringify(allPosts?.records || []))}
          // deleteCallBack={handleDelete}
          error={errorAllPosts}
          exportProps={{
            data: allPosts?.records,
            fileName: 'EmployeeRemarks',
            columns: useTranslatedColumnsForPDF(employeeRemarksColumnMappings),
            pdf: {
              orientation: 'landscape',
            },
            allRecords: {
              baseURL: getEnv('REACT_APP_UP_BASE_URL', null),
              endpoint: getAPIWithEntityUrl(apiEndPoint.EmployeeRemarksList),
              filterData,
            },
          }}
          filterData={filterData}
          handlePagination={handlePagination}
          handleSearch={onSearch}
          isError={isErrorAllPosts}
          loading={isLoadingAllPosts || deleteEmployeeRemarksLoading}
          rowClickHandler={handleView}
          rowNumber={0}
          // selelctedUser={selelctedDelete}
          // setSelelctedUser={setSelelctedDelete}
          sortHandleClick={sorting}
          // success={deleteEmployeeRemarksSuccess}
          title={t('employee_remark')}
        />
      </Box>
    </>
  )
}

export default EmployeeRemarksList
