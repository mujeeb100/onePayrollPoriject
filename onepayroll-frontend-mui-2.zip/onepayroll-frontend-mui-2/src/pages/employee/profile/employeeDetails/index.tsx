import './index.css'

import { KeyboardArrowLeft, KeyboardArrowRight, People } from '@mui/icons-material'
import {
  Box, IconButton,
} from '@mui/material'
import Tab from '@mui/material/Tab'
import Tabs from '@mui/material/Tabs'
import { useLazyGetEmployeeProfileByIdQuery } from 'api/employeeServices'
import { LeftBack } from 'assets/svg-images/SvgComponents'
import { OPRInnerFormLayout } from 'components/organism/OPRInnerFormLayout'
import { useEditable } from 'hooks/useEdit'
import * as React from 'react'
import { useEffect } from 'react'
import { useLocation, useNavigate } from 'react-router-dom'
import { routes } from 'routes/routes'
import { getParamsValue, setRouteValues } from 'utils'

import AverageWagesEmployeeList from '../employeeForm/employeeAvergeWages'
import EmployeeBankAccountList from '../employeeForm/employeeBankAccount'
import EmployementEmployeeForm from '../employeeForm/employeeEmployement'
import MovementEmployeeList from '../employeeForm/employeeMovement'
import PensionFundEmployeeList from '../employeeForm/employeePensionFund'
import ProfileEmployeeForm from '../employeeForm/employeeProfile'
import RecurringEmployeeList from '../employeeForm/employeeRecurring'
import TaxEmployeeForm from '../employeeForm/employeeTax'
import { MovementModal } from './movementModal'

  interface TabPanelProps {
    children?: React.ReactNode;
    index: number;
    value: number;
  }
// Define your tab labels and handlers
const tabLabels = [
  'Profile',
  'Employment',
  'Tax',
  'Bank accounts',
  'Recurring items',
  'Pension fund',
  'Movements',
  'Average wages',
]
function CustomTabPanel(props: TabPanelProps) {
  const {
    children, value, index, ...other
  } = props

  return (
    <div
      aria-labelledby={`simple-tab-${index}`}
      hidden={value !== index}
      id={`simple-tabpanel-${index}`}
      role="tabpanel"
      {...other}
    >
      {value === index && (
        <Box sx={{ pt: 5 }}>
          {children}
        </Box>
      )}
    </div>
  )
}
function a11yProps(index: number) {
  return {
    id: `simple-tab-${index}`,
    'aria-controls': `simple-tabpanel-${index}`,
  }
}
  interface MessageProps {
      text?: string;
      important?: boolean;
    }
function employeeTabHeader(item:any) {
  return (
    <div style={{
      textAlign: 'center', color: '#3B3839', fontSize: 16, fontFamily: 'Lato', fontWeight: '900', wordWrap: 'break-word',
    }}
    >
      {item}
    </div>
  )
}
export default function EmployeeDetails() {
  const myRef:any = React.useRef()
  const location: any = useLocation()
  const navigate = useNavigate()
  const [isOpen, setIsOpen] = React.useState(false)
  const {
    isEditable,
    setEditable,
  } = useEditable()
  const [openMadal, setModal]:any = React.useState(false)
  const [dataList, setDataList]:any = React.useState({})
  const [userRoleOperation, setRoleOperation]:any = React.useState('')
  const { id, viewUrl } = getParamsValue(location, routes.createClientGroupProfile)
  const [value, setValue] = React.useState(0)
  const [count, setCount] = React.useState(0)

  const handleTabChange = (event: React.SyntheticEvent, newValue: number) => {
    setValue(newValue)
  }
  const maxTabIndex = tabLabels.length - 1 // Calculate maximum tab index
  // Function to navigate back
  const handlePrevTab = () => {
    setValue((prevValue) => Math.max(prevValue - 1, 0))
  }

  const handleNextTab = () => {
    setValue((prevValue) => Math.min(prevValue + 1, maxTabIndex))
  }
  const [updateEmployeeProfileById, {
    data: updatedEmployeeProfileByIdResponse,
    error: updatedEmployeeProfileByIdError,
    isLoading: updatedEmployeeProfileByIdLoading,
    isSuccess: updatedEmployeeProfileByIdSuccess,
    isError: updatedEmployeeProfileByIdIsError,
    refetch: refetchEmployeeProfile,
  }] = useLazyGetEmployeeProfileByIdQuery()
  useEffect(() => {
    setEditable(true)
    updateEmployeeProfileById(id)
  }, [])

  useEffect(() => {
    if (!isOpen) {
      updateEmployeeProfileById(id)
    }
    // const interval = setInterval(() => {
    //   updateEmployeeProfileById(id)
    // }, 5000)

    // return () => clearInterval(interval)
  }, [isOpen])
  function flattenObject(obj:any, prefix = '') {
    return Object.keys(obj).reduce((acc:any, key) => {
      const pre = prefix.length ? `${prefix}.` : ''
      if (typeof obj[key] === 'object' && obj[key] !== null) {
        Object.assign(acc, flattenObject(obj[key], pre + key))
      } else {
        acc[key] = obj[key]
      }
      return acc
    }, {})
  }

  useEffect(() => {
    if (updatedEmployeeProfileByIdSuccess) {
      setDataList(flattenObject(updatedEmployeeProfileByIdResponse))
    }
  }, [updatedEmployeeProfileByIdSuccess])

  const labelUi = (item:any) => (
    <div
      style={{
        width: '20px', background: '#DA3237', borderRadius: 9999,
      }}
    >
      {item}
    </div>

  )

  const customeHeader = () => (
    <div
      className="MainTitle"
      style={{
        width: '100%', height: '100%', justifyContent: 'flex-start', alignItems: 'flex-start', gap: 64, display: 'inline-flex',
      }}
    >
      <div
        className="Frame449"
        style={{
          flex: '1 1 0', height: 66, justifyContent: 'flex-start', alignItems: 'flex-start', gap: 20, display: 'flex',
        }}
      >
        <div
          className="Icon"
          style={{
            justifyContent: 'flex-start', alignItems: 'center', gap: 8, display: 'flex',
          }}
        >
          <div
            className="Directional"
            style={{
              padding: 8, borderRadius: 4, justifyContent: 'center', alignItems: 'center', display: 'flex',
            }}
          >
            <div className="Left" style={{ width: 16, height: 16, position: 'relative' }}>
              {/* <div
                className="IconFill"
                style={{
                  width: 12, height: 7, left: 3.50, top: 2.50, position: 'absolute', transform: 'rotate(90deg)', transformOrigin: '0 0', background: '#D4D2D3',
                }}
              /> */}
              <Box
                component="div"
                onClick={() => navigate(-1)}
              >
                <LeftBack />
              </Box>
            </div>
          </div>
          <div
            className="ContentGroup"
            style={{
              width: 40, height: 40, padding: 8, background: '#E8E6E7', boxShadow: '0px 0px 1px rgba(0, 0, 0, 0.05) inset', borderRadius: 8, justifyContent: 'center', alignItems: 'center', display: 'flex',
            }}
          >
            <div
              className="People1"
              style={{
                width: 24, height: 24, position: 'relative', flexDirection: 'column', justifyContent: 'flex-start', alignItems: 'flex-start', display: 'flex',
              }}
            >
              <Box
                component="div"
                onClick={() => navigate(-1)}
              >
                <People />
              </Box>
              {/* <div className="IconFill" style={{ width: 18, height: 18, background: '#7D7B7C' }} /> */}
            </div>
          </div>
        </div>
        <div
          className="Frame449"
          style={{
            flex: '1 1 0', flexDirection: 'column', justifyContent: 'flex-start', alignItems: 'flex-start', gap: 4, display: 'inline-flex',
          }}
        >
          <div
            className="PageTitle"
            style={{
              alignSelf: 'stretch', color: '#3B3839', fontSize: 32, fontFamily: 'Lato', fontWeight: '700', wordWrap: 'break-word',
            }}
          >
            {dataList?.givenName}
          </div>
          <div
            className="LabelCopy"
            style={{
              alignSelf: 'stretch', color: '#666364', fontSize: 14, fontFamily: 'Lato', fontWeight: '400', wordWrap: 'break-word',
            }}
          >
            Employee ID:
            {' '}
            {dataList?.employeeCode}
          </div>
        </div>
      </div>
      <div
        className="ButtonContainer"
        style={{
          paddingTop: 5, paddingBottom: 5, justifyContent: 'flex-start', alignItems: 'flex-start', gap: 8, display: 'flex',
        }}
      >
        <div
          className="Button"
          style={{
            borderRadius: 110, overflow: 'hidden', border: '1px #0049DB solid', justifyContent: 'center', alignItems: 'center', gap: 8, display: 'flex',
          }}
        >
          <div
            className="ButtonsContent"
            style={{
              paddingLeft: 12, paddingRight: 12, paddingTop: 4, paddingBottom: 4, justifyContent: 'flex-start', alignItems: 'center', gap: 8, display: 'flex',
            }}
          >
            <Box
              className="Button"
              style={{
                color: '#0049DB', fontSize: 14, fontFamily: 'Lato', fontWeight: '700', wordWrap: 'break-word', cursor: 'pointer',
              }}
              onClick={() => setIsOpen(true)}
            >
              Edit employee
            </Box>
          </div>
        </div>
      </div>
    </div>
  )

  const newLabelLayout = (item:any, name:any, index:any) => (
    <div style={{
      width: '100%', height: '100%', flexDirection: 'column', justifyContent: 'center', alignItems: 'flex-start', gap: 8, display: 'inline-flex',
    }}
    >
      <div style={{
        paddingLeft: 20, paddingRight: 20, justifyContent: 'center', alignItems: 'center', gap: 8, display: 'inline-flex',
      }}
      >
        <div style={{
          textAlign: 'center', color: '#3B3839', fontSize: 16, fontFamily: 'Lato', fontWeight: '900', wordWrap: 'break-word',
        }}
        >
          {name}
        </div>
        <div style={{
          background: '#DA3237', borderRadius: 100, overflow: 'hidden', justifyContent: 'center', alignItems: 'center', display: 'flex',
        }}
        >
          {/* <div style={{
            width: 20, height: 20, background: '#DA3237', borderRadius: 9999,
          }}
          /> */}
          {value === index ? (
            <div style={{
              width: 20, height: 20, textAlign: 'center', color: 'white', fontSize: 14, fontFamily: 'Lato', fontWeight: '700', wordWrap: 'break-word',
            }}
            >
              {item}
            </div>
          ) : null}

        </div>
      </div>
      {/* <div style={{ alignSelf: 'stretch', height: 0, border: '3px #DA3237 solid' }} /> */}
    </div>
  )

  return (
    <Box sx={{ display: 'flex', flexDirection: 'column' }}>
      {
        customeHeader()
      }
      <MovementModal
        handleClose={() => {
          setIsOpen(false)
        }}
        handleOpen={() => setIsOpen(true)}
        isOpen={isOpen}
        user={dataList}
        onClick={() => {
          setIsOpen(false)
          navigate(
            setRouteValues(`${routes.editEmployeeProfileDetalis}`, {
              id,
            }),
          )
        }}
      />
      <br />
      <OPRInnerFormLayout
        isEditUser
        isHandleContinueClick
        error={false}
        handleCancelClick={() => navigate(-1)}
        handleContinueClick={(e:any) => {
          myRef.current.handleSumbmit(e)
        }}
        handleUserCreate={
          () => {
            // console.log('handleUserCreate')
            setIsOpen(true)
          }
        }
        isBackButton={isEditable}
        isHeader={false}
        isLoading={updatedEmployeeProfileByIdLoading}
        pageType="detailsPage"
        subtitle={isEditable ? 'Please check the user details below.' : 'All field to mandatory expect those mark optional'}
        title="Employee "
      >
        <Box>

          <Box sx={{ display: 'flex' }}>
            {/* Left arrow button */}
            <IconButton disabled={value === 0} onClick={handlePrevTab}>
              <KeyboardArrowLeft />
            </IconButton>
            <Tabs
              aria-label="basic tabs example"
              className="tabs-horizontal-bar"
              sx={{
                overflowX: 'auto', // Enable horizontal scrolling
                whiteSpace: 'nowrap', // Prevent wrapping of tab labels
              }}
              value={value}
              onChange={handleTabChange}
            >

              <Tab label={employeeTabHeader('Profile')} {...a11yProps(0)} />
              <Tab label={employeeTabHeader('Employment')} {...a11yProps(1)} />
              <Tab label={employeeTabHeader('Tax')} {...a11yProps(2)} />
              <Tab
                label={newLabelLayout(`${count}`, 'Bank accounts', 3)}
                {...a11yProps(3)}

              />
              <Tab label={newLabelLayout(`${count}`, 'Recurring items', 4)} {...a11yProps(4)} />
              <Tab label={newLabelLayout(`${count}`, 'Pension fund', 5)} {...a11yProps(5)} />
              {/* {`Movements(${count})`} */}
              <Tab label={newLabelLayout(`${count}`, 'Movements', 6)} {...a11yProps(6)} />
              <Tab label={newLabelLayout(`${count}`, 'Average wages', 7)} {...a11yProps(7)} />

              {tabLabels.map((label, index) => (
                <Tab key={label} label={label} {...a11yProps(index)} />
              ))}
            </Tabs>

            <IconButton disabled={value === maxTabIndex} onClick={handleNextTab}>
              <KeyboardArrowRight />
            </IconButton>
          </Box>

          <CustomTabPanel index={0} value={value}>
            <ProfileEmployeeForm id={id} isEditable={isEditable} rowData={dataList} viewUrl={viewUrl} />
          </CustomTabPanel>
          <CustomTabPanel index={1} value={value}>
            <EmployementEmployeeForm isEditable={isEditable} terminationList={updatedEmployeeProfileByIdResponse?.data} values={dataList} viewUrl={viewUrl} />
            {/* <h1>Employement EmployeeForm</h1> */}
          </CustomTabPanel>
          <CustomTabPanel index={2} value={value}>
            <TaxEmployeeForm id={updatedEmployeeProfileByIdResponse?.data?.employeeCode} isEditable={isEditable} rowData={dataList} viewUrl={viewUrl} />
          </CustomTabPanel>
          <CustomTabPanel index={3} value={value}>
            <EmployeeBankAccountList ProfileId={updatedEmployeeProfileByIdResponse?.data?.employeeProfileId} id={updatedEmployeeProfileByIdResponse?.data?.employeeCode} setCount={setCount} />
          </CustomTabPanel>
          <CustomTabPanel index={4} value={value}>
            <RecurringEmployeeList ProfileId={updatedEmployeeProfileByIdResponse?.data?.employeeProfileId} effectiveDate={updatedEmployeeProfileByIdResponse?.data?.commencementDate} id={updatedEmployeeProfileByIdResponse?.data?.employeeCode} setCount={setCount} />
          </CustomTabPanel>
          <CustomTabPanel index={5} value={value}>
            <PensionFundEmployeeList ProfileId={updatedEmployeeProfileByIdResponse?.data?.employeeProfileId} employeeData={updatedEmployeeProfileByIdResponse?.data} id={updatedEmployeeProfileByIdResponse?.data?.employeeCode} setCount={setCount} />
          </CustomTabPanel>
          <CustomTabPanel index={6} value={value}>
            <MovementEmployeeList ProfileId={updatedEmployeeProfileByIdResponse?.data?.employeeProfileId} empName={updatedEmployeeProfileByIdResponse?.data?.employeeProfile?.givenName} id={updatedEmployeeProfileByIdResponse?.data?.employeeCode} setCount={setCount} />
          </CustomTabPanel>
          <CustomTabPanel index={7} value={value}>
            <AverageWagesEmployeeList ProfileId={updatedEmployeeProfileByIdResponse?.data?.employeeProfileId} empName={updatedEmployeeProfileByIdResponse?.data?.employeeProfile?.givenName} id={updatedEmployeeProfileByIdResponse?.data?.employeeProfileId} setCount={setCount} />
          </CustomTabPanel>
        </Box>
        {/* <ClientGroupEnitiesForm /> */}
      </OPRInnerFormLayout>

    </Box>
  )
}
