import {
  Box,
  Typography,
} from '@mui/material'
import Tab from '@mui/material/Tab'
import Tabs from '@mui/material/Tabs'
import { useEmployeeProfileUpdateMutation, useLazyGetEmployeeProfileByIdQuery } from 'api/employeeServices'
import { TickIcon } from 'assets/svg-images/SvgComponents'
import { OPRConfirmationDialog } from 'components/molecules/OPRAlertControl/OPRConfirmationDialog'
import OPRAlertControl from 'components/organism/OPRAlertControl'
import { OPRInnerFormLayout } from 'components/organism/OPRInnerFormLayout'
import { validationSchemaEmployeeProfile, validationSchemaEmployeeProfileEmployment, validationSchemaEmployeeProfileTax } from 'constants/validate'
import { useEditable } from 'hooks/useEdit'
import useForm from 'hooks/useForm'
import * as React from 'react'
import { useEffect } from 'react'
import { useLocation, useNavigate } from 'react-router-dom'
import { routes } from 'routes/routes'
import { getParamsValue } from 'utils'

import { dataTransformationT, modifiedDataList } from '../dataTransfer'
import EmployementEmployeeForm from '../employeeForm/employeeEmployement'
import ProfileEmployeeForm from '../employeeForm/employeeProfile'
import TaxEmployeeForm from '../employeeForm/employeeTax'

interface TabPanelProps {
      children?: React.ReactNode;
      index: number;
      value: number;
    }

function CustomTabPanel(props: TabPanelProps) {
  const {
    children, value, index, ...other
  } = props

  return (
    <div
      aria-labelledby={`simple-tab-${index}`}
      hidden={value !== index}
      id={`simple-tabpanel-${index}`}
      role="tabpanel"
      {...other}
    >
      {value === index && (
        <Box sx={{ pt: 5 }}>
          {children}
        </Box>
      )}
    </div>
  )
}
function a11yProps(index: number) {
  return {
    id: `simple-tab-${index}`,
    'aria-controls': `simple-tabpanel-${index}`,
  }
}
    interface MessageProps {
        text?: string;
        important?: boolean;
      }

const validationSchema = (selectTeb:any) => {
  let validateSchem
  switch (selectTeb) {
    case 0:
      validateSchem = validationSchemaEmployeeProfile
      break
    case 1:
      validateSchem = validationSchemaEmployeeProfileEmployment
      break
    default:
      validateSchem = validationSchemaEmployeeProfileTax
  }
  return validateSchem
}
export default function EmployeeProfileForm() {
  const myRef:any = React.useRef()
  const [open, setOpen] = React.useState(false)
  const location: any = useLocation()
  const [value, setValue] = React.useState(0)
  const navigate = useNavigate()
  const [isOpen, setIsOpen] = React.useState(false)
  const {
    isEditable,
    setEditable,
  } = useEditable()
  const [dataList, setDataList] = React.useState({})
  const {
    values,
    setValues,
    errors,
    handleChange,
    handleOnChange,
    setErrors,
    handleFormSubmit,
  } = useForm(validationSchema(value))

  const { id, viewUrl } = getParamsValue(location, routes.createClientGroupProfile)

  const handleTabChange = (event: React.SyntheticEvent, newValue: number) => {
    setValue(newValue)
  }

  const [updateEmployeeProfileById, {
    data: updatedEmployeeProfileByIdResponse,
    error: updatedEmployeeProfileByIdError,
    isLoading: updatedEmployeeProfileByIdLoading,
    isSuccess: updatedEmployeeProfileByIdSuccess,
    isError: updatedEmployeeProfileByIdIsError,
  }] = useLazyGetEmployeeProfileByIdQuery()

  const [updateEmployeeProfile, {
    data: updatedDataResponse,
    error: updatedEmployeeProfileError,
    isLoading: updatedEmployeeProfileLoading,
    isSuccess: updatedEmployeeProfileSuccess,
    isError: updatedEmployeeProfileIsError,
  }] = useEmployeeProfileUpdateMutation()
  useEffect(() => {
    // setEditable(true)
    updateEmployeeProfileById(id)
  }, [])

  useEffect(() => {
    if (updatedEmployeeProfileSuccess) {
      setOpen(true)
    }
  }, [updatedEmployeeProfileSuccess])

  function flattenObject(obj:any, prefix = '') {
    const data = Object.keys(obj).reduce((acc:any, key) => {
      const pre = prefix.length ? `${prefix}.` : ''
      if (typeof obj[key] === 'object' && obj[key] !== null) {
        Object.assign(acc, flattenObject(obj[key], pre + key))
      } else {
        acc[key] = obj[key] ? obj[key] : ''
      }
      return acc
    }, {})
    data.nationalityName = ''
    return data
  }

  useEffect(() => {
    if (updatedEmployeeProfileByIdSuccess) {
      setValues(flattenObject(dataTransformationT(updatedEmployeeProfileByIdResponse)))
    }
  }, [updatedEmployeeProfileByIdSuccess])
  console.log(values, errors, 'errorssssssssssssss')
  const updateEmployeeProfileList = () => {
    console.log(values, errors, 'eeeeeeee')

    if (value === 2) {
      const data = { ...modifiedDataList({ ...values, id: updatedEmployeeProfileByIdResponse?.data?.employeeProfile?.id }) }
      updateEmployeeProfile(data)
      // return
    }
    setValue(value + 1)
  }

  useEffect(() => {
    if (values.VisaHolderIndicator === 'No') {
      setValue({
        ...values,
        visaIssueDate: null,
        visaFirstLandingDate: null,
        visaExpiryDate: null,
      })
    }
  }, [values.VisaHolderIndicator])
  return (
    <Box sx={{ display: 'flex', flexDirection: 'column' }}>
      <OPRConfirmationDialog
        buttonLayout="close"
        icon={<TickIcon />}
        infoMessage=""
        message={(
          <>
            {`${values.givenName} ${values.surname} has been updated.`}
            .
          </>
        )}
        open={open}
        title="Employee Profile Updated."
        onClose={() => {
          setOpen(false)
          navigate(-1)
        }}
      />
      <OPRAlertControl
        callBack={(type:any) => {
          // if (type === 'success') {
          //   navigate(-1)
          // }
        }}
        customMessage={`${values.givenName} ${values.surname} has been updated`}
        error={updatedEmployeeProfileError}
        // handleEditable={setEditable}
        // handleSetValue={setValues}
        handleSubmit={updateEmployeeProfileList}
        isError={updatedEmployeeProfileIsError}
        isLoading={updatedEmployeeProfileLoading || updatedEmployeeProfileByIdLoading}
        isSuccess={false}
        name=""
        // previousUrl={routes.country}
        title="Employee Profile"
        type="Updated"
      />
      <OPRInnerFormLayout
        // isEditUser
        isHandleContinueClick
        error={false}
        handleCancelClick={() => navigate(-1)}
        handleContinueClick={(e:any) => {
          handleFormSubmit(e, updateEmployeeProfileList)
        }}
        handleUserCreate={
          () => {
            // console.log('handleUserCreate')
            setIsOpen(true)
          }
        }
        isBackButton={isEditable}
        isEditUser={false}
        isLoading={false}
        pageType="detailsPage"
        subtitle={isEditable ? 'Please check the user details below.' : 'All field to mandatory expect those mark optional'}
        title={`Edit ${values.givenName} ${values.surname}`}
      >
        <Box>

          <Box sx={{ borderBottom: 1, borderColor: 'divider' }}>
            <Tabs aria-label="basic tabs example" value={value} onChange={handleTabChange}>
              <Tab label="Profile" {...a11yProps(0)} />
              <Tab label="Employment" {...a11yProps(1)} />
              <Tab label="Tax" {...a11yProps(2)} />
            </Tabs>
          </Box>

          <CustomTabPanel index={0} value={value}>
            <ProfileEmployeeForm
              errors={errors}
              handleChange={handleChange}
              handleOnChange={handleOnChange}
              id={id}
              isEditable={isEditable}
              rowData={values}
            />
          </CustomTabPanel>
          <CustomTabPanel index={1} value={value}>
            <EmployementEmployeeForm
              errors={errors}
              handleChange={handleChange}
              handleOnChange={handleOnChange}
              isEditable={isEditable}
              values={values}
            />
            {/* <h1>Employement EmployeeForm</h1> */}
          </CustomTabPanel>
          <CustomTabPanel index={2} value={value}>
            {/* <Typography style={{ color: 'red' }} variant="h3">My Text</Typography> */}

            <TaxEmployeeForm
              errors={errors}
              handleChange={handleChange}
              handleOnChange={handleOnChange}
              isEditable={isEditable}
              isQuater={false}
              rowData={values}
            />
            <ul>
              {Object.keys(errors).map((key) => (
                <Typography style={{ color: 'red' }} variant="h6">
                  <li key={key}>
                    {key}
                    :
                    {errors[key]}
                  </li>
                </Typography>
              ))}
            </ul>
          </CustomTabPanel>

        </Box>
        {/* <ClientGroupEnitiesForm /> */}
      </OPRInnerFormLayout>

    </Box>
  )
}
