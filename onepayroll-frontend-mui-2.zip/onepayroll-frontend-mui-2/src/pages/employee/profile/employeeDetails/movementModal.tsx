import { useTheme } from '@emotion/react'
import {
  Box, FormControlLabel, Grid, Radio, RadioGroup,
} from '@mui/material'
import { useEmpMovementCreateMutation } from 'api/employeeServices'
import {
  useGetAllCostCenterQuery, useGetAllDepartmentQuery, useGetAllDivisionQuery, useGetAllGradeQuery, useGetAllIRDQuery, useGetAllPositionQuery, useGetAllRegionQuery, useGetAllStaffTypeQuery, useGetAllTeamQuery, useGetAllTerminationCodeQuery,
  useGetAllWorkCalenderQuery,
} from 'api/entityServices'
import { LeftCaret, RighCaretBlue, TickIcon } from 'assets/svg-images/SvgComponents'
import OPRButton from 'components/atoms/button/OPRButton'
import OPRLabel from 'components/atoms/label/OPRLabel'
import { OPRConfirmationDialog } from 'components/molecules/OPRAlertControl/OPRConfirmationDialog'
import OPRDatePickerControl from 'components/molecules/OPRDatePickerControl/OPRDatePickerControl'
import OPRInputControl from 'components/molecules/OPRInputControl'
import OPRResponsiveGrid from 'components/molecules/OPRResponsiveGrid'
import OPRSelectorControl from 'components/molecules/OPRSelectorControl/OPRSelectorControl'
import { validationSchemaEmployeeMovement, validationSchemaEmployeeMovement2 } from 'constants/validate'
import { useEditable } from 'hooks/useEdit'
import useForm from 'hooks/useForm'
import { t } from 'i18next'
import React, { useEffect, useState } from 'react'
import { generateFilterUrl } from 'utils'

import { CustomDialog } from '../../../../components/atoms/modal/OPRModal'
import OPRAlertControl from '../../../../components/organism/OPRAlertControl'

type MovementModalProps = {
    onClick: () => void;
    handleClose: () => void;
    isOpen: boolean;
    handleOpen: () => void;
    user?: any;
  };
const validationList = (expression:any) => {
  let validationScheme:any = {}
  switch (expression) {
    case 1:
      validationScheme = validationSchemaEmployeeMovement
      break
    case 2:
      validationScheme = validationSchemaEmployeeMovement2
      break
    default:
      validationScheme = validationSchemaEmployeeMovement2
  }
  return validationScheme
}
export function MovementModal({
  onClick, isOpen, user, handleClose, handleOpen,
}: MovementModalProps) {
  const theme:any = useTheme()
  const [steps, setSteps] = useState(0)
  const [isskip, setIsskip] = useState(true)
  const [isWork, setIsWork] = useState(true)
  const [userRoleOperation, setRoleOperation]:any = React.useState('')
  const { isEditable, setEditable } = useEditable()
  const [openSuccesses, setOpenSuccesses]:any = useState(false)
  const {
    values,
    setValues,
    errors,
    handleChange,
    setErrors,
    handleFormSubmit,
    handleOnChange,
  } = useForm(validationList(steps))

  const {
    data: allPosts,
    isLoading: isLoadingAllPosts,
    isSuccess: isSuccessAllPosts,
    isError: isErrorAllPosts,
    error: errorAllPosts,
    refetch: refetchAllPosts,
  } = useGetAllTerminationCodeQuery(generateFilterUrl({ pageSize: '200' }))
  const {
    data: allRegion,
    isLoading: isLoadingAllRegion,
    isSuccess: isSuccessAllRegion,
    isError: isErrorAllRegion,
    error: errorAllRegion,
  } = useGetAllRegionQuery(generateFilterUrl({ pageSize: '200' }), { skip: isskip })
  const {
    data: allDivision,
    isLoading: isLoadingallDivision,
    isSuccess: isSuccessallDivision,
    isError: isErrorallDivision,
    error: errorallDivision,
  } = useGetAllDivisionQuery(generateFilterUrl({ pageSize: '200' }), { skip: isskip })
  const {
    data: allDepartment,
    isLoading: isLoadingallDepartment,
    isSuccess: isSuccessallDepartment,
    isError: isErroralDepartment,
    error: errorallDepartment,
  } = useGetAllDepartmentQuery(generateFilterUrl({ pageSize: '200' }), { skip: isskip })
  const {
    data: allTeam,
    isLoading: isLoadingallTeam,
    isSuccess: isSuccessallTeam,
    isError: isErrorallTeam,
    error: errorallTeam,
  } = useGetAllTeamQuery(generateFilterUrl({ pageSize: '200' }), { skip: isskip })
  const {
    data: allCostCenter,
    isLoading: isLoadingallCostCenter,
    isSuccess: isSuccessallCostCenter,
    isError: isErrorallCostCenter,
    error: errorallCostCenter,
  } = useGetAllCostCenterQuery(generateFilterUrl({ pageSize: '200' }), { skip: isskip })
  const {
    data: allPosition,
    isLoading: isLoadingallPosition,
    isSuccess: isSuccessallPosition,
    isError: isErrorallPosition,
    error: errorallPosition,
  } = useGetAllPositionQuery(generateFilterUrl({ pageSize: '200' }), { skip: isskip })
  const {
    data: allGrade,
    isLoading: isLoadingallGrade,
    isSuccess: isSuccessallGrade,
    isError: isErrorallGrade,
    error: errorallGrade,
  } = useGetAllGradeQuery(generateFilterUrl({ pageSize: '200' }), { skip: isskip })
  const {
    data: allStaffType,
    isLoading: isLoadingallStaffType,
    isSuccess: isSuccessallStaffType,
    isError: isErrorallStaffType,
    error: errorallStaffType,
  } = useGetAllStaffTypeQuery(generateFilterUrl({ pageSize: '200' }), { skip: isskip })
  const {
    data: allWorkCalendere,
    isLoading: isLoadingallWorkCalender,
    isSuccess: isSuccessallWorkCalender,
    isError: isErrorallWorkCalender,
    error: errorallWorkCalender,
  } = useGetAllWorkCalenderQuery(generateFilterUrl({ pageSize: '200' }), { skip: isWork })

  const {
    data: allIRD,
    isLoading: isLoadingallIRD,
    isSuccess: isSuccessallIRD,
    isError: isErrorallIRD,
    error: errorallIRD,
  } = useGetAllIRDQuery(generateFilterUrl({ pageSize: '200' }), { skip: isskip })
  const [createEmpMovement, {
    data: createdEmpMovementData,
    error: createdEmpMovementError,
    isLoading: createdEmpMovementLoading,
    isSuccess: createdEmpMovementSuccess,
    isError: createdEmpMovementIsError,
  }] = useEmpMovementCreateMutation()

  useEffect(() => {
    if (createdEmpMovementSuccess) {
      setOpenSuccesses(true)
    }
  }, [createdEmpMovementSuccess])

  // useEffect(() => {
  //   setValues({
  //     ...values,
  //     EmployeeCode: user?.employeeCode
  //     ,
  //   })
  // }, [])

  const handleSubmit = async () => {
    const formatDate = (date:any) => {
      const d = new Date(date)
      return d?.toLocaleDateString('en-US')
    }
    const fields = []
    if (values.rehireUsingSameEmployeeCode?.label === 'No') {
      fields.push({ fieldName: 'EmployeeCode', value: values.EmployeeCode })
    }
    if (values?.employeeMovementType?.label === 'Rehire From Same Entity') {
      fields.push({ fieldName: 'CommencementDate', value: formatDate(values.commencementDate) })
    }
    if (values?.employeeMovementType?.label === 'Rehire From Same Entity') {
      fields.push({ fieldName: 'StartDate418', value: formatDate(values.fourOneEightDate) })
    }
    if (values?.lastEmploymentDate) {
      fields.push({ fieldName: 'LastEmploymentDate', value: formatDate(values?.lastEmploymentDate) })
    }
    if (values?.resignationDate) {
      fields.push({ fieldName: 'ResignationDate', value: formatDate(values?.resignationDate) })
    }
    if (values?.lastWorkingDate) {
      fields.push({ fieldName: 'LastWorkingDate', value: formatDate(values?.lastWorkingDate) })
    }
    if (values?.noticePeriodEndDate) {
      fields.push({ fieldName: 'NoticePeriodEndDate', value: formatDate(values?.noticePeriodEndDate) })
    }
    if (values?.payThroughDate) {
      fields.push({ fieldName: 'PayThroughDate', value: formatDate(values?.payThroughDate) })
    }
    if (values?.terminationCode) {
      fields.push({ fieldName: 'TerminationCodeId', value: values?.terminationCode?.id })
    }
    if (values?.terminationReason) {
      fields.push({ fieldName: 'TerminationReason', value: values?.terminationReason })
    }
    if (values?.region) {
      fields.push({ fieldName: 'RegionId', value: values?.region?.id })
    }
    if (values?.division) {
      fields.push({ fieldName: 'DivisionId', value: values?.division?.id })
    }
    if (values?.department) {
      fields.push({ fieldName: 'DepartmentId', value: values?.department?.id })
    }
    if (values?.team) {
      fields.push({ fieldName: 'TeamId', value: values?.team?.id })
    }
    if (values?.costCenter) {
      fields.push({ fieldName: 'CostCenterId', value: values?.costCenter?.id })
    }
    if (values?.position) {
      fields.push({ fieldName: 'PositionId', value: values?.position?.id })
    }
    if (values?.grade) {
      fields.push({ fieldName: 'GradeId', value: values?.grade?.id })
    }
    if (values?.staffType) {
      fields.push({ fieldName: 'StaffTypeId', value: values?.staffType?.id })
    }
    if (values?.irdCorporateTitle) {
      fields.push({ fieldName: 'IRDCorporateTitleId', value: values?.irdCorporateTitle?.id })
    }
    if (values?.workCalendar) {
      fields.push({ fieldName: 'WorkCalendarId', value: values?.workCalendar?.id })
    }
    if (values?.caw) {
      fields.push({ fieldName: 'CAWCalculationMethod', value: values?.caw?.label })
    }
    const effectiveDateTerm = new Date(new Date().getTime() + 60 * 60 * 24 * 1000)
    const data = {
      employeeMovementType: values?.employeeMovementType?.label,
      employeeProfileId: user?.employeeProfileId,
      effectiveDate: values?.employeeMovementType?.label === 'Termination' ? formatDate(values?.lastEmploymentDate) : formatDate(values?.effectiveDate),
      reason: values?.reason || '',
      fields,
      rehireUsingSameEmployeeCode: values?.rehireUsingSameEmployeeCode?.label,
    }
    handleClose()
    await createEmpMovement(data)
  }

  const handleMovementSubmit = () => {
    if (steps === 1) {
      if ((values?.employeeMovementType && values?.sequence) || values?.rehireUsingSameEmployeeCode?.label === 'Yes') {
        setSteps((prev) => prev + 1)
      }
    } else if (steps === 2) {
      if (values?.employeeMovementType?.label === 'Change of Assignment') {
        if (values?.irdCorporateTitle) {
          setSteps((prev) => prev + 1)
        }
      } else if (values?.employeeMovementType?.label === 'Change of Remuneration') {
        if (values?.workCalendar && values?.caw) {
          setSteps((prev) => prev + 1)
        }
      } else if (values?.employeeMovementType?.label === 'Termination') {
        if (values?.lastEmploymentDate) {
          setSteps((prev) => prev + 1)
        }
      } else if (values?.employeeMovementType?.label === 'Rehire From Same Entity') {
        // if (values?.lastEmploymentDate) {
        setSteps((prev) => prev + 1)
        // }
      }
    } else if (steps === 3) {
      handleSubmit()
    } else {
      setSteps((prev) => prev + 1)
    }
  }

  return (
    <Box>
      <OPRConfirmationDialog
        buttonLayout="close"
        icon={<TickIcon />}
        infoMessage=""
        message={(
          <>
            {`${user?.displayName} has been updated`}
            .
          </>
        )}
        open={openSuccesses}
        title="Employee profile updated"
        onClose={() => {
          handleClose()
          setValues({})
          setSteps(0)
          setOpenSuccesses(false)
        }}
      />
      <OPRAlertControl
        isCustomError
        callBack={() => {
          handleClose()
          setValues({})
          setSteps(0)
        }}
        customBack={() => {
          handleOpen()
        }}
        error={createdEmpMovementError}
        handleSubmit={handleSubmit}
        isError={createdEmpMovementIsError}
        isLoading={createdEmpMovementLoading}
        isSuccess={false}
        name={`${user?.displayName}`}
        title="Employee profile"
        type="update"
      />
      <CustomDialog
        CustomStyles={{ borderRadius: '16px' }}
        isOpen={isOpen}
        type="loader"
      >
        {(() => {
          switch (steps) {
            case 0:
              return (
                <>
                  <OPRLabel variant="h4">Edit Employee</OPRLabel>
                  <RadioGroup
                    row
                    aria-labelledby="demo-row-radio-buttons-group-label"
                    name="row-radio-buttons-group"
                    sx={{ display: 'flex', flexDirection: 'column' }}
                    value={userRoleOperation}
                    onChange={(e) => {
                      setRoleOperation(e.target.value)
                    }}
                  >
                    <FormControlLabel control={<Radio />} label="Edit profile" value="Edit profile" />
                    <FormControlLabel control={<Radio />} label="Employee movement" value="Employee movement" />
                  </RadioGroup>
                </>
              )
            case 1:
              return (
                <>
                  <OPRLabel variant="h4">Employee movement</OPRLabel>
                  <OPRLabel sx={{ marginTop: '15px', marginBottom: '15px' }} variant="body2">
                    {t('All fields are mandatory except those marked optional')}
                  </OPRLabel>
                  <OPRResponsiveGrid>
                    <Grid item md={4} sm={1} xs={1}>
                      <OPRSelectorControl
                        error={errors?.employeeMovementType}
                        isEditable={isEditable}
                        keyName="label"
                        label={t('ent_emp_move_type_movement_type')}
                        multiple={false}
                        name="employeeMovementType"
                        options={[{ id: '4094fce4-51a4-45bf-a7ae-3dbef5d02cc5', label: 'Termination' }, { id: 'efe289aa-2abd-4100-8b2c-a34b61208843', label: 'Change of Assignment' }, { id: 'efe289aa-2abd-4100-8b2c-a34b61208420', label: 'Change of Remuneration' }, { id: 'efe289aa-2abd-4100-8b2c-a34b6120884323', label: 'Rehire From Same Entity' }]}
                        placeholder="Select"
                        value={[{ id: '4094fce4-51a4-45bf-a7ae-3dbef5d02cc5', label: 'Termination' }, { id: 'efe289aa-2abd-4100-8b2c-a34b61208843', label: 'Change of Assignment' }, { id: 'efe289aa-2abd-4100-8b2c-a34b61208420', label: 'Change of Remuneration' }, { id: 'efe289aa-2abd-4100-8b2c-a34b6120884323', label: 'Rehire From Same Entity' }].find((o:any) => o?.id === values?.employeeMovementType?.id)}
                        valueKey="id"
                        onChange={(text:any) => {
                          if (text?.label === 'Change of Assignment') {
                            setIsskip(false)
                          }
                          if (text?.label === 'Change of Remuneration') {
                            setIsWork(false)
                          }
                          if (text?.label === 'Rehire From Same Entity') {
                            setIsWork(false)
                            setIsskip(false)
                          }
                          // if (text?.label === 'Rehire From Same Entity') {
                          //   setIsskip(false)
                          //   setIsWork(false)
                          // }
                          handleOnChange('employeeMovementType', text)
                        }}
                      />
                    </Grid>
                    {values?.employeeMovementType?.label === 'Rehire From Same Entity' ? (
                      <>
                        <Grid item md={4} sm={1} xs={1}>
                          <OPRSelectorControl
                            error={errors?.rehireUsingSameEmployeeCode}
                            isEditable={false}
                            keyName="label"
                            label={t('rehire_same_empl_title')}
                            multiple={false}
                            name="rehireUsingSameEmployeeCode"
                            options={[{ id: '4094fce4-51a4-45bf-a7ae-3dbef5d02cc5', label: 'Yes' }, { id: 'efe289aa-2abd-4100-8b2c-a34b61208420', label: 'No' }]}
                            placeholder="Select"
                            value={[{ id: '4094fce4-51a4-45bf-a7ae-3dbef5d02cc5', label: 'Yes' }, { id: 'efe289aa-2abd-4100-8b2c-a34b61208420', label: 'No' }].find((o:any) => o?.id === values?.rehireUsingSameEmployeeCode?.id)}
                            valueKey="id"
                            onChange={(text:any) => {
                              handleOnChange('rehireUsingSameEmployeeCode', text)
                            }}
                          />
                        </Grid>
                        <Grid item md={4} sm={1} xs={1}>
                          <OPRDatePickerControl
                            error={errors?.effectiveDate}
                            isEditable={isEditable}
                            label={t('ent_curr_exch_currency_effective_dt')}
                            name="effectiveDate"
                            value={values?.effectiveDate || null}
                            onChange={(date) => {
                              handleOnChange('effectiveDate', date)
                            }}
                          />
                        </Grid>
                        {values?.rehireUsingSameEmployeeCode?.label === 'No' && (
                          <Grid item md={4} sm={1} xs={1}>
                            <OPRInputControl
                              error={t(errors?.sequence)}
                              isEditable={isEditable}
                              label="sequence"
                              name="sequence"
                              value={values?.sequence}
                              onChange={handleChange}
                            />
                          </Grid>
                        )}
                      </>
                    ) : (
                      <>
                        {(values?.employeeMovementType?.label === 'Change of Remuneration' || values?.employeeMovementType?.label === 'Change of Assignment') && (
                          <Grid item md={4} sm={1} xs={1}>
                            <OPRDatePickerControl
                              error={errors?.effectiveDate}
                              isEditable={isEditable}
                              label={t('ent_curr_exch_currency_effective_dt')}
                              name="effectiveDate"
                              value={values?.effectiveDate || null}
                              onChange={(date) => {
                                handleOnChange('effectiveDate', date)
                              }}
                            />
                          </Grid>
                        )}

                        <Grid item md={4} sm={1} xs={1}>
                          <OPRInputControl
                            error={t(errors?.sequence)}
                            isEditable={isEditable}
                            label="sequence"
                            name="sequence"
                            value={values?.sequence}
                            onChange={handleChange}
                          />
                        </Grid>
                      </>

                    )}
                    <Grid item md={4} sm={1} xs={1}>
                      <OPRInputControl
                        error={t(errors?.reason)}
                        isEditable={isEditable}
                        label="reason"
                        name="reason"
                        optionalText={t('optional')}
                        value={values?.reason}
                        onChange={handleChange}
                      />
                    </Grid>
                  </OPRResponsiveGrid>
                </>
              )
            case 2:
              return (
                <>
                  <OPRLabel variant="h4">{values?.employeeMovementType?.label}</OPRLabel>
                  <OPRLabel sx={{ marginTop: '15px', marginBottom: '15px' }} variant="body2">
                    {`  ${t('All fields are mandatory except those marked optional')}`}
                  </OPRLabel>
                  <OPRResponsiveGrid>
                    {values?.employeeMovementType?.label === 'Termination' && (
                      <>
                        <Grid item md={2} sm={1} xs={1}>
                          {/* effective end date */}

                          <OPRDatePickerControl
                            error={errors?.lastEmploymentDate}
                            isEditable={isEditable}
                            label={t('employee_profile_last_working_date')}
                            name="lastEmploymentDate"
                            value={values?.lastEmploymentDate || null}
                            onChange={(date) => {
                              handleOnChange('lastEmploymentDate', date)
                            }}
                          />
                        </Grid>
                        <Grid item md={2} sm={1} xs={1}>
                          {/* effective end date */}

                          <OPRDatePickerControl
                            error={errors?.resignationDate}
                            isEditable={isEditable}
                            label={t('Resignation date')}
                            name="resignationDate"
                            optionalText="optional"
                            value={values?.resignationDate || null}
                            onChange={(date) => {
                              handleOnChange('resignationDate', date)
                            }}
                          />
                        </Grid>
                        <Grid item md={2} sm={1} xs={1}>
                          {/* effective end date */}

                          <OPRDatePickerControl
                            error={errors?.lastWorkingDate}
                            isEditable={isEditable}
                            label={t('employee_profile_last_working_date_text')}
                            name="lastWorkingDate"
                            optionalText="optional"
                            value={values?.lastWorkingDate || null}
                            onChange={(date) => {
                              handleOnChange('lastWorkingDate', date)
                            }}
                          />
                        </Grid>
                        <Grid item md={2} sm={1} xs={1}>
                          {/* effective end date */}

                          <OPRDatePickerControl
                            error={errors?.noticePeriodEndDate}
                            isEditable={isEditable}
                            label={t('employee_profile_resignation_date_text')}
                            name="noticePeriodEndDate"
                            optionalText="optional"
                            value={values?.noticePeriodEndDate || null}
                            onChange={(date) => {
                              handleOnChange('noticePeriodEndDate', date)
                            }}
                          />
                        </Grid>
                        <Grid item md={2} sm={1} xs={1}>
                          {/* effective end date */}

                          <OPRDatePickerControl
                            error={errors?.payThroughDate}
                            isEditable={isEditable}
                            label={t('employee_profile_pay_through_date')}
                            name="payThroughDate"
                            optionalText="optional"
                            value={values?.payThroughDate || null}
                            onChange={(date) => {
                              handleOnChange('payThroughDate', date)
                            }}
                          />
                        </Grid>
                        <Grid item md={2} sm={1} xs={1}>
                          <OPRSelectorControl
                            error={errors?.terminationCode}
                            isEditable={isEditable}
                            keyName="label"
                            label={t('employee_profile_termination_code')}
                            multiple={false}
                            name="terminationCode"
                            optionalText="optional"
                            options={(allPosts?.records || []).map((o:any) => ({ id: o?.id, label: o?.terminationCode }))}
                            placeholder="Select"
                            value={values?.terminationCode || null}
                            valueKey="id"
                            onChange={(text:any) => {
                              handleOnChange('terminationCode', text)
                            }}
                          />
                        </Grid>
                        <Grid item md={4} sm={1} xs={1}>
                          <OPRInputControl
                            error={t(errors?.terminationReason)}
                            isEditable={isEditable}
                            label="employee_profile_termination_reason"
                            name="terminationReason"
                            optionalText={t('optional')}
                            value={values?.terminationReason}
                            onChange={handleChange}
                          />
                        </Grid>
                      </>

                    )}
                    {values?.employeeMovementType?.label === 'Change of Assignment' && (
                      <>
                        <Grid item md={2} sm={1} xs={1}>
                          <OPRSelectorControl
                            error={errors?.region}
                            isEditable={isEditable}
                            keyName="label"
                            label={t('region')}
                            multiple={false}
                            name="region"
                            optionalText="optional"
                            options={(allRegion?.records || []).map((o:any) => ({ id: o?.id, label: o?.regionCode }))}
                            placeholder="Select"
                            value={values?.region || null}
                            valueKey="id"
                            onChange={(text:any) => {
                              handleOnChange('region', text)
                            }}
                          />
                        </Grid>
                        <Grid item md={2} sm={1} xs={1}>
                          <OPRSelectorControl
                            error={errors?.division}
                            isEditable={isEditable}
                            keyName="label"
                            label={t('entity_division_submenu_title')}
                            multiple={false}
                            name="division"
                            optionalText="optional"
                            options={(allDivision?.records || []).map((o:any) => ({ id: o?.id, label: o?.divisionCode }))}
                            placeholder="Select"
                            value={values?.division || null}
                            valueKey="id"
                            onChange={(text:any) => {
                              handleOnChange('division', text)
                            }}
                          />
                        </Grid>
                        <Grid item md={2} sm={1} xs={1}>
                          <OPRSelectorControl
                            error={errors?.department}
                            isEditable={isEditable}
                            keyName="label"
                            label={t('entity_department_submenu_title')}
                            multiple={false}
                            name="department"
                            optionalText="optional"
                            options={(allDepartment?.records || []).map((o:any) => ({ id: o?.id, label: o?.departmentCode }))}
                            placeholder="Select"
                            value={values?.department || null}
                            valueKey="id"
                            onChange={(text:any) => {
                              handleOnChange('department', text)
                            }}
                          />
                        </Grid>
                        <Grid item md={2} sm={1} xs={1}>
                          <OPRSelectorControl
                            error={errors?.team}
                            isEditable={isEditable}
                            keyName="label"
                            label={t('entity_team_submenu_title')}
                            multiple={false}
                            name="team"
                            optionalText="optional"
                            options={(allTeam?.records || []).map((o:any) => ({ id: o?.id, label: o?.teamCode }))}
                            placeholder="Select"
                            value={values?.team || null}
                            valueKey="id"
                            onChange={(text:any) => {
                              handleOnChange('team', text)
                            }}
                          />
                        </Grid>
                        <Grid item md={2} sm={1} xs={1}>
                          <OPRSelectorControl
                            error={errors?.costCenter}
                            isEditable={isEditable}
                            keyName="label"
                            label={t('entity_cost_center_submenu_title')}
                            multiple={false}
                            name="costCenter"
                            optionalText="optional"
                            options={(allCostCenter?.records || []).map((o:any) => ({ id: o?.id, label: o?.costCenterCode }))}
                            placeholder="Select"
                            value={values?.costCenter || null}
                            valueKey="id"
                            onChange={(text:any) => {
                              handleOnChange('costCenter', text)
                            }}
                          />
                        </Grid>
                        <Grid item md={2} sm={1} xs={1}>
                          <OPRSelectorControl
                            error={errors?.position}
                            isEditable={isEditable}
                            keyName="label"
                            label={t('employee_profile_position')}
                            multiple={false}
                            name="position"
                            optionalText="optional"
                            options={(allPosition?.records || []).map((o:any) => ({ id: o?.id, label: o?.positionCode }))}
                            placeholder="Select"
                            value={values?.position || null}
                            valueKey="id"
                            onChange={(text:any) => {
                              handleOnChange('position', text)
                            }}
                          />
                        </Grid>
                        <Grid item md={2} sm={1} xs={1}>
                          <OPRSelectorControl
                            error={errors?.grade}
                            isEditable={isEditable}
                            keyName="label"
                            label={t('entity_submenu_grade_title')}
                            multiple={false}
                            name="grade"
                            optionalText="optional"
                            options={(allGrade?.records || []).map((o:any) => ({ id: o?.id, label: o?.gradeCode }))}
                            placeholder="Select"
                            value={values?.grade || null}
                            valueKey="id"
                            onChange={(text:any) => {
                              handleOnChange('grade', text)
                            }}
                          />
                        </Grid>
                        <Grid item md={2} sm={1} xs={1}>
                          <OPRSelectorControl
                            error={errors?.staffType}
                            isEditable={isEditable}
                            keyName="label"
                            label={t('StaffType')}
                            multiple={false}
                            name="staffType"
                            optionalText="optional"
                            options={(allStaffType?.records || []).map((o:any) => ({ id: o?.id, label: o?.staffTypeCode }))}
                            placeholder="Select"
                            value={values?.staffType || null}
                            valueKey="id"
                            onChange={(text:any) => {
                              handleOnChange('staffType', text)
                            }}
                          />
                        </Grid>
                        <Grid item md={4} sm={1} xs={1}>
                          <OPRSelectorControl
                            error={errors?.irdCorporateTitle}
                            isEditable={isEditable}
                            keyName="label"
                            label={t('emp_profile_ird_corporate_title')}
                            multiple={false}
                            name="irdCorporateTitle"
                            options={(allIRD?.records || []).map((o:any) => ({ id: o?.id, label: o?.corporateTitleCode }))}
                            placeholder="Select"
                            value={values?.irdCorporateTitle || null}
                            valueKey="id"
                            onChange={(text:any) => {
                              handleOnChange('irdCorporateTitle', text)
                            }}
                          />
                        </Grid>
                      </>

                    )}
                    {values?.employeeMovementType?.label === 'Change of Remuneration' && (
                      <>
                        <Grid item md={4} sm={1} xs={1}>
                          <OPRSelectorControl
                            error={errors?.workCalendar}
                            isEditable={isEditable}
                            keyName="label"
                            label={t('ent_work_calendar_title')}
                            multiple={false}
                            name="workCalendar"
                            options={(allWorkCalendere?.records || []).map((o:any) => ({ id: o?.id, label: o?.workCalendarCode }))}
                            placeholder="Select"
                            value={values?.workCalendar || null}
                            valueKey="id"
                            onChange={(text:any) => {
                              handleOnChange('workCalendar', text)
                            }}
                          />
                        </Grid>
                        <Grid item md={4} sm={1} xs={1}>
                          <OPRSelectorControl
                            error={errors?.caw}
                            isEditable={isEditable}
                            keyName="label"
                            label={t('caw_calulation_method_title')}
                            multiple={false}
                            name="caw"
                            options={(allWorkCalendere?.records || []).map((o:any) => ({ id: o?.id, label: o?.cawCalculationMethod }))}
                            placeholder="Select"
                            value={values?.caw || null}
                            valueKey="id"
                            onChange={(text:any) => {
                              handleOnChange('caw', text)
                            }}
                          />
                        </Grid>
                      </>
                    )}
                    {/*  step 2 */}
                    {values?.employeeMovementType?.label === 'Rehire From Same Entity' && (
                      <>
                        {
                          values.rehireUsingSameEmployeeCode?.label === 'No' ? (
                            <Grid item md={4} sm={1} xs={1}>
                              <OPRInputControl
                                disabled={isEditable}
                                error={t(errors?.EmployeeCode)}
                                isEditable={isEditable}
                                label="Employee ID"
                                name="EmployeeCode"
                                value={values?.EmployeeCode}
                                onChange={handleChange}
                              />
                            </Grid>
                          ) : null
                        }
                        <Grid item md={2} sm={1} xs={1}>
                          <OPRDatePickerControl
                            error={errors?.commencementDate}
                            isEditable={isEditable}
                            label={t('employee_profile_commencement_date')}
                            name="commencementDate"
                            value={values?.commencementDate || null}
                            onChange={(date) => {
                              handleOnChange('commencementDate', date)
                            }}
                          />
                        </Grid>
                        <Grid item md={2} sm={1} xs={1}>
                          <OPRDatePickerControl
                            error={errors?.fourOneEightDate}
                            isEditable={isEditable}
                            label={t('start_date_418_picker')}
                            name="fourOneEightDate"
                            value={values?.fourOneEightDate || null}
                            onChange={(date) => {
                              handleOnChange('fourOneEightDate', date)
                            }}
                          />
                        </Grid>
                        <Grid item md={2} sm={1} xs={1}>
                          <OPRSelectorControl
                            error={errors?.region}
                            isEditable={isEditable}
                            keyName="label"
                            label={t('region')}
                            multiple={false}
                            name="region"
                            optionalText="optional"
                            options={(allRegion?.records || []).map((o:any) => ({ id: o?.id, label: o?.regionCode }))}
                            placeholder="Select"
                            value={values?.region || null}
                            valueKey="id"
                            onChange={(text:any) => {
                              handleOnChange('region', text)
                            }}
                          />
                        </Grid>
                        <Grid item md={2} sm={1} xs={1}>
                          <OPRSelectorControl
                            error={errors?.division}
                            isEditable={isEditable}
                            keyName="label"
                            label={t('entity_division_submenu_title')}
                            multiple={false}
                            name="division"
                            optionalText="optional"
                            options={(allDivision?.records || []).map((o:any) => ({ id: o?.id, label: o?.divisionCode }))}
                            placeholder="Select"
                            value={values?.division || null}
                            valueKey="id"
                            onChange={(text:any) => {
                              handleOnChange('division', text)
                            }}
                          />
                        </Grid>
                        <Grid item md={2} sm={1} xs={1}>
                          <OPRSelectorControl
                            error={errors?.department}
                            isEditable={isEditable}
                            keyName="label"
                            label={t('entity_department_submenu_title')}
                            multiple={false}
                            name="department"
                            optionalText="optional"
                            options={(allDepartment?.records || []).map((o:any) => ({ id: o?.id, label: o?.departmentCode }))}
                            placeholder="Select"
                            value={values?.department || null}
                            valueKey="id"
                            onChange={(text:any) => {
                              handleOnChange('department', text)
                            }}
                          />
                        </Grid>
                        <Grid item md={2} sm={1} xs={1}>
                          <OPRSelectorControl
                            error={errors?.team}
                            isEditable={isEditable}
                            keyName="label"
                            label={t('entity_team_submenu_title')}
                            multiple={false}
                            name="team"
                            optionalText="optional"
                            options={(allTeam?.records || []).map((o:any) => ({ id: o?.id, label: o?.teamCode }))}
                            placeholder="Select"
                            value={values?.team || null}
                            valueKey="id"
                            onChange={(text:any) => {
                              handleOnChange('team', text)
                            }}
                          />
                        </Grid>
                        <Grid item md={2} sm={1} xs={1}>
                          <OPRSelectorControl
                            error={errors?.costCenter}
                            isEditable={isEditable}
                            keyName="label"
                            label={t('entity_cost_center_submenu_title')}
                            multiple={false}
                            name="costCenter"
                            optionalText="optional"
                            options={(allCostCenter?.records || []).map((o:any) => ({ id: o?.id, label: o?.costCenterCode }))}
                            placeholder="Select"
                            value={values?.costCenter || null}
                            valueKey="id"
                            onChange={(text:any) => {
                              handleOnChange('costCenter', text)
                            }}
                          />
                        </Grid>
                        <Grid item md={2} sm={1} xs={1}>
                          <OPRSelectorControl
                            error={errors?.position}
                            isEditable={isEditable}
                            keyName="label"
                            label={t('employee_profile_position')}
                            multiple={false}
                            name="position"
                            optionalText="optional"
                            options={(allPosition?.records || []).map((o:any) => ({ id: o?.id, label: o?.positionCode }))}
                            placeholder="Select"
                            value={values?.position || null}
                            valueKey="id"
                            onChange={(text:any) => {
                              handleOnChange('position', text)
                            }}
                          />
                        </Grid>
                        <Grid item md={2} sm={1} xs={1}>
                          <OPRSelectorControl
                            error={errors?.grade}
                            isEditable={isEditable}
                            keyName="label"
                            label={t('entity_submenu_grade_title')}
                            multiple={false}
                            name="grade"
                            optionalText="optional"
                            options={(allGrade?.records || []).map((o:any) => ({ id: o?.id, label: o?.gradeCode }))}
                            placeholder="Select"
                            value={values?.grade || null}
                            valueKey="id"
                            onChange={(text:any) => {
                              handleOnChange('grade', text)
                            }}
                          />
                        </Grid>
                        <Grid item md={2} sm={1} xs={1}>
                          <OPRSelectorControl
                            error={errors?.staffType}
                            isEditable={isEditable}
                            keyName="label"
                            label={t('StaffType')}
                            multiple={false}
                            name="staffType"
                            optionalText="optional"
                            options={(allStaffType?.records || []).map((o:any) => ({ id: o?.id, label: o?.staffTypeCode }))}
                            placeholder="Select"
                            value={values?.staffType || null}
                            valueKey="id"
                            onChange={(text:any) => {
                              handleOnChange('staffType', text)
                            }}
                          />
                        </Grid>
                        <Grid item md={4} sm={1} xs={1}>
                          <OPRSelectorControl
                            error={errors?.irdCorporateTitle}
                            isEditable={isEditable}
                            keyName="label"
                            label={t('emp_profile_ird_corporate_title')}
                            multiple={false}
                            name="irdCorporateTitle"
                            options={(allIRD?.records || []).map((o:any) => ({ id: o?.id, label: o?.corporateTitleCode }))}
                            placeholder="Select"
                            value={values?.irdCorporateTitle || null}
                            valueKey="id"
                            onChange={(text:any) => {
                              handleOnChange('irdCorporateTitle', text)
                            }}
                          />
                        </Grid>
                        <Grid item md={4} sm={1} xs={1}>
                          <OPRSelectorControl
                            error={errors?.workCalendar}
                            isEditable={isEditable}
                            keyName="label"
                            label={t('ent_work_calendar_title')}
                            multiple={false}
                            name="workCalendar"
                            options={(allWorkCalendere?.records || []).map((o:any) => ({ id: o?.id, label: o?.workCalendarCode }))}
                            placeholder="Select"
                            value={values?.workCalendar || null}
                            valueKey="id"
                            onChange={(text:any) => {
                              handleOnChange('workCalendar', text)
                            }}
                          />
                        </Grid>
                        <Grid item md={4} sm={1} xs={1}>
                          <OPRSelectorControl
                            error={errors?.caw}
                            isEditable={isEditable}
                            keyName="label"
                            label={t('caw_calulation_method_title')}
                            multiple={false}
                            name="caw"
                            options={(allWorkCalendere?.records || []).map((o:any) => ({ id: o?.id, label: o?.cawCalculationMethod }))}
                            placeholder="Select"
                            value={values?.caw || null}
                            valueKey="id"
                            onChange={(text:any) => {
                              handleOnChange('caw', text)
                            }}
                          />
                        </Grid>
                      </>
                    )}
                  </OPRResponsiveGrid>
                </>
              )
            case 3:
              return (
                <>
                  <OPRLabel variant="h4">{t('confirm_details')}</OPRLabel>
                  <OPRLabel sx={{ marginTop: '15px', marginBottom: '15px' }} variant="body2">
                    {`  ${t('please_check_details_below')}`}
                  </OPRLabel>
                  <OPRResponsiveGrid>
                    {values?.employeeMovementType?.label === 'Termination' && (
                      <>
                        <div style={{ display: 'block', width: '100%', margin: '10px 16px 10px' }}>
                          <OPRLabel variant="h4">Employee movement</OPRLabel>
                        </div>
                        <Grid item md={4} sm={1} xs={1}>
                          <OPRSelectorControl
                            isEditable
                            error={errors?.employeeMovementType}
                            keyName="label"
                            label={t('ent_emp_move_type_movement_type')}
                            multiple={false}
                            name="employeeMovementType"
                            options={[{ id: '4094fce4-51a4-45bf-a7ae-3dbef5d02cc5', label: 'Termination' }, { id: 'efe289aa-2abd-4100-8b2c-a34b61208843', label: 'Change of Assignment' }, { id: 'efe289aa-2abd-4100-8b2c-a34b61208420', label: ' Change of Remuneration' }, { id: 'efe289aa-2abd-4100-8b2c-a34b6120884323', label: 'Rehire From Same Entity' }]}
                            placeholder="Select"
                            value={[{ id: '4094fce4-51a4-45bf-a7ae-3dbef5d02cc5', label: 'Termination' }, { id: 'efe289aa-2abd-4100-8b2c-a34b61208843', label: 'Change of Assignment' }, { id: 'efe289aa-2abd-4100-8b2c-a34b61208420', label: ' Change of Remuneration' }, { id: 'efe289aa-2abd-4100-8b2c-a34b6120884323', label: 'Rehire From Same Entity' }].find((o:any) => o?.id === values?.employeeMovementType?.id)}
                            valueKey="label"
                            onChange={(text:any) => {
                              handleOnChange('employeeMovementType', text)
                            }}
                          />
                        </Grid>
                        {/* {values?.employeeMovementType} */}

                        <Grid item md={4} sm={1} xs={1}>
                          <OPRInputControl
                            isEditable
                            error={t(errors?.sequence)}
                            label="sequence"
                            name="sequence"
                            value={values?.sequence}
                            onChange={handleChange}
                          />
                        </Grid>
                        <Grid item md={4} sm={1} xs={1}>
                          <OPRInputControl
                            isEditable
                            error={t(errors?.reason)}
                            label="reason"
                            name="reason"
                            value={values?.reason}
                            onChange={handleChange}
                          />
                        </Grid>
                        <div style={{ display: 'block', width: '100%', margin: '10px 16px 10px' }}>
                          <OPRLabel variant="h4">{values?.employeeMovementType?.label}</OPRLabel>
                        </div>

                        <Grid item md={2} sm={1} xs={1}>
                          {/* effective end date */}

                          <OPRDatePickerControl
                            isEditable
                            error={errors?.lastEmploymentDate}
                            label={t('employee_profile_last_working_date')}
                            name="lastEmploymentDate"
                            value={values?.lastEmploymentDate || null}
                            onChange={(date) => {
                              handleOnChange('lastEmploymentDate', date)
                            }}
                          />
                        </Grid>
                        <Grid item md={2} sm={1} xs={1}>
                          {/* effective end date */}

                          <OPRDatePickerControl
                            isEditable
                            error={errors?.resignationDate}
                            label={t('Resignation date')}
                            name="resignationDate"
                            value={values?.resignationDate || null}
                            onChange={(date) => {
                              handleOnChange('resignationDate', date)
                            }}
                          />
                        </Grid>
                        <Grid item md={2} sm={1} xs={1}>
                          {/* effective end date */}

                          <OPRDatePickerControl
                            isEditable
                            error={errors?.lastWorkingDate}
                            label={t('employee_profile_last_working_date_text')}
                            name="lastWorkingDate"
                            value={values?.lastWorkingDate || null}
                            onChange={(date) => {
                              handleOnChange('lastWorkingDate', date)
                            }}
                          />
                        </Grid>
                        <Grid item md={2} sm={1} xs={1}>
                          {/* effective end date */}

                          <OPRDatePickerControl
                            isEditable
                            error={errors?.noticePeriodEndDate}
                            label={t('employee_profile_resignation_date_text')}
                            name="noticePeriodEndDate"
                            value={values?.noticePeriodEndDate || null}
                            onChange={(date) => {
                              handleOnChange('noticePeriodEndDate', date)
                            }}
                          />
                        </Grid>
                        <Grid item md={2} sm={1} xs={1}>
                          {/* effective end date */}

                          <OPRDatePickerControl
                            isEditable
                            error={errors?.payThroughDate}
                            label={t('employee_profile_pay_through_date')}
                            name="payThroughDate"
                            value={values?.payThroughDate || null}
                            onChange={(date) => {
                              handleOnChange('payThroughDate', date)
                            }}
                          />
                        </Grid>
                        <Grid item md={2} sm={1} xs={1}>
                          <OPRSelectorControl
                            isEditable
                            error={errors?.terminationCode}
                            keyName="label"
                            label={t('employee_profile_termination_code')}
                            multiple={false}
                            name="terminationCode"
                            optionalText="optional"
                            options={(allPosts?.records || []).map((o:any) => ({ id: o?.id, label: o?.terminationCode }))}
                            placeholder="Select"
                            value={values?.terminationCode || null}
                            valueKey="label"
                            onChange={(text:any) => {
                              handleOnChange('terminationCode', text)
                            }}
                          />
                        </Grid>
                        <Grid item md={4} sm={1} xs={1}>
                          <OPRInputControl
                            isEditable
                            error={t(errors?.sequence)}
                            label="employee_profile_termination_reason"
                            name="terminationReason"
                            value={values?.sequence}
                            onChange={handleChange}
                          />
                        </Grid>
                      </>

                    )}
                    {values?.employeeMovementType?.label === 'Change of Assignment' && (
                      <>
                        <div style={{ display: 'block', width: '100%', margin: '10px 16px 10px' }}>
                          <OPRLabel variant="h4">Employee movement</OPRLabel>
                        </div>
                        <Grid item md={4} sm={1} xs={1}>
                          <OPRSelectorControl
                            isEditable
                            error={errors?.employeeMovementType}
                            keyName="label"
                            label={t('ent_emp_move_type_movement_type')}
                            multiple={false}
                            name="employeeMovementType"
                            options={[{ id: '4094fce4-51a4-45bf-a7ae-3dbef5d02cc5', label: 'Termination' }, { id: 'efe289aa-2abd-4100-8b2c-a34b61208843', label: 'Change of Assignment' }, { id: 'efe289aa-2abd-4100-8b2c-a34b61208420', label: ' Change of Remuneration' }]}
                            placeholder="Select"
                            value={[{ id: '4094fce4-51a4-45bf-a7ae-3dbef5d02cc5', label: 'Termination' }, { id: 'efe289aa-2abd-4100-8b2c-a34b61208843', label: 'Change of Assignment' }, { id: 'efe289aa-2abd-4100-8b2c-a34b61208420', label: ' Change of Remuneration' }].find((o:any) => o?.id === values?.employeeMovementType?.id)}
                            valueKey="label"
                            onChange={(text:any) => {
                              handleOnChange('employeeMovementType', text)
                            }}
                          />
                        </Grid>
                        <Grid item md={4} sm={1} xs={1}>
                          <OPRDatePickerControl
                            isEditable
                            error={errors?.effectiveDate}
                            label={t('ent_curr_exch_currency_effective_dt')}
                            name="effectiveDate"
                            value={values?.effectiveDate || null}
                            onChange={(date) => {
                              handleOnChange('effectiveDate', date)
                            }}
                          />
                        </Grid>
                        <Grid item md={4} sm={1} xs={1}>
                          <OPRInputControl
                            isEditable
                            error={t(errors?.sequence)}
                            label="sequence"
                            name="sequence"
                            value={values?.sequence}
                            onChange={handleChange}
                          />
                        </Grid>
                        <Grid item md={4} sm={1} xs={1}>
                          <OPRInputControl
                            isEditable
                            error={t(errors?.reason)}
                            label="reason"
                            name="reason"
                            value={values?.reason}
                            onChange={handleChange}
                          />
                        </Grid>
                        <div style={{ display: 'block', width: '100%', margin: '10px 16px 10px' }}>
                          <OPRLabel variant="h4">{values?.employeeMovementType?.label}</OPRLabel>
                        </div>
                        <Grid item md={2} sm={1} xs={1}>
                          <OPRSelectorControl
                            isEditable
                            error={errors?.region}
                            keyName="label"
                            label={t('region')}
                            multiple={false}
                            name="region"
                            options={(allRegion?.records || []).map((o:any) => ({ id: o?.id, label: o?.regionCode }))}
                            placeholder="Select"
                            value={values?.region || null}
                            valueKey="label"
                            onChange={(text:any) => {
                              handleOnChange('region', text)
                            }}
                          />
                        </Grid>
                        <Grid item md={2} sm={1} xs={1}>
                          <OPRSelectorControl
                            isEditable
                            error={errors?.division}
                            keyName="label"
                            label={t('entity_division_submenu_title')}
                            multiple={false}
                            name="division"
                            options={(allDivision?.records || []).map((o:any) => ({ id: o?.id, label: o?.divisionCode }))}
                            placeholder="Select"
                            value={values?.division || null}
                            valueKey="label"
                            onChange={(text:any) => {
                              handleOnChange('division', text)
                            }}
                          />
                        </Grid>
                        <Grid item md={2} sm={1} xs={1}>
                          <OPRSelectorControl
                            isEditable
                            error={errors?.department}
                            keyName="label"
                            label={t('entity_department_submenu_title')}
                            multiple={false}
                            name="department"
                            options={(allDepartment?.records || []).map((o:any) => ({ id: o?.id, label: o?.departmentCode }))}
                            placeholder="Select"
                            value={values?.department || null}
                            valueKey="label"
                            onChange={(text:any) => {
                              handleOnChange('department', text)
                            }}
                          />
                        </Grid>
                        <Grid item md={2} sm={1} xs={1}>
                          <OPRSelectorControl
                            isEditable
                            error={errors?.team}
                            keyName="label"
                            label={t('entity_team_submenu_title')}
                            multiple={false}
                            name="team"
                            options={(allTeam?.records || []).map((o:any) => ({ id: o?.id, label: o?.teamCode }))}
                            placeholder="Select"
                            value={values?.team || null}
                            valueKey="label"
                            onChange={(text:any) => {
                              handleOnChange('team', text)
                            }}
                          />
                        </Grid>
                        <Grid item md={2} sm={1} xs={1}>
                          <OPRSelectorControl
                            isEditable
                            error={errors?.costCenter}
                            keyName="label"
                            label={t('entity_cost_center_submenu_title')}
                            multiple={false}
                            name="costCenter"
                            options={(allCostCenter?.records || []).map((o:any) => ({ id: o?.id, label: o?.costCenterCode }))}
                            placeholder="Select"
                            value={values?.costCenter || null}
                            valueKey="label"
                            onChange={(text:any) => {
                              handleOnChange('costCenter', text)
                            }}
                          />
                        </Grid>
                        <Grid item md={2} sm={1} xs={1}>
                          <OPRSelectorControl
                            isEditable
                            error={errors?.position}
                            keyName="label"
                            label={t('employee_profile_position')}
                            multiple={false}
                            name="position"
                            options={(allPosition?.records || []).map((o:any) => ({ id: o?.id, label: o?.positionCode }))}
                            placeholder="Select"
                            value={values?.position || null}
                            valueKey="label"
                            onChange={(text:any) => {
                              handleOnChange('position', text)
                            }}
                          />
                        </Grid>
                        <Grid item md={2} sm={1} xs={1}>
                          <OPRSelectorControl
                            isEditable
                            error={errors?.grade}
                            keyName="label"
                            label={t('entity_submenu_grade_title')}
                            multiple={false}
                            name="grade"
                            options={(allGrade?.records || []).map((o:any) => ({ id: o?.id, label: o?.gradeCode }))}
                            placeholder="Select"
                            value={values?.grade || null}
                            valueKey="label"
                            onChange={(text:any) => {
                              handleOnChange('grade', text)
                            }}
                          />
                        </Grid>
                        <Grid item md={2} sm={1} xs={1}>
                          <OPRSelectorControl
                            isEditable
                            error={errors?.staffType}
                            keyName="label"
                            label={t('StaffType')}
                            multiple={false}
                            name="staffType"
                            options={(allStaffType?.records || []).map((o:any) => ({ id: o?.id, label: o?.staffTypeCode }))}
                            placeholder="Select"
                            value={values?.staffType || null}
                            valueKey="label"
                            onChange={(text:any) => {
                              handleOnChange('staffType', text)
                            }}
                          />
                        </Grid>
                        <Grid item md={4} sm={1} xs={1}>
                          <OPRSelectorControl
                            isEditable
                            error={errors?.irdCorporateTitle}
                            keyName="label"
                            label={t('emp_profile_ird_corporate_title')}
                            multiple={false}
                            name="irdCorporateTitle"
                            options={(allIRD?.records || []).map((o:any) => ({ id: o?.id, label: o?.corporateTitleCode }))}
                            placeholder="Select"
                            value={values?.irdCorporateTitle || null}
                            valueKey="label"
                            onChange={(text:any) => {
                              handleOnChange('irdCorporateTitle', text)
                            }}
                          />
                        </Grid>
                      </>
                    )}
                    {values?.employeeMovementType?.label === 'Change of Remuneration' && (
                      <>
                        <div style={{ display: 'block', width: '100%', margin: '10px 16px 10px' }}>
                          <OPRLabel variant="h4">Employee movement</OPRLabel>
                        </div>
                        <Grid item md={4} sm={1} xs={1}>
                          <OPRSelectorControl
                            isEditable
                            error={errors?.employeeMovementType}
                            keyName="label"
                            label={t('ent_emp_move_type_movement_type')}
                            multiple={false}
                            name="employeeMovementType"
                            options={[{ id: '4094fce4-51a4-45bf-a7ae-3dbef5d02cc5', label: 'Termination' }, { id: 'efe289aa-2abd-4100-8b2c-a34b61208843', label: 'Change of Assignment' }, { id: 'efe289aa-2abd-4100-8b2c-a34b61208420', label: ' Change of Remuneration' }]}
                            placeholder="Select"
                            value={[{ id: '4094fce4-51a4-45bf-a7ae-3dbef5d02cc5', label: 'Termination' }, { id: 'efe289aa-2abd-4100-8b2c-a34b61208843', label: 'Change of Assignment' }, { id: 'efe289aa-2abd-4100-8b2c-a34b61208420', label: ' Change of Remuneration' }].find((o:any) => o?.id === values?.employeeMovementType?.id)}
                            valueKey="label"
                            onChange={(text:any) => {
                              handleOnChange('employeeMovementType', text)
                            }}
                          />
                        </Grid>
                        <Grid item md={4} sm={1} xs={1}>
                          <OPRDatePickerControl
                            isEditable
                            error={errors?.effectiveDate}
                            label={t('ent_curr_exch_currency_effective_dt')}
                            name="effectiveDate"
                            value={values?.effectiveDate || null}
                            onChange={(date) => {
                              handleOnChange('effectiveDate', date)
                            }}
                          />
                        </Grid>
                        <Grid item md={4} sm={1} xs={1}>
                          <OPRInputControl
                            isEditable
                            error={t(errors?.sequence)}
                            label="sequence"
                            name="sequence"
                            value={values?.sequence}
                            onChange={handleChange}
                          />
                        </Grid>
                        <Grid item md={4} sm={1} xs={1}>
                          <OPRInputControl
                            isEditable
                            error={t(errors?.reason)}
                            label="reason"
                            name="reason"
                            value={values?.reason}
                            onChange={handleChange}
                          />
                        </Grid>
                        <div style={{ display: 'block', width: '100%', margin: '10px 16px 10px' }}>
                          <OPRLabel variant="h4">{values?.employeeMovementType.label}</OPRLabel>
                        </div>
                        <Grid item md={4} sm={1} xs={1}>
                          <OPRSelectorControl
                            isEditable
                            error={errors?.workCalendar}
                            keyName="label"
                            label={t('ent_work_calendar_title')}
                            multiple={false}
                            name="workCalendar"
                            options={(allWorkCalendere?.records || []).map((o:any) => ({ id: o?.id, label: o?.workCalendarCode }))}
                            placeholder="Select"
                            value={values?.workCalendar || null}
                            valueKey="label"
                            onChange={(text:any) => {
                              handleOnChange('workCalendar', text)
                            }}
                          />
                        </Grid>
                        <Grid item md={4} sm={1} xs={1}>
                          <OPRSelectorControl
                            isEditable
                            error={errors?.caw}
                            keyName="label"
                            label={t('caw_calulation_method_title')}
                            multiple={false}
                            name="caw"
                            options={(allWorkCalendere?.records || []).map((o:any) => ({ id: o?.id, label: o?.cawCalculationMethod }))}
                            placeholder="Select"
                            value={values?.caw || null}
                            valueKey="label"
                            onChange={(text:any) => {
                              handleOnChange('caw', text)
                            }}
                          />
                        </Grid>
                      </>
                    )}
                    {values?.employeeMovementType?.label === 'Rehire From Same Entity' && (
                      <>
                        <div style={{ display: 'block', width: '100%', margin: '10px 16px 10px' }}>
                          <OPRLabel variant="h4">Employee movement</OPRLabel>
                        </div>
                        <Grid item md={4} sm={1} xs={1}>
                          <OPRSelectorControl
                            isEditable
                            error={errors?.employeeMovementType}
                            keyName="label"
                            label={t('ent_emp_move_type_movement_type')}
                            multiple={false}
                            name="employeeMovementType"
                            options={[{ id: '4094fce4-51a4-45bf-a7ae-3dbef5d02cc5', label: 'Termination' }, { id: 'efe289aa-2abd-4100-8b2c-a34b61208843', label: 'Change of Assignment' }, { id: 'efe289aa-2abd-4100-8b2c-a34b61208420', label: ' Change of Remuneration' }, { id: 'efe289aa-2abd-4100-8b2c-a34b6120884323', label: 'Rehire From Same Entity' }]}
                            placeholder="Select"
                            value={[{ id: '4094fce4-51a4-45bf-a7ae-3dbef5d02cc5', label: 'Termination' }, { id: 'efe289aa-2abd-4100-8b2c-a34b61208843', label: 'Change of Assignment' }, { id: 'efe289aa-2abd-4100-8b2c-a34b61208420', label: ' Change of Remuneration' }, { id: 'efe289aa-2abd-4100-8b2c-a34b6120884323', label: 'Rehire From Same Entity' }].find((o:any) => o?.id === values?.employeeMovementType?.id)}
                            valueKey="label"
                            onChange={(text:any) => {
                              handleOnChange('employeeMovementType', text)
                            }}
                          />
                        </Grid>
                        <Grid item md={4} sm={1} xs={1}>
                          <OPRDatePickerControl
                            isEditable
                            error={errors?.effectiveDate}
                            label={t('ent_curr_exch_currency_effective_dt')}
                            name="effectiveDate"
                            value={values?.effectiveDate || null}
                            onChange={(date) => {
                              handleOnChange('effectiveDate', date)
                            }}
                          />
                        </Grid>
                        <Grid item md={4} sm={1} xs={1}>
                          <OPRInputControl
                            isEditable
                            error={t(errors?.sequence)}
                            label="sequence"
                            name="sequence"
                            value={values?.sequence}
                            onChange={handleChange}
                          />
                        </Grid>
                        <Grid item md={4} sm={1} xs={1}>
                          <OPRInputControl
                            isEditable
                            error={t(errors?.reason)}
                            label="reason"
                            name="reason"
                            value={values?.reason}
                            onChange={handleChange}
                          />
                        </Grid>
                        <div style={{ display: 'block', width: '100%', margin: '10px 16px 10px' }}>
                          <OPRLabel variant="h4">{values?.employeeMovementType?.label}</OPRLabel>
                        </div>
                        <Grid item md={2} sm={1} xs={1}>
                          <OPRDatePickerControl
                            isEditable
                            error={errors?.commencementDate}
                            label={t('employee_profile_commencement_date')}
                            name="commencementDate"
                            value={values?.commencementDate || null}
                            onChange={(date) => {
                              handleOnChange('commencementDate', date)
                            }}
                          />
                        </Grid>
                        <Grid item md={2} sm={1} xs={1}>
                          <OPRDatePickerControl
                            isEditable
                            error={errors?.fourOneEightDate}
                            label={t('start_date_418_picker')}
                            name="fourOneEightDate"
                            value={values?.fourOneEightDate || null}
                            onChange={(date) => {
                              handleOnChange('fourOneEightDate', date)
                            }}
                          />
                        </Grid>
                        <Grid item md={2} sm={1} xs={1}>
                          <OPRSelectorControl
                            isEditable
                            error={errors?.region}
                            keyName="label"
                            label={t('region')}
                            multiple={false}
                            name="region"
                            optionalText="optional"
                            options={(allRegion?.records || []).map((o:any) => ({ id: o?.id, label: o?.regionCode }))}
                            placeholder="Select"
                            value={values?.region || null}
                            valueKey="label"
                            onChange={(text:any) => {
                              handleOnChange('region', text)
                            }}
                          />
                        </Grid>
                        <Grid item md={2} sm={1} xs={1}>
                          <OPRSelectorControl
                            isEditable
                            error={errors?.division}
                            keyName="label"
                            label={t('entity_division_submenu_title')}
                            multiple={false}
                            name="division"
                            optionalText="optional"
                            options={(allDivision?.records || []).map((o:any) => ({ id: o?.id, label: o?.divisionCode }))}
                            placeholder="Select"
                            value={values?.division || null}
                            valueKey="label"
                            onChange={(text:any) => {
                              handleOnChange('division', text)
                            }}
                          />
                        </Grid>
                        <Grid item md={2} sm={1} xs={1}>
                          <OPRSelectorControl
                            isEditable
                            error={errors?.department}
                            keyName="label"
                            label={t('entity_department_submenu_title')}
                            multiple={false}
                            name="department"
                            optionalText="optional"
                            options={(allDepartment?.records || []).map((o:any) => ({ id: o?.id, label: o?.departmentCode }))}
                            placeholder="Select"
                            value={values?.department || null}
                            valueKey="label"
                            onChange={(text:any) => {
                              handleOnChange('department', text)
                            }}
                          />
                        </Grid>
                        <Grid item md={2} sm={1} xs={1}>
                          <OPRSelectorControl
                            isEditable
                            error={errors?.team}
                            keyName="label"
                            label={t('entity_team_submenu_title')}
                            multiple={false}
                            name="team"
                            optionalText="optional"
                            options={(allTeam?.records || []).map((o:any) => ({ id: o?.id, label: o?.teamCode }))}
                            placeholder="Select"
                            value={values?.team || null}
                            valueKey="label"
                            onChange={(text:any) => {
                              handleOnChange('team', text)
                            }}
                          />
                        </Grid>
                        <Grid item md={2} sm={1} xs={1}>
                          <OPRSelectorControl
                            isEditable
                            error={errors?.costCenter}
                            keyName="label"
                            label={t('entity_cost_center_submenu_title')}
                            multiple={false}
                            name="costCenter"
                            optionalText="optional"
                            options={(allCostCenter?.records || []).map((o:any) => ({ id: o?.id, label: o?.costCenterCode }))}
                            placeholder="Select"
                            value={values?.costCenter || null}
                            valueKey="label"
                            onChange={(text:any) => {
                              handleOnChange('costCenter', text)
                            }}
                          />
                        </Grid>
                        <Grid item md={2} sm={1} xs={1}>
                          <OPRSelectorControl
                            isEditable
                            error={errors?.position}
                            keyName="label"
                            label={t('employee_profile_position')}
                            multiple={false}
                            name="position"
                            optionalText="optional"
                            options={(allPosition?.records || []).map((o:any) => ({ id: o?.id, label: o?.positionCode }))}
                            placeholder="Select"
                            value={values?.position || null}
                            valueKey="label"
                            onChange={(text:any) => {
                              handleOnChange('position', text)
                            }}
                          />
                        </Grid>
                        <Grid item md={2} sm={1} xs={1}>
                          <OPRSelectorControl
                            isEditable
                            error={errors?.grade}
                            keyName="label"
                            label={t('entity_submenu_grade_title')}
                            multiple={false}
                            name="grade"
                            optionalText="optional"
                            options={(allGrade?.records || []).map((o:any) => ({ id: o?.id, label: o?.gradeCode }))}
                            placeholder="Select"
                            value={values?.grade || null}
                            valueKey="label"
                            onChange={(text:any) => {
                              handleOnChange('grade', text)
                            }}
                          />
                        </Grid>
                        <Grid item md={2} sm={1} xs={1}>
                          <OPRSelectorControl
                            isEditable
                            error={errors?.staffType}
                            keyName="label"
                            label={t('StaffType')}
                            multiple={false}
                            name="staffType"
                            optionalText="optional"
                            options={(allStaffType?.records || []).map((o:any) => ({ id: o?.id, label: o?.staffTypeCode }))}
                            placeholder="Select"
                            value={values?.staffType || null}
                            valueKey="label"
                            onChange={(text:any) => {
                              handleOnChange('staffType', text)
                            }}
                          />
                        </Grid>
                        <Grid item md={4} sm={1} xs={1}>
                          <OPRSelectorControl
                            isEditable
                            error={errors?.irdCorporateTitle}
                            keyName="label"
                            label={t('emp_profile_ird_corporate_title')}
                            multiple={false}
                            name="irdCorporateTitle"
                            options={(allIRD?.records || []).map((o:any) => ({ id: o?.id, label: o?.corporateTitleCode }))}
                            placeholder="Select"
                            value={values?.irdCorporateTitle || null}
                            valueKey="label"
                            onChange={(text:any) => {
                              handleOnChange('irdCorporateTitle', text)
                            }}
                          />
                        </Grid>
                        <Grid item md={4} sm={1} xs={1}>
                          <OPRSelectorControl
                            isEditable
                            error={errors?.workCalendar}
                            keyName="label"
                            label={t('ent_work_calendar_title')}
                            multiple={false}
                            name="workCalendar"
                            options={(allWorkCalendere?.records || []).map((o:any) => ({ id: o?.id, label: o?.workCalendarCode }))}
                            placeholder="Select"
                            value={values?.workCalendar || null}
                            valueKey="label"
                            onChange={(text:any) => {
                              handleOnChange('workCalendar', text)
                            }}
                          />
                        </Grid>
                        <Grid item md={4} sm={1} xs={1}>
                          <OPRSelectorControl
                            isEditable
                            error={errors?.caw}
                            keyName="label"
                            label={t('caw_calulation_method_title')}
                            multiple={false}
                            name="caw"
                            options={(allWorkCalendere?.records || []).map((o:any) => ({ id: o?.id, label: o?.cawCalculationMethod }))}
                            placeholder="Select"
                            value={values?.caw || null}
                            valueKey="label"
                            onChange={(text:any) => {
                              handleOnChange('caw', text)
                            }}
                          />
                        </Grid>
                      </>
                    )}
                  </OPRResponsiveGrid>
                </>
              )
            default:
              console.log('No Cases matched , Please Close')
              return null // return null when no other cases match
          }
        })()}
        <Box sx={{
          display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: 5,
        }}
        >
          <OPRButton
            color="info"
            variant="text"
            onClick={() => {
              handleClose()
              setSteps(0)
              setValues({})
            }}
          >
            Cancel
          </OPRButton>
          {steps > 0 && (
            <OPRButton
              style={{ marginLeft: 'auto' }}
              variant="text"
              onClick={() => {
                setSteps((prev) => prev - 1)
              }}
            >
              <RighCaretBlue />
              Back
            </OPRButton>
          )}
          <OPRButton
            variant="contained"
            onClick={(e:any) => {
              if (userRoleOperation === 'Edit profile') {
                onClick()
              } else {
                // setSteps((prev) => prev + 1)
              }
              // if (steps === 0) {

              // }
              handleFormSubmit(e, () => {
                handleMovementSubmit()
              })
            }}
          >
            {steps === 3 ? 'Confirm' : 'Continue'}
            <LeftCaret />
          </OPRButton>
        </Box>
      </CustomDialog>
    </Box>
  )
}
