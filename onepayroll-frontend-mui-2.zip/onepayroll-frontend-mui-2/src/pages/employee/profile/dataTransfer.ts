import { customeDateFormat } from 'constants/index'

export const dataModification = (rowData:any) => {
  const data = {
    id: rowData.id,
    employeeCode: rowData.employeeCode,
    commencementDate: rowData.commencementDate,
    dateJoinGroup: rowData.dateJoinGroup,
    positionId: rowData.positionId,
    positionCode: rowData.positionCode,
    gradeId: rowData.gradeId,
    gradeCode: rowData.gradeCode,
    staffTypeId: rowData.staffTypeId,
    staffTypeCode: rowData.staffTypeCode,
    departmentId: rowData.departmentId,
    departmentCode: rowData.departmentCode,
    costCenterId: rowData.costCenterId,
    costCenterCode: rowData.costCenterCode,
    divisionId: rowData.divisionId,
    divisionCode: rowData.divisionCode,
    regionId: rowData.regionId,
    regionCode: rowData.regionCode,
    teamId: rowData.teamId,
    teamCode: rowData.teamCode,
    lastEmploymentDate: rowData.lastEmploymentDate,
    resignationDate: rowData.resignationDate,
    lastWorkingDate: rowData.lastWorkingDate,
    noticePeriodEndDate: rowData.noticePeriodEndDate,
    payThroughDate: rowData.payThroughDate,
    terminationCodeId: rowData.terminationCodeId,
    terminationCode: rowData.terminationCode,
    terminationReason: rowData.terminationReason,
    workCalendarId: rowData.workCalendarId,
    workCalendarCode: rowData.workCalendarCode,
    cawCalculationMethod: rowData.cawCalculationMethod,
    cawCalculationMethodDivideByFixedDays: rowData.cawCalculationMethodDivideByFixedDays,
    employeeProfileId: rowData.employeeProfileId,
    employeeProfile: {
      id: rowData.id,
      personID: rowData.personID,
      globalID: rowData.globalID,
      employmentStatus: rowData.employmentStatus,
      payrollIndicator: rowData.payrollIndicator,
      surname: rowData.surname,
      givenName: rowData.givenName,
      displayName: rowData.displayName,
      nameInLocalLanguage: rowData.nameInLocalLanguage,
      christianName: rowData.christianName,
      middleName: rowData.middleName,
      title: rowData.title,
      gender: rowData.gender,
      dateOfBirth: rowData.dateOfBirth,
      identityNumber: rowData.identityNumber,
      passportNumber: rowData.passportNumber,
      passportIssueCountry: rowData.passportIssueCountry,
      nationalityId: rowData.nationalityId,
      nationalityCode: rowData.nationalityCode,
      maritalStatus: rowData.maritalStatus,
      visaHolderIndicator: rowData.visaHolderIndicator,
      visaIssueDate: rowData.visaIssueDate,
      visaFirstLandingDate: rowData.visaFirstLandingDate,
      visaExpiryDate: rowData.visaExpiryDate,
      homeCountryId: rowData.homeCountryId,
      homeCountryCode: rowData.homeCountryCode,
      workEmailAddress: rowData.workEmailAddress,
      personalEmailAddress: rowData.personalEmailAddress,
      mobileNumber: rowData.mobileNumber,
      homePhoneNumber: rowData.homePhoneNumber,
      officePhoneNumber: rowData.officePhoneNumber,
      residentialAddress: rowData.residentialAddress,
      postalAddress: rowData.postalAddress,
      yearOfServiceOption: rowData.yearOfServiceOption,
      receivePayslipMethod: rowData.receivePayslipMethod,
      probationType: rowData.probationType,
      probationUnit: rowData.probationUnit,
      probationDate: rowData.probationDate,
      baseSalaryType: rowData.baseSalaryType,
      baseSalaryCurrencyId: rowData.baseSalaryCurrencyId,
      baseSalaryCurrencyCode: rowData.baseSalaryCurrencyCode,
      baseSalaryWage: rowData.baseSalaryWage,
      salaryProrationMethod: rowData.salaryProrationMethod,
      payGroupId: rowData.payGroupId,
      payGroupCode: rowData.payGroupCode,
      holdPayment: rowData.holdPayment,
      paymentCurrencyId: rowData.paymentCurrencyId,
      paymentCurrencyCode: rowData.paymentCurrencyCode,
      paymentMethodId: rowData.paymentMethodId,
      paymentMethodCode: rowData.paymentMethodCode,
      eligible13thMonthSalary: rowData.eligible13thMonthSalary,
      eaoCalculationMethod: rowData.eaoCalculationMethod,
      eaoStatutoryHolidayPayStartDate: rowData.eaoStatutoryHolidayPayStartDate,
      hkEmployeeProfile: rowData.hkEmployeeProfile,
    },
    effectiveDate: rowData,
    hkEmployeeSnapshot: {
      id: rowData.id,
      employeeSnapshotId: rowData.employeeSnapshotId,
      startDate418: rowData.startDate418,
      irdCorporateTitleId: rowData.irdCorporateTitleId,
      irdCorporateTitleCode: rowData.irdCorporateTitleCode,
    },
  }
  return data
}

export const modifiedDataList = (data:any) => {
  Object.entries(data).forEach(([key, value]) => {
    if (value === '') {
      data[key] = null
    }
  })

  const dataList = {
    id: data.id,
    personID: data.personID,
    globalID: data.globalID,
    employmentStatus: data.employmentStatus,
    payrollIndicator: data.payrollIndicator,
    surname: data.surname,
    givenName: data.givenName,
    displayName: data.displayName,
    nameInLocalLanguage: data.nameInLocalLanguage,
    christianName: data.christianName,
    middleName: data.middleName,
    title: data.title,
    gender: data.gender,
    dateOfBirth: customeDateFormat(data.dateOfBirth),
    identityNumber: data.identityNumber,
    passportNumber: data.passportNumber,
    passportIssueCountry: data.passportIssueCountry,
    nationalityId: data.nationalityId,
    nationalityCode: data.nationalityCode,
    maritalStatus: data.maritalStatus,
    visaHolderIndicator: data.visaHolderIndicator,
    visaIssueDate: customeDateFormat(data.visaIssueDate),
    visaFirstLandingDate: customeDateFormat(data.visaFirstLandingDate),
    visaExpiryDate: customeDateFormat(data.visaExpiryDate),
    homeCountryId: data.homeCountryId,
    homeCountryCode: data.homeCountryCode,
    workEmailAddress: data.workEmailAddress,
    personalEmailAddress: data.personalEmailAddress,
    mobileNumber: data.mobileNumber,
    homePhoneNumber: data.homePhoneNumber,
    officePhoneNumber: data.officePhoneNumber,
    residentialAddress: data.residentialAddress,
    postalAddress: data.postalAddress,
    yearOfServiceOption: data.yearOfServiceOption,
    receivePayslipMethod: data.receivePayslipMethod,
    probationType: data.probationType,
    probationUnit: data.probationUnit,
    probationDate: data.probationDate,
    baseSalaryType: data.baseSalaryType,
    baseSalaryCurrencyId: data.baseSalaryCurrencyId,
    baseSalaryCurrencyCode: data.baseSalaryCurrencyCode,
    baseSalaryWage: data.baseSalaryWage,
    salaryProrationMethod: data.salaryProrationMethod,
    payGroupId: data.payGroupId,
    payGroupCode: data.payGroupCode,
    holdPayment: data.holdPayment,
    paymentCurrencyId: data.paymentCurrencyId,
    paymentCurrencyCode: data.paymentCurrencyCode,
    paymentMethodId: data.paymentMethodId,
    paymentMethodCode: data.paymentMethodCode,
    eligible13thMonthSalary: data?.eligible13thMonthSalary,
    eaoCalculationMethod: data.eaoCalculationMethod,
    eaoStatutoryHolidayPayStartDate: customeDateFormat(data.eaoStatutoryHolidayPayStartDate),
    hkEmployeeProfile: {
      id: data.hkEmployeeProfile_id,
      employeeProfileId: data.employeeProfileId,
      spouseName: data.spouseName,
      spouseIdentityNumber: data.spouseIdentityNumber,
      spousePassportNumber: data.spousePassportNumber,
      spousePassportIssueCountry: data.spousePassportIssueCountry,
      areaCode: data.areaCode,
      hongKongIRDTaxFilingIndicator: data.hongKongIRDTaxFilingIndicator,
      quartersProvidedIndicator: data.quartersProvidedIndicator,
      quartersEffectiveDate: data.quartersEffectiveDate,
      paidByOverseasCompanyIndicator: data.paidByOverseasCompanyIndicator,
      overseasCompanyName: data.overseasCompanyName,
      overseasCompanyAddress: data.overseasCompanyAddress,
      amountPaidByOverseasCompany: data.amountPaidByOverseasCompany,
      taxReturnRemarksForIR56B_IR56M: data.taxReturnRemarksForIR56B_IR56M,
      iR56EMonthlyAllowance: data.iR56EMonthlyAllowance,
      iR56EFluctuatingIncome: data.iR56EFluctuatingIncome,
      iR56GTaxBorneByEmployerIndicator: data.iR56GTaxBorneByEmployerIndicator,
      iR56GDepartureDate: data.iR56GDepartureDate,
      iR56GDepartureType: data.iR56GDepartureType,
      iR56GDepartureReason: data.iR56GDepartureReason,
      iR56GReturningIndicator: data.iR56GReturningIndicator,
      iR56GReturningDate: data.iR56GReturningDate,
      iR56GMoneyHeldIndicator: data.iR56GMoneyHeldIndicator,
      iR56GMoneyHeldAmount: data.iR56GMoneyHeldAmount,
      iR56GMoneyNotHeldReason: data.iR56GMoneyNotHeldReason,
      iR56GShareOptionGrantedIndicator: data.iR56GShareOptionGrantedIndicator,
      iR56GNoOfShareNotYetExercised: data.iR56GNoOfShareNotYetExercised,
      iR56GShareOptionGrantDate: data.iR56GShareOptionGrantDate,
      iR56GTaxClearanceIndicator: data.iR56GTaxClearanceIndicator,
      iR56MSumWithheldToSettleTaxDueByRecipientIndicator: data.iR56MSumWithheldToSettleTaxDueByRecipientIndicator,
      iR56MSumWithheldAmount: data.iR56MSumWithheldAmount,
      sunshineEPortalFolderID: data.sunshineEPortalFolderID,
      sunshineLastLoginDate: data?.sunshineLastLoginDate,
    },
  }
  console.log(dataList, 'dataList')

  return dataList
}

const renameDuplicateKeysWithParent:any = (obj:any, parentKey = null) => {
  // Base case: if obj is not an object, return it as is
  if (typeof obj !== 'object' || obj === null) {
    return obj
  }

  // If obj is an array, map over its elements
  if (Array.isArray(obj)) {
    return obj.map((item) => renameDuplicateKeysWithParent(item, parentKey))
  }

  // If obj is an object, check for duplicate keys
  return Object.entries(obj).reduce((result:any, [key, value]) => {
    // Check if the key already exists
    if (key === 'id' && parentKey) {
      const newKey = `${parentKey}_${key}`
      result[newKey] = renameDuplicateKeysWithParent(value, parentKey)
    } else {
      result[key] = renameDuplicateKeysWithParent(value, key)
    }
    return result
  }, {})
}
export const dataTransformationT = (data:any) => {
  const renamedData = renameDuplicateKeysWithParent(data)
  return renamedData
}

export const employeeStatus = [{ name: 'Active', value: 'Active' }, { name: 'Terminated', value: 'Terminated' }, { name: 'Non-Payroll Employee', value: 'Non-Payroll Employee' }]
export const payrollIndicator = [{ name: 'On Payroll', value: 'On Payroll' }, { name: 'No Payroll', value: 'No Payroll' }, { name: 'Resume Payroll', value: 'Resume Payroll' }]
export const employeePaySlip = [{ name: 'Hardcopy', value: 'Hardcopy' }, { name: 'Email', value: 'Email' }, { name: 'ESS Portal', value: '4ESS Portal' }]
export const probationType = [{ name: 'Month', value: 'Month' }, { name: 'Day', value: 'Day' }]
export const emplyeeTaxFillingIndicator = [{ name: 'Yes (IR56B)', value: 'Yes (IR56B)' }, { name: 'No', value: 'No' }, { name: 'Yes (IR56M)', value: 'Yes (IR56M)' }]
export const employeeQuarterIndicater = [{ name: ' Yes', value: ' True' }, { name: 'No', value: 'False' }]
export const paidByOverseasCompanyIndicator = [{ name: 'Yes', value: 'True' }, { name: 'No', value: 'False' }]
export const iR56GDepartureType = [{ name: ' Emigration', value: ' Emigration' }, { name: 'Return to Homeland', value: 'Return to Homeland' }, { name: ' Secondment', value: ' Secondment' }, { name: 'Others', value: 'Others' }]
export const IR56GReturningIndicator = [{ name: 'Yes', value: 'True' }, { name: 'No', value: 'False' }]
export const IR56GMoneyHeldIndicator = [{ name: ' Yes', value: ' Yes' }, { name: 'No', value: 'No' }]
export const IR56GShareOptionGrantedIndicator = [{ name: ' Yes', value: 'True' }, { name: 'No', value: 'False' }]
export const IR56GTaxClearanceIndicator = [{ name: 'Emigration', value: '0' }, { name: 'Return to Homeland', value: '1' }, { name: 'Secondment', value: '2' }, { name: 'Others', value: '3' }]
export const IR56MSumWithheldToSettleTaxDueByRecipientIndicator = [{ name: ' Yes', value: 'True' }, { name: 'No', value: 'False' }]
export const employeeAreaCode = [{ name: 'H-Hong Kong', value: 'H-Hong Kong' }, { name: 'K-Kowloon', value: 'K-Kowloon' }, { name: 'N-New Territories', value: 'N-New Territories' }, { name: 'F-Others', value: 'F-Others' }]
export const title = [
  { name: 'Mr', value: 'Mr' },
  { name: 'Mrs', value: 'Mrs' },
  { name: 'Miss', value: 'Miss' },
  { name: 'Mis', value: 'Mis' },
  { name: 'Dr', value: 'Dr' },
]

export const gender = [
  { name: 'Male', value: 'Male' },
  { name: 'Female', value: 'Femal' },
]

export const maritalStatus = [
  { name: 'Single', value: 'Single' },
  { name: 'Widowed', value: 'Widowed' },
  { name: 'Divorced', value: 'Divorced' },
  { name: 'Living Apart', value: 'Living Apart' },
  { name: 'Married ', value: 'Married ' },
]

const baseSalaryType = [{ name: 'Monthly', value: 'Monthly' }, { name: 'Daily', value: 'Daily' }, { name: 'Hourly', value: 'Hourly' }]
export const paymentHold = [{ name: 'Yes', value: 'Yes' }, { name: 'No', value: 'No' }]
export const salaryProrationMethod = [{ name: 'Actual', value: 'Actual' }, { name: 'Pro-Rata', value: 'Pro-Rata' }]
export const eaoCalculationMethod = [{ name: ' Not Applicable [HRMnet value is "N"]', value: ' Not Applicable [HRMnet value is "N"]' },
  { name: 'Yes, applicable with positive/negative EAO difference [HRMnet value is "Y"]', value: 'Yes, applicable with positive/negative EAO difference [HRMnet value is "Y"]' },
  { name: 'Yes, applicable with only positive EAO difference [HRMnet value is "C"]', value: 'Yes, applicable with only positive EAO difference [HRMnet value is "C"]' }]
export const eligible13thMonthSalary = [{ name: 'Yes', value: 'Yes' }, { name: 'No', value: 'No' }]
export const VisaHolderIndicator = [{ name: 'Yes', value: 'Yes' }, { name: 'No', value: 'No' }]

const HOLIDAY_PAYMENT_OPTION = [
  { name: 'ent_work_calendar_holiday_payment_opt_1', value: 'Paid for Statutory and Public Holidays' },
  { name: 'ent_work_calendar_holiday_payment_opt_2', value: 'Paid for only Statutory Holidays' },
]

const SALARY_PRORATION_METHOD = [
  { name: 'ent_work_calendar_salary_proration_method_1', value: 'Basic Salary / Calendar Day' },
  { name: 'ent_work_calendar_salary_proration_method_2', value: 'Basic Salary / Working Day' },
]

const CAW_CALCULATION_METHOD = [
  { name: 'ent_work_calendar_salary_proration_method_1', value: 'Basic Salary / Calendar Day' },
  { name: 'ent_work_calendar_salary_proration_method_2', value: 'Basic Salary / Working Day' },
]

const FIXED_WORKING_SCHEDULE = [
  { name: 'ent_work_calendar_working_day_full_day', value: 'Work Day - Full Day' },
  { name: 'ent_work_calendar_working_day_half_day', value: 'Work Day - Half Day' },
  { name: 'ent_work_calendar_working_day_non_working_day', value: 'Off Day' },
]
