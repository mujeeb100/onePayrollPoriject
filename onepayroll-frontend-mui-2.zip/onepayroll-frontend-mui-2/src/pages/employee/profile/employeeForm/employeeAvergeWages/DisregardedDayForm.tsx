import { Box, Grid } from '@mui/material'
import { useAverageWageDisregardedDayUpdateMutation, useLazyGetEmployeeAverageWageByIdQuery } from 'api/employeeServices'
import { RighCaretBlue } from 'assets/svg-images/SvgComponents'
import OPRButton from 'components/atoms/button/OPRButton'
import OPRFormHeaderLabel from 'components/molecules/OPRFormHeaderLabel/OPRFormHeaderLabel'
import OPRInputControl from 'components/molecules/OPRInputControl'
import OPRResponsiveGrid from 'components/molecules/OPRResponsiveGrid'
import OPRAlertControl from 'components/organism/OPRAlertControl'
import { employeeDisregardedDayValidationSchema } from 'constants/validate'
import { useEditable } from 'hooks/useEdit'
import useForm from 'hooks/useForm'
import { useEffect } from 'react'
import { routes } from 'routes/routes'

function DisregardedDayForm({
  setIsDisregardedDay, isDisregardedDay, selectedId, empName,
}:any) {
  const { isEditable, setEditable } = useEditable()
  const {
    values,
    setValues,
    errors,
    handleChange,
    setErrors,
    handleFormSubmit,
    handleOnChange,
  } = useForm(employeeDisregardedDayValidationSchema)
  const [updateAverageWageById, {
    data: updatedAverageWageByIdResponse,
    error: updatedAverageWageByIdError,
    isLoading: updatedAverageWageByIdLoading,
    isSuccess: updatedAverageWageByIdSuccess,
    isError: updatedAverageWageByIdIsError,
  }] = useLazyGetEmployeeAverageWageByIdQuery()
  const [updateDisregardedDay, {
    data: uupdatedClientGroupDataResponse,
    error: updatedDisregardedDayError,
    isLoading: updatedDisregardedDayLoading,
    isSuccess: updatedDisregardedDaySuccess,
    isError: updatedDisregardedDayIsError,
  }] = useAverageWageDisregardedDayUpdateMutation()

  useEffect(() => {
    console.log('selectedIdselectedId', selectedId)

    if (selectedId) {
      updateAverageWageById(selectedId)
      // updateAverageWageById('49fbdbef-2b58-41fd-a7dc-059de7383adc')
    }
  }, [])
  useEffect(() => {
    if (updatedAverageWageByIdSuccess) {
      setValues(updatedAverageWageByIdResponse.data)
    }
  }, [updatedAverageWageByIdSuccess])
  useEffect(() => {
    if (updatedDisregardedDaySuccess) {
      // setIsDisregardedDay(false)
    }
  }, [updatedDisregardedDaySuccess])
  const handleSubmit = () => {
    const data = {
      id: selectedId,
      disregardedDayOthers: parseInt(values.disregardedDayOthers, 10),
      disregardedDays: parseInt(values.disregardedDays, 10),
      coveredDay: values.coveredDay,
      disregardedDaySickLeave: values.disregardedDaySickLeave,
      disregardedDayMaternityLeave: values.disregardedDayMaternityLeave,
      disregardedDayNoPayLeave: values.disregardedDayNoPayLeave,
    }
    if (isEditable) {
      updateDisregardedDay(data)
    } else {
      setEditable(true)
    }
  }

  return (
    <Box>
      {/* <CustomDialog
        CustomStyles={{ borderRadius: '16px' }}
        isOpen={updatedDisregardedDayLoading || updatedAverageWageByIdLoading}
        type="loader"
      >
        <CustomLoader text="Processing request" />
      </CustomDialog> */}
      {/* <OPRAlertControl
        callBack={(type) => {
          // if (type === 'success') {
          //   navigate(-1)
          // }
        }}
        error={updatedDisregardedDayError || updatedAverageWageByIdError}
        handleEditable={setEditable}
        handleSetValue={setValues}
        handleSubmit={handleSubmit}
        isError={updatedDisregardedDayIsError || updatedAverageWageByIdError}
        isLoading={updatedDisregardedDayLoading || updatedAverageWageByIdIsError}
        isSuccess={updatedDisregardedDaySuccess}
        name={values?.EmployeeBankAccountName}
        // previousUrl={routes.employeeProfile}
        title="Disregarded"
        type="Update"

      /> */}

      <OPRAlertControl
        isCustom
        isCustomError
        callBack={() => {
          // handleClose()
          // setValues({})
          // setSteps(0)
          setIsDisregardedDay(false)
        }}
        customBack={() => {
          // handleOpen()

        }}
        customMessage={`${empName} has been updated.`}
        customTitle="Employee profile updated"
        error={updatedDisregardedDayError || updatedAverageWageByIdError}
        handleSetValue={setValues}
        handleSubmit={handleSubmit}
        isError={updatedDisregardedDayIsError || updatedAverageWageByIdError}
        isLoading={updatedDisregardedDayLoading}
        isSuccess={updatedDisregardedDaySuccess}
        name={values?.EmployeeBankAccountName}
        previousUrl={routes.employeeProfile}
        title="Employee profile"
        type="Updated"
      />

      <OPRFormHeaderLabel title={isEditable ? 'Confirm details' : 'Edit disregarded day'} />
      <Box style={{ marginTop: 10 }}>
        <OPRResponsiveGrid>
          <Grid item md={12} sm={1} xs={1}>
            <OPRInputControl
              isEditable
              isRequired
              error={errors?.disregardedDaySickLeave}
              label="Disregarded day - Sick leave"
              name="disregardedDaySickLeave"
              value={values?.disregardedDaySickLeave}
              onChange={handleChange}
            />
          </Grid>
          <Grid item md={12} sm={1} xs={1}>
            <OPRInputControl
              isEditable
              isRequired
              error={errors?.disregardedDayMaternityLeave}
              label="Disregarded day - Maternity leave"
              name="disregardedDayMaternityLeave"
              value={values?.disregardedDayMaternityLeave}
              onChange={handleChange}
            />
          </Grid>
          <Grid item md={12} sm={1} xs={1}>
            <OPRInputControl
              isEditable
              isRequired
              error={errors?.disregardedDayNoPayLeave}
              label="Disregarded day - Paternity leave"
              name="disregardedDayNoPayLeave"
              value={values?.disregardedDayNoPayLeave}
              onChange={handleChange}
            />
          </Grid>
          <Grid item md={12} sm={1} xs={1}>
            <OPRInputControl
              isRequired
              error={errors?.disregardedDayOthers}
              isEditable={isEditable}
              label="Disregarded day - Others"
              name="disregardedDayOthers"
              optionalText="Optional"
              value={values?.disregardedDayOthers}
              onChange={handleChange}
            />
          </Grid>
          <Grid item md={12} sm={1} xs={1}>
            <OPRInputControl
              isRequired
              error={errors?.disregardedDays}
              isEditable={isEditable}
              label="Disregarded days"
              name="disregardedDays"
              optionalText="Optional"
              value={values?.disregardedDays}
              onChange={handleChange}
            />
          </Grid>

        </OPRResponsiveGrid>
        <Box sx={{
          display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: 5,
        }}
        >
          <OPRButton color="info" variant="text" onClick={() => setIsDisregardedDay(false)}>
            Cancel
          </OPRButton>
          <Box>
            {
              isEditable ? (
                <OPRButton
                  style={{ marginLeft: 'auto' }}
                  variant="text"
                  onClick={() => {
                    setEditable(false)
                  }}
                >
                  <RighCaretBlue />
                  Back
                </OPRButton>
              ) : <div />
            }
            <OPRButton
              color="info"
              variant="text"
              onClick={(e:any) => {
                //   myRef?.current?.handleOnSubmit(e)
                handleSubmit()
              }}
            >
              Confirm
            </OPRButton>
          </Box>

        </Box>
      </Box>
    </Box>
  )
}

export default DisregardedDayForm
