import { Box, Grid } from '@mui/material'
import { ReactComponent as Calendar } from 'assets/svg-icons/Calendar.svg'
import OPRButton from 'components/atoms/button/OPRButton'
import OPRDatePickerControl from 'components/molecules/OPRDatePickerControl/OPRDatePickerControl'
import OPRFormHeaderLabel from 'components/molecules/OPRFormHeaderLabel/OPRFormHeaderLabel'
import OPRResponsiveGrid from 'components/molecules/OPRResponsiveGrid'
import { employeeDisregardedDayValidationSchema } from 'constants/validate'
import { useEditable } from 'hooks/useEdit'
import useForm from 'hooks/useForm'
import { useState } from 'react'

function Recalculation({ close, isModal, handleRecalculation }:any) {
  const { isEditable, setEditable } = useEditable()
  const [conformation, setConfirmation] = useState(false)
  const {
    values,
    setValues,
    errors,
    handleChange,
    setErrors,
    handleFormSubmit,
    handleOnChange,
  } = useForm(employeeDisregardedDayValidationSchema)

  return (
    <Box>
      {/* {
            conformation && ()
        } */}
      <OPRFormHeaderLabel title={conformation ? 'Are you sure you want to recalculate average wages?' : 'Recalculate average wages'} />
      <Box style={{ marginTop: 10 }}>
        {
          conformation && (
            <div style={{
              width: '100%', height: '100%', padding: 12, background: '#FFF7EB', borderRadius: 4, justifyContent: 'flex-start', alignItems: 'flex-start', gap: 12, display: 'inline-flex',
            }}
            >
              <div style={{
                paddingTop: 4, flexDirection: 'column', justifyContent: 'flex-start', alignItems: 'center', display: 'inline-flex',
              }}
              >
                <div style={{ width: 16, height: 16, position: 'relative' }}>
                  <Calendar />
                </div>
              </div>
              <div style={{
                flex: '1 1 0', flexDirection: 'column', justifyContent: 'flex-start', alignItems: 'flex-start', display: 'inline-flex',
              }}
              >
                <div style={{
                  alignSelf: 'stretch', color: '#3B3839', fontSize: 16, fontFamily: 'Lato', fontWeight: '400', wordWrap: 'break-word',
                }}
                >
                  If average wages is recalculated, you won't be able to revert it.
                </div>
              </div>
            </div>
          )
        }
        {
          !conformation && (
            <OPRResponsiveGrid>
              <Grid item md={2} sm={1} xs={1}>
                <OPRDatePickerControl
                  isRequired
                  error={errors?.startDate}
                  isEditable={isEditable}
                  label="From"
                  name="startDate"
                  value={values?.startDate || null}
                  onChange={(date:any) => {
                    handleOnChange('startDate', new Date(date))
                  }}
                />
              </Grid>
              <Grid item md={2} sm={1} xs={1}>
                <OPRDatePickerControl
                  isRequired
                  error={errors?.endDate}
                  isEditable={isEditable}
                  label="To"
                  name="endDate"
                  value={values?.endDate || null}
                  onChange={(date:any) => {
                    handleOnChange('endDate', new Date(date))
                  }}
                />
              </Grid>

            </OPRResponsiveGrid>
          )
        }

        <Box sx={{
          display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: 5,
        }}
        >
          <OPRButton
            color="info"
            variant="text"
            onClick={() => {
              close(false)
            }}
          >
            Cancel
          </OPRButton>
          <OPRButton
            color="primary"
            variant="contained"
            onClick={(e:any) => {
              if (conformation) {
                handleRecalculation(values)
                // close(false)
                return
              }
              setConfirmation(true)
            //   myRef?.current?.handleOnSubmit(e)
            //   updateDisregardedDay({ ...values, id: selectedId })
            }}
          >
            Recalculate
          </OPRButton>
        </Box>
      </Box>
    </Box>
  )
}

export default Recalculation
