import {
  Box,
} from '@mui/material'
import { useEmployeeAverageWageDeleteMutation, useGetAllEmployeeAverageWageQuery, usePayRollAverageWageUpdateMutation } from 'api/employeeServices'
// import { ReactComponent as Reset } from 'assets/svg-icons/Reset.svg'
import { ReactComponent as Reset } from 'assets/svg-icons/Reset.svg'
import OPRButton from 'components/atoms/button/OPRButton'
import OPRLabel from 'components/atoms/label/OPRLabel'
import CustomLoader from 'components/atoms/loader/OPRLoader'
import { CustomDialog } from 'components/atoms/modal/OPRModal'
import OPRPagination from 'components/atoms/pagination/OPRPagination'
import OPRTable from 'components/atoms/table/OPRTable'
import { employeeAverageWageColumn } from 'components/atoms/table/OPRTableConstant'
import OPRAlertControl from 'components/organism/OPRAlertControl'
import React, { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import {
  generateFilterUrl,
} from 'utils'

import AverageWagesEmployeeForm from './AverageWagesEmployeeForm'
import DisregardedDayForm from './DisregardedDayForm'
import Recalculation from './Recalculation'

function AverageWagesEmployeeList({
  id, ProfileId, setCount, empName,
}:any) {
  const [selelctedUser, setSelelctedUser]:any = useState({
    data: {},
    isDelete: false,
    name: '',
  })
  console.log('iddddddddddddddddd', id)

  const [isDisregardedDay, setIsDisregardedDay] = useState(false)
  const [isSelectedRow, setIsSelectedRow] = useState(false)
  const [selectedId, setSelectedId]:any = useState(undefined)
  const [isRecalculation, SetIsRecalculation] = useState(false)
  const navigate: any = useNavigate()
  const [filterData, setFilterData]:any = useState({
    pageNumber: 1,
    pageSize: 20,
    totalItems: 0,
    orderByAsc: false,
    sortBy: '',
    SearchText: '',
    employeeProfileId: id,
  })
  const {
    data: allPosts,
    error: createAllPostsBankAccountError,
    isLoading: isLoadingAllPosts,
    isSuccess: isSuccessAllPosts,
    isError: isErrorAllPosts,
    error: errorAllPosts,
  } = useGetAllEmployeeAverageWageQuery(generateFilterUrl(filterData))
  useEffect(() => {
    setCount(JSON.parse(JSON.stringify(allPosts || [])).totalItems)
  }, [isSuccessAllPosts])
  // console.log(useEmployeeAverageWageChangeStatusMutation, 'useClientGroupEntitesChangeStatusMutationuseClientGroupEntitesChangeStatusMutation')

  const [deleteEmployeeAverageWageById,
    {
      data: deleteEmployeeAverageWageResponse,
      error: deleteEmployeeAverageWageError,
      isLoading: deleteEmployeeAverageWageLoading,
      isSuccess: deleteEmployeeAverageWageSuccess,
      isError: deleteEmployeeAverageWageIsError,
    }] = useEmployeeAverageWageDeleteMutation()

  const [createPayRollAverageWage, {
    data: createdPayRollAverageWageData,
    error: createdPayRollAverageWageError,
    isLoading: createdPayRollAverageWageLoading,
    isSuccess: createdPayRollAverageWageSuccess,
    isError: createdPayRollAverageWageIsError,
  }] = usePayRollAverageWageUpdateMutation()

  const sorting = (
    event: React.MouseEvent<unknown>,
    property: keyof any,
  ) => {
    const isAsc = filterData.sortBy === property && filterData.orderByAsc === true
    setFilterData({ ...filterData, orderByAsc: !isAsc, sortBy: property })
    // setOrder(isAsc ? 'desc' : 'asc')
    // setOrderBy(property)
  }

  useEffect(() => {
    if (createdPayRollAverageWageSuccess) {
      SetIsRecalculation(false)
    }
  }, [createdPayRollAverageWageSuccess])

  useEffect(() => {
    setFilterData({ ...filterData, totalItems: allPosts?.totalItems ? allPosts?.totalItems : 0 })
  }, [allPosts?.pageNumber, filterData.sortBy, filterData.orderByAsc, allPosts?.totalItems])

  const onSearch = (e: any, data: any) => {
    setFilterData({ ...filterData, ...data })
  }
  const handlePagination = (pageNumber: number, pageSize: number) => {
    setFilterData({ ...filterData, pageNumber })
  }
  const viewAcoount = (data: any, type:string) => {
    // const id = JSON.stringify(data)
    if (type === 'Edit disregarded day') {
      setSelelctedUser({ data, isDelete: false, name: '' })
      setIsDisregardedDay(true)
    }
  }

  const handleView = (data: any) => {
    setSelectedId(data.employeeCode)
    setIsSelectedRow(true)
    // alert('fdhdfh')
  }

  useEffect(() => {
    if (createdPayRollAverageWageData) {
      SetIsRecalculation(false)
    }
  }, [])

  const handleRecalculation = (data: any) => {
    const newData = {
      startDate: data.startDate,
      endDate: data.endDate,
      employeeProfileIds: [
        ProfileId,
      ],
    }
    createPayRollAverageWage(newData)
  }

  const deleteEntities = (data:any) => {
    deleteEmployeeAverageWageById(`Id=${data.id}`)
  }
  return (
    <Box sx={{ display: 'flex', flexDirection: 'column' }}>

      <CustomDialog
        CustomStyles={{ borderRadius: '16px' }}
        isOpen={isSelectedRow}
        type="loader"
      >
        <AverageWagesEmployeeForm close={setIsSelectedRow} empName={empName} selectedId={selectedId} />
      </CustomDialog>
      <CustomDialog
        CustomStyles={{ borderRadius: '16px' }}
        isOpen={isDisregardedDay}
        type="loader"
      >
        <DisregardedDayForm
          empName={empName}
          isDisregardedDay={isDisregardedDay}
          selectedId={selelctedUser.data.id}
          setIsDisregardedDay={setIsDisregardedDay}
        />
      </CustomDialog>
      <CustomDialog
        CustomStyles={{ borderRadius: '16px' }}
        isOpen={isRecalculation}
        type="loader"
      >
        <Recalculation close={SetIsRecalculation} handleRecalculation={handleRecalculation} isModal={isRecalculation} />
      </CustomDialog>
      <Box sx={{ display: 'flex', justifyContent: 'flex-end', alignItems: 'center' }}>
        <OPRButton
          handleClick={() => {
            SetIsRecalculation(true)
          }}
          variant="text"
        >
          <Reset />
          {' '}
          Recalculate average wages
        </OPRButton>
      </Box>

      <CustomDialog
        CustomStyles={{ borderRadius: '16px' }}
        isOpen={isLoadingAllPosts || createdPayRollAverageWageLoading}
        type="loader"
      >
        <CustomLoader text="Processing request" />
      </CustomDialog>
      {/* <OPRDeleteControl
        deleteCallBack={deleteEntities}
        selelctedUser={selelctedUser}
        setSelelctedUser={setSelelctedUser}
        title="Client Group Entities"
      /> */}
      {/* <OPRErrorAlertControl
        error={deleteEmployeeAverageWageError || createdPayRollAverageWageError}
        header="Failed to recalculated average wages"
        isBackButton={false}
        isError={deleteEmployeeAverageWageIsError || createdPayRollAverageWageIsError}
        isSuccess={createdPayRollAverageWageSuccess}
        isTry={false}
        name=""
      /> */}
      <OPRAlertControl
        isCustom
        isCustomError
        callBack={() => {
          // handleClose()
          // setValues({})
          // setSteps(0)
          // setIsDisregardedDay(false)
        }}
        customBack={() => {
          // handleOpen()

        }}
        customMessage="Average wages has been recalculated."
        customTitle="Average wages recalculated"
        error={createdPayRollAverageWageError}
        handleSubmit={() => {
          console.log('handle submit')
        }}
        isError={createdPayRollAverageWageIsError}
        isLoading={createdPayRollAverageWageLoading}
        isSuccess={createdPayRollAverageWageSuccess}
        name="1 Room Hotel"
        // previousUrl={routes.employeeProfile}
        title="Employee profile"
        type="added to Alex Johnson."
      />
      <OPRLabel CustomStyles={{ marginBottom: 5 }} variant="body2">
        {JSON.parse(JSON.stringify(allPosts?.records || [])).length}
        {' '}
        items
      </OPRLabel>
      <OPRTable
        cols={employeeAverageWageColumn(viewAcoount)}
        data={JSON.parse(JSON.stringify(allPosts?.records || []))}
        handleEdit={viewAcoount}
        isLoader={isLoadingAllPosts}
        newOptions={[]}
        orderBy={filterData?.orderByAsc}
        rowClickHandler={handleView}
        rowNumber={0}
        sortBy={filterData?.sortBy}
        title="title"
        onRequestSort={sorting}
      />
      {
        filterData?.totalItems < 20 ? null : (
          <Box sx={{ display: 'flex', justifyContent: 'center', mt: 2 }}>
            <OPRPagination
              limit={filterData?.pageSize}
              page={filterData?.pageNumber}
              setPage={handlePagination}
              total={filterData?.totalItems}
            />
          </Box>
        )
      }
    </Box>
  )
}

export default AverageWagesEmployeeList
