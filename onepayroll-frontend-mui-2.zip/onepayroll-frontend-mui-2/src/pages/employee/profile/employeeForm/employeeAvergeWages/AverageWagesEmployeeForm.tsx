import { Box, Grid } from '@mui/material'
import { useAverageWageDisregardedDayUpdateMutation, useLazyGetEmployeeAverageWageByIdQuery } from 'api/employeeServices'
import OPRButton from 'components/atoms/button/OPRButton'
import CustomLoader from 'components/atoms/loader/OPRLoader'
import { CustomDialog } from 'components/atoms/modal/OPRModal'
import OPRErrorAlertControl from 'components/molecules/OPRAlertControl/OPRErrorControl'
import OPRFormHeaderLabel from 'components/molecules/OPRFormHeaderLabel/OPRFormHeaderLabel'
import OPRInputControl from 'components/molecules/OPRInputControl'
import OPRResponsiveGrid from 'components/molecules/OPRResponsiveGrid'
import { employeeDisregardedDayValidationSchema } from 'constants/validate'
import { useEditable } from 'hooks/useEdit'
import useForm from 'hooks/useForm'
import React, { useEffect } from 'react'

function AverageWagesEmployeeForm({ selectedId, close }:any) {
  const { isEditable, setEditable } = useEditable()
  const {
    values,
    setValues,
    errors,
    handleChange,
    setErrors,
    handleFormSubmit,
    handleOnChange,
  } = useForm(employeeDisregardedDayValidationSchema)
  const [updateAverageWageById, {
    data: updatedAverageWageByIdResponse,
    error: updatedAverageWageByIdError,
    isLoading: updatedAverageWageByIdLoading,
    isSuccess: updatedAverageWageByIdSuccess,
    isError: updatedAverageWageByIdIsError,
  }] = useLazyGetEmployeeAverageWageByIdQuery()
  const [updateDisregardedDay, {
    data: uupdatedClientGroupDataResponse,
    error: updatedDisregardedDayError,
    isLoading: updatedDisregardedDayLoading,
    isSuccess: updatedDisregardedDaySuccess,
    isError: updatedDisregardedDayIsError,
  }] = useAverageWageDisregardedDayUpdateMutation()
  console.log(updateDisregardedDay)

  useEffect(() => {
    if (selectedId) {
      updateAverageWageById(selectedId)
      // updateAverageWageById('49fbdbef-2b58-41fd-a7dc-059de7383adc')
    }
  }, [])
  useEffect(() => {
    if (updatedAverageWageByIdSuccess) {
      setValues(updatedAverageWageByIdResponse.data)
    }
  }, [updatedAverageWageByIdSuccess])

  return (
    <Box>
      <CustomDialog
        CustomStyles={{ borderRadius: '16px' }}
        isOpen={updatedDisregardedDayLoading}
        type="loader"
      >
        <CustomLoader text="Processing request" />
      </CustomDialog>
      <OPRErrorAlertControl
        error={uupdatedClientGroupDataResponse}
        header="Failed to Delete"
        isBackButton={false}
        isError={updatedDisregardedDayIsError}
        isTry={false}
        name="disregarded day"
      />
      <OPRFormHeaderLabel title="Average wages" />
      <Box style={{ marginTop: 10 }}>
        <OPRResponsiveGrid>
          <Grid item md={2} sm={1} xs={1}>
            <OPRInputControl
              isEditable
              isRequired
              error={errors?.year}
              label="Pay cycle year"
              name="year"
              value={values?.year}
              onChange={handleChange}
            />
          </Grid>
          <Grid item md={2} sm={1} xs={1}>
            <OPRInputControl
              isEditable
              isRequired
              error={errors?.month}
              label="Pay cycle month"
              name="month"
              value={values?.month}
              onChange={handleChange}
            />
          </Grid>
          <Grid item md={12} sm={1} xs={1}>
            <OPRInputControl
              isEditable
              isRequired
              error={errors?.status}
              label="Status"
              name="status"
              value={values?.status}
              onChange={handleChange}
            />
          </Grid>
          <Grid item md={2} sm={1} xs={1}>
            <OPRInputControl
              isEditable
              isRequired
              error={errors?.regardedWagesStartDate}
              label="Regarded wages start date"
              name="regardedWagesStartDate"
              value={values?.regardedWagesStartDate}
              onChange={handleChange}
            />
          </Grid>
          <Grid item md={2} sm={1} xs={1}>
            <OPRInputControl
              isEditable
              isRequired
              error={errors?.regardedWagesEndDate}
              label="Regarded wages end date"
              name="regardedWagesEndDate"
              value={values?.regardedWagesEndDate}
              onChange={handleChange}
            />
          </Grid>
          <Grid item md={12} sm={1} xs={1}>
            <OPRInputControl
              isEditable
              isRequired
              error={errors?.currency}
              label="Currency"
              name="currency"
              value={values?.currency}
              onChange={handleChange}
            />
          </Grid>
          <Grid item md={2} sm={1} xs={1}>
            <OPRInputControl
              isEditable
              isRequired
              error={errors?.lastMonthRegardedWages}
              label="Last month regarded wages"
              name="lastMonthRegardedWages"
              value={values?.lastMonthRegardedWages}
              onChange={handleChange}
            />
          </Grid>
          <Grid item md={2} sm={1} xs={1}>
            <OPRInputControl
              isEditable
              isRequired
              error={errors?.last12MonthRegardedWages}
              label="Last 12 month regarded wages"
              name="last12MonthRegardedWages"
              value={values?.last12MonthRegardedWages}
              onChange={handleChange}
            />
          </Grid>
          <Grid item md={2} sm={1} xs={1}>
            <OPRInputControl
              isEditable
              isRequired
              error={errors?.averageDailyWages}
              label="Average daily wages (ADW)"
              name="averageDailyWages"
              value={values?.averageDailyWages}
              onChange={handleChange}
            />
          </Grid>
          <Grid item md={2} sm={1} xs={1}>
            <OPRInputControl
              isEditable
              isRequired
              error={errors?.averageMonthlyWages}
              label="Average monthly wages (AMW"
              name="averageMonthlyWages"
              value={values?.averageMonthlyWages}
              onChange={handleChange}
            />
          </Grid>
          <Grid item md={12} sm={1} xs={1}>
            <OPRInputControl
              isEditable
              isRequired
              error={errors?.dailySalaryPerCompanyPolicy}
              label="Daily salary per company policy (CAW)"
              name="dailySalaryPerCompanyPolicy"
              value={values?.dailySalaryPerCompanyPolicy}
              onChange={handleChange}
            />
          </Grid>
          <Grid item md={2} sm={1} xs={1}>
            <OPRInputControl
              isEditable
              isRequired
              error={errors?.coveredDay}
              label="Covered days"
              name="coveredDay"
              value={values?.coveredDay}
              onChange={handleChange}
            />
          </Grid>
          <Grid item md={2} sm={1} xs={1}>
            <OPRInputControl
              isEditable
              isRequired
              error={errors?.last12MonthCoveredDay}
              label="Last 12 month covered day"
              name="last12MonthCoveredDay"
              value={values?.last12MonthCoveredDay}
              onChange={handleChange}
            />
          </Grid>
          <Grid item md={2} sm={1} xs={1}>
            <OPRInputControl
              isEditable
              isRequired
              error={errors?.last12MonthNoOT}
              label="Last 12 month no OT"
              name="last12MonthNoOT"
              value={values?.last12MonthNoOT}
              onChange={handleChange}
            />
          </Grid>
          <Grid item md={2} sm={1} xs={1}>
            <OPRInputControl
              isEditable
              isRequired
              error={errors?.last12MonthOT}
              label="Last 12 month OT"
              name="last12MonthOT"
              value={values?.last12MonthOT}
              onChange={handleChange}
            />
          </Grid>
          <Grid item md={12} sm={1} xs={1}>
            <OPRInputControl
              isEditable
              isRequired
              error={errors?.disregardedDays}
              label="Disregarded day"
              name="disregardedDays"
              value={values?.disregardedDays}
              onChange={handleChange}
            />
          </Grid>
          <Grid item md={2} sm={1} xs={1}>
            <OPRInputControl
              isEditable
              isRequired
              error={errors?.disregardedDaySickLeave}
              label="Disregarded day - Sick leave"
              name="disregardedDaySickLeave"
              value={values?.disregardedDaySickLeave}
              onChange={handleChange}
            />
          </Grid>
          <Grid item md={2} sm={1} xs={1}>
            <OPRInputControl
              isEditable
              isRequired
              error={errors?.disregardedDayMaternityLeave}
              label="Disregarded day - Maternity leave"
              name="disregardedDayMaternityLeave"
              value={values?.disregardedDayMaternityLeave}
              onChange={handleChange}
            />
          </Grid>
          <Grid item md={2} sm={1} xs={1}>
            <OPRInputControl
              isEditable
              isRequired
              error={errors?.disregardedDayNoPayLeave}
              label="Disregarded day - Paternity leave"
              name="disregardedDayNoPayLeave"
              value={values?.disregardedDayNoPayLeave}
              onChange={handleChange}
            />
          </Grid>
          <Grid item md={2} sm={1} xs={1}>
            <OPRInputControl
              isEditable
              isRequired
              error={errors?.disregardedDayOthers}
              label="Disregarded day - Others"
              name="disregardedDayOthers"
              value={values?.disregardedDayOthers}
              onChange={handleChange}
            />
          </Grid>

        </OPRResponsiveGrid>
        <Box sx={{
          display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: 5,
        }}
        >
          <OPRButton color="info" variant="text" onClick={() => close(false)}>
            Cancel
          </OPRButton>
          <OPRButton
            color="info"
            variant="text"
            onClick={(e:any) => {
            //   myRef?.current?.handleOnSubmit(e)
              // updateDisregardedDay({ ...values, id: selectedId })
            }}
          >
            Edit disregarded day
          </OPRButton>
        </Box>
      </Box>
    </Box>
  )
}

export default AverageWagesEmployeeForm
