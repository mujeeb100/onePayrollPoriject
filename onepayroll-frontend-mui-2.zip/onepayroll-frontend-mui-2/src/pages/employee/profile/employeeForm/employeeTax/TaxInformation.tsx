import { Box, Grid } from '@mui/material'
import { useGetAllIRDQuery } from 'api/entityServices'
import OPRLabel from 'components/atoms/label/OPRLabel'
import OPRDatePickerControl from 'components/molecules/OPRDatePickerControl/OPRDatePickerControl'
import OPRInputControl from 'components/molecules/OPRInputControl'
import OPRResponsiveGrid from 'components/molecules/OPRResponsiveGrid'
import OPRSelectorControl from 'components/molecules/OPRSelectorControl/OPRSelectorControl'
import { forwardRef } from 'react'
import { generateFilterUrl } from 'utils'

import { employeeQuarterIndicater, emplyeeTaxFillingIndicator, paidByOverseasCompanyIndicator } from '../../dataTransfer'

interface MessageProps {
    text?: string;
    important?: boolean;
  }

const TaxInformation = forwardRef(({
  isEditable,
  setEditable,
  id,
  values,
  errors,
  handleChange,
  handleOnChange,
  viewUrl,
}:any, ref) => {
  const {
    data: allPosts,
    isLoading: isLoadingAllPosts,
    isSuccess: isSuccessAllPosts,
    isError: isErrorAllPosts,
    error: errorAllPosts,
    refetch: refetchAllPosts,
  } = useGetAllIRDQuery(generateFilterUrl({
    pageSize: 1000,
  }))

  return (
    <Box>

      <OPRLabel variant="h1">Tax Information</OPRLabel>
      <OPRResponsiveGrid>
        <Grid item md={2} sm={1} xs={1}>
          {/* <OPRInputControl
            error={errors?.hongKongIRDTaxFilingIndicator}
            isEditable={isEditable}
            label="emp_profile_hongkong_ird_tax_filing_indicator"
            name="hongKongIRDTaxFilingIndicator"
            value={values?.hongKongIRDTaxFilingIndicator}
            onChange={handleChange}
          /> */}
          <OPRSelectorControl
            error={errors?.hongKongIRDTaxFilingIndicator}
            isEditable={isEditable}
            keyName="name"
            label="Hong Kong IRD tax filling indicator"
            name="name"
            options={emplyeeTaxFillingIndicator}
            value={emplyeeTaxFillingIndicator?.find((o:any) => o?.value === values?.hongKongIRDTaxFilingIndicator)}
            valueKey="value"
            onChange={(text:any) => {
              handleOnChange('hongKongIRDTaxFilingIndicator', text?.value)
            }}
          />
        </Grid>
        <Grid item md={2} sm={1} xs={1}>
          {/* <OPRInputControl
            error={errors?.IRDCorporateTitleId}
            isEditable={isEditable}
            label="emp_profile_ird_corporate_title"
            name="IRDCorporateTitleId"
            value={values?.IRDCorporateTitleId}
            onChange={handleChange}
          /> */}
          {
            viewUrl && (
              <OPRSelectorControl
                error={errors?.irdCorporateTitleId}
                isEditable={isEditable}
                keyName="corporateTitleCode"
                label="emp_profile_ird_corporate_title"
                name="corporateTitleCode"
                options={JSON.parse(JSON.stringify(allPosts?.records || []))}
                value={JSON.parse(JSON.stringify(allPosts?.records || []))?.find((o:any) => o?.id === values?.irdCorporateTitleId)}
                valueKey="corporateTitleCode"
                onChange={(text:any) => {
                  handleOnChange('irdCorporateTitleId', text?.id)
                }}
              />
            )
          }

        </Grid>
        <Grid item md={2} sm={1} xs={1}>
          <OPRSelectorControl
            error={errors?.quartersProvidedIndicator}
            isEditable={isEditable}
            keyName="name"
            label="Quarterly provided indicator"
            name="name"
            options={[{ name: 'Yes', value: 'True' }, { name: 'No', value: 'False' }]}
            value={employeeQuarterIndicater?.find((o:any) => o?.value === values?.quartersProvidedIndicator)}
            valueKey="name"
            onChange={(text:any) => {
              handleOnChange('quartersProvidedIndicator', text?.value)
            }}
          />
          {/* <OPRInputControl
            error={errors?.quartersProvidedIndicator}
            isEditable={isEditable}
            label="emp_profile_quarters_provided_indicator"
            name="quartersProvidedIndicator"
            value={values?.quartersProvidedIndicator}
            onChange={handleChange}
          /> */}
        </Grid>
        <Grid item md={2} sm={1} xs={1}>
          <OPRDatePickerControl
            error={errors?.quartersEffectiveDate}
            isEditable={isEditable}
            label="Quarters effective date"
            name="quartersEffectiveDate"
            optionalText="Optional"
            value={values?.quartersEffectiveDate || null}
            onChange={(date) => {
              handleOnChange('quartersEffectiveDate', date)
            }}
          />
          {/* <OPRInputControl
            error={errors?.quartersEffectiveDate}
            isEditable={isEditable}
            label="emp_profile_quarters_effective_date"
            name="quartersEffectiveDate"
            value={values?.quartersEffectiveDate}
            onChange={handleChange}
          /> */}
        </Grid>
        <Grid item md={2} sm={1} xs={1}>
          <OPRSelectorControl
            error={errors?.paidByOverseasCompanyIndicator}
            isEditable={isEditable}
            keyName="name"
            label="Paid by overseas company indicator"
            name="name"
            optionalText="Optional"
            options={paidByOverseasCompanyIndicator}
            value={paidByOverseasCompanyIndicator?.find((o:any) => o?.value === values?.paidByOverseasCompanyIndicator)}
            valueKey="name"
            onChange={(text:any) => {
              handleOnChange('paidByOverseasCompanyIndicator', text?.value)
            }}
          />
          {/* <OPRInputControl
            error={errors?.paidByOverseasCompanyIndicator}
            isEditable={isEditable}
            label="emp_profile_paid_by_overseas_company_indicator"
            name="paidByOverseasCompanyIndicator"
            value={values?.paidByOverseasCompanyIndicator}
            onChange={handleChange}
          /> */}
        </Grid>
        <Grid item md={2} sm={1} xs={1}>
          <OPRInputControl
            error={errors?.overseasCompanyName}
            isEditable={isEditable}
            label="Overseas company name"
            name="overseasCompanyName"
            optionalText="Optional"
            value={values?.overseasCompanyName}
            onChange={handleChange}
          />
        </Grid>
        {
          // JSON.parse(JSON.stringify(allPosts?.records || []))
        }
        <Grid item md={2} sm={1} xs={1}>
          <OPRInputControl
            error={errors?.amountPaidByOverseasCompany}
            isEditable={isEditable}
            label="Amount paid by overseas company"
            name="amountPaidByOverseasCompany"
            optionalText="Optional"
            value={values?.amountPaidByOverseasCompany}
            onChange={handleChange}
          />

        </Grid>
        <Grid item md={2} sm={1} xs={1} />
        <Grid item md={12} sm={1} xs={1}>
          <OPRInputControl
            multiline
            error={errors?.overseasCompanyAddress}
            isEditable={isEditable}
            label="Overseas company address"
            name="overseasCompanyAddress"
            optionalText="Optional"
            value={values?.overseasCompanyAddress}
            onChange={handleChange}
          />
        </Grid>
        <Grid item md={12} sm={1} xs={1}>
          <OPRInputControl
            multiline
            error={errors?.taxReturnRemarksForIR56B_IR56M}
            isEditable={isEditable}
            label="Tax return remarks for IR56B/IR56M"
            name="taxReturnRemarksForIR56B_IR56M"
            optionalText="Optional"
            value={values?.taxReturnRemarksForIR56B_IR56M}
            onChange={handleChange}
          />
        </Grid>
      </OPRResponsiveGrid>
    </Box>
  )
})

export default TaxInformation
