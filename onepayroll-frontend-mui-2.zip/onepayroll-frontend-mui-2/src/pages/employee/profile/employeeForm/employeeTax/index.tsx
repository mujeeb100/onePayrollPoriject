import { Box } from '@mui/material'
import { useClientGroupEntitiesUpdateMutation, useLazyGetClientGroupEntitiesByIdQuery } from 'api/clientServices'
import { useGetAllRegionQuery } from 'api/entityServices'
import { useGetAllCountryQuery } from 'api/globalServices'
import { defaultPageSize } from 'constants/index'
import { forwardRef } from 'react'
import { useLocation } from 'react-router-dom'
import { generateFilterUrl } from 'utils'

import EmployeeQuartersList from './employeeQuarters'
import IR56EInformation from './IR56EInformation'
import IR56GInformation from './IR56GInformation'
import IR56MInformation from './IR56MInformation'
import TaxInformation from './TaxInformation'

interface MessageProps {
    text?: string;
    important?: boolean;
    isQuater?:boolean
  }

const TaxEmployeeForm = forwardRef(({
  isEditable,
  setEditable,
  id,
  isQuater = true,
  rowData,
  handleChange,
  handleOnChange,
  viewUrl,
  errors,
}:any, ref) => {
  const location: any = useLocation()

  const {
    data: allPosts,
    error: createAllPostsBankAccountError,
    isLoading: isLoadingAllPosts,
    isSuccess: isSuccessAllPosts,
    isError: isErrorAllPosts,
    error: errorAllPosts,
  } = useGetAllCountryQuery(generateFilterUrl(''))

  const {
    data: allRegionPosts,
    isLoading: isLoadingAllRegionPosts,
    isSuccess: isSuccessAllRegionPosts,
    isError: isErrorAllRegionPosts,
    error: errorAllRegionPosts,
    refetch: refetchAllPosts,
  } = useGetAllRegionQuery(generateFilterUrl(defaultPageSize))

  const [updateClientGroupEntities, {
    data: uupdatedClientGroupDataResponse,
    error: updatedClientGroupEntitiesError,
    isLoading: updatedClientGroupEntitiesLoading,
    isSuccess: updatedClientGroupEntitiesSuccess,
    isError: updatedClientGroupEntitiesIsError,
  }] = useClientGroupEntitiesUpdateMutation()

  const [updateClientGroupEntitiesById, {
    data: updatedClientGroupEntitiesByIdResponse,
    error: updatedClientGroupEntitiesByIdError,
    isLoading: updatedClientGroupEntitiesByIdLoading,
    isSuccess: updatedClientGroupEntitiesByIdSuccess,
    isError: updatedClientGroupEntitiesByIdIsError,
  }] = useLazyGetClientGroupEntitiesByIdQuery()

  return (
    <Box>
      {/* <OPRAlertControl
        callBack={(type) => {
        }}
        error={createdClientGroupEntitiesError || updatedClientGroupEntitiesError}
        handleEditable={setEditable}
        handleSetValue={setValues}
        handleSubmit={handleSubmit}
        isError={createdClientGroupEntitiesError || updatedClientGroupEntitiesError}
        isLoading={createdClientGroupEntitiesLoading || updatedClientGroupEntitiesLoading || updatedClientGroupEntitiesByIdLoading}
        isSuccess={updatedClientGroupEntitiesSuccess || createdClientGroupEntitiesSuccess}
        name={values?.ClientGroupEntitiesName}
        previousUrl={routes.clientGroupEntities}
        title="Client Group Entitites"
        type={id ? 'Update' : 'New'}
      /> */}
      <TaxInformation
        errors={errors}
        handleChange={handleChange}
        handleOnChange={handleOnChange}
        isEditable={isEditable}
        values={rowData}
        viewUrl={viewUrl}
      />
      <IR56EInformation
        errors={errors}
        handleChange={handleChange}
        handleOnChange={handleOnChange}
        isEditable={isEditable}
        values={rowData}
        viewUrl={viewUrl}
      />
      <IR56GInformation
        errors={errors}
        handleChange={handleChange}
        handleOnChange={handleOnChange}
        isEditable={isEditable}
        values={rowData}
        viewUrl={viewUrl}
      />
      <IR56MInformation
        errors={errors}
        handleChange={handleChange}
        handleOnChange={handleOnChange}
        isEditable={isEditable}
        values={rowData}
        viewUrl={viewUrl}
      />
      <br />
      <br />
      {isQuater && <EmployeeQuartersList empId={id} />}
    </Box>
  )
})

export default TaxEmployeeForm
