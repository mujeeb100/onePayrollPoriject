import { Box, Grid } from '@mui/material'
import OPRLabel from 'components/atoms/label/OPRLabel'
import OPRInputControl from 'components/molecules/OPRInputControl'
import OPRResponsiveGrid from 'components/molecules/OPRResponsiveGrid'
import { forwardRef } from 'react'

interface MessageProps {
    text?: string;
    important?: boolean;
  }

const IR56EInformation = forwardRef(({
  isEditable,
  setEditable,
  id,
  rowData,
  values,
  errors,
  handleChange,
  handleOnChange,
  viewUrl,
}:any, ref) => (
  <Box>

    <OPRLabel variant="h1">IR56E</OPRLabel>
    <OPRResponsiveGrid>
      <Grid item md={2} sm={1} xs={1}>
        <OPRInputControl
          error={errors?.iR56EMonthlyAllowance}
          isEditable={isEditable}
          label="56E monthly allowance"
          name="iR56EMonthlyAllowance"
          optionalText="Optional"
          value={values?.iR56EMonthlyAllowance}
          onChange={handleChange}
        />
      </Grid>
      <Grid item md={2} sm={1} xs={1}>
        <OPRInputControl
          error={errors?.iR56EFluctuatingIncome}
          isEditable={isEditable}
          label="56E fluctuating income"
          name="iR56EFluctuatingIncome"
          optionalText="Optional"
          value={values?.iR56EFluctuatingIncome}
          onChange={handleChange}
        />
      </Grid>
    </OPRResponsiveGrid>
  </Box>
))

export default IR56EInformation
