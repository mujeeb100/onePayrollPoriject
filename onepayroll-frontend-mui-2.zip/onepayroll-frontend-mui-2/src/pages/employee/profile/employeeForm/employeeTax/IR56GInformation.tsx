import { Box, Grid } from '@mui/material'
import OPRLabel from 'components/atoms/label/OPRLabel'
import OPRDatePickerControl from 'components/molecules/OPRDatePickerControl/OPRDatePickerControl'
import OPRInputControl from 'components/molecules/OPRInputControl'
import OPRResponsiveGrid from 'components/molecules/OPRResponsiveGrid'
import OPRSelectorControl from 'components/molecules/OPRSelectorControl/OPRSelectorControl'
import { forwardRef } from 'react'

import {
  IR56GReturningIndicator, IR56GShareOptionGrantedIndicator, IR56GTaxClearanceIndicator, IR56MSumWithheldToSettleTaxDueByRecipientIndicator,
  paidByOverseasCompanyIndicator,
} from '../../dataTransfer'

interface MessageProps {
    text?: string;
    important?: boolean;
  }

const IR56GInformation = forwardRef(({
  isEditable,
  setEditable,
  id,
  rowData,
  values,
  errors,
  handleChange,
  handleOnChange,
  viewUrl,
}:any, ref) => (
  <Box>

    <OPRLabel variant="h1">IR56G</OPRLabel>
    <OPRResponsiveGrid>
      <Grid item md={2} sm={1} xs={1}>
        <OPRSelectorControl
          error={errors?.iR56GTaxBorneByEmployerIndicator}
          isEditable={isEditable}
          keyName="name"
          label="56G tax borne by employer indicator"
          name="name"
          optionalText="Optional"
          options={paidByOverseasCompanyIndicator}
          value={paidByOverseasCompanyIndicator?.find((o:any) => o?.value === values?.iR56GTaxBorneByEmployerIndicator)}
          valueKey="value"
          onChange={(text:any) => {
            handleOnChange('iR56GTaxBorneByEmployerIndicator', text?.value)
          }}
        />
        {/* <OPRInputControl
          error={errors?.iR56GTaxBorneByEmployerIndicator}
          isEditable={isEditable}
          label="emp_profile_ir56g_tax_borne_by_employer_indicator"
          name="iR56GTaxBorneByEmployerIndicator"
          value={values?.iR56GTaxBorneByEmployerIndicator}
          onChange={handleChange}
        /> */}
      </Grid>
      <Grid item md={2} sm={1} xs={1}>
        {/* <OPRInputControl
          error={errors?.iR56GDepartureType}
          isEditable={isEditable}
          label="emp_profile_ir56g_departure_type"
          name="iR56GDepartureType"
          value={values?.iR56GDepartureType}
          onChange={handleChange}
        /> */}
        <OPRSelectorControl
          error={errors?.iR56GDepartureType}
          isEditable={isEditable}
          keyName="name"
          label="56G departure type"
          name="name"
          optionalText="Optional"
          options={IR56GTaxClearanceIndicator}
          value={IR56GTaxClearanceIndicator?.find((o:any) => o?.value === values?.iR56GDepartureType)}
          valueKey="value"
          onChange={(text:any) => {
            handleOnChange('iR56GDepartureType', text?.value)
          }}
        />
      </Grid>
      <Grid item md={2} sm={1} xs={1}>
        <OPRDatePickerControl
          error={errors?.iR56GDepartureDate}
          isEditable={isEditable}
          label="56G departure date"
          name="iR56GDepartureDate"
          optionalText="Optional"
          value={values?.iR56GDepartureDate || null}
          onChange={(date) => {
            handleOnChange('iR56GDepartureDate', date)
          }}
        />
        {/* <OPRInputControl
          error={errors?.iR56GDepartureDate}
          isEditable={isEditable}
          label="emp_profile_departure_date"
          name="iR56GDepartureDate"
          optionalText="Optional"
          value={values?.iR56GDepartureDate}
          onChange={handleChange}
        /> */}
      </Grid>
      <Grid item md={2} sm={1} xs={1}>
        <OPRInputControl
          error={errors?.iR56GDepartureReason}
          isEditable={isEditable}
          label="56G departure reason"
          name="iR56GDepartureReason"
          optionalText="Optional"
          value={values?.iR56GDepartureReason}
          onChange={handleChange}
        />
      </Grid>

      <Grid item md={2} sm={1} xs={1}>
        {/* <OPRInputControl
          error={errors?.iR56GReturningIndicator}
          isEditable={isEditable}
          label="emp_profile_ir56g_returning_indicator"
          name="iR56GReturningIndicator"
          value={values?.iR56GReturningIndicator}
          onChange={handleChange}
        /> */}
        <OPRSelectorControl
          error={errors?.iR56GDepartureType}
          isEditable={isEditable}
          keyName="name"
          label="56G returning indicator"
          name="name"
          optionalText="Optional"
          options={IR56GReturningIndicator}
          value={IR56GReturningIndicator?.find((o:any) => o?.value === values?.iR56GReturningIndicator)}
          valueKey="name"
          onChange={(text:any) => {
            handleOnChange('iR56GReturningIndicator', text?.value)
          }}
        />
      </Grid>
      {
        // JSON.parse(JSON.stringify(allPosts?.records || []))
      }
      <Grid item md={2} sm={1} xs={1}>
        <OPRInputControl
          error={errors?.iR56GReturningDate}
          isEditable={isEditable}
          label="56G returning date"
          name="iR56GReturningDate"
          optionalText="Optional"
          value={values?.iR56GReturningDate}
          onChange={handleChange}
        />

      </Grid>
      <Grid item md={2} sm={1} xs={1}>
        {/* <OPRInputControl
          error={errors?.iR56GMoneyHeldIndicator}
          isEditable={isEditable}
          label="emp_profile_r56g_money_held_indicator"
          name="iR56GMoneyHeldIndicator"
          value={values?.iR56GMoneyHeldIndicator}
          onChange={handleChange}
        /> */}
        <OPRSelectorControl
          error={errors?.iR56GDepartureType}
          isEditable={isEditable}
          keyName="name"
          label="56G money held indicator"
          name="name"
          optionalText="Optional"
          options={IR56MSumWithheldToSettleTaxDueByRecipientIndicator}
          value={IR56MSumWithheldToSettleTaxDueByRecipientIndicator?.find((o:any) => o?.value === values?.iR56GMoneyHeldIndicator)}
          valueKey="name"
          onChange={(text:any) => {
            handleOnChange('iR56GMoneyHeldIndicator', text?.value)
          }}
        />
      </Grid>
      <Grid item md={2} sm={1} xs={1}>
        <OPRInputControl
          error={errors?.iR56GMoneyHeldAmount}
          isEditable={isEditable}
          label="56G money held amount"
          name="iR56GMoneyHeldAmount"
          optionalText="Optional"
          value={values?.iR56GMoneyHeldAmount}
          onChange={handleChange}
        />
      </Grid>
      <Grid item md={2} sm={1} xs={1}>
        <OPRInputControl
          error={errors?.iR56GMoneyNotHeldReason}
          isEditable={isEditable}
          label="56G money held reason"
          name="iR56GMoneyNotHeldReason"
          value={values?.iR56GMoneyNotHeldReason}
          onChange={handleChange}
        />
      </Grid>
      <Grid item md={2} sm={1} xs={1} />
      <Grid item md={2} sm={1} xs={1}>
        {/* <OPRInputControl
          error={errors?.iR56GShareOptionGrantedIndicator}
          isEditable={isEditable}
          label="emp_profile_ir56g_share_option_granted_indicator"
          name="iR56GShareOptionGrantedIndicator"
          value={values?.iR56GShareOptionGrantedIndicator}
          onChange={handleChange}
        /> */}
        <OPRSelectorControl
          error={errors?.iR56GDepartureType}
          isEditable={isEditable}
          keyName="name"
          label="56G share option granted indicator"
          name="name"
          optionalText="Optional"
          options={IR56GShareOptionGrantedIndicator}
          value={IR56GShareOptionGrantedIndicator?.find((o:any) => o?.value === values?.iR56GShareOptionGrantedIndicator)}
          valueKey="value"
          onChange={(text:any) => {
            handleOnChange('iR56GShareOptionGrantedIndicator', text?.value)
          }}
        />
      </Grid>
      <Grid item md={2} sm={1} xs={1}>
        <OPRInputControl
          error={errors?.iR56GNoOfShareNotYetExercised}
          isEditable={isEditable}
          label="56G no. of share not yet exercised"
          name="iR56GNoOfShareNotYetExercised"
          optionalText="Optional"
          value={values?.iR56GNoOfShareNotYetExercised}
          onChange={handleChange}
        />
      </Grid>
      <Grid item md={2} sm={1} xs={1}>
        {/* <OPRInputControl
          error={errors?.iR56GShareOptionGrantDate}
          isEditable={isEditable}
          label="56G share option grant date"
          name="iR56GShareOptionGrantDate"
          optionalText="Optional"
          value={values?.iR56GShareOptionGrantDate}
          onChange={handleChange}
        /> */}
        <OPRDatePickerControl
          error={errors?.iR56GShareOptionGrantDate}
          isEditable={isEditable}
          label="56G share option grant date"
          name="iR56GShareOptionGrantDate"
          optionalText="Optional"
          value={values?.iR56GDepartureDate || null}
          onChange={(date) => {
            handleOnChange('iR56GShareOptionGrantDate', date)
          }}
        />
      </Grid>
      <Grid item md={2} sm={1} xs={1} />
      <Grid item md={2} sm={1} xs={1}>
        <OPRInputControl
          error={errors?.iR56GTaxClearanceIndicator}
          isEditable={isEditable}
          label="56G tax clearance indicator"
          name="iR56GTaxClearanceIndicator"
          optionalText="Optional"
          value={values?.iR56GTaxClearanceIndicator}
          onChange={handleChange}
        />
      </Grid>
      <Grid item md={2} sm={1} xs={1} />
    </OPRResponsiveGrid>
  </Box>
))

export default IR56GInformation
