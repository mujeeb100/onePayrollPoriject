import {
  Box,
} from '@mui/material'
import { useEmployeeQuarterDeleteMutation, useGetAllEmployeeQuarterQuery } from 'api/employeeServices'
import { RighCaretBlue } from 'assets/svg-images/SvgComponents'
import OPRButton from 'components/atoms/button/OPRButton'
import OPRLabel from 'components/atoms/label/OPRLabel'
import CustomLoader from 'components/atoms/loader/OPRLoader'
import { CustomDialog } from 'components/atoms/modal/OPRModal'
import OPRPagination from 'components/atoms/pagination/OPRPagination'
import OPRTable from 'components/atoms/table/OPRTable'
import { employeeQuarterColumn } from 'components/atoms/table/OPRTableConstant'
import CancelAlert from 'components/molecules/OPRAlertControl/CancelAlert'
import { OPRDeleteControl } from 'components/molecules/OPRAlertControl/OPRDeleteControl'
import OPRErrorAlertControl from 'components/molecules/OPRAlertControl/OPRErrorControl'
import { displayFormatDate } from 'constants/index'
import { useEditable } from 'hooks/useEdit'
import React, { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import {
  generateFilterUrl,
} from 'utils'

import EmployeeQuarterForm from './employeeQuarterForm'

function EmployeeQuartersList({ ProfileId, empId }:any) {
  const [selelctedUser, setSelelctedUser]:any = useState({
    data: {},
    isDelete: false,
    name: '',
  })
  const myRef:any = React.useRef()
  const { isEditable, setEditable } = useEditable()
  const [isModal, setModal] = useState(false)
  const [isCancel, setCancel] = useState(false)
  const navigate: any = useNavigate()
  const [selectedId, setSelectedId]:any = useState(null)
  const [filterData, setFilterData]:any = useState({
    pageNumber: 1,
    pageSize: 20,
    totalItems: 0,
    orderByAsc: true,
    sortBy: '',
    SearchText: empId,
  })
  const {
    data: allPosts,
    error: createAllPostsBankAccountError,
    isLoading: isLoadingAllPosts,
    isSuccess: isSuccessAllPosts,
    isError: isErrorAllPosts,
    error: errorAllPosts,
  } = useGetAllEmployeeQuarterQuery(generateFilterUrl(filterData))

  // console.log(useEmployeeQuarterChangeStatusMutation, 'useClientGroupEntitesChangeStatusMutationuseClientGroupEntitesChangeStatusMutation')

  const [deleteEmployeeQuarterById,
    {
      data: deleteEmployeeQuarterResponse,
      error: deleteEmployeeQuarterError,
      isLoading: deleteEmployeeQuarterLoading,
      isSuccess: deleteEmployeeQuarterSuccess,
      isError: deleteEmployeeQuarterIsError,
    }] = useEmployeeQuarterDeleteMutation()

  const sorting = (
    event: React.MouseEvent<unknown>,
    property: keyof any,
  ) => {
    const isAsc = filterData.sortBy === property && filterData.orderByAsc === true
    setFilterData({ ...filterData, orderByAsc: !isAsc, sortBy: property })
    // setOrder(isAsc ? 'desc' : 'asc')
    // setOrderBy(property)
  }

  useEffect(() => {
    setFilterData({ ...filterData, totalItems: allPosts?.totalItems ? allPosts?.totalItems : 0 })
  }, [allPosts?.pageNumber, filterData.sortBy, filterData.orderByAsc, allPosts?.totalItems])
  useEffect(() => {
    if (isModal === false) {
      setSelectedId(null)
    }
  }, [isModal])
  const onSearch = (e: any, data: any) => {
    setFilterData({ ...filterData, ...data })
  }
  const handlePagination = (pageNumber: number, pageSize: number) => {
    setFilterData({ ...filterData, pageNumber })
  }
  const viewAcoount = (data: any, type:string) => {
    if (type === 'edit') {
    //   navigate(
    //     setRouteValues(`${routes.editEmployeeQuarter}`, {
    //       id: data.clientGroupProfileId,
    //       profilId: data.id,
    //     }),
    //   )
    } else if (type === 'Delete employee quarter') {
      setSelelctedUser({ data, isDelete: true, name: `${displayFormatDate(data?.periodFromDate)}- ${displayFormatDate(data?.periodToDate)}` })
    } else if (type === 'change status') {
    //   changeStatusEmployeeQuarter({
    //     id: data.id,
    //     status: !data.status,
    //   })
      // deleteEmployeeQuarterById(`Id=${data.id}`)
    } else {
    //   navigate(
    //     setRouteValues(`${routes.viewEmployeeQuarter}`, {
    //       id: data.clientGroupProfileId,
    //       profilId: data.id,
    //       view: false,
    //     }),
    //   )
    }
    // const id = JSON.stringify(data)
  }

  const handleView = (data: any) => {
    setSelectedId(data.id)
    setModal(!isModal)
    // navigate(
    //   setRouteValues(`${routes.editEmployeeBankAccount}`, {
    //     id: data.clientGroupProfileId,
    //     profilId: data.id,
    //   }),
    // )
  }
  const deleteEntities = (data:any) => {
    deleteEmployeeQuarterById(`Id=${data.id}`)
  }

  return (
    <Box sx={{ display: 'flex', flexDirection: 'column' }}>
      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <div
          className="TableTitle"
          style={{
            color: '#3B3839', fontSize: 24, fontFamily: 'Lato', fontWeight: '700', wordWrap: 'break-word',
          }}
        >
          Employee quarters
        </div>
        <OPRButton
          startIcon
          handleClick={() => {
            setModal(!isModal)
          }}
          variant="text"
        >
          {' '}
          Add employee quarter
        </OPRButton>
      </Box>
      <CustomDialog
        CustomStyles={{ borderRadius: '16px' }}
        isOpen={isLoadingAllPosts}
        type="loader"
      >
        <CustomLoader text="Processing request" />
      </CustomDialog>
      {/* open modal */}

      <CustomDialog
        CustomStyles={{ borderRadius: '16px' }}
        isOpen={isModal}
        type="loader"
      >
        {/* <BankAccountEmployeeForm /> */}
        <EmployeeQuarterForm
          ref={myRef}
          empId={empId}
          id={selectedId}
          isEditable={isEditable}
          setEditable={setEditable}
        />
        <Box sx={{
          display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: 5,
        }}
        >
          <OPRButton color="info" variant="text" onClick={() => setCancel(true)}>
            Cancel
          </OPRButton>
          <>
            {
              isEditable && (
                <OPRButton
                  style={{ marginLeft: 'auto' }}
                  variant="text"
                  onClick={() => {
                  // alert('back')

                    myRef?.current?.handleBack()
                  }}
                >
                  <RighCaretBlue />
                  Back
                </OPRButton>
              )
            }

            <OPRButton
              color="info"
              variant="text"
              onClick={(e:any) => {
                myRef?.current?.handleOnSubmit(e)
              }}
            >
              Confirm
            </OPRButton>
          </>

        </Box>
      </CustomDialog>
      <CancelAlert
        callBack={() => {
          setCancel(false)
          setModal(false)
        }}
        handleCancel={() => {
          setCancel(false)
        }}
        isCancel={isCancel}
      />
      <OPRDeleteControl
        deleteCallBack={deleteEntities}
        selelctedUser={selelctedUser}
        setSelelctedUser={setSelelctedUser}
        success={deleteEmployeeQuarterSuccess}
        title="employee quarter"
      />
      <OPRErrorAlertControl
        error={deleteEmployeeQuarterError}
        header="Failed to Delete"
        isBackButton={false}
        isError={deleteEmployeeQuarterIsError}
        isTry={false}
        name="employee quarter"
      />
      <OPRLabel CustomStyles={{ marginBottom: 5 }} variant="body2">
        {JSON.parse(JSON.stringify(allPosts?.records || [])).length}
        {' '}
        items
      </OPRLabel>
      <OPRTable
        cols={employeeQuarterColumn(viewAcoount)}
        data={JSON.parse(JSON.stringify(allPosts?.records || []))}
        handleEdit={viewAcoount}
        isLoader={isLoadingAllPosts || deleteEmployeeQuarterLoading}
        newOptions={[]}
        orderBy={filterData?.orderByAsc}
        rowClickHandler={handleView}
        rowNumber={0}
        sortBy={filterData?.sortBy}
        title="title"
      />
      {
        filterData?.totalItems < 20 ? null : (
          <Box sx={{ display: 'flex', justifyContent: 'center', mt: 2 }}>
            <OPRPagination
              limit={filterData?.pageSize}
              page={filterData?.pageNumber}
              setPage={handlePagination}
              total={filterData?.totalItems}
            />
          </Box>
        )
      }
    </Box>
  )
}

export default EmployeeQuartersList
