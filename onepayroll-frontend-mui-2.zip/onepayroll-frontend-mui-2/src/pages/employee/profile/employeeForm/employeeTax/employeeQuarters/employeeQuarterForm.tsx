import { Box, Grid } from '@mui/material'
import {
  useEmployeeQuarterCreateMutation, useEmployeeQuarterUpdateMutation, useGetAllEmployeeProfileQuery, useLazyGetEmployeeQuarterByIdQuery,
} from 'api/employeeServices'
import { useGetAllRegionQuery } from 'api/entityServices'
import OPRDatePickerControl from 'components/molecules/OPRDatePickerControl/OPRDatePickerControl'
import OPRFormHeaderLabel from 'components/molecules/OPRFormHeaderLabel/OPRFormHeaderLabel'
import OPRInputControl from 'components/molecules/OPRInputControl'
import OPRResponsiveGrid from 'components/molecules/OPRResponsiveGrid'
import OPRSelectorControl from 'components/molecules/OPRSelectorControl/OPRSelectorControl'
import OPRAlertControl from 'components/organism/OPRAlertControl'
import { defaultPageSize, employeeQuartersNature, employeeQuartersStatus } from 'constants/index'
import { employeeQuarterSchema } from 'constants/validate'
import useForm from 'hooks/useForm'
import { forwardRef, useEffect, useImperativeHandle } from 'react'
import { useLocation } from 'react-router-dom'
import { customDateFormate, generateFilterUrl } from 'utils'

interface MessageProps {
    text?: string;
    important?: boolean;
    empId:any
  }

const EmployeeQuarterForm = forwardRef(({
  id, isEditable, setEditable, empId,
}:any, ref) => {
  const {
    values,
    setValues,
    errors,
    handleChange,
    setErrors,
    handleFormSubmit,
    handleOnChange,

  } = useForm(employeeQuarterSchema)
  const location: any = useLocation()

  const [createEmployeeQuarter, {
    data: createdEmployeeQuarterData,
    error: createdEmployeeQuarterError,
    isLoading: createdEmployeeQuarterLoading,
    isSuccess: createdEmployeeQuarterSuccess,
    isError: createdEmployeeQuarterIsError,
  }] = useEmployeeQuarterCreateMutation()

  const {
    data: employeeDataList,
    isLoading: isLoadingEmployeeDataList,
    isSuccess: isSuccessEmployeeDataList,
    isError: isErrorEmployeeDataList,
    error: errorEmployeeDataList,
    refetch: refetchEmployeeDataList,
  } = useGetAllEmployeeProfileQuery(generateFilterUrl({
    EffectiveDate: '10/10/2040',
    ...defaultPageSize,
  }))

  const {
    data: allRegionPosts,
    isLoading: isLoadingAllRegionPosts,
    isSuccess: isSuccessAllRegionPosts,
    isError: isErrorAllRegionPosts,
    error: errorAllRegionPosts,
    refetch: refetchAllPosts,
  } = useGetAllRegionQuery(generateFilterUrl(defaultPageSize))

  const [updateEmployeeQuarter, {
    data: uupdatedClientGroupDataResponse,
    error: updatedEmployeeQuarterError,
    isLoading: updatedEmployeeQuarterLoading,
    isSuccess: updatedEmployeeQuarterSuccess,
    isError: updatedEmployeeQuarterIsError,
  }] = useEmployeeQuarterUpdateMutation()

  const [updateEmployeeQuarterById, {
    data: updatedEmployeeQuarterByIdResponse,
    error: updatedEmployeeQuarterByIdError,
    isLoading: updatedEmployeeQuarterByIdLoading,
    isSuccess: updatedEmployeeQuarterByIdSuccess,
    isError: updatedEmployeeQuarterByIdIsError,
  }] = useLazyGetEmployeeQuarterByIdQuery()
  useEffect(() => {
    if (id) {
      updateEmployeeQuarterById(id)
    }
  }, [])
  useEffect(() => {
    if (id === null || id === undefined) {
      setValues({ ...values, status: 'Active' })
    }
  }, [])

  useEffect(() => {
    const data = {
      ...updatedEmployeeQuarterByIdResponse?.data,
      rentPaidToEmployerByEmployee: updatedEmployeeQuarterByIdResponse?.data?.rentPaidToEmployerByEmployee?.toString(),
      rentPaidToLandlordByEmployee: updatedEmployeeQuarterByIdResponse?.data?.rentPaidToLandlordByEmployee?.toString(),
      rentPaidToLandlordByEmployer: updatedEmployeeQuarterByIdResponse?.data?.rentPaidToLandlordByEmployer?.toString(),
      rentRefundedToEmployeeByEmployer: updatedEmployeeQuarterByIdResponse?.data?.rentRefundedToEmployeeByEmployer?.toString(),
    }
    if (updatedEmployeeQuarterByIdSuccess) {
      setValues(data || {})
    }
  }, [updatedEmployeeQuarterByIdSuccess])

  function getSurnameByEmployeeCode(employeeCode:any) {
    const employee = employeeDataList?.records?.find((emp:any) => emp.employeeCode === employeeCode)
    return employee.employeeProfile.id ? employee.employeeProfile.id : null
  }
  // const handleSubmit:any = async () => {
  //   if (isEditable) {
  //     await createEmployeeQuarter({ ...values, employeeCode: empId })
  //   } else {
  //     setEditable(true)
  //   }
  // }

  // const handleSubmit:any = async () => {
  //   if (isEditable) {
  //     if (id === null) {
  //       await createEmployeeQuarter({ ...values, employeeCode: empId })
  //     } else {
  //       await updateEmployeeQuarter({ ...values, employeeCode: empId })
  //     }
  //   } else {
  //     setEditable(true)
  //   }
  // }
  const handleSubmit: any = async () => {
    if (isEditable) {
      // Clone the values and filter out empty fields
      const payload = { ...values }

      // Remove fields with empty values
      if (!payload.rentPaidToLandlordByEmployer) {
        delete payload.rentPaidToLandlordByEmployer
      }
      if (!payload.rentPaidToLandlordByEmployee) {
        delete payload.rentPaidToLandlordByEmployee
      }
      if (!payload.rentRefundedToEmployeeByEmployer) {
        delete payload.rentRefundedToEmployeeByEmployer
      }
      if (!payload.rentPaidToEmployerByEmployee) {
        delete payload.rentPaidToEmployerByEmployee
      }

      // Perform create or update operation
      if (id === null) {
        await createEmployeeQuarter({ ...payload, employeeCode: empId })
      } else {
        await updateEmployeeQuarter({ ...payload, employeeCode: empId })
      }
    } else {
      setEditable(true)
    }
  }

  useImperativeHandle(ref, () => ({
    handleOnSubmit(e:any) {
      // console.log(errors, 'eeeeeeeeeeee')
      handleFormSubmit(e, handleSubmit)
    },
    handleBack() {
      setEditable(false)
    },
  }))

  useEffect(() => {
    if (createdEmployeeQuarterSuccess && updatedEmployeeQuarterSuccess) {
      // Reset form values after successful add operation
      setValues({})
      setErrors({})
    }
  }, [createdEmployeeQuarterSuccess, updatedEmployeeQuarterSuccess])

  const successfullMessage: any = () => {
    const isUpdate = !!updatedEmployeeQuarterByIdResponse?.data
    const data = isUpdate ? updatedEmployeeQuarterByIdResponse?.data : createdEmployeeQuarterData?.data

    const htmString = `<div className="MainContent" 
      style={{width: '100%', height: '100%', paddingLeft: 40, paddingRight: 40, flexDirection: 'column', justifyContent: 'flex-start', alignItems: 'flex-start', gap: 20, display: 'inline-flex'}}>
      <div className="InsertContent" style={{alignSelf: 'stretch'}}>
        <span style="color: '#3B3839', fontSize: 16, fontFamily: 'Lato', fontWeight: '700', lineHeight: 24, wordWrap: 'break-word'">
          ${customDateFormate(data?.periodFromDate)} - ${customDateFormate(data?.periodToDate)}
        </span>
        <span style="color: '#3B3839', fontSize: 16, fontFamily: 'Lato', fontWeight: '400', lineHeight: 24, wordWrap: 'break-word'">
          has been ${isUpdate ? 'updated' : 'added'} to
        </span>
        <span style="color: '#3B3839', fontSize: 16, fontFamily: 'Lato', fontWeight: '700', lineHeight: 24, wordWrap: 'break-word'">
          ${customDateFormate(data?.periodFromDate)} - ${customDateFormate(data?.periodToDate)}
        </span>
        <span style="color: '#3B3839', fontSize: 16, fontFamily: 'Lato', fontWeight: '400', lineHeight: 24, wordWrap: 'break-word'">.
        </span>
      </div>
    </div>`

    const plainString = htmString.replace(/<[^>]+>/g, '')
    return plainString
  }

  return (
    <Box>
      <OPRAlertControl
        callBack={(type) => {
          // if (type === 'success') {
          //   navigate(-1)
          // }
        }}
        customMessage={successfullMessage()}
        error={createdEmployeeQuarterError || updatedEmployeeQuarterError}
        handleEditable={setEditable}
        handleSetValue={setValues}
        handleSubmit={handleSubmit}
        isError={createdEmployeeQuarterError || updatedEmployeeQuarterError}
        isLoading={createdEmployeeQuarterLoading || updatedEmployeeQuarterLoading}
        isSuccess={updatedEmployeeQuarterSuccess || createdEmployeeQuarterSuccess}
        name={values?.EmployeeQuarterName}
        previousUrl="routes.EmployeeQuarter"
        title="Employee Quarter"
        type={id ? 'Update' : 'New'}
      />
      <OPRFormHeaderLabel title="Add employee quarter" />
      <OPRResponsiveGrid>

        {/* <Grid item md={12} sm={1} xs={1}>
          <OPRSelectorControl
            disabled
            isRequired
            error={errors?.employeeCode}
            isEditable={isEditable}
            keyName="employeeCode"
            label="emp_quarters_emp_code"
            multiple={false}
            name="employeeCode"
            options={JSON.parse(JSON.stringify(employeeDataList?.records || []))}
            placeholder="Select an option"
            value={JSON.parse(JSON.stringify(employeeDataList?.records || []))?.find((o:any) => o?.employeeCode === empId) || {}}
            valueKey="employeeCode"
            onChange={(text:any) => {
              handleOnChange('employeeCode', text?.employeeCode)
            }}
          />
        </Grid> */}
        <Grid item md={2} sm={1} xs={1}>
          <OPRDatePickerControl
            isRequired
            error={errors?.periodFromDate}
            isEditable={isEditable}
            label="emp_quarters_period_from_date"
            name="periodFromDate"
            // value={values?.effectiveStartDate ? values?.effectiveStartDate?.toISOString() : null}
            value={values?.periodFromDate || null}
            onChange={(date) => {
              handleOnChange('periodFromDate', date)
            }}
          />
        </Grid>
        <Grid item md={2} sm={1} xs={1}>
          <OPRDatePickerControl
            isRequired
            error={errors?.periodToDate}
            isEditable={isEditable}
            label="emp_quarters_period_to_date"
            name="periodToDate"
            // value={values?.effectiveStartDate ? values?.effectiveStartDate?.toISOString() : null}
            value={values?.periodToDate || null}
            onChange={(date) => {
              handleOnChange('periodToDate', date)
            }}
          />
        </Grid>
        <Grid item md={2} sm={1} xs={1}>
          <OPRSelectorControl
            isRequired
            error={errors?.nature}
            isEditable={isEditable}
            keyName="name"
            label="emp_quarters_nature"
            multiple={false}
            name="name"
            options={employeeQuartersNature}
            placeholder="Select an option"
            value={employeeQuartersNature?.find((o:any) => o?.value === values?.nature) || {}}
            valueKey="value"
            onChange={(text:any) => {
              handleOnChange('nature', text?.value)
            }}
          />
        </Grid>
        {
          // JSON.parse(JSON.stringify(allPosts?.records || []))
        }
        <Grid item md={2} sm={1} xs={1}>
          <OPRSelectorControl
            isRequired
            error={errors?.status}
            isEditable={isEditable}
            keyName="name"
            label="emp_quarters_status"
            multiple={false}
            name="name"
            options={employeeQuartersStatus}
            placeholder="Select an option"
            value={employeeQuartersStatus?.find((o:any) => o?.value === values?.status)}
            valueKey="value"
            onChange={(text:any) => {
              handleOnChange('status', text?.value)
            }}
          />
        </Grid>
        <Grid item md={12} sm={1} xs={1}>
          <OPRInputControl
            multiline
            error={errors?.address}
            isEditable={isEditable}
            label="emp_quarters_address"
            name="address"
            value={values?.address}
            onChange={handleChange}
          />
        </Grid>
        <Grid item md={2} sm={1} xs={1}>
          <OPRInputControl
            error={errors?.rentPaidToLandlordByEmployer}
            isEditable={isEditable}
            label="emp_quarters_rent_paid_to_landlord_by_employer"
            name="rentPaidToLandlordByEmployer"
            optionalText="Optional"
            type="number"
            value={values?.rentPaidToLandlordByEmployer}
            onChange={handleChange}
          />
        </Grid>
        <Grid item md={2} sm={1} xs={1}>
          <OPRInputControl
            error={errors?.rentPaidToLandlordByEmployee}
            isEditable={isEditable}
            label="emp_quarters_rent_paid_to_landlord_by_employee"
            name="rentPaidToLandlordByEmployee"
            optionalText="Optional"
            type="number"
            value={values?.rentPaidToLandlordByEmployee}
            onChange={handleChange}
          />
        </Grid>
        <Grid item md={2} sm={1} xs={1}>
          <OPRInputControl
            error={errors?.rentRefundedToEmployeeByEmployer}
            isEditable={isEditable}
            label="emp_quarters_rent_refunded_to_employee_by_employer"
            name="rentRefundedToEmployeeByEmployer"
            optionalText="Optional"
            type="number"
            value={values?.rentRefundedToEmployeeByEmployer}
            onChange={handleChange}
          />
        </Grid>
        <Grid item md={2} sm={1} xs={1}>
          <OPRInputControl
            error={errors?.rentPaidToEmployerByEmployee}
            isEditable={isEditable}
            label="emp_quarters_rent_paid_to_employer_by_employee"
            name="rentPaidToEmployerByEmployee"
            optionalText="Optional"
            type="number"
            value={values?.rentPaidToEmployerByEmployee}
            onChange={handleChange}
          />
        </Grid>

      </OPRResponsiveGrid>
    </Box>
  )
})

export default EmployeeQuarterForm
