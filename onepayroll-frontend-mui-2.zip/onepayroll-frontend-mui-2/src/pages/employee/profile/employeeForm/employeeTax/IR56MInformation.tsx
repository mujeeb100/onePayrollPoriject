import { Box, Grid } from '@mui/material'
import OPRLabel from 'components/atoms/label/OPRLabel'
import OPRInputControl from 'components/molecules/OPRInputControl'
import OPRResponsiveGrid from 'components/molecules/OPRResponsiveGrid'
import { forwardRef } from 'react'

interface MessageProps {
    text?: string;
    important?: boolean;
  }

const IR56MInformation = forwardRef(({
  isEditable,
  setEditable,
  id,
  rowData,
  values,
  errors,
  handleChange,
  handleOnChange,
  viewUrl,
}:any, ref) => (
  <Box>

    <OPRLabel variant="h1">IR56M</OPRLabel>
    <OPRResponsiveGrid>
      <Grid item md={2} sm={1} xs={1}>
        <OPRInputControl
          error={errors?.iR56MSumWithheldToSettleTaxDueByRecipientIndicator}
          isEditable={isEditable}
          label="56M sum withheld to settle tax due by recipient indicator"
          name="iR56MSumWithheldToSettleTaxDueByRecipientIndicator"
          optionalText="Optional"
          value={values?.iR56MSumWithheldToSettleTaxDueByRecipientIndicator}
          onChange={handleChange}
        />
        {/* <OPRSelectorControl
          error={errors?.iR56GDepartureType}
          isEditable={isEditable}
          keyName="name"
          label="emp_profile_ir56m_sum_withheld_to_settle_tax_due_by_recipient_indicator"
          name="name"
          options={IR56MSumWithheldToSettleTaxDueByRecipientIndicator}
          value={IR56MSumWithheldToSettleTaxDueByRecipientIndicator?.find((o:any) => o?.value === values?.iR56MSumWithheldToSettleTaxDueByRecipientIndicator)}
          valueKey="value"
          onChange={(text:any) => {
            handleOnChange('iR56MSumWithheldToSettleTaxDueByRecipientIndicator', text?.value)
          }}
        /> */}
      </Grid>
      <Grid item md={2} sm={1} xs={1}>
        <OPRInputControl
          error={errors?.IR56MSumWithheldAmount}
          isEditable={isEditable}
          label="56M sum withheld amount"
          name="IR56MSumWithheldAmount"
          optionalText="Optional"
          value={values?.IR56MSumWithheldAmount}
          onChange={handleChange}
        />
      </Grid>

    </OPRResponsiveGrid>
  </Box>
))

export default IR56MInformation
