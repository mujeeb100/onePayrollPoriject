import { Box } from '@mui/material'
import { forwardRef, useImperativeHandle } from 'react'

import ContactInformation from './ContactInformation'
import EmploymentInformation from './EmployeeInformation'
import PersonalInformation from './PersonalInformation'

interface MessageProps {
    text?: string;
    important?: boolean;
  }

const ProfileEmployeeForm = forwardRef(({
  isEditable,
  setEditable,
  id,
  rowData,
  handleChange,
  handleOnChange,
  errors,
  viewUrl,
}:any, ref) => {
  useImperativeHandle(ref, () => ({
    handleOnSubmit(e:any) {
      // handleFormSubmit(e, handleSubmit)
    },

  }))

  return (
    <Box>

      <EmploymentInformation
        errors={errors}
        handleChange={handleChange}
        handleOnChange={handleOnChange}
        id={id}
        isEditable={isEditable}
        values={rowData}
        viewUrl={viewUrl}
      />
      <PersonalInformation
        errors={errors}
        handleChange={handleChange}
        handleOnChange={handleOnChange}
        isEditable={isEditable}
        values={rowData}
        viewUrl={viewUrl}
      />
      <ContactInformation
        errors={errors}
        handleChange={handleChange}
        handleOnChange={handleOnChange}
        isEditable={isEditable}
        values={rowData}
        viewUrl={viewUrl}
      />
    </Box>
  )
})

export default ProfileEmployeeForm
