import { Box, Grid } from '@mui/material'
import { useGetAllCountryQuery, useGetAllNationalityQuery } from 'api/globalServices'
import OPRLabel from 'components/atoms/label/OPRLabel'
import OPRDatePickerControl from 'components/molecules/OPRDatePickerControl/OPRDatePickerControl'
import OPRInputControl from 'components/molecules/OPRInputControl'
import OPRResponsiveGrid from 'components/molecules/OPRResponsiveGrid'
import OPRSelectorControl from 'components/molecules/OPRSelectorControl/OPRSelectorControl'
import { forwardRef } from 'react'
import { generateFilterUrl } from 'utils'

import { filterByValueOrFirstLetter, mariatalStatusList } from './data'

const calculateAge = (dob:any) => {
  const birthDate = new Date(dob)
  const today = new Date()

  const age = today.getFullYear() - birthDate.getFullYear()
  const monthDifference = today.getMonth() - birthDate.getMonth()
  const dayDifference = today.getDate() - birthDate.getDate()

  // If the current month is before the birth month or
  // if the current month is the birth month but the current day is before the birth day,
  // subtract one year from the age.
  if (monthDifference < 0 || (monthDifference === 0 && dayDifference < 0)) {
    age
  }

  return age
}
interface MessageProps {
    text?: string;
    important?: boolean;
  }

const PersonalInformation = forwardRef(({
  isEditable,
  setEditable,
  id,
  values,
  errors,
  handleChange,
  handleOnChange,
  viewUrl,
}:any, ref) => {
  const {
    data: allPosts,
    isLoading: isLoadingAllPosts,
    isSuccess: isSuccessAllPosts,
    isError: isErrorAllPosts,
    error: errorAllPosts,
    refetch: refetchAllPosts,
  } = useGetAllNationalityQuery(generateFilterUrl({
    pageSize: 1000,
  }))
  const {
    data: allPostsCountry,
    error: createAllPostsBankAccountCountryError,
    isLoading: isLoadingAllPostsCountry,
    isSuccess: isSuccessAllPostsCountry,
    isError: isErrorAllPostsCountry,
    error: errorAllPostsCountry,
  } = useGetAllCountryQuery(generateFilterUrl({
    pageSize: 1000,
  }))
  const countryDataList = JSON.parse(JSON.stringify(allPostsCountry?.records || []))?.map((item:any) => ({
    ...item,
    label: `${item.countryName}(${item.countryCode})`,
  }))
  return (
    <Box>

      <OPRLabel variant="h1">Personal Information</OPRLabel>
      <OPRResponsiveGrid>
        <Grid item md={2} sm={1} xs={1}>
          <OPRSelectorControl
            error={errors?.title}
            isEditable={isEditable}
            keyName="name"
            label="employee_profile_title_mr"
            name="name"
            optionalText="Optional"
            options={[
              { name: 'Mr', value: 'Mr' },
              { name: 'Mrs', value: 'Mrs' },
              { name: 'Miss', value: 'Miss' },
              { name: 'Mis', value: 'Mis' },
              { name: 'Dr', value: 'Dr' },
            ]}
            value={[
              { name: 'Mr', value: 'Mr' },
              { name: 'Mrs', value: 'Mrs' },
              { name: 'Miss', value: 'Miss' },
              { name: 'Mis', value: 'Mis' },
              { name: 'Dr', value: 'Dr' },
            ].find((o:any) => o?.value === values?.title)}
            valueKey="value"
            onChange={(text:any) => {
              handleOnChange('title', text?.value)
            }}
          />
        </Grid>
        <Grid item md={2} sm={1} xs={1}>
          <OPRSelectorControl
            error={errors?.title}
            isEditable={isEditable}
            keyName="name"
            label="employee_profile_gender"
            name="name"
            options={[
              { name: 'Male', value: 'Male' },
              { name: 'Female', value: 'Female' },
            ]}
            value={[
              { name: 'Male', value: 'Male' },
              { name: 'Female', value: 'Female' },
            ]?.find((o:any) => o?.value === values?.gender)}
            valueKey="value"
            onChange={(text:any) => {
              handleOnChange('gender', text?.value)
            }}
          />
        </Grid>
        <Grid item md={2} sm={1} xs={1}>
          <OPRInputControl
            error={errors?.nameInLocalLanguage}
            isEditable={isEditable}
            label="employee_profile_name_In_local_language"
            name="nameInLocalLanguage"
            optionalText="Optional"
            value={values?.nameInLocalLanguage}
            onChange={handleChange}
          />
        </Grid>
        <Grid item md={2} sm={1} xs={1}>
          <OPRInputControl
            error={errors?.displayName}
            isEditable={isEditable}
            label="employee_profile_display_name"
            name="displayName"
            optionalText="Optional"
            value={values?.displayName}
            onChange={handleChange}
          />
        </Grid>
        {
          // JSON.parse(JSON.stringify(allPosts?.records || []))
        }
        <Grid item md={2} sm={1} xs={1}>
          <OPRInputControl
            error={errors?.christianName}
            isEditable={isEditable}
            label="employee_profile_christian_name"
            name="christianName"
            optionalText="Optional"
            value={values?.christianName}
            onChange={handleChange}
          />

        </Grid>
        <Grid item md={2} sm={1} xs={1}>
          <OPRInputControl
            error={errors?.middleName}
            isEditable={isEditable}
            label="employee_profile_middle_name"
            name="middleName"
            optionalText="Optional"
            value={values?.middleName}
            onChange={handleChange}
          />
        </Grid>
        <Grid item md={2} sm={1} xs={1}>
          <OPRInputControl
            error={errors?.identityNumber}
            isEditable={isEditable}
            label="emp_profile_identity_num"
            name="identityNumber"
            optionalText="Optional"
            value={values?.identityNumber}
            onChange={handleChange}
          />
        </Grid>
        <Grid item md={2} sm={1} xs={1}>
          <OPRSelectorControl
            error={errors?.nationalityCode}
            isEditable={isEditable}
            keyName="nationalityCode"
            label="Nationality"
            name="nationalityCode"
            optionalText="Optional"
            options={JSON.parse(JSON.stringify(allPosts?.records || []))}
            value={JSON.parse(JSON.stringify(allPosts?.records || [])).find((o:any) => o?.id === values?.nationalityId)}
            valueKey="nationalityCode"
            onChange={(text:any) => {
              handleOnChange('nationalityId', text?.id)
            }}
          />
        </Grid>
        <Grid item md={2} sm={1} xs={1}>
          <OPRDatePickerControl
            isRequired
            error={errors?.dateOfBirth}
            isEditable={isEditable}
            label="emp_profile_dob"
            name="dateOfBirth"
            optionalText="Optional"
            // value={values?.effectiveStartDate ? values?.effectiveStartDate?.toISOString() : null}
            value={values?.dateOfBirth || null}
            onChange={(date) => {
              handleOnChange('dateOfBirth', date)
            }}
          />
        </Grid>
        {
          viewUrl ? (
            <Grid item md={2} sm={1} xs={1}>
              <OPRInputControl
                error={errors?.passportNumber}
                isEditable={isEditable}
                label="Age"
                name="age"
                optionalText="Optional"
                value={calculateAge(values?.dateOfBirth)}
                onChange={handleChange}
              />
            </Grid>
          )
            : <Grid item md={2} sm={1} xs={1} />
        }

        <Grid item md={2} sm={1} xs={1}>
          <OPRInputControl
            error={errors?.passportNumber}
            isEditable={isEditable}
            label="emp_profile_pp_num"
            name="passportNumber"
            optionalText="Optional"
            value={values?.passportNumber}
            onChange={handleChange}
          />
        </Grid>
        {/* <Grid item md={2} sm={1} xs={1}>
          <OPRInputControl
            error={errors?.passportNumber}
            isEditable={isEditable}
            label="emp_profile_pp_num"
            name="passportNumber"
            value={values?.passportNumber}
            onChange={handleChange}
          />
        </Grid> */}
        <Grid item md={2} sm={1} xs={1}>
          <OPRInputControl
            error={errors?.passportIssueCountry}
            isEditable={isEditable}
            label="emp_profile_pp_issue_country"
            name="passportIssueCountry"
            value={values?.passportIssueCountry}
            onChange={handleChange}
          />
        </Grid>
        <Grid item md={2} sm={1} xs={1}>
          <OPRSelectorControl
            error={errors?.maritalStatus}
            isEditable={isEditable}
            keyName="name"
            label="Marital Status"
            name="name"
            options={mariatalStatusList}
            value={mariatalStatusList?.find((o:any) => o?.value === filterByValueOrFirstLetter(mariatalStatusList, 'value', values?.maritalStatus)?.value)}
            valueKey="value"
            onChange={(text:any) => {
              handleOnChange('maritalStatus', text?.value)
            }}
          />
        </Grid>
        <Grid item md={2} sm={1} xs={1} />
        {
          // JSON.parse(JSON.stringify(allPosts?.records || []))
        }
        <Grid item md={2} sm={1} xs={1}>
          <OPRInputControl
            error={errors?.spouseName}
            isEditable={isEditable}
            label="employee_profile_spouse_Name"
            name="spouseName"
            optionalText="Optional"
            value={values?.spouseName}
            onChange={handleChange}
          />

        </Grid>
        <Grid item md={2} sm={1} xs={1}>
          <OPRInputControl
            error={errors?.spouseIdentityNumber}
            isEditable={isEditable}
            label="employee_profile_spouse_Identity_Number"
            name="spouseIdentityNumber"
            optionalText="Optional"
            value={values?.spouseIdentityNumber}
            onChange={handleChange}
          />
        </Grid>
        <Grid item md={2} sm={1} xs={1}>
          <OPRInputControl
            error={errors?.spousePassportNumber}
            isEditable={isEditable}
            label="employee_profile_spouse_Passport_Number"
            name="spousePassportNumber"
            optionalText="Optional"
            value={values?.spousePassportNumber}
            onChange={handleChange}
          />
        </Grid>
        <Grid item md={2} sm={1} xs={1}>
          <OPRInputControl
            error={errors?.spousePassportIssueCountry}
            isEditable={isEditable}
            label="employee_profile_spouse_Passport_Issue_Country"
            name="spousePassportIssueCountry"
            // optionalText="Optional"
            value={values?.spousePassportIssueCountry}
            onChange={handleChange}
          />
        </Grid>
        <Grid item md={2} sm={1} xs={1}>
          <OPRSelectorControl
            error={errors?.visaHolderIndicator}
            isEditable={isEditable}
            keyName="name"
            label="emp_profile_visa_holder_indicator"
            name="name"
            optionalText="Optional"
            options={[{ name: 'Yes', value: 'Yes' }, { name: 'No', value: 'No' }]}
            value={[{ name: 'Yes', value: 'Yes' }, { name: 'No', value: 'No' }]?.find((o:any) => o?.value === values?.visaHolderIndicator)}
            valueKey="value"
            onChange={(text:any) => {
              handleOnChange('visaHolderIndicator', text?.value)
            }}
          />
        </Grid>
        {
          values?.visaHolderIndicator === 'Yes' ? (
            <>
              <Grid item md={2} sm={1} xs={1}>
                <OPRDatePickerControl
                  isRequired
                  error={errors?.visaIssueDate}
                  isEditable={isEditable}
                  label="emp_profile_visa_issue_date"
                  name="visaIssueDate"
                  optionalText="Optional"
                  // value={values?.effectiveStartDate ? values?.effectiveStartDate?.toISOString() : null}
                  value={values?.visaIssueDate || null}
                  onChange={(date:any) => {
                    handleOnChange('visaIssueDate', new Date(date))
                  }}
                />
              </Grid>
              <Grid item md={2} sm={1} xs={1}>
                <OPRDatePickerControl
                  isRequired
                  error={errors?.visaFirstLandingDate}
                  isEditable={isEditable}
                  label="emp_profile_visa_first_landing_date"
                  name="visaFirstLandingDate"
                  // value={values?.effectiveStartDate ? values?.effectiveStartDate?.toISOString() : null}
                  value={values?.visaFirstLandingDate || null}
                  onChange={(date:any) => {
                    handleOnChange('visaFirstLandingDate', new Date(date))
                  }}
                />
              </Grid>
              <Grid item md={2} sm={1} xs={1}>
                <OPRDatePickerControl
                  isRequired
                  error={errors?.visaExpiryDate}
                  isEditable={isEditable}
                  label="emp_profile_expiry_date"
                  name="visaExpiryDate"
                  optionalText="Optional"
                  // value={values?.effectiveStartDate ? values?.effectiveStartDate?.toISOString() : null}
                  value={values?.visaExpiryDate || null}
                  onChange={(date:any) => {
                    handleOnChange('visaExpiryDate', new Date(date))
                  }}
                />
              </Grid>
            </>
          ) : null
        }
        <Grid item md={2} sm={1} xs={1}>
          <OPRSelectorControl
            isRequired
            error={errors?.hsbcCountryCode}
            isEditable={isEditable}
            keyName="label"
            label="emp_profile_home_country"
            multiple={false}
            name="label"
            optionalText="Optional"
            options={countryDataList}
            placeholder="Select an option"
            value={countryDataList?.find((o:any) => o?.id === values.homeCountryId)}
            valueKey="label"
            onChange={(text:any) => {
              handleOnChange('homeCountryId', text?.id)
            }}

            // disabled={values?.bankFileFormat !== 'HSBC IFILE - Priority Payment'}

            // optionalText="Optional"
          />
        </Grid>
      </OPRResponsiveGrid>
    </Box>
  )
})

export default PersonalInformation
