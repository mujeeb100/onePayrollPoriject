import { Box, Grid } from '@mui/material'
import { useGetAllEmployeeProfileQuery, useGetAllPersonQuery } from 'api/employeeServices'
import OPRLabel from 'components/atoms/label/OPRLabel'
import OPRInputControl from 'components/molecules/OPRInputControl'
import OPRResponsiveGrid from 'components/molecules/OPRResponsiveGrid'
import OPRSelectorControl from 'components/molecules/OPRSelectorControl/OPRSelectorControl'
import { forwardRef } from 'react'
import { generateFilterUrl } from 'utils'

import { employeeStatus, payrollIndicator } from '../../dataTransfer'

interface MessageProps {
    text?: string;
    important?: boolean;
  }

const EmployeeInformation = forwardRef(({
  isEditable,
  setEditable,
  id,
  values,
  errors,
  handleChange,
  handleOnChange,
  viewUrl,
}:any, ref) => {
  const {
    data: employeeDataList,
    isLoading: isLoadingEmployeeDataList,
    isSuccess: isSuccessEmployeeDataList,
    isError: isErrorEmployeeDataList,
    error: errorEmployeeDataList,
    refetch: refetchEmployeeDataList,
  } = useGetAllEmployeeProfileQuery(generateFilterUrl({
    EffectiveDate: '10/10/2040',
    pageSize: 1000,
  }))
  const {
    data: allPosts,
    isLoading: isLoadingAllPosts,
    isSuccess: isSuccessAllPosts,
    isError: isErrorAllPosts,
    error: errorAllPosts,
    refetch: refetchAllPosts,
  } = useGetAllPersonQuery(generateFilterUrl({
    pageSize: 1000,
  }))

  return (
    <Box>

      <OPRLabel variant="h1">Employee Information</OPRLabel>
      <OPRResponsiveGrid>
        <Grid item md={2} sm={1} xs={1}>
          <OPRInputControl
            error={errors?.surname}
            isEditable={isEditable}
            label="employee_profile_surname"
            name="surname"
            value={values?.surname}
            onChange={handleChange}
          />
        </Grid>
        <Grid item md={2} sm={1} xs={1}>
          <OPRInputControl
            error={errors?.givenName}
            isEditable={isEditable}
            label="employee_profile_given_name"
            name="givenName"
            value={values?.givenName}
            onChange={handleChange}
          />
        </Grid>
        <Grid item md={2} sm={1} xs={1}>
          <OPRInputControl
            disabled
            error={errors?.employeeCode}
            isEditable={isEditable}
            label="Employee Id"
            name="employeeCode"
            value={values?.employeeCode}
            onChange={handleChange}
          />
          {/* <OPRSelectorControl
            disabled
            isRequired
            error={errors?.employeeCode}
            isEditable={isEditable}
            keyName="employeeCode"
            label="employee_bank_account_employee_profile_id"
            multiple={false}
            name="employeeCode"
            options={JSON.parse(JSON.stringify(employeeDataList?.records || []))}
            placeholder="Select an option"
            value={JSON.parse(JSON.stringify(employeeDataList?.records || []))?.find((o:any) => o?.id === id) || {}}
            valueKey="employeeCode"
            onChange={(text:any) => {
              handleOnChange('employeeCodeId', text?.id)
            }}
          /> */}
        </Grid>
        <Grid item md={2} sm={1} xs={1}>
          <OPRInputControl
            error={errors?.globalID}
            isEditable={isEditable}
            label="employee_profile_global_ID"
            name="globalID"
            optionalText="Optional"
            value={values?.globalID}
            onChange={handleChange}
          />
        </Grid>
        {
          // JSON.parse(JSON.stringify(allPosts?.records || []))
        }
        {viewUrl && (
          <Grid item md={2} sm={1} xs={1}>
            <OPRInputControl
              disabled
              error={errors?.personID}
              isEditable={isEditable}
              label="person_id"
              name="personID"
              value={values?.personID}
              onChange={handleChange}
            />
            {/* <OPRSelectorControl
            isRequired
            error={errors?.employeeCode}
            isEditable={isEditable}
            keyName="personName"
            label="person_id"
            multiple={false}
            name="personName"
            options={JSON.parse(JSON.stringify(allPosts?.records || []))}
            placeholder="Select an option"
            value={JSON.parse(JSON.stringify(allPosts?.records || []))?.find((o:any) => o?.id === values?.personID)}
            valueKey="personName"
            onChange={(text:any) => {
              handleOnChange('personID', text?.id)
            }}
          /> */}
          </Grid>
        )}
        <Grid item md={2} sm={1} xs={1}>
          {/* <OPRInputControl
            error={errors?.employmentStatus}
            isEditable={isEditable}
            label="employee_profile_employment_status"
            name="employmentStatus"
            value={values?.employmentStatus}
            onChange={handleChange}
          /> */}
          <OPRSelectorControl
            error={errors?.visaHolderIndicator}
            isEditable={isEditable}
            keyName="name"
            label="employee_profile_employment_status"
            name="name"
            options={employeeStatus}
            value={employeeStatus?.find((o:any) => o?.value === values?.employmentStatus)}
            valueKey="value"
            onChange={(text:any) => {
              handleOnChange('employmentStatus', text?.value)
            }}
          />
        </Grid>
        <Grid item md={2} sm={1} xs={1}>
          {/* <OPRInputControl
            error={errors?.payrollIndicator}
            isEditable={isEditable}
            label="employee_profile_payroll_indicator"
            name="payrollIndicator"
            value={values?.payrollIndicator}
            onChange={handleChange}
          /> */}
          <OPRSelectorControl
            error={errors?.visaHolderIndicator}
            isEditable={isEditable}
            keyName="name"
            label="employee_profile_payroll_indicator"
            name="name"
            options={payrollIndicator}
            value={payrollIndicator?.find((o:any) => o?.value === values?.payrollIndicator)}
            valueKey="value"
            onChange={(text:any) => {
              handleOnChange('payrollIndicator', text?.value)
            }}
          />
        </Grid>

      </OPRResponsiveGrid>
    </Box>
  )
})

export default EmployeeInformation
