import { Box, Grid } from '@mui/material'
import OPRLabel from 'components/atoms/label/OPRLabel'
import OPRInputControl from 'components/molecules/OPRInputControl'
import OPRResponsiveGrid from 'components/molecules/OPRResponsiveGrid'
import OPRSelectorControl from 'components/molecules/OPRSelectorControl/OPRSelectorControl'
import { forwardRef } from 'react'

import { employeeAreaCode } from '../../dataTransfer'

interface MessageProps {
    text?: string;
    important?: boolean;
  }

const ContactInformation = forwardRef(({
  isEditable,
  setEditable,
  id,
  rowData,
  values,
  errors,
  handleChange,
  handleOnChange,
  viewUrl,
}:any, ref) => (
  <Box>

    <OPRLabel variant="h1">Contact Information</OPRLabel>
    <OPRResponsiveGrid>
      <Grid item md={2} sm={1} xs={1}>
        <OPRInputControl
          error={errors?.workEmailAddress}
          isEditable={isEditable}
          label="employee_profile_work_email_address"
          name="workEmailAddress"
          optionalText="Optional"
          value={values?.workEmailAddress}
          onChange={handleChange}
        />
      </Grid>
      <Grid item md={2} sm={1} xs={1}>
        <OPRInputControl
          error={errors?.personalEmailAddress}
          isEditable={isEditable}
          label="employee_profile_personal_email_address"
          name="personalEmailAddress"
          optionalText="Optional"
          value={values?.personalEmailAddress}
          onChange={handleChange}
        />
      </Grid>
      <Grid item md={2} sm={1} xs={1}>
        <OPRInputControl
          error={errors?.mobileNumber}
          isEditable={isEditable}
          label="employee_profile_mobile_number"
          name="mobileNumber"
          optionalText="Optional"
          value={values?.mobileNumber}
          onChange={handleChange}
        />
      </Grid>
      <Grid item md={2} sm={1} xs={1}>
        <OPRInputControl
          error={errors?.homePhoneNumber}
          isEditable={isEditable}
          label="employee_profile_home_phone_number"
          name="homePhoneNumber"
          optionalText="Optional"
          value={values?.homePhoneNumber}
          onChange={handleChange}
        />
      </Grid>
      {
        // JSON.parse(JSON.stringify(allPosts?.records || []))
      }
      <Grid item md={2} sm={1} xs={1}>
        <OPRInputControl
          error={errors?.officePhoneNumber}
          isEditable={isEditable}
          label="employee_profile_office_phone_number"
          name="officePhoneNumber"
          optionalText="Optional"
          value={values?.officePhoneNumber}
          onChange={handleChange}
        />

      </Grid>
      <Grid item md={2} sm={1} xs={1} />
      <Grid item md={12} sm={1} xs={1}>
        <OPRInputControl
          multiline
          error={errors?.residentialAddress}
          isEditable={isEditable}
          label="employee_profile_residential_address"
          name="residentialAddress"
          value={values?.residentialAddress}
          onChange={handleChange}
        />
      </Grid>
      <Grid item md={2} sm={1} xs={1}>
        {/* <OPRInputControl
          error={errors?.areaCode}
          isEditable={isEditable}
          label="emp_profile_area_code"
          name="areaCode"
          value={values?.areaCode}
          onChange={handleChange}
        /> */}
        <OPRSelectorControl
          error={errors?.visaHolderIndicator}
          isEditable={isEditable}
          keyName="name"
          label="emp_profile_area_code"
          name="name"
          options={employeeAreaCode}
          value={employeeAreaCode?.find((o:any) => o?.value === values?.areaCode)}
          valueKey="value"
          onChange={(text:any) => {
            handleOnChange('areaCode', text?.value)
          }}
        />
      </Grid>
      <Grid item md={2} sm={1} xs={1} />
      <Grid item md={12} sm={1} xs={1}>
        <OPRInputControl
          multiline
          error={errors?.postalAddress}
          isEditable={isEditable}
          label="employee_prfile_post_address"
          name="postalAddress"
          optionalText="Optional"
          value={values?.postalAddress}
          onChange={handleChange}
        />
      </Grid>
    </OPRResponsiveGrid>
  </Box>
))

export default ContactInformation
