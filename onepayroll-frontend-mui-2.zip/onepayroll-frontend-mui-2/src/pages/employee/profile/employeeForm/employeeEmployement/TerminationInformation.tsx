import { Box, Grid } from '@mui/material'
import { useGetAllWorkCalenderQuery } from 'api/entityServices'
import { useGetAllCurrencyQuery, useGetAllProviderTypeQuery } from 'api/globalServices'
import OPRLabel from 'components/atoms/label/OPRLabel'
import OPRDatePickerControl from 'components/molecules/OPRDatePickerControl/OPRDatePickerControl'
import OPRInputControl from 'components/molecules/OPRInputControl'
import OPRResponsiveGrid from 'components/molecules/OPRResponsiveGrid'
import { forwardRef } from 'react'
import { generateFilterUrl } from 'utils'

interface MessageProps {
    text?: string;
    important?: boolean;
  }

const TerminationInformation = forwardRef(({
  isEditable,
  setEditable,
  values,
  errors,
  handleChange,
  handleOnChange,
  id,
  viewUrl,
}:any, ref) => {
  const {
    data: allPosts,
    isLoading: isLoadingAllPosts,
    isSuccess: isSuccessAllPosts,
    isError: isErrorAllPosts,
    error: errorAllPosts,
    refetch: refetchAllPosts,
  } = useGetAllWorkCalenderQuery(generateFilterUrl({
    pageSize: 1000,
  }))
  const {
    data: currencyData,
    isLoading: isLoadingCurrencyDatas,
    isSuccess: isSuccessCurrencyData,
    isError: isErrorCurrencyData,
    error: errorCurrencyData,
    refetch: refetchCurrencyData,
  } = useGetAllCurrencyQuery(generateFilterUrl({
    pageSize: 1000,
  }))
  const {
    data: providerTypeData,
    isLoading: isLoadingProviderTypeData,
    isSuccess: isSuccessProviderTypeData,
    isError: isErrorProviderTypeData,
    error: errorProviderTypeData,
    refetch: refetchProviderTypeData,
  } = useGetAllProviderTypeQuery(generateFilterUrl({
    pageSize: 1000,
  }))

  return (
    <Box>

      <OPRLabel variant="h1">Termination information</OPRLabel>
      <OPRResponsiveGrid>
        <Grid item md={2} sm={1} xs={1}>
          <OPRDatePickerControl
            isRequired
            dateFormate="MM/DD/YYYY"
            error={errors?.lastEmploymentDate}
            isEditable={isEditable}
            label="employee_profile_last_working_date"
            name="dateJoinGroup"
            // value={values?.effectiveStartDate ? values?.effectiveStartDate?.toISOString() : null}
            value={values?.lastEmploymentDate || null}
            onChange={(date) => {
              handleOnChange('lastEmploymentDate', date)
            }}
          />
        </Grid>
        <Grid item md={2} sm={1} xs={1}>
          <OPRDatePickerControl
            isRequired
            dateFormate="MM/DD/YYYY"
            error={errors?.resignationDate}
            isEditable={isEditable}
            label="employee_profile_resignation_date"
            name="resignationDate"
            // value={values?.effectiveStartDate ? values?.effectiveStartDate?.toISOString() : null}
            value={values?.resignationDate || null}
            onChange={(date) => {
              handleOnChange('resignationDate', date)
            }}
          />
        </Grid>
        <Grid item md={2} sm={1} xs={1}>
          <OPRDatePickerControl
            isRequired
            dateFormate="MM/DD/YYYY"
            error={errors?.lastWorkingDate}
            isEditable={isEditable}
            label="employee_profile_last_working_date_text"
            name="dateJoinGroup"
            // value={values?.effectiveStartDate ? values?.effectiveStartDate?.toISOString() : null}
            value={values?.lastWorkingDate || null}
            onChange={(date) => {
              handleOnChange('lastWorkingDate', date)
            }}
          />
        </Grid>
        <Grid item md={2} sm={1} xs={1}>
          <OPRDatePickerControl
            isRequired
            dateFormate="MM/DD/YYYY"
            error={errors?.noticePeriodEndDate}
            isEditable={isEditable}
            label="employee_profile_resignation_date_text"
            name="noticePeriodEndDate"
            // value={values?.effectiveStartDate ? values?.effectiveStartDate?.toISOString() : null}
            value={values?.noticePeriodEndDate || null}
            onChange={(date) => {
              handleOnChange('noticePeriodEndDate', date)
            }}
          />
        </Grid>
        <Grid item md={12} sm={1} xs={1}>
          <OPRDatePickerControl
            isRequired
            dateFormate="MM/DD/YYYY"
            error={errors?.payThroughDate}
            isEditable={isEditable}
            label="employee_profile_pay_through_date"
            name="payThroughDate"
            // value={values?.effectiveStartDate ? values?.effectiveStartDate?.toISOString() : null}
            value={values?.payThroughDate || null}
            onChange={(date) => {
              handleOnChange('payThroughDate', date)
            }}
          />
        </Grid>
        <Grid item md={2} sm={1} xs={1}>

          <OPRInputControl
            error={errors?.terminationCode}
            isEditable={isEditable}
            label="employee_profile_termination_code"
            name="terminationCode"
            value={values?.terminationCode}
            onChange={handleChange}
          />
        </Grid>

        <Grid item md={2} sm={1} xs={1}>
          <OPRInputControl
            error={errors?.terminationReason}
            isEditable={isEditable}
            label="ent_termination_reason"
            name="terminationReason"
            value={values?.terminationReason}
            onChange={handleChange}
          />

        </Grid>
      </OPRResponsiveGrid>
    </Box>
  )
})

export default TerminationInformation
