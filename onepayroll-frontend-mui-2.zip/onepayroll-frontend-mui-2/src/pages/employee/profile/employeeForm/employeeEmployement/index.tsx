import { Box } from '@mui/material'
import { forwardRef } from 'react'

import EmploymentInformation from './EmploymentInformation'
import OrganizationUnit from './OrganizationUnit'
import RemunerationInformation from './RemunerationInformation'
import TerminationInformation from './TerminationInformation'

interface MessageProps {
    text?: string;
    important?: boolean;
  }

const EmployementEmployeeForm = forwardRef(({
  isEditable,
  setEditable,
  values,
  id,
  handleChange,
  handleOnChange,
  errors,
  terminationList,
  viewUrl,
}:any, ref) => (
  <Box>
    <EmploymentInformation
      errors={errors}
      handleChange={handleChange}
      handleOnChange={handleOnChange}
      isEditable={isEditable}
      values={values}
      viewUrl={viewUrl}
    />
    {viewUrl && (
      <OrganizationUnit
        errors={errors}
        handleChange={handleChange}
        handleOnChange={handleOnChange}
        isEditable={isEditable}
        values={values}
        viewUrl={viewUrl}
      />
    )}
    <RemunerationInformation
      errors={errors}
      handleChange={handleChange}
      handleOnChange={handleOnChange}
      isEditable={isEditable}
      values={values}
      viewUrl={viewUrl}
    />
    {isEditable ? <TerminationInformation isEditable={isEditable} values={terminationList} /> : ''}
  </Box>
))

export default EmployementEmployeeForm
