import { Box, Grid } from '@mui/material'
import { useGetAllGradeQuery, useGetAllPositionQuery, useGetAllStaffTypeQuery } from 'api/entityServices'
import OPRLabel from 'components/atoms/label/OPRLabel'
import OPRDatePickerControl from 'components/molecules/OPRDatePickerControl/OPRDatePickerControl'
import OPRInputControl from 'components/molecules/OPRInputControl'
import OPRResponsiveGrid from 'components/molecules/OPRResponsiveGrid'
import OPRSelectorControl from 'components/molecules/OPRSelectorControl/OPRSelectorControl'
import { forwardRef } from 'react'
import { generateFilterUrl } from 'utils'

import { defaultPageSize } from '../../../../../constants'

interface MessageProps {
    text?: string;
    important?: boolean;
  }

const EmploymentInformation = forwardRef(({
  isEditable,
  setEditable,
  values,
  errors,
  handleChange,
  handleOnChange,
  id,
  viewUrl,
}:any, ref) => {
  const {
    data: allPosts,
    isLoading: isLoadingAllPosts,
    isSuccess: isSuccessAllPosts,
    isError: isErrorAllPosts,
    error: errorAllPosts,
    refetch: refetchAllPosts,
  } = useGetAllPositionQuery(generateFilterUrl(defaultPageSize))
  const {
    data: entityGradeData,
    isLoading: isLoadingEntityGradeData,
    isSuccess: isSuccessEntityGradeData,
    isError: isErrorEntityGradeData,
    error: errorEntityGradeData,
    refetch: refetchEntityGradeData,
  } = useGetAllGradeQuery(generateFilterUrl(defaultPageSize))
  const {
    data: allStaffData,
    isLoading: isLoadingStaffData,
    isSuccess: isSuccessStaffData,
    isError: isErrorStaffData,
    error: errorStaffData,
    refetch: refetchStaffData,
  } = useGetAllStaffTypeQuery(generateFilterUrl(defaultPageSize))

  return (
    <Box>

      <OPRLabel variant="h1">Employment Information</OPRLabel>
      <OPRResponsiveGrid>
        {viewUrl && (
          <Grid item md={2} sm={1} xs={1}>
            <OPRDatePickerControl
              isRequired
              error={errors?.commencementDate}
              isEditable={isEditable}
              label="employee_profile_commencement_date"
              name="commencementDate"
              // value={values?.effectiveStartDate ? values?.effectiveStartDate?.toISOString() : null}
              value={values?.commencementDate || null}
              onChange={(date) => {
                handleOnChange('commencementDate', date)
              }}
            />
          </Grid>
        )}
        {viewUrl && (
          <Grid item md={2} sm={1} xs={1}>
            <OPRDatePickerControl
              isRequired
              error={errors?.dateJoinGroup}
              isEditable={isEditable}
              label="employee_profile_date_join_group"
              name="dateJoinGroup"
              // value={values?.effectiveStartDate ? values?.effectiveStartDate?.toISOString() : null}
              value={values?.dateJoinGroup || null}
              onChange={(date) => {
                handleOnChange('dateJoinGroup', date)
              }}
            />
          </Grid>
        )}
        {viewUrl && (
          <Grid item md={2} sm={1} xs={1}>
            <OPRDatePickerControl
              isRequired
              error={errors?.startDate418}
              isEditable={isEditable}
              label="418 Start Date"
              name="startDate418"
              // value={values?.effectiveStartDate ? values?.effectiveStartDate?.toISOString() : null}
              value={values?.startDate418 || null}
              onChange={(date) => {
                handleOnChange('startDate418', date)
              }}
            />
          </Grid>
        )}
        <Grid item md={2} sm={1} xs={1}>
          <OPRSelectorControl
            isRequired
            error={errors?.yearOfServiceOption}
            isEditable={isEditable}
            keyName="name"
            label="employee_profile_year_of_service"
            multiple={false}
            name="name"
            optionalText="Optional"
            options={[{ name: 'Commencement Date', value: 'Commencement Date' }, { name: 'Date Join Group', value: 'Date Join Group' }, { name: '418 Start Date', value: '418 Start Date' }]}
            value={[{ name: 'Commencement Date', value: 'Commencement Date' }, { name: 'Date Join Group', value: 'Date Join Group' }, { name: '418 Start Date', value: '418 Start Date' }].find((o:any) => o?.value === values?.yearOfServiceOption)}
            valueKey="value"
            onChange={(text:any) => {
              handleOnChange('yearOfServiceOption', text?.value)
            }}
          />
        </Grid>
        {
          // JSON.parse(JSON.stringify(allPosts?.records || []))
        }
        {viewUrl && (
          <Grid item md={2} sm={1} xs={1}>
            <OPRInputControl
              error={errors?.YearOfService}
              isEditable={isEditable}
              label="Year Of Service"
              name="yearOfService"
              value={values?.yearOfService}
              onChange={handleChange}
            />

          </Grid>
        )}
        {viewUrl && (
          <Grid item md={2} sm={1} xs={1}>
            <OPRInputControl
              error={errors?.monthOfService}
              isEditable={isEditable}
              label="employee_profile_month_of_service"
              name="monthOfService"
              value={values?.monthOfService}
              onChange={handleChange}
            />
          </Grid>
        )}
        <Grid item md={2} sm={1} xs={1}>
          <OPRSelectorControl
            isRequired
            error={errors?.receivePayslipMethod}
            isEditable={isEditable}
            keyName="name"
            label="emp_profile_recieve_payslip_method"
            multiple={false}
            name="name"
            optionalText="Optional"
            options={[{ name: 'Hardcopy', value: 'Hardcopy' }, { name: 'Email', value: 'Email' }, { name: 'ESS Portal', value: '4ESS Portal' }]}
            value={[{ name: 'Hardcopy', value: 'Hardcopy' }, { name: 'Email', value: 'Email' }, { name: 'ESS Portal', value: '4ESS Portal' }].find((o:any) => o?.value === values?.receivePayslipMethod)}
            valueKey="value"
            onChange={(text:any) => {
              handleOnChange('receivePayslipMethod', text?.value)
            }}
          />
        </Grid>
        <Grid item md={2} sm={1} xs={1}>
          <OPRSelectorControl
            isRequired
            error={errors?.probationType}
            isEditable={isEditable}
            keyName="name"
            label="employee_profile_probation_type"
            multiple={false}
            name="name"
            optionalText="Optional"
            options={[{ name: 'Month', value: 'Month' }, { name: 'Day', value: 'Day' }]}
            value={[{ name: 'Month', value: 'Month' }, { name: 'Day', value: 'Day' }].find((o:any) => o?.value === values?.probationType)}
            valueKey="value"
            onChange={(text:any) => {
              handleOnChange('probationType', text?.value)
            }}
          />
        </Grid>
        {viewUrl && (
          <Grid item md={2} sm={1} xs={1}>
            <OPRInputControl
              isEditable
              isRequired
              error={errors?.probationUnit}
              label="employee_profile_probation_unit"
              name="probationUnit"
              value={values?.probationUnit || null}
              onChange={handleChange}
            />
          </Grid>
        )}
        {viewUrl && (
          <Grid item md={2} sm={1} xs={1}>
            <OPRDatePickerControl
              isRequired
              error={errors?.probationDate}
              isEditable={isEditable}
              label="employee_profile_probation_date"
              name="probationDate"
              optionalText="Optional"
              // value={values?.effectiveStartDate ? values?.effectiveStartDate?.toISOString() : null}
              value={values?.probationDate || null}
              onChange={(date) => {
                handleOnChange('probationDate', date)
              }}
            />
          </Grid>
        )}

        {
          // JSON.parse(JSON.stringify(allPosts?.records || []))
        }
        {viewUrl && (
          <Grid item md={2} sm={1} xs={1}>
            <OPRSelectorControl
              isRequired
              error={errors?.positionCode}
              isEditable={isEditable}
              keyName="positionCode"
              label="employee_profile_position"
              multiple={false}
              name="positionCode"
              options={JSON.parse(JSON.stringify(allPosts?.records || []))}
              value={JSON.parse(JSON.stringify(allPosts?.records || [])).find((o:any) => o?.positionCode === values?.positionCode)}
              valueKey="positionCode"
              onChange={(text:any) => {
                handleOnChange('positionCode', text?.positionCode)
              }}
            />
          </Grid>
        )}
        {viewUrl && (
          <Grid item md={2} sm={1} xs={1}>
            <OPRSelectorControl
              isRequired
              error={errors?.gradeCode}
              isEditable={isEditable}
              keyName="gradeCode"
              label="employee_profile_grade"
              multiple={false}
              name="gradeCode"
              options={JSON.parse(JSON.stringify(entityGradeData?.records || []))}
              value={JSON.parse(JSON.stringify(entityGradeData?.records || [])).find((o:any) => o?.gradeCode === values?.gradeCode)}
              valueKey="gradeCode"
              onChange={(text:any) => {
                handleOnChange('gradeCode', text?.gradeCode)
              }}
            />
          </Grid>
        )}
        {viewUrl && (
          <Grid item md={2} sm={1} xs={1}>
            <OPRSelectorControl
              isRequired
              error={errors?.staffTypeCode}
              isEditable={isEditable}
              keyName="staffTypeCode"
              label="employee_profile_staff_type"
              multiple={false}
              name="staffTypeCode"
              options={JSON.parse(JSON.stringify(allStaffData?.records || []))}
              value={JSON.parse(JSON.stringify(allStaffData?.records || [])).find((o:any) => o?.staffTypeCode === values?.staffTypeCode)}
              valueKey="staffTypeCode"
              onChange={(text:any) => {
                handleOnChange('staffTypeCode', text?.staffTypeCode)
              }}
            />
          </Grid>
        )}
      </OPRResponsiveGrid>
    </Box>
  )
})

export default EmploymentInformation
