import { Box, Grid } from '@mui/material'
import { useGetAllEmployeeRecurringDropDownQuery } from 'api/employeeServices'
import { useGetAllWorkCalenderQuery } from 'api/entityServices'
import { useGetAllCurrencyQuery, useGetAllPaymentMethodQuery } from 'api/globalServices'
import OPRLabel from 'components/atoms/label/OPRLabel'
import OPRDatePickerControl from 'components/molecules/OPRDatePickerControl/OPRDatePickerControl'
import OPRInputControl from 'components/molecules/OPRInputControl'
import OPRResponsiveGrid from 'components/molecules/OPRResponsiveGrid'
import OPRSelectorControl from 'components/molecules/OPRSelectorControl/OPRSelectorControl'
import { forwardRef } from 'react'
import { generateFilterUrl } from 'utils'

interface MessageProps {
    text?: string;
    important?: boolean;
  }

const RemunerationInformation = forwardRef(({
  isEditable,
  setEditable,
  values,
  errors,
  handleChange,
  handleOnChange,
  id,
  viewUrl,
}:any, ref) => {
  const {
    data: allPosts,
    isLoading: isLoadingAllPosts,
    isSuccess: isSuccessAllPosts,
    isError: isErrorAllPosts,
    error: errorAllPosts,
    refetch: refetchAllPosts,
  } = useGetAllWorkCalenderQuery(generateFilterUrl({
    pageSize: 1000,
  }))
  const {
    data: currencyData,
    isLoading: isLoadingCurrencyDatas,
    isSuccess: isSuccessCurrencyData,
    isError: isErrorCurrencyData,
    error: errorCurrencyData,
    refetch: refetchCurrencyData,
  } = useGetAllCurrencyQuery(generateFilterUrl({
    pageSize: 1000,
  }))
  const {
    data: providerTypeData,
    isLoading: isLoadingProviderTypeData,
    isSuccess: isSuccessProviderTypeData,
    isError: isErrorProviderTypeData,
    error: errorProviderTypeData,
    refetch: refetchProviderTypeData,
  } = useGetAllPaymentMethodQuery(generateFilterUrl({
    pageSize: 1000,
  }))

  const {
    data: allPostsPaymentMethod,
    error: createAllPostsBankAccountErrorPaymentMethod,
    isLoading: isLoadingAllPostsPaymentMethod,
    isSuccess: isSuccessAllPostsPaymentMethod,
    isError: isErrorAllPostsPaymentMethod,
    error: errorAllPostsPaymentMethod,
  } = useGetAllEmployeeRecurringDropDownQuery(generateFilterUrl({
    pageSize: 1000,
  }))
  console.log(values.eaoCalculationMethod, 'eaoCalculationMethodeaoCalculationMethodeaoCalculationMethod')

  return (
    <Box>

      <OPRLabel variant="h1">Remuneration Information</OPRLabel>
      <OPRResponsiveGrid>
        {viewUrl && (
          <Grid item md={12} sm={1} xs={1}>
            <OPRSelectorControl
              isRequired
              error={errors?.workCalendarCode}
              isEditable={isEditable}
              keyName="workCalendarCode"
              label="emp_profile_work_calender"
              multiple={false}
              name="workCalendarCode"
              options={JSON.parse(
                JSON.stringify(allPosts?.records || []),
              )}
              value={allPosts?.records?.find((o:any) => o?.workCalendarCode === values.workCalendarCode)}
              valueKey="workCalendarCode"
              onChange={(text:any) => {
                handleOnChange('workCalendarCode', text?.workCalendarCode)
              }}
            />
          </Grid>
        )}

        {
          viewUrl && (
            <Grid item md={2} sm={1} xs={1}>
              <OPRSelectorControl
                isRequired
                error={errors?.cawCalculationMethod}
                isEditable={isEditable}
                keyName="label"
                label="CAW calculation method - One day wage based on"
                multiple={false}
                name="label"
                options={JSON.parse(JSON.stringify(allPostsPaymentMethod?.salaryProrationMethods || []))}
                value={JSON.parse(JSON.stringify(allPostsPaymentMethod?.salaryProrationMethods || []))?.find((o:any) => o?.label === values?.cawCalculationMethod)}
                valueKey="label"
                onChange={(text:any) => {
                  handleOnChange('cawCalculationMethod', text?.id)
                }}
              />
            </Grid>
          )
        }
        {/* <Grid item md={2} sm={1} xs={1}>
          <OPRInputControl
            disabled={!(values?.cawCalculationMethod === 'Required if CAW Calculation Method selects "Base Salary / Fixed Days' || values?.cawCalculationMethod === 'Required if CAW Calculation Method selects "Base Salary / Fixed Days')}
            error={errors?.cawCalculationMethodDivideByFixedDays}
            isEditable={isEditable}
            label="CAW Calculation Method - Divide by Fixed Days"
            name="cawCalculationMethodDivideByFixedDays"
            optionalText="Optional"
            value={values?.cawCalculationMethodDivideByFixedDays}
            onChange={handleChange}
          />
        </Grid> */}
        {
          !(values?.cawCalculationMethod === 'Required if CAW Calculation Method selects "Base Salary / Fixed Days' || values?.cawCalculationMethod === 'Base Salary * 12 / Fixed Days') ? <Grid item md={2} sm={1} xs={1} /> : (
            <>
              <Grid item md={2} sm={1} xs={1}>
                <OPRInputControl
                  disabled={!(values?.cawCalculationMethod === 'Base Salary / Fixed Days' || values?.cawCalculationMethod === 'Base Salary * 12 / Fixed Days')}
                  error={errors?.cawCalculationMethodDivideByFixedDays}
                  isEditable={isEditable}
                  label="CAW Calculation Method - Divide by Fixed Days"
                  name="CAW Calculation Method - Divide by Fixed Days"
                  optionalText="Optional"
                  value={values?.cawCalculationMethodDivideByFixedDays}
                  onChange={handleChange}
                />
              </Grid>
              {' '}

            </>
          )
        }

        <Grid item md={2} sm={1} xs={1}>
          <OPRSelectorControl
            isRequired
            error={errors?.holdPayment}
            isEditable={isEditable}
            keyName="name"
            label="emp_profile_hold_payment"
            multiple={false}
            name="name"
            options={[{ name: 'Yes', value: 'Yes' }, { name: 'No', value: 'No' }]}
            value={[{ name: 'Yes', value: 'Yes' }, { name: 'No', value: 'No' }].find((o:any) => o?.value === values?.holdPayment)}
            valueKey="value"
            onChange={(text:any) => {
              handleOnChange('holdPayment', text?.value)
            }}
          />
        </Grid>
        <Grid item md={2} sm={1} xs={1}>
          <OPRSelectorControl
            isRequired
            error={errors?.currencyCode}
            isEditable={isEditable}
            keyName="currencyCode"
            label="emp_profile_payment_currency"
            multiple={false}
            name="currencyCode"
            options={JSON.parse(JSON.stringify(currencyData?.records || []))}
            value={JSON.parse(JSON.stringify(currencyData?.records || [])).find((o:any) => o?.id === values?.paymentCurrencyId)}
            valueKey="currencyCode"
            onChange={(text:any) => {
              handleOnChange('paymentCurrencyId', text?.id)
            }}
          />
        </Grid>
        {
          // JSON.parse(JSON.stringify(allPosts?.records || []))
        }
        <Grid item md={2} sm={1} xs={1}>
          <OPRSelectorControl
            isRequired
            error={errors?.paymentMethodCode}
            isEditable={isEditable}
            keyName="paymentMethodCode"
            label="emp_profile_payment_method"
            multiple={false}
            name="paymentMethodCode"
            optionalText="Optional"
            options={JSON.parse(JSON.stringify(providerTypeData?.records || []))}
            value={JSON.parse(JSON.stringify(providerTypeData?.records || [])).find((o:any) => o?.id === values?.paymentMethodId)}
            valueKey="paymentMethodCode"
            onChange={(text:any) => {
              handleOnChange('paymentMethodId', text?.id)
            }}
          />
        </Grid>
        <Grid item md={2} sm={1} xs={1}>
          <OPRSelectorControl
            isRequired
            error={errors?.eligible13thMonthSalary}
            isEditable={isEditable}
            keyName="name"
            label="emp_profile_eligible_month_salary"
            multiple={false}
            name="name"
            options={[{ name: 'Yes', value: 'Yes' }, { name: 'No', value: 'No' }]}
            value={[{ name: 'Yes', value: 'Yes' }, { name: 'No', value: 'No' }].find((o:any) => o?.value === values?.eligible13thMonthSalary)}
            valueKey="value"
            onChange={(text:any) => {
              handleOnChange('eligible13thMonthSalary', text?.value)
            }}
          />
        </Grid>
        <Grid item md={2} sm={1} xs={1}>
          <OPRSelectorControl
            isRequired
            error={errors?.eaoCalculationMethod}
            isEditable={isEditable}
            keyName="name"
            label="emp_profile_eoa_calculation_method"
            multiple={false}
            name="name"
            optionalText="Optional"
            options={[{ name: 'Not Applicable', value: 'Not Applicable' },
              { name: 'Yes, applicable with positive/negative EAO difference', value: 'Yes, applicable with positive/negative EAO difference' },
              { name: 'Yes, applicable with only positive EAO difference', value: 'Yes, applicable with only positive EAO difference' }]}
            value={[{ name: 'Not Applicable', value: 'Not Applicable' },
              { name: 'Yes, applicable with positive/negative EAO difference', value: 'Yes, applicable with positive/negative EAO difference' },
              { name: 'Yes, applicable with only positive EAO difference', value: 'Yes, applicable with only positive EAO difference' }].find((o:any) => o?.value === values?.eaoCalculationMethod)}
            valueKey="value"
            onChange={(text:any) => {
              handleOnChange('eaoCalculationMethod', text?.value)
            }}
          />
        </Grid>
        <Grid item md={2} sm={1} xs={1}>
          <OPRDatePickerControl
            isRequired
            error={errors?.eaoStatutoryHolidayPayStartDate}
            isEditable={isEditable}
            label="EAO Statutory Holiday Pay Start Date"
            name="EAOStatutoryHolidayPayStartDate"
            optionalText="Optional"
            // value={values?.effectiveStartDate ? values?.effectiveStartDate?.toISOString() : null}
            value={values?.eaoStatutoryHolidayPayStartDate || null}
            onChange={(date) => {
              handleOnChange('eaoStatutoryHolidayPayStartDate', date)
            }}
          />
        </Grid>
      </OPRResponsiveGrid>
    </Box>
  )
})

export default RemunerationInformation
