import { Box, Grid } from '@mui/material'
import {
  useGetAllCostCenterQuery, useGetAllDepartmentQuery, useGetAllDivisionQuery, useGetAllRegionQuery, useGetAllTeamQuery,
} from 'api/entityServices'
import OPRLabel from 'components/atoms/label/OPRLabel'
import OPRResponsiveGrid from 'components/molecules/OPRResponsiveGrid'
import OPRSelectorControl from 'components/molecules/OPRSelectorControl/OPRSelectorControl'
import { forwardRef } from 'react'
import { generateFilterUrl } from 'utils'

import { defaultPageSize } from '../../../../../constants'

interface MessageProps {
    text?: string;
    important?: boolean;
  }

const OrganizationUnit = forwardRef(({
  isEditable,
  setEditable,
  values,
  errors,
  handleChange,
  handleOnChange,
  id,
  viewUrl,
}:any, ref) => {
  const {
    data: divisionData,
    isLoading: isLoadingDivisionData,
    isSuccess: isSuccessDivisionData,
    isError: isErrorDivisionData,
    error: errorDivisionData,
    refetch: refetchDivisionData,
  } = useGetAllDivisionQuery(generateFilterUrl(defaultPageSize))
  const {
    data: coastCenterData,
    isLoading: isLoadingCoastCenterData,
    isSuccess: isSuccessCoastCenterData,
    isError: isErrorCenterData,
    error: errorCenterData,
    refetch: refetchCenterData,
  } = useGetAllCostCenterQuery(generateFilterUrl(defaultPageSize))
  const {
    data: entityDeptData,
    isLoading: isLoadingEntityDeptData,
    isSuccess: isSuccessEntityDeptData,
    isError: isErrorEntityDeptData,
    error: errorEntityDeptData,
    refetch: refetchEntityDeptData,
  } = useGetAllDepartmentQuery(generateFilterUrl(defaultPageSize))
  const {
    data: teamsData,
    isLoading: isLoadingTeamsData,
    isSuccess: isSuccessTeamsData,
    isError: isErrorTeamsData,
    error: errorTeamsData,
    refetch: refetchTeamsData,
  } = useGetAllTeamQuery(generateFilterUrl(defaultPageSize))

  const {
    data: regionData,
    isLoading: isLoadingRegionData,
    isSuccess: isSuccessRegionData,
    isError: isErrorRegionData,
    error: errorRegionData,
    refetch: refetchRegionData,
  } = useGetAllRegionQuery(generateFilterUrl(defaultPageSize))
  console.log(JSON.parse(JSON.stringify(coastCenterData?.records || [])).find((o:any) => o?.costCenterCode === values?.costCenterCode), 'ccccccccccccc')

  return (
    <Box>

      <OPRLabel variant="h1">Organization Unit</OPRLabel>
      <OPRResponsiveGrid>
        <Grid item md={2} sm={1} xs={1}>
          <OPRSelectorControl
            isRequired
            error={errors?.departmentCode}
            isEditable={isEditable}
            keyName="departmentCode"
            label="employee_profile_department"
            multiple={false}
            name="departmentCode"
            options={JSON.parse(JSON.stringify(entityDeptData?.records || []))}
            value={JSON.parse(JSON.stringify(entityDeptData?.records || [])).find((o:any) => o?.departmentCode === values?.departmentCode)}
            valueKey="departmentCode"
            onChange={(text:any) => {
              handleOnChange('departmentCode', text?.departmentCode)
            }}
          />
        </Grid>
        <Grid item md={2} sm={1} xs={1}>
          <OPRSelectorControl
            isRequired
            error={errors?.costCenterCode}
            isEditable={isEditable}
            keyName="costCenterCode"
            label="employee_profile_cost_center"
            multiple={false}
            name="costCenterCode"
            options={JSON.parse(JSON.stringify(coastCenterData?.records || []))}
            value={JSON.parse(JSON.stringify(coastCenterData?.records || [])).find((o:any) => o?.costCenterCode === values?.costCenterCode)}
            valueKey="costCenterCode"
            onChange={(text:any) => {
              handleOnChange('costCenterCode', text?.costCenterCode)
            }}
          />
        </Grid>
        {
          // JSON.parse(JSON.stringify(allPosts?.records || []))
        }
        <Grid item md={2} sm={1} xs={1}>
          <OPRSelectorControl
            isRequired
            error={errors?.divisionCode}
            isEditable={isEditable}
            keyName="divisionCode"
            label="employee_profile_division"
            multiple={false}
            name="divisionCode"
            options={JSON.parse(JSON.stringify(divisionData?.records || []))}
            value={JSON.parse(JSON.stringify(divisionData?.records || [])).find((o:any) => o?.divisionCode === values?.divisionCode)}
            valueKey="divisionCode"
            onChange={(text:any) => {
              handleOnChange('divisionCode', text?.divisionCode)
            }}
          />
        </Grid>
        <Grid item md={2} sm={1} xs={1}>
          <OPRSelectorControl
            isRequired
            error={errors?.regionCode}
            isEditable={isEditable}
            keyName="regionCode"
            label="employee_profile_region"
            multiple={false}
            name="regionCode"
            options={JSON.parse(JSON.stringify(regionData?.records || []))}
            value={JSON.parse(JSON.stringify(regionData?.records || [])).find((o:any) => o?.regionCode === values?.regionCode)}
            valueKey="regionCode"
            onChange={(text:any) => {
              handleOnChange('regionCode', text?.regionCode)
            }}
          />
        </Grid>
        <Grid item md={2} sm={1} xs={1}>
          <OPRSelectorControl
            isRequired
            error={errors?.teamCode}
            isEditable={isEditable}
            keyName="teamCode"
            label="Team"
            multiple={false}
            name="teamCode"
            options={JSON.parse(JSON.stringify(teamsData?.records || []))}
            value={JSON.parse(JSON.stringify(teamsData?.records || [])).find((o:any) => o?.teamCode === values?.teamCode)}
            valueKey="teamCode"
            onChange={(text:any) => {
              handleOnChange('teamCode', text?.teamCode)
            }}
          />
        </Grid>
      </OPRResponsiveGrid>
    </Box>
  )
})

export default OrganizationUnit
