import { Grid } from '@mui/material'
import { useGetAllEmployeeProfileQuery } from 'api/employeeServices'
import { useGetAllPensionFundSchemeQuery } from 'api/entityServices'
import { useGetAllCurrencyQuery, useGetAllPensionFundTerminationQuery } from 'api/globalServices'
import OPRDatePickerControl from 'components/molecules/OPRDatePickerControl/OPRDatePickerControl'
import OPRFormHeaderLabel from 'components/molecules/OPRFormHeaderLabel/OPRFormHeaderLabel'
import OPRInputControl from 'components/molecules/OPRInputControl'
import OPRResponsiveGrid from 'components/molecules/OPRResponsiveGrid'
import OPRSelectorControl from 'components/molecules/OPRSelectorControl/OPRSelectorControl'
import {
  defaultPageSize,
  employeeIdentityType, employeePensionFundStatus, employeeTransferCode,
} from 'constants/index'
import { generateFilterUrl } from 'utils'

function GeneralPensionFundInformation({
  errors, isEditable, values, handleOnChange, handleChange, isSubTitle = true,
}:any) {
  const {
    data: currencyDataList,
    isLoading: isLoadingCurrencyDataList,
    isSuccess: isSuccessCurrencyDataList,
    isError: isErrorCurrencyDataList,
    error: errorCurrencyDataList,
    refetch: refetchCurrencyDataList,
  } = useGetAllCurrencyQuery(generateFilterUrl(defaultPageSize))
  const {
    data: employeeDataList,
    isLoading: isLoadingEmployeeDataList,
    isSuccess: isSuccessEmployeeDataList,
    isError: isErrorEmployeeDataList,
    error: errorEmployeeDataList,
    refetch: refetchEmployeeDataList,
  } = useGetAllEmployeeProfileQuery(generateFilterUrl({
    EffectiveDate: '10/10/2040',
    ...defaultPageSize,
  }))

  const {
    data: allPosts,
    isLoading: isLoadingAllPosts,
    isSuccess: isSuccessAllPosts,
    isError: isErrorAllPosts,
    error: errorAllPosts,
    refetch: refetchAllPosts,
  } = useGetAllPensionFundTerminationQuery(generateFilterUrl(defaultPageSize))
  const {
    data: allPensionFundSchem,
    isLoading: isLoadingAllPensionFundSchem,
    isSuccess: isSuccessAllPensionFundSchem,
    isError: isErrorAllPensionFundSchem,
    error: errorAllPensionFundSchem,
    refetch: refetchAllPensionFundSchem,
  } = useGetAllPensionFundSchemeQuery(generateFilterUrl(defaultPageSize))

  return (
    <OPRResponsiveGrid>
      <OPRFormHeaderLabel isSubTitle={isSubTitle} title="General pension fund information" />
      <Grid item md={12} sm={1} xs={1}>
        <OPRSelectorControl
          isRequired
          error={errors?.entityPensionFundSchemeId}
          isEditable={isEditable}
          keyName="pensionFundSchemeCode"
          label="employee_pension_fund_scheme_code"
          multiple={false}
          name="pensionFundSchemeCode"
          options={JSON.parse(JSON.stringify(allPensionFundSchem?.records || []))}
          placeholder="Select an option"
          value={JSON.parse(JSON.stringify(allPensionFundSchem?.records || []))?.find((o:any) => o?.id === values?.entityPensionFundSchemeId)}
          valueKey="pensionFundSchemeCode"
          onChange={(text:any) => {
            handleOnChange('entityPensionFundSchemeId', text?.id)
          }}
        />
      </Grid>
      {/* <Grid item md={2} sm={1} xs={1}>
        <OPRSelectorControl
          isRequired
          error={errors?.employeeCodeId}
          isEditable={isEditable}
          keyName="employeeCode"
          label="employee_pension_fund_Code"
          multiple={false}
          name="employeeCode"
          options={JSON.parse(JSON.stringify(employeeDataList?.records || []))}
          placeholder="Select an option"
          value={JSON.parse(JSON.stringify(employeeDataList?.records || []))?.find((o:any) => o?.employeeCode === values?.employeeCodeId) || {}}
          valueKey="employeeCode"
          onChange={(text:any) => {
            handleOnChange('employeeCodeId', text?.employeeCode)
          }}
        />
      </Grid> */}
      <Grid item md={2} sm={1} xs={1}>
        <OPRSelectorControl
          isRequired
          error={errors?.status}
          isEditable={isEditable}
          keyName="value"
          label="employee_pension_fund_status"
          multiple={false}
          name="status"
          options={employeePensionFundStatus}
          placeholder="Select an option"
          value={employeePensionFundStatus.find((o:any) => o?.value === values?.status)}
          valueKey="value"
          onChange={(text:any) => {
            handleOnChange('status', text?.value)
          }}
        />
      </Grid>
      <Grid item md={2} sm={1} xs={1}>
        <OPRDatePickerControl
          isRequired
          error={errors?.schemeJoinDate}
          isEditable={isEditable}
          label="employee_pension_fund_scheme_join_date"
          name="schemeJoinDate"
          // value={values?.effectiveStartDate ? values?.effectiveStartDate?.toISOString() : null}
          value={values?.schemeJoinDate || null}
          onChange={(date) => {
            handleOnChange('schemeJoinDate', date)
          }}
        />
      </Grid>
      <Grid item md={2} sm={1} xs={1}>
        <OPRDatePickerControl
          isRequired
          error={errors?.schemeCeaseDate}
          isEditable={isEditable}
          label="employee_pension_fund_scheme_cease_date"
          name="schemeCeaseDate"
          optionalText="Optional"
          // value={values?.effectiveStartDate ? values?.effectiveStartDate?.toISOString() : null}
          value={values?.schemeCeaseDate || null}
          onChange={(date) => {
            handleOnChange('schemeCeaseDate', date)
          }}
        />
      </Grid>
      <Grid item md={2} sm={1} xs={1}>
        <OPRSelectorControl
          isRequired
          error={errors?.identityType}
          isEditable={isEditable}
          keyName="name"
          label="employee_pension_fund_identity_type"
          multiple={false}
          name="name"
          optionalText="Optional"
          options={employeeIdentityType}
          value={employeeIdentityType.find((o:any) => o?.value === values?.identityType)}
          valueKey="value"
          onChange={(text:any) => {
            handleOnChange('identityType', text?.value)
          }}
        />
      </Grid>
      <Grid item md={12} sm={1} xs={1}>
        <OPRSelectorControl
          isRequired
          error={errors?.SchemeTerminationCodeId}
          isEditable={isEditable}
          keyName="terminationCode"
          label="employee_pension_fund_scheme_termination_code"
          multiple={false}
          name="terminationCode"
          optionalText="Optional"
          options={JSON.parse(JSON.stringify(allPosts?.records || []))}
          value={JSON.parse(JSON.stringify(allPosts?.records || [])).find((o:any) => o?.id === values?.SchemeTerminationCodeId)}
          valueKey="terminationCode"
          onChange={(text:any) => {
            handleOnChange('SchemeTerminationCodeId', text?.id)
          }}
        />
      </Grid>
      <Grid item md={12} sm={1} xs={1}>
        <OPRSelectorControl
          isRequired
          error={errors?.otherReportCurrencyId}
          isEditable={isEditable}
          keyName="currencyCode"
          label="employee_pension_fund_other_report_currency"
          multiple={false}
          name="currencyCode"
          optionalText="Optional"
          options={JSON.parse(JSON.stringify(currencyDataList?.records || []))}
          value={JSON.parse(JSON.stringify(currencyDataList?.records || [])).find((o:any) => o?.id === values?.otherReportCurrencyId)}
          valueKey="currencyCode"
          onChange={(text:any) => {
            handleOnChange('otherReportCurrencyId', text?.id)
          }}
        />
      </Grid>
      <Grid item md={2} sm={1} xs={1}>
        <OPRInputControl
          error={errors?.schemeMemberNumber}
          isEditable={isEditable}
          label="employee_pension_fund_scheme_member_number"
          name="schemeMemberNumber"
          optionalText="Optional"
          value={values?.schemeMemberNumber}
          onChange={handleChange}
        />
      </Grid>

      <Grid item md={2} sm={1} xs={1}>
        <OPRInputControl
          error={errors?.classId}
          isEditable={isEditable}
          label="employee_pension_fund_class_id"
          name="classId"
          optionalText="Optional"
          value={values?.classId}
          onChange={handleChange}
        />
      </Grid>
      <Grid item md={2} sm={1} xs={1}>
        <OPRSelectorControl
          isRequired
          error={errors?.transferCode}
          isEditable={isEditable}
          keyName="name"
          label="employee_pension_fund_transfer_code"
          multiple={false}
          name="name"
          optionalText="Optional"
          options={employeeTransferCode}
          value={employeeTransferCode.find((o:any) => o?.value === values?.transferCode)}
          valueKey="value"
          onChange={(text:any) => {
            handleOnChange('transferCode', text?.value)
          }}
        />
      </Grid>
    </OPRResponsiveGrid>
  )
}
export default GeneralPensionFundInformation
