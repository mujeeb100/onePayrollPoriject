import { Grid } from '@mui/material'
import OPRFormHeaderLabel from 'components/molecules/OPRFormHeaderLabel/OPRFormHeaderLabel'
import OPRInputControl from 'components/molecules/OPRInputControl'
import OPRResponsiveGrid from 'components/molecules/OPRResponsiveGrid'
import OPRSelectorControl from 'components/molecules/OPRSelectorControl/OPRSelectorControl'
import { employeeLongService } from 'constants/index'

function LSPPensionFundInformation({
  errors, isEditable, values, handleOnChange, handleChange, isSubTitle = true,
}:any) {
  return (
    <OPRResponsiveGrid>
      <OPRFormHeaderLabel isSubTitle={isSubTitle} title="LSP/SP" />
      <br />
      <Grid item md={2} sm={1} xs={1}>
        <OPRSelectorControl
          isRequired
          error={errors?.lspSpFlag}
          isEditable={isEditable}
          keyName="name"
          label="long_service_and_severence_pay"
          multiple={false}
          name="lspSpFlag"
          options={employeeLongService}
          value={employeeLongService.find((o:any) => o?.value === values?.lspSpFlag)}
          valueKey="name"
          onChange={(text:any) => {
            handleOnChange('lspSpFlag', text?.value)
          }}
        />
      </Grid>
      <Grid item md={2} sm={1} xs={1}>
        <OPRInputControl
          error={errors?.entitleLspSpAmount}
          isEditable={isEditable}
          label="employee_pension_fund_entitle_lsp_sp_amount"
          name="entitleLspSpAmount"
          value={values?.entitleLspSpAmount}
          onChange={handleChange}
        />
      </Grid>
      <Grid item md={2} sm={1} xs={1}>
        <OPRInputControl
          error={errors?.paidAmountForLspSp}
          isEditable={isEditable}
          label="employee_pension_fund_paid_amount_for_lsp_sp"
          name="paidAmountForLspSp"
          value={values?.paidAmountForLspSp}
          onChange={handleChange}
        />
      </Grid>
    </OPRResponsiveGrid>
  )
}
export default LSPPensionFundInformation
