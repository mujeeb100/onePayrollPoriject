import { Grid } from '@mui/material'
import OPRDatePickerControl from 'components/molecules/OPRDatePickerControl/OPRDatePickerControl'
import OPRFormHeaderLabel from 'components/molecules/OPRFormHeaderLabel/OPRFormHeaderLabel'
import OPRInputControl from 'components/molecules/OPRInputControl'
import OPRResponsiveGrid from 'components/molecules/OPRResponsiveGrid'

function EmployeeAndEmployerPensionfund({
  errors, isEditable, values, handleOnChange, isSubTitle = true, handleChange, setErrors,
}:any) {
  function isEmpty(val: string) {
    return !!((val === undefined || val == null || val.length <= 0))
  }
  console.log(errors, 'errors')

  // useEffect(() => {
  //   if (!isEmpty(values?.employerCalculationStartDate)
  //     && !isEmpty(values?.employerContributionStartDate)) {
  //     if (new Date(values?.employerCalculationStartDate)
  //       <= new Date(values?.employerContributionStartDate)
  //     ) {
  //       const newObj = omit(errors, 'employerCalculationStartDate', 'employerContributionStartDate')
  //       setErrors(newObj)
  //     } else {
  //       setErrors({
  //         ...errors,
  //         employerContributionStartDate: 'Employer Calculation Start Date must be set before or equal to the Employer Contribution Start Date',
  //         employerCalculationStartDate: 'Employee Calculation Start Date must be set before or equal to the Employee Contribution Start Date',
  //       })
  //     }
  //   }

  //   if (!isEmpty(values?.employeeCalculationStartDate)
  //     && !isEmpty(values?.employeeContributionStartDate)) {
  //     if (new Date(values?.employeeCalculationStartDate)
  //       <= new Date(values?.employeeContributionStartDate)
  //     ) {
  //       const newObj = omit(errors, 'employeeCalculationStartDate', 'employeeContributionStartDate')
  //       setErrors(newObj)
  //     } else {
  //       setErrors({
  //         ...errors,
  //         employeeCalculationStartDate: 'Employer Calculation Start Date must be set before or equal to the Employer Contribution Start Date',
  //         employeeContributionStartDate: 'Employee Calculation Start Date must be set before or equal to the Employee Contribution Start Date',

  //       })
  //     }
  //   }
  // }, [values?.employerCalculationStartDate, values?.employeeCalculationStartDate,
  //   values?.employerContributionStartDate, values?.employeeContributionStartDate])
  return (
    <OPRResponsiveGrid>
      <OPRFormHeaderLabel isSubTitle={isSubTitle} title="Employer and employee" />

      {
        // JSON.parse(JSON.stringify(allPosts?.records || []))
      }
      <Grid item md={2} sm={1} xs={1}>
        <OPRDatePickerControl
          isRequired
          error={errors?.employerCalculationStartDate}
          isEditable={isEditable}
          label="employee_pension_fund_employer_calculation_start_date"
          name="employerCalculationStartDate"
          // value={values?.effectiveStartDate ? values?.effectiveStartDate?.toISOString() : null}
          value={values?.employerCalculationStartDate || null}
          onChange={(date) => {
            handleOnChange('employerCalculationStartDate', date)
          }}
        />
      </Grid>
      <Grid item md={2} sm={1} xs={1}>
        <OPRDatePickerControl
          isRequired
          error={errors?.employeeCalculationStartDate}
          isEditable={isEditable}
          label="employee_pension_fund_employee_calculation_start_date"
          name="employeeCalculationStartDate"
          // value={values?.effectiveStartDate ? values?.effectiveStartDate?.toISOString() : null}
          value={values?.employeeCalculationStartDate || null}
          onChange={(date) => {
            handleOnChange('employeeCalculationStartDate', date)
          }}
        />
      </Grid>
      <Grid item md={2} sm={1} xs={1}>
        <OPRDatePickerControl
          isRequired
          error={errors?.employerContributionStartDate}
          isEditable={isEditable}
          label="employee_pension_fund_employer_contribution_start_date"
          name="employerContributionStartDate"
          // value={values?.effectiveStartDate ? values?.effectiveStartDate?.toISOString() : null}
          value={values?.employerContributionStartDate || null}
          onChange={(date) => {
            handleOnChange('employerContributionStartDate', date)
          }}
        />
      </Grid>
      <Grid item md={2} sm={1} xs={1}>
        <OPRDatePickerControl
          isRequired
          error={errors?.employeeContributionStartDate}
          isEditable={isEditable}
          label="employee_pension_fund_employee_contribution_start_date"
          name="employeeContributionStartDate"
          // value={values?.effectiveStartDate ? values?.effectiveStartDate?.toISOString() : null}
          value={values?.employeeContributionStartDate || null}
          onChange={(date) => {
            handleOnChange('employeeContributionStartDate', date)
          }}
        />
      </Grid>
      <Grid item md={2} sm={1} xs={1}>
        <OPRInputControl
          error={errors?.employerAnnualContributionCap}
          isEditable={isEditable}
          label="employee_pension_fund_employer_annual_contribution_cap"
          name="employerAnnualContributionCap"
          optionalText="Optional"
          value={values?.employerAnnualContributionCap}
          onChange={handleChange}
        />
      </Grid>
      <Grid item md={2} sm={1} xs={1}>
        <OPRInputControl
          error={errors?.employeeAnnualContributionCap}
          isEditable={isEditable}
          label="employee_pension_fund_employee_annual_contribution_cap"
          name="employeeAnnualContributionCap"
          optionalText="Optional"
          value={values?.employeeAnnualContributionCap}
          onChange={handleChange}
        />
      </Grid>
    </OPRResponsiveGrid>
  )
}
export default EmployeeAndEmployerPensionfund
