import {
  Box,
} from '@mui/material'
import { useEmployeePensionFundDeleteMutation, useGetAllEmployeePensionFundQuery } from 'api/employeeServices'
import { RighCaretBlue, WhiteRightCaret } from 'assets/svg-images/SvgComponents'
import OPRButton from 'components/atoms/button/OPRButton'
import OPRLabel from 'components/atoms/label/OPRLabel'
import CustomLoader from 'components/atoms/loader/OPRLoader'
import { CustomDialog } from 'components/atoms/modal/OPRModal'
import OPRPagination from 'components/atoms/pagination/OPRPagination'
import OPRTable from 'components/atoms/table/OPRTable'
import { employeePensionFundColumn } from 'components/atoms/table/OPRTableConstant'
import CancelAlert from 'components/molecules/OPRAlertControl/CancelAlert'
import { OPRDeleteControl } from 'components/molecules/OPRAlertControl/OPRDeleteControl'
import OPRErrorAlertControl from 'components/molecules/OPRAlertControl/OPRErrorControl'
import { defaultPageSize } from 'constants/index'
import React, { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import {
  generateFilterUrl,
} from 'utils'

import PensionFundEmployeeForm from './PensionFundEmployeeForm'

function PensionFundEmployeeList({
  id, setCount, ProfileId, employeeData,
}:any) {
  const [selectedTab, setSelectedTab] = React.useState(0)
  const [isModal, setModal] = useState(false)
  const myRef:any = React.useRef()
  const [isCancel, setCancel] = useState(false)
  const [selectedId, setSelectedId]:any = useState(undefined)
  const [isEditPension, setIsEditPension]:any = useState(false)
  const [selelctedUser, setSelelctedUser]:any = useState({
    data: {},
    isDelete: false,
    name: '',
  })

  const navigate: any = useNavigate()
  const [filterData, setFilterData]:any = useState({
    pageNumber: 1,
    pageSize: 20,
    totalItems: 0,
    orderByAsc: true,
    sortBy: '',
    SearchText: id,
  })
  const {
    data: allPosts,
    error: createAllPostsBankAccountError,
    isLoading: isLoadingAllPosts,
    isSuccess: isSuccessAllPosts,
    isError: isErrorAllPosts,
    error: errorAllPosts,
  } = useGetAllEmployeePensionFundQuery(`${generateFilterUrl(defaultPageSize)}&EmployeeProfileId=${ProfileId}`)
  useEffect(() => {
    setCount(JSON.parse(JSON.stringify(allPosts || [])).totalItems)
  }, [isSuccessAllPosts])
  // console.log(useEmployeePensionFundChangeStatusMutation, 'useClientGroupEntitesChangeStatusMutationuseClientGroupEntitesChangeStatusMutation')

  const [deleteEmployeePensionFundById,
    {
      data: deleteEmployeePensionFundResponse,
      error: deleteEmployeePensionFundError,
      isLoading: deleteEmployeePensionFundLoading,
      isSuccess: deleteEmployeePensionFundSuccess,
      isError: deleteEmployeePensionFundIsError,
    }] = useEmployeePensionFundDeleteMutation()

  const sorting = (
    event: React.MouseEvent<unknown>,
    property: keyof any,
  ) => {
    const isAsc = filterData.sortBy === property && filterData.orderByAsc === true
    setFilterData({ ...filterData, orderByAsc: !isAsc, sortBy: property })
    // setOrder(isAsc ? 'desc' : 'asc')
    // setOrderBy(property)
  }

  useEffect(() => {
    setFilterData({ ...filterData, totalItems: allPosts?.totalItems ? allPosts?.totalItems : 0 })
  }, [allPosts?.pageNumber, filterData.sortBy, filterData.orderByAsc, allPosts?.totalItems])

  const onSearch = (e: any, data: any) => {
    setFilterData({ ...filterData, ...data })
  }
  const handlePagination = (pageNumber: number, pageSize: number) => {
    setFilterData({ ...filterData, pageNumber })
  }
  useEffect(() => {
    setIsEditPension(false)
  }, [])
  const viewAcoount = (data: any, type:string) => {
    if (type === 'Edit Pension Fund') {
      setSelectedId(3)
      setSelectedId(data.id)
      setModal(!isModal)
      setIsEditPension(true)
      // navigate(
      //   setRouteValues(`${routes.editEmployeePensionFund}`, {
      //     id: data.clientGroupProfileId,
      //     profilId: data.id,
      //   }),
      // )
    } else if (type === 'delete') {
      setSelelctedUser({ data, isDelete: true, name: data.clientGroupName })
    } else {
      // navigate(
      //   setRouteValues(`${routes.viewEmployeePensionFund}`, {
      //     id: data.clientGroupProfileId,
      //     profilId: data.id,
      //     view: false,
      //   }),
      // )
    }
    // const id = JSON.stringify(data)
  }

  const handleView = (data: any) => {
    setIsEditPension(false)
    setSelectedTab(3)
    setSelectedId(data.id)
    setModal(!isModal)
  }

  const deleteEntities = (data:any) => {
    deleteEmployeePensionFundById(`Id=${data.id}`)
  }
  return (
    <Box sx={{ display: 'flex', flexDirection: 'column' }}>
      <Box sx={{ display: 'flex', justifyContent: 'flex-end', alignItems: 'center' }}>
        <OPRButton
          startIcon
          handleClick={() => {
            setModal(!isModal)
            setIsEditPension(true)
          }}
          variant="text"
        >
          {' '}
          Add Pension Fund
        </OPRButton>
      </Box>
      <CancelAlert
        callBack={() => {
          setCancel(false)
          setModal(false)
        }}
        handleCancel={() => {
          setCancel(false)
        }}
        isCancel={isCancel}
      />
      <CustomDialog
        CustomStyles={{ borderRadius: '16px' }}
        isOpen={isLoadingAllPosts}
        type="loader"
      >
        <CustomLoader text="Processing request" />
      </CustomDialog>
      <OPRDeleteControl
        deleteCallBack={deleteEntities}
        selelctedUser={selelctedUser}
        setSelelctedUser={setSelelctedUser}
        title="Client Group Entities"
      />
      <CustomDialog
        CustomStyles={{ borderRadius: '16px' }}
        isOpen={isModal}
        type="loader"
      >
        <PensionFundEmployeeForm ref={myRef} empId={id} employeeData={employeeData} id={selectedId} isModal={isModal} selectedTab={selectedTab} setModal={setModal} setSelectedId={setSelectedId} setSelectedTab={setSelectedTab} />
        <Box sx={{
          display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: 5,
        }}
        >
          <OPRButton color="info" variant="text" onClick={() => { if (isEditPension) { setCancel(true) } else { setModal(false) } }}>
            Cancel
          </OPRButton>
          {isEditPension && (
            <Box>
              {selectedTab === 0 ? <div /> : (
                <OPRButton
                  style={{ marginLeft: 'auto' }}
                  variant="text"
                  onClick={() => {
                    setSelectedTab(selectedTab - 1)
                  }}
                >
                  <RighCaretBlue />
                  Back
                </OPRButton>
              )}
              <OPRButton
                color="primary"
                variant="contained"
                onClick={(e:any) => {
                  myRef?.current?.handleOnSubmit(e)
                }}
              >
                {
                  selectedTab === 3 ? 'Confirm ' : 'Continue'
                }
                {' '}
                <Box>
                  <WhiteRightCaret />
                </Box>
              </OPRButton>
            </Box>
          )}
        </Box>
      </CustomDialog>

      <OPRErrorAlertControl
        error={deleteEmployeePensionFundError}
        header="Failed to Delete"
        isBackButton={false}
        isError={deleteEmployeePensionFundIsError}
        isTry={false}
        name="Client Group Entities"
      />
      <OPRLabel CustomStyles={{ marginBottom: 5 }} variant="body2">
        {JSON.parse(JSON.stringify(allPosts?.records || [])).length}
        {' '}
        items
      </OPRLabel>
      <OPRTable
        cols={employeePensionFundColumn(viewAcoount)}
        data={JSON.parse(JSON.stringify(allPosts?.records || []))}
        handleEdit={viewAcoount}
        isLoader={isLoadingAllPosts}
        newOptions={[]}
        orderBy={filterData?.orderByAsc}
        rowClickHandler={handleView}
        rowNumber={0}
        sortBy={filterData?.sortBy}
        title="title"
        onRequestSort={sorting}
      />
      {
        filterData?.totalItems < 20 ? null : (
          <Box sx={{ display: 'flex', justifyContent: 'center', mt: 2 }}>
            <OPRPagination
              limit={filterData?.pageSize}
              page={filterData?.pageNumber}
              setPage={handlePagination}
              total={filterData?.totalItems}
            />
          </Box>
        )
      }
    </Box>
  )
}

export default PensionFundEmployeeList
