import { Box } from '@mui/material'
import {
  useEmployeePensionFundCreateMutation, useEmployeePensionFundUpdateMutation, useGetAllEmployeeProfileQuery, useLazyGetEmployeePensionFundByIdQuery,
} from 'api/employeeServices'
import { useGetAllPensionFundSchemeQuery } from 'api/entityServices'
import { CrossIcon, TickIcon } from 'assets/svg-images/SvgComponents'
import CustomLoader from 'components/atoms/loader/OPRLoader'
import { CustomDialog } from 'components/atoms/modal/OPRModal'
import { CustomTabPanel } from 'components/atoms/tabs'
import { OPRConfirmationDialog, OPRConfirmationDialogProps } from 'components/molecules/OPRAlertControl/OPRConfirmationDialog'
import OPRResponsiveGrid from 'components/molecules/OPRResponsiveGrid'
import { customeDateFormat, defaultPageSize } from 'constants/index'
import {
  employeePensionFundFPSValidationSchema, employeePensionFundGeneralValidationSchema, employeePensionFundPaymentValidationSchema,
} from 'constants/validate'
import { useEditable } from 'hooks/useEdit'
import useForm from 'hooks/useForm'
import { t } from 'i18next'
import React, {
  forwardRef, useEffect, useImperativeHandle, useState,
} from 'react'
import { useLocation } from 'react-router-dom'
import { generateFilterUrl } from 'utils'

import EmployeeAndEmployerPensionfund from './EmployeeAndEmployerPensionfund'
import GeneralPensionFundInformation from './GeneralPensionFundInformation'
import LSPPensionFundInformation from './LSPPensionFundInformation'

const validationList = (expression:any) => {
  let validationScheme:any = {}
  switch (expression) {
    case 0:
      validationScheme = employeePensionFundGeneralValidationSchema
      break
    case 1:
      validationScheme = employeePensionFundPaymentValidationSchema
      break
    default:
      validationScheme = employeePensionFundFPSValidationSchema
  }
  return validationScheme
}
interface MessageProps {
    text?: string;
    important?: boolean;
  }

const PensionFundEmployeeForm = forwardRef(({
  id, empId, isModal, selectedTab, setSelectedTab, setSelectedId, setModal, employeeData,
}:any, ref) => {
  const handleTabChange = (event: React.SyntheticEvent, newValue: number) => {
    setSelectedTab(newValue)
  }
  const { isEditable, setEditable } = useEditable()
  const {
    values,
    setValues,
    errors,
    handleChange,
    setErrors,
    handleFormSubmit,
    handleOnChange,
  } = useForm(validationList(selectedTab))
  const location: any = useLocation()

  const [createEmployeePensionFund, {
    data: createdEmployeePensionFundData,
    error: createdEmployeePensionFundError,
    isLoading: createdEmployeePensionFundLoading,
    isSuccess: createdEmployeePensionFundSuccess,
    isError: createdEmployeePensionFundIsError,
  }] = useEmployeePensionFundCreateMutation()

  const {
    data: employeeDataList,
    isLoading: isLoadingEmployeeDataList,
    isSuccess: isSuccessEmployeeDataList,
    isError: isErrorEmployeeDataList,
    error: errorEmployeeDataList,
    refetch: refetchEmployeeDataList,
  } = useGetAllEmployeeProfileQuery(generateFilterUrl({
    EffectiveDate: '10/10/2040',
    ...defaultPageSize,
  }))

  useEffect(() => {
    // setValues({ ...values, schemeJoinDate: calculatedFinalDate })
  }, [])

  function getSurnameByEmployeeCode(employeeCode:any) {
    const employee = employeeDataList?.records?.find((emp:any) => emp?.employeeCode === employeeCode)
    return employee?.employeeProfile?.id ? employee?.employeeProfile?.id : null
  }

  const [updateEmployeePensionFund, {
    data: uupdatedClientGroupDataResponse,
    error: updatedEmployeePensionFundError,
    isLoading: updatedEmployeePensionFundLoading,
    isSuccess: updatedEmployeePensionFundSuccess,
    isError: updatedEmployeePensionFundIsError,
  }] = useEmployeePensionFundUpdateMutation()

  const [updateEmployeePensionFundById, {
    data: updatedEmployeePensionFundByIdResponse,
    error: updatedEmployeePensionFundByIdError,
    isLoading: updatedEmployeePensionFundByIdLoading,
    isSuccess: updatedEmployeePensionFundByIdSuccess,
    isError: updatedEmployeePensionFundByIdIsError,
  }] = useLazyGetEmployeePensionFundByIdQuery()
  useEffect(() => {
    if (id && updatedEmployeePensionFundByIdSuccess) {
      setValues(updatedEmployeePensionFundByIdResponse?.data)
      // setSelectedTab(0)
      // setEditable(false)
    } else {
      let calculatedFinalDate:any = new Date(employeeData?.commencementDate)
      const dob:any = new Date(employeeData.employeeProfile.dateOfBirth)

      if (employeeData.employeeProfile.visaFirstLandingDate) {
      // Add 13 months to the final date
        calculatedFinalDate.setMonth(calculatedFinalDate.getMonth() + 13)
      }

      // Calculate age at the calculated final date
      const ageAtFinalDate = (calculatedFinalDate - dob) / (1000 * 60 * 60 * 24 * 365.25)

      if (ageAtFinalDate < 18) {
      // Set final date to 18 years from dob
        calculatedFinalDate = new Date(dob)
        calculatedFinalDate.setFullYear(calculatedFinalDate.getFullYear() + 18)
      }
      setValues({
        ...values, transferCode: 'false', status: 'Active', schemeJoinDate: calculatedFinalDate,
      })
      // setEditable(false)
    }
  }, [updatedEmployeePensionFundByIdSuccess])
  useEffect(() => {
    if (isModal === false) {
      setSelectedTab(0)
      setEditable(false)
    }
  }, [isModal])
  useEffect(() => {
    if (isModal === false) {
      setValues({ transferCode: 'false', status: 'Active' })
      setSelectedId(undefined)
      setSelectedTab(0)
    }
  }, [isModal])
  useEffect(() => {
    if (id) {
      updateEmployeePensionFundById(id)
    }
  }, [])

  useEffect(() => {
    if (selectedTab === 3) {
      setEditable(true)
    } else {
      setEditable(false)
    }
  }, [selectedTab])

  const handleSubmit:any = async () => {
    if (selectedTab === 0) {
      setSelectedTab(1)
    }
    if (selectedTab === 1) {
      setSelectedTab(2)
    }
    if (selectedTab === 2) {
      setSelectedTab(3)
      // setEditable(true)
    }
    if (selectedTab === 3) {
      if (id) {
        await updateEmployeePensionFund({
          ...values,
          // employeeProfileId: getSurnameByEmployeeCode(empId),
          // employeeCode: empId,
          transferCode: values.transferCode.toString(),
          schemeJoinDate: values.schemeJoinDate ? customeDateFormat(values.schemeJoinDate) : null,
          schemeCeaseDate: values.schemeCeaseDate ? customeDateFormat(values.schemeCeaseDate) : null,
          employerCalculationStartDate: values.employerCalculationStartDate ? customeDateFormat(values.employerCalculationStartDate) : null,
          employeeCalculationStartDate: values.employeeCalculationStartDate ? customeDateFormat(values.employeeCalculationStartDate) : null,
          employerContributionStartDate: values.employerContributionStartDate ? customeDateFormat(values.employerContributionStartDate) : null,
          employeeContributionStartDate: values.employeeContributionStartDate ? customeDateFormat(values.employeeContributionStartDate) : null,
        })
      } else {
        await createEmployeePensionFund({
          ...values,
          employeeProfileId: getSurnameByEmployeeCode(empId),
          employeeCode: empId,
          transferCode: values.transferCode.toString(),
          schemeJoinDate: values.schemeJoinDate ? customeDateFormat(values.schemeJoinDate) : null,
          schemeCeaseDate: values.schemeCeaseDate ? customeDateFormat(values.schemeCeaseDate) : null,
          employerCalculationStartDate: values.employerCalculationStartDate ? customeDateFormat(values.employerCalculationStartDate) : null,
          employeeCalculationStartDate: values.employeeCalculationStartDate ? customeDateFormat(values.employeeCalculationStartDate) : null,
          employerContributionStartDate: values.employerContributionStartDate ? customeDateFormat(values.employerContributionStartDate) : null,
          employeeContributionStartDate: values.employeeContributionStartDate ? customeDateFormat(values.employeeContributionStartDate) : null,
        })
      }
    }
  }
  useImperativeHandle(ref, () => ({
    handleOnSubmit(e:any) {
      handleFormSubmit(e, handleSubmit)
    },

  }))

  useEffect(() => {
    if (createdEmployeePensionFundSuccess) {
      // Reset form values after successful add operation
      setValues({})
      setErrors({})
    }
  }, [createdEmployeePensionFundSuccess])
  console.log('$$$$$$$$$', values)

  const {
    data: allPensionFundSchem,
    isLoading: isLoadingAllPensionFundSchem,
    isSuccess: isSuccessAllPensionFundSchem,
    isError: isErrorAllPensionFundSchem,
    error: errorAllPensionFundSchem,
    refetch: refetchAllPensionFundSchem,
  } = useGetAllPensionFundSchemeQuery(generateFilterUrl(defaultPageSize))
  function getSurnameByEmployeeName(employeeCode:any) {
    const employee = employeeDataList?.records?.find((emp:any) => emp?.employeeCode === employeeCode)
    return employee?.employeeProfile?.givenName ? employee?.employeeProfile?.givenName : null
  }
  const message1 = JSON.parse(JSON.stringify(allPensionFundSchem?.records || []))?.find((o:any) => o?.id === createdEmployeePensionFundData?.data?.entityPensionFundSchemeId
  || uupdatedClientGroupDataResponse?.data?.entityPensionFundSchemeId)?.pensionFundSchemeCode
  const message2 = getSurnameByEmployeeName(empId)

  const [confirmDialog, setConfirmDialog] = useState<OPRConfirmationDialogProps>({
    open: false,
    buttonLayout: 'confirm',
    title: '',
    message: '',
  })

  const createErrorDialog: any = () => {
    setConfirmDialog({
      open: true,
      icon: <CrossIcon />,
      buttonLayout: 'try-again',
      error: (createdEmployeePensionFundError || updatedEmployeePensionFundError),
      title: t('Failed to add pension fund'),
      onClose: () => {
        setConfirmDialog({
          open: true,
          buttonLayout: 'confirm',
          infoMessage: t('Are you sure you want to quit without saving your changes? Any unsaved progress will be lost.'),
          title: t('Are you sure you want to quit'),
          onConfirm: () => {
            setConfirmDialog({ ...confirmDialog, open: false })
            setModal(false)
            setValues({})
            setErrors({})
          },
          onCancel: () => {
            setConfirmDialog({ ...confirmDialog, open: false })
            createErrorDialog()
          },
        })
      },
      onTryAgain: () => {
        setConfirmDialog({ ...confirmDialog, open: false })
        handleSubmit()
      },
      onBack: () => {
        setConfirmDialog({ ...confirmDialog, open: false })
      },
    })
  }

  useEffect(() => {
    if (updatedEmployeePensionFundSuccess || createdEmployeePensionFundSuccess) {
      setConfirmDialog({
        open: true,
        icon: <TickIcon />,
        buttonLayout: 'close',
        title: t('Pension fund added'),
        message: (
          <>
            <strong>{message1}</strong>
            {' '}
            {t('has been added to')}
            {' '}
            <strong>{message2}</strong>
            .
          </>
        ),
        onClose: () => {
          setConfirmDialog({ ...confirmDialog, open: false })
          setModal(false)
        },
      })
    }
    if (createdEmployeePensionFundError || updatedEmployeePensionFundError) {
      createErrorDialog()
    }
  }, [createdEmployeePensionFundError, updatedEmployeePensionFundError, updatedEmployeePensionFundSuccess, createdEmployeePensionFundSuccess])

  return (
    <Box>

      <CustomDialog
        CustomStyles={{ borderRadius: '16px' }}
        isOpen={createdEmployeePensionFundLoading || updatedEmployeePensionFundLoading}
        type="loader"
      >
        <CustomLoader text="Processing request" />
      </CustomDialog>

      <OPRConfirmationDialog
        key="confirmation-dialog"
        titleSx={{
          '&::first-letter': {
            textTransform: 'capitalize',
          },
        }}
        {...confirmDialog}
      />

      <OPRResponsiveGrid>

        <CustomTabPanel index={0} value={selectedTab}>

          <GeneralPensionFundInformation
            errors={errors}
            handleChange={handleChange}
            handleOnChange={handleOnChange}
            isEditable={isEditable}
            values={values}
          />

        </CustomTabPanel>
        <CustomTabPanel index={1} value={selectedTab}>
          <EmployeeAndEmployerPensionfund
            errors={errors}
            handleChange={handleChange}
            handleOnChange={handleOnChange}
            isEditable={isEditable}
            isSubTitile={false}
            values={values}
          />
        </CustomTabPanel>
        <CustomTabPanel index={2} value={selectedTab}>
          <LSPPensionFundInformation
            errors={errors}
            handleChange={handleChange}
            handleOnChange={handleOnChange}
            isEditable={isEditable}
            setValues={setValues}
            values={values}
          />
        </CustomTabPanel>
        <CustomTabPanel index={3} value={selectedTab}>
          <GeneralPensionFundInformation
            errors={errors}
            handleChange={handleChange}
            handleOnChange={handleOnChange}
            isEditable={isEditable}
            isSubTitle={false}
            values={values}
          />
          <br />
          <br />
          <EmployeeAndEmployerPensionfund
            errors={errors}
            handleChange={handleChange}
            handleOnChange={handleOnChange}
            isEditable={isEditable}
            isSubTitle={false}
            setErrors={setErrors}
            values={values}
          />
          <br />
          <br />
          <LSPPensionFundInformation
            errors={errors}
            handleChange={handleChange}
            handleOnChange={handleOnChange}
            isEditable={isEditable}
            isSubTitle={false}
            setErrors={setErrors}
            values={values}
          />
        </CustomTabPanel>
        {/* <Grid item md={2} sm={1} xs={1}>
          <OPRSelectorControl
            isRequired
            error={errors?.pensionFundSchemeCode}
            isEditable={isEditable}
            keyName="pensionFundSchemeCode"
            label="employee_pension_fund_scheme_code"
            multiple={false}
            name="pensionFundSchemeCode"
            options={JSON.parse(JSON.stringify(allPensionFundSchem?.records || []))}
            placeholder="Select an option"
            value={JSON.parse(JSON.stringify(allPensionFundSchem?.records || []))?.find((o:any) => o?.countryName === values?.countryLocalization) || {}}
            valueKey="pensionFundSchemeCode"
            onChange={(text:any) => {
              handleOnChange('pensionFundSchemeCode', text?.pensionFundSchemeCode)
            }}
          />
        </Grid>
        <Grid item md={2} sm={1} xs={1}>
          <OPRSelectorControl
            isRequired
            error={errors?.employeeCodeId}
            isEditable={isEditable}
            keyName="employeeCode"
            label="employee_pension_fund_Code"
            multiple={false}
            name="employeeCodeId"
            options={JSON.parse(JSON.stringify(employeeDataList?.records || []))}
            placeholder="Select an option"
            value={JSON.parse(JSON.stringify(employeeDataList?.records || []))?.find((o:any) => o?.employeeCodeId === values?.employeeCodeId) || {}}
            valueKey="employeeCodeId"
            onChange={(text:any) => {
              handleOnChange('employeeCodeId', text?.employeeCodeId)
            }}
          />
        </Grid>
        <Grid item md={2} sm={1} xs={1}>
          <OPRSelectorControl
            isRequired
            error={errors?.status}
            isEditable={isEditable}
            keyName="value"
            label="employee_pension_fund_status"
            multiple={false}
            name="status"
            options={employeePensionFundStatus}
            placeholder="Select an option"
            value={employeePensionFundStatus.find((o:any) => o?.value === values?.status)}
            valueKey="status"
            onChange={(text:any) => {
              handleOnChange('status', text?.value)
            }}
          />
        </Grid>
        <Grid item md={2} sm={1} xs={1}>
          <OPRDatePickerControl
            isRequired
            error={errors?.schemeJoinDate}
            isEditable={isEditable}
            label="employee_pension_fund_scheme_join_date"
            name="schemeJoinDate"
            // value={values?.effectiveStartDate ? values?.effectiveStartDate?.toISOString() : null}
            value={values?.schemeJoinDate || null}
            onChange={(date) => {
              handleOnChange('schemeJoinDate', new Date(date))
            }}
          />
        </Grid>
        {
          // JSON.parse(JSON.stringify(allPosts?.records || []))
        }
        <Grid item md={2} sm={1} xs={1}>
          <OPRDatePickerControl
            isRequired
            error={errors?.employerCalculationStartDate}
            isEditable={isEditable}
            label="employee_pension_fund_employer_calculation_start_date"
            name="employerCalculationStartDate"
            // value={values?.effectiveStartDate ? values?.effectiveStartDate?.toISOString() : null}
            value={values?.employerCalculationStartDate || null}
            onChange={(date) => {
              handleOnChange('employerCalculationStartDate', new Date(date))
            }}
          />
        </Grid>
        <Grid item md={2} sm={1} xs={1}>
          <OPRDatePickerControl
            isRequired
            error={errors?.employeeCalculationStartDate}
            isEditable={isEditable}
            label="employee_pension_fund_employee_calculation_start_date"
            name="employeeCalculationStartDate"
            // value={values?.effectiveStartDate ? values?.effectiveStartDate?.toISOString() : null}
            value={values?.employeeCalculationStartDate || null}
            onChange={(date) => {
              handleOnChange('employeeCalculationStartDate', new Date(date))
            }}
          />
        </Grid>
        <Grid item md={2} sm={1} xs={1}>
          <OPRDatePickerControl
            isRequired
            error={errors?.employerContributionStartDate}
            isEditable={isEditable}
            label="employee_pension_fund_employer_contribution_start_date"
            name="employerContributionStartDate"
            // value={values?.effectiveStartDate ? values?.effectiveStartDate?.toISOString() : null}
            value={values?.employerContributionStartDate || null}
            onChange={(date) => {
              handleOnChange('employerContributionStartDate', new Date(date))
            }}
          />
        </Grid>
        <Grid item md={2} sm={1} xs={1}>
          <OPRDatePickerControl
            isRequired
            error={errors?.employeeContributionStartDate}
            isEditable={isEditable}
            label="employee_pension_fund_employee_contribution_start_date"
            name="employeeContributionStartDate"
            // value={values?.effectiveStartDate ? values?.effectiveStartDate?.toISOString() : null}
            value={values?.employeeContributionStartDate || null}
            onChange={(date) => {
              handleOnChange('employeeContributionStartDate', new Date(date))
            }}
          />
        </Grid>
        <Grid item md={2} sm={1} xs={1}>
          <OPRDatePickerControl
            isRequired
            error={errors?.schemeCeaseDate}
            isEditable={isEditable}
            label="employee_pension_fund_scheme_cease_date"
            name="schemeCeaseDate"
            // value={values?.effectiveStartDate ? values?.effectiveStartDate?.toISOString() : null}
            value={values?.schemeCeaseDate || null}
            onChange={(date) => {
              handleOnChange('schemeCeaseDate', new Date(date))
            }}
          />
        </Grid>
        <Grid item md={2} sm={1} xs={1}>
          <OPRSelectorControl
            isRequired
            error={errors?.schemeTerminationCode}
            isEditable={isEditable}
            keyName="value"
            label="employee_pension_fund_scheme_termination_code"
            multiple={false}
            name="schemeTerminationCode"
            options={employeeSchemeTerminationCode}
            value={employeeSchemeTerminationCode.find((o:any) => o?.value === values?.schemeTerminationCode)}
            valueKey="schemeTerminationCode"
            onChange={(text:any) => {
              handleOnChange('schemeTerminationCode', text?.value)
            }}
          />
        </Grid>
        <Grid item md={2} sm={1} xs={1}>
          <OPRSelectorControl
            isRequired
            error={errors?.identityType}
            isEditable={isEditable}
            keyName="value"
            label="employee_pension_fund_identity_type"
            multiple={false}
            name="paymentCurrencyId"
            options={employeeIdentityType}
            value={employeeIdentityType.find((o:any) => o?.value === values?.identityType)}
            valueKey="identityType"
            onChange={(text:any) => {
              handleOnChange('identityType', text?.paymentCurrencyId)
            }}
          />
        </Grid>
        <Grid item md={2} sm={1} xs={1}>
          <OPRSelectorControl
            isRequired
            error={errors?.otherReportCurrencyId}
            isEditable={isEditable}
            keyName="currencyCode"
            label="employee_pension_fund_other_report_currency"
            multiple={false}
            name="otherReportCurrencyId"
            options={JSON.parse(JSON.stringify(currencyDataList?.records || []))}
            value={JSON.parse(JSON.stringify(currencyDataList?.records || []))?.find((o:any) => o?.countryName === values?.countryLocalization) || {}}
            onChange={(text:any) => {
              handleOnChange('otherReportCurrencyId', text?.currencyCode)
            }}
          />
        </Grid>
        <Grid item md={2} sm={1} xs={1}>
          <OPRInputControl
            error={errors?.employerAnnualContributionCap}
            isEditable={isEditable}
            label="employee_pension_fund_employer_annual_contribution_cap"
            name="employerAnnualContributionCap"
            value={values?.employerAnnualContributionCap}
            onChange={handleChange}
          />
        </Grid>
        <Grid item md={2} sm={1} xs={1}>
          <OPRInputControl
            error={errors?.schemeMemberNumber}
            isEditable={isEditable}
            label="employee_pension_fund_scheme_member_number"
            name="schemeMemberNumber"
            value={values?.schemeMemberNumber}
            onChange={handleChange}
          />
        </Grid>
        <Grid item md={2} sm={1} xs={1}>
          <OPRInputControl
            error={errors?.classId}
            isEditable={isEditable}
            label="employee_pension_fund_class_id"
            name="classId"
            value={values?.classId}
            onChange={handleChange}
          />
        </Grid>
        <Grid item md={2} sm={1} xs={1}>
          <OPRSelectorControl
            isRequired
            error={errors?.transferCode}
            isEditable={isEditable}
            keyName="value"
            label="employee_pension_fund_transfer_code"
            multiple={false}
            name="transferCode"
            options={employeeTransferCode}
            value={employeeTransferCode.find((o:any) => o?.value === values?.transferCode)}
            valueKey="transferCode"
            onChange={(text:any) => {
              handleOnChange('transferCode', text?.transferCode)
            }}
          />
        </Grid>
        <Grid item md={2} sm={1} xs={1}>
          <OPRSelectorControl
            isRequired
            error={errors?.lspSpFlag}
            isEditable={isEditable}
            keyName="name"
            label="long_service_and_severence_pay"
            multiple={false}
            name="lspSpFlag"
            options={employeeLongService}
            value={employeeLongService.find((o:any) => o?.value === values?.lspSpFlag)}
            onChange={(text:any) => {
              handleOnChange('lspSpFlag', text?.value)
            }}
          />
        </Grid>
        <Grid item md={2} sm={1} xs={1}>
          <OPRInputControl
            error={errors?.entitleLspSpAmount}
            isEditable={isEditable}
            label="employee_pension_fund_entitle_lsp_sp_amount"
            name="entitleLspSpAmount"
            value={values?.entitleLspSpAmount}
            onChange={handleChange}
          />
        </Grid>
        <Grid item md={2} sm={1} xs={1}>
          <OPRInputControl
            error={errors?.paidAmountForLspSp}
            isEditable={isEditable}
            label="employee_pension_fund_paid_amount_for_lsp_sp"
            name="classId"
            value={values?.paidAmountForLspSp}
            onChange={handleChange}
          />
        </Grid> */}
      </OPRResponsiveGrid>
    </Box>
  )
})

export default PensionFundEmployeeForm
