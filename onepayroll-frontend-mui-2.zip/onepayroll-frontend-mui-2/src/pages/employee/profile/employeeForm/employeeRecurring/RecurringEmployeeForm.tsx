import {
  Box, Grid,
} from '@mui/material'
import {
  useEmployeeRecurringCreateMutation, useEmployeeRecurringUpdateMutation, useGetAllEmployeeProfileQuery, useGetAllEmployeeRecurringDropDownQuery, useLazyGetEmployeeRecurringByIdQuery,
} from 'api/employeeServices'
import { useGetAllRegionQuery } from 'api/entityServices'
import { useGetAllPayGroupQuery, useGetAllPayItemMasterQuery } from 'api/payRollServices'
import OPRLabel from 'components/atoms/label/OPRLabel'
import { CustomTabPanel } from 'components/atoms/tabs'
import OPRDatePickerControl from 'components/molecules/OPRDatePickerControl/OPRDatePickerControl'
import OPRInputControl from 'components/molecules/OPRInputControl'
import OPRResponsiveGrid from 'components/molecules/OPRResponsiveGrid'
import OPRSelectorControl from 'components/molecules/OPRSelectorControl/OPRSelectorControl'
import OPRAlertControl from 'components/organism/OPRAlertControl'
import {
  employeeReccuringFPSValidationSalaryProrationSchema,
  employeeReccuringFPSValidationSchema, employeeReccuringGeneralValidationSchema, employeeReccuringValidationSchema,
} from 'constants/validate'
import { useEditable } from 'hooks/useEdit'
import useForm from 'hooks/useForm'
import React, {
  forwardRef, useEffect, useImperativeHandle,
} from 'react'
import { useLocation } from 'react-router-dom'
import { routes } from 'routes/routes'
import { generateFilterUrl } from 'utils'

import { customeDateFormat, defaultPageSize } from '../../../../../constants/index'

const defaultValue = {
  effectiveEndDate: '31/12/3000',
}
interface MessageProps {
    text?: string;
    important?: boolean;
  }

const validationList = (expression:any) => {
  let validationScheme:any = {}
  switch (expression) {
    case 0:
      validationScheme = employeeReccuringValidationSchema
      break
    case 1:
      validationScheme = employeeReccuringGeneralValidationSchema
      break
    case 2:
      validationScheme = employeeReccuringFPSValidationSalaryProrationSchema
      break
    default:
      validationScheme = employeeReccuringFPSValidationSchema
  }
  return validationScheme
}

const RecurringEmployeeForm = forwardRef(({
  id, empId, selectedTab, setSelectedTab, isModal, setSelectedId, isEditReccuring, effectiveDate,
}:any, ref) => {
  const {
    values,
    setValues,
    errors,
    handleChange,
    setErrors,
    handleFormSubmit,
    handleOnChange,
  } = useForm(validationList(selectedTab))
  const location: any = useLocation()
  const {
    isEditable,
    setEditable,
  } = useEditable()

  const handleTabChange = (event: React.SyntheticEvent, newValue: number) => {
    setSelectedTab(newValue)
  }
  const [messageId, setMessageId] = React.useState(null)
  // const [messageId, setMessageId]:any = useState(null)
  const [createEmployeeRecurring, {
    data: createdEmployeeRecurringData,
    error: createdEmployeeRecurringError,
    isLoading: createdEmployeeRecurringLoading,
    isSuccess: createdEmployeeRecurringSuccess,
    isError: createdEmployeeRecurringIsError,
  }] = useEmployeeRecurringCreateMutation()

  const {
    data: allPosts,
    error: createAllPostsBankAccountError,
    isLoading: isLoadingAllPosts,
    isSuccess: isSuccessAllPosts,
    isError: isErrorAllPosts,
    error: errorAllPosts,
  } = useGetAllEmployeeRecurringDropDownQuery(generateFilterUrl(defaultPageSize))

  const {
    data: allPostsItem,
    error: createAllPostsItemError,
    isLoading: isLoadingAllPostsItem,
    isSuccess: isSuccessAllPostsItem,
    isError: isErrorAllPostsItem,
    error: errorAllPostsItem,
  } = useGetAllPayItemMasterQuery(generateFilterUrl(defaultPageSize))

  const {
    data: allPostsGroup,
    error: createAllPostsGroupError,
    isLoading: isLoadingAllPostsGroup,
    isSuccess: isSuccessAllPostsGroup,
    isError: isErrorAllPostsGroup,
    error: errorAllPostsGroup,
  } = useGetAllPayGroupQuery(generateFilterUrl(defaultPageSize))

  const {
    data: employeeDataList,
    isLoading: isLoadingEmployeeDataList,
    isSuccess: isSuccessEmployeeDataList,
    isError: isErrorEmployeeDataList,
    error: errorEmployeeDataList,
    refetch: refetchEmployeeDataList,
  } = useGetAllEmployeeProfileQuery(generateFilterUrl({
    EffectiveDate: '10/10/2040',
    pageSize: 1000,
  }))
  const {
    data: allRegionPosts,
    isLoading: isLoadingAllRegionPosts,
    isSuccess: isSuccessAllRegionPosts,
    isError: isErrorAllRegionPosts,
    error: errorAllRegionPosts,
    refetch: refetchAllPosts,
  } = useGetAllRegionQuery(generateFilterUrl(defaultPageSize))

  const [updateEmployeeRecurring, {
    data: uupdatedClientGroupDataResponse,
    error: updatedEmployeeRecurringError,
    isLoading: updatedEmployeeRecurringLoading,
    isSuccess: updatedEmployeeRecurringSuccess,
    isError: updatedEmployeeRecurringIsError,
  }] = useEmployeeRecurringUpdateMutation()

  // const [updateEmployeeRecurringDropDownList, {
  //   data: uupdatedDropDownListResponse,
  //   error: updatedDropDownListError,
  //   isLoading: updatedDropDownListLoading,
  //   isSuccess: updatedDropDownListSuccess,
  //   isError: updatedDropDownListIsError,
  // }] = useGetAllEmployeeRecurringDropDownQuery()

  const [updateEmployeeRecurringById, {
    data: updatedEmployeeRecurringByIdResponse,
    error: updatedEmployeeRecurringByIdError,
    isLoading: updatedEmployeeRecurringByIdLoading,
    isSuccess: updatedEmployeeRecurringByIdSuccess,
    isError: updatedEmployeeRecurringByIdIsError,
  }] = useLazyGetEmployeeRecurringByIdQuery()
  useEffect(() => {
    if (id) {
      updateEmployeeRecurringById(id)
    }
  }, [])
  const parseDate = (dateString:any) => {
    const [day, month, year] = dateString.split('/').map(Number)
    return new Date(year, month - 1, day)
  }
  useEffect(() => {
    if (id && updatedEmployeeRecurringByIdSuccess) {
      setValues({ ...updatedEmployeeRecurringByIdResponse?.data, generateBackPay: updatedEmployeeRecurringByIdResponse?.data?.generateBackPay ? 'Yes' : 'No' })
      // setSelectedTab(0)
      // setEditable(false)
    } else {
      setValues({
        effectiveStartDate: new Date(effectiveDate),
        effectiveEndDate: parseDate(defaultValue.effectiveEndDate),
      })
      // setEditable(false)
    }
  }, [updatedEmployeeRecurringByIdSuccess])

  useEffect(() => {
    // if (isModal === false) {
    //   setValues({ })
    //   setSelectedId(undefined)
    //   setSelectedTab(0)
    // }
  }, [isModal])
  useEffect(() => {
    if (isModal === false) {
      setSelectedTab(0)
      setEditable(false)
    }
  }, [isModal])

  function getSurnameByEmployeeCode(employeeCode:any) {
    const employee = employeeDataList?.records?.find((emp:any) => emp.employeeCode === employeeCode)
    return employee?.employeeProfile?.id ? employee?.employeeProfile?.id : null
  }

  function getSurnameByEmployeeName(employeeCode:any) {
    const employee = employeeDataList?.records?.find((emp:any) => emp.employeeCode === employeeCode)
    return employee?.employeeProfile?.givenName ? employee?.employeeProfile?.givenName : null
  }
  useEffect(() => {
    if (selectedTab === 4) {
      setEditable(true)
    } else {
      setEditable(false)
    }
  }, [selectedTab])

  const handleSubmit:any = async () => {
    if (selectedTab === 0) {
      setSelectedTab(1)
    }
    if (selectedTab === 1) {
      setSelectedTab(2)
    }
    if (selectedTab === 2) {
      setSelectedTab(3)
      // await createEmployeeRecurring({ ...values })
    }
    if (selectedTab === 3) {
      setSelectedTab(4)
      // setEditable(true)
      // await createEmployeeRecurring({ ...values })
    }
    if (selectedTab === 4) {
      if (id) {
        updateEmployeeRecurring({
          ...values,
          generateBackPay: values.generateBackPay === 'Yes',
          employeeId: values?.employeeProfileId,
          // employeeId: getSurnameByEmployeeCode(empId),
          // employeeCode: empId,
          effectiveStartDate: customeDateFormat(values?.effectiveStartDate),
          effectiveEndDate: customeDateFormat(values?.effectiveEndDate),
          baseSalaryTypeId: values.baseSalaryTypeId.toString(),
          salaryProrationMethodId: values.salaryProrationMethodId.toString(),
          periodToGenerateBackpay: customeDateFormat(values?.periodToGenerateBackpay),
          spM_ActualDaysMethod: values.spM_ActualDaysMethod,
          spM_DivideByFixedDays: values?.spM_DivideByFixedDays,
          // payItemId: JSON.parse(JSON.stringify(allPostsItem?.records || []))?.find((o:any) => o?.payItemCode === values?.payItemCode)?.id,
          // payGroupId: JSON.parse(JSON.stringify(allPostsGroup?.records || []))?.find((o:any) => o?.payGroupCode === values?.payGroupCode)?.id,
        })
      } else {
        await createEmployeeRecurring({
          ...values,
          generateBackPay: values.generateBackPay === 'Yes',
          employeeId: getSurnameByEmployeeCode(empId),
          employeeCode: empId,
          effectiveStartDate: customeDateFormat(values?.effectiveStartDate),
          effectiveEndDate: customeDateFormat(values?.effectiveEndDate),
          baseSalaryTypeId: values.baseSalaryTypeId.toString(),
          salaryProrationMethodId: values.salaryProrationMethodId.toString(),
          periodToGenerateBackpay: customeDateFormat(values?.periodToGenerateBackpay),
          spM_ActualDaysMethod: values.spM_ActualDaysMethod,
          spM_DivideByFixedDays: values?.spM_DivideByFixedDays,
          // payItemId: JSON.parse(JSON.stringify(allPostsItem?.records || []))?.find((o:any) => o?.payItemCode === values?.payItemCode)?.id,
          // payGroupId: JSON.parse(JSON.stringify(allPostsGroup?.records || []))?.find((o:any) => o?.payGroupCode === values?.payGroupCode)?.id,
        })
      }
    }
    // if (isEditable) {
    //   await createEmployeeRecurring({ ...values, countryLocalization: JSON.parse(JSON.stringify(allPosts?.records || []))?.find((o:any) => o?.countryName === values?.countryLocalization).countryCode })
    // } else {
    //   setEditable(true)
    // }
  }
  useImperativeHandle(ref, () => ({
    handleOnSubmit(e:any) {
      handleFormSubmit(e, handleSubmit)
    },

  }))

  useEffect(() => {
    if (createdEmployeeRecurringSuccess) {
      // Reset form values after successful add operation
      setValues({})
      setErrors({})
    }
  }, [createdEmployeeRecurringSuccess])
  const selectedData = ''

  useEffect(() => {
    if (values?.payItemId) {
      setMessageId(values?.payItemId)
    }
  }, [values.payItemId])
  // const successfullMessage:any = () => {
  //   const htmString = `<div className="InsertContent" style={{width:  '100% '}}><span style="color:  '#3B3839 ', fontSize: 16, fontFamily:  'Lato ', fontWeight:  '700 ', lineHeight: 24, wordWrap:  'break-word '">${JSON.parse(JSON.stringify(allPostsItem?.records || []))?.find((o:any) => o?.id === messageId)?.payItemName}
  //   </span><span style="color:  '#3B3839 ', fontSize: 16, fontFamily:  'Lato ', fontWeight:  '400 ', lineHeight: 24, wordWrap:  'break-word '">has been added to </span><span style="color:  '#3B3839 ', fontSize: 16, fontFamily:  'Lato ', fontWeight:  '700 ', lineHeight: 24, wordWrap: 'break-word'">${getSurnameByEmployeeName(empId)}
  //   </span><span style="color:  '#3B3839 ', fontSize: 16, fontFamily:  'Lato ', fontWeight:  '400 ', wordWrap:  'break-word '">.</span></div>`
  //   const plainString = htmString.replace(/<[^>]+>/g, '')
  //   return plainString
  // }
  const type = id ? 'Update' : 'New'
  const successfullMessage = (type:any) => {
    const item = JSON.parse(JSON.stringify(allPostsItem?.records || [])).find((o:any) => o?.id === messageId)
    const payItemName = item?.payItemName || ''
    const employeeSurname = getSurnameByEmployeeName(empId)

    if (type === 'Update') {
      return `${payItemName} has been updated.`
    }
    const htmString = `<div className="InsertContent" style={{width: '100%'}}>
        <span style="color: '#3B3839', fontSize: 16, fontFamily: 'Lato', fontWeight: '700', lineHeight: 24, wordWrap: 'break-word'>${payItemName}</span>
        <span style="color: '#3B3839', fontSize: 16, fontFamily: 'Lato', fontWeight: '400', lineHeight: 24, wordWrap: 'break-word'>has been added to</span>
        <span style="color: '#3B3839', fontSize: 16, fontFamily: 'Lato', fontWeight: '700', lineHeight: 24, wordWrap: 'break-word'>${employeeSurname}</span>
        <span style="color: '#3B3839', fontSize: 16, fontFamily: 'Lato', fontWeight: '400', wordWrap: 'break-word'>.</span>
      </div>`

    return htmString.replace(/<[^>]+>/g, '')
  }
  useEffect(() => {
    if (id === null) {
      setValues(defaultValue)
    }
  }, [])

  useEffect(() => {
    setValues((prevValues: any) => ({
      ...prevValues,
      effectiveEndDate: values?.effectiveEndDate ? parseDate(values.effectiveEndDate) : parseDate(defaultValue.effectiveEndDate),
    }))
  }, [])
  return (
    <Box>
      <OPRAlertControl
        callBack={(type) => {
          // if (type === 'success') {
          //   navigate(-1)
          // }
        }}
        customMessage={successfullMessage(type)}
        error={createdEmployeeRecurringError || updatedEmployeeRecurringError}
        handleEditable={setEditable}
        handleSetValue={setValues}
        handleSubmit={handleSubmit}
        isError={createdEmployeeRecurringError || updatedEmployeeRecurringError}
        isLoading={createdEmployeeRecurringLoading || updatedEmployeeRecurringLoading || updatedEmployeeRecurringByIdLoading}
        isSuccess={updatedEmployeeRecurringSuccess || createdEmployeeRecurringSuccess}
        name={values?.EmployeeRecurringName}
        previousUrl={routes?.employeeProfile}
        title="Recurring item"
        type={id ? 'Update' : 'New'}
      />
      <OPRResponsiveGrid>

        <CustomTabPanel index={0} value={selectedTab}>
          <OPRLabel variant="h4">General recurring item information</OPRLabel>
          <OPRLabel CustomStyles={{ marginBottom: 25 }} variant="body2">All fields are mandatory except those marked optional.</OPRLabel>
          <OPRResponsiveGrid>
            <Grid item md={12} sm={1} xs={1}>
              <OPRSelectorControl
                isRequired
                error={errors?.payItemId}
                isEditable={isEditable}
                keyName="payItemCode"
                label="emp_pay_item"
                multiple={false}
                name="payItemCode"
                options={JSON.parse(JSON.stringify(allPostsItem?.records || []))}
                placeholder="Select an option"
                value={JSON.parse(JSON.stringify(allPostsItem?.records || []))?.find((o:any) => o?.id === values?.payItemId)}
                valueKey="id"
                onChange={(text:any) => {
                  handleOnChange('payItemId', text?.id)
                }}
              />
            </Grid>
            <Grid item md={12} sm={1} xs={1}>
              <OPRSelectorControl
                isRequired
                error={errors?.payGroupId}
                isEditable={isEditable}
                keyName="payGroupCode"
                label="emp_pay_group"
                multiple={false}
                name="payGroupCode"
                options={JSON.parse(JSON.stringify(allPostsGroup?.records || []))}
                placeholder="Select an option"
                value={JSON.parse(JSON.stringify(allPostsGroup?.records || []))?.find((o:any) => o?.id === values?.payGroupId) || {}}
                valueKey="id"
                onChange={(text:any) => {
                  handleOnChange('payGroupId', text?.id)
                }}
              />
            </Grid>
            <Grid item md={2} sm={1} xs={1}>
              <OPRDatePickerControl
                isRequired
                error={errors?.effectiveStartDate}
                isEditable={isEditable}
                label="effectiveStartDate"
                name="effectiveStartDate"
                // value={values?.effectiveStartDate ? values?.effectiveStartDate?.toISOString() : null}
                value={values?.effectiveStartDate || null}
                onChange={(date) => {
                  handleOnChange('effectiveStartDate', date)
                }}
              />
            </Grid>
            {
              // JSON.parse(JSON.stringify(allPosts?.records || []))
            }
            <Grid item md={2} sm={1} xs={1}>
              <OPRDatePickerControl
                isRequired
                error={errors?.effectiveEndDate}
                isEditable={isEditable}
                label="effectiveEndDate"
                name="effectiveEndDate"
                // value={values?.effectiveStartDate ? values?.effectiveStartDate?.toISOString() : null}
                value={values?.effectiveEndDate || null}
                onChange={(date) => {
                  handleOnChange('effectiveEndDate', date)
                }}
              />
            </Grid>
            <Grid item md={12} sm={1} xs={1}>
              <OPRInputControl
                multiline
                error={errors?.remarks}
                isEditable={isEditable}
                label="emp_remarks"
                name="remarks"
                optionalText="Optional"
                value={values?.remarks}
                onChange={handleChange}
              />
            </Grid>
          </OPRResponsiveGrid>
        </CustomTabPanel>
        <CustomTabPanel index={1} value={selectedTab}>
          <OPRLabel CustomStyles={{ paddingLeft: 15 }} variant="h4">Payment information</OPRLabel>
          <OPRLabel CustomStyles={{ marginBottom: 25 }} variant="body2">All fields are mandatory except those marked optional.</OPRLabel>
          <OPRResponsiveGrid>
            <Grid item md={2} sm={1} xs={1}>
              <OPRSelectorControl
                isRequired
                error={errors?.baseSalaryTypeId}
                isEditable={isEditable}
                keyName="label"
                label="emp_base_salary_type"
                multiple={false}
                name="label"
                options={JSON.parse(JSON.stringify(allPosts?.baseSalaryTypes || []))}
                value={JSON.parse(JSON.stringify(allPosts?.baseSalaryTypes || []))?.find((o:any) => (o?.id === values?.baseSalaryTypeId ? values.baseSalaryTypeId : values.baseSalaryType)) || {}}
                valueKey="id"
                onChange={(text:any) => {
                  handleOnChange('baseSalaryTypeId', text?.id)
                }}
              />
            </Grid>
            <Grid item md={2} sm={1} xs={1}>
              <OPRSelectorControl
                isRequired
                error={errors?.baseSalaryCurrencyId}
                isEditable={isEditable}
                keyName="label"
                label="emp_base_salary_currency"
                multiple={false}
                name="label"
                options={JSON.parse(JSON.stringify(allPosts?.baseSalaryCurrencys || []))}
                value={JSON.parse(JSON.stringify(allPosts?.baseSalaryCurrencys || []))?.find((o:any) => (o?.id === values?.baseSalaryCurrencyId)) || {}}
                valueKey="id"
                onChange={(text:any) => {
                  handleOnChange('baseSalaryCurrencyId', text?.id)
                }}
              />
            </Grid>
            <Grid item md={2} sm={1} xs={1}>
              <OPRSelectorControl
                isRequired
                error={errors?.paymentCurrencyId}
                isEditable={isEditable}
                keyName="label"
                label="emp_payment_currency"
                multiple={false}
                name="label"
                options={JSON.parse(JSON.stringify(allPosts?.baseSalaryCurrencys || []))}
                value={JSON.parse(JSON.stringify(allPosts?.baseSalaryCurrencys || []))?.find((o:any) => (o?.id === values?.paymentCurrencyId)) || {}}
                valueKey="id"
                onChange={(text:any) => {
                  handleOnChange('paymentCurrencyId', text?.id)
                }}
              />
            </Grid>
            <Grid item md={2} sm={1} xs={1}>
              <OPRInputControl
                error={errors?.baseSalaryAmount}
                isEditable={isEditable}
                label="emp_base_salary_amount"
                name="baseSalaryAmount"
                value={values?.baseSalaryAmount}
                onChange={handleChange}
              />
            </Grid>

          </OPRResponsiveGrid>
        </CustomTabPanel>
        <CustomTabPanel index={2} value={selectedTab}>
          <OPRLabel variant="h4">Salary proration method</OPRLabel>
          <OPRLabel CustomStyles={{ marginBottom: 25 }} variant="body2">All fields are mandatory except those marked optional.</OPRLabel>
          <OPRResponsiveGrid>
            <Grid item md={12} sm={1} xs={1}>
              <OPRSelectorControl
                isRequired
                error={errors?.salaryProrationMethodId}
                isEditable={isEditable}
                keyName="label"
                label="emp_base_salary_proration_method"
                multiple={false}
                name="label"
                options={JSON.parse(JSON.stringify(allPosts?.salaryProrationMethods || []))}
                value={JSON.parse(JSON.stringify(allPosts?.salaryProrationMethods || []))?.find((o:any) => o?.id === values?.salaryProrationMethodId)}
                valueKey="id"
                onChange={(text:any) => {
                  handleOnChange('salaryProrationMethodId', text?.id)
                }}
              />
            </Grid>
            <Grid item md={2} sm={1} xs={1}>
              <OPRSelectorControl
                isRequired
                error={errors?.spM_ActualDaysMethod}
                isEditable={isEditable}
                keyName="label"
                label="Actual days method"
                multiple={false}
                name="label"
                options={
                  [
                    { label: 'Actual Working Days', value: 'Actual Working Days' },
                    { label: 'Actual Calendar Days', value: 'Actual Calendar Days' },
                  ]
                }
                value={[
                  { label: 'Actual Working Days', value: 'Actual Working Days' },
                  { label: 'Actual Calendar Days', value: 'Actual Calendar Days' },
                ]?.find((o:any) => o?.value === values?.spM_ActualDaysMethod) || {}}
                valueKey="value"
                onChange={(text:any) => {
                  handleOnChange('spM_ActualDaysMethod', text?.value)
                }}
              />
            </Grid>
            {/* <Grid item md={2} sm={1} xs={1}>
              <OPRInputControl
                error={errors?.spM_DivideByFixedDays}
                isEditable={isEditable}
                label="Fixed days"
                name="spM_DivideByFixedDays"
                value={values?.spM_DivideByFixedDays}
                onChange={handleChange}
              />
            </Grid> */}
            {

              values?.salaryProrationMethodId === 6 || values?.salaryProrationMethodId === 9 ? (
                <Grid item md={2} sm={1} xs={1}>
                  <OPRInputControl
                    error={errors?.spM_DivideByFixedDays}
                    isEditable={isEditable}
                    label="Fixed days"
                    name="spM_DivideByFixedDays"
                    value={values?.spM_DivideByFixedDays}
                    onChange={handleChange}
                  />
                </Grid>
              ) : <Grid item md={2} sm={1} xs={1} />
            }

          </OPRResponsiveGrid>
        </CustomTabPanel>
        <CustomTabPanel index={3} value={selectedTab}>
          <OPRLabel CustomStyles={{ paddingLeft: 15 }} variant="h4">Backpay information</OPRLabel>
          <OPRLabel CustomStyles={{ marginBottom: 25 }} variant="body2">All fields are mandatory except those marked optional.</OPRLabel>
          <OPRResponsiveGrid>
            {/* <Grid item md={2} sm={1} xs={1}>
              <OPRSelectorControl
                isRequired
                error={errors?.payItemId}
                isEditable={isEditable}
                keyName="employeeCode"
                label="emp_employee_code"
                multiple={false}
                name="employeeCode"
                options={JSON.parse(JSON.stringify(employeeDataList?.records || []))}
                placeholder="Select an option"
                value={JSON.parse(JSON.stringify(employeeDataList?.records || []))?.find((o:any) => o?.countryName === values?.countryLocalization) || {}}
                valueKey="employeeCode"
                onChange={(text:any) => {
                  handleOnChange('employeeCode', text?.payItemId)
                }}
              />
            </Grid> */}

            <Grid item md={2} sm={1} xs={1}>
              <OPRSelectorControl
                isRequired
                error={errors?.generateBackPay}
                isEditable={isEditable}
                keyName="label"
                label="emp_generate_backpay"
                multiple={false}
                name="label"
                options={[
                  {
                    label: 'Yes',
                  },
                  {
                    label: 'No',
                  },
                ]}
                value={[
                  {
                    label: 'Yes',
                  },
                  {
                    label: 'No',
                  },
                ]?.find((o:any) => o?.label === values?.generateBackPay) || {}}
                valueKey="label"
                onChange={(text:any) => {
                  handleOnChange('generateBackPay', text?.label)
                }}
              />
            </Grid>
            <Grid item md={2} sm={1} xs={1}>
              <OPRDatePickerControl
                isRequired
                error={errors?.periodToGenerateBackpay}
                isEditable={isEditable}
                label="emp_period_generate_backpay"
                name="periodToGenerateBackpay"
                // value={values?.effectiveStartDate ? values?.effectiveStartDate?.toISOString() : null}
                value={values?.periodToGenerateBackpay || null}
                onChange={(date) => {
                  handleOnChange('periodToGenerateBackpay', date)
                }}
              />
            </Grid>
          </OPRResponsiveGrid>
        </CustomTabPanel>
        <CustomTabPanel index={4} value={selectedTab}>
          <OPRLabel variant="h4">Add recurring item</OPRLabel>
          <OPRLabel CustomStyles={{ marginBottom: 25 }} variant="body2">All fields are mandatory except those marked optional.</OPRLabel>
          <OPRLabel variant="h4">General recurring item information</OPRLabel>
          <br />
          <OPRResponsiveGrid>
            <Grid item md={12} sm={1} xs={1}>
              <OPRSelectorControl
                isRequired
                error={errors?.payItemId}
                isEditable={isEditable}
                keyName="payItemCode"
                label="emp_pay_item"
                multiple={false}
                name="payItemCode"
                options={JSON.parse(JSON.stringify(allPosts?.payItems || []))}
                placeholder="Select an option"
                value={JSON.parse(JSON.stringify(allPostsItem?.records || []))?.find((o:any) => o?.id === values?.payItemId)}
                valueKey="payItemCode"
                onChange={(text:any) => {
                  handleOnChange('payItemId', text?.id)
                }}
              />
            </Grid>
            <Grid item md={12} sm={1} xs={1}>
              <OPRSelectorControl
                isRequired
                error={errors?.payGroupCode}
                isEditable={isEditable}
                keyName="payGroupCode"
                label="emp_pay_group"
                multiple={false}
                name="payGroupCode"
                options={JSON.parse(JSON.stringify(allPosts?.payGroups || []))}
                placeholder="Select an option"
                value={JSON.parse(JSON.stringify(allPostsGroup?.records || []))?.find((o:any) => o?.id === values?.payGroupId) || {}}
                valueKey="payGroupCode"
                onChange={(text:any) => {
                  handleOnChange('payGroupId', text?.payGroupCode)
                }}
              />
            </Grid>
            <Grid item md={2} sm={1} xs={1}>
              <OPRDatePickerControl
                isRequired
                error={errors?.effectiveStartDate}
                isEditable={isEditable}
                label="effectiveStartDate"
                name="effectiveStartDate"
                // value={values?.effectiveStartDate ? values?.effectiveStartDate?.toISOString() : null}
                value={values?.effectiveStartDate || null}
                onChange={(date) => {
                  handleOnChange('effectiveStartDate', date)
                }}
              />
            </Grid>
            {
              // JSON.parse(JSON.stringify(allPosts?.records || []))
            }
            <Grid item md={2} sm={1} xs={1}>
              <OPRDatePickerControl
                isRequired
                error={errors?.effectiveEndDate}
                isEditable={isEditable}
                label="effectiveEndDate"
                name="effectiveEndDate"
                // value={values?.effectiveStartDate ? values?.effectiveStartDate?.toISOString() : null}
                value={values?.effectiveEndDate || null}
                onChange={(date) => {
                  handleOnChange('effectiveEndDate', date)
                }}
              />
            </Grid>
            <Grid item md={12} sm={1} xs={1}>
              <OPRInputControl
                multiline
                error={errors?.remarks}
                isEditable={isEditable}
                label="emp_remarks"
                name="remarks"
                value={values?.remarks}
                onChange={handleChange}
              />
            </Grid>
            <br />
            <OPRLabel CustomStyles={{ paddingLeft: 15, width: '100%' }} variant="h4">Payment information</OPRLabel>
            <Grid item md={2} sm={1} xs={1}>
              <OPRSelectorControl
                isRequired
                error={errors?.baseSalaryTypeId}
                isEditable={isEditable}
                keyName="label"
                label="emp_base_salary_type"
                multiple={false}
                name="label"
                options={JSON.parse(JSON.stringify(allPosts?.baseSalaryTypes || []))}
                value={JSON.parse(JSON.stringify(allPosts?.baseSalaryTypes || []))?.find((o:any) => o?.id === values?.baseSalaryTypeId) || {}}
                valueKey="id"
                onChange={(text:any) => {
                  handleOnChange('baseSalaryTypeId', text?.id)
                }}
              />
            </Grid>
            <Grid item md={2} sm={1} xs={1}>
              <OPRSelectorControl
                isRequired
                error={errors?.baseSalaryCurrencyId}
                isEditable={isEditable}
                keyName="label"
                label="emp_base_salary_currency"
                multiple={false}
                name="label"
                options={JSON.parse(JSON.stringify(allPosts?.baseSalaryCurrencys || []))}
                value={JSON.parse(JSON.stringify(allPosts?.baseSalaryCurrencys || []))?.find((o:any) => o?.id === values?.baseSalaryCurrencyId) || {}}
                valueKey="label"
                onChange={(text:any) => {
                  handleOnChange('baseSalaryCurrencyId', text?.id)
                }}
              />
            </Grid>
            <Grid item md={2} sm={1} xs={1}>
              <OPRSelectorControl
                isRequired
                error={errors?.paymentCurrencyId}
                isEditable={isEditable}
                keyName="label"
                label="emp_payment_currency"
                multiple={false}
                name="label"
                options={JSON.parse(JSON.stringify(allPosts?.baseSalaryCurrencys || []))}
                value={JSON.parse(JSON.stringify(allPosts?.baseSalaryCurrencys || []))?.find((o:any) => o?.id === values?.paymentCurrencyId) || {}}
                valueKey="label"
                onChange={(text:any) => {
                  handleOnChange('paymentCurrencyId', text?.id)
                }}
              />
            </Grid>
            <Grid item md={2} sm={1} xs={1}>
              <OPRInputControl
                error={errors?.baseSalaryAmount}
                isEditable={isEditable}
                label="emp_base_salary_amount"
                name="baseSalaryAmount"
                value={values?.baseSalaryAmount}
                onChange={handleChange}
              />
            </Grid>
            <OPRLabel CustomStyles={{ paddingLeft: 15, width: '100%' }} variant="h4">Salary proration method</OPRLabel>
            <Grid item md={12} sm={1} xs={1}>
              <OPRSelectorControl
                isRequired
                error={errors?.salaryProrationMethodId}
                isEditable={isEditable}
                keyName="label"
                label="emp_base_salary_proration_method"
                multiple={false}
                name="label"
                options={JSON.parse(JSON.stringify(allPosts?.salaryProrationMethods || []))}
                value={JSON.parse(JSON.stringify(allPosts?.salaryProrationMethods || []))?.find((o:any) => o?.id === values?.salaryProrationMethodId) || {}}
                valueKey="id"
                onChange={(text:any) => {
                  handleOnChange('salaryProrationMethodId', text?.id)
                }}
              />
            </Grid>
            <Grid item md={2} sm={1} xs={1}>
              <OPRSelectorControl
                isRequired
                error={errors?.spM_ActualDaysMethod}
                isEditable={isEditable}
                keyName="label"
                label="Actual days method"
                multiple={false}
                name="label"
                options={
                  [
                    { label: 'Actual Working Days', value: 'Actual Working Days' },
                    { label: 'Actual Calendar Days', value: 'Actual Calendar Days' },
                  ]
                }
                value={[
                  { label: 'Actual Working Days', value: 'Actual Working Days' },
                  { label: 'Actual Calendar Days', value: 'Actual Calendar Days' },
                ]?.find((o:any) => o?.value === values?.spM_ActualDaysMethod) || {}}
                valueKey="value"
                onChange={(text:any) => {
                  handleOnChange('spM_ActualDaysMethod', text?.value)
                }}
              />
            </Grid>
            {
              (values?.salaryProrationMethodId === 6 || values?.salaryProrationMethodId === 9) && (
                <Grid item md={2} sm={1} xs={1}>
                  <OPRInputControl
                    error={errors?.spM_DivideByFixedDays}
                    isEditable={isEditable}
                    label="Fixed days"
                    name="spM_DivideByFixedDays"
                    value={values?.spM_DivideByFixedDays}
                    onChange={handleChange}
                  />
                </Grid>
              )
            }

            <br />
            <OPRLabel CustomStyles={{ paddingLeft: 15, width: '100%' }} variant="h4">Backpay information</OPRLabel>
            {/* <Grid item md={2} sm={1} xs={1}>
              <OPRSelectorControl
                isRequired
                error={errors?.payItemId}
                isEditable={isEditable}
                keyName="employeeCode"
                label="emp_employee_code"
                multiple={false}
                name="employeeCode"
                options={JSON.parse(JSON.stringify(employeeDataList?.records || []))}
                placeholder="Select an option"
                value={JSON.parse(JSON.stringify(employeeDataList?.records || []))?.find((o:any) => o?.countryName === values?.countryLocalization) || {}}
                valueKey="employeeCode"
                onChange={(text:any) => {
                  handleOnChange('employeeCode', text?.payItemId)
                }}
              />
            </Grid> */}

            <Grid item md={2} sm={1} xs={1}>
              <OPRSelectorControl
                isRequired
                error={errors?.generateBackPay}
                isEditable={isEditable}
                keyName="label"
                label="emp_generate_backpay"
                multiple={false}
                name="label"
                options={[
                  {
                    label: 'Yes',
                  },
                  {
                    label: 'No',
                  },
                ]}
                value={[
                  {
                    label: 'Yes',
                  },
                  {
                    label: 'No',
                  },
                ]?.find((o:any) => o?.label === values?.generateBackPay) || {}}
                valueKey="label"
                onChange={(text:any) => {
                  handleOnChange('generateBackPay', text?.label)
                }}
              />
            </Grid>
            <Grid item md={2} sm={1} xs={1}>
              <OPRDatePickerControl
                isRequired
                error={errors?.periodToGenerateBackpay}
                isEditable={isEditable}
                label="emp_period_generate_backpay"
                name="periodToGenerateBackpay"
                // value={values?.effectiveStartDate ? values?.effectiveStartDate?.toISOString() : null}
                value={values?.periodToGenerateBackpay || null}
                onChange={(date) => {
                  handleOnChange('periodToGenerateBackpay', date)
                }}
              />
            </Grid>
          </OPRResponsiveGrid>
        </CustomTabPanel>
      </OPRResponsiveGrid>
    </Box>
  )
})

export default RecurringEmployeeForm
