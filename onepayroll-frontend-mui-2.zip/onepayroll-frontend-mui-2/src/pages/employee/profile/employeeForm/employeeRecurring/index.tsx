import {
  Box,
} from '@mui/material'
import { useEmployeeRecurringDeleteMutation, useGetAllEmployeeRecurringQuery } from 'api/employeeServices'
import { RighCaretBlue, WhiteRightCaret } from 'assets/svg-images/SvgComponents'
import OPRButton from 'components/atoms/button/OPRButton'
import OPRLabel from 'components/atoms/label/OPRLabel'
import CustomLoader from 'components/atoms/loader/OPRLoader'
import { CustomDialog } from 'components/atoms/modal/OPRModal'
import OPRPagination from 'components/atoms/pagination/OPRPagination'
import OPRTable from 'components/atoms/table/OPRTable'
import { employeeRecurringItemsColumn } from 'components/atoms/table/OPRTableConstant'
import CancelAlert from 'components/molecules/OPRAlertControl/CancelAlert'
import { OPRDeleteControl } from 'components/molecules/OPRAlertControl/OPRDeleteControl'
import OPRErrorAlertControl from 'components/molecules/OPRAlertControl/OPRErrorControl'
import { defaultPageSize } from 'constants/index'
import React, { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import {
  generateFilterUrl,
} from 'utils'

import RecurringEmployeeForm from './RecurringEmployeeForm'

function RecurringEmployeeList({
  id, setCount, effectiveDate, ProfileId,
}:any) {
  const [selelctedUser, setSelelctedUser]:any = useState({
    data: {},
    isDelete: false,
    name: '',
  })
  const myRef:any = React.useRef()
  const [selectedId, setSelectedId]:any = useState(undefined)
  const [selectedTab, setSelectedTab] = React.useState(0)
  const [isCancel, setCancel] = useState(false)
  const [isModal, setModal] = useState(false)
  const navigate: any = useNavigate()
  const [isEditReccuring, setIsEditReccuring]:any = useState(false)
  const [filterData, setFilterData]:any = useState({
    pageNumber: 1,
    pageSize: 20,
    totalItems: 0,
    orderByAsc: true,
    sortBy: '',
    SearchText: id,
  })
  const {
    data: allPosts,
    error: createAllPostsBankAccountError,
    isLoading: isLoadingAllPosts,
    isSuccess: isSuccessAllPosts,
    isError: isErrorAllPosts,
    error: errorAllPosts,
  } = useGetAllEmployeeRecurringQuery(`${generateFilterUrl(defaultPageSize)}&EmployeeProfileId=${ProfileId}`)

  const [deleteEmployeeRecurringById,
    {
      data: deleteEmployeeRecurringResponse,
      error: deleteEmployeeRecurringError,
      isLoading: deleteEmployeeRecurringLoading,
      isSuccess: deleteEmployeeRecurringSuccess,
      isError: deleteEmployeeRecurringIsError,
    }] = useEmployeeRecurringDeleteMutation()
  useEffect(() => {
    if (isModal === false) {
      setSelectedId(null)
      setIsEditReccuring(false)
    }
  }, [isModal])
  const sorting = (
    event: React.MouseEvent<unknown>,
    property: keyof any,
  ) => {
    const isAsc = filterData.sortBy === property && filterData.orderByAsc === true
    setFilterData({ ...filterData, orderByAsc: !isAsc, sortBy: property })
    // setOrder(isAsc ? 'desc' : 'asc')
    // setOrderBy(property)
  }

  useEffect(() => {
    setCount(JSON.parse(JSON.stringify(allPosts || [])).totalItems)
  }, [isSuccessAllPosts])

  useEffect(() => {
    setFilterData({ ...filterData, totalItems: allPosts?.totalItems ? allPosts?.totalItems : 0 })
  }, [allPosts?.pageNumber, filterData.sortBy, filterData.orderByAsc, allPosts?.totalItems])

  const onSearch = (e: any, data: any) => {
    setFilterData({ ...filterData, ...data })
  }
  const handlePagination = (pageNumber: number, pageSize: number) => {
    setFilterData({ ...filterData, pageNumber })
  }
  const viewAcoount = (data: any, type:string) => {
    if (type === 'Edit Recurring Item') {
      setModal(!isModal)
      setSelectedId(data.id)
      // navigate(
      //   setRouteValues(`${routes.editEmployeeRecurring}`, {
      //     id: data.clientGroupProfileId,
      //     profilId: data.id,
      //   }),
      // )
    } else if (type === 'delete') {
      setSelelctedUser({ data, isDelete: true, name: data.clientGroupName })
    } else if (type === 'change status') {

      // deleteEmployeeRecurringById(`Id=${data.id}`)
    } else {
      // navigate(
      //   setRouteValues(`${routes.viewEmployeeRecurring}`, {
      //     id: data.clientGroupProfileId,
      //     profilId: data.id,
      //     view: false,
      //   }),
      // )
    }
    // const id = JSON.stringify(data)
  }

  const handleView = (data: any) => {
    setSelectedId(data.id)
    setSelectedTab(4)
    setIsEditReccuring(!isEditReccuring)
    setModal(!isModal)
  }
  const deleteEntities = (data:any) => {
    deleteEmployeeRecurringById(`Id=${data.id}`)
  }
  return (
    <Box sx={{ display: 'flex', flexDirection: 'column' }}>
      <Box sx={{ display: 'flex', justifyContent: 'flex-end', alignItems: 'center' }}>
        <OPRButton
          startIcon
          handleClick={() => {
            setModal(!isModal)
          }}
          variant="text"
        >
          {' '}
          Add Recurring Item
        </OPRButton>
      </Box>
      <CustomDialog
        CustomStyles={{ borderRadius: '16px' }}
        isOpen={isModal}
        type="loader"
      >
        <form style={{ width: '100% ' }} onSubmit={(e) => myRef?.current?.handleOnSubmit(e)}>
          {/* <EmployeeModal isModal={isModal} setModal={setModal}><RecurringEmployeeForm ref={myRef} /></EmployeeModal> */}
          <RecurringEmployeeForm ref={myRef} effectiveDate={effectiveDate} empId={id} id={selectedId} isEditReccuring={isEditReccuring} isModal={isModal} selectedTab={selectedTab} setSelectedId={setSelectedId} setSelectedTab={setSelectedTab} />
          <Box sx={{
            display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: 5,
          }}
          >
            <OPRButton color="info" variant="text" onClick={() => setCancel(true)}>
              Cancel
            </OPRButton>
            {!isEditReccuring && (
              <Box>
                {selectedTab === 0 ? <div /> : (
                  <OPRButton
                    style={{ marginLeft: 'auto' }}
                    variant="text"
                    onClick={() => {
                      setSelectedTab(selectedTab - 1)
                    }}
                  >
                    <RighCaretBlue />
                    Back
                  </OPRButton>
                )}
                <OPRButton
                  color="primary"
                  variant="contained"
                  onClick={(e:any) => {
                    myRef?.current?.handleOnSubmit(e)
                  }}
                >
                  {
                    selectedTab === 3 ? 'Confirm ' : 'Continue'
                  }
                  {' '}
                  <Box>
                    <WhiteRightCaret />
                  </Box>
                </OPRButton>
              </Box>
            )}

          </Box>
        </form>
      </CustomDialog>
      <CancelAlert
        callBack={() => {
          setCancel(false)
          setModal(false)
        }}
        handleCancel={() => {
          setCancel(false)
        }}
        isCancel={isCancel}
      />
      {/* */}
      <CustomDialog
        CustomStyles={{ borderRadius: '16px' }}
        isOpen={isLoadingAllPosts}
        type="loader"
      >
        <CustomLoader text="Processing request" />
      </CustomDialog>
      <OPRDeleteControl
        deleteCallBack={deleteEntities}
        selelctedUser={selelctedUser}
        setSelelctedUser={setSelelctedUser}
        title="Client Group Entities"
      />
      <OPRErrorAlertControl
        error={deleteEmployeeRecurringError}
        header="Failed to Delete"
        isBackButton={false}
        isError={deleteEmployeeRecurringIsError}
        isTry={false}
        name="Client Group Entities"
      />
      <OPRLabel CustomStyles={{ marginBottom: 5 }} variant="body2">
        {JSON.parse(JSON.stringify(allPosts?.records || [])).length}
        {' '}
        items
      </OPRLabel>
      <OPRTable
        cols={employeeRecurringItemsColumn(viewAcoount)}
        data={JSON.parse(JSON.stringify(allPosts?.records || []))}
        handleEdit={viewAcoount}
        isLoader={isLoadingAllPosts}
        newOptions={[]}
        orderBy={filterData?.orderByAsc}
        rowClickHandler={handleView}
        rowNumber={0}
        sortBy={filterData?.sortBy}
        title="title"
        onRequestSort={sorting}
      />
      {
        filterData?.totalItems < 20 ? null : (
          <Box sx={{ display: 'flex', justifyContent: 'center', mt: 2 }}>
            <OPRPagination
              limit={filterData?.pageSize}
              page={filterData?.pageNumber}
              setPage={handlePagination}
              total={filterData?.totalItems}
            />
          </Box>
        )
      }
    </Box>
  )
}

export default RecurringEmployeeList
