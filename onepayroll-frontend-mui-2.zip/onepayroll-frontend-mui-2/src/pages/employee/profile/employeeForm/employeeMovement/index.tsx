import {
  Box,
} from '@mui/material'
import {
  useEmpMovement1Update2Mutation, useGetAllEmployeeMovementActionQuery,
} from 'api/employeeServices'
import { TickIcon } from 'assets/svg-images/SvgComponents'
import OPRLabel from 'components/atoms/label/OPRLabel'
import CustomLoader from 'components/atoms/loader/OPRLoader'
import { CustomDialog } from 'components/atoms/modal/OPRModal'
import OPRPagination from 'components/atoms/pagination/OPRPagination'
import OPRTable from 'components/atoms/table/OPRTable'
import { employeeMovementColumn } from 'components/atoms/table/OPRTableConstant'
import { OPRConfirmationDialog } from 'components/molecules/OPRAlertControl/OPRConfirmationDialog'
import { OPRDeleteControl } from 'components/molecules/OPRAlertControl/OPRDeleteControl'
import OPRErrorAlertControl from 'components/molecules/OPRAlertControl/OPRErrorControl'
import { defaultPageSize } from 'constants/index'
import React, { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import {
  generateFilterUrl,
} from 'utils'

function MovementEmployeeList({
  ProfileId, id, setCount, empName,
}:any) {
  const [selelctedUser, setSelelctedUser]:any = useState({
    data: {},
    isDelete: false,
    name: '',
  })
  const [isOpen, setOpen]:any = useState(false)
  const navigate: any = useNavigate()
  const [filterData, setFilterData]:any = useState({
    pageNumber: 1,
    pageSize: 20,
    totalItems: 0,
    orderByAsc: true,
    sortBy: '',
    SearchText: id,
  })
  const {
    data: allPosts,
    error: createAllPostsBankAccountError,
    isLoading: isLoadingAllPosts,
    isSuccess: isSuccessAllPosts,
    isError: isErrorAllPosts,
    error: errorAllPosts,
  } = useGetAllEmployeeMovementActionQuery(`${generateFilterUrl(defaultPageSize)}&EmployeeProfileId=${ProfileId}`)
  useEffect(() => {
    setCount(JSON.parse(JSON.stringify(allPosts || [])).totalItems)
  }, [isSuccessAllPosts])
  // console.log(useEmployeeMovementChangeStatusMutation, 'useClientGroupEntitesChangeStatusMutationuseClientGroupEntitesChangeStatusMutation')

  // const [deleteEmployeeMovementById,
  //   {
  //     data: deleteEmployeeMovementResponse,
  //     error: deleteEmployeeMovementError,
  //     isLoading: deleteEmployeeMovementLoading,
  //     isSuccess: deleteEmployeeMovementSuccess,
  //     isError: deleteEmployeeMovementIsError,
  //   }] = useEmpMovementDeleteMutation()

  const [
    updateEmpMovementById,
    {
      data: updateEmpMovementByIdResponse,
      error: updateEmpMovementError,
      isLoading: updateEmpMovementIsLoading,
      isSuccess: updateEmpMovementIsSuccess,
      isError: updateEmpMovementIsError,
    },
  ] = useEmpMovement1Update2Mutation()
  useEffect(() => {
    if (updateEmpMovementIsSuccess) {
      setOpen(true)
    }
  }, [updateEmpMovementIsSuccess])
  const sorting = (
    event: React.MouseEvent<unknown>,
    property: keyof any,
  ) => {
    const isAsc = filterData.sortBy === property && filterData.orderByAsc === true
    setFilterData({ ...filterData, orderByAsc: !isAsc, sortBy: property })
    // setOrder(isAsc ? 'desc' : 'asc')
    // setOrderBy(property)
  }

  useEffect(() => {
    setFilterData({ ...filterData, totalItems: allPosts?.totalItems ? allPosts?.totalItems : 0 })
  }, [allPosts?.pageNumber, filterData.sortBy, filterData.orderByAsc, allPosts?.totalItems])

  const onSearch = (e: any, data: any) => {
    setFilterData({ ...filterData, ...data })
  }
  const handlePagination = (pageNumber: number, pageSize: number) => {
    setFilterData({ ...filterData, pageNumber })
  }
  // const viewAcoount = (data: any, type:string) => {
  //   if (type === 'Withdraw Movement') {
  //     updateEmpMovementById(id)
  //     // setEditable(viewUrl)
  //     // setSelelctedUser({ data, isDelete: true, name: data?.movementType })
  //   }
  // }
  const viewAcoount = (data: any, type: string) => {
    if (type === 'Withdraw Movement') {
      setSelelctedUser({ data, isDelete: true, name: data.movementType })
      // updateEmpMovementById({ id: data.id }) // Pass the id here
    }
  }

  const handleView = (data: any) => {

  }

  const deleteEntities = (data:any) => {
    updateEmpMovementById(`Id=${data.id}`)
  }
  return (
    <Box sx={{ display: 'flex', flexDirection: 'column' }}>
      <CustomDialog
        CustomStyles={{ borderRadius: '16px' }}
        isOpen={isLoadingAllPosts}
        type="loader"
      >
        <CustomLoader text="Processing request" />
      </CustomDialog>
      <OPRConfirmationDialog
        buttonLayout="close"
        icon={<TickIcon />}
        infoMessage=""
        message={(
          <>
            {`${empName} has been updated`}
            .
          </>
        )}
        open={isOpen}
        title="Employee profile updated"
        onClose={() => setOpen(false)}
      />
      <OPRDeleteControl
        deleteCallBack={deleteEntities}
        isUserDelete={updateEmpMovementIsLoading}
        // isWithdraw={updateEmpMovementIsSuccess}
        selelctedUser={selelctedUser}
        setSelelctedUser={setSelelctedUser}
        title="Employee Movements"
      />
      <OPRErrorAlertControl
        error={updateEmpMovementError}
        header="Failed to Delete"
        isBackButton={false}
        isError={updateEmpMovementIsError}
        isTry={false}
        name="Employee Movements"
        // isLoading={updateEmpMovementIsLoading}

      />
      <OPRLabel CustomStyles={{ marginBottom: 5 }} variant="body2">
        {JSON.parse(JSON.stringify(allPosts?.records || [])).length}
        {' '}
        items
      </OPRLabel>
      <OPRTable
        cols={employeeMovementColumn(viewAcoount)}
        data={JSON.parse(JSON.stringify(allPosts?.records || []))}
        handleEdit={viewAcoount}
        isLoader={isLoadingAllPosts}
        newOptions={[]}
        orderBy={filterData?.orderByAsc}
        rowClickHandler={handleView}
        rowNumber={0}
        sortBy={filterData?.sortBy}
        title="title"
        onRequestSort={sorting}
      />
      {
        filterData?.totalItems < 20 ? null : (
          <Box sx={{ display: 'flex', justifyContent: 'center', mt: 2 }}>
            <OPRPagination
              limit={filterData?.pageSize}
              page={filterData?.pageNumber}
              setPage={handlePagination}
              total={filterData?.totalItems}
            />
          </Box>
        )
      }
    </Box>
  )
}

export default MovementEmployeeList
