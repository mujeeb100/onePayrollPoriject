import { Box, Grid } from '@mui/material'
import { useClientGroupEntitiesCreateMutation, useClientGroupEntitiesUpdateMutation, useLazyGetClientGroupEntitiesByIdQuery } from 'api/clientServices'
import { useGetAllRegionQuery } from 'api/entityServices'
import { useGetAllCountryQuery } from 'api/globalServices'
import OPRInputControl from 'components/molecules/OPRInputControl'
import OPRResponsiveGrid from 'components/molecules/OPRResponsiveGrid'
import OPRSelectorControl from 'components/molecules/OPRSelectorControl/OPRSelectorControl'
import OPRAlertControl from 'components/organism/OPRAlertControl'
import { clientGropEntitiesValidationSchema } from 'constants/validate'
import useForm from 'hooks/useForm'
import { forwardRef, useEffect, useImperativeHandle } from 'react'
import { useLocation } from 'react-router-dom'
import { routes } from 'routes/routes'
import { generateFilterUrl } from 'utils'

interface MessageProps {
    text?: string;
    important?: boolean;
  }

const MovementEmployeeForm = forwardRef(({
  isEditable,
  setEditable,
  id,
}:any, ref) => {
  const {
    values,
    setValues,
    errors,
    handleChange,
    setErrors,
    handleFormSubmit,
    handleOnChange,
  } = useForm(clientGropEntitiesValidationSchema)
  const location: any = useLocation()
  const getParamsNewValue:any = (url: any) => {
    let EntityId:any
    let ProfileId:any
    const viewUrl:any = url?.pathname?.split('/').pop() === 'view'
    const ProfileIdUrl = url?.pathname?.split('/').pop().url?.pathname?.slice(0, url?.pathname?.lastIndexOf('/'))
    if (url?.pathname?.split('/').pop() === 'create') {
      EntityId = null
      ProfileId = url.pathname?.split('/')[3]
    } else {
      const newUrl = url?.pathname?.slice(0, url?.pathname?.lastIndexOf('/'))
      EntityId = newUrl?.split('/').pop()
      ProfileId = url.pathname?.split('/')[3]
    }
    return { EntityId, ProfileId, viewUrl }
  }
  const { EntityId, ProfileId, viewUrl } = getParamsNewValue(location)

  const [createClientGroupEntities, {
    data: createdClientGroupEntitiesData,
    error: createdClientGroupEntitiesError,
    isLoading: createdClientGroupEntitiesLoading,
    isSuccess: createdClientGroupEntitiesSuccess,
    isError: createdClientGroupEntitiesIsError,
  }] = useClientGroupEntitiesCreateMutation()

  const {
    data: allPosts,
    error: createAllPostsBankAccountError,
    isLoading: isLoadingAllPosts,
    isSuccess: isSuccessAllPosts,
    isError: isErrorAllPosts,
    error: errorAllPosts,
  } = useGetAllCountryQuery(generateFilterUrl(''))

  const {
    data: allRegionPosts,
    isLoading: isLoadingAllRegionPosts,
    isSuccess: isSuccessAllRegionPosts,
    isError: isErrorAllRegionPosts,
    error: errorAllRegionPosts,
    refetch: refetchAllPosts,
  } = useGetAllRegionQuery(generateFilterUrl(''))

  const [updateClientGroupEntities, {
    data: uupdatedClientGroupDataResponse,
    error: updatedClientGroupEntitiesError,
    isLoading: updatedClientGroupEntitiesLoading,
    isSuccess: updatedClientGroupEntitiesSuccess,
    isError: updatedClientGroupEntitiesIsError,
  }] = useClientGroupEntitiesUpdateMutation()

  const [updateClientGroupEntitiesById, {
    data: updatedClientGroupEntitiesByIdResponse,
    error: updatedClientGroupEntitiesByIdError,
    isLoading: updatedClientGroupEntitiesByIdLoading,
    isSuccess: updatedClientGroupEntitiesByIdSuccess,
    isError: updatedClientGroupEntitiesByIdIsError,
  }] = useLazyGetClientGroupEntitiesByIdQuery()
  useEffect(() => {
    if (EntityId) {
      updateClientGroupEntitiesById(`${ProfileId}&EntityId=${EntityId}`)
      // setEditable(viewUrl)
    }
  }, [])
  useEffect(() => {
    if (EntityId) {
      setValues(updatedClientGroupEntitiesByIdResponse?.data)
    } else {
      setValues({
        clientGroupCode: '',
        clientGroupName: '',
        entityCode: '',
        entityName: '',
        countryLocalization: '',
        url: '',
        region: '',
      })
      // setEditable(false)
    }
  }, [updatedClientGroupEntitiesByIdResponse?.data])

  const handleSubmit:any = async () => {
    if (isEditable) {
      if (EntityId === null) {
        await createClientGroupEntities({ ...values, countryLocalization: JSON.parse(JSON.stringify(allPosts?.records || []))?.find((o:any) => o?.countryName === values?.countryLocalization).countryCode })
      } else {
        await updateClientGroupEntities({ ...values, countryLocalization: JSON.parse(JSON.stringify(allPosts?.records || []))?.find((o:any) => o?.countryName === values?.countryLocalization).countryCode })
      }
    } else {
      setEditable(true)
    }
  }
  useImperativeHandle(ref, () => ({
    handleOnSubmit(e:any) {
      handleFormSubmit(e, handleSubmit)
    },

  }))

  useEffect(() => {
    if (createdClientGroupEntitiesSuccess) {
      // Reset form values after successful add operation
      setValues({})
      setErrors({})
    }
  }, [createdClientGroupEntitiesSuccess])

  return (
    <Box>
      <OPRAlertControl
        callBack={(type) => {
          // if (type === 'success') {
          //   navigate(-1)
          // }
        }}
        error={createdClientGroupEntitiesError || updatedClientGroupEntitiesError}
        handleEditable={setEditable}
        handleSetValue={setValues}
        handleSubmit={handleSubmit}
        isError={createdClientGroupEntitiesError || updatedClientGroupEntitiesError}
        isLoading={createdClientGroupEntitiesLoading || updatedClientGroupEntitiesLoading || updatedClientGroupEntitiesByIdLoading}
        isSuccess={updatedClientGroupEntitiesSuccess || createdClientGroupEntitiesSuccess}
        name={values?.ClientGroupEntitiesName}
        previousUrl={routes.clientGroupEntities}
        title="Client Group Entitites"
        type={id ? 'Update' : 'New'}
      />
      <OPRResponsiveGrid>
        <Grid item md={2} sm={1} xs={1}>
          <OPRInputControl
            error={errors?.clientGroupCode}
            isEditable={isEditable}
            label="client_group_code"
            name="clientGroupCode"
            value={values?.clientGroupCode?.toUpperCase()}
            onChange={handleChange}
          />
        </Grid>
        <Grid item md={2} sm={1} xs={1}>
          <OPRInputControl
            error={errors?.clientGroupName}
            isEditable={isEditable}
            label="client_group_name"
            name="clientGroupName"
            value={values?.clientGroupName}
            onChange={handleChange}
          />
        </Grid>
        <Grid item md={2} sm={1} xs={1}>
          <OPRInputControl
            error={errors?.entityCode}
            isEditable={isEditable}
            label="entity_code"
            name="entityCode"
            value={values?.entityCode}
            onChange={handleChange}
          />
        </Grid>
        <Grid item md={2} sm={1} xs={1}>
          <OPRInputControl
            error={errors?.entityName}
            isEditable={isEditable}
            label="client_group_entity_name"
            name="entityName"
            value={values?.entityName}
            onChange={handleChange}
          />
        </Grid>
        {
          // JSON.parse(JSON.stringify(allPosts?.records || []))
        }
        <Grid item md={2} sm={1} xs={1}>
          {/* <OPRInputControl
            error={errors?.countryLocalization}
            isEditable={isEditable}
            label="Country Localization"
            name="countryLocalization"
            value={values?.countryLocalization}
            onChange={handleChange}
          /> */}
          <OPRSelectorControl
            isRequired
            error={errors?.countryLocalization}
            isEditable={isEditable}
            keyName="countryName"
            label="country_localization_title"
            multiple={false}
            name="countryLocalization"
            options={JSON.parse(JSON.stringify(allPosts?.records || []))}
            placeholder="Select an option"
            value={JSON.parse(JSON.stringify(allPosts?.records || []))?.find((o:any) => o?.countryName === values?.countryLocalization) || {}}
            valueKey="countryName"
            onChange={(text:any) => {
              handleOnChange('countryLocalization', text?.countryName)
            }}
          />
        </Grid>
        <Grid item md={2} sm={1} xs={1}>
          <OPRInputControl
            error={errors?.url}
            isEditable={isEditable}
            label="client_entity_url"
            name="url"
            value={values?.url}
            onChange={handleChange}
          />
        </Grid>
        <Grid item md={2} sm={1} xs={1}>
          <OPRInputControl
            error={errors?.region}
            isEditable={isEditable}
            label="region"
            name="region"
            value={values?.region}
            onChange={handleChange}
          />
        </Grid>
      </OPRResponsiveGrid>
    </Box>
  )
})

export default MovementEmployeeForm
