import { Box } from '@mui/material'
import {
  useEmployeeBankAccountCreateMutation, useEmployeeBankAccountUpdateMutation, useGetAllEmployeeProfileQuery, useLazyGetEmployeeBankAccountByIdQuery,
} from 'api/employeeServices'
import { CustomTabPanel } from 'components/atoms/tabs'
import OPRFormHeaderLabel from 'components/molecules/OPRFormHeaderLabel/OPRFormHeaderLabel'
import OPRResponsiveGrid from 'components/molecules/OPRResponsiveGrid'
import OPRAlertControl from 'components/organism/OPRAlertControl'
import { employeeBankAccountFPSValidationSchema, employeeBankAccountGeneralValidationSchema, employeeBankAccountValidationSchema } from 'constants/validate'
import { useEditable } from 'hooks/useEdit'
import useForm from 'hooks/useForm'
import React, { forwardRef, useEffect, useImperativeHandle } from 'react'
import { generateFilterUrl } from 'utils'

import { customeHyphenDateFormat } from '../../../../../constants/index'
import FSInformationBank from './FSInformationBank'
import GeneralBankInformation from './GeneralBankInformation'
import HSBCBankInformation from './HSBCBankInformation'

interface MessageProps {
    text?: string;
    important?: boolean;
    isView?: boolean;
  }

const BankAccountEmployeeForm = forwardRef(({
  id, isView, empId, isModal, setSelectedPage,
  selectedTab, setSelectedTab,
}:any, ref) => {
  const { isEditable, setEditable } = useEditable()

  // const [selectedTab, setSelectedTab] = React.useState(0)
  const handleTabChange = (event: React.SyntheticEvent, newValue: number) => {
    setSelectedTab(newValue)
  }
  const {
    data: employeeDataList,
    isLoading: isLoadingEmployeeDataList,
    isSuccess: isSuccessEmployeeDataList,
    isError: isErrorEmployeeDataList,
    error: errorEmployeeDataList,
    refetch: refetchEmployeeDataList,
  } = useGetAllEmployeeProfileQuery(generateFilterUrl({
    EffectiveDate: '10/10/2040',
    pageSize: 1000,
  }))
  function getSurnameByEmployeeCode(employeeCode:any) {
    const employee = employeeDataList?.records?.find((emp:any) => emp.employeeCode === employeeCode)
    return employee.employeeProfile.id ? employee.employeeProfile.id : null
  }

  const validationList = (expression:any) => {
    let validationScheme:any = {}
    switch (expression) {
      case 0:
        validationScheme = employeeBankAccountGeneralValidationSchema
        break
      case 1:
        validationScheme = employeeBankAccountFPSValidationSchema
        break
      default:
        validationScheme = employeeBankAccountValidationSchema
    }
    return validationScheme
  }
  const {
    values,
    setValues,
    errors,
    handleChange,
    setErrors,
    handleFormSubmit,
    handleOnChange,
  } = useForm(validationList(selectedTab))

  const [createEmployeeBankAccount, {
    data: createdEmployeeBankAccountData,
    error: createdEmployeeBankAccountError,
    isLoading: createdEmployeeBankAccountLoading,
    isSuccess: createdEmployeeBankAccountSuccess,
    isError: createdEmployeeBankAccountIsError,
  }] = useEmployeeBankAccountCreateMutation()

  const [updateEmployeeBankAccount, {
    data: uupdatedClientGroupDataResponse,
    error: updatedEmployeeBankAccountError,
    isLoading: updatedEmployeeBankAccountLoading,
    isSuccess: updatedEmployeeBankAccountSuccess,
    isError: updatedEmployeeBankAccountIsError,
  }] = useEmployeeBankAccountUpdateMutation()

  const [updateEmployeeBankAccountById, {
    data: updatedEmployeeBankAccountByIdResponse,
    error: updatedEmployeeBankAccountByIdError,
    isLoading: updatedEmployeeBankAccountByIdLoading,
    isSuccess: updatedEmployeeBankAccountByIdSuccess,
    isError: updatedEmployeeBankAccountByIdIsError,
  }] = useLazyGetEmployeeBankAccountByIdQuery()
  useEffect(() => {
    setSelectedPage(selectedTab)
  }, [selectedTab])
  useEffect(() => {
    if (id && updatedEmployeeBankAccountByIdSuccess) {
      setValues(updatedEmployeeBankAccountByIdResponse?.data)
    } else {
      setValues({})
      // setSelectedTab(0)
      // setEditable(false)
      // setEditable(false)
    }
  }, [updatedEmployeeBankAccountByIdSuccess])
  useEffect(() => {
    if (isModal === false) {
      setSelectedTab(0)
      setEditable(false)
    }
  }, [isModal])
  const handleSubmit:any = async () => {
    if (selectedTab === 0) {
      setSelectedTab(1)
    }
    if (selectedTab === 1) {
      setSelectedTab(2)
    }
    if (selectedTab === 2) {
      setSelectedTab(3)
      // setEditable(true)
    }
    if (selectedTab === 3) {
      // alert('Api')
      if (id) {
        await updateEmployeeBankAccount({ ...values, effectiveDate: customeHyphenDateFormat(values.effectiveDate) })
      } else {
        await createEmployeeBankAccount({
          ...values, defaultBankAccount: 'abc', employeeCodeId: getSurnameByEmployeeCode(empId), effectiveDate: customeHyphenDateFormat(values.effectiveDate),
        })
      }
    }
  }
  useEffect(() => {
    if (selectedTab === 3) {
      setEditable(true)
    } else {
      setEditable(false)
    }
  }, [selectedTab])
  useEffect(() => {
    if (id) {
      updateEmployeeBankAccountById(id)
    }
  }, [])

  useImperativeHandle(ref, () => ({
    handleOnSubmit(e:any) {
      handleFormSubmit(e, handleSubmit)
    },

  }))

  useEffect(() => {
    if (createdEmployeeBankAccountSuccess) {
      setValues({})
      setErrors({})
    }
  }, [createdEmployeeBankAccountSuccess])
  function getSurnameByEmployee(employeeCode:any) {
    const employee = employeeDataList?.records?.find((emp:any) => emp?.employeeCode === employeeCode)
    return employee?.employeeProfile?.id ? employee?.employeeProfile?.givenName : null
  }
  const successfullMessage:any = () => {
    const accountNamberData = id ? uupdatedClientGroupDataResponse?.data?.accountNumber : createdEmployeeBankAccountData?.data?.accountNumber
    const htmString = `<div style={{width: '100%'}}><span style='color: '#3B3839', fontSize: 16, fontFamily: 'Lato', fontWeight: '700', lineHeight: 24, wordWrap: 'break-word''>${getSurnameByEmployee(empId)} - ${accountNamberData} </span><span style='color: '#3B3839', fontSize: 16, fontFamily: 'Lato', fontWeight: '400', lineHeight: 24, wordWrap: 'break-word''>has been ${id ? 'update' : 'added'}.</span></div>`
    const plainString = htmString.replace(/<[^>]+>/g, '')
    return plainString
  }
  return (
    <Box>
      <OPRAlertControl
        callBack={(type) => {
          // if (type === 'success') {
          //   navigate(-1)
          // }
        }}
        customMessage={successfullMessage()}
        error={createdEmployeeBankAccountError || updatedEmployeeBankAccountError}
        handleEditable={setEditable}
        handleSetValue={setValues}
        handleSubmit={handleSubmit}
        isError={createdEmployeeBankAccountError || updatedEmployeeBankAccountError}
        isLoading={createdEmployeeBankAccountLoading || updatedEmployeeBankAccountLoading || updatedEmployeeBankAccountByIdLoading}
        isSuccess={updatedEmployeeBankAccountSuccess || createdEmployeeBankAccountSuccess}
        name={values?.EmployeeBankAccountName}
        // previousUrl={routes.employeeProfile}
        title="Employee Bank Account"
        type={id ? 'Update' : 'New'}
      />

      <OPRResponsiveGrid>
        <CustomTabPanel index={0} value={selectedTab}>
          <OPRFormHeaderLabel title="General bank account information" />
          <br />
          <GeneralBankInformation
            errors={errors}
            handleChange={handleChange}
            handleOnChange={handleOnChange}
            isEditable={isEditable}
            setValues={setValues}
            values={values}
          />
        </CustomTabPanel>
        <CustomTabPanel index={1} value={selectedTab}>
          <OPRFormHeaderLabel title="FPS information" />
          <FSInformationBank
            errors={errors}
            handleChange={handleChange}
            handleOnChange={handleOnChange}
            isEditable={isEditable}
            values={values}
          />
        </CustomTabPanel>
        <CustomTabPanel index={2} value={selectedTab}>
          <OPRFormHeaderLabel title="HSBC IFILE information" />
          <HSBCBankInformation
            errors={errors}
            handleChange={handleChange}
            handleOnChange={handleOnChange}
            isEditable={isEditable}
            values={values}
          />
        </CustomTabPanel>
        <CustomTabPanel index={3} value={selectedTab}>
          <OPRFormHeaderLabel title="Add bank account" />
          <br />
          <OPRFormHeaderLabel isSubTitle={false} title="General bank account information" />
          <GeneralBankInformation
            errors={errors}
            handleChange={handleChange}
            handleOnChange={handleOnChange}
            isEditable={isEditable}
            values={values}
          />
          <br />
          <OPRFormHeaderLabel isSubTitle={false} title="FPS information" />
          <FSInformationBank
            errors={errors}
            handleChange={handleChange}
            handleOnChange={handleOnChange}
            isEditable={isEditable}
            values={values}
          />
          <br />
          <OPRFormHeaderLabel isSubTitle={false} title="HSBC IFILE information" />
          <HSBCBankInformation
            errors={errors}
            handleChange={handleChange}
            handleOnChange={handleOnChange}
            isEditable={isEditable}
            values={values}
          />
        </CustomTabPanel>
      </OPRResponsiveGrid>
    </Box>
  )
})

export default BankAccountEmployeeForm
