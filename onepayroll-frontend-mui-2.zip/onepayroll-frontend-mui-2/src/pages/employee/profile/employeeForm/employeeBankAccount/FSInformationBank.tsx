import { Grid } from '@mui/material'
import OPRInputControl from 'components/molecules/OPRInputControl'
import OPRResponsiveGrid from 'components/molecules/OPRResponsiveGrid'
import OPRSelectorControl from 'components/molecules/OPRSelectorControl/OPRSelectorControl'

const hsbcmrifpsProxyTypeData = [{
  value: 'BBAN (Bank Account Number)',
  name: 'BBAN (Bank Account Number)',
}, {
  value: 'SVID (FPS Identifier)',
  name: 'SVID (FPS Identifier)',
}, {
  value: 'EMAL (Email Address)',
  name: 'EMAL (Email Address)',
},
{
  value: 'MOBN (Mobile Number)',
  name: 'MOBN (Mobile Number)',
},
{
  value: 'HKID (Hong Kong Identity Card Number)',
  name: 'HKID (Hong Kong Identity Card Number)',
}]

function FSInformationBank({
  errors, isEditable, employeeDataList, values, handleOnChange, handleChange, companyBankAccountList,
}:any) {
  return (
    <OPRResponsiveGrid>
      <Grid item md={2} sm={1} xs={1}>
        <OPRSelectorControl
          isRequired
          error={errors?.hsbcmrifpsProxyType}
          isEditable={isEditable}
          keyName="name"
          label="employee_bank_account_hsbcmrifps_proxy_type"
          multiple={false}
          name="name"
          options={hsbcmrifpsProxyTypeData}
          placeholder="Select an option"
          value={hsbcmrifpsProxyTypeData?.find((o:any) => o?.value === values.hsbcmrifpsProxyType)}
          valueKey="value"
          onChange={(text:any) => {
            handleOnChange('hsbcmrifpsProxyType', text?.value)
          }}
        />
      </Grid>
      {/* <Grid item md={2} sm={1} xs={1}>
        <OPRInputControl
          error={errors?.hsbcmrifpsProxyType}
          isEditable={isEditable}
          label="employee_bank_account_hsbcmrifps_proxy_type"
          name="hsbcmrifpsProxyType"
          value={values?.hsbcmrifpsProxyType}
          onChange={handleChange}
        />
      </Grid> */}
      <Grid item md={2} sm={1} xs={1}>
        <OPRInputControl
          error={errors?.hsbcmrifpsProxyID}
          isEditable={isEditable}
          label="employee_bank_account_hsbcmrifps_proxy_id"
          name="hsbcmrifpsProxyID"
          value={values?.hsbcmrifpsProxyID}
          onChange={handleChange}
        />
      </Grid>
    </OPRResponsiveGrid>
  )
}
export default FSInformationBank
