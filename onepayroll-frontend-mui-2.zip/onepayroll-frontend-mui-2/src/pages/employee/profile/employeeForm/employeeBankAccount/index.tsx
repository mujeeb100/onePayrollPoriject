import {
  Box,
} from '@mui/material'
import { useEmployeeBankAccountDeleteMutation, useGetAllEmployeeBankAccountQuery } from 'api/employeeServices'
import { companyBankAccountSlice } from 'api/entityServices'
import { RighCaretBlue, WhiteRightCaret } from 'assets/svg-images/SvgComponents'
import OPRButton from 'components/atoms/button/OPRButton'
import OPRLabel from 'components/atoms/label/OPRLabel'
import CustomLoader from 'components/atoms/loader/OPRLoader'
import { CustomDialog } from 'components/atoms/modal/OPRModal'
import OPRPagination from 'components/atoms/pagination/OPRPagination'
import OPRTable from 'components/atoms/table/OPRTable'
import { employeeBankAccountColumn } from 'components/atoms/table/OPRTableConstant'
import CancelAlert from 'components/molecules/OPRAlertControl/CancelAlert'
import { OPRDeleteControl } from 'components/molecules/OPRAlertControl/OPRDeleteControl'
import OPRErrorAlertControl from 'components/molecules/OPRAlertControl/OPRErrorControl'
import { defaultPageSize } from 'constants/index'
import React, { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import {
  generateFilterUrl,
} from 'utils'

import BankAccountEmployeeForm from './BankAccountEmployeeForm'

function EmployeeBankAccountList({ id, setCount, ProfileId }:any) {
  const [selelctedUser, setSelelctedUser]:any = useState({
    data: {},
    isDelete: false,
    name: '',
  })
  const myRef:any = React.useRef()
  const [isModal, setModal] = useState(false)
  const [isCancel, setCancel] = useState(false)
  const navigate: any = useNavigate()
  const [viewBank, setViewBank]:any = useState(false)
  const [isEditBank, setIsEditBank]:any = useState(false)
  const [selectedId, setSelectedId]:any = useState(null)
  const [selectedPage, setSelectedPage]:any = useState(0)
  const [selectedTab, setSelectedTab] = React.useState(0)

  const [filterData, setFilterData]:any = useState({
    pageNumber: 1,
    pageSize: 20,
    totalItems: 0,
    orderByAsc: true,
    sortBy: '',
    SearchText: '',
  })
  const {
    data: companyBankAccountList,
    isLoading: isLoadingAllcompanyBankAccountList,
    isSuccess: isSuccessAllcompanyBankAccountList,
    isError: isErrorAllcompanyBankAccountList,
    error: errorAllcompanyBankAccountList,
    refetch: refetchAllcompanyBankAccountList,
  } = companyBankAccountSlice.useGetAllCompanyBankAccountQuery(`${generateFilterUrl(defaultPageSize)}`)

  const {
    data: allPosts,
    error: createAllPostsBankAccountError,
    isLoading: isLoadingAllPosts,
    isSuccess: isSuccessAllPosts,
    isError: isErrorAllPosts,
    error: errorAllPosts,
  } = useGetAllEmployeeBankAccountQuery(`${generateFilterUrl(defaultPageSize)}&EmployeeProfileId=${ProfileId}`)

  // console.log(useEmployeeBankAccountChangeStatusMutation, 'useClientGroupEntitesChangeStatusMutationuseClientGroupEntitesChangeStatusMutation')
  useEffect(() => {
    setCount(JSON.parse(JSON.stringify(allPosts || [])).totalItems)
  }, [isSuccessAllPosts])
  const [deleteEmployeeBankAccountById,
    {
      data: deleteEmployeeBankAccountResponse,
      error: deleteEmployeeBankAccountError,
      isLoading: deleteEmployeeBankAccountLoading,
      isSuccess: deleteEmployeeBankAccountSuccess,
      isError: deleteEmployeeBankAccountIsError,
    }] = useEmployeeBankAccountDeleteMutation()

  const sorting = (
    event: React.MouseEvent<unknown>,
    property: keyof any,
  ) => {
    const isAsc = filterData.sortBy === property && filterData.orderByAsc === true
    setFilterData({ ...filterData, orderByAsc: !isAsc, sortBy: property })
    // setOrder(isAsc ? 'desc' : 'asc')
    // setOrderBy(property)
  }

  useEffect(() => {
    setFilterData({ ...filterData, totalItems: allPosts?.totalItems ? allPosts?.totalItems : 0 })
  }, [allPosts?.pageNumber, filterData.sortBy, filterData.orderByAsc, allPosts?.totalItems])

  const onSearch = (e: any, data: any) => {
    setFilterData({ ...filterData, ...data })
  }
  const handlePagination = (pageNumber: number, pageSize: number) => {
    setFilterData({ ...filterData, pageNumber })
  }
  useEffect(() => {
    if (isModal === false) {
      setSelectedId(null)
      setIsEditBank(false)
    }
  }, [isModal])
  const viewAcoount = (data: any, type:string) => {
    if (type === 'Edit Employee Bank') {
      setModal(!isModal)
      setSelectedId(data.id)
      // navigate(
      //   setRouteValues(`${routes.editEmployeeBankAccount}`, {
      //     id: data.clientGroupProfileId,
      //     profilId: data.id,
      //   }),
      // )
    } else if (type === 'delete') {
      setSelelctedUser({ data, isDelete: true, name: data.clientGroupName })
    } else {
      // navigate(
      //   setRouteValues(`${routes.viewEmployeeBankAccount}`, {
      //     id: data.clientGroupProfileId,
      //     profilId: data.id,
      //     view: false,
      //   }),
      // )
    }
    // const id = JSON.stringify(data)
  }

  const handleView = (data: any) => {
    setIsEditBank(!isEditBank)
    setSelectedTab(3)
    setSelectedId(data.id)
    setModal(!isModal)

    // navigate(
    //   setRouteValues(`${routes.editEmployeeBankAccount}`, {
    //     id: data.clientGroupProfileId,
    //     profilId: data.id,
    //   }),
    // )
  }

  const deleteEntities = (data:any) => {
    deleteEmployeeBankAccountById(`Id=${data.id}`)
  }

  return (
    <Box sx={{ display: 'flex', flexDirection: 'column' }}>
      <Box sx={{ display: 'flex', justifyContent: 'flex-end', alignItems: 'center' }}>
        <OPRButton
          startIcon
          handleClick={() => {
            setViewBank(true)
            setModal(!isModal)
            // setModal(!isModal)
          }}
          variant="text"
        >
          {' '}
          Add Bank Account
        </OPRButton>
      </Box>
      <CustomDialog
        CustomStyles={{ borderRadius: '16px' }}
        isOpen={isLoadingAllPosts}
        type="loader"
      >
        <CustomLoader text="Processing request" />
      </CustomDialog>
      {/* open modal */}

      <CustomDialog
        CustomStyles={{ borderRadius: '16px' }}
        isOpen={isModal}
        type="loader"
      >
        <BankAccountEmployeeForm ref={myRef} empId={id} id={selectedId} isEditBank={isEditBank} isModal={isModal} selectedTab={selectedTab} setSelectedPage={setSelectedPage} setSelectedTab={setSelectedTab} />
        <Box sx={{
          display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: 5,
        }}
        >
          <OPRButton color="info" variant="text" onClick={() => setCancel(true)}>
            Cancel
          </OPRButton>
          {!isEditBank && (
            <Box>
              {selectedTab === 0 ? <div /> : (
                <OPRButton
                  style={{ marginLeft: 'auto' }}
                  variant="text"
                  onClick={() => {
                    setSelectedTab(selectedTab - 1)
                  }}
                >
                  <RighCaretBlue />
                  Back
                </OPRButton>
              )}
              <OPRButton
                color="primary"
                variant="contained"
                onClick={(e:any) => {
                  myRef?.current?.handleOnSubmit(e)
                }}
              >
                {
                  selectedTab === 3 ? 'Confirm ' : 'Continue'
                }
                {' '}
                <Box>
                  <WhiteRightCaret />
                </Box>
              </OPRButton>
            </Box>
          )}
        </Box>
      </CustomDialog>
      <OPRDeleteControl
        deleteCallBack={deleteEntities}
        selelctedUser={selelctedUser}
        setSelelctedUser={setSelelctedUser}
        title="Client Group Entities"
      />
      <OPRErrorAlertControl
        error={deleteEmployeeBankAccountError}
        header="Failed to Delete"
        isBackButton={false}
        isError={deleteEmployeeBankAccountIsError}
        isTry={false}
        name="Client Group Entities"
      />
      <CancelAlert
        callBack={() => {
          setCancel(false)
          setModal(false)
        }}
        handleCancel={() => {
          setCancel(false)
        }}
        isCancel={isCancel}
      />
      <OPRLabel CustomStyles={{ marginBottom: 5 }} variant="body2">
        {JSON.parse(JSON.stringify(allPosts?.records || [])).length}
        {' '}
        items
      </OPRLabel>
      <OPRTable
        cols={employeeBankAccountColumn(viewAcoount, companyBankAccountList?.records)}
        data={JSON.parse(JSON.stringify(allPosts?.records || []))}
        handleEdit={viewAcoount}
        isLoader={isLoadingAllPosts}
        newOptions={[]}
        orderBy={filterData?.orderByAsc}
        rowClickHandler={handleView}
        rowNumber={0}
        sortBy={filterData?.sortBy}
        title="title"
        onRequestSort={sorting}
      />
      {
        filterData?.totalItems < 20 ? null : (
          <Box sx={{ display: 'flex', justifyContent: 'center', mt: 2 }}>
            <OPRPagination
              limit={filterData?.pageSize}
              page={filterData?.pageNumber}
              setPage={handlePagination}
              total={filterData?.totalItems}
            />
          </Box>
        )
      }
    </Box>
  )
}

export default EmployeeBankAccountList
