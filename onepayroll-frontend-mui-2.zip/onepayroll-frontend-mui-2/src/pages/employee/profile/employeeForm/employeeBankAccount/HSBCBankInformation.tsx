import { Grid } from '@mui/material'
import { useGetAllCountryQuery } from 'api/globalServices'
import OPRInputControl from 'components/molecules/OPRInputControl'
import OPRResponsiveGrid from 'components/molecules/OPRResponsiveGrid'
import OPRSelectorControl from 'components/molecules/OPRSelectorControl/OPRSelectorControl'

import { defaultPageSize } from '../../../../../constants'

const dataHSBCIFILE = [
  { value: 'SWF (Swift Account Code)', name: 'SWF (Swift Account Code)' },
  { value: 'BCD (Bank Code)', name: 'BCD (Bank Code)' },
]
const dataHSBCIFILECharge = [
  { value: 'SHA (Shared charges)', name: 'SHA (Shared charges)' },
  { value: 'BEN (Charged to beneficiary)', name: 'BEN (Charged to beneficiary)' },
  { value: 'OUR (Charged to ordering party)', name: 'OUR (Charged to ordering party)' },
]
function HSBCBankInformation({
  errors, isEditable, values, handleChange, handleOnChange,
}:any) {
  const {
    data: allPosts,
    error: createAllPostsBankAccountError,
    isLoading: isLoadingAllPosts,
    isSuccess: isSuccessAllPosts,
    isError: isErrorAllPosts,
    error: errorAllPosts,
  } = useGetAllCountryQuery(defaultPageSize)

  // JSON.parse(JSON.stringify(allPosts?.records || []))
  return (
    <OPRResponsiveGrid>
      <Grid item md={2} sm={1} xs={1}>
        <OPRSelectorControl
          isRequired
          disabled={values?.bankFileFormat !== 'HSBC IFILE - Priority Payment'}
          error={errors?.hsbcSwiftBcdCode}
          isEditable={isEditable}
          keyName="name"
          label="HSBC IFILE = SWF/BCD"
          multiple={false}
          name="name"
          optionalText="Optional"
          options={dataHSBCIFILE}
          placeholder="Select an option"
          value={dataHSBCIFILE?.find((o:any) => o?.value === values.hsbcSwiftBcdCode)}
          valueKey="value"
          onChange={(text:any) => {
            handleOnChange('hsbcSwiftBcdCode', text?.value)
          }}
        />
      </Grid>
      {/* <Grid item md={2} sm={1} xs={1}>
        <OPRInputControl
          error={errors?.hsbcSwiftBcdCode}
          isEditable={isEditable}
          label="HSBC IFILE = SWF/BCD"
          name="hsbcSwiftBcdCode"
          optionalText="Optional"
          value={values?.hsbcSwiftBcdCode}
          onChange={handleChange}
        />
      </Grid> */}
      <Grid item md={2} sm={1} xs={1}>
        <OPRInputControl
          disabled={values?.bankFileFormat !== 'HSBC IFILE - Priority Payment'}
          error={errors?.hsbcSwiftCode}
          isEditable={isEditable}
          label="HSBC IFILE - Swift code/Sort code"
          name="hsbcSwiftCode"
          value={values?.hsbcSwiftCode}
          onChange={handleChange}
        />
      </Grid>
      <Grid item md={2} sm={1} xs={1}>
        <OPRSelectorControl
          isRequired
          disabled={values?.bankFileFormat !== 'HSBC IFILE - Priority Payment'}
          error={errors?.hsbcCountryCode}
          isEditable={isEditable}
          keyName="countryCode"
          label="HSBC IFILE - Country"
          multiple={false}
          name="countryCode"
          optionalText="Optional"
          options={JSON.parse(JSON.stringify(allPosts?.records || []))}
          placeholder="Select an option"
          value={JSON.parse(JSON.stringify(allPosts?.records || []))?.find((o:any) => o?.countryCode === values.hsbcCountryCode)}
          valueKey="countryCode"
          onChange={(text:any) => {
            handleOnChange('hsbcCountryCode', text?.countryCode)
          }}
        />
      </Grid>
      {/* <Grid item md={2} sm={1} xs={1}>
        <OPRInputControl
          error={errors?.hsbcCountryCode}
          isEditable={isEditable}
          label="HSBC IFILE - Country"
          name="hsbcCountryCode"
          value={values?.hsbcCountryCode}
          onChange={handleChange}
        />
      </Grid> */}
      <Grid item md={2} sm={1} xs={1}>
        <OPRSelectorControl
          isRequired
          disabled={values?.bankFileFormat !== 'HSBC IFILE - Priority Payment'}
          error={errors?.hsbcBankCharge}
          isEditable={isEditable}
          keyName="name"
          label="HSBC IFILE - Details of charges"
          multiple={false}
          name="name"
          optionalText="Optional"
          options={dataHSBCIFILECharge}
          placeholder="Select an option"
          value={dataHSBCIFILECharge?.find((o:any) => o?.value === values.hsbcBankCharge)}
          valueKey="value"
          onChange={(text:any) => {
            handleOnChange('hsbcBankCharge', text?.value)
          }}
        />
      </Grid>
      {/* <Grid item md={2} sm={1} xs={1}>
        <OPRInputControl
          error={errors?.hsbcBankCharge}
          isEditable={isEditable}
          label="HSBC IFILE - Details of charges"
          name="hsbcBankCharge"
          value={values?.hsbcBankCharge}
          onChange={handleChange}
        />
      </Grid> */}
    </OPRResponsiveGrid>
  )
}
export default HSBCBankInformation
