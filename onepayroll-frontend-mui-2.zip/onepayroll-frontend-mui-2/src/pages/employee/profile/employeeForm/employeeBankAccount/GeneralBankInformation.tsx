import { Checkbox, Grid } from '@mui/material'
import { useGetAllEmployeeProfileQuery } from 'api/employeeServices'
import { companyBankAccountSlice } from 'api/entityServices'
import OPRDatePickerControl from 'components/molecules/OPRDatePickerControl/OPRDatePickerControl'
import OPRInputControl from 'components/molecules/OPRInputControl'
import OPRResponsiveGrid from 'components/molecules/OPRResponsiveGrid'
import OPRSelectorControl from 'components/molecules/OPRSelectorControl/OPRSelectorControl'
import { generateFilterUrl } from 'utils'

import { defaultPageSize } from '../../../../../constants'

const bankFileFormatData = [{ bankFileFormat: 'HSBC MRI', value: 'HSBC MRI' },
  { bankFileFormat: 'HSBC IFILE - Priority Payment', value: 'HSBC IFILE - Priority Payment' },
  { bankFileFormat: 'SCB - PAY', value: 'SCB - PAY' },
  { bankFileFormat: 'SCB - BT', value: 'SCB - BT' },
  { bankFileFormat: 'SCB - RTGS', value: 'SCB - RTGS' },
  { bankFileFormat: 'SCB - DISK', value: 'SCB - DISK' },
]
function GeneralBankInformation({
  errors, isEditable, values, handleOnChange, handleChange, setValues,
}:any) {
  const {
    data: employeeDataList,
    isLoading: isLoadingEmployeeDataList,
    isSuccess: isSuccessEmployeeDataList,
    isError: isErrorEmployeeDataList,
    error: errorEmployeeDataList,
    refetch: refetchEmployeeDataList,
  } = useGetAllEmployeeProfileQuery(generateFilterUrl({
    EffectiveDate: '10/10/2040',
    ...defaultPageSize,
  }))

  const {
    data: companyBankAccountList,
    isLoading: isLoadingAllcompanyBankAccountList,
    isSuccess: isSuccessAllcompanyBankAccountList,
    isError: isErrorAllcompanyBankAccountList,
    error: errorAllcompanyBankAccountList,
    refetch: refetchAllcompanyBankAccountList,
  } = companyBankAccountSlice.useGetAllCompanyBankAccountQuery(generateFilterUrl(defaultPageSize))

  return (
    <OPRResponsiveGrid>
      {/* <Grid item md={2} sm={1} xs={1}>
        <OPRSelectorControl
          isRequired
          error={errors?.employeeCode}
          isEditable={isEditable}
          keyName="employeeCode"
          label="employee_bank_account_employee_profile_id"
          multiple={false}
          name="employeeCode"
          options={JSON.parse(JSON.stringify(employeeDataList?.records || []))}
          placeholder="Select an option"
          value={JSON.parse(JSON.stringify(employeeDataList?.records || []))?.find((o:any) => o?.id === values?.employeeCodeId) || {}}
          valueKey="id"
          onChange={(text:any) => {
            handleOnChange('employeeCodeId', text?.id)
          }}
        />
      </Grid> */}

      <Grid item md={2} sm={1} xs={1}>
        <OPRInputControl
          error={errors?.accountNumber}
          isEditable={isEditable}
          label="employee_bank_account_account_number"
          name="accountNumber"
          value={values?.accountNumber}
          onChange={handleChange}
        />
      </Grid>
      <Grid item md={2} sm={1} xs={1}>
        <OPRInputControl
          error={errors?.accountName}
          isEditable={isEditable}
          label="Beneficiary name"
          name="accountName"
          value={values?.accountName}
          onChange={handleChange}
        />
      </Grid>
      <Grid item md={2} sm={1} xs={1}>
        <OPRInputControl
          error={errors?.bankCode}
          isEditable={isEditable}
          label="employee_bank_account_bank_code"
          name="bankCode"
          optionalText="Optional"
          value={values?.bankCode}
          onChange={handleChange}
        />
      </Grid>
      <Grid item md={2} sm={1} xs={1}>
        <OPRInputControl
          error={errors?.branchCode}
          isEditable={isEditable}
          label="employee_bank_account_branch_code"
          name="branchCode"
          optionalText="Optional"
          value={values?.branchCode}
          onChange={handleChange}
        />
      </Grid>
      <div
        className="CheckboxWText"
        style={{
          width: '100%', height: '100%', justifyContent: 'flex-start', alignItems: 'flex-start', gap: 8, display: 'inline-flex', padding: '24px',
        }}
      >
        <div
          className="AtomCheckbox"
          style={{
            paddingTop: 1, paddingBottom: 1, justifyContent: 'flex-start', alignItems: 'center', display: 'flex',
          }}
        >
          <div
            className="Checkbox"
            style={{
              padding: 2, background: 'white', borderRadius: 4, overflow: 'hidden', justifyContent: 'flex-start', alignItems: 'flex-start', gap: 10, display: 'flex',
            }}
          >
            <Checkbox
              checked={values.defaultBankAccount}
              style={{ width: 16, height: 16, position: 'relative' }}
              onChange={(e) => {
                // console.log('values.defaultBankAccount', e.target.checked)
                handleOnChange('defaultBankAccount', e.target.checked)
              }}
            />
          </div>
        </div>
        <div
          className="AtomLabels"
          style={{
            flex: '1 1 0', height: 22, justifyContent: 'flex-start', alignItems: 'flex-start', gap: 8, display: 'flex',
          }}
        >
          <div
            className="Label"
            style={{
              flex: '1 1 0', color: '#3B3839', fontSize: 14, fontFamily: 'Lato', fontWeight: '400', wordWrap: 'break-word',
            }}
          >
            Set as default bank account
          </div>
        </div>
      </div>
      <Grid item md={2} sm={1} xs={1}>
        <OPRSelectorControl
          isRequired
          error={errors?.companyBankAccountCodeId}
          isEditable={isEditable}
          keyName="name"
          label="Company bank account"
          multiple={false}
          name="name"
          options={JSON.parse(JSON.stringify(companyBankAccountList?.records || []))?.map((item:any, index:any) => ({
            name: `${item.companyBankAccountCode}-${item.companyBankAccountDescription}`,
            ...item,
          })) || []}
          placeholder="Select an option"
          value={JSON.parse(JSON.stringify(companyBankAccountList?.records || []))?.map((item:any, index:any) => ({
            name: `${item.companyBankAccountCode}-${item.companyBankAccountDescription}`,
            ...item,
          }))?.find((o:any) => o?.id === values?.companyBankAccountCodeId) || {}}
          valueKey="name"
          onChange={(text:any) => {
            setValues({ ...values, companyBankAccountCodeId: text?.id })
            // handleOnChange('bankFileFormat', text?.bankFileFormat)
            // handleOnChange('companyBankAccountCodeId', text?.id)
          }}
        />
      </Grid>
      {/* <Grid item md={2} sm={1} xs={1}>
        <OPRSelectorControl
          isRequired
          error={errors?.bankFileFormat}
          isEditable={isEditable}
          keyName="bankFileFormat"
          label="Company bank account"
          multiple={false}
          name="bankFileFormat"
          options={bankFileFormatData}
          placeholder="Select an option"
          value={bankFileFormatData?.find((o:any) => o?.value === values.bankFileFormat)}
          valueKey="value"
          onChange={(text:any) => {
            // handleOnChange('bankFileFormat', text?.value)
          }}
        />
      </Grid> */}
      {/* <Grid item md={2} sm={1} xs={1}>
        <OPRInputControl
          error={errors?.accountName}
          isEditable={isEditable}
          label="employee_bank_account_account_name"
          name="accountName"
          value={values?.accountName}
          onChange={handleChange}
        />
      </Grid> */}
      <Grid item md={2} sm={1} xs={1}>
        <OPRDatePickerControl
          isRequired
          error={errors?.effectiveDate}
          isEditable={isEditable}
          label="employee_bank_account_effective_date"
          name="effectiveStartDate"
          value={values?.effectiveDate || null}
          onChange={(date:any) => {
            handleOnChange('effectiveDate', new Date(date))
          }}
        />
      </Grid>
      <Grid item md={2} sm={1} xs={1}>
        <OPRInputControl
          error={errors?.swiftCode}
          isEditable={isEditable}
          label="employee_bank_account_swift_code"
          name="swiftCode"
          optionalText="Optional"
          value={values?.swiftCode}
          onChange={handleChange}
        />
      </Grid>
      <Grid item md={2} sm={1} xs={1}>
        <OPRInputControl
          error={errors?.paymentReference}
          isEditable={isEditable}
          label="employee_bank_account_payment_reference"
          name="paymentReference"
          value={values?.paymentReference}
          onChange={handleChange}
        />
      </Grid>
    </OPRResponsiveGrid>
  )
}
export default GeneralBankInformation
