import { Box } from '@mui/material'
import OPRButton from 'components/atoms/button/OPRButton'
import { CustomDialog } from 'components/atoms/modal/OPRModal'

function EmployeeModal({ isModal, setModal, children }: any, myRef:any) {
  return (
    <CustomDialog
      CustomStyles={{ borderRadius: '16px' }}
      isOpen={isModal}
      type="loader"
    >
      {children}
      <Box sx={{
        display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: 5,
      }}
      >
        <OPRButton color="info" variant="text" onClick={() => setModal(false)}>
          Cancel
        </OPRButton>
        <OPRButton
          color="info"
          type="submit"
          variant="text"
          onClick={(e:any) => {
            // myRef?.current?.handleOnSubmit(e)
          }}
        >
          Confirm
        </OPRButton>
      </Box>
    </CustomDialog>
  )
}

export default EmployeeModal
