import {
  Box,
} from '@mui/material'
import { useEmployeeProfileDeleteMutation, useGetAllEmployeeProfileQuery } from 'api/employeeServices'
import { employeeProfileColumn } from 'components/atoms/table/OPRTableConstant'
import { OPRInnerListLayout } from 'components/organism/OPRInnerLayoutList'
// import { useEmployeeProfileDeleteMutation, useGetAllEmployeeProfileQuery } from 'api/globalServices'
import React, { useEffect, useState } from 'react'
// import { EmployeeProfileColumn } from 'components/atoms/table/OPRTableConstant'
import { useNavigate } from 'react-router-dom'
import { routes } from 'routes/routes'
import {
  generateFilterUrl, setRouteValues,
} from 'utils'

function EmployeeProfileList() {
  const navigate: any = useNavigate()
  const [selelctedUser, setSelelctedUser]:any = useState({
    data: {},
    isDelete: false,
    name: '',
  })
  const [filterData, setFilterData]:any = useState({
    Status: 2,
    pageNumber: 1,
    pageSize: 20,
    totalItems: 0,
    orderByAsc: true,
    sortBy: '',
    SearchText: '',
    EffectiveDate: '10/10/2040',
  })
  const {
    data: allPosts,
    error: createAllPostsBankAccountError,
    isLoading: isLoadingAllPosts,
    isSuccess: isSuccessAllPosts,
    isError: isErrorAllPosts,
    error: errorAllPosts,
  } = useGetAllEmployeeProfileQuery(generateFilterUrl(filterData))
  const [deleteEmployeeProfileById,
    {
      data: deleteEmployeeProfileResponse,
      error: deleteEmployeeProfileError,
      isLoading: deleteEmployeeProfileLoading,
      isSuccess: deleteEmployeeProfileSuccess,
      isError: deleteEmployeeProfileIsError,
    }] = useEmployeeProfileDeleteMutation()

  const sorting = (
    event: React.MouseEvent<unknown>,
    property: keyof any,
  ) => {
    const isAsc = filterData.sortBy === property && filterData.orderByAsc === true
    setFilterData({ ...filterData, orderByAsc: !isAsc, sortBy: property })
    // setOrder(isAsc ? 'desc' : 'asc')
    // setOrderBy(property)
  }

  useEffect(() => {
    setFilterData({ ...filterData, totalItems: allPosts?.totalItems ? allPosts?.totalItems : 0 })
  }, [allPosts?.pageNumber, filterData.sortBy, filterData.orderByAsc, allPosts?.totalItems])

  const onSearch = (e: any, data: any) => {
    setFilterData({ ...filterData, ...data })
  }
  const handlePagination = (pageNumber: number, pageSize: number) => {
    setFilterData({ ...filterData, pageNumber })
  }
  const viewAcoount = (data: any, type:string) => {
    if (type === 'edit') {
      navigate(
        setRouteValues(`${routes.editEmployeeProfile}`, {
          id: data.id,
        }),
      )
    } else if (type === 'delete Employee Profile') {
      // deleteEmployeeProfileById(`Id=${data.id}`)
      setSelelctedUser({ data, isDelete: true, name: `${data?.employeeCode} - ${data?.employeeProfile?.givenName}` })
    } else {
      console.log('else')
    }
    // const id = JSON.stringify(data)
  }
  const handleView = (data: any) => {
    navigate(
      setRouteValues(`${routes.viewEmployeeProfile}`, {
        id: data.id,
        view: true,
      }),
    )
  }
  const handleDelete = (data:any) => {
    deleteEmployeeProfileById(`Id=${data.id}`)
  }

  return (
    <Box sx={{ display: 'flex' }}>
      <OPRInnerListLayout
        Search={filterData.SearchText}
        addHandleClick={() => navigate(routes.createEmployeeProfile)}
        columns={employeeProfileColumn(viewAcoount)}
        dataList={JSON.parse(JSON.stringify(allPosts?.records || []))}
        deleteCallBack={handleDelete}
        error={errorAllPosts || deleteEmployeeProfileError}
        filterData={filterData}
        handlePagination={handlePagination}
        handleSearch={onSearch}
        isAdd={false}
        isError={isErrorAllPosts || deleteEmployeeProfileIsError}
        loading={isLoadingAllPosts || deleteEmployeeProfileLoading}
        rowClickHandler={handleView}
        rowNumber={0}
        selelctedUser={selelctedUser}
        setSelelctedUser={setSelelctedUser}
        sortHandleClick={sorting}
        success={deleteEmployeeProfileSuccess}
        title="Employees"
      />
    </Box>
  )
}

export default EmployeeProfileList
