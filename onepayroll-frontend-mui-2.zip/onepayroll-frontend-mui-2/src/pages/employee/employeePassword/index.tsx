import {
  Box,
} from '@mui/material'
import {
  useEmployeePasswordDeleteMutation, useGeneratePasswordCreateMutation, useGetAllEmployeePasswordExportQuery, useGetAllEmployeePasswordQuery,
} from 'api/employeeServices'
import { ReactComponent as SuccessIcon } from 'assets/svg-icons/Tick.svg'
import OPRButton from 'components/atoms/button/OPRButton'
import OPRCheckbox from 'components/atoms/checkbox/OPRCheckbox'
import OPRLabel from 'components/atoms/label/OPRLabel'
import { CustomDialog } from 'components/atoms/modal/OPRModal'
import MultipleSelectCheckmarks from 'components/atoms/multiSelectCheckbox'
import { entityEmployeePassword } from 'components/atoms/table/OPRTableConstant'
import OPRAlertControl from 'components/organism/OPRAlertControl'
import { OPRInnerListLayout } from 'components/organism/OPRInnerLayoutList'
// import { useEmployeePasswordDeleteMutation, useGetAllEmployeePasswordQuery } from 'api/entityServices'
// import { EmployeePasswordColumnMappings } from 'constants/exportColumnMappings'
// import { useTranslatedColumnsForPDF } from 'hooks/useTranslatedColumnsForPDF'
import apiEndPoint from 'constants/apiEndPoint'
import { employeePasswordColumnMappingsView } from 'constants/exportColumnMappings'
import { validationSchemaPasswordEmpgeneration } from 'constants/validate'
import useForm from 'hooks/useForm'
import { useTranslatedColumnsForPDF } from 'hooks/useTranslatedColumnsForPDF'
import { t } from 'i18next'
import React, { useEffect, useState } from 'react'
// import { entityEmployeePasswordColumn, nationalityColumn } from 'components/atoms/table/OPRTableConstant'
import { useNavigate } from 'react-router-dom'
import { routes } from 'routes/routes'
import {
  generateFilterUrl, getAPIWithEntityUrl, getEnv,
} from 'utils'

import { FinalModal, PasswordEmpModal } from './PassWordModal'

function EmployeePasswordList() {
  const [payGroup, setPayGroup] = React.useState('')
  const [isOpen, setIsOpen] = useState(false)
  const navigate: any = useNavigate()
  // Checkbox state
  // const [selectedCodes, setSelectedCodes] = useState<{ employeeCode: string; givenName: string }[]>([])
  const [selectedCodes, setSelectedCodes]:any = useState([])
  // const [selectAllChecked, setSelectAllChecked] = useState(false)
  const [isOpenSecondModal, setIsOpenSecondModal] = useState(false)
  const [isSuccess, setIsSuccess]:any = useState(false)
  const [isDropDateModal, setIsDropDateModal] = useState(false)
  const [isFinalOpenModal, setIsFinalOpenModal] = useState(false)
  const [selectAllPassword, setSelectAllPassword] = useState(false)
  // employe modal list
  const {
    values,
    setValues,
    errors,
    handleChange,
    setErrors,
    handleFormSubmit,
    handleOnChange,
  } = useForm(validationSchemaPasswordEmpgeneration)
  const [selectedEmployeeData, setSelectedEmployeeData] = useState<{ employeeCode: string; givenName: string }[]>([])
  const [selectedOptions, setSelectedOptions]:any = useState<any>({ passwordIndicator: [] })
  const [listOfOptions, setListOfOptions]:any = useState<any>({ passwordIndicator: [{ roleCode: 'Yes', roleName: 'Yes' }, { roleCode: 'No', roleName: 'No' }] })

  const [selectedDate, setSelectedDate] = useState<Date | null>(null) // State to hold the selected date

  const [selelctedDelete, setSelelctedDelete]:any = useState({
    data: {},
    isDelete: false,
    name: '',
  })

  const [filterData, setFilterData]:any = useState({
    pageNumber: 1,
    pageSize: 20,
    totalItems: 0,
    orderByAsc: true,
    sortBy: '',
    SearchText: '',
    PasswordIndicator: '',
  })
  const [filterExportAll, setFilterExportAll]:any = useState({
    pageNumber: 1,
    pageSize: 20,
    totalItems: 0,
    orderByAsc: true,
    sortBy: '',
  })
  const {
    data: allPosts,
    isLoading: isLoadingAllPosts,
    isSuccess: isSuccessAllPosts,
    isError: isErrorAllPosts,
    error: errorAllPosts,
    refetch: refetchAllPosts,
  } = useGetAllEmployeePasswordQuery(generateFilterUrl(filterData))

  // for export

  const {
    data: allPostExports,
    isLoading: isLoadingAllPostsExports,
    isSuccess: isSuccessAllPostsExports,
    isError: isErrorAllPostsExports,
    error: errorAllPostsExports,
  } = useGetAllEmployeePasswordExportQuery(
    generateFilterUrl(filterExportAll),
  )

  // Determine if a single record is being exported
  const isSingleRecordExport = filterData.SearchText && allPostExports?.records.length === 1

  const [
    generatePassword,
    {
      data: generatePasswordData,
      error: generatePasswordError,
      isLoading: generatePasswordLoading,
      isSuccess: generatePasswordIsSuccess,
      isError: generatePasswordIsError,
    },
  ] = useGeneratePasswordCreateMutation()

  const [deleteEmployeePasswordById,
    {
      data: deleteEmployeePasswordResponse,
      error: deleteEmployeePasswordError,
      isLoading: deleteEmployeePasswordLoading,
      isSuccess: deleteEmployeePasswordSuccess,
      isError: deleteEmployeePasswordIsError,
    }] = useEmployeePasswordDeleteMutation()

  useEffect(() => {
    const hardcodedPasswordOptions = [
      { roleCode: 'Yes', roleName: 'Yes' },
      { roleCode: 'No', roleName: 'No' },
    ]
    setListOfOptions((prev:any) => ({
      ...prev,
      passwordIndicator: hardcodedPasswordOptions,
    }))
  }, [])

  useEffect(() => {
    const updateFilterData = () => {
      if (selectedOptions.passwordIndicator.length > 0) {
        const filterStatus = selectedOptions.passwordIndicator.map((item: any) => item.roleCode).join(',')
        setFilterData({ ...filterData, PasswordIndicator: filterStatus })
      } else {
        setFilterData({ ...filterData, PasswordIndicator: '' }) // Clear the status filter if no options selected
      }
    }

    updateFilterData()
  }, [selectedOptions?.passwordIndicator])

  const sorting = (
    event: React.MouseEvent<unknown>,
    property: keyof any,
  ) => {
    const isAsc = filterData.sortBy === property && filterData.orderByAsc === true
    setFilterData({ ...filterData, orderByAsc: !isAsc, sortBy: property })
  }

  useEffect(() => {
    setFilterData({ ...filterData, totalItems: allPosts?.totalItems ? allPosts?.totalItems : 0 })
  }, [allPosts?.pageNumber, filterData.sortBy, filterData.orderByAsc, allPosts?.totalItems])

  useEffect(() => {
    setFilterExportAll({ ...filterExportAll, totalItems: allPostExports?.totalItems ? allPostExports?.totalItems : 0 })
  }, [allPostExports?.pageNumber, filterExportAll.sortBy, filterExportAll.orderByAsc, allPostExports?.totalItems])

  const onSearch = (e: any) => {
    setFilterData({ ...filterData, SearchText: e.target.value })
  }
  // const handlePagination = (pageNumber: number, pageSize: number) => {
  //   setFilterData({
  //     ...filterData, ...filterExportAll, pageNumber, pageSize,
  //   })
  // }

  const handlePagination = (pageNumber: number, pageSize: number) => {
    setFilterData((prev:any) => ({
      ...prev,
      pageNumber,
      // pageSize,
    }))
    // Refetch data with updated pagination
    refetchAllPosts()
  }

  useEffect(() => {
    setFilterExportAll((prev:any) => ({
      ...prev,
      pageNumber: filterData.pageNumber,
      pageSize: filterData.pageSize,
    }))
  }, [filterData.pageNumber, filterData.pageSize])

  // Function to handle "Generate Password" button click
  const handleGeneratePassword = () => {
    setIsDropDateModal(true)
    const selectedEmployeeData = allPosts?.records?.filter((item: any) => selectedCodes.includes(item.employeeCode)).map((item: any) => ({ employeeCode: item.employeeCode, givenName: item.givenName }))
    setSelectedEmployeeData(selectedEmployeeData)
    // setIsOpen(true)
  }

  // viewAcoount  spelling mistake
  const viewAcoount = (data: any, type: string) => {
    if (type === 'Generate Password') {
      setIsDropDateModal(true)
      // Wrap single object into an array if needed
      setSelectedEmployeeData(Array.isArray(data) ? data : [data])
    }
  }
  const handleList = () => {
    setIsSuccess(false)
  }
  const handleView = (data: any) => {
    setSelectedCodes(data)
  }
  const handleCancel = () => {
    setIsDropDateModal(true)
    setIsFinalOpenModal(false)
  }
  const handleOpenDate = () => {
    setIsFinalOpenModal(true)
  }
  // handle Delete
  const handleDelete = (data:any) => {
    deleteEmployeePasswordById(`Id=${data.id}`)
  }
  useEffect(() => {
    if (generatePasswordIsSuccess === true) {
      setIsSuccess(true)
    }
  }, [generatePasswordIsSuccess])

  const handleSubmit = async () => {
    setIsDropDateModal(false)
    setIsFinalOpenModal(false)

    // Extract employee codes from selectedEmployeeData
    const employeeCodes = selectedEmployeeData.map((employee:any) => employee?.employeeCode)

    const payload = {
      employeeCodes,
      expiryDate: values?.expiryDate || '', // Add default value if expiryDate is undefined
    }

    await generatePassword(payload)
  }
  const handleConfirm = async () => {
    setIsOpenSecondModal(false)
  }

  const renderValue = (selected: string[], filterName: string) => {
    if (selected.length === 0) {
      return <span>{t(`${filterName}`)}</span>
    }

    return (
      <span style={{ }}>
        <span style={{ color: '' }}>
          {t(`${filterName}`)}
          {' '}
        </span>
        {/* <span
          style={{
            backgroundColor: 'white',
            color: '#00308F',
            // width: 'auto',
            // height: '24px',
            // width: '24px',
            borderRadius: '50%',
            textAlign: 'center',
            border: '1px solid',
          }}
        >
          {selected.length}
        </span> */}
      </span>
    )
  }

  const filterLayout = () => (
    <>
      <MultipleSelectCheckmarks
        listOfOptions={listOfOptions?.passwordIndicator}
        renderValue={(selected:any) => renderValue(selected, 'Password indicator')}
        selectedOptions={selectedOptions?.passwordIndicator}
        setSelectedOptions={(passwordIndicator:any) => {
          setSelectedOptions((prev: any) => ({ ...prev, passwordIndicator }))
        }}
      />

      {/* <OPRButton color="primary" variant="contained" onClick={handleClearFilters}> Clear</OPRButton> */}

    </>
  )

  // Function to handle individual checkbox change
  const handleCheckboxChange = (event: any, employeeCode:any) => {
    // Update individual checkbox selection state
    setSelectedCodes((prev:any) => {
      if (Array.isArray(prev)) {
        if (event.target.checked) {
          return [...prev, employeeCode]
        }
        return prev.filter((key:any) => key !== employeeCode)
      }
      // If prev is not an array, initialize it as an array with the new value
      if (event.target.checked) {
        return [employeeCode]
      }
      return []
    })
  }

  useEffect(() => {
    if (selectAllPassword && generatePasswordIsSuccess) {
      setSelectAllPassword(false)
      setValues({})
    }
  }, [generatePasswordIsSuccess])

  const handleSubmitall = () => {
    const payload = {
      employeeCodes: ['All'],
      expiryDate: values?.expiryDate || '', // Add default value if expiryDate is undefined
    }
    // alert('Api call')
    generatePassword(payload)
  }

  const isDeleteButtonDisabled = selectedCodes?.length <= 0

  const renderTopButtons = () => (
    <Box sx={{ display: 'flex', justifyContent: 'space-between', margin: '20px 0 0' }}>
      <div>
        <OPRCheckbox
          checked={selectedCodes?.length > 0 && selectedCodes?.length === allPosts?.records?.length} // Check if all rows are selected
          label="Select All"
          onChange={(event:any) => {
            if (event?.target?.checked) {
              setSelectedCodes(allPosts?.records.map((row:any) => row?.employeeCode))
            } else {
              setSelectedCodes([])
            }
          }}
        />
      </div>
      <div>
        <OPRButton
          color="primary" // Disable button when Select All is checked
          onClick={() => {
            setSelectAllPassword(true)
          }}
        >
          Generate All Password
        </OPRButton>
        <OPRButton
          color="primary"
          disabled={isDeleteButtonDisabled} // Disable button when Select All is checked
          onClick={handleGeneratePassword}
        >
          Generate Password
        </OPRButton>
      </div>
    </Box>
  )
  // const handleOnChange = (fieldNameOrValue:any, value:any) => {
  //   if (handleOnChange) {
  //     handleOnChange(fieldName, value)
  //   }
  // }
  // console.log(isSingleRecordExport ? [allPostExports?.records[0]] : allPostExports?.records, 'isSingleRecordExport')
  return (
    <>
      <PasswordEmpModal
        dropDate={isDropDateModal || selectAllPassword}
        errors={errors}
        handleFinalize={selectAllPassword ? handleSubmitall : handleOpenDate}
        handleOnChange={(fieldName, value) => handleOnChange(fieldName, value)} // Pass the function with two arguments        values={values}
        values={values}
        onClose={() => (selectAllPassword ? setSelectAllPassword(false) : setIsDropDateModal(false))}
      />
      <FinalModal
        handleCancel={handleCancel}
        handleSubmit={handleSubmit}
        isOpenSecondModal={isFinalOpenModal}
        selectedCodes={selectedCodes}
        selectedEmployeeData={selectedEmployeeData}
        onClose={() => setIsFinalOpenModal(false)}
      />

      <Box sx={{ display: 'flex' }}>
        <OPRAlertControl
          error={generatePasswordError}
          handleSubmit={handleSubmit}
          isError={generatePasswordIsError}
          isLoading={generatePasswordLoading}
          isSuccess={false}
          // name={values?.givenName}
          title={t('Employee password')}
          type="Update"
        />
        <OPRInnerListLayout
          isExport
          Search={decodeURIComponent(filterData.SearchText)}
          addHandleClick={() => navigate(routes.employeePassword)}
          columns={entityEmployeePassword(
            viewAcoount,
            handleCheckboxChange, // Pass your checkbox change handler here
            selectedCodes,
          )}
          dataList={isSingleRecordExport ? [allPostExports?.records[0]] : JSON.parse(JSON.stringify(allPosts?.records || []))}
          deleteCallBack={handleDelete} // Pass checkbox state and handler to logsPaycycle
          error={errorAllPosts || deleteEmployeePasswordError}
          exportProps={{
            data: allPostExports?.records,
            fileName: 'EmployeePassword',
            columns: useTranslatedColumnsForPDF(employeePasswordColumnMappingsView),
            pdf: {
              orientation: 'landscape',
            },
            allRecords: {
              baseURL: getEnv('REACT_APP_UP_BASE_URL', null),
              endpoint: getAPIWithEntityUrl(apiEndPoint.employeePasswordExportList),
              filterData: filterExportAll,
            },
          }}
          filterData={filterData}
          filterLayout={filterLayout}
          handlePagination={handlePagination}
          handleSearch={onSearch}
          isAdd={false}
          isError={isErrorAllPosts || deleteEmployeePasswordIsError}
          loading={isLoadingAllPosts || deleteEmployeePasswordLoading}
          renderTopButtons={renderTopButtons}
          selelctedUser={selelctedDelete}
          setSelelctedUser={setSelelctedDelete}
          sortHandleClick={sorting}
          success={deleteEmployeePasswordSuccess}
          title={t('Employee Password')}
        />

        {generatePasswordIsSuccess === true ? (
          <CustomDialog
            CustomStyles={{ borderRadius: '16px' }}
            isOpen={isSuccess}
            type="loader"
          >
            <div
              className="AtomPopupTitleStrip"
              style={{
                width: '100%', flexDirection: 'column', justifyContent: 'flex-start', alignItems: 'flex-start', gap: 16, display: 'inline-flex',
              }}
            >
              <div
                className="Header"
                style={{
                  alignSelf: 'stretch', justifyContent: 'flex-start', alignItems: 'flex-start', gap: 8, display: 'inline-flex',
                }}
              >
                <div
                  className="Icon"
                  style={{
                    paddingTop: 5, paddingBottom: 5, justifyContent: 'flex-start', alignItems: 'flex-start', display: 'flex',
                  }}
                >
                  <div className="Tick" style={{ width: 24, height: 24, position: 'relative' }}>
                    <SuccessIcon />
                  </div>
                </div>
                <div
                  className="Text"
                  style={{
                    flex: '1 1 0', flexDirection: 'column', justifyContent: 'flex-start', alignItems: 'flex-start', display: 'inline-flex',
                  }}
                >
                  <OPRLabel CustomStyles={{ marginTop: 2 }} variant="h4">
                    Employee password updated

                  </OPRLabel>
                  {selectedEmployeeData.map((employee:any, index:any) => (
                    <OPRLabel CustomStyles={{ marginTop: 2 }} variant="body2">
                      {`${employee?.givenName} password has been updated.`}
                    </OPRLabel>
                  ))}

                </div>
              </div>
            </div>

            <Box sx={{ display: 'flex', justifyContent: 'flex-end', marginTop: 5 }}>
              <OPRButton
                color="info"
                variant="text"
                onClick={() => {
                  handleList()
                }}
              >
                Close
              </OPRButton>
            </Box>
          </CustomDialog>
        ) : null}

      </Box>
    </>
  )
}

export default EmployeePasswordList
