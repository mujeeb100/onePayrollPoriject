import { useTheme } from '@emotion/react'
import {
  Box, Grid,
  List,
  ListItem,
} from '@mui/material'
import {
  BlueInfo, Info, RighCaretBlue,
} from 'assets/svg-images/SvgComponents'
import OPRButton from 'components/atoms/button/OPRButton'
import OPRLabel from 'components/atoms/label/OPRLabel'
import OPRDatePickerControl from 'components/molecules/OPRDatePickerControl/OPRDatePickerControl'
import OPRResponsiveGrid from 'components/molecules/OPRResponsiveGrid'
import { useState } from 'react'
import { useLocation, useNavigate } from 'react-router-dom'

import { CustomDialog } from '../../../components/atoms/modal/OPRModal'

type PasswordEmpModalProps = {
  onClose: () => void;
    isDelete?: boolean;
    dropDate: boolean;
    handleFinalize: () => void;
    errors:any
    values:any
    // setValues:any
    handleOnChange: (field: string, value: any) => void;
    // selectedEmployeeData: Array<{ employeeCode: string; givenName: string }>;
  };

  type FinalModalProps = {
    onClose: () => void;
    handleCancel:()=> void;
    handleSubmit: () => void;
    isOpenSecondModal:boolean;
    // selectedCodes: Array<{ employeeCode: string; givenName: string }>;
    selectedCodes:any
    selectedEmployeeData:any

  };

export function PasswordEmpModal({
  values, errors, handleOnChange,
  dropDate, onClose, handleFinalize,
}: PasswordEmpModalProps) {
  const theme:any = useTheme()
  const location: any = useLocation()

  const [isSuccess, setIsSuccess]:any = useState(false)

  const [isEditable, setIsEditable] = useState(false)
  const [isOpenSecondModal, setIsOpenSecondModal] = useState(false)

  const id = ''
  const navigate = useNavigate()

  const firstClose = () => {
    setIsOpenSecondModal(false)
  }
  const handleList = () => {
    setIsSuccess(false)
  }

  return (

    <Box>
      <CustomDialog
        isOpen={dropDate}
        type="loader"
      >

        <Box>
          <Box sx={{ display: 'block' }}>
            <OPRLabel sx={{ margin: '10px 0' }} variant="h4">Generate password</OPRLabel>
            <OPRLabel sx={{ margin: '0px 0px 20px' }} variant="body2">All fields are mandatory except those marked optional.</OPRLabel>

            <OPRResponsiveGrid>
              <Grid item md={8} sm={1} xs={1}>
                <OPRDatePickerControl
                  error={errors?.expiryDate}
                  isEditable={isEditable}
                  label="Expiry date"
                  name="expiryDate"
                  optionalText="Optional"
                  value={values?.expiryDate || null}
                  onChange={(date) => {
                    handleOnChange('expiryDate', date)
                  }}

                />
              </Grid>
            </OPRResponsiveGrid>

            <Box>
              <Box
                className="pop-up"
                sx={{
                  display: 'flex',
                  padding: '12px',
                  gap: '12px',
                  alignItems: 'flex-start',
                  borderRadius: '4px',
                  alignSelf: 'stretch',
                  backgroundColor: `${theme.palette.pending.main}`,
                  marginTop: 1,
                }}
              >
                <BlueInfo />
                <OPRLabel
                  CustomStyles={{
                    backgroundColor: `${theme.palette.pending.main}`,
                  }}
                  backgroundColor={theme.palette.pending.main}
                  variant="subtitle2"
                >
                  Password will be generated based on the policy below.

                </OPRLabel>
              </Box>
              <Box sx={{ display: 'block', backgroundColor: theme.palette.pending.main }}>
                <List sx={{ padding: 0 }}>
                  <ListItem sx={{ padding: '0px 10' }}>
                    <OPRLabel variant="body2"> Password Length:</OPRLabel>
                  </ListItem>
                  <ListItem sx={{ padding: '0px 10' }}>
                    <OPRLabel variant="body2">Characters [0-9 / a-z / A-Z]</OPRLabel>
                  </ListItem>
                  <ListItem sx={{ padding: '0px 10' }}>
                    <OPRLabel variant="body2">Special characters (non-alphanumeric)</OPRLabel>
                  </ListItem>
                  <ListItem sx={{ padding: '0px 10' }}>
                    <OPRLabel variant="body2">Exclude characters</OPRLabel>
                  </ListItem>
                </List>

              </Box>

            </Box>
            <Box style={{
              justifyContent:
                     'space-between',
              alignItems: 'center',
              gap: 10,
              display: 'flex',
              marginTop: '20px',
            }}
            >

              <OPRButton
                color="primary"
                variant="contained"
                onClick={onClose}
              >
                Cancel
              </OPRButton>

              <OPRButton
                color="primary"
                variant="outlined"
                onClick={handleFinalize}
              >
                Confirm
              </OPRButton>

            </Box>
          </Box>
        </Box>

      </CustomDialog>
    </Box>
  )
}

export function FinalModal({
  onClose, handleSubmit, isOpenSecondModal, selectedCodes, handleCancel, selectedEmployeeData,

}: FinalModalProps) {
  const theme:any = useTheme()

  return (

    <Box>

      <CustomDialog
        isOpen={isOpenSecondModal}
        type="loader"
      >
        <Box sx={{ display: 'block' }}>
          <OPRLabel sx={{ margin: '10px 0' }} variant="h4">Confirm to generate password</OPRLabel>
          <OPRLabel sx={{ margin: '0px 0px 20px' }} variant="body2">Please check the Employee to generate password listed below.</OPRLabel>

          <Box>
            <Box sx={{ display: 'block' }}>
              {/* Display the selected employee data */}
              <OPRLabel variant="body2">
                Employee
                (
                {selectedEmployeeData?.length}
                )
              </OPRLabel>
              <table style={{ width: '100%' }}>
                <thead>
                  <tr>
                    <th><OPRLabel sx={{ margin: '20px 0 10px' }} variant="subtitle2">Employee name | Employee ID</OPRLabel></th>
                  </tr>
                </thead>
                <tbody>
                  {/* Check if selectedEmployeeData is an array before mapping over it */}
                  {selectedEmployeeData.map((employee:any, index:any) => (
                    <tr key={employee.employeeCode}>
                      {' '}
                      {/* Add key to each row */}
                      <td>
                        <OPRLabel variant="body2">
                          {employee?.givenName}
                          <br />
                          {employee?.employeeCode}
                        </OPRLabel>
                        <hr style={{ borderBottom: '1px solid #E8E6E7' }} />
                      </td>

                    </tr>
                  ))}
                </tbody>
              </table>

            </Box>

            <Box
              className="pop-up"
              sx={{
                display: 'flex',
                padding: '12px',
                gap: '12px',
                alignItems: 'flex-start',
                borderRadius: '4px',
                alignSelf: 'stretch',
                backgroundColor: `${theme.palette.Invite.main}`,
                marginTop: 15,
              }}
            >
              <Info />
              <OPRLabel
                CustomStyles={{
                  backgroundColor: `${theme.palette.Invite.main}`,
                }}
                backgroundColor={theme.palette.Invite.main}
                variant="body2"
              >
                The password for the selected employees will be generated. Please note that you won't be able to revert this action.

              </OPRLabel>
            </Box>

            <Box sx={{
              display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: 5,
            }}
            >
              <OPRButton color="info" variant="text" onClick={onClose}>
                Cancel
              </OPRButton>
              <>
                <OPRButton
                  style={{ marginLeft: 'auto' }}
                  variant="text"
                  onClick={() => {
                  // alert('back')
                    handleCancel()
                  }}
                >
                  <RighCaretBlue />
                  Back
                </OPRButton>
                <OPRButton
                  color="primary"
                  variant="contained"
                  onClick={() => {
                    onClose(); handleSubmit()
                  // downloadFile()
                  }}
                >

                  Confirm
                </OPRButton>
              </>
            </Box>

          </Box>
        </Box>

      </CustomDialog>
    </Box>

  )
}
