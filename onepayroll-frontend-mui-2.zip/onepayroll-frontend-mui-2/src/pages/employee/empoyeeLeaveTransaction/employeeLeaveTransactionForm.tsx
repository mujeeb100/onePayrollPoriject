import { Box, Grid } from '@mui/material'
import {
  useEmployeeLeaveTransactionCreateMutation, useEmployeeLeaveTransactionUpdateMutation, useGetAllEmployeeProfileQuery, useLazyGetEmployeeLeaveTransactionByIdQuery,
} from 'api/employeeServices'
import { useGetAllPayRollNonRecurringDropDownQuery } from 'api/payRollServices'
import OPRInputControl from 'components/molecules/OPRInputControl'
import OPRResponsiveGrid from 'components/molecules/OPRResponsiveGrid'
import OPRSelectorControl from 'components/molecules/OPRSelectorControl/OPRSelectorControl'
import OPRTextArea from 'components/molecules/OPRTextArea/OPRTextArea'
import OPRAlertControl from 'components/organism/OPRAlertControl'
import { OPRInnerFormLayout } from 'components/organism/OPRInnerFormLayout'
import {
  validationSchemaEmployeeLeaveTransaction,
} from 'constants/validate'
import { useEditable } from 'hooks/useEdit'
import useForm from 'hooks/useForm'
import { t } from 'i18next'
import { useEffect, useState } from 'react'
import { useLocation, useNavigate } from 'react-router-dom'
import { routes } from 'routes/routes'
import { generateFilterUrl, getParamsValue, setRouteValues } from 'utils'

interface MessageProps {
  text?: string;
  important?: boolean;
}

export default function CostCenterForm() {
  const location: any = useLocation()
  // const id = getParamsValue(location, routes.createCostCenter)
  const { id, viewUrl } = getParamsValue(location, routes.createEmployeeLeaveTransaction)
  // const [mode, setMode] = useState('view') // Default mode is edit
  const { isEditable, setEditable } = useEditable()
  const [selectedEmployeeOption, setSelectedEmployeeOption]:any = useState(null)

  const {
    values,
    setValues,
    errors,
    handleChange,
    setErrors,
    handleFormSubmit,
    handleOnChange,
  } = useForm(validationSchemaEmployeeLeaveTransaction)

  const navigate = useNavigate()
  const [
    createCostCenter,
    {
      data: createdCostCenterData,
      error: createdCostCenterError,
      isLoading: createdCostCenterLoading,
      isSuccess: createdCostCenterSuccess,
      isError: createdCostCenterIsError,
    },
  ] = useEmployeeLeaveTransactionCreateMutation()

  const {
    data: payCycleMonthDropdown,
  } = useGetAllPayRollNonRecurringDropDownQuery('')

  //   useGetAllEmployeeProfileQuery
  const {
    data: employeeCodeData,
  } = useGetAllEmployeeProfileQuery(generateFilterUrl({ pageNumber: 1, pageSize: 1000 }))

  const [
    updateCostCenter,
    {
      data: updatedDataResponse,
      error: updatedCostCenterError,
      isLoading: updatedCostCenterLoading,
      isSuccess: updatedCostCenterSuccess,
      isError: updatedCostCenterIsError,
    },
  ] = useEmployeeLeaveTransactionUpdateMutation()

  const [
    updateCostCenterById,
    {
      data: updatedCostCenterByIdResponse,
      error: updatedCostCenterByIdError,
      isLoading: updatedCostCenterByIdLoading,
      isSuccess: updatedCostCenterByIdSuccess,
      isError: updatedCostCenterByIdIsError,
    },
  ] = useLazyGetEmployeeLeaveTransactionByIdQuery()

  useEffect(() => {
    if (id) {
      updateCostCenterById(id)
      setEditable(viewUrl)
    }
  }, [])
  useEffect(() => {
    if (id) {
      setValues(updatedCostCenterByIdResponse?.data)
    } else {
      setValues(location.state ? location.state : {})
    }
  }, [updatedCostCenterByIdResponse?.data])

  useEffect(() => {
    if (id && updatedCostCenterByIdResponse?.data) {
      const employeeProfileId = updatedCostCenterByIdResponse.data?.employeeProfileId
      const selectedEmployee = employeeOptions.find(
        (employee:any) => employee.value === employeeProfileId,
      )
      if (selectedEmployee) {
        setSelectedEmployeeOption(selectedEmployee) // Set the selected option in the dropdown
      }
      setValues(updatedCostCenterByIdResponse.data) // Set form values with the fetched data
    }
  }, [updatedCostCenterByIdResponse?.data])

  // reset the values
  // useEffect(() => {
  //   if (createdCostCenterSuccess) {
  //     setValues({})
  //     setErrors({})
  //   }
  // }, [createdCostCenterSuccess])

  const handleSubmit: any = async () => {
    if (isEditable) {
      if (id === null) {
        await createCostCenter({
          year: values?.year,
          month: values?.month,
          employeeProfileId: values?.employeeProfileId,
          leaveTransactionType: values?.leaveTransactionType,
          description: values?.description,
          unit: values?.unit,
          remarks: values?.remarks || '',
        })
      } else {
        await updateCostCenter({
          id: values?.id,
          year: values?.year,
          month: values?.month,
          employeeProfileId: values?.employeeProfileId,
          leaveTransactionType: values?.leaveTransactionType,
          description: values?.description,
          unit: values?.unit,
          remarks: values?.remarks || '',
        })
      }
    } else {
      setEditable(true)
    }
  }

  async function editCostCenter() {
    await updateCostCenter({
      id: values?.id,
      year: values?.year,
      month: values?.month,
      employeeProfileId: values?.employeeProfileId,
      leaveTransactionType: values?.leaveTransactionType,
      description: values?.description,
      unit: values?.unit,
      remarks: values?.remarks || '',
    })
  }

  const onScreenClose:any = (item: any) => {
    setEditable(item)
    setValues({})
  }

  const monthNames = [
    { MontheName: 'January', MonthValue: '01' },
    { MontheName: 'February', MonthValue: '02' },
    { MontheName: 'March', MonthValue: '03' },
    { MontheName: 'April', MonthValue: '04' },
    { MontheName: 'May', MonthValue: '05' },
    { MontheName: 'June', MonthValue: '06' },
    { MontheName: 'July', MonthValue: '07' },
    { MontheName: 'August', MonthValue: '08' },
    { MontheName: 'September', MonthValue: '09' },
    { MontheName: 'October', MonthValue: '10' },
    { MontheName: 'November', MonthValue: '11' },
    { MontheName: 'December', MonthValue: '12' },
  ]

  const employeeOptions = (employeeCodeData?.records || []).map((record:any) => ({
    id: record.id,
    label: `${record.employeeCode} - ${record.employeeProfile.givenName}`,
    value: record.employeeProfileId,
    name: record.employeeProfile.givenName,
  }))

  const handleEmployeeOptionChange = (selectedOption:any) => {
    setSelectedEmployeeOption(selectedOption)
    setValues((prevValues:any) => ({
      ...prevValues,
      employeeProfileId: selectedOption?.value, // Store employeeProfileId in state
    }))
  }
  // console.log(values?.costCenterDescription, 'costcenter')
  // Assuming you have the selected employee's ID or another identifier
  const selectedEmployee = employeeOptions.find((employee:any) => employee.id === values?.selectedEmployeeId)

  const options = [
    { MontheName: '01 - January', MonthValue: '01' },
    { MontheName: '02 - February', MonthValue: '02' },
    { MontheName: '03 - March', MonthValue: '03' },
    { MontheName: '04 - April', MonthValue: '04' },
    { MontheName: '05 - May', MonthValue: '05' },
    { MontheName: '06 - June', MonthValue: '06' },
    { MontheName: '07 - July', MonthValue: '07' },
    { MontheName: '08 - August', MonthValue: '08' },
    { MontheName: '09 - September', MonthValue: '09' },
    { MontheName: '10 - October', MonthValue: '10' },
    { MontheName: '11 - November', MonthValue: '11' },
    { MontheName: '12 - December', MonthValue: '12' },
  ]
  const handleEditClick = () => {
    // alert('hello')
    navigate(setRouteValues(`${routes.editEmployeeLeaveTransaction}`, { id })) // alert('success')
    setEditable(true)
  }

  const determineTitle = () => {
    if (viewUrl) {
      return selectedEmployeeOption?.label || ''
    }
    if (id) {
      return t('employee_leave_edit')
    }
    return t('employee_leave_add_transaction_title')
  }

  const title = determineTitle()
  return (
    <Box sx={{ display: 'flex' }}>
      <form
        style={{ display: 'flex', width: '100% ' }}
        onSubmit={(e) => handleFormSubmit(e, handleSubmit)}
      >
        <OPRAlertControl
          callBack={(type) => {
          // if (type === 'success') {
          //   navigate(-1)
          // }
          }}
          customMessage={
            id
              ? `${t('employee_leave_transaction_main_title')} ${t('employee_leave_for_text')} ${selectedEmployeeOption?.label} ${t('for')} ${monthNames.find((month: any) => month.MonthValue === values?.month)?.MontheName || 'the selected month'} ${values?.year || t('the_selected_year')} ${t('employee_leave_updated_message')}`
              : `${t('employee_leave_transaction_added_text')} ${selectedEmployeeOption?.label || t('the_selected_employee')} ${t('for')} ${monthNames.find((month: any) => month.MonthValue === values?.month)?.MontheName || t('the_selected_month')} ${values?.year || t('the_selected_year')}`
          }
          // customMessage={`Employee leave transaction has been added to ${selectedEmployeeOption?.label || 'the selected employee'} for ${monthNames.find((month:any) => month.MonthValue === values?.month)?.MontheName || 'the selected month'} ${values?.year || 'the selected year'}`}
          // customMessage={`Employee leave transaction has been added to ${selectedEmployeeOption?.label || 'the selected employee'} for ${'month'} ${'year'}`}
          error={createdCostCenterError || updatedCostCenterError}
          handleEditable={setEditable}
          handleSetValue={setValues}
          handleSubmit={handleSubmit}
          isError={createdCostCenterError || updatedCostCenterError}
          isLoading={
            createdCostCenterLoading
            || updatedCostCenterLoading
            || updatedCostCenterByIdLoading
          }
          isSuccess={updatedCostCenterSuccess || createdCostCenterSuccess}
          name={values?.year}
          // name={`Employee leave transaction has been added to ${selectedEmployeeOption?.label || 'selected employee'} for ${month} ${year}`} // Dynamically display employee name
          title={t('employee_leave_transaction_leave_text')}
          type={id ? 'Update' : 'New'}
        />

        <OPRInnerFormLayout
          error={createdCostCenterError || updatedCostCenterError}
          handleCancelClick={() => navigate(-1)}
          handleContinueClick={handleSubmit}
          handleEditable={() => {
            setEditable(true)
          }}
          isBackButton={isEditable}
          isLoading={
            createdCostCenterLoading
            || updatedCostCenterLoading
            || updatedCostCenterByIdLoading
          }
          pageType="detailsPage"
          subtitle={
            isEditable
              ? t('employee_title_message_user')
              : t('form_structure_title_des')
          }
          title={
            title
          }
          onScreenClose={onScreenClose}
        >
          <Box>
            <OPRResponsiveGrid>
              <Grid item md={2} sm={1} xs={1}>
                <OPRInputControl
                  // disabled={!!id}
                  error={t(errors?.year)}
                  isEditable={isEditable}
                  label="payroll_non_recurring_year"
                  name="year"
                  value={values?.year}
                  onChange={handleChange}
                />
              </Grid>
              <Grid item md={2} sm={1} xs={1}>
                <OPRSelectorControl
                  error={t(errors?.month)}
                  isEditable={isEditable}
                  keyName="MontheName"
                  label="payroll_non_recurring_month"
                  multiple={false}
                  name="month"
                  options={options}
                  placeholder="Select"
                  value={{
                    MontheName: options.find((option:any) => option.MonthValue === values?.month)?.MontheName, // Display the correct month name
                    MonthValue: values?.month,
                  }}
                  valueKey="MonthValue"
                  onChange={(selectedMonth:any) => handleOnChange('month', selectedMonth?.MonthValue)}
                />
              </Grid>
              <Grid item md={4} sm={6} xs={12}>
                {/* employee  */}
                <OPRSelectorControl
                  error={t(errors?.employeeProfileId)}
                  isEditable={isEditable}
                  keyName="label"
                  label="Employee"
                  multiple={false}
                  name="employeeProfileId"
                  options={employeeOptions}
                  placeholder="Select"
                  value={selectedEmployeeOption}
                  valueKey="label"
                  onChange={handleEmployeeOptionChange}
                />
              </Grid>
              <Grid item md={4} sm={6} xs={12}>
                {/* Description */}
                <OPRInputControl
                  error={t(errors?.description)}
                  isEditable={isEditable}
                  label="ent_pens_fund_scheme_code_desc"
                  name="description"
                  value={values?.description}
                  onChange={handleChange}
                />
              </Grid>
              <Grid item md={2} sm={1} xs={1}>
                {/* leave transaction type */}

                <OPRSelectorControl
                  error={t(errors?.leaveTransactionType)}
                  isEditable={isEditable}
                  keyName="providerTypeName"
                  label="employee_leave_type"
                  multiple={false}
                  name="leaveTransactionType"
                  options={[
                    { providerTypeName: 'Brought Forward', providerTypeValue: 'Brought Forward' },
                    { providerTypeName: 'Entitlement', providerTypeValue: 'Entitlement' },
                    { providerTypeName: 'Taken', providerTypeValue: 'Taken' },
                  ]}
                  placeholder="Select"
                  value={{
                    providerTypeName: values?.leaveTransactionType,
                    providerTypeValue: values?.leaveTransactionType,
                  }}
                  valueKey="providerTypeValue"
                  onChange={(text: any) => {
                    handleOnChange('leaveTransactionType', text?.providerTypeValue)
                  }}
                />
              </Grid>
              <Grid item md={2} sm={1} xs={1}>
                {/* Unit */}
                <OPRInputControl
                  error={t(errors?.unit)}
                  isEditable={isEditable}
                  label="employee_leave_unit"
                  name="unit"
                  value={values?.unit}
                  onChange={handleChange}
                />
              </Grid>
              <Grid item md={4} sm={6} xs={12}>
                <OPRTextArea
                  error={t(errors?.remarks)}
                  isEditable={isEditable}
                  label="remarks"
                  name="remarks"
                  optionalText="optional"
                  value={values?.remarks}
                  onChange={handleChange}
                />
              </Grid>

            </OPRResponsiveGrid>

          </Box>
        </OPRInnerFormLayout>
      </form>
    </Box>
  )
}
