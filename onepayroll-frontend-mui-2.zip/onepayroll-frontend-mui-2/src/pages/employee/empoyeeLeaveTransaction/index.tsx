import {
  Badge,
  Box,
} from '@mui/material'
import { useEmployeeLeaveTransactionDeleteMutation, useGetAllEmployeeLeaveTransactionQuery } from 'api/employeeServices'
import { useGetAllPayCycleOptionsQuery } from 'api/payRollServices'
import { CrossIcon, TickIcon } from 'assets/svg-images/SvgComponents'
import OPRButton from 'components/atoms/button/OPRButton'
import { OPRActionMenuOption } from 'components/atoms/dropDown/OPRActionMenu'
import OPRMultiSelectCheckbox from 'components/atoms/multiSelectCheckbox'
import { employeeLeaveTransaction } from 'components/atoms/table/OPRTableConstant'
import { OPRConfirmationDialog, OPRConfirmationDialogProps } from 'components/molecules/OPRAlertControl/OPRConfirmationDialog'
import { OPRInnerListLayout, TableRefInterface } from 'components/organism/OPRInnerLayoutList'
import apiEndPoint from 'constants/apiEndPoint'
import { ColumnemployeeLeaveTransaction } from 'constants/exportColumnMappings'
import { useTranslatedColumnsForPDF } from 'hooks/useTranslatedColumnsForPDF'
import { t } from 'i18next'
import { IOPRMultiSelectCheckboxSXProps } from 'interfaces'
import moment from 'moment'
import React, { useEffect, useRef, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { routes } from 'routes/routes'
import { DropDownOption } from 'types'
import {
  flattenDropDownOptions,
  generateFilterUrl,
  getAPIWithEntityUrl, getEnv, setRouteValues,
} from 'utils'

interface PayCycleOption {
  roleCode: string;
  roleName: string;
}

interface FilteringOptions {
  payCycleYears: PayCycleOption[];
  payCycleMonths: PayCycleOption[];
  payCycleTypes: PayCycleOption[];
  payCycleStatus: PayCycleOption[];
}

type FilterData = {
  pageNumber: number
  pageSize: number
  orderByAsc: boolean
  sortBy: string | number | symbol
  payCycleName: string
  Year: DropDownOption[]
  Month: DropDownOption[]
  Type: DropDownOption[]
}

function CostCenterList() {
  const navigate: any = useNavigate()
  const tableRef = useRef<TableRefInterface>(null)
  const [selectedPayroll, setSelectedPayroll] = useState<any>(null)
  const [selelctedDelete, setSelelctedDelete]:any = useState({
    data: {},
    isDelete: false,
    name: '',
  })

  const [confirmDialog, setConfirmDialog] = useState<OPRConfirmationDialogProps>({
    open: false,
    buttonLayout: 'confirm',
    title: '',
    message: '',
  })

  const [actionResultDialog, setActionResultDialog] = useState<OPRConfirmationDialogProps>({
    open: false,
    buttonLayout: 'close',
    title: '',
    message: '',
  })

  const defaultFilterData: FilterData = {
    pageNumber: 1,
    pageSize: 20,
    orderByAsc: true,
    sortBy: '',
    payCycleName: '',
    Type: [],
    Year: [],
    Month: [],
  }
  const [filterData, setFilterData]:any = useState(defaultFilterData)
  const [filteringOptions, setFilteringOptions] = useState<FilteringOptions>({
    payCycleYears: [],
    payCycleMonths: [],
    payCycleTypes: [],
    payCycleStatus: [],
  })

  const [filterData1, setFilterData1] = useState(defaultFilterData)

  const transformData = () => {
    const payload: any = { ...filterData }
    payload.Month = flattenDropDownOptions(filterData.Month)
    payload.Year = flattenDropDownOptions(filterData.Year)
    // payoad.lstatuses = flattenDropDownOptions(filterData.statuses)
    payload.Type = flattenDropDownOptions(filterData.Type)
    return payload
  }

  const {
    data: allPosts,
    isLoading: isLoadingAllPosts,
    isSuccess: isSuccessAllPosts,
    isError: isErrorAllPosts,
    error: errorAllPosts,
    refetch: refetchAllPosts,
  } = useGetAllEmployeeLeaveTransactionQuery(generateFilterUrl(transformData()))

  const [deleteCostCenterById,
    {
      data: deleteCostCenterResponse,
      error: deleteCostCenterError,
      isLoading: deleteCostCenterLoading,
      isSuccess: deleteCostCenterSuccess,
      isError: deleteCostCenterIsError,
    }] = useEmployeeLeaveTransactionDeleteMutation()

  const {
    data: payCycleOptions,
    isSuccess: isPayCycleOptionsSuccess,
    isError: isPayCycleOptionsError,
  } = useGetAllPayCycleOptionsQuery('')

  const sorting = (
    event: React.MouseEvent<unknown>,
    property: keyof any,
  ) => {
    const isAsc = filterData.sortBy === property && filterData.orderByAsc === true
    setFilterData({ ...filterData, orderByAsc: !isAsc, sortBy: property })
  }

  useEffect(() => {
    setFilterData({ ...filterData, totalItems: allPosts?.totalItems ? allPosts?.totalItems : 0 })
  }, [allPosts?.pageNumber, filterData.sortBy, filterData.orderByAsc, allPosts?.totalItems])

  const onSearch = (e: any, data: any) => {
    setFilterData({ ...filterData, ...data })
  }

  const handlePagination = (pageNumber: number, pageSize: number) => {
    setFilterData({ ...filterData, pageNumber })
  }

  const successHandler = (
    isSuccess: boolean,
    toStatus: string,
    data: any, // Add data parameter
    title: string | null = null,
    message: string | null = null,
  ) => {
    if (isSuccess) {
      if (title || message) {
        setActionResultDialog({
          open: true,
          icon: <TickIcon />,
          buttonLayout: 'close',
          title: title || t('employee_leave_pop_up_msg'),
          onClose: () => setActionResultDialog({ ...actionResultDialog, open: false }),
          message: message || (
            data
              ? `${t('employee_leave_title')} ${t('employee_leave_for_text')} ${selectedPayroll.employeeCode} - ${selectedPayroll.firstName} ${selectedPayroll.lastName} ${t('employee_leave_for_text')} ${moment(selectedPayroll.month).format('MMMM')} ${selectedPayroll.year}  ${t('employee_deleted_text')}`
              : 'Employee leave transaction has been deleted.'
          ),
          // message: message || `Employee leave transaction for ${data.employeeCode} - ${data.employeeName} for ${moment(data.month).format('MMMM YYYY')} has been deleted.`,employee_deleted_text
        })
      }
    }
  }

  const errorHandler = (isError: boolean, error: Error, toStatus: string, onRetry?: ()=> void, title: string | null = null) => {
    if (isError) {
      if (title) {
        const dismiss = () => setActionResultDialog({ ...actionResultDialog, open: false })
        setActionResultDialog({
          open: true,
          error,
          icon: <CrossIcon />,
          buttonLayout: 'try-again',
          title: title || t('Failed to '),
          onClose: () => {
            dismiss()
          },
          onTryAgain: () => {
            dismiss()
            onRetry?.()
          },
          onBack: () => {
            dismiss()
          },
        })
      }
    }
  }

  useEffect(() => {
    successHandler(deleteCostCenterSuccess, '', t('Pay cycle deleted'), 'Employee leave transaction has been deleted.')
    errorHandler(
      deleteCostCenterIsError,
      deleteCostCenterError,
      t('Failed to delete pay cycle'),
    )
  }, [deleteCostCenterSuccess, deleteCostCenterIsError, deleteCostCenterError])
  const viewAcoount = (data: any, option: OPRActionMenuOption) => {
    const type = option.value
    // const formattedMonth = moment(data.month, 'YYYY-MM-DD') // Adjust format as needed

    setSelectedPayroll(data)
    if (type === 'edit leave transaction') {
      navigate(
        setRouteValues(`${routes.editEmployeeLeaveTransaction}`, {
          id: data.id,
        }),
      )
    } else if (type === 'delete Leave Transaction') {
      // ${moment(data.month).format('MMMM YYYY')}
      // setSelelctedDelete({ data, isDelete: true, name: `Employee leave transaction for ${data.employeeCode} - ${data.employeeName} for ${moment(data.month).format('MMMM YYYY')} will be deleted.` })
      setConfirmDialog({
        open: true,
        buttonLayout: 'delete',
        title: t('employee_leave_conf_message'),
        message: `${t('employee_leave_title')} ${t('employee_leave_for_text')} ${data.employeeCode} - ${data.firstName} ${data.lastName} ${t('employee_leave_for_text')} ${moment(data.month).format('MMMM')} ${data.year}  ${t('employee_leave_will_be_deleted')}`,
        infoMessage: t('employee_leave_main_title'),
        onCancel: () => setConfirmDialog({ ...confirmDialog, open: false }),
        onDelete: () => {
          setConfirmDialog({ ...confirmDialog, open: false })
          deleteCostCenterById(`Id=${data.id}`)
        },
      })
    } else {
      navigate(
        setRouteValues(`${routes.viewEmployeeLeaveTransaction}`, {
          id: data.id,
        }),
      )
    }
  }
  //   {
  //   // deleteCostCenterById(`Id=${data.id}`)
  //   setSelelctedDelete({ data, isDelete: true, name: data.costCenterDescription })
  // }
  const handleView = (data: any) => {
    navigate(
      setRouteValues(`${routes.viewEmployeeLeaveTransaction}`, {
        id: data.id,
        view: true,
      }),
    )
  }
  // handle Delete
  const handleDelete = (data:any) => {
    deleteCostCenterById(`Id=${data.id}`)
  }

  // #endregion
  // #region Filter Layout
  const dropdownInputStyle = (selected?: any) : IOPRMultiSelectCheckboxSXProps => {
    const count = selected?.length || 0
    let result: IOPRMultiSelectCheckboxSXProps = { }
    if (count > 0) {
      result = { ...result, backgroundColor: '#0037A4', color: '#FFFFFF' }
    }
    return result
  }

  const renderValue = (selected: string[], filterName: string) => (
    <Box key={filterName} style={{ display: 'flex', justifyContent: 'space-between' }}>
      <span style={{ paddingLeft: '10px' }}>
        {t(`${filterName}`)}
      </span>
      <Badge
        badgeContent={selected?.length || 0}
        sx={{
          '& .MuiBadge-badge': {
            color: '#0037A4',
            backgroundColor: 'white',
            fontWeight: '700',
            fontSize: '14px',
          },
          marginTop: '12px',
          marginRight: '10px',
        }}
      />
    </Box>
  )

  useEffect(() => {
    if (isPayCycleOptionsSuccess) {
      const payCycleYears = payCycleOptions.payCycleYear.map((item: string) => ({
        roleCode: item,
        roleName: item,
      }))

      const payCycleMonths = payCycleOptions.months.map((item: any) => ({
        roleCode: item.label,
        roleName: moment().month(parseInt(item.label, 10) - 1).format('MMMM'),
      }))

      // Include hardcoded values for payCycleTypes and payCycleStatus
      const hardcodedPayCycleTypes = [
        { roleCode: 'Brought Forward', roleName: 'Brought Forward' },
        { roleCode: 'Taken', roleName: 'Taken' },
        { roleCode: 'Entitlement', roleName: 'Entitlement' },
      ]

      // Include default values for payCycleTypes and payCycleStatus
      setFilteringOptions({
        payCycleYears,
        payCycleMonths,
        payCycleTypes: hardcodedPayCycleTypes, // Default empty array
        payCycleStatus: [], // Default empty array
      })
    }
  }, [payCycleOptions])

  const filterLayout = () => (
    <>
      {/* payCycleMonth */}
      <OPRMultiSelectCheckbox
        listOfOptions={filteringOptions?.payCycleYears || []}
        renderValue={(selected) => renderValue(selected, t('employee_leave_year'))}
        selectedOptions={filterData.Year}
        setSelectedOptions={(item: any) => {
          filterData.Year = item
          setFilterData({ ...filterData })
        }}
        sx={dropdownInputStyle(filterData.Year)}
      />
      {/* payCycleYear */}
      <OPRMultiSelectCheckbox
        listOfOptions={filteringOptions?.payCycleMonths || []}
        renderValue={(selected) => renderValue(selected, t('employee_leave_month'))}
        selectedOptions={filterData.Month}
        setSelectedOptions={(item: any) => {
          filterData.Month = item
          setFilterData({ ...filterData })
        }}
        sx={dropdownInputStyle(filterData.Month)}
      />
      {/* payCycleTypes */}
      <OPRMultiSelectCheckbox
        listOfOptions={filteringOptions?.payCycleTypes || []}
        renderValue={(selected) => renderValue(selected, t('employee_leave_type'))}
        selectedOptions={filterData.Type}
        setSelectedOptions={(item: any) => {
          // Directly set the selected options to the filterData state
          filterData.Type = item
          setFilterData({ ...filterData })
        }}
        sx={dropdownInputStyle(filterData.Type)}
      />
      {/* payCycleStatus */}

      <OPRButton
        handleClick={() => {
          setFilterData(defaultFilterData)
          tableRef?.current?.setSearchField('')
        }}
        sx={{
          color: '#DA3237',
          fontWeight: 700,
          fontSize: '16px',
        }}
        variant="text"
      >
        <CrossIcon />
        {t('ent_curr_exch_clear_btn_label')}
      </OPRButton>
    </>
  )
  return (
    <>
      <OPRConfirmationDialog
        key="confirmation-dialog"
        {...confirmDialog}
      />

      <OPRConfirmationDialog
        key="action-result-dialog"
        titleSx={{
          '&::first-letter': {
            textTransform: 'capitalize',
          },
        }}
        {...actionResultDialog}
      />
      <Box sx={{ display: 'flex' }}>
        <OPRInnerListLayout
          isExport
          Search={decodeURIComponent(filterData.SearchText)}
          addHandleClick={() => navigate(routes.createEmployeeLeaveTransaction)}
          columns={employeeLeaveTransaction(viewAcoount)}
          dataList={JSON.parse(JSON.stringify(allPosts?.records || []))}
          // deleteCallBack={handleDelete}
          error={errorAllPosts}
          exportProps={{
            data: allPosts?.records,
            fileName: 'leaveTransaction',
            columns: useTranslatedColumnsForPDF(ColumnemployeeLeaveTransaction),
            pdf: {
              orientation: 'landscape',
            },
            allRecords: {
              baseURL: getEnv('REACT_APP_UP_BASE_URL', null),
              endpoint: getAPIWithEntityUrl(apiEndPoint.employeeLeaveTransactionList),
              filterData,
            },
          }}
          filterData={filterData}
          filterLayout={filterLayout}
          handlePagination={handlePagination}
          handleSearch={onSearch}
          isError={isErrorAllPosts}
          loading={isLoadingAllPosts || deleteCostCenterLoading}
          rowClickHandler={handleView}
          rowNumber={0}
          // selelctedUser={selelctedDelete}
          // setSelelctedUser={setSelelctedDelete}
          sortHandleClick={sorting}
          // success={deleteCostCenterSuccess}
          title={t('employee_leave_text')}
        />
      </Box>
    </>
  )
}

export default CostCenterList
