import OPRLabel from 'components/atoms/label/OPRLabel'
import React from 'react'

interface CustomCheckboxProps {
  employees: { code: string; personalEmailAddress: string; surname: string; givenName: string }[];
  selectedCodes: string[];
  handleCheckboxChange: (event: React.ChangeEvent<HTMLInputElement>, code: string) => void;
  handleRemoveEmployee: (codeToRemove: string) => void;
  handleSelectAllChange: (event: React.ChangeEvent<HTMLInputElement>) => void;
  selectAll: boolean;
}
function CustomCheckbox({
  onChange, selectAll, handleSelectAllChange, employees, selectedCodes, handleCheckboxChange, handleRemoveEmployee,
}: any) {
  return (
    <div>
      <label style={{ marginBottom: '10px', marginTop: '10px', display: 'block' }}>
        <input
          checked={selectAll}
          type="checkbox"
          onChange={handleSelectAllChange}
        />
        {' '}
        Select All
      </label>
      <hr style={{ borderColor: '#E8E6E7', marginBottom: '10px' }} />
      {employees?.map((employee:any) => (
        <div key={employee.code}>
          <div style={{ display: 'flex', alignItems: 'center', marginBottom: '5px' }}>
            <label style={{ marginRight: '10px', display: 'flex' }}>
              <input
                checked={selectedCodes.includes(employee.employeeCode)}
                type="checkbox"
                value={employee.employeeCode}
                onChange={(event) => handleCheckboxChange(event, employee.employeeCode)}
              />
              <div style={{ display: 'block' }}>
                <OPRLabel label={` ${employee.employeeProfile.displayName}`} variant="subtitle2" />
                <OPRLabel label={`${employee.employeeCode}`} variant="body2" />
              </div>
            </label>
          </div>
          <hr style={{ borderColor: '#E8E6E7', marginTop: '5px', marginBottom: '5px' }} />
        </div>
      ))}

    </div>
  )
}

export default CustomCheckbox
