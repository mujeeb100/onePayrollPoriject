import { useTheme } from '@emotion/react'
import {
  Box,
  Button,
  Dialog,
  DialogActions,
  DialogContent,
  DialogContentText,
  DialogTitle,
  IconButton,
  Tab,
  Tabs,
} from '@mui/material'
// import { entityPayrollHistoryColumn, nationalityColumn } from 'components/atoms/table/OPRTableConstant'
import { useGetAllEmployeeProfileQuery } from 'api/employeeServices'
import {
  useGetAllPayItemMasterQuery,
  useGetAllPayrollHistoryLogQuery,
  usePayCycleMasterSearchFilterCreateMutation,
  usePayrollHistoryCreateMutation,
  usePayrollHistoryDelete2Mutation,
} from 'api/payRollServices'
import { ReactComponent as SuccessIcon } from 'assets/svg-icons/Tick.svg'
import { ReactComponent as Trash } from 'assets/svg-icons/Trash.svg'
import OPRButton from 'components/atoms/button/OPRButton'
import OPRCheckbox from 'components/atoms/checkbox/OPRCheckbox'
import OPRLabel from 'components/atoms/label/OPRLabel'
import { CustomDialog } from 'components/atoms/modal/OPRModal'
import MultipleSelectCheckmarks from 'components/atoms/multiSelectCheckbox'
import { logPayrollHistory, payrollHistory } from 'components/atoms/table/OPRTableConstant'
import OPRDatePickerControl from 'components/molecules/OPRDatePickerControl/OPRDatePickerControl'
import { OPRInnerListLayout } from 'components/organism/OPRInnerLayoutList'
import { } from 'constants/exportColumnMappings'
import { t } from 'i18next'
import React, { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { routes } from 'routes/routes'
import {
  formatedYearDate,
  generateFilterUrl,
} from 'utils/index'

import { DeletePayrollHistoryModal } from './deletePayroll'

interface TabPanelProps {
    children?: React.ReactNode;
    index: number;
    value: number;
  }
  interface Option {
    roleCode: string
    roleName: string
  }
  interface SelectedOptions {
    employeeCodes: Option[],
    payItemCodes: Option[],
    payCycles: Option[],
    EmployeeName: Option[],
  }
function CustomTabPanel(props: TabPanelProps) {
  const {
    children, value, index, ...other
  } = props

  return (
    <div
      aria-labelledby={`simple-tab-${index}`}
      hidden={value !== index}
      id={`simple-tabpanel-${index}`}
      role="tabpanel"
      {...other}
    >
      {value === index && (
        <Box sx={{ pt: 5 }}>
          {children}
        </Box>
      )}
    </div>
  )
}

function a11yProps(index: number) {
  return {
    id: `simple-tab-${index}`,
    'aria-controls': `simple-tabpanel-${index}`,
  }
}

function PayrollHistoryList() {
  const [employeeData, setEmployeeData] = useState(null)
  const [value, setValue] = useState(0)
  const [isSuccess, setIsSuccess]:any = useState(false)

  // Checkbox state
  const [selectedPayrollCodes, setSelectedCodes]:any = useState([])
  const [selectAllChecked, setSelectAllChecked] = useState(false)
  // Assume you have a state that holds the displayed records
  // State to hold the displayed records
  const [displayedRecords, setDisplayedRecords] = useState([]) // Initialize with an empty array

  const theme:any = useTheme()
  const navigate: any = useNavigate()

  // All Filteration data here
  const [selectedDate, setSelectedDate]:any = useState(null) // State to hold the selected date
  const [selectedOptions, setSelectedOptions]:any = useState<SelectedOptions>(
    {
      employeeCodes: [],
      payItemCodes: [],
      payCycles: [],
      EmployeeName: [], // Add EmployeeName option

    },
  )
  const [listOfOptions, setListOfOptions]:any = useState<any>({
    employeeCodes: [],
    payItemCodes: [],
    payCycles: [],
  })

  // State to hold no records message
  const [noRecordsMessage, setNoRecordsMessage] = useState('')
  const [openDialog, setOpenDialog] = useState(false)

  const handleTabChange = (event: React.SyntheticEvent, newValue: number) => {
    setValue(newValue)
  }
  // checbox
  const [selelctedDeleteItem, setSelelctedDeleteItem]:any = useState({
    data: {},
    isDelete: false,
    name: '',
  })

  const [filterData, setFilterData]:any = useState({
    // CreatedDate: new Date().toISOString().split('T')[0],
    createdDate: '', // 2024-05-23
    creationOptionId: 1,
    pageNumber: 1,
    pageSize: 1000,
    totalItems: 0,
    orderByAsc: true,
    sortBy: '',
    SearchText: '',
    employeeCodes: null,
    payItemCodes: null,
    payCycles: null,
  })
  // modal
  const [isEditables, setIsEditables] = useState(false)
  const [steps, setSteps] = useState(0)
  const [selectedEmployeeData, setSelectedEmployeeData] = useState<{ employeeCode: string; givenName: string }[]>([])
  const [payGroup, setPayGroup] = React.useState('')
  const [isOpen, setIsOpen] = useState(false)
  const {
    data: allPostsLog,
    isLoading: isLoadingAllPostsLogs,
    isSuccess: isSuccessAllPostsLogs,
    isError: isErrorAllPostsLogs,
    error: errorAllPostsLogs,
    refetch: refetchAllPostsLogs,
  } = useGetAllPayrollHistoryLogQuery('')

  const
    [createPayrollHistory,
      {
        data: allPosts,
        isLoading: isLoadingAllPosts,
        isSuccess: isSuccessAllPosts,
        isError: isErrorAllPosts,
        error: errorAllPosts,
        refetch: refetchAllPosts,
      },
    ] = usePayrollHistoryCreateMutation('')

  // employee filter
  const {
    data: employeeDataList,
    isLoading: isLoadingEmployeeDataList,
    isSuccess: isSuccessEmployeeDataList,
    isError: isErrorEmployeeDataList,
    error: errorEmployeeDataList,
    refetch: refetchEmployeeDataList,
  } = useGetAllEmployeeProfileQuery(generateFilterUrl({ pageNumber: 1, pageSize: 10000 }))

  // PayItemMaster filter
  const {
    data: allPayItemMasterData,
    isLoading: isLoadingAllPayItemMasterData,
    isSuccess: isSuccessAllPayItemMasterData,
    isError: isErrorAllPayItemMasterData,
    error: errorAllPayItemMasterData,
  } = useGetAllPayItemMasterQuery(generateFilterUrl({ pageNumber: 1, pageSize: 10000 }))

  // PayCycle Master data
  // PayCycle Master data
  const
    [createPayCycleMasterData,
      {
        data: payCycleYearData,
      },
    ] = usePayCycleMasterSearchFilterCreateMutation()

  console.log('ggggggggggg', payCycleYearData)

  // usePayrollHistoryDelete2Mutation
  const [
    deletePayrollHistoryDeleteMutaion,
    {
      data: payrollHistorydelete2,
      error: payrollHistorydelete2Error,
      isLoading: payrollHistorydelete2Loading,
      isSuccess: payrollHistorydelete2Success,
      isError: payrollHistorydelete2IsError,
    },
  ] = usePayrollHistoryDelete2Mutation()

  useEffect(() => {
    if (allPosts?.data?.totalItems) {
      setFilterData((prev:any) => ({ ...prev, totalItems: allPosts?.data?.totalItems }))
    }
  }, [allPosts])

  useEffect(() => {
    // Define the request body
    const requestBody = {
      pageSize: 1000,
      pageNumber: 1,
      sortBy: '',
      orderByAsc: true,
      // "payCycleType": [2]
    }

    // Call the API
    createPayCycleMasterData(requestBody)
  }, [createPayCycleMasterData])

  useEffect(() => {
    fetchData()
  }, [])
  useEffect(() => {
    // Determine which filters have selections
    const hasPayItemCodes = selectedOptions?.payItemCodes?.length > 0
    const hasPayCycles = selectedOptions?.payCycles?.length > 0
    const hasEmployeeCodes = selectedOptions?.employeeCodes?.length > 0

    // Update filterData and fetchData based on conditions
    if (hasPayItemCodes || hasPayCycles || hasEmployeeCodes) {
      setFilterData({
        payItemCodes: hasPayItemCodes ? selectedOptions.payItemCodes : null,
        payCycles: hasPayCycles ? selectedOptions.payCycles : null,
        pageSize: 1000, // Assuming pageSize should be set to 1000 in any case
      })
      fetchData()
    } else {
      setFilterData({
        payItemCodes: null, payCycles: null, employeeCodes: null, pageSize: 1000,
      })
      fetchData()
    }
  }, [selectedOptions.payItemCodes, selectedOptions.payCycles, selectedOptions.employeeCodes])

  const fetchData = async (pageNumber = filterData.pageNumber, pageSize = filterData.pageSize) => {
    const employeeCodes = selectedOptions?.employeeCodes?.map((item:any) => item.roleCode)
    const payItemCodes = selectedOptions?.payItemCodes?.map((item:any) => item?.roleCode)
    const payCycles = selectedOptions?.payCycles?.map((item:any) => item?.roleCode)
    const createdDate = formatedYearDate(selectedDate) || new Date()

    await createPayrollHistory({
      payrollHistorySearch: {
        createdDate,
        creationOptionId: filterData?.creationOptionId,
        payItemCodes: payItemCodes?.length > 0 ? payItemCodes : null,
        payCycles: payCycles?.length > 0 ? payCycles : null,
        employeeCodes: employeeCodes?.length > 0 ? employeeCodes : null,
      },
      pageNumber,
      pageSize,
      sortBy: filterData.sortBy,
      orderByAsc: filterData.orderByAsc,
    })
  }

  // Other filteration Part
  useEffect(() => {
    // pay cycle year option
    if (employeeDataList && allPayItemMasterData && payCycleYearData) {
      const uniquePayCycleYears = Array.from(new Set(payCycleYearData?.data?.records?.map((item: any) => item.payCycleYear) || []))
      const uniquePayCycleMonths = Array.from(new Set(payCycleYearData?.data?.records?.map((item: any) => item.payCycleMonth) || []))
      const uniquePayCycleCodes = Array.from(new Set(payCycleYearData?.data?.records?.map((item: any) => item.payCycleCode) || []))

      // Generate PayCycleYearMonthCode options
      const payCycleYearMonthCodeOptions = uniquePayCycleYears.flatMap((year) => uniquePayCycleMonths.flatMap((month) => uniquePayCycleCodes.flatMap((code) => ({
        roleCode: `${year}${month}${code}`,
        roleName: `${year}${month}${code}`,
      }))))

      const employeeCodeOption = employeeDataList?.records?.map((item: any) => ({
        roleCode: item.employeeCode,
        roleName: `${item.employeeCode} - ${item.employeeProfile?.givenName || ''}`, // Concatenate employeeCode and givenName
      }))
      const payItemCodeOption = allPayItemMasterData?.records?.map((item: any) => ({
        roleCode: item.payItemCode,
        roleName: `${item.payItemCode} - ${item?.payItemName || ''}`,
      }))

      setListOfOptions((prev:any) => ({
        ...prev,
        employeeCodes: employeeCodeOption,
        payItemCodes: payItemCodeOption,
        payCycles: payCycleYearMonthCodeOptions,

      }))
    }
  }, [employeeDataList, allPayItemMasterData, payCycleYearData])

  // useEffect(() => {
  const updateFilterData = () => {
    // const employeeCodes = selectedOptions.employeeCodes.map((item: any) => item.roleCode).join(',')
    // const payItemCodes = selectedOptions.payItemCodes.map((item: any) => item.roleCode).join(',')

    selectedOptions?.EmployeeName?.forEach((item:any) => {
      setFilterData((prev:any) => ({ ...prev, employeeCodes: item.roleCode }))
    })

    selectedOptions?.payItemCodes?.forEach((item:any) => {
      setFilterData((prev:any) => ({ ...prev, payItemCodes: item.roleCode }))
    })

    if (selectedOptions?.payCycles?.length > 0) {
      const payCycles = selectedOptions.payCycles.map((item: any) => item.roleCode)

      setFilterData((prev: any) => ({
        ...prev,
        payCycles,
      }))
    }
  }

  useEffect(() => {
    if (selectedOptions?.payCycles?.length > 0) {
      const payCycles = selectedOptions.payCycles.map((item: any) => item.roleCode)

      setFilterData((prev: any) => ({
        ...prev,
        payCycles,
      }))

      updateFilterData()
    }
  }, [selectedOptions.payCycles])

  useEffect(() => {
    fetchData()
  }, [
    filterData.payCycles,
    filterData.payItemCodes,
    selectedOptions.employeeCodes,
  ])
  useEffect(() => {
    updateFilterData()
  }, [selectedOptions])
  // Function to handle date selection change filterarion part for date
  const handleDateChange = (date: any | null) => {
    setSelectedDate(date)
    if (date) {
      // const formattedDate = date.toISOString().split('T')[0]
      setFilterData((prev: any) => ({ ...prev, CreatedDate: formatedYearDate(date.toString()) }))
      // fetchData()
    }
  }

  // date picker
  useEffect(() => {
    if (selectedDate) {
      // const formattedDate = selectedDate.toISOString().split('T')[0]
      setFilterData((prev: any) => ({ ...prev, CreatedDate: formatedYearDate(selectedDate.toString()) }))
      fetchData()
    }
  }, [selectedDate])

  useEffect(() => {
    // Update filterData state with selectedDate whenever it changes
    if (selectedDate) {
      const formattedDate = selectedDate?.toISOString()?.split('T')[0]
      setFilterData((prev: any) => ({
        ...prev,
        createdDate: formattedDate,
      }))
    }
  }, [selectedDate])
  useEffect(() => {
    if (selectedDate && allPosts?.data?.records?.length === 0) {
      setNoRecordsMessage('No records found for the selected Items')
      setOpenDialog(true)
    } else {
      setNoRecordsMessage('')
      setOpenDialog(false)
    }
  }, [selectedDate, allPosts])

  const handleCloseDialog = () => {
    setOpenDialog(false)
  }
  const handleSuccessClose = () => {
    setIsSuccess(false)
  }
  const sorting = (
    event: React.MouseEvent<unknown>,
    property: keyof any,
  ) => {
    const isAsc = filterData.sortBy === property && filterData.orderByAsc === true
    setFilterData({ ...filterData, orderByAsc: !isAsc, sortBy: property })
  }

  useEffect(() => {
    setFilterData({ ...filterData, totalItems: allPosts?.totalItems ? allPosts?.totalItems : 0 })
  }, [allPosts?.pageNumber, filterData.sortBy, filterData.orderByAsc, allPosts?.totalItems])

  const onSearch = (e: any, data: any) => {
    setFilterData({ ...filterData, ...data })
  }
  const handlePagination = (pageNumber: number, pageSize: number) => {
    setFilterData({ ...filterData, pageNumber })
  }

  const handleSubmit: any = async () => {
    const selectedEmployeeData = {
      payrollHistoryUploadId: selectedPayrollCodes,
      filterCriteria: 'createdDate, creationOptionId, employeeCodes, payItemCodes, payCycles',
    }
    await deletePayrollHistoryDeleteMutaion({ body: selectedEmployeeData })
    // setSelectedEmployeeData(selectedEmployeeData)
    // setIsOpen(true)
    setSelelctedDeleteItem({ ...selelctedDeleteItem, isDelete: false })
  }

  useEffect(() => {
    if (payrollHistorydelete2Success) {
      setSelectedCodes([])

      // Remove the deleted records from the displayed list
      // setDisplayedRecords((prevRecords) => prevRecords.filter((record) => !selectedPayrollCodes.includes(record)))
    }
  }, [payrollHistorydelete2Success])

  // Function to handle individual checkbox change
  const handleCheckboxChange = (event: any, id:any) => {
    // Update individual checkbox selection state
    if (event.target.checked) {
      setSelectedCodes((prev:any) => [...prev, id])
    } else {
      setSelectedCodes((prev:any) => prev.filter((key:any) => key !== id))
    }
  }

  const handleDeleteButtonClick = () => {
    setSelelctedDeleteItem({ isDelete: true })
    // const selectedEmployeeData = allPosts?.records?.filter((item: any) => selectedCodes.includes(item.employeeCode)).map((item: any) => ({ employeeCode: item.employeeCode, givenName: item.givenName }))
    // setSelectedEmployeeData(selectedEmployeeData)
    // setIsOpen(true)
  }

  const renderValue = (selected: any[], filterName: string) => {
    if (selected?.length === 0) {
      return <span>{t(`${filterName}`)}</span>
    }

    return (
      <span style={{ display: 'flex', justifyContent: 'space-between' }}>
        <span style={{ }}>
          {t(`${filterName}`)}
          {' '}
        </span>
        <span>
          {selected?.length}
        </span>
      </span>
    )
  }

  const handleFilterChange = (filterName: string, values: any) => {
    setSelectedOptions((prevSelectedOptions: any) => ({
      ...prevSelectedOptions,
      [filterName]: values,
    }))
    fetchData()
  }

  const filterLayout = () => (
    <>
      <MultipleSelectCheckmarks
        listOfOptions={listOfOptions?.employeeCodes}
        renderValue={(selected:any) => renderValue(selected, 'Employee')}
        selectedOptions={selectedOptions?.employeeCodes}
        setSelectedOptions={(employeeCodes:any) => {
          setSelectedOptions((prev: any) => ({ ...prev, employeeCodes }))
          fetchData()
        }}
      />
      <MultipleSelectCheckmarks
        listOfOptions={listOfOptions?.payItemCodes}
        renderValue={(selected:any) => renderValue(selected, 'Pay Item')}
        selectedOptions={selectedOptions?.payItemCodes}
        setSelectedOptions={(payItemCodes:any) => {
          setSelectedOptions((prev: any) => ({ ...prev, payItemCodes }))
          fetchData()
        }}
      />
      <MultipleSelectCheckmarks
        listOfOptions={listOfOptions?.payCycles || []} // Ensure it's an array and provide a default empty array if null
        renderValue={(selected:any) => renderValue(selected, 'Pay Cycle')}
        selectedOptions={selectedOptions?.payCycles || []} // Ensure selectedOptions is always an array
        setSelectedOptions={(payCycles:any) => {
          setSelectedOptions((prev: any) => ({ ...prev, payCycles }))
          fetchData()
        }}
      />
      <OPRDatePickerControl
        // label="Select Date"
        placeholder="Creation Date"
        value={selectedDate} // Pass selectedDate as the value
        onChange={handleDateChange} // Handle date selection change

      />

    </>
  )
  useEffect(() => {
    if (payrollHistorydelete2Success === true) {
      setIsSuccess(true)
    }
  }, [payrollHistorydelete2Success])

  const isDeleteButtonDisabled = selectedPayrollCodes?.length <= 0

  const renderTopButtons = () => (
    <Box sx={{ display: 'flex', justifyContent: 'space-between', margin: '20px 0 0' }}>
      <div>

        <OPRCheckbox
          checked={
            selectedPayrollCodes?.length > 0
  && selectedPayrollCodes?.length === allPosts?.data?.records?.length
          }
          label="Select All"
          onChange={(event:any) => {
            if (event.target.checked) {
              setSelectedCodes(allPosts?.data?.records.map((row:any) => row.id))
            } else {
              setSelectedCodes([])
            }
          }} // Handle "Select All" checkbox change
        />

      </div>
      <div>
        <Box
          sx={{
            borderRadius: 110,
            overflow: 'hidden',
            border: '1px #DA3237 solid',
            justifyContent: 'center',
            alignItems: 'center',
            display: 'inline-flex',
            opacity: isDeleteButtonDisabled ? 0.5 : 1, // Conditional opacity based on button disabled state
            pointerEvents: isDeleteButtonDisabled ? 'none' : 'auto', // Disable pointer events based on button disabled state
          }}
        >
          <IconButton>
            <Trash />
          </IconButton>
          <OPRButton
            disabled={isDeleteButtonDisabled} // Disable button when Select All is checked
            sx={{
              color: '#DA3237',
            }}
            variant="text"
            onClick={handleDeleteButtonClick}
          >
            Delete selected
          </OPRButton>
        </Box>
      </div>
    </Box>
  )

  return (
    <>
      <DeletePayrollHistoryModal
        handleClose={() => setSelelctedDeleteItem({ isDelete: false })}
        handleConfirm={handleSubmit}
        open={selelctedDeleteItem.isDelete}
        // payItem={payGroup}
        selectedPayrollCodes={selectedPayrollCodes}
      />

      <Box sx={{ display: 'flex', flexDirection: 'column' }}>
        <OPRLabel label={t('Delete payroll history')} variant="h2" />
        <Box>
          <Tabs aria-label="basic tabs example" value={value} onChange={handleTabChange}>
            <Tab label=" payroll history" {...a11yProps(0)} />
            <Tab label="Logs" {...a11yProps(1)} />
          </Tabs>
        </Box>
        {/* <Box sx={{ display: 'flex', justifyContent: 'space-between', margin: '20px 0 0' }}>
          <div>

            <OPRCheckbox
              checked={selectedPayrollCodes.length === allPosts?.records.length} // Check if all rows are selected
              label="Select All"
              onChange={(event:any) => {
                if (event.target.checked) {
                  setSelectedCodes(allPosts?.records.map((row:any) => row.id))
                } else {
                  setSelectedCodes([])
                }
              }} // Handle "Select All" checkbox change
            />

          </div>
          <div>
            <OPRButton
              color="primary"
              // disabled={!selectAllChecked} // Disable button when Select All is checked
              onClick={handleDeleteButtonClick}
            >
              Delete selected
            </OPRButton>
          </div>
        </Box> */}
        <CustomTabPanel index={0} value={value}>
          <OPRInnerListLayout
            Search={filterData.SearchText}
            addHandleClick={() => navigate(routes.payrollHistory)}
            columns={payrollHistory(
              '', // Pass your edit function here
              handleCheckboxChange, // Pass your checkbox change handler here
              selectedPayrollCodes, // Pass the selected payroll codes
            )}
            // columns={payrollHistory('', props.selectedPayrollCodes, props.handleCheckboxChange)}
            dataList={JSON.parse(JSON.stringify(allPosts?.data?.records || []))}
            // deleteCallBack={} // Pass checkbox state and handler to logsPaycycle
            error={errorAllPosts || payrollHistorydelete2Error}
            filterData={filterData}
            filterLayout={filterLayout}
            handlePagination={handlePagination}
            handleSearch={onSearch}
            isAdd={false}
            isError={isErrorAllPosts || payrollHistorydelete2IsError}
            loading={isLoadingAllPosts || payrollHistorydelete2Loading}
            renderTopButtons={renderTopButtons}
            rowNumber={0}
            selectedCodes={selectedPayrollCodes}
            sortHandleClick={sorting}
            success=""
            title={t('')}
          />

        </CustomTabPanel>
        <CustomTabPanel index={1} value={value}>
          <OPRInnerListLayout
            Search={filterData.SearchText}
            addHandleClick={() => navigate(routes.createRunPayroll)}
            columns={logPayrollHistory('')}
            dataList={JSON.parse(JSON.stringify(allPostsLog?.records || []))}
            deleteCallBack=""
            error={errorAllPosts}
            filterData={filterData}
            handlePagination={handlePagination}
            handleSearch={onSearch}
            isAdd={false}
            isError={isErrorAllPosts}
            loading={isLoadingAllPosts}
            sortHandleClick={sorting}
            success=""
            title={t('')}
          />
        </CustomTabPanel>

      </Box>
      {/* Dialog for no records message */}
      <Dialog
        aria-describedby="alert-dialog-description"
        aria-labelledby="alert-dialog-title"
        open={openDialog}
        onClose={handleCloseDialog}
      >
        <DialogTitle id="alert-dialog-title">No Records Found</DialogTitle>
        <DialogContent>
          <DialogContentText id="alert-dialog-description">
            {noRecordsMessage}
          </DialogContentText>
        </DialogContent>
        <DialogActions>
          <Button autoFocus color="primary" onClick={handleCloseDialog}>
            OK
          </Button>
        </DialogActions>
      </Dialog>
      {payrollHistorydelete2Success === true ? (
        <CustomDialog
          CustomStyles={{ borderRadius: '16px' }}
          isOpen={isSuccess}
          type="loader"
        >
          <div
            className="AtomPopupTitleStrip"
            style={{
              width: '100%', flexDirection: 'column', justifyContent: 'flex-start', alignItems: 'flex-start', gap: 16, display: 'inline-flex',
            }}
          >
            <div
              className="Header"
              style={{
                alignSelf: 'stretch', justifyContent: 'flex-start', alignItems: 'flex-start', gap: 8, display: 'inline-flex',
              }}
            >
              <div
                className="Icon"
                style={{
                  paddingTop: 5, paddingBottom: 5, justifyContent: 'flex-start', alignItems: 'flex-start', display: 'flex',
                }}
              >
                <div className="Tick" style={{ width: 24, height: 24, position: 'relative' }}>
                  <SuccessIcon />
                </div>
              </div>
              <div
                className="Text"
                style={{
                  flex: '1 1 0', flexDirection: 'column', justifyContent: 'flex-start', alignItems: 'flex-start', display: 'inline-flex',
                }}
              >
                <OPRLabel CustomStyles={{ marginTop: 2 }} variant="h4">
                  Bulk delete payroll history submitted

                </OPRLabel>
                <OPRLabel
                  CustomStyles={{
                    marginTop: '12px',
                    display: 'flex',
                    alignItems: 'center',
                    gap: '12px',
                  }}
                  variant="body2"
                >

                  Bulk delete payroll history has been submitted.
                  Please refer to the log file for more information.
                </OPRLabel>

              </div>
            </div>
          </div>

          <Box sx={{
            display: 'flex', justifyContent: 'space-between', marginTop: 5,
          }}
          >

            <OPRButton
              color="info"
              style={{ textAlign: 'left', paddingLeft: '15px' }} // Align button text to the left
              variant="text"
              onClick={() => {
                handleSuccessClose()
              }}
            >
              Go to log
            </OPRButton>

            <OPRButton
              color="info"
              style={{
                display: 'flex',
                padding: '8px 16px',
                alignItems: 'center',
                gap: '12px',
                color: '#FFF',
                background: 'var(--blue-blue-5000049-db, #0049DB)',
              }}
              variant="text"
              onClick={() => {
                handleSuccessClose()
              }}
            >
              Close
            </OPRButton>

          </Box>
        </CustomDialog>

      ) : null}

    </>
  )
}

export default PayrollHistoryList
