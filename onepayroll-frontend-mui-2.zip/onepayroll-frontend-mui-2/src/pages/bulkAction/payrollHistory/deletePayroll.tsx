import { useTheme } from '@emotion/react'
import {
  Box, Button, DialogActions, DialogContent, DialogTitle,
} from '@mui/material'
// import { usePayrollHistoryDelete2Mutation } from 'api/payRollServices'
import { Info } from 'assets/svg-images/SvgComponents'
import OPRLabel from 'components/atoms/label/OPRLabel'
import React, { useState } from 'react'
import { useLocation, useNavigate } from 'react-router-dom'

import { CustomDialog } from '../../../components/atoms/modal/OPRModal'

type DeletePayrollHistoryModalProps = {
    onClick?: (data: any, type: string) => void;
    handleClose: () => void;
    isDelete?: boolean;
    isOpen?: boolean;
    payItem?: any;
    selectedCodes?:any;
    open?:boolean;
    handleConfirm: () => void;
    selectedPayrollCodes:any;
  };

export function DeletePayrollHistoryModal({
  onClick, isDelete = false, open = false,
  isOpen, payItem, handleClose, handleConfirm, selectedPayrollCodes,
}: DeletePayrollHistoryModalProps) {
  const theme:any = useTheme()
  const location: any = useLocation()

  const [isSuccess, setIsSuccess]:any = useState(false)

  const id = ''
  const navigate = useNavigate()

  return (
    <Box>

      <CustomDialog
        closeTitle=""
        isOpen={open}
        type="loader"
      >

        <Box>

          <DialogTitle>
            Are you sure you want to delete the selected items?
          </DialogTitle>
          <DialogContent sx={{
            display: 'flex',
            padding: '12px',
            gap: '12px',
            alignItems: 'flex-start',
            borderRadius: '4px',
            alignSelf: 'stretch',
            backgroundColor: `${theme.palette.Invite.main}`,
            marginTop: 1,
          }}
          >
            <Info />
            <OPRLabel
              CustomStyles={{
                backgroundColor: `${theme.palette.Invite.main}`,
              }}
              backgroundColor={theme.palette.Invite.main}
              variant="body2"
            >

              You’ve chosen to delete
              {' '}
              {selectedPayrollCodes?.length}
              {' '}
              items. If they are deleted, you will not be able to revert it.
            </OPRLabel>
          </DialogContent>
          <DialogActions sx={{
            display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: 5,
          }}
          >
            <Button color="info" variant="text" onClick={handleClose}>
              Cancel
            </Button>
            <Button
              style={{
                color: 'var(--red-red-500-da-3237, #DA3237)',
                borderRadius: '110px',
                border: '1px solid var(--red-red-500-da-3237, #DA3237)',
              }}
              variant="text"
              onClick={handleConfirm}
            >
              Delete
            </Button>
          </DialogActions>

        </Box>

      </CustomDialog>
      {/*
      {deletePayrollHistorySuccess === true ? (
        <CustomDialog
          CustomStyles={{ borderRadius: '16px' }}
          isOpen={isSuccess}
          type="loader"
        >
          <div
            className="AtomPopupTitleStrip"
            style={{
              width: '100%', flexDirection: 'column', justifyContent: 'flex-start', alignItems: 'flex-start', gap: 16, display: 'inline-flex',
            }}
          >
            <div
              className="Header"
              style={{
                alignSelf: 'stretch', justifyContent: 'flex-start', alignItems: 'flex-start', gap: 8, display: 'inline-flex',
              }}
            >
              <div
                className="Icon"
                style={{
                  paddingTop: 5, paddingBottom: 5, justifyContent: 'flex-start', alignItems: 'flex-start', display: 'flex',
                }}
              >
                <div className="Tick" style={{ width: 24, height: 24, position: 'relative' }}>
                  <SuccessIcon />
                </div>
              </div>
              <div
                className="Text"
                style={{
                  flex: '1 1 0', flexDirection: 'column', justifyContent: 'flex-start', alignItems: 'flex-start', display: 'inline-flex',
                }}
              >
                <OPRLabel CustomStyles={{ marginTop: 2 }} variant="h4">
                  Employee password updated

                </OPRLabel>
                h

              </div>
            </div>
          </div>

          <Box sx={{ display: 'flex', justifyContent: 'flex-end', marginTop: 5 }}>
            <OPRButton
              color="info"
              variant="text"
              onClick={() => {
                navigate(-1)
              }}
            >
              Close
            </OPRButton>
          </Box>
        </CustomDialog>
      ) : null} */}

    </Box>
  )
}
