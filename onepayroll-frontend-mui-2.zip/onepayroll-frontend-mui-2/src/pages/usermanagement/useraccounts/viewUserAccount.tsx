import { Box, Checkbox, Grid } from '@mui/material'
import {
  useGetAllUserAdminEntityQuery,
  useGetAllUserRoleQuery,
  useLazyGetUserAdministrationByIdQuery, useUserAdministrationCreateMutation, useUserAdministrationUpdateMutation,
} from 'api/identityServices'
import { LeftBack } from 'assets/svg-images/SvgComponents'
import OPRButton from 'components/atoms/button/OPRButton'
import OPRLabel from 'components/atoms/label/OPRLabel'
import OPRInputControl from 'components/molecules/OPRInputControl'
import OPRResponsiveGrid from 'components/molecules/OPRResponsiveGrid'
import OPRSelectorControl from 'components/molecules/OPRSelectorControl/OPRSelectorControl'
import OPRAlertControl from 'components/organism/OPRAlertControl'
import { OPRInnerFormLayout } from 'components/organism/OPRInnerFormLayout'
import { validationSchemaUserAccount } from 'constants/validate'
import { useEditable } from 'hooks/useEdit'
import useForm from 'hooks/useForm'
import React, { useEffect, useState } from 'react'
import { useLocation, useNavigate } from 'react-router-dom'
import { routes } from 'routes/routes'
import { generateFilterUrl, getParamsValue, setRouteValues } from 'utils'

import {
  a11yProps,
  CustomTabPanel, StyledTab, StyledTabs,
} from '../../../components/atoms/tabs'
import UserAccountEntityList from './userAccountEntity'

interface MessageProps {
    text?: string;
    important?: boolean;
  }

export default function ViewUserAccounts() {
  const navigate = useNavigate()
  const location: any = useLocation()
  const { id, viewUrl } = getParamsValue(location, routes.createUserAccounts)
  const [value, setValue] = React.useState(0)
  const [filterData, setFilterData] = useState({ SearchText: '' })

  const handleTabChange = (event: React.SyntheticEvent, newValue: number) => {
    setValue(newValue)
  }
  const {
    isEditable,
    setEditable,
  } = useEditable()

  const {
    values,
    setValues,
    errors,
    handleChange,
    handleOnChange,
    setErrors,
    handleFormSubmit,
  } = useForm(validationSchemaUserAccount)

  const [createUserAccount, {
    data: createdUserAdministrationData,
    error: createdUserAdministrationError,
    isLoading: createdUserAdministrationLoading,
    isSuccess: createdUserAdministrationSuccess,
    isError: createdUserAdministrationIsError,
  }] = useUserAdministrationCreateMutation()

  const {
    data: allUserRoles,
    error: createAllPostsBankAccountError,
    isLoading: isLoadingAllUserRoles,
    isSuccess: isSuccessAllPosts1,
    isError: isErrorAllPosts1,
    error: errorAllPosts1,
  } = useGetAllUserRoleQuery(generateFilterUrl({
    pageSize: 10000,
    roleType: true,
  }))

  const [updateUserAccount, {
    data: updatedUserAdministrationDataResponse,
    error: updatedUserAdministrationError,
    isLoading: updatedUserAdministrationLoading,
    isSuccess: updatedUserAdministrationSuccess,
    isError: updatedUserAdministrationIsError,
  }] = useUserAdministrationUpdateMutation()

  const [updateUserAccountById, {
    data: updatedCountryByIdResponse,
    error: updatedCountryByIdError,
    isLoading: updatedCountryByIdLoading,
    isSuccess: updatedCountryByIdSuccess,
    isError: updatedCountryByIdIsError,
  }] = useLazyGetUserAdministrationByIdQuery()

  const {
    data: allPosts,
    isLoading: isLoadingAllPosts,
    isSuccess: isSuccessAllPosts,
    isError: isErrorAllPosts,
    error: errorAllPosts,
    refetch: refetchAllPosts,
  } = useGetAllUserAdminEntityQuery(generateFilterUrl(filterData))

  useEffect(() => {
    setFilterData({ ...filterData, SearchText: updatedCountryByIdResponse?.responseData?.firstName })
  }, [updatedCountryByIdSuccess])

  useEffect(() => {
    if (id) {
      updateUserAccountById(id)
      setEditable(viewUrl)
      // getUserAdminEntityById(id)
    }
  }, [])

  useEffect(() => {
    if (id) {
      setValues(updatedCountryByIdResponse?.responseData)
    } else {
      setValues(location.state ? location.state : {})
      // setEditable(false)
    }
  }, [updatedCountryByIdResponse?.responseData])

  useEffect(() => {
    if (createdUserAdministrationSuccess) {
      // Reset form values after successful add operation
      setValues({})
      setErrors({})
    }
  }, [createdUserAdministrationSuccess])

  const handleSubmit:any = async () => {
    if (isEditable) {
      if (id === null) {
        await createUserAccount({
          username: values?.username,
          firstName: values?.firstName,
          lastName: values?.lastName,
          emailAddress: values?.emailAddress,
          officeNumber: values?.officeNumber,
          mobileNumber: values?.mobileNumber,
          accountStatus: 'Active',
          userType: 'Internal',
          defaultLanguage: values?.defaultLanguage.value,
          defaultTimeZone: values?.defaultTimeZone.value,
          remarks: values?.remarks,
          cultureInfo: '',
        })
      } else {
        await updateUserAccount({
          id: values.id,
          username: values?.username,
          firstName: values?.firstName,
          lastName: values?.lastName,
          emailAddress: values?.emailAddress,
          officeNumber: values?.officeNumber,
          mobileNumber: values?.mobileNumber,
          accountStatus: values?.accountStatus,
          userType: values?.userType,
          defaultLanguage: values?.defaultLanguage.value,
          defaultTimeZone: values?.defaultTimeZone.value,
          remarks: values?.remarks,
          cultureInfo: '',
        })
      }
    } else {
      setEditable(true)
    }
  }
  async function editUserAdministration() {
    await updateUserAccount({
      id: values.id,
      UserAdministrationCode: values.UserAdministrationCode?.toUpperCase(),
      UserAdministrationName: values.UserAdministrationName,
    })
  }

  const onScreenClose:any = (item:any) => {
    setEditable(item)
    setValues({})
  }
  const handleEditClick = () => {
    navigate(
      setRouteValues(`${routes.editUserAccounts}`, {
        id,
      }),
    )
  }
  console.log('********************', values?.isSystemAdmin)

  return (
    <>
      <Box sx={{
        display: 'flex', justifyContent: 'space-between', flexDirection: 'row',
      }}
      >
        <Box sx={{
          display: 'flex', justifyContent: 'flex-start', alignItems: 'center', gap: '25px',
        }}
        >
          <Box
            component="div"
            onClick={() => navigate(-1)}
          >
            <LeftBack />
          </Box>
          <OPRLabel variant="h2">

            {' '}
            {` ${updatedCountryByIdResponse?.responseData?.firstName || ''}`}
            {' '}
            {` ${updatedCountryByIdResponse?.responseData?.lastName || ''}`}
          </OPRLabel>
        </Box>
        <Box sx={{
          display: 'flex', justifyContent: 'flex-start', height: 'fit-content',
        }}
        >
          <OPRButton
            color="primary"
            handleClick={handleEditClick}
            style={{ borderRadius: '110px' }}
            variant="outlined"
          >
            Edit User Account
          </OPRButton>
        </Box>
      </Box>
      <Box sx={{ width: '100%' }}>
        <Box sx={{ borderBottom: 1, borderColor: 'divider' }}>
          <StyledTabs aria-label="basic tabs example" value={value} onChange={handleTabChange}>
            <StyledTab label="Overview" {...a11yProps(0)} />
            <StyledTab label="Entities" {...a11yProps(1)} />
          </StyledTabs>
        </Box>
        <CustomTabPanel index={0} value={value}>
          <Box sx={{ display: 'flex' }}>
            <form style={{ display: 'flex', width: '100% ' }} onSubmit={(e) => handleFormSubmit(e, handleSubmit)}>
              <OPRAlertControl
                error={createdUserAdministrationError || updatedUserAdministrationError}
                handleEditable={setEditable}
                handleSetValue={setValues}
                handleSubmit={handleSubmit}
                isError={createdUserAdministrationError || updatedUserAdministrationError}
                isLoading={createdUserAdministrationLoading || updatedUserAdministrationLoading || updatedCountryByIdLoading}
                isSuccess={updatedUserAdministrationSuccess || createdUserAdministrationSuccess}
                name={values?.username}
                title="User Account"
                type={id ? 'Update' : 'New'}
              />
              <OPRInnerFormLayout
                error={createdUserAdministrationError || updatedUserAdministrationError}
                handleCancelClick={() => navigate(-1)}
                handleContinueClick={handleSubmit}
                handleEditable={() => {
                  setEditable(true)
                }}
                isBackButton={isEditable}
                isHeader={false}
                isLoading={createdUserAdministrationLoading || updatedUserAdministrationLoading || updatedCountryByIdLoading}
                pageType="detailsPage"
                subtitle={isEditable ? 'Please check the user details below.' : 'All field to mandatory expect those mark optional'}
                title="User account"
                onScreenClose={onScreenClose}
              >
                <Box>
                  <OPRResponsiveGrid>
                    <Grid item md={2} sm={1} xs={1}>
                      <OPRInputControl
                        disabled={location.pathname !== routes.createUserAccounts}
                        error={errors?.username}
                        isEditable={isEditable}
                        label="Username"
                        name="username"
                        value={values?.username}
                        onChange={handleChange}
                      />
                    </Grid>
                    <Grid item md={12} sm={1} xs={1}>
                      <div
                        className="CheckboxWText"
                        style={{
                          width: '100%', height: '100%', justifyContent: 'flex-start', alignItems: 'flex-start', gap: 8, display: 'inline-flex', padding: '0px',
                        }}
                      >
                        <div
                          className="AtomCheckbox"
                          style={{
                            paddingTop: 1, paddingBottom: 1, justifyContent: 'flex-start', alignItems: 'center', display: 'flex',
                          }}
                        >
                          <div
                            className="Checkbox"
                            style={{
                              padding: 2, background: 'white', borderRadius: 4, overflow: 'hidden', justifyContent: 'flex-start', alignItems: 'flex-start', gap: 10, display: 'flex',
                            }}
                          >
                            <Checkbox
                              checked={values?.isSystemAdmin}
                              style={{ width: 16, height: 16, position: 'relative' }}
                              onChange={(e) => {
                                // console.log('values.defaultBankAccount', e.target.checked)
                                handleOnChange('isSystemAdmin', e.target.checked)
                              }}
                            />
                          </div>
                        </div>
                        <div
                          className="AtomLabels"
                          style={{
                            flex: '1 1 0', height: 22, justifyContent: 'flex-start', alignItems: 'flex-start', gap: 8, display: 'flex',
                          }}
                        >
                          <div
                            className="Label"
                            style={{
                              flex: '1 1 0', color: '#3B3839', fontSize: 14, fontFamily: 'Lato', fontWeight: '400', wordWrap: 'break-word',
                            }}
                          >
                            Assign as System admin
                          </div>
                        </div>
                      </div>
                    </Grid>
                    {values?.isSystemAdmin ? (
                      <Grid item md={12} sm={1} xs={1}>
                        <OPRSelectorControl
                          isRequired
                          isEditable={isEditable}
                          keyName="roleName"
                          label="Role Type"
                          name="roleName"
                          options={allUserRoles?.data || []}
                          value={allUserRoles?.data?.find((o:any) => o?.id === values?.userRoleId) || {}}
                          valueKey="roleName"
                          onChange={(text:any) => {
                            handleOnChange('userRoleId', text?.id)
                          }}
                        />
                      </Grid>
                    ) : <div style={{ display: 'none', background: 'red' }}><h1>efvshhvvfd</h1></div>}

                    <Grid item md={2} sm={1} xs={1}>
                      <OPRInputControl error={errors?.firstName} isEditable={isEditable} label="First Name" name="firstName" value={values?.firstName} onChange={handleChange} />
                    </Grid>
                    <Grid item md={2} sm={1} xs={1}>
                      <OPRInputControl error={errors?.lastName} isEditable={isEditable} label="Last Name" name="lastName" value={values?.lastName} onChange={handleChange} />
                    </Grid>
                    <Grid item md={4} sm={1} xs={1}>
                      <OPRInputControl error={errors?.emailAddress} isEditable={isEditable} label="Email address" name="emailAddress" value={values?.emailAddress} onChange={handleChange} />
                    </Grid>
                    <Grid item md={2} sm={1} xs={1}>
                      <OPRInputControl error={errors?.mobileNumber} isEditable={isEditable} label="Mobile number" name="mobileNumber" value={values?.mobileNumber} onChange={handleChange} />
                    </Grid>
                    <Grid item md={2} sm={1} xs={1}>
                      <OPRInputControl error={errors?.officeNumber} isEditable={isEditable} label="Office number" name="officeNumber" value={values?.officeNumber} onChange={handleChange} />
                    </Grid>
                    <Grid item md={2} sm={1} xs={1}>
                      <OPRSelectorControl
                        isRequired
                        isEditable={isEditable}
                        keyName="name"
                        label="Default language"
                        name="defaultLanguage"
                        options={[
                          { name: 'English', values: 'English' },
                          { name: '中文（简体', values: 'zh-CN' },
                        ]}
                        value={[{ name: 'English', values: 'English' },
                          { name: '中文（简体', values: 'zh-CN' },
                        ].find((o:any) => o.values === values?.defaultLanguage) || {}}
                        valueKey="values"
                        onChange={(text:any) => {
                          handleOnChange('defaultLanguage', text?.values)
                        }}
                      />
                    </Grid>
                    <Grid item md={2} sm={1} xs={1}>
                      <OPRSelectorControl
                        isRequired
                        isEditable={isEditable}
                        keyName="name"
                        label="Default Timezone"
                        name="defaultTimeZone"
                        options={[{ name: 'IND', values: 'IND' },
                          { name: 'HK', values: 'HK' },
                        ]}
                        value={[{ name: 'IND', values: 'IND' },
                          { name: 'HK', values: 'HK' },
                        ].find((o:any) => o.values === values?.defaultTimeZone) || {}}
                        valueKey="values"
                        onChange={(text:any) => {
                          handleOnChange(
                            'defaultTimeZone',
                            text?.values,
                          )
                        }}
                      />
                      {/* <OPRInputControl error={errors?.defaultTimeZone} isEditable={isEditable} label="Default Timezone" name="defaultTimeZone" value={values?.defaultTimeZone} onChange={handleChange} /> */}
                    </Grid>
                    <Grid item md={4} sm={1} xs={1}>
                      <OPRInputControl error={errors?.remarks} isEditable={isEditable} label="Remarks" name="remarks" value={values?.remarks} onChange={handleChange} />
                    </Grid>
                  </OPRResponsiveGrid>
                </Box>

              </OPRInnerFormLayout>
            </form>
          </Box>
        </CustomTabPanel>
        <CustomTabPanel index={1} value={value}>
          <UserAccountEntityList entityData={allPosts?.data} />
        </CustomTabPanel>
      </Box>
    </>
  )
}
