import { useTheme } from '@emotion/react'
import { Box } from '@mui/material'
import {
  useGetAllUserAdminEntityQuery,
} from 'api/identityServices'
import { ReactComponent as ErrorIcon } from 'assets/svg-icons/ErrorIcon.svg'
import { ReactComponent as ErrorStatus } from 'assets/svg-icons/ErrorStatus.svg'
import OPRButton from 'components/atoms/button/OPRButton'
import OPRLabel from 'components/atoms/label/OPRLabel'
import OPREnhancedTable from 'components/atoms/table/OPREnhancedTable'
import { uerRoleSelectColumn } from 'components/atoms/table/OPRTableConstant'
import { t } from 'i18next'
import React, { useState } from 'react'
import { generateFilterUrl } from 'utils'

import { CustomDialog } from '../../../components/atoms/modal/OPRModal'

type DeactivateModalProps = {
    onClick?: (data: any, type: string) => void;
    handleClose: () => void;
    isDelete?: boolean;
    isOpen: boolean;
    user: any;
  };

export function DeactivateModal({
  onClick, isDelete = false, isOpen, user, handleClose,
}: DeactivateModalProps) {
  const theme:any = useTheme()
  const [steps, setSteps] = useState(0)
  const [isEntity, setIsEntity] = useState(user.entityCount > 0)
  const createSubtitle = () => (isDelete ? {
    title: t('unable_delete_user_account'),
  } : {
    title: t('unable_deactivate_user_account'),
  })
  const isSelected = (id:any) => {}
  const {
    data: UserAdminEntityData,
    isLoading: isLoadingAllUserAdminEntity,
    isSuccess: isSuccessAllUserAdminEntity,
    isError: isErrorAllUserAdminEntity,
    error: errorAllUserAdminEntity,
    refetch: refetchAllUserAdminEntity,
  } = useGetAllUserAdminEntityQuery(generateFilterUrl({ SearchText: user.firstName }))
  const handleResume = () => {
    if (steps === 1) {
      setSteps((prev) => prev - 1)
    } else {
      handleClose()
      setSteps(0)
    }
  }
  return (
    <Box>
      {/* <OPRAlertControl
            isEntity
            error={createUserRoleError}
            handleSubmit={handleConfirm}
            isError={createUserRoleError}
            isLoading={createUserRoleLoading}
            isSuccess={createUserRoleSuccess}
            name={`${user?.firstName} ${user?.lastName}`}
            title="Entities"
            type="New"
          /> */}
      <CustomDialog
        isResume
        CustomStyles={{ borderRadius: '16px' }}
        closeTitle="cancel"
        handleBack={() => {
        }}
        handleClose={() => {
          handleClose()
          setSteps(0)
        }}
        handleResume={handleResume}
        isClose={false}
        isOpen={isOpen}
        resumeTitle={steps === 1 ? 'Back' : 'Close'}
        subtitle={steps === 1 ? `${user?.firstName} ${user?.lastName} is associated with the entities below` : ''}
        title={steps === 1 ? 'Associated entities' : ''}
      >
        {(() => {
          switch (steps) {
            case 0:
              return (
                <>
                  <div
                    className="AtomPopupTitleStrip"
                    style={{
                      width: '100%', flexDirection: 'column', justifyContent: 'flex-start', alignItems: 'flex-start', gap: 16, display: 'inline-flex',
                    }}
                  >
                    <div
                      className="Header"
                      style={{
                        alignSelf: 'stretch', justifyContent: 'flex-start', alignItems: 'flex-start', gap: 8, display: 'inline-flex',
                      }}
                    >
                      <div
                        className="Icon"
                        style={{
                          paddingTop: 5, paddingBottom: 5, justifyContent: 'flex-start', alignItems: 'flex-start', display: 'flex',
                        }}
                      >
                        <div className="Tick" style={{ width: 24, height: 24, position: 'relative' }}>
                          <ErrorIcon />
                        </div>
                      </div>
                      <div
                        className="Text"
                        style={{
                          flex: '1 1 0', flexDirection: 'column', justifyContent: 'flex-start', alignItems: 'flex-start', display: 'inline-flex',
                        }}
                      >
                        <OPRLabel CustomStyles={{ marginTop: 2 }} variant="h4">
                          {createSubtitle().title}
                        </OPRLabel>
                      </div>
                    </div>
                  </div>
                  <Box sx={{
                    display: 'flex',
                    padding: '12px',
                    gap: '12px',
                    alignItems: 'flex-start',
                    // flexDirection: 'row',
                    borderRadius: '4px',
                    alignSelf: 'stretch',
                    // gap: 1,
                    marginTop: 1,
                    backgroundColor: `${theme.palette.error.main}`,
                  }}
                  >
                    <ErrorStatus />
                    <Box sx={{
                      display: 'flex',
                      flexDirection: 'column',

                    }}
                    >
                      <OPRLabel variant="body2">
                        {t('action_cannot_associated_entites')}
                      </OPRLabel>
                    </Box>
                  </Box>
                  <OPRButton
                    //   style={{ marginLeft: 'auto' }}
                    variant="text"
                    onClick={() => {
                      setSteps((prev) => prev + 1)
                    }}
                  >
                    {t('show_associated_entities')}
                  </OPRButton>
                </>
              )
            case 1:
              return (
                <>
                  <OPRLabel CustomStyles={{ marginLeft: '15px' }} variant="body2">
                    Entities
                    (
                    {user.entityCount}
                    )
                  </OPRLabel>
                  <OPREnhancedTable
                    isDeactivate
                    cols={uerRoleSelectColumn()}
                    data={JSON.parse(JSON.stringify(UserAdminEntityData?.data || []))}
                    isSelected={isSelected}
                    steps={0}
                  />
                </>
              )
            default:
              console.log('No Cases mmatched , Please Close')
              return null // return null when no other cases match
          }
        })()}
      </CustomDialog>
    </Box>
  )
}
