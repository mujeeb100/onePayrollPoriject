import {
  Box,
} from '@mui/material'
import { uerRoleSelectColumn } from 'components/atoms/table/OPRTableConstant'
import { OPRInnerListLayout } from 'components/organism/OPRInnerLayoutList'
import { t } from 'i18next'
import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { routes } from 'routes/routes'

function UserAccountEntityList({ entityData }:any) {
  const navigate: any = useNavigate()
  const [filterData, setFilterData]:any = useState({
    pageNumber: 1,
    pageSize: 20,
    totalItems: 0,
    orderByAsc: true,
    sortBy: '',
    SearchText: '',
  })

  const sorting = (
    event: React.MouseEvent<unknown>,
    property: keyof any,
  ) => {
    const isAsc = filterData.sortBy === property && filterData.orderByAsc === true
    setFilterData({ ...filterData, orderByAsc: !isAsc, sortBy: property })
    // setOrder(isAsc ? 'desc' : 'asc')
    // setOrderBy(property)
  }

  const onSearch = (e: any, data: any) => {
    setFilterData({ ...filterData, ...data })
  }
  const handlePagination = (pageNumber: number, pageSize: number) => {
    setFilterData({ ...filterData, pageNumber })
  }
  const viewAcoount = (data: any, type:string) => {
  }

  return (
    <Box sx={{ display: 'flex' }}>
      <OPRInnerListLayout
        Search={filterData.SearchText}
        addHandleClick={() => navigate(routes.createCountry)}
        columns={uerRoleSelectColumn(viewAcoount)}
        dataList={JSON.parse(JSON.stringify(entityData || []))}
        filterData={filterData}
        handlePagination={handlePagination}
        handleSearch={onSearch}
        isHeader={false}
        // rowClickHandler={handleView}
        rowNumber={0}
        sortHandleClick={sorting}
        title={t('Entities')}
      />
    </Box>
  )
}

export default UserAccountEntityList
