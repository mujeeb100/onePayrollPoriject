import {
  Box,
} from '@mui/material'
import { useGetAllUserAdministrationQuery, useUserAdministrationDeleteMutation, useUserAdministrationUpdateMutation } from 'api/identityServices'
import { userAccountsColumn } from 'components/atoms/table/OPRTableConstant'
import { OPRDeleteControl } from 'components/molecules/OPRAlertControl/OPRDeleteControl'
import OPRAlertControl from 'components/organism/OPRAlertControl'
import { OPRInnerListLayout } from 'components/organism/OPRInnerLayoutList'
import { t } from 'i18next'
import React, { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { routes } from 'routes/routes'
import { AccountActionHandlerType } from 'types'
import { generateFilterUrl, setRouteValues } from 'utils'

import { EntityAssignModal } from './bulkAssignModal'
import { DeactivateModal } from './deactivateModal'

function UserAccounts() {
  const [isOpen, setIsOpen] = useState(false)
  const [isDelOpen, setIsDelOpen] = useState(false)
  const [isDeactivate, setIsDeactivate] = useState(false)
  const [isDuplicate, setIsDuplicate] = useState(false)
  const [isUserDel, setIsUserDel] = React.useState({})
  const [user, setUser] = React.useState({})
  const [isDelete, setIsDelete] = useState(false)
  const navigate: any = useNavigate()
  const [selelctedDelete, setSelelctedDelete]:any = useState({
    data: {},
    isDelete: false,
    name: '',
  })
  const [filterData, setFilterData]:any = useState({
    pageNumber: 1,
    pageSize: 20,
    totalItems: 0,
    orderByAsc: true,
    sortBy: '',
    SearchText: '',
  })
  const {
    data: allPosts,
    isLoading: isLoadingAllPosts,
    isSuccess: isSuccessAllPosts,
    isError: isErrorAllPosts,
    error: errorAllPosts,
    refetch: refetchAllPosts,
  } = useGetAllUserAdministrationQuery(generateFilterUrl(filterData))
  const [updateUserAccount, {
    data: updatedUserAdministrationDataResponse,
    error: updatedUserAdministrationError,
    isLoading: updatedUserAdministrationLoading,
    isSuccess: updatedUserAdministrationSuccess,
    isError: updatedUserAdministrationIsError,
  }] = useUserAdministrationUpdateMutation()
  const [activeUserAccount, {
    data: activeUserAdministrationDataResponse,
    error: activeUserAdministrationError,
    isLoading: activeUserAdministrationLoading,
    isSuccess: activeUserAdministrationSuccess,
    isError: activeUserAdministrationIsError,
  }] = useUserAdministrationUpdateMutation()
  const [deleteUserAccountById,
    {
      data: deleteCountryResponse,
      error: deleteCountryError,
      isLoading: deleteCountryLoading,
      isSuccess: deleteCountrySuccess,
      isError: deleteCountryIsError,
    }] = useUserAdministrationDeleteMutation()
  const sorting = (
    event: React.MouseEvent<unknown>,
    property: keyof any,
  ) => {
    const isAsc = filterData.sortBy === property && filterData.orderByAsc === true
    setFilterData({ ...filterData, orderByAsc: !isAsc, sortBy: property })
    // setOrder(isAsc ? 'desc' : 'asc')
    // setOrderBy(property)
  }
  const handleDelete = async (data:any) => {
    if (isDeactivate) {
      await updateUserAccount({
        id: data.id,
        username: data?.username,
        firstName: data?.firstName,
        lastName: data?.lastName,
        emailAddress: data?.emailAddress,
        officeNumber: data?.officeNumber,
        mobileNumber: data?.mobileNumber,
        accountStatus: 'Inactive',
        userType: data?.userType,
        defaultLanguage: data?.defaultLanguage,
        defaultTimeZone: data?.defaultTimeZone,
        remarks: data?.remarks,
        cultureInfo: '',
      })
    } else {
      deleteUserAccountById(`Id=${data.id}`)
    }
  }

  useEffect(() => {
    setFilterData({ ...filterData, totalItems: allPosts?.totalItems ? allPosts?.totalItems : 0 })
  }, [allPosts?.pageNumber, filterData.sortBy, filterData.orderByAsc, allPosts?.totalItems])

  const onSearch = (e: any, data: any) => {
    setFilterData({ ...filterData, ...data })
  }
  const handlePagination = (pageNumber: number, pageSize: number) => {
    setFilterData({ ...filterData, pageNumber })
  }

  const accountActionHandler = async (data: any, type: AccountActionHandlerType) => {
    if (type === 'edit_user_account') {
      setIsDuplicate(false)
      setUser(data)
      setIsOpen(true)
    } else if (type === 'duplicate_user_access') {
      setIsDuplicate(true)
      setUser(data)
      setIsOpen(true)
    } else if (type === 'deactivate_user_account') {
      if (data.entityCount > 0) {
        setIsDelete(false)
        setUser(data)
        setIsDelOpen(true)
      } else {
        setIsDeactivate(true)
        setSelelctedDelete({ data, isDelete: true, name: `${data?.firstName} ${data?.lastName}` })
      }
    } else if (type === 'delete_user_account') {
      if (data.entityCount > 0) {
        setIsDelete(true)
        setUser(data)
        setIsDelOpen(true)
      } else {
        setIsDeactivate(false)
        setSelelctedDelete({ data, isDelete: true, name: `${data?.firstName} ${data?.lastName}` })
      }
    } else if (type === 'edit_user_modal') {
      navigate(
        setRouteValues(`${routes.editUserAccounts}`, {
          id: data.id,
        }),
      )
    } else if (type === 'activate_user_account') {
      if (data) {
        setSelelctedDelete({ data, name: `${data?.firstName} ${data?.lastName}` })
        await activeUserAccount({
          id: data.id,
          username: data.username,
          firstName: data.firstName,
          lastName: data.lastName,
          emailAddress: data.emailAddress,
          officeNumber: data.officeNumber,
          mobileNumber: data.mobileNumber,
          accountStatus: 'Active',
          userType: data.userType,
          defaultLanguage: data.defaultLanguage,
          defaultTimeZone: data.defaultTimeZone,
          remarks: data.remarks,
          cultureInfo: data.cultureInfo || '',
        })
      }
    }
  }
  const handleView = (data: any) => {
    navigate(
      setRouteValues(`${routes.viewUserAccounts}`, {
        id: data.id,
        view: true,
      }),
    )
  }
  return (
    <>
      <DeactivateModal
        handleClose={() => {
          // if (reason && reason === 'backdropClick') return
          setIsDelOpen(false)
        }}
        isDelete={isDelete}
        isOpen={isDelOpen}
        user={user}
      />
      <EntityAssignModal
        handleClose={() => {
          // if (reason && reason === 'backdropClick') return
          setIsOpen(false)
        }}
        handleOpen={() => setIsOpen(true)}
        isDuplicate={isDuplicate}
        isOpen={isOpen}
        user={user}
        onClick={accountActionHandler}
      />
      <OPRDeleteControl
        isUserDelete
        deleteCallBack={handleDelete}
        isDeactivate={isDeactivate}
        selelctedUser={selelctedDelete}
        setSelelctedUser={setSelelctedDelete}
        title={t('user_account')}
      />
      <Box sx={{ display: 'flex' }}>
        <OPRAlertControl
          isCustom
          customMessage={isDeactivate ? `${selelctedDelete?.name} has been deactivated` : `${selelctedDelete?.name} has been deleted`}
          customTitle={isDeactivate ? 'User account deactivated' : 'User account deleted'}
          error={deleteCountryError || updatedUserAdministrationError}
          isError={deleteCountryIsError || updatedUserAdministrationIsError}
          isLoading={deleteCountryLoading || updatedUserAdministrationLoading}
          isSuccess={updatedUserAdministrationSuccess || deleteCountrySuccess}
          name={`${selelctedDelete?.name}`}
          title={t('user_account')}
          type="New"
        />
        <OPRAlertControl
          isCustom
          customMessage={`${selelctedDelete?.name} has been Activated`}
          customTitle="User account Activated"
          error={activeUserAdministrationError}
          isError={activeUserAdministrationIsError}
          isLoading={activeUserAdministrationLoading}
          isSuccess={activeUserAdministrationSuccess}
          name={`${selelctedDelete?.name}`}
          title={t('user_account')}
          type="New"
        />
        <OPRInnerListLayout
          Search={filterData.SearchText}
          addHandleClick={() => navigate(routes.createUserAccounts)}
          columns={userAccountsColumn(accountActionHandler)}
          dataList={JSON.parse(JSON.stringify(allPosts?.data || []))}
          deleteCallBack={handleDelete}
          error={errorAllPosts}
          filterData={filterData}
          handlePagination={handlePagination}
          handleSearch={onSearch}
          isError={isErrorAllPosts}
          loading={isLoadingAllPosts}
          rowClickHandler={handleView}
          rowNumber={0}
          sortHandleClick={sorting}
          success={deleteCountrySuccess}
          title="User Accounts"
        />
      </Box>
    </>
  )
}

export default UserAccounts
