import { Box, Divider } from '@mui/material'
import { useGetAllClientGroupEntityQuery } from 'api/globalServices'
import {
  useGetAllUserAdminEntityQuery, useGetAllUserAdministrationQuery, useGetAllUserRoleQuery, useUserAdminEntityCreateMutation, useUserAdminEntityDeleteMutation,
} from 'api/identityServices'
import OPRLabel from 'components/atoms/label/OPRLabel'
import OPRRadioGroup from 'components/atoms/radioGroup'
import OPREnhancedTable from 'components/atoms/table/OPREnhancedTable'
import { entitySelectColumn, uerRoleSelectColumn } from 'components/atoms/table/OPRTableConstant'
import { t } from 'i18next'
import React, { useState } from 'react'
import { AccountActionHandlerType } from 'types'
import { generateFilterUrl } from 'utils'

import { CustomDialog } from '../../../components/atoms/modal/OPRModal'
import OPRAlertControl from '../../../components/organism/OPRAlertControl'

type EntityAssignModalProps = {
    onClick: (data: any, type: AccountActionHandlerType) => void;
    handleClose: () => void;
    handleOpen?: () => void;
    isDuplicate?: boolean;
    isOpen: boolean;
    user: any;
  };

const options = ['Edit user account', 'Assign entity', 'Remove entity']

export function EntityAssignModal({
  onClick, isDuplicate = false, isOpen, user, handleOpen, handleClose,
}: EntityAssignModalProps) {
  const [steps, setSteps] = useState(0)
  const [isCancel, setIsCancel] = useState(false)
  const [customMessage, setCustomMessage] = useState({
    customTitle: '',
    customMessage: '',
  })
  const [value, setValue] = React.useState('')
  const [checkedValue, setCheckedValue] = React.useState<any[]>([])
  const [selected, setSelected] = React.useState<readonly number[]>([])
  const [filterData, setFilterData]:any = useState({
    pageNumber: 1,
    pageSize: 20,
    totalItems: 0,
    orderByAsc: true,
    sortBy: '',
    SearchText: '',
  })
  const [userEntityData, setUserEntityData] = useState({
    SearchText: '',
  })
  const [isSkip, setIsSkip] = useState(true)
  const [isRemove, setIsRemove] = useState(false)
  const [duplicateItem, setDuplicateItem] = useState({
    accountStatus:
'',
    cultureInfo:
'',
    defaultLanguage:
'',
    defaultTimeZone:
'',
    emailAddress:
'',
    entityCount:
0,
    firstName:
'',
    id:
'',
    lastName:
'',
    mobileNumber:
'',
    officeNumber:
'',
    remarks:
'',
    userType:
'',
    username:
'',
  })

  const [createBulkUserAdminEntity, {
    data: createUserRoleData,
    error: createUserRoleError,
    isLoading: createUserRoleLoading,
    isSuccess: createUserRoleSuccess,
    isError: createUserRoleIsError,
  }] = useUserAdminEntityCreateMutation()

  const {
    data: allPosts,
    isLoading: isLoadingAllPosts,
    isSuccess: isSuccessAllPosts,
    isError: isErrorAllPosts,
    error: errorAllPosts,
    refetch: refetchAllPosts,
  } = useGetAllClientGroupEntityQuery(generateFilterUrl(filterData))

  const {
    data: userRoleData,
    isLoading: isLoadingUserRole,
    isSuccess: isSuccessUserRole,
    isError: isErrorUserRole,
    error: errorUserRole,
    refetch: refetchUserRole,
  } = useGetAllUserRoleQuery(generateFilterUrl(filterData), { skip: steps === 1 })
  const {
    data: userAdmin,
    isLoading: isLoadingUserAdmin,
    isSuccess: isSuccessUserAdmin,
    isError: isErrorUserAdmin,
    error: errorUserAdmin,
    refetch: refetchUserAdmin,
  } = useGetAllUserAdministrationQuery(generateFilterUrl(filterData), { skip: !isDuplicate })
  const {
    data: UserAdminEntityData,
    isLoading: isLoadingAllUserAdminEntity,
    isSuccess: isSuccessAllUserAdminEntity,
    isError: isErrorAllUserAdminEntity,
    error: errorAllUserAdminEntity,
    refetch: refetchAllUserAdminEntity,
  } = useGetAllUserAdminEntityQuery(generateFilterUrl(userEntityData), { skip: isSkip })
  const [
    deleteUserAdminEntityById,
    {
      data: deleteUserAdminEntityResponse,
      error: deleteUserAdminEntityError,
      isLoading: deleteUserAdminEntityLoading,
      isSuccess: deleteUserAdminEntitySuccess,
      isError: deleteUserAdminEntityIsError,
    },
  ] = useUserAdminEntityDeleteMutation()
  // useEffect(
  //   () => {
  //     setSelected([])
  //     setCheckedValue([])
  //     setSteps(0)
  //   },
  //   [isOpen],
  // )

  const handleChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    setValue((event.target as HTMLInputElement).value)
  }

  const handleConfirm:any = async () => {
    handleClose()
    if (isRemove) {
      setCustomMessage({
        customTitle: 'Entities removed',
        customMessage: `Entities removed from ${user?.firstName} ${user?.lastName}`,

      })
      await deleteUserAdminEntityById(`userAdminId=${checkedValue[0].id}`)
      // checkedValue?.forEach((item:any) => {
      //   deleteUserAdminEntityById(`userAdminId=${item.id}`)
      // })
      setSelected([])
      setCheckedValue([])
      setSteps(0)
    } else {
      setCustomMessage({
        customTitle: 'Entities assigned',
        customMessage: `Entities assigned to ${user?.firstName} ${user?.lastName}`,

      })
      const entities = checkedValue.map((item) => {
        // if (isDuplicate) {
        // const userRoleIds = userRoleData.data.filter((role:any) => role.roleName === item.userRole).map((item: any) => item.id)
        // const clientGroupId = allPosts?.records.filter((grp:any) => grp.clientGroupName === item.clientGroupName).map((item: any) => {
        //   const entityId = item.id
        //   const clientGroupId = item.clientGroupProfileId
        //   return { entityId, clientGroupId }
        // })
        // }
        const userRoleIds = item.userRole.map((item: any) => item.id)
        const entityId = item.id
        const clientGroupId = item.clientGroupProfileId
        return { entityId, clientGroupId, userRoleIds }
      })
      await createBulkUserAdminEntity({
        userId: user.id,
        entities,
      })
      setSelected([])
      setCheckedValue([])
      setSteps(0)
    }
  }

  const handleRadioSubmit = () => {
    if (steps === 1 && checkedValue.length > 0) {
      isDuplicate || isRemove ? setSteps((prev) => prev + 2) : setSteps((prev) => prev + 1)
    } else if (steps === 2) {
      setSteps((prev) => prev + 1)
    } else if (steps === 3) {
      handleConfirm()
    } else if (steps === 0) {
      if (value === 'Edit user account') {
        onClick(user, 'edit_user_modal')
      }
      if (value === 'Assign entity') {
        setSteps((prev) => prev + 1)
      }
      if (value === 'Remove entity') {
        setIsRemove(true)
        setUserEntityData({ ...filterData, SearchText: user?.firstName })
        setIsSkip(false)
        setSteps((prev) => prev + 1)
      }
    }
  }

  const handleClick = (event: React.MouseEvent<unknown>, item: any) => {
    const selectedIndex = selected.indexOf(item.id)
    let newSelected: readonly number[] = []
    if (selectedIndex === -1) {
      newSelected = newSelected.concat(selected, item.id)
      setCheckedValue([
        ...checkedValue,
        item,
      ])
    } else if (selectedIndex === 0) {
      newSelected = newSelected.concat(selected.slice(1))
      setCheckedValue(checkedValue.filter((val) => val.id !== item.id))
    } else if (selectedIndex === selected.length - 1) {
      newSelected = newSelected.concat(selected.slice(0, -1))
      setCheckedValue(checkedValue.filter((val) => val.id !== item.id))
    } else if (selectedIndex > 0) {
      newSelected = newSelected.concat(
        selected.slice(0, selectedIndex),
        selected.slice(selectedIndex + 1),
      )
      setCheckedValue(checkedValue.filter((val) => val.id !== item.id))
    }
    setSelected(newSelected)
  }
  const isSelected = (id:any) => selected.indexOf(id) !== -1

  const onSearch = (e: any) => {
    setFilterData({ ...filterData, SearchText: e.target.value, pageNumber: 1 })
  }

  const createSubtitle = (steps: number) => {
    if (steps === 0) {
      return isDuplicate ? {
        title: t('select_user_account'),
        subtitle: `${t('select_user_account_duplicate')} ${user?.firstName} ${user?.lastName}'s access`,
      } : {
        title: t('edit_user_account'),
        subtitle: '',
      }
    }
    if (steps === 1) {
      return isDuplicate ? {
        title: t('select_entities'),
        subtitle: t('select_entities_for_duplicating'),
      } : {
        title: t('assign_entity'),
        subtitle: t('select_entitties_assign_to_user'),
      }
    } if (steps === 2) {
      return {
        title: t('select_user_role'),
        subtitle: t('select_user_role_for_entity'),
      }
    } if (steps === 3) {
      return isDuplicate ? {
        title: t('confirm_details'),
        subtitle: t('please_check_user_entities'),
      } : {
        title: t('confirm_entities_to_assign'),
        subtitle: t('please_check_entities_listed'),
      }
    }
    return {
      title: t('edit_user_account'),
      subtitle: '',
    }
  }
  const handleUserClick = (item: any) => {
    setDuplicateItem(item)
    setUserEntityData({ ...filterData, SearchText: item?.firstName })
    setIsSkip(false)
    setSteps((prev) => prev + 1)
  }

  return (
    <>
      <OPRAlertControl
        isCustom
        isEntity
        callBack={() => {
          setIsCancel(false)
          handleClose()
          setSelected([])
          setCheckedValue([])
          setSteps(0)
        }}
        customMessage={customMessage.customMessage}
        customTitle={customMessage.customTitle}
        error={createUserRoleError || deleteUserAdminEntityError}
        handleCancel={handleOpen}
        handleSubmit={handleConfirm}
        isCancel={isCancel}
        isError={createUserRoleError || deleteUserAdminEntityError}
        isLoading={createUserRoleLoading || deleteUserAdminEntityLoading}
        isSuccess={createUserRoleSuccess || deleteUserAdminEntitySuccess}
        name={`${user?.firstName} ${user?.lastName}`}
        title="Entities"
        type="New"
      />
      <CustomDialog
        isResume
        CustomStyles={{ borderRadius: '16px' }}
        closeTitle="cancel"
        handleBack={() => {
          if (isDuplicate && steps === 3) {
            setSteps((prev) => prev - 2)
          } else if (isRemove && steps === 3) {
            setSteps((prev) => prev - 2)
          } else {
            setSteps((prev) => prev - 1)
          }
        }}
        handleClose={() => {
          if (steps > 0) {
            setIsCancel(true)
            handleClose()
          } else {
            handleClose()
            setSelected([])
            setCheckedValue([])
            setSteps(0)
          }
        }}
        handleResume={handleRadioSubmit}
        isBackButton={steps > 1 || (isDuplicate && steps > 0)}
        isOpen={isOpen}
        isSearch={isDuplicate && steps < 1}
        resumeTitle={steps === 3 ? 'bulk_upload_data_confirm' : 'bulk_upload_data_continue'}
        searchValue={filterData.SearchText}
        subtitle={createSubtitle(steps).subtitle}
        title={createSubtitle(steps).title}
        onSearch={onSearch}
      >
        {(() => {
          switch (steps) {
            case 0:
              return (
                isDuplicate ? (
                  <OPREnhancedTable
                    cols={entitySelectColumn(handleClick)}
                    data={JSON.parse(JSON.stringify(userAdmin?.data || []))}
                    handleClick={handleClick}
                    handleUserClick={handleUserClick}
                    isDuplicate={isDuplicate}
                    isSelected={isSelected}
                    orderBy={filterData?.orderByAsc}
                    sortBy={filterData?.sortBy}
                    steps={steps}
                  />
                ) : (
                  <OPRRadioGroup handleChange={handleChange} options={options} />)
              )
            case 1:
              return (
                <>
                  {/* <OPRSearchIcon placeholder="Search for existing entities" value={filterData.SearchText} onChange={onSearch} /> */}
                  {isDuplicate && (
                    <Box sx={{
                      display: 'flex',
                      flexDirection: 'row',
                      gap: '5px',
                      alignItems: 'center',
                      padding: '10px 10px',
                      justifyContent: 'space-between',
                    }}
                    >
                      <Box sx={{
                        display: 'flex', flexDirection: 'column', alignItems: 'flex-start',
                      }}
                      >
                        <OPRLabel CustomStyles={{ marginBottom: '15px' }} variant="body2">Duplicate from</OPRLabel>
                        <OPRLabel CustomStyles={{ marginBottom: '15px' }} variant="body2">{`${user?.firstName} ${user?.lastName}`}</OPRLabel>
                      </Box>
                      <Box sx={{
                        display: 'flex', flexDirection: 'column', alignItems: 'flex-start',
                      }}
                      >
                        <OPRLabel CustomStyles={{ marginBottom: '15px' }} variant="body2">Duplicate To</OPRLabel>
                        <OPRLabel CustomStyles={{ marginBottom: '15px' }} variant="body2">{`${duplicateItem?.firstName} ${duplicateItem?.lastName}`}</OPRLabel>
                      </Box>
                    </Box>
                  )}
                  <OPREnhancedTable
                    cols={isDuplicate || isRemove ? uerRoleSelectColumn(handleClick) : entitySelectColumn(handleClick)}
                    data={isDuplicate || isRemove ? JSON.parse(JSON.stringify(UserAdminEntityData?.data || [])) : JSON.parse(JSON.stringify(allPosts?.records || []))}
                    handleClick={handleClick}
                    isDuplicate={isDuplicate || isRemove}
                    isSelected={isSelected}
                    orderBy={filterData?.orderByAsc}
                    sortBy={filterData?.sortBy}
                    steps={steps}
                  />
                </>
              )
            case 2:
              return (
                <OPREnhancedTable
                  cols={uerRoleSelectColumn(handleClick)}
                  data={checkedValue}
                  handleClick={handleClick}
                  isSelected={isSelected}
                  listOfOptions={userRoleData.data}
                  orderBy={filterData?.orderByAsc}
                  sortBy={filterData?.sortBy}
                  steps={steps}
                />
              )
            case 3:
              return (
                <>
                  {isDuplicate ? (
                    <>
                      <Box sx={{
                        display: 'flex',
                        flexDirection: 'row',
                        gap: '5px',
                        alignItems: 'center',
                        padding: '10px 10px',
                        justifyContent: 'space-between',
                      }}
                      >
                        <Box sx={{
                          display: 'flex', flexDirection: 'column', alignItems: 'flex-start',
                        }}
                        >
                          <OPRLabel CustomStyles={{ marginBottom: '15px' }} variant="body2">Duplicate from</OPRLabel>
                          <OPRLabel CustomStyles={{ marginBottom: '15px' }} variant="body2">{`${user?.firstName} ${user?.lastName}`}</OPRLabel>
                        </Box>
                        <Box sx={{
                          display: 'flex', flexDirection: 'column', alignItems: 'flex-start',
                        }}
                        >
                          <OPRLabel CustomStyles={{ marginBottom: '15px' }} variant="body2">Duplicate To</OPRLabel>
                          <OPRLabel CustomStyles={{ marginBottom: '15px' }} variant="body2">{`${duplicateItem?.firstName} ${duplicateItem?.lastName}`}</OPRLabel>
                        </Box>
                      </Box>
                      <Box sx={{
                        display: 'flex', flexDirection: 'column', alignItems: 'flex-start', padding: '0px 10px',
                      }}
                      >
                        <OPRLabel CustomStyles={{ marginBottom: '15px' }} variant="body2">User ID</OPRLabel>
                        <OPRLabel CustomStyles={{ marginBottom: '15px' }} variant="body2">{duplicateItem?.emailAddress}</OPRLabel>
                      </Box>
                    </>
                  ) : (
                    <Box sx={{
                      display: 'flex',
                      flexDirection: 'row',
                      gap: '5px',
                      alignItems: 'center',
                      padding: '10px 0',
                      justifyContent: 'space-around',
                    }}
                    >
                      <Box sx={{
                        display: 'flex', flexDirection: 'column', alignItems: 'flex-start',
                      }}
                      >
                        <OPRLabel CustomStyles={{ marginBottom: '15px' }} variant="body2">Name</OPRLabel>
                        <OPRLabel CustomStyles={{ marginBottom: '15px' }} variant="body2">{`${user?.firstName} ${user?.lastName}`}</OPRLabel>
                      </Box>
                      <Box sx={{
                        display: 'flex', flexDirection: 'column', alignItems: 'flex-start',
                      }}
                      >
                        <OPRLabel CustomStyles={{ marginBottom: '15px' }} variant="body2">User ID</OPRLabel>
                        <OPRLabel CustomStyles={{ marginBottom: '15px' }} variant="body2">{user.emailAddress}</OPRLabel>
                      </Box>
                    </Box>
                  )}
                  <OPRLabel CustomStyles={{ marginLeft: '15px', marginBottom: '15px' }} variant="body2">
                    Entities
                    (
                    {checkedValue.length}
                    )
                  </OPRLabel>
                  <Divider />
                  <OPREnhancedTable
                    cols={uerRoleSelectColumn(handleClick)}
                    data={checkedValue}
                    handleClick={handleClick}
                    isDuplicate={isDuplicate || isRemove}
                    isSelected={isSelected}
                    orderBy={filterData?.orderByAsc}
                    sortBy={filterData?.sortBy}
                    steps={steps}
                  />
                </>
              )
            default:
              console.log('No Cases mmatched , Please Close')
              return null // return null when no other cases match
          }
        })()}
      </CustomDialog>
    </>
  )
}
