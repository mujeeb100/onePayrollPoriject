export function Demo() {
  return (
    <div
      className="Content"
      style={{
        width: 1175, height: 834, paddingLeft: 64, paddingRight: 64, paddingTop: 56, paddingBottom: 56, background: 'white', justifyContent: 'flex-start', alignItems: 'flex-start', gap: 24, display: 'inline-flex',
      }}
    >
      <div
        className="MainBody"
        style={{
          flex: '1 1 0', alignSelf: 'stretch', flexDirection: 'column', justifyContent: 'flex-start', alignItems: 'flex-start', gap: 48, display: 'inline-flex',
        }}
      >
        <div
          className="MainTitle"
          style={{
            width: 1047, justifyContent: 'flex-start', alignItems: 'flex-start', gap: 64, display: 'inline-flex',
          }}
        >
          <div
            className="Frame449"
            style={{
              flex: '1 1 0', height: 40, justifyContent: 'flex-start', alignItems: 'flex-start', gap: 20, display: 'flex',
            }}
          >
            <div
              className="Frame449"
              style={{
                flex: '1 1 0', flexDirection: 'column', justifyContent: 'flex-start', alignItems: 'flex-start', gap: 4, display: 'inline-flex',
              }}
            >
              <div
                className="PageTitle"
                style={{
                  alignSelf: 'stretch', color: '#3B3839', fontSize: 32, fontFamily: 'Lato', fontWeight: '700', lineHeight: 40, wordWrap: 'break-word',
                }}
              >
                0 user accounts
              </div>
            </div>
          </div>
          <div
            className="ButtonContainer"
            style={{
              paddingTop: 5, paddingBottom: 5, justifyContent: 'flex-start', alignItems: 'flex-start', gap: 8, display: 'flex',
            }}
          >
            <div
              className="Button"
              style={{
                borderRadius: 110, overflow: 'hidden', border: '1px #7D7B7C solid', justifyContent: 'center', alignItems: 'center', gap: 8, display: 'flex',
              }}
            >
              <div
                className="ButtonsContent"
                style={{
                  paddingLeft: 12, paddingRight: 12, paddingTop: 4, paddingBottom: 4, justifyContent: 'flex-start', alignItems: 'center', gap: 8, display: 'flex',
                }}
              >
                <div className="Export" style={{ width: 14, height: 14, position: 'relative' }}>
                  {/* <img
                    className="IconFill"
                    src="https://via.placeholder.com/10x11"
                    style={{
                      width: 10.38, height: 10.50, left: 1.69, top: 12.19, position: 'absolute', transform: 'rotate(-90deg)', transformOrigin: '0 0',
                    }}
                  /> */}
                </div>
                <div
                  className="Button"
                  style={{
                    color: '#7D7B7C', fontSize: 14, fontFamily: 'Lato', fontWeight: '700', lineHeight: 22, wordWrap: 'break-word',
                  }}
                >
                  Export
                </div>
              </div>
            </div>
            <div
              className="Button"
              style={{
                borderRadius: 110, overflow: 'hidden', border: '1px #7D7B7C solid', justifyContent: 'center', alignItems: 'center', gap: 8, display: 'flex',
              }}
            >
              <div
                className="ButtonsContent"
                style={{
                  paddingLeft: 12, paddingRight: 12, paddingTop: 4, paddingBottom: 4, background: '#7D7B7C', justifyContent: 'flex-start', alignItems: 'center', gap: 8, display: 'flex',
                }}
              >
                <div className="Plus" style={{ width: 14, height: 14, position: 'relative' }}>
                  <div
                    className="IconFill"
                    style={{
                      width: 10.50, height: 10.50, left: 1.75, top: 1.75, position: 'absolute', background: 'white',
                    }}
                  />
                </div>
                <div
                  className="Button"
                  style={{
                    color: 'white', fontSize: 14, fontFamily: 'Lato', fontWeight: '700', lineHeight: 22, wordWrap: 'break-word',
                  }}
                >
                  Add user account
                </div>
              </div>
            </div>
          </div>
        </div>
        <div
          className="TableGroup"
          style={{
            alignSelf: 'stretch', height: 307, flexDirection: 'column', justifyContent: 'flex-start', alignItems: 'flex-start', gap: 16, display: 'flex',
          }}
        >
          <div
            className="Row"
            style={{
              alignSelf: 'stretch', justifyContent: 'space-between', alignItems: 'flex-start', display: 'inline-flex',
            }}
          >
            <div
              className="Left"
              style={{
                flex: '1 1 0', height: 40, justifyContent: 'flex-start', alignItems: 'flex-start', gap: 8, display: 'flex',
              }}
            >
              <div
                className="Selector"
                style={{
                  padding: 1, justifyContent: 'flex-start', alignItems: 'flex-start', display: 'flex',
                }}
              >
                <div
                  className="Filter"
                  style={{
                    paddingLeft: 12, paddingRight: 12, paddingTop: 8, paddingBottom: 8, background: '#F7F5F6', borderRadius: 5, border: '1px #F7F5F6 solid', justifyContent: 'flex-start', alignItems: 'center', gap: 24, display: 'flex',
                  }}
                >
                  <div
                    className="ListTitle"
                    style={{
                      color: '#3B3839', fontSize: 14, fontFamily: 'Lato', fontWeight: '400', lineHeight: 22, wordWrap: 'break-word',
                    }}
                  >
                    User type
                  </div>
                  <div
                    className="Frame398"
                    style={{
                      justifyContent: 'flex-end', alignItems: 'center', gap: 8, display: 'flex',
                    }}
                  >
                    <div className="Down" style={{ width: 16, height: 16, position: 'relative' }}>
                      <div
                        className="IconFill"
                        style={{
                          width: 12, height: 7, left: 2, top: 12, position: 'absolute', background: '#3B3839',
                        }}
                      />
                    </div>
                  </div>
                </div>
              </div>
              <div
                className="Selector"
                style={{
                  padding: 1, justifyContent: 'flex-start', alignItems: 'flex-start', display: 'flex',
                }}
              >
                <div
                  className="Filter"
                  style={{
                    paddingLeft: 12, paddingRight: 12, paddingTop: 8, paddingBottom: 8, background: '#F7F5F6', borderRadius: 5, border: '1px #F7F5F6 solid', justifyContent: 'flex-start', alignItems: 'center', gap: 24, display: 'flex',
                  }}
                >
                  <div
                    className="ListTitle"
                    style={{
                      color: '#3B3839', fontSize: 14, fontFamily: 'Lato', fontWeight: '400', lineHeight: 22, wordWrap: 'break-word',
                    }}
                  >
                    Status
                  </div>
                  <div
                    className="Frame398"
                    style={{
                      justifyContent: 'flex-end', alignItems: 'center', gap: 8, display: 'flex',
                    }}
                  >
                    <div className="Down" style={{ width: 16, height: 16, position: 'relative' }}>
                      <div
                        className="IconFill"
                        style={{
                          width: 12, height: 7, left: 2, top: 12, position: 'absolute', background: '#3B3839',
                        }}
                      />
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div
              className="Right"
              style={{
                flex: '1 1 0', height: 40, justifyContent: 'flex-start', alignItems: 'flex-start', gap: 10, display: 'flex',
              }}
            >
              <div
                className="SearchInput"
                style={{
                  flex: '1 1 0', flexDirection: 'column', justifyContent: 'flex-start', alignItems: 'flex-start', gap: 4, display: 'inline-flex',
                }}
              >
                <div
                  className="AtomSearchInputField"
                  style={{
                    alignSelf: 'stretch', paddingTop: 4, paddingBottom: 4, paddingLeft: 16, paddingRight: 8, background: 'white', borderRadius: 8, border: '1px #666364 solid', justifyContent: 'flex-start', alignItems: 'center', gap: 8, display: 'inline-flex',
                  }}
                >
                  <div
                    className="Frame497"
                    style={{
                      flex: '1 1 0', height: 24, justifyContent: 'flex-start', alignItems: 'center', gap: 8, display: 'flex',
                    }}
                  >
                    <div className="Search" style={{ width: 16, height: 16, position: 'relative' }}>
                      {/* <img
                        className="IconFill"
                        src="https://via.placeholder.com/12x12"
                        style={{
                          width: 12, height: 12, left: 2, top: 2, position: 'absolute',
                        }}
                      /> */}
                    </div>
                    <div
                      className="Entry"
                      style={{
                        flex: '1 1 0', color: '#7D7B7C', fontSize: 16, fontFamily: 'Lato', fontWeight: '400', lineHeight: 24, wordWrap: 'break-word',
                      }}
                    >
                      Type a name or user ID to filter list below
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div
            className="StandardTable"
            style={{
              alignSelf: 'stretch', height: 251, flexDirection: 'column', justifyContent: 'flex-start', alignItems: 'flex-start', display: 'flex',
            }}
          >
            <div
              className="TableRowStandardDesktop"
              style={{
                alignSelf: 'stretch', height: 51, flexDirection: 'column', justifyContent: 'flex-start', alignItems: 'flex-start', display: 'flex',
              }}
            >
              <div className="Line2px" style={{ alignSelf: 'stretch', height: 2, background: '#E8E6E7' }} />
              <div
                className="Cells"
                style={{
                  alignSelf: 'stretch', justifyContent: 'flex-start', alignItems: 'flex-start', gap: 16, display: 'inline-flex',
                }}
              >
                <div
                  className="AtomCellTitle"
                  style={{
                    flex: '1 1 0', height: 48, paddingTop: 8, paddingBottom: 8, justifyContent: 'flex-start', alignItems: 'center', display: 'flex',
                  }}
                >
                  <div
                    className="Frame456"
                    style={{
                      padding: 8, justifyContent: 'flex-start', alignItems: 'center', gap: 8, display: 'flex',
                    }}
                  >
                    <div
                      className="GroupName"
                      style={{
                        color: '#3B3839', fontSize: 12, fontFamily: 'Lato', fontWeight: '700', lineHeight: 16, wordWrap: 'break-word',
                      }}
                    >
                      Name | User ID
                    </div>
                  </div>
                </div>
                <div
                  className="Frame1071"
                  style={{
                    flex: '1 1 0', height: 48, justifyContent: 'flex-start', alignItems: 'flex-start', gap: 16, display: 'flex',
                  }}
                >
                  <div
                    className="AtomCellTitle"
                    style={{
                      flex: '1 1 0', height: 48, paddingTop: 8, paddingBottom: 8, justifyContent: 'flex-start', alignItems: 'center', display: 'flex',
                    }}
                  >
                    <div
                      className="Frame456"
                      style={{
                        padding: 8, justifyContent: 'flex-start', alignItems: 'center', gap: 8, display: 'flex',
                      }}
                    >
                      <div
                        className="GroupName"
                        style={{
                          color: '#3B3839', fontSize: 12, fontFamily: 'Lato', fontWeight: '700', lineHeight: 16, wordWrap: 'break-word',
                        }}
                      >
                        User type
                      </div>
                    </div>
                  </div>
                  <div
                    className="AtomCellTitle"
                    style={{
                      flex: '1 1 0', height: 48, paddingTop: 8, paddingBottom: 8, justifyContent: 'flex-start', alignItems: 'center', display: 'flex',
                    }}
                  >
                    <div
                      className="Frame456"
                      style={{
                        padding: 8, justifyContent: 'flex-start', alignItems: 'center', gap: 8, display: 'flex',
                      }}
                    >
                      <div
                        className="GroupName"
                        style={{
                          color: '#3B3839', fontSize: 12, fontFamily: 'Lato', fontWeight: '700', lineHeight: 16, wordWrap: 'break-word',
                        }}
                      >
                        Entites
                      </div>
                    </div>
                  </div>
                </div>
                <div
                  className="CellGroup22"
                  style={{
                    flex: '1 1 0', height: 48, justifyContent: 'flex-start', alignItems: 'flex-start', gap: 16, display: 'flex',
                  }}
                >
                  <div
                    className="AtomCellTitle"
                    style={{
                      flex: '1 1 0', height: 48, paddingTop: 8, paddingBottom: 8, justifyContent: 'flex-start', alignItems: 'center', display: 'flex',
                    }}
                  >
                    <div
                      className="Frame456"
                      style={{
                        padding: 8, justifyContent: 'flex-start', alignItems: 'center', gap: 8, display: 'flex',
                      }}
                    >
                      <div
                        className="GroupName"
                        style={{
                          color: '#3B3839', fontSize: 12, fontFamily: 'Lato', fontWeight: '700', lineHeight: 16, wordWrap: 'break-word',
                        }}
                      >
                        Status
                      </div>
                    </div>
                  </div>
                  <div
                    className="AtomCellTitle"
                    style={{
                      flex: '1 1 0', height: 48, paddingTop: 8, paddingBottom: 8, justifyContent: 'flex-start', alignItems: 'center', display: 'flex',
                    }}
                  >
                    <div
                      className="Frame456"
                      style={{
                        padding: 8, justifyContent: 'flex-start', alignItems: 'center', gap: 8, display: 'flex',
                      }}
                    >
                      <div
                        className="GroupName"
                        style={{
                          color: '#3B3839', fontSize: 12, fontFamily: 'Lato', fontWeight: '700', lineHeight: 16, wordWrap: 'break-word',
                        }}
                      />
                    </div>
                  </div>
                </div>
              </div>
              <div className="Line1px" style={{ alignSelf: 'stretch', height: 1, background: '#E8E6E7' }} />
            </div>
            <div
              className="TableRowOtherStates"
              style={{
                alignSelf: 'stretch', height: 200, flexDirection: 'column', justifyContent: 'center', alignItems: 'center', display: 'flex',
              }}
            >
              <div
                className="Frame1066"
                style={{
                  alignSelf: 'stretch', height: 200, justifyContent: 'center', alignItems: 'center', gap: 4, display: 'inline-flex',
                }}
              >
                <div
                  className="Frame1079"
                  style={{
                    justifyContent: 'center', alignItems: 'flex-start', gap: 16, display: 'flex',
                  }}
                >
                  <div className="People2" style={{ width: 24, height: 24, position: 'relative' }}>
                    <div
                      className="IconFill"
                      style={{
                        width: 24, height: 15.53, left: 0, top: 4.24, position: 'absolute', background: '#D4D2D3',
                      }}
                    />
                  </div>
                  <div
                    className="Frame1078"
                    style={{
                      flexDirection: 'column', justifyContent: 'flex-start', alignItems: 'flex-start', display: 'inline-flex',
                    }}
                  >
                    <div
                      className="BodyTextHere"
                      style={{
                        color: '#666364', fontSize: 14, fontFamily: 'Lato', fontWeight: '400', lineHeight: 22, wordWrap: 'break-word',
                      }}
                    >
                      No user account
                    </div>
                    <div
                      className="TextLink"
                      style={{
                        borderRadius: 110, justifyContent: 'flex-start', alignItems: 'flex-start', display: 'inline-flex',
                      }}
                    >
                      <div
                        className="TextLink"
                        style={{
                          color: '#0049DB', fontSize: 14, fontFamily: 'Lato', fontWeight: '700', lineHeight: 22, wordWrap: 'break-word',
                        }}
                      >
                        Add user account?
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div className="Line1px" style={{ width: 1047, height: 1, background: '#E8E6E7' }} />
            </div>
          </div>
        </div>
        <div
          className="Pagination"
          style={{
            alignSelf: 'stretch', height: 32, flexDirection: 'column', justifyContent: 'flex-start', alignItems: 'center', gap: 10, display: 'flex',
          }}
        >
          <div
            className="Pagination"
            style={{
              justifyContent: 'flex-start', alignItems: 'flex-start', gap: 4, display: 'inline-flex',
            }}
          >
            <div
              className="Directional"
              style={{
                padding: 8, borderRadius: 4, justifyContent: 'center', alignItems: 'center', display: 'flex',
              }}
            >
              <div className="DoubleLeft" style={{ width: 16, height: 16, position: 'relative' }}>
                <div
                  className="IconFill"
                  style={{
                    width: 12, height: 12, left: 2, top: 2, position: 'absolute', background: '#D4D2D3',
                  }}
                />
              </div>
            </div>
            <div
              className="Directional"
              style={{
                padding: 8, borderRadius: 4, justifyContent: 'center', alignItems: 'center', display: 'flex',
              }}
            >
              <div className="Left" style={{ width: 16, height: 16, position: 'relative' }}>
                <div
                  className="IconFill"
                  style={{
                    width: 12, height: 7, left: 3.50, top: 2.50, position: 'absolute', transform: 'rotate(90deg)', transformOrigin: '0 0', background: '#D4D2D3',
                  }}
                />
              </div>
            </div>
            <div
              className="AtomBox"
              style={{
                paddingLeft: 8, paddingRight: 8, paddingTop: 5, paddingBottom: 5, borderRadius: 5, overflow: 'hidden', justifyContent: 'center', alignItems: 'center', gap: 8, display: 'flex',
              }}
            >
              <div style={{
                color: '#3B3839', fontSize: 14, fontFamily: 'Lato', fontWeight: '400', lineHeight: 22, wordWrap: 'break-word',
              }}
              >
                1
              </div>
            </div>
            <div
              className="AtomBox"
              style={{
                paddingLeft: 8, paddingRight: 8, paddingTop: 5, paddingBottom: 5, borderRadius: 5, overflow: 'hidden', justifyContent: 'center', alignItems: 'center', gap: 8, display: 'flex',
              }}
            >
              <div style={{
                color: '#3B3839', fontSize: 14, fontFamily: 'Lato', fontWeight: '400', lineHeight: 22, wordWrap: 'break-word',
              }}
              >
                of
              </div>
            </div>
            <div
              className="AtomBox"
              style={{
                paddingLeft: 8, paddingRight: 8, paddingTop: 5, paddingBottom: 5, borderRadius: 5, overflow: 'hidden', justifyContent: 'center', alignItems: 'center', gap: 8, display: 'flex',
              }}
            >
              <div style={{
                color: '#3B3839', fontSize: 14, fontFamily: 'Lato', fontWeight: '400', lineHeight: 22, wordWrap: 'break-word',
              }}
              >
                1
              </div>
            </div>
            <div
              className="Directional"
              style={{
                padding: 8, borderRadius: 4, justifyContent: 'center', alignItems: 'center', display: 'flex',
              }}
            >
              <div className="Right" style={{ width: 16, height: 16, position: 'relative' }}>
                <div
                  className="IconFill"
                  style={{
                    width: 12, height: 7, left: 12.50, top: 2.50, position: 'absolute', transform: 'rotate(90deg)', transformOrigin: '0 0', background: '#D4D2D3',
                  }}
                />
              </div>
            </div>
            <div
              className="Directional"
              style={{
                padding: 8, borderRadius: 4, justifyContent: 'center', alignItems: 'center', display: 'flex',
              }}
            >
              <div className="DoubleRight" style={{ width: 16, height: 16, position: 'relative' }}>
                <div
                  className="IconFill"
                  style={{
                    width: 12, height: 12, left: 2, top: 2, position: 'absolute', background: '#D4D2D3',
                  }}
                />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
