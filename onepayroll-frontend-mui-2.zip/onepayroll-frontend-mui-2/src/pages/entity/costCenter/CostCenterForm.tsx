import { Box, Grid } from '@mui/material'
import {
  useCostCenterCreateMutation,
  useCostCenterUpdateMutation,
  useLazyGetCostCenterByIdQuery,
} from 'api/entityServices'
import OPRInputControl from 'components/molecules/OPRInputControl'
import OPRResponsiveGrid from 'components/molecules/OPRResponsiveGrid'
import OPRTextArea from 'components/molecules/OPRTextArea/OPRTextArea'
import OPRAlertControl from 'components/organism/OPRAlertControl'
import { OPRInnerFormLayout } from 'components/organism/OPRInnerFormLayout'
import {
  validationSchemaCostCenter,
} from 'constants/validate'
import { useEditable } from 'hooks/useEdit'
import useForm from 'hooks/useForm'
import { t } from 'i18next'
import { useEffect } from 'react'
import { useLocation, useNavigate } from 'react-router-dom'
import { routes } from 'routes/routes'
import { getParamsValue } from 'utils'

interface MessageProps {
  text?: string;
  important?: boolean;
}

export default function CostCenterForm() {
  const location: any = useLocation()
  // const id = getParamsValue(location, routes.createCostCenter)
  const { id, viewUrl } = getParamsValue(location, routes.createCostCenter)
  // const [mode, setMode] = useState('view') // Default mode is edit
  const { isEditable, setEditable } = useEditable()

  const {
    values,
    setValues,
    errors,
    handleChange,
    setErrors,
    handleFormSubmit,
  } = useForm(validationSchemaCostCenter)

  const navigate = useNavigate()
  const [
    createCostCenter,
    {
      data: createdCostCenterData,
      error: createdCostCenterError,
      isLoading: createdCostCenterLoading,
      isSuccess: createdCostCenterSuccess,
      isError: createdCostCenterIsError,
    },
  ] = useCostCenterCreateMutation()

  // console.log(createdCostCenterData, 'createdCostCenterData')

  const [
    updateCostCenter,
    {
      data: updatedDataResponse,
      error: updatedCostCenterError,
      isLoading: updatedCostCenterLoading,
      isSuccess: updatedCostCenterSuccess,
      isError: updatedCostCenterIsError,
    },
  ] = useCostCenterUpdateMutation()

  const [
    updateCostCenterById,
    {
      data: updatedCostCenterByIdResponse,
      error: updatedCostCenterByIdError,
      isLoading: updatedCostCenterByIdLoading,
      isSuccess: updatedCostCenterByIdSuccess,
      isError: updatedCostCenterByIdIsError,
    },
  ] = useLazyGetCostCenterByIdQuery()

  useEffect(() => {
    if (id) {
      updateCostCenterById(id)
      setEditable(viewUrl)
      // setMode('view') // Set mode to view if id is present
    }
  }, [])
  console.log('aaa', updatedCostCenterByIdResponse?.data)

  useEffect(() => {
    if (id) {
      setValues(updatedCostCenterByIdResponse?.data)
    } else {
      setValues(location.state ? location.state : {})
    }
  }, [updatedCostCenterByIdResponse?.data])

  // reset the values
  // useEffect(() => {
  //   if (createdCostCenterSuccess) {
  //     setValues({})
  //     setErrors({})
  //   }
  // }, [createdCostCenterSuccess])

  const handleSubmit: any = async () => {
    if (isEditable) {
      if (id === null) {
        await createCostCenter({
          costCenterCode: values?.costCenterCode,
          costCenterDescription: values?.costCenterDescription,
          remarks: values?.remarks || '',
        })
      } else {
        await updateCostCenter({
          id: values?.id,
          costCenterCode: values?.costCenterCode,
          costCenterDescription: values?.costCenterDescription,
          remarks: values?.remarks || '',
        })
      }
    } else {
      setEditable(true)
    }
  }

  async function editCostCenter() {
    await updateCostCenter({
      id: values?.id,
      costCenterCode: values?.costCenterCode,
      costCenterDescription: values?.costCenterDescription,
      remarks: values?.remarks || '',
    })
  }

  const onScreenClose:any = (item: any) => {
    setEditable(item)
    setValues({})
  }

  // console.log(values?.costCenterDescription, 'costcenter')
  return (
    <Box sx={{ display: 'flex' }}>
      <form
        style={{ display: 'flex', width: '100% ' }}
        onSubmit={(e) => handleFormSubmit(e, handleSubmit)}
      >
        <OPRAlertControl
          callBack={(type) => {
          // if (type === 'success') {
          //   navigate(-1)
          // }
          }}
          error={createdCostCenterError || updatedCostCenterError}
          handleEditable={setEditable}
          handleSetValue={setValues}
          handleSubmit={handleSubmit}
          isError={createdCostCenterError || updatedCostCenterError}
          isLoading={
            createdCostCenterLoading
            || updatedCostCenterLoading
            || updatedCostCenterByIdLoading
          }
          isSuccess={updatedCostCenterSuccess || createdCostCenterSuccess}
          name={values?.costCenterDescription}
          title={t('costCenter')}
          type={id ? 'Update' : 'New'}
        />

        <OPRInnerFormLayout
          error={createdCostCenterError || updatedCostCenterError}
          handleCancelClick={() => navigate(-1)}
          handleContinueClick={handleSubmit}
          handleEditable={() => {
            setEditable(true)
          }}
          isBackButton={isEditable}
          isLoading={
            createdCostCenterLoading
            || updatedCostCenterLoading
            || updatedCostCenterByIdLoading
          }
          pageType="detailsPage"
          subtitle={
            isEditable
              ? 'Please check the user details below.'
              : 'All fields are mandatory except those marked optional'
          }
          title={(viewUrl) ? values?.costCenterDescription : false || ((id) ? values?.costCenterDescription : t('addCostCenter'))} // Set title based on mode
          onScreenClose={onScreenClose}
        >
          <Box>
            <OPRResponsiveGrid>
              <Grid item md={2} sm={1} xs={1}>
                <OPRInputControl
                  disabled={!!id}
                  error={t(errors?.costCenterCode)}
                  isEditable={isEditable}
                  label="cost_Center_Code"
                  name="costCenterCode"
                  value={values?.costCenterCode}
                  onChange={handleChange}
                />
              </Grid>
              <Grid item md={2} sm={1} xs={1}>
                <OPRInputControl
                  error={t(errors?.costCenterDescription)}
                  isEditable={isEditable}
                  label="cost_Center_Description"
                  name="costCenterDescription"
                  value={values?.costCenterDescription}
                  onChange={handleChange}
                />
              </Grid>
              <Grid item md={4} sm={6} xs={12}>
                <OPRTextArea
                  error={t(errors?.remarks)}
                  isEditable={isEditable}
                  label="remarks"
                  name="remarks"
                  optionalText="optional"
                  value={values?.remarks}
                  onChange={handleChange}
                />
              </Grid>
            </OPRResponsiveGrid>

          </Box>
        </OPRInnerFormLayout>
      </form>
    </Box>
  )
}
