import 'styles/style.css'

import { Box, Grid } from '@mui/material'
import {
  useLazyGetServiceProviderByIdQuery,
  useServiceProviderCreateMutation,
  useServiceProviderUpdateMutation,
} from 'api/entityServices'
import { useGetAllCountryQuery, useGetAllProviderTypeQuery } from 'api/globalServices'
import OPRInputControl from 'components/molecules/OPRInputControl'
import OPRResponsiveGrid from 'components/molecules/OPRResponsiveGrid'
import OPRSelectorControl from 'components/molecules/OPRSelectorControl/OPRSelectorControl'
import OPRAlertControl from 'components/organism/OPRAlertControl'
import { OPRInnerFormLayout } from 'components/organism/OPRInnerFormLayout'
import {
  validationSchemaServiceProvider,
} from 'constants/validate'
import { useEditable } from 'hooks/useEdit'
import useForm from 'hooks/useForm'
import { t } from 'i18next'
import { useEffect, useState } from 'react'
import { useLocation, useNavigate } from 'react-router-dom'
import { routes } from 'routes/routes'
import { generateFilterUrl, getParamsValue } from 'utils'

interface MessageProps {
  text?: string;
  important?: boolean;
}

export default function ServiceProviderForm() {
  const location: any = useLocation()
  const [selectedProviderType, setSelectedProviderType] = useState('')
  // const id = getParamsValue(location, routes.createServiceProvider)
  const { id, viewUrl } = getParamsValue(location, routes.createServiceProvider)
  const [filterData, setFilterData]:any = useState({
    pageNumber: 1,
    pageSize: 1000,
    totalItems: 0,
    orderByAsc: true,
    sortBy: '',
    SearchText: '',
  })
  const { isEditable, setEditable } = useEditable()

  const {
    values,
    setValues,
    errors,
    handleChange,
    setErrors,
    handleOnChange,
    handleFormSubmit,
  } = useForm(validationSchemaServiceProvider)

  // provider type slice
  const {
    data: allProvideTypeData,
  } = useGetAllProviderTypeQuery(generateFilterUrl({ pageNumber: 1, pageSize: 1000 }))

  //   country slice
  const {
    data: allData,

  } = useGetAllCountryQuery(generateFilterUrl(filterData))

  const navigate = useNavigate()
  const [
    createServiceProvider,
    {
      data: createdServiceProviderData,
      error: createdServiceProviderError,
      isLoading: createdServiceProviderLoading,
      isSuccess: createdServiceProviderSuccess,
      isError: createdServiceProviderIsError,
    },
  ] = useServiceProviderCreateMutation()

  const [
    updateServiceProvider,
    {
      data: updatedDataResponse,
      error: updatedServiceProviderError,
      isLoading: updatedServiceProviderLoading,
      isSuccess: updatedServiceProviderSuccess,
      isError: updatedServiceProviderIsError,
    },
  ] = useServiceProviderUpdateMutation()

  const [
    updateServiceProviderById,
    {
      data: updatedServiceProviderByIdResponse,
      error: updatedServiceProviderByIdError,
      isLoading: updatedServiceProviderByIdLoading,
      isSuccess: updatedServiceProviderByIdSuccess,
      isError: updatedServiceProviderByIdIsError,
    },
  ] = useLazyGetServiceProviderByIdQuery()

  // useEffect(() => {
  //   if (values.providerCode === 'Inland Revenue') {
  //     setValues({ ...values, employerRegistrationFileNo: '' })
  //   }
  // }, [values.providerCode])

  useEffect(() => {
    if (id) {
      updateServiceProviderById(id)
      setEditable(viewUrl)
    }
  }, [])
  useEffect(() => {
    if (id) {
      setValues(updatedServiceProviderByIdResponse?.data)
    } else {
      setValues(location.state ? location.state : {})
    }
  }, [updatedServiceProviderByIdResponse?.data])
  // reset the values
  // useEffect(() => {
  //   if (createdServiceProviderSuccess) {
  //     setValues({})
  //   }
  // }, [createdServiceProviderSuccess])

  const handleSubmit: any = async () => {
    if (isEditable) {
      if (id === null) {
        await createServiceProvider({
          providerCode: values.providerCode || '',
          providerName: values.providerName || '',
          providerContactPerson: values.providerContactPerson || '',
          providerPhoneNo: values.providerPhoneNo || '',
          providerFaxNo: values.providerFaxNo || '',
          providerEmailAddress: values.providerEmailAddress || '',
          providerAddressLine1: values.providerAddressLine1 || '',
          providerAddressLine2: values.providerAddressLine2 || '',
          providerAddressLine3: values.providerAddressLine3 || '',
          providerAddressCountry: values.providerAddressCountry,
          employerName: values.employerName || '',
          employerRegistrationFileNo: values.employerRegistrationFileNo || '',
          employerPICName: values.employerPICName || '',
          officeFaxNo: values.officeFaxNo || '',
          officePhoneNo: values.officePhoneNo || '',
          employerPICDesignation: values.employerPICDesignation || '',
          employerPICSignatureRemarks: values.employerPICSignatureRemarks || '',
        })
      } else {
        await updateServiceProvider({
          id: values.id,
          providerCode: values.providerCode || '',
          providerName: values.providerName || '',
          providerContactPerson: values.providerContactPerson || '',
          providerPhoneNo: values.providerPhoneNo || '',
          providerFaxNo: values.providerFaxNo || '',
          providerEmailAddress: values.providerEmailAddress || '',
          providerAddressLine1: values.providerAddressLine1 || '',
          providerAddressLine2: values.providerAddressLine2 || '',
          providerAddressLine3: values.providerAddressLine3 || '',
          providerAddressCountry: values.providerAddressCountry,
          employerName: values.employerName || '',
          employerRegistrationFileNo: values.employerRegistrationFileNo || '',
          employerPICName: values.employerPICName || '',
          officeFaxNo: values.officeFaxNo || '',
          officePhoneNo: values.officePhoneNo || '',
          employerPICDesignation: values.employerPICDesignation || '',
          employerPICSignatureRemarks: values.employerPICSignatureRemarks || '',
        })
      }
    } else {
      setEditable(true)
    }
  }

  async function editServiceProvider() {
    await updateServiceProvider({
      id: values.id,
      providerCode: values.providerCode || '',
      providerName: values.providerName || '',
      providerContactPerson: values.providerContactPerson || '',
      providerPhoneNo: values.providerPhoneNo || '',
      providerFaxNo: values.providerFaxNo || '',
      providerEmailAddress: values.providerEmailAddress || '',
      providerAddressLine1: values.providerAddressLine1 || '',
      providerAddressLine2: values.providerAddressLine2 || '',
      providerAddressLine3: values.providerAddressLine3 || '',
      providerAddressCountry: values.providerAddressCountry || '',
      employerName: values.employerName || '',
      employerRegistrationFileNo: values.employerRegistrationFileNo || '',
      employerPICName: values.employerPICName || '',
      officeFaxNo: values.officeFaxNo || '',
      officePhoneNo: values.officePhoneNo || '',
      employerPICDesignation: values.employerPICDesignation || '',
      employerPICSignatureRemarks: values.employerPICSignatureRemarks || '',
    })
  }

  const onScreenClose:any = (item: any) => {
    setEditable(item)
    setValues({})
  }

  // const renderValue = (value:any) => (value === 0 ? '0' : value || '-')

  return (
    <Box sx={{ display: 'flex' }}>
      <form
        style={{ display: 'flex', width: '100% ' }}
        onSubmit={(e) => handleFormSubmit(e, handleSubmit)}
      >
        <OPRAlertControl
          error={createdServiceProviderError || updatedServiceProviderError}
          handleEditable={setEditable}
          handleSetValue={setValues}
          handleSubmit={handleSubmit}
          isError={createdServiceProviderError || updatedServiceProviderIsError}
          isLoading={
            createdServiceProviderLoading
            || updatedServiceProviderLoading
            || updatedServiceProviderByIdLoading
          }
          isSuccess={updatedServiceProviderSuccess || createdServiceProviderSuccess}
          name={values?.providerName}
          title={t('Service_Provider_Sub_Menu')}
          type={id ? 'Update' : 'New'}
        />

        <OPRInnerFormLayout
          error={createdServiceProviderError || updatedServiceProviderError}
          handleCancelClick={() => navigate(-1)}
          handleContinueClick={handleSubmit}
          handleEditable={() => {
            setEditable(true)
          }}
          isBackButton={isEditable}
          isLoading={
            createdServiceProviderLoading
            || updatedServiceProviderLoading
            || updatedServiceProviderByIdLoading
          }
          pageType="detailsPage"
          subtitle={
            isEditable
              ? 'Please check the user details below.'
              : 'All fields are mandatory except those marked optional'
          }
          // title={t('Add Service Provider')}
          title={(viewUrl) ? values?.providerName : false || ((id) ? values?.providerName : t('Add Service Provider'))} // Set title based on mode
          onScreenClose={onScreenClose}

        >
          <Box>
            <OPRResponsiveGrid>
              <Grid item xs={12}>
                <div className="ServiceProvider">
                  General information
                </div>
              </Grid>

              <Grid item md={2} sm={1} xs={1}>

                <OPRSelectorControl
                  error={errors?.providerCode}
                  isEditable={isEditable}
                  keyName="providerCode"
                  label="Provider_type"
                  multiple={false}
                  name="providerCode"
                  options={(allProvideTypeData?.records || [])}
                  placeholder="Select an option"
                  value={
                    { providerType: values?.providerCode, providerCode: values?.providerCode }
                  }
                  // value={(allProvideTypeData?.records || []).find((o:any) => o.providerType === values?.providerCode)}
                  valueKey="providerCode"
                  onChange={(text: any) => {
                    // setSelectedProviderType(text?.providerType)
                    setValues((prev:any) => ({ ...prev, providerCode: text?.providerCode, providerName: text?.providerName }))
                    // handleOnChange('providerCode', text?.providerType)
                    // handleOnChange('providerName', text?.providerType)
                  }}

                />

              </Grid>

              <Grid item md={2} sm={1} xs={1}>
                <OPRInputControl
                  error={t(errors?.providerName)}
                  isEditable={isEditable}
                  label="Service provider name"
                  name="providerName"
                  value={values?.providerName}
                  onChange={handleChange}
                />
              </Grid>

              <Grid item xs={12}>
                <div
                  className="ServiceProvider"
                >
                  Service provider information
                </div>
              </Grid>

              <br />
              <Grid item md={2} sm={1} xs={1}>

                <OPRInputControl
                  error={t(errors?.providerContactPerson)}
                  isEditable={isEditable}
                  label="Contact person"
                  name="providerContactPerson"
                  optionalText="Optional"
                  value={values?.providerContactPerson}
                  onChange={handleChange}
                />
              </Grid>

              <Grid item md={2} sm={1} xs={1}>
                <OPRInputControl
                  error={t(errors?.providerPhoneNo)}
                  isEditable={isEditable}
                  label="Phone number"
                  name="providerPhoneNo"
                  optionalText="Optional"
                  value={values?.providerPhoneNo}
                  onChange={handleChange}
                />
              </Grid>
              <Grid item md={2} sm={1} xs={1}>
                <OPRInputControl
                  error={t(errors?.providerFaxNo)}
                  isEditable={isEditable}
                  label="Fax number"
                  name="providerFaxNo"
                  optionalText="Optional"
                  value={values?.providerFaxNo}
                  onChange={handleChange}
                />
              </Grid>
              <Grid item md={2} sm={1} xs={1}>
                <OPRInputControl
                  error={t(errors?.providerEmailAddress)}
                  isEditable={isEditable}
                  label="Provider_Email_Address"
                  name="providerEmailAddress"
                  optionalText="Optional"
                  value={values?.providerEmailAddress}
                  onChange={handleChange}
                />
              </Grid>
              <Grid item md={2} sm={1} xs={1}>
                <OPRInputControl
                  error={t(errors?.providerAddressLine1)}
                  isEditable={isEditable}
                  label="Address line 1"
                  name="providerAddressLine1"
                  optionalText="Optional"
                  value={values?.providerAddressLine1}
                  onChange={handleChange}
                />
              </Grid>
              <Grid item md={2} sm={1} xs={1}>
                <OPRInputControl
                  error={t(errors?.providerAddressLine2)}
                  isEditable={isEditable}
                  label="Address line 2"
                  name="providerAddressLine2"
                  optionalText="Optional"
                  value={values?.providerAddressLine2}
                  onChange={handleChange}
                />
              </Grid>
              <Grid item md={2} sm={1} xs={1}>
                <OPRInputControl
                  error={t(errors?.providerAddressLine3)}
                  isEditable={isEditable}
                  label="Address line 3"
                  name="providerAddressLine3"
                  optionalText="Optional"
                  value={values?.providerAddressLine3}
                  onChange={handleChange}
                />
              </Grid>
              <Grid item md={2} sm={1} xs={1}>

                <OPRSelectorControl
                  isEditable={isEditable}
                  keyName="countryName"
                  label="Provider_Address_Country"
                  multiple={false}
                  name="providerAddressCountry"
                  optionalText="optional"
                  options={(allData?.records || [])}
                  placeholder="Select an option"
                  value={(allData?.records || []).find((o:any) => o.countryName === values?.providerAddressCountry)}
                  valueKey="countryName"
                  onChange={(text:any) => {
                    // handleChange({ target: { name: 'countryLocalization', value: text?.countryCode }, persist: () => {} })
                    // setValues({ ...values, providerAddressCountry: text?.countryCode })
                    handleOnChange('providerAddressCountry', text?.countryName)
                  }}
                />
              </Grid>
              <Grid item xs={12}>
                <div className="ServiceProvider">
                  Employer’s information
                </div>
              </Grid>

              <Grid item md={2} sm={1} xs={1}>
                <OPRInputControl
                  error={t(errors?.employerName)}
                  isEditable={isEditable}
                  label="Employer_name"
                  name="employerName"
                  value={values?.employerName}
                  onChange={handleChange}
                />
              </Grid>
              {values?.providerCode === 'IRD' && (
                <Grid item md={2} sm={1} xs={1}>
                  <OPRInputControl
                    error={t(errors?.employerRegistrationFileNo)}
                    isEditable={isEditable}
                    label="Employers_Registeration"
                    name="employerRegistrationFileNo"
                    value={values?.employerRegistrationFileNo}
                    onChange={handleChange}
                  />
                </Grid>
              )}
              <Grid item xs={12}>
                <div className="ServiceProvider">
                  Employer’s person-in-charge
                </div>
              </Grid>

              <Grid item md={2} sm={1} xs={1}>
                <OPRInputControl
                  error={t(errors?.employerPICName)}
                  isEditable={isEditable}
                  label="Employers_PIC_Name"
                  name="employerPICName"
                  optionalText="Optional"
                  value={values?.employerPICName}
                  onChange={handleChange}
                />
              </Grid>
              <Grid item md={2} sm={1} xs={1}>
                <OPRInputControl
                  error={t(errors?.officeFaxNo)}
                  isEditable={isEditable}
                  label="service_provider_office_fax_no"
                  name="officeFaxNo"
                  optionalText="Optional"
                  value={values?.officeFaxNo}
                  onChange={handleChange}
                />
              </Grid>
              <Grid item md={2} sm={1} xs={1}>
                <OPRInputControl
                  error={t(errors?.officePhoneNo)}
                  isEditable={isEditable}
                  label="service_provider_office_phone_no"
                  name="officePhoneNo"
                  optionalText="Optional"
                  value={values?.officePhoneNo}
                  onChange={handleChange}
                />
              </Grid>
              <Grid item md={2} sm={1} xs={1}>
                <OPRInputControl
                  error={t(errors?.employerPICDesignation)}
                  isEditable={isEditable}
                  label="Employers_PIC_Designation"
                  name="employerPICDesignation"
                  optionalText="Optional"
                  value={values?.employerPICDesignation}
                  onChange={handleChange}
                />
              </Grid>
              <Grid item md={2} sm={1} xs={1}>
                <OPRInputControl
                  error={t(errors?.employerPICSignatureRemarks)}
                  isEditable={isEditable}
                  label="Employers_PIC_Signature_Remarks"
                  name="employerPICSignatureRemarks"
                  optionalText="optional"
                  value={values?.employerPICSignatureRemarks}
                  onChange={handleChange}
                />
              </Grid>

            </OPRResponsiveGrid>
          </Box>
        </OPRInnerFormLayout>
      </form>
    </Box>
  )
}
