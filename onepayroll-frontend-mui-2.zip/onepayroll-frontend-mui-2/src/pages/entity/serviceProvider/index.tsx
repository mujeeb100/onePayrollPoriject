import {
  Box,
} from '@mui/material'
import { useGetAllServiceProviderQuery, useServiceProviderDeleteMutation } from 'api/entityServices'
import { entityServiceProviderColumn } from 'components/atoms/table/OPRTableConstant'
import { OPRInnerListLayout } from 'components/organism/OPRInnerLayoutList'
import apiEndPoint from 'constants/apiEndPoint'
import { ServiceProviderColumnMappings } from 'constants/exportColumnMappings'
// import { ServiceProviderColumnMappings } from 'constants/exportColumnMappings'
import { useTranslatedColumnsForPDF } from 'hooks/useTranslatedColumnsForPDF'
import { t } from 'i18next'
import React, { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { routes } from 'routes/routes'
import { TProviderType } from 'types'
import {
  generateFilterUrl, getAPIWithEntityUrl, getEnv, setRouteValues,
} from 'utils'

function ServiceProviderList() {
  const navigate: any = useNavigate()
  const [selectedOptions, setSelectedOptions] = useState<any>([])
  const [listOfOptions, setListOfOptions] = useState<TProviderType[]>([])
  const [selelctedDelete, setSelelctedDelete]:any = useState({
    data: {},
    isDelete: false,
    name: '',
  })
  const [filterData, setFilterData]:any = useState({
    pageNumber: 1,
    pageSize: 20,
    totalItems: 0,
    orderByAsc: true,
    sortBy: '',
    SearchText: '',
  })
  const {
    data: allPosts,
    isLoading: isLoadingAllPosts,
    isSuccess: isSuccessAllPosts,
    isError: isErrorAllPosts,
    error: errorAllPosts,
    refetch: refetchAllPosts,
  } = useGetAllServiceProviderQuery(generateFilterUrl(filterData))

  const [deleteServiceProviderById,
    {
      data: deleteServiceProviderResponse,
      error: deleteServiceProviderError,
      isLoading: deleteServiceProviderLoading,
      isSuccess: deleteServiceProviderSuccess,
      isError: deleteServiceProviderIsError,
    }] = useServiceProviderDeleteMutation()

  const sorting = (
    event: React.MouseEvent<unknown>,
    property: keyof any,
  ) => {
    const isAsc = filterData.sortBy === property && filterData.orderByAsc === true
    setFilterData({ ...filterData, orderByAsc: !isAsc, sortBy: property })
  }

  useEffect(() => {
    setFilterData({ ...filterData, totalItems: allPosts?.totalItems ? allPosts?.totalItems : 0 })
  }, [allPosts?.pageNumber, filterData.sortBy, filterData.orderByAsc, allPosts?.totalItems])

  const onSearch = (e: any, data: any) => {
    setFilterData({ ...filterData, ...data })
  }
  const handlePagination = (pageNumber: number, pageSize: number) => {
    setFilterData({ ...filterData, pageNumber })
  }

  const viewAcoount = (data: any, type:string) => {
    if (type === 'Edit Service Provider') {
      navigate(
        setRouteValues(`${routes.editServiceProvider}`, {
          id: data.id,
        }),
      )
    } else if (type === 'Delete Service Provider') {
      // deleteServiceProviderById(`Id=${data.id}`)
      setSelelctedDelete({ data, isDelete: true, name: data.providerName })
    } else {
      navigate(
        setRouteValues(`${routes.viewServiceProvider}`, {
          id: data.id,
        }),
      )
    }
  }
  const handleView = (data: any) => {
    // const ensureDefaultValues = (obj: any) => ({
    //   ...obj,
    //   providerContactPerson: obj.providerContactPerson || '',
    //   providerPhoneNo: obj.providerPhoneNo || '',
    //   providerFaxNo: obj.providerFaxNo || '',
    //   providerEmailAddress: obj.providerEmailAddress || '',
    //   providerAddressLine1: obj.providerAddressLine1 || '',
    //   providerAddressLine2: obj.providerAddressLine2 || '',
    //   providerAddressLine3: obj.providerAddressLine3 || '',
    //   providerAddressCountry: obj.providerAddressCountry || '',
    //   employerName: obj.employerName || '',
    //   employerRegistrationFileNo: obj.employerRegistrationFileNo || '',
    //   employerPICName: obj.employerPICName || '',
    //   officeFaxNo: obj.officeFaxNo || '',
    //   officePhoneNo: obj.officePhoneNo || '',
    //   employerPICDesignation: obj.employerPICDesignation || '',
    //   employerPICSignatureRemarks: obj.employerPICSignatureRemarks || '',
    // })

    navigate(
      setRouteValues(`${routes.viewServiceProvider}`, {
        id: data.id,
        view: true,
      }),
    )
  }
  // handle Delete
  const handleDelete = (data:any) => {
    deleteServiceProviderById(`Id=${data.id}`)
  }
  return (
    <Box sx={{ display: 'flex' }}>
      <OPRInnerListLayout
        isExport
        Search={decodeURIComponent(filterData.SearchText)}
        addHandleClick={() => navigate(routes.createServiceProvider)}
        columns={entityServiceProviderColumn(viewAcoount)}
        dataList={JSON.parse(JSON.stringify(allPosts?.records || []))}
        deleteCallBack={handleDelete}
        error={errorAllPosts || deleteServiceProviderError}
        exportProps={{
          data: allPosts?.records,
          fileName: 'ServiceProvider',
          columns: useTranslatedColumnsForPDF(ServiceProviderColumnMappings),
          pdf: {
            orientation: 'landscape',
          },
          allRecords: {
            baseURL: getEnv('REACT_APP_UP_BASE_URL', null),
            endpoint: getAPIWithEntityUrl(apiEndPoint.serviceProviderList),
            filterData,
          },
        }}
        filterData={filterData}
        handlePagination={handlePagination}
        handleSearch={onSearch}
        isError={isErrorAllPosts || deleteServiceProviderIsError}
        loading={isLoadingAllPosts || deleteServiceProviderLoading}
        rowClickHandler={handleView}
        rowNumber={0}
        selelctedUser={selelctedDelete}
        setSelelctedUser={setSelelctedDelete}
        sortHandleClick={sorting}
        success={deleteServiceProviderSuccess}
        title={t('Service_Provider_Sub_Menu')}
      />
    </Box>
  )
}

export default ServiceProviderList
