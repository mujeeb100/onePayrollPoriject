import {
  Box,
} from '@mui/material'
import { useCurrencyExchangeDeleteMutation, useGetAllCurrencyExchangeQuery } from 'api/entityServices'
import { entityCurrencyExchangeColumn } from 'components/atoms/table/OPRTableConstant'
import { OPRInnerListLayout } from 'components/organism/OPRInnerLayoutList'
import apiEndPoint from 'constants/apiEndPoint'
import { currencyExchangeColumnMappings } from 'constants/exportColumnMappings'
import { useTranslatedColumnsForPDF } from 'hooks/useTranslatedColumnsForPDF'
import { t } from 'i18next'
import React, { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { routes } from 'routes/routes'
import {
  generateFilterUrl, getAPIWithEntityUrl, getEnv, setRouteValues,
} from 'utils'

function CurrencyExchangeList() {
  const navigate: any = useNavigate()
  const [selelctedDelete, setSelelctedDelete]:any = useState({
    data: {},
    isDelete: false,
    name: '',
  })
  const [filterData, setFilterData]:any = useState({
    pageNumber: 1,
    pageSize: 20,
    totalItems: 0,
    orderByAsc: true,
    sortBy: '',
    SearchText: '',
  })
  const {
    data: allPosts,
    isLoading: isLoadingAllPosts,
    isSuccess: isSuccessAllPosts,
    isError: isErrorAllPosts,
    error: errorAllPosts,
    refetch: refetchAllPosts,
  } = useGetAllCurrencyExchangeQuery(generateFilterUrl(filterData))

  const [deleteCurrencyExchangeById,
    {
      data: deleteCurrencyExchangeResponse,
      error: deleteCurrencyExchangeError,
      isLoading: deleteCurrencyExchangeLoading,
      isSuccess: deleteCurrencyExchangeSuccess,
      isError: deleteCurrencyExchangeIsError,
    }] = useCurrencyExchangeDeleteMutation()

  const sorting = (
    event: React.MouseEvent<unknown>,
    property: keyof any,
  ) => {
    const isAsc = filterData.sortBy === property && filterData.orderByAsc === true
    setFilterData({ ...filterData, orderByAsc: !isAsc, sortBy: property })
  }

  useEffect(() => {
    setFilterData({ ...filterData, totalItems: allPosts?.totalItems ? allPosts?.totalItems : 0 })
  }, [allPosts?.pageNumber, filterData.sortBy, filterData.orderByAsc, allPosts?.totalItems])

  const onSearch = (e: any, data: any) => {
    setFilterData({ ...filterData, ...data })
  }
  const handlePagination = (pageNumber: number, pageSize: number) => {
    setFilterData({ ...filterData, pageNumber })
  }

  const viewAcoount = (data:any, type:any) => {
    // const currencyFrom = `${data.currencyFrom} - ${data.currencyFromName}`
    // const currencyTo = `${data.currencyTo} - ${data.currencyToName}`
    if (type === 'Edit currency exchange') {
      navigate(setRouteValues(routes.editCurrencyExchange, { id: data.id }))
    } else if (type === 'Delete currency exchange') {
      setSelelctedDelete({ data, isDelete: true, name: data.costCenterDescription })
    } else {
      navigate(setRouteValues(routes.viewCurrencyExchange, {
        id: data.id,
        // currencyFrom,
        // currencyTo,
      }))
    }
  }

  const handleView = (data:any) => {
    // const currencyFrom = `${data.currencyFrom} - ${data.currencyFromName}`
    // const currencyTo = `${data.currencyTo} - ${data.currencyToName}`
    navigate(setRouteValues(routes.viewCurrencyExchange, {
      id: data.id,
      // currencyFrom,
      // currencyTo,
      view: true,
    }))
  }

  const handleDelete = (data:any) => {
    deleteCurrencyExchangeById(`Id=${data.id}`)
  }
  return (
    <Box sx={{ display: 'flex' }}>
      <OPRInnerListLayout
        isExport
        Search={decodeURIComponent(filterData.SearchText)}
        addHandleClick={() => navigate(routes.createCurrencyExchange)}
        columns={entityCurrencyExchangeColumn(viewAcoount)}
        dataList={JSON.parse(JSON.stringify(allPosts?.records || []))}
        deleteCallBack={handleDelete}
        error={errorAllPosts || deleteCurrencyExchangeError}
        exportProps={{
          data: allPosts?.records,
          fileName: 'CurrencyExchange',
          columns: useTranslatedColumnsForPDF(currencyExchangeColumnMappings),
          pdf: {
            orientation: 'landscape',
          },
          allRecords: {
            baseURL: getEnv('REACT_APP_UP_BASE_URL', null),
            endpoint: getAPIWithEntityUrl(apiEndPoint.currencyExchangeList),
            filterData,
          },
        }}
        filterData={filterData}
        handlePagination={handlePagination}
        handleSearch={onSearch}
        isError={isErrorAllPosts || deleteCurrencyExchangeIsError}
        loading={isLoadingAllPosts || deleteCurrencyExchangeLoading}
        rowClickHandler={handleView}
        rowNumber={0}
        selelctedUser={selelctedDelete}
        setSelelctedUser={setSelelctedDelete}
        sortHandleClick={sorting}
        success={deleteCurrencyExchangeSuccess}
        title={t('ent_curr_exch_title')}
      />
    </Box>
  )
}

export default CurrencyExchangeList
