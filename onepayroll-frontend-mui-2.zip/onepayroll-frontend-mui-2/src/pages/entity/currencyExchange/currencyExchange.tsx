import { Box, Grid } from '@mui/material'
import {
  useCurrencyExchangeCreateMutation,
  useCurrencyExchangeUpdateMutation,
  useLazyGetCurrencyExchangeByIdQuery,
} from 'api/entityServices'
import { useGetAllCurrencyQuery } from 'api/globalServices'
import OPRDatePickerControl from 'components/molecules/OPRDatePickerControl/OPRDatePickerControl'
import OPRInputControl from 'components/molecules/OPRInputControl'
import OPRResponsiveGrid from 'components/molecules/OPRResponsiveGrid'
import OPRSelectorControl from 'components/molecules/OPRSelectorControl/OPRSelectorControl'
import OPRAlertControl from 'components/organism/OPRAlertControl'
import { OPRInnerFormLayout } from 'components/organism/OPRInnerFormLayout'
import {
  validationSchemaCurrencyExchange,
} from 'constants/validate'
import { useEditable } from 'hooks/useEdit'
import useForm from 'hooks/useForm'
import { t } from 'i18next'
import { useEffect, useState } from 'react'
import { useLocation, useNavigate } from 'react-router-dom'
import { routes } from 'routes/routes'
import { formatedYearDate, generateFilterUrl, getParamsValue } from 'utils'

interface MessageProps {
  text?: string;
  important?: boolean;
}

export default function CurrencyExchangeForm() {
  const location: any = useLocation()
  const { currencyFrom, currencyTo } = location.state || {}
  // const id = getParamsValue(location, routes.createCurrencyExchange)
  const { id, viewUrl } = getParamsValue(location, routes.createCurrencyExchange)
  const [currencyToOptions, setCurrencyToOptions] = useState<any[]>([])
  const [formattedOptions, setFormattedOptions]:any = useState([])
  // const [formattedOptions, setFormattedOptions] = useState([])

  const { isEditable, setEditable } = useEditable()
  const [filterData, setFilterData]:any = useState({
    pageNumber: 1,
    pageSize: 1000,
    totalItems: 0,
    orderByAsc: true,
    sortBy: '',
    SearchText: '',
  })
  // countrylist
  const {
    data: allData,

  } = useGetAllCurrencyQuery(generateFilterUrl(filterData))

  const {
    values,
    setValues,
    errors,
    handleChange,
    setErrors,
    handleFormSubmit,
    handleOnChange,
  } = useForm(validationSchemaCurrencyExchange)
  const navigate = useNavigate()
  const [
    createCurrencyExchange,
    {
      data: createdCurrencyExchangeData,
      error: createdCurrencyExchangeError,
      isLoading: createdCurrencyExchangeLoading,
      isSuccess: createdCurrencyExchangeSuccess,
      isError: createdCurrencyExchangeIsError,
    },
  ] = useCurrencyExchangeCreateMutation()

  const [
    updateCurrencyExchange,
    {
      data: updatedDataResponse,
      error: updatedCurrencyExchangeError,
      isLoading: updatedCurrencyExchangeLoading,
      isSuccess: updatedCurrencyExchangeSuccess,
      isError: updatedCurrencyExchangeIsError,
    },
  ] = useCurrencyExchangeUpdateMutation()

  const [
    getCurrencyExchangeById,
    {
      data: updatedCurrencyExchangeByIdResponse,
      error: updatedCurrencyExchangeByIdError,
      isLoading: updatedCurrencyExchangeByIdLoading,
      isSuccess: updatedCurrencyExchangeByIdSuccess,
      isError: updatedCurrencyExchangeByIdIsError,
    },
  ] = useLazyGetCurrencyExchangeByIdQuery()
  useEffect(() => {
    // console.log(id, 'ididididididid')
    if (id) {
      getCurrencyExchangeById(id)
      setEditable(viewUrl)
    }
  }, [])
  // id, getCurrencyExchangeById, setEditable, viewUrl
  // console.log(viewUrl, 'viewUrlviewUrlviewUrlviewUrl')

  useEffect(() => {
    if (id) {
      setValues(updatedCurrencyExchangeByIdResponse?.data)
    } else {
      setValues(location.state ? location.state : {})
    }
  }, [id,
    updatedCurrencyExchangeByIdResponse,
    allData,
  ])

  // reset the values
  // useEffect(() => {
  //   setValues((prev: any) => ({
  //     ...prev,
  //     currencyFrom: '',
  //     currencyTo: '',
  //     exchangeRate: '',
  //     conversionMethod: '',
  //     effectiveDate: '',
  //   }))
  // }, [createdCurrencyExchangeSuccess])

  const handleSubmit = async () => {
    if (isEditable) {
      if (!id) {
        // Extract currency data from allData response
        const currencyFromData = allData?.records.find((currency:any) => currency.currencyCode === values?.currencyFrom)
        const currencyToData = allData?.records.find((currency:any) => currency.currencyCode === values?.currencyTo)

        if (currencyFromData && currencyToData) {
          await createCurrencyExchange({
            currencyFrom: currencyFromData.currencyCode,
            currencyFromName: currencyFromData.currencyName,
            currencyTo: currencyToData.currencyCode,
            currencyToName: currencyToData.currencyName,
            exchangeRate: values?.exchangeRate,
            conversionMethod: values?.conversionMethod,
            effectiveDate: formatedYearDate(values?.effectiveDate),
          })
        }
      } else {
        const data = {
          id: values?.id,
          currencyFrom: values?.currencyFrom,
          currencyFromName: values?.currencyFromName,
          currencyTo: values?.currencyTo,
          currencyToName: values?.currencyToName,
          exchangeRate: values?.exchangeRate,
          conversionMethod: values?.conversionMethod,
          effectiveDate: formatedYearDate(values?.effectiveDate),
        }
        await updateCurrencyExchange({
          ...data,
        })
      }
    } else {
      setEditable(true)
    }
  }

  async function editCurrencyExchange() {
    await updateCurrencyExchange({
      id: values?.id,
      currencyFrom: values?.currencyFrom,
      currencyTo: values?.currencyTo,
      exchangeRate: values?.exchangeRate,
      conversionMethod: values?.conversionMethod,
      effectiveDate: values?.effectiveDate,
    })
  }

  const onScreenClose:any = (item: any) => {
    setEditable(item)
    setValues({})
  }
  // useEffect(() => {
  //   if (allData) {
  //     const formattedOptions = allData.records.map((currency: any) => ({
  //       value: currency.currencyCode,
  //       label: `${currency.currencyName} (${currency.currencyCode})`,
  //     }))
  //     setCurrencyToOptions(formattedOptions)
  //   }
  // }, [allData])
  useEffect(() => {
    // Format the options by combining currency code and name
    const formatted = (allData?.records || []).map((option:any) => ({
      ...option,
      label: `${option.currencyCode} - ${option.currencyName}`,
    }))
    setFormattedOptions(formatted)
  }, [allData])

  // useEffect(() => {
  //   // Format the options for currencyFrom by combining currency code and name
  //   const formatted = (allData?.records || []).map((option:any) => ({
  //     ...option,
  //     label: option.currencyFromName,
  //     value: option.currencyFrom,
  //   }))
  //   setFormattedOptions(formatted)
  // }, [allData])

  return (
    <Box sx={{ display: 'flex' }}>
      <form
        style={{ display: 'flex', width: '100% ' }}
        onSubmit={(e) => handleFormSubmit(e, handleSubmit)}
      >
        <OPRAlertControl
          error={createdCurrencyExchangeError || updatedCurrencyExchangeError}
          handleEditable={setEditable}
          handleSetValue={setValues}
          handleSubmit={handleSubmit}
          isError={createdCurrencyExchangeError || updatedCurrencyExchangeIsError}
          isLoading={
            createdCurrencyExchangeLoading
            || updatedCurrencyExchangeLoading
            || updatedCurrencyExchangeByIdLoading
          }
          isSuccess={updatedCurrencyExchangeSuccess || createdCurrencyExchangeSuccess}
          name={id
            ? `${updatedDataResponse?.data?.currencyFromName}--> ${updatedDataResponse?.data?.currencyToName}`
            : `${createdCurrencyExchangeData?.data?.currencyFromName} ---> ${createdCurrencyExchangeData?.data?.currencyToName}`}
          // name={`${createdCurrencyExchangeData?.data?.currencyFromName} ---> ${createdCurrencyExchangeData?.data?.currencyToName}`}
          title={t('ent_curr_exch_title')}
          type={id ? 'Update' : 'New'}
        />

        <OPRInnerFormLayout
          error={createdCurrencyExchangeError || updatedCurrencyExchangeError}
          handleCancelClick={() => navigate(-1)}
          handleContinueClick={handleSubmit}
          handleEditable={() => {
            setEditable(true)
          }}
          isBackButton={isEditable}
          isLoading={
            createdCurrencyExchangeLoading
            || updatedCurrencyExchangeLoading
            || updatedCurrencyExchangeByIdLoading
          }
          pageType="detailsPage"
          subtitle={
            isEditable
              ? 'Please check the user details below.'
              : 'All fields are mandatory except those marked optional'
          }
          // title={t('ent_curr_exch_rate_add_btn_title')}
          title={(viewUrl && t('Currency Exchange')) || ((id) ? `${values?.currencyFrom} → ${values?.currencyTo}` : t('addCostCenter'))}
          onScreenClose={onScreenClose}

        >
          <Box>
            <OPRResponsiveGrid>
              <Grid item md={2} sm={1} xs={1}>
                <OPRSelectorControl
                  error={errors?.currencyFrom}
                  isEditable={isEditable}
                  keyName="label"
                  label="ent_curr_exch_currency_from"
                  multiple={false}
                  name="currencyFrom"
                  options={formattedOptions}
                  placeholder="Select an option"
                  value={formattedOptions.find((o:any) => o.currencyCode === values?.currencyFrom)}
                  valueKey="currencyCode"
                  onChange={(text:any) => handleOnChange('currencyFrom', text?.currencyCode)}
                />

              </Grid>
              <Grid item md={2} sm={1} xs={1}>
                <OPRSelectorControl
                  error={errors?.currencyTo}
                  isEditable={isEditable}
                  keyName="label"
                  label="ent_curr_exch_currency_to"
                  multiple={false}
                  name="currencyTo"
                  options={formattedOptions}
                  placeholder="Select an option"
                  value={formattedOptions.find((o:any) => o.currencyCode === values?.currencyTo)}
                  valueKey="currencyCode"
                  onChange={(text:any) => handleOnChange('currencyTo', text?.currencyCode)}
                />
                {/* <OPRSelectorControl
                  error={errors?.currencyTo}
                  isEditable={isEditable}
                  keyName="currencyName"
                  label="ent_curr_exch_currency_to"
                  multiple={false}
                  name="currencyTo"
                  options={(allData?.records || [])}
                  placeholder="Select an option"
                  value={(allData?.records || []).find((o:any) => o.currencyCode === values?.currencyTo)}
                  // value={
                  //   { currencyName: values?.currencyTo, currencyCode: values?.currencyTo }
                  // }
                  valueKey="currencyCode"
                  onChange={(text:any) => {
                    // handleChange({ target: { name: 'currencyTo', value: text?.currencyCode }, persist: () => {} })
                    // setValues({ ...values, currencyTo: text?.currencyCode })
                    handleOnChange('currencyTo', text?.currencyCode)
                  }}
                /> */}
              </Grid>
              <Grid item md={2} sm={1} xs={1}>
                <OPRSelectorControl
                  error={errors?.conversionMethod}
                  isEditable={isEditable}
                  keyName="name"
                  label={t('ent_curr_exch_conv_method')}
                  multiple={false}
                  name="conversionMethod"
                  options={[{ name: 'Multiply exchange rate', values: 'Multiply exchange rate' },
                    { name: 'Divide exchange rate', values: 'Divide exchange rate' }]}
                  placeholder="Select an option"
                  value={
                    { name: values?.conversionMethod, values: values?.conversionMethod }
                  }
                  valueKey="values"
                  onChange={(text:any) => {
                    // handleChange({ target: { name: 'countryLocalization', value: text?.countryCode }, persist: () => {} })
                    // setValues({ ...values, countryLocalization: text })
                    handleOnChange('conversionMethod', text?.values)
                  }}
                />
              </Grid>
              <Grid item md={2} sm={1} xs={1}>
                <OPRInputControl
                  error={t(errors?.exchangeRate)}
                  isEditable={isEditable}
                  label="Exchange rate"
                  name="exchangeRate"
                  //   type="number"
                  value={values?.exchangeRate}
                  onChange={handleChange}
                />
              </Grid>
              <Grid item md={2} sm={1} xs={1}>
                <OPRDatePickerControl
                  isRequired
                  error={errors?.effectiveDate}
                  isEditable={isEditable}
                  label={t('ent_curr_exch_currency_effective_dt')}
                  name="effectiveDate"
                  value={values?.effectiveDate || null}
                  // value={values?.effectiveDate ? values?.effectiveDate?.toISOString() : null}
                  onChange={(date) => {
                    handleOnChange('effectiveDate', date)
                  }}
                />
                {/* <OPRDatePickerControl
                  isRequired
                  error={errors?.effectiveDate}
                  isEditable={isEditable}
                  label={t('ent_curr_exch_currency_effective_dt')}
                  name="effectiveDate"
                  value={values?.effectiveDate ? values?.effectiveDate?.toLocaleDateString('en-GB', {
                    day: '2-digit',
                    month: 'long',
                    year: 'numeric',
                  }) : null}
                  // value={values?.effectiveDate ? values?.effectiveDate?.toISOString() : null}
                  onChange={(date) => {
                    handleOnChange('effectiveDate', new Date(date))
                  }}
                /> */}
              </Grid>

            </OPRResponsiveGrid>

          </Box>
        </OPRInnerFormLayout>
      </form>
    </Box>
  )
}
