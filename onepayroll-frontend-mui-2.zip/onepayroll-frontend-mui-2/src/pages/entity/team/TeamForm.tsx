import { Box, Grid } from '@mui/material'
import {
  useLazyGetTeamByIdQuery,
  useTeamCreateMutation,
  useTeamUpdateMutation,
} from 'api/entityServices/index'
import OPRInputControl from 'components/molecules/OPRInputControl'
import OPRResponsiveGrid from 'components/molecules/OPRResponsiveGrid'
import OPRTextArea from 'components/molecules/OPRTextArea/OPRTextArea'
import OPRAlertControl from 'components/organism/OPRAlertControl'
import { OPRInnerFormLayout } from 'components/organism/OPRInnerFormLayout'
import { validationSchemaTeam } from 'constants/validate'
import { useEditable } from 'hooks/useEdit'
import useForm from 'hooks/useForm'
import { t } from 'i18next'
import { useEffect } from 'react'
import { useLocation, useNavigate } from 'react-router-dom'
import { routes } from 'routes/routes'
import { getParamsValue } from 'utils'

interface MessageProps {
  text?: string;
  important?: boolean;
}

export default function TeamForm() {
  const location: any = useLocation()
  const { id, viewUrl } = getParamsValue(location, routes.createTeam)

  const { isEditable, setEditable } = useEditable()

  const {
    values,
    setValues,
    errors,
    handleChange,
    setErrors,
    handleFormSubmit,
  } = useForm(validationSchemaTeam)

  const navigate = useNavigate()
  const [
    createTeam,
    {
      data: createdTeamData,
      error: createdTeamError,
      isLoading: createdTeamLoading,
      isSuccess: createdTeamSuccess,
      isError: createdTeamIsError,
    },
  ] = useTeamCreateMutation()

  const [
    updateTeam,
    {
      data: updatedDataResponse,
      error: updatedTeamError,
      isLoading: updatedTeamLoading,
      isSuccess: updatedTeamSuccess,
      isError: updatedTeamIsError,
    },
  ] = useTeamUpdateMutation()

  const [
    updateTeamById,
    {
      data: updatedTeamByIdResponse,
      error: updatedTeamByIdError,
      isLoading: updatedTeamByIdLoading,
      isSuccess: updatedTeamByIdSuccess,
      isError: updatedTeamByIdIsError,
    },
  ] = useLazyGetTeamByIdQuery()
  useEffect(() => {
    if (id) {
      updateTeamById(id)
      setEditable(viewUrl)
    }
  }, [])
  useEffect(() => {
    if (id) {
      setValues(updatedTeamByIdResponse?.data)
    } else {
      setValues(location.state ? location.state : {})
    }
  }, [updatedTeamByIdResponse?.data])
  // reset the values

  const handleSubmit: any = async () => {
    if (isEditable) {
      if (id === null) {
        await createTeam({
          teamCode: values?.teamCode,
          teamDescription: values?.teamDescription,
          remarks: values?.remarks || '',
        })
      } else {
        await updateTeam({
          id: values.id,
          teamCode: values.teamCode,
          teamDescription: values.teamDescription,
          remarks: values?.remarks || '',
        })
      }
    } else {
      setEditable(true)
    }
  }

  async function editTeam() {
    await updateTeam({
      id: values.id,
      teamCode: values.teamCode,
      teamDescription: values.teamDescription,
      remarks: values?.remarks || '',
    })
  }

  const onScreenClose:any = (item: any) => {
    setEditable(item)
    setValues({})
  }

  return (
    <Box sx={{ display: 'flex' }}>
      <form
        style={{ display: 'flex', width: '100% ' }}
        onSubmit={(e) => handleFormSubmit(e, handleSubmit)}
      >
        <OPRAlertControl
          error={createdTeamError || updatedTeamError}
          handleEditable={setEditable}
          handleSetValue={setValues}
          handleSubmit={handleSubmit}
          isError={createdTeamError || updatedTeamIsError}
          isLoading={
            createdTeamLoading || updatedTeamLoading || updatedTeamByIdLoading
          }
          isSuccess={updatedTeamSuccess || createdTeamSuccess}
          name={values?.teamDescription}
          title={t('team')}
          type={id ? 'Update' : 'New'}
        />
        <OPRInnerFormLayout
          error={createdTeamError || updatedTeamError}
          handleCancelClick={() => navigate(-1)}
          handleContinueClick={handleSubmit}
          handleEditable={() => {
            setEditable(true)
          }}
          isBackButton={isEditable}
          isLoading={
            createdTeamLoading || updatedTeamLoading || updatedTeamByIdLoading
          }
          pageType="detailsPage"
          subtitle={
            isEditable
              ? 'Please check the user details below.'
              : 'All fields are mandatory except those marked optional'
          }
          // title={t('addTeam')}
          title={(viewUrl) ? values?.teamDescription : false || ((id) ? values?.teamDescription : t('addTeam'))} // Set title based on mode
          onScreenClose={onScreenClose}
        >
          <Box>
            <OPRResponsiveGrid>
              <Grid item md={2} sm={1} xs={1}>
                <OPRInputControl
                  disabled={!!id}
                  error={t(errors?.teamCode)}
                  isEditable={isEditable}
                  label="team_Code"
                  name="teamCode"
                  value={values?.teamCode}
                  onChange={handleChange}
                />
              </Grid>
              <Grid item md={2} sm={1} xs={1}>
                <OPRInputControl
                  error={t(errors?.teamDescription)}
                  isEditable={isEditable}
                  label="team_Description"
                  name="teamDescription"
                  value={values?.teamDescription}
                  onChange={handleChange}
                />
              </Grid>
              <Grid item md={4} sm={6} xs={12}>
                <OPRTextArea
                  error={t(errors?.remarks)}
                  isEditable={isEditable}
                  label="remarks"
                  name="remarks"
                  optionalText="optional"
                  value={values?.remarks}
                  onChange={handleChange}
                />
              </Grid>
            </OPRResponsiveGrid>
          </Box>
        </OPRInnerFormLayout>
      </form>
    </Box>
  )
}
