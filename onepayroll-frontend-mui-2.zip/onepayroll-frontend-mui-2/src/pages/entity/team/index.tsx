import {
  Box,
} from '@mui/material'
import { useGetAllTeamQuery, useTeamDeleteMutation } from 'api/entityServices'
import { entityTeamColumn } from 'components/atoms/table/OPRTableConstant'
import { OPRInnerListLayout } from 'components/organism/OPRInnerLayoutList'
import apiEndPoint from 'constants/apiEndPoint'
import { teamColumnMappings } from 'constants/exportColumnMappings'
import { useTranslatedColumnsForPDF } from 'hooks/useTranslatedColumnsForPDF'
import { t } from 'i18next'
import React, { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { routes } from 'routes/routes'
import {
  generateFilterUrl, getAPIWithEntityUrl, getEnv, setRouteValues,
} from 'utils'

function TeamList() {
  const navigate: any = useNavigate()
  const [selelctedDelete, setSelelctedDelete]:any = useState({
    data: {},
    isDelete: false,
    name: '',
  })
  const [filterData, setFilterData]:any = useState({
    pageNumber: 1,
    pageSize: 20,
    totalItems: 0,
    orderByAsc: true,
    sortBy: '',
    SearchText: '',
  })
  const {
    data: allPosts,
    isLoading: isLoadingAllPosts,
    isSuccess: isSuccessAllPosts,
    isError: isErrorAllPosts,
    error: errorAllPosts,
    refetch: refetchAllPosts,
  } = useGetAllTeamQuery(generateFilterUrl(filterData))

  const [deleteTeamById,
    {
      data: deleteTeamResponse,
      error: deleteTeamError,
      isLoading: deleteTeamLoading,
      isSuccess: deleteTeamSuccess,
      isError: deleteTeamIsError,
    }] = useTeamDeleteMutation()
  const sorting = (
    event: React.MouseEvent<unknown>,
    property: keyof any,
  ) => {
    const isAsc = filterData.sortBy === property && filterData.orderByAsc === true
    setFilterData({ ...filterData, orderByAsc: !isAsc, sortBy: property })
    // setOrder(isAsc ? 'desc' : 'asc')
    // setOrderBy(property)
  }

  useEffect(() => {
    setFilterData({ ...filterData, totalItems: allPosts?.totalItems ? allPosts?.totalItems : 0 })
  }, [allPosts?.pageNumber, filterData.sortBy, filterData.orderByAsc, allPosts?.totalItems])

  const onSearch = (e: any, data: any) => {
    setFilterData({ ...filterData, ...data })
  }
  const handlePagination = (pageNumber: number, pageSize: number) => {
    setFilterData({ ...filterData, pageNumber })
  }

  const viewAcoount = (data: any, type:string) => {
    if (type === 'Edit Team') {
      navigate(
        setRouteValues(`${routes.editTeam}`, {
          id: data.id,
        }),
      )
    } else if (type === 'Delete Team') {
      // deleteTeamById(`Id=${data.id}`)
      setSelelctedDelete({ data, isDelete: true, name: data.teamDescription })
    } else {
      navigate(
        setRouteValues(`${routes.viewTeam}`, {
          id: data.id,
        }),
      )
    }
    // const id = JSON.stringify(data)
  }

  const handleView = (data: any) => {
    navigate(
      setRouteValues(`${routes.viewTeam}`, {
        id: data.id,
        view: true,
      }),
    )
  }
  // handle Delete
  const handleDelete = (data:any) => {
    deleteTeamById(`Id=${data.id}`)
  }
  return (
    <Box sx={{ display: 'flex' }}>
      <OPRInnerListLayout
        isExport
        Search={decodeURIComponent(filterData.SearchText)}
        addHandleClick={() => navigate(routes.createTeam)}
        columns={entityTeamColumn(viewAcoount)}
        dataList={JSON.parse(JSON.stringify(allPosts?.records || []))}
        deleteCallBack={handleDelete}
        error={errorAllPosts || deleteTeamError}
        exportProps={{
          data: allPosts?.records,
          fileName: 'Team',
          columns: useTranslatedColumnsForPDF(teamColumnMappings),
          pdf: {
            orientation: 'portrait',
          },
          allRecords: {
            baseURL: getEnv('REACT_APP_UP_BASE_URL', null),
            endpoint: getAPIWithEntityUrl(apiEndPoint.teamList),
            filterData,
          },
        }}
        filterData={filterData}
        handlePagination={handlePagination}
        handleSearch={onSearch}
        isError={isErrorAllPosts || deleteTeamIsError}
        loading={isLoadingAllPosts || deleteTeamLoading}
        rowClickHandler={handleView}
        rowNumber={0}
        selelctedUser={selelctedDelete}
        setSelelctedUser={setSelelctedDelete}
        sortHandleClick={sorting}
        success={deleteTeamSuccess}
        title={t('team')}
      />
    </Box>
  )
}

export default TeamList
