import { Box, Grid } from '@mui/material'
import {
  useLazyGetSettingsByIdQuery,
  useSettingsCreateMutation,
  useSettingsUpdateMutation,
} from 'api/entityServices'
import OPRInputControl from 'components/molecules/OPRInputControl'
import OPRResponsiveGrid from 'components/molecules/OPRResponsiveGrid'
import OPRTextArea from 'components/molecules/OPRTextArea/OPRTextArea'
import OPRAlertControl from 'components/organism/OPRAlertControl'
import { OPRInnerFormLayout } from 'components/organism/OPRInnerFormLayout'
import {
  validationSchemaSettings,
} from 'constants/validate'
import { useEditable } from 'hooks/useEdit'
import useForm from 'hooks/useForm'
import { t } from 'i18next'
import { useEffect } from 'react'
import { useLocation, useNavigate } from 'react-router-dom'
import { routes } from 'routes/routes'
import { getParamsValue } from 'utils'

interface MessageProps {
  text?: string;
  important?: boolean;
}

export default function SettingsForm() {
  const location: any = useLocation()
  // const id = getParamsValue(location, routes.createSettings)
  const { id, viewUrl } = getParamsValue(location, routes.createSettings)

  const { isEditable, setEditable } = useEditable()

  const {
    values,
    setValues,
    errors,
    handleChange,
    setErrors,
    handleFormSubmit,
  } = useForm(validationSchemaSettings)

  const navigate = useNavigate()
  const [
    createSettings,
    {
      data: createdSettingsData,
      error: createdSettingsError,
      isLoading: createdSettingsLoading,
      isSuccess: createdSettingsSuccess,
      isError: createdSettingsIsError,
    },
  ] = useSettingsCreateMutation()

  const [
    updateSettings,
    {
      data: updatedDataResponse,
      error: updatedSettingsError,
      isLoading: updatedSettingsLoading,
      isSuccess: updatedSettingsSuccess,
      isError: updatedSettingsIsError,
    },
  ] = useSettingsUpdateMutation()

  const [
    updateSettingsById,
    {
      data: updatedSettingsByIdResponse,
      error: updatedSettingsByIdError,
      isLoading: updatedSettingsByIdLoading,
      isSuccess: updatedSettingsByIdSuccess,
      isError: updatedSettingsByIdIsError,
    },
  ] = useLazyGetSettingsByIdQuery()

  useEffect(() => {
    if (id) {
      updateSettingsById(id)
      setEditable(viewUrl)
    }
  }, [])
  useEffect(() => {
    if (id) {
      setValues(updatedSettingsByIdResponse?.data)
    } else {
      setValues(location.state ? location.state : {})
    }
  }, [updatedSettingsByIdResponse?.data])
  // reset the values
  // useEffect(() => {
  //   if (createdSettingsSuccess) {
  //     setValues({})
  //   }
  // }, [createdSettingsSuccess])

  const handleSubmit: any = async () => {
    if (isEditable) {
      if (id === null) {
        await createSettings({
          settingCode: values?.settingCode,
          settingName: values?.settingName,
          settingValue: values?.settingValue,
          category: values?.category,
          remarks: values?.remarks || '',
        })
      } else {
        await updateSettings({
          id: values?.id,
          settingCode: values?.settingCode,
          settingName: values?.settingName,
          settingValue: values?.settingValue,
          category: values?.category,
          remarks: values?.remarks || '',
        })
      }
    } else {
      setEditable(true)
    }
  }

  async function editSettings() {
    await updateSettings({
      id: values?.id,
      settingCode: values?.settingCode,
      settingName: values?.settingName,
      settingValue: values?.settingValue,
      category: values?.category,
      remarks: values?.remarks || '',
    })
  }

  const onScreenClose:any = (item: any) => {
    setEditable(item)
    setValues({})
  }

  return (
    <Box sx={{ display: 'flex' }}>
      <form
        style={{ display: 'flex', width: '100% ' }}
        onSubmit={(e) => handleFormSubmit(e, handleSubmit)}
      >
        <OPRAlertControl
          error={createdSettingsError || updatedSettingsError}
          handleEditable={setEditable}
          handleSetValue={setValues}
          handleSubmit={handleSubmit}
          isError={createdSettingsError || updatedSettingsIsError}
          isLoading={
            createdSettingsLoading
            || updatedSettingsLoading
            || updatedSettingsByIdLoading
          }
          isSuccess={updatedSettingsSuccess || createdSettingsSuccess}
          name={values?.settingName}
          title={t('Entity setting')}
          type={id ? 'Update' : 'New'}
        />

        <OPRInnerFormLayout
          error={createdSettingsError || updatedSettingsError}
          handleCancelClick={() => navigate(-1)}
          handleContinueClick={handleSubmit}
          handleEditable={() => {
            setEditable(true)
          }}
          isBackButton={isEditable}
          isLoading={
            createdSettingsLoading
            || updatedSettingsLoading
            || updatedSettingsByIdLoading
          }
          pageType="detailsPage"
          subtitle={
            isEditable
              ? 'Please check the user details below.'
              : 'All fields are mandatory except those marked optional'
          }
          title={(location.pathname === routes.createSettings) ? t('Add Entity setting') : values?.settingName}
          onScreenClose={onScreenClose}

        >
          <Box>
            <OPRResponsiveGrid>
              <Grid item md={2} sm={1} xs={1}>
                <OPRInputControl
                  disabled={!!id}
                  error={errors?.settingCode}
                  isEditable={isEditable}
                  // label={t('entity_setting_id')}
                  label={t('Entity setting ID')}
                  name="settingCode"
                  value={values?.settingCode}
                  onChange={handleChange}
                />
              </Grid>
              <Grid item md={2} sm={1} xs={1}>
                <OPRInputControl
                  error={errors?.settingName}
                  isEditable={isEditable}
                  label={t('Entity setting name')}
                  name="settingName"
                  value={values?.settingName}
                  onChange={handleChange}
                />
              </Grid>
              <Grid item md={2} sm={1} xs={1}>
                <OPRInputControl
                  error={errors?.category}
                  isEditable={isEditable}
                  label={t('Category')}
                  name="category"
                  value={values?.category}
                  onChange={handleChange}
                />
              </Grid>
              <Grid item md={2} sm={1} xs={1}>
                <OPRInputControl
                  error={errors?.settingValue}
                  isEditable={isEditable}
                  label={t('Setting value')}
                  name="settingValue"
                  value={values?.settingValue}
                  onChange={handleChange}
                />
              </Grid>
              <Grid item md={4} sm={6} xs={12}>
                <OPRTextArea
                  error={errors?.remarks}
                  isEditable={isEditable}
                  label={t('remarks')}
                  name="remarks"
                  optionalText="optional"
                  value={values?.remarks}
                  onChange={handleChange}
                />
              </Grid>

            </OPRResponsiveGrid>

          </Box>
        </OPRInnerFormLayout>
      </form>
    </Box>
  )
}
