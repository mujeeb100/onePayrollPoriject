import { Box, Grid } from '@mui/material'
import {
  useDepartmentCreateMutation,
  useDepartmentUpdateMutation,
  useLazyGetDepartmentByIdQuery,
} from 'api/entityServices'
import OPRInputControl from 'components/molecules/OPRInputControl'
import OPRResponsiveGrid from 'components/molecules/OPRResponsiveGrid'
import OPRTextArea from 'components/molecules/OPRTextArea/OPRTextArea'
import OPRAlertControl from 'components/organism/OPRAlertControl'
import { OPRInnerFormLayout } from 'components/organism/OPRInnerFormLayout'
import { validationSchemaDepartment } from 'constants/validate'
import { useEditable } from 'hooks/useEdit'
import useForm from 'hooks/useForm'
import { t } from 'i18next'
import { useEffect } from 'react'
import { useLocation, useNavigate } from 'react-router-dom'
import { routes } from 'routes/routes'
import { getParamsValue } from 'utils'

interface MessageProps {
  text?: string;
  important?: boolean;
}

export default function DepartmentForm() {
  const location: any = useLocation()
  const { id, viewUrl } = getParamsValue(location, routes.createDepartment)

  const { isEditable, setEditable } = useEditable()

  const {
    values,
    setValues,
    errors,
    handleChange,
    setErrors,
    handleFormSubmit,
  } = useForm(validationSchemaDepartment)

  const navigate = useNavigate()
  const [
    createDepartment,
    {
      data: createdDepartmentData,
      error: createdDepartmentError,
      isLoading: createdDepartmentLoading,
      isSuccess: createdDepartmentSuccess,
      isError: createdDepartmentIsError,
    },
  ] = useDepartmentCreateMutation()

  const [
    updateDepartment,
    {
      data: updatedDataResponse,
      error: updatedDepartmentError,
      isLoading: updatedDepartmentLoading,
      isSuccess: updatedDepartmentSuccess,
      isError: updatedDepartmentIsError,
    },
  ] = useDepartmentUpdateMutation()

  const [
    updateDepartmentById,
    {
      data: updatedDepartmentByIdResponse,
      error: updatedDepartmentByIdError,
      isLoading: updatedDepartmentByIdLoading,
      isSuccess: updatedDepartmentByIdSuccess,
      isError: updatedDepartmentByIdIsError,
    },
  ] = useLazyGetDepartmentByIdQuery()

  useEffect(() => {
    if (id) {
      updateDepartmentById(id)
      setEditable(viewUrl)
    }
  }, [])
  useEffect(() => {
    if (id) {
      setValues(updatedDepartmentByIdResponse?.data)
    } else {
      setValues(location.state ? location.state : {})
    }
  }, [updatedDepartmentByIdResponse?.data])

  // // reset the values
  // useEffect(() => {
  //   if (createdDepartmentSuccess) {
  //     setValues({})
  //   }
  // }, [createdDepartmentSuccess])

  const handleSubmit: any = async () => {
    if (isEditable) {
      if (id === null) {
        await createDepartment({
          departmentCode: values?.departmentCode,
          departmentDescription: values?.departmentDescription,
          remarks: values?.remarks || '',

        })
      } else {
        await updateDepartment({
          id: values?.id,
          departmentCode: values?.departmentCode,
          departmentDescription: values?.departmentDescription,
          remarks: values?.remarks || '',

        })
      }
    } else {
      setEditable(true)
    }
  }

  async function editDepartment() {
    await updateDepartment({
      id: values.id,
      departmentCode: values.departmentCode,
      departmentDescription: values.departmentDescription,
      remarks: values.remarks || '',
    })
  }

  const onScreenClose:any = (item: any) => {
    setEditable(item)
    setValues({})
  }

  return (
    <Box sx={{ display: 'flex' }}>
      <form
        style={{ display: 'flex', width: '100% ' }}
        onSubmit={(e) => handleFormSubmit(e, handleSubmit)}
      >
        <OPRAlertControl
          error={createdDepartmentError || updatedDepartmentError}
          handleEditable={setEditable}
          handleSetValue={setValues}
          handleSubmit={handleSubmit}
          isError={createdDepartmentError || updatedDepartmentIsError}
          isLoading={
            createdDepartmentLoading
            || updatedDepartmentLoading
            || updatedDepartmentByIdLoading
          }
          isSuccess={updatedDepartmentSuccess || createdDepartmentSuccess}
          name={values?.departmentDescription}
          title={t('ent_dept_title')}
          type={id ? 'Update' : 'New'}
        />
        <OPRInnerFormLayout
          error={createdDepartmentError || updatedDepartmentError}
          handleCancelClick={() => navigate(-1)}
          handleContinueClick={handleSubmit}
          handleEditable={() => {
            setEditable(true)
          }}
          isBackButton={isEditable}
          isLoading={
            createdDepartmentLoading
            || updatedDepartmentLoading
            || updatedDepartmentByIdLoading
          }
          pageType="detailsPage"
          subtitle={
            isEditable
              ? 'Please check the user details below.'
              : 'All fields are mandatory except those marked optional'
          }
          // title={t('ent_dept_add_btn_title')}
          title={(viewUrl) ? values?.departmentDescription : false || ((id) ? values?.departmentDescription : t('ent_dept_add_btn_title'))} // Set title based on mode
          onScreenClose={onScreenClose}
        >
          <Box>
            <OPRResponsiveGrid>
              <Grid item md={2} sm={1} xs={1}>
                <OPRInputControl
                  disabled={!!id}
                  error={t(errors?.departmentCode)}
                  isEditable={isEditable}
                  label="ent_dept_code"
                  name="departmentCode"
                  value={values?.departmentCode}
                  onChange={handleChange}
                />
              </Grid>
              <Grid item md={2} sm={1} xs={1}>
                <OPRInputControl
                  error={t(errors?.departmentDescription)}
                  isEditable={isEditable}
                  label="ent_dept_description"
                  name="departmentDescription"
                  value={values?.departmentDescription}
                  onChange={handleChange}
                />
              </Grid>
              <Grid item md={4} sm={6} xs={12}>
                <OPRTextArea
                  error={t(errors?.remarks)}
                  isEditable={isEditable}
                  label="remarks"
                  name="remarks"
                  optionalText="optional"
                  value={values?.remarks}
                  onChange={handleChange}
                />
              </Grid>
            </OPRResponsiveGrid>
          </Box>
        </OPRInnerFormLayout>
      </form>
    </Box>
  )
}

// export default DepartmentForm
