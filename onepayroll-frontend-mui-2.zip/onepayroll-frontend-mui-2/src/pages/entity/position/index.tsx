import {
  Box,
} from '@mui/material'
import { useGetAllPositionQuery, usePositionDeleteMutation } from 'api/entityServices'
import { entityPositionColumn } from 'components/atoms/table/OPRTableConstant'
import { OPRInnerListLayout } from 'components/organism/OPRInnerLayoutList'
import apiEndPoint from 'constants/apiEndPoint'
import { positionColumnMappings } from 'constants/exportColumnMappings'
import { useTranslatedColumnsForPDF } from 'hooks/useTranslatedColumnsForPDF'
import { t } from 'i18next'
import React, { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { routes } from 'routes/routes'
import {
  generateFilterUrl, getAPIWithEntityUrl, getEnv, setRouteValues,
} from 'utils'

function PositionList() {
  const navigate: any = useNavigate()
  const [selelctedDelete, setSelelctedDelete]:any = useState({
    data: {},
    isDelete: false,
    name: '',
  })
  const [filterData, setFilterData]:any = useState({
    pageNumber: 1,
    pageSize: 20,
    totalItems: 0,
    orderByAsc: true,
    sortBy: '',
    SearchText: '',
  })
  const {
    data: allPosts,
    isLoading: isLoadingAllPosts,
    isSuccess: isSuccessAllPosts,
    isError: isErrorAllPosts,
    error: errorAllPosts,
    refetch: refetchAllPosts,
  } = useGetAllPositionQuery(generateFilterUrl(filterData))

  const [deletePositionById,
    {
      data: deletePositionResponse,
      error: deletePositionError,
      isLoading: deletePositionLoading,
      isSuccess: deletePositionSuccess,
      isError: deletePositionIsError,
    }] = usePositionDeleteMutation()
  const sorting = (
    event: React.MouseEvent<unknown>,
    property: keyof any,
  ) => {
    const isAsc = filterData.sortBy === property && filterData.orderByAsc === true
    setFilterData({ ...filterData, orderByAsc: !isAsc, sortBy: property })
    // setOrder(isAsc ? 'desc' : 'asc')
    // setOrderBy(property)
  }

  useEffect(() => {
    setFilterData({ ...filterData, totalItems: allPosts?.totalItems ? allPosts?.totalItems : 0 })
  }, [allPosts?.pageNumber, filterData.sortBy, filterData.orderByAsc, allPosts?.totalItems])

  const onSearch = (e: any, data: any) => {
    setFilterData({ ...filterData, ...data })
  }

  const handlePagination = (pageNumber: number, pageSize: number) => {
    setFilterData({ ...filterData, pageNumber })
  }

  const viewAcoount = (data: any, type:string) => {
    if (type === 'Edit Position') {
      navigate(
        setRouteValues(`${routes.editPosition}`, {
          id: data.id,
        }),
      )
    } else if (type === 'Delete Position') {
      // deletePositionById(`Id=${data.id}`)
      setSelelctedDelete({ data, isDelete: true, name: data.positionCode })
    } else {
      navigate(
        setRouteValues(`${routes.viewPosition}`, {
          id: data.id,
        }),
      )
    }
  }

  const handleView = (data: any) => {
    navigate(
      setRouteValues(`${routes.viewPosition}`, {
        id: data.id,
        view: true,
      }),
    )
  }
  // handle Delete
  const handleDelete = (data:any) => {
    deletePositionById(`Id=${data.id}`)
  }
  return (
    <Box sx={{ display: 'flex' }}>
      <OPRInnerListLayout
        isExport
        Search={decodeURIComponent(filterData.SearchText)}
        addHandleClick={() => navigate(routes.createPosition)}
        columns={entityPositionColumn(viewAcoount)}
        dataList={JSON.parse(JSON.stringify(allPosts?.records || []))}
        deleteCallBack={handleDelete}
        error={errorAllPosts || deletePositionError}
        exportProps={{
          data: allPosts?.records,
          fileName: 'Position',
          columns: useTranslatedColumnsForPDF(positionColumnMappings),
          pdf: {
            orientation: 'portrait',
          },
          allRecords: {
            baseURL: getEnv('REACT_APP_UP_BASE_URL', null),
            endpoint: getAPIWithEntityUrl(apiEndPoint.positionList),
            filterData,
          },
        }}
        filterData={filterData}
        handlePagination={handlePagination}
        handleSearch={onSearch}
        isError={isErrorAllPosts || deletePositionIsError}
        loading={isLoadingAllPosts || deletePositionLoading}
        rowClickHandler={handleView}
        rowNumber={0}
        selelctedUser={selelctedDelete}
        setSelelctedUser={setSelelctedDelete}
        sortHandleClick={sorting}
        success={deletePositionSuccess}
        title={t('Position')}
      />
    </Box>
  )
}

export default PositionList
