import { Box, Grid } from '@mui/material'
import {
  useLazyGetPositionByIdQuery,
  usePositionCreateMutation,
  usePositionUpdateMutation,
} from 'api/entityServices/index'
import OPRInputControl from 'components/molecules/OPRInputControl'
import OPRResponsiveGrid from 'components/molecules/OPRResponsiveGrid'
import OPRTextArea from 'components/molecules/OPRTextArea/OPRTextArea'
import OPRAlertControl from 'components/organism/OPRAlertControl'
import { OPRInnerFormLayout } from 'components/organism/OPRInnerFormLayout'
import { validationSchemaPosition } from 'constants/validate'
import { useEditable } from 'hooks/useEdit'
import useForm from 'hooks/useForm'
import { t } from 'i18next'
import { useEffect } from 'react'
import { useLocation, useNavigate } from 'react-router-dom'
import { routes } from 'routes/routes'
import { getParamsValue } from 'utils'

interface MessageProps {
  text?: string;
  important?: boolean;
}

export default function PositionForm() {
  const location: any = useLocation()
  const { id, viewUrl } = getParamsValue(location, routes.createPosition)

  const { isEditable, setEditable } = useEditable()

  const {
    values,
    setValues,
    errors,
    handleChange,
    setErrors,
    handleFormSubmit,
  } = useForm(validationSchemaPosition)

  const navigate = useNavigate()
  const [
    createPosition,
    {
      data: createdPositionData,
      error: createdPositionError,
      isLoading: createdPositionLoading,
      isSuccess: createdPositionSuccess,
      isError: createdPositionIsError,
    },
  ] = usePositionCreateMutation()

  const [
    updatePosition,
    {
      data: updatedDataResponse,
      error: updatedPositionError,
      isLoading: updatedPositionLoading,
      isSuccess: updatedPositionSuccess,
      isError: updatedPositionIsError,
    },
  ] = usePositionUpdateMutation()

  const [
    updatePositionById,
    {
      data: updatedPositionByIdResponse,
      error: updatedPositionByIdError,
      isLoading: updatedPositionByIdLoading,
      isSuccess: updatedPositionByIdSuccess,
      isError: updatedPositionByIdIsError,
    },
  ] = useLazyGetPositionByIdQuery()
  useEffect(() => {
    if (id) {
      updatePositionById(id)
      setEditable(viewUrl)
    }
  }, [])
  useEffect(() => {
    if (id) {
      setValues(updatedPositionByIdResponse?.data)
    } else {
      setValues(location.state ? location.state : {})
    }
  }, [updatedPositionByIdResponse?.data])

  const handleSubmit: any = async () => {
    if (isEditable) {
      if (id === null) {
        await createPosition({
          positionCode: values?.positionCode,
          positionDescription: values?.positionDescription,
          remarks: values?.remarks || '',
        })
      } else {
        await updatePosition({
          id: values.id,
          positionCode: values.positionCode,
          positionDescription: values.positionDescription,
          remarks: values?.remarks || '',
        })
      }
    } else {
      setEditable(true)
    }
  }

  async function editPosition() {
    await updatePosition({
      id: values.id,
      positionCode: values.positionCode,
      positionDescription: values.positionDescription,
      remarks: values?.remarks || '',
    })
  }

  const onScreenClose:any = (item: any) => {
    setEditable(item)
    setValues({})
  }

  return (
    <Box sx={{ display: 'flex' }}>
      <form
        style={{ display: 'flex', width: '100% ' }}
        onSubmit={(e) => handleFormSubmit(e, handleSubmit)}
      >
        <OPRAlertControl
          error={createdPositionError || updatedPositionError}
          handleEditable={setEditable}
          handleSetValue={setValues}
          handleSubmit={handleSubmit}
          isError={createdPositionError || updatedPositionIsError}
          isLoading={
            createdPositionLoading
            || updatedPositionLoading
            || updatedPositionByIdLoading
          }
          isSuccess={updatedPositionSuccess || createdPositionSuccess}
          name={values?.positionDescription}
          title={t('Position_sub_menu')}
          type={id ? 'Update' : 'New'}
        />
        <OPRInnerFormLayout
          error={createdPositionError || updatedPositionError}
          handleCancelClick={() => navigate(-1)}
          handleContinueClick={handleSubmit}
          handleEditable={() => {
            setEditable(true)
          }}
          isBackButton={isEditable}
          isLoading={
            createdPositionLoading
            || updatedPositionLoading
            || updatedPositionByIdLoading
          }
          pageType="detailsPage"
          subtitle={
            isEditable
              ? 'Please check the user details below.'
              : 'All fields are mandatory except those marked optional'
          }
          // title={t('add_Position')}
          title={(viewUrl) ? values?.positionDescription : false || ((id) ? values?.positionDescription : t('add_Position'))} // Set title based on mode
          onScreenClose={onScreenClose}
        >
          <Box>
            <OPRResponsiveGrid>
              <Grid item md={2} sm={1} xs={1}>
                <OPRInputControl
                  disabled={!!id}
                  error={t(errors?.positionCode)}
                  isEditable={isEditable}
                  label="position_Code"
                  name="positionCode"
                  value={values?.positionCode}
                  onChange={handleChange}
                />
              </Grid>
              <Grid item md={2} sm={1} xs={1}>
                <OPRInputControl
                  error={t(errors?.positionDescription)}
                  isEditable={isEditable}
                  label="position_Description"
                  name="positionDescription"
                  value={values?.positionDescription}
                  onChange={handleChange}
                />
              </Grid>
              <Grid item md={4} sm={6} xs={12}>
                <OPRTextArea
                  error={t(errors?.remarks)}
                  isEditable={isEditable}
                  label="remarks"
                  name="remarks"
                  optionalText="optional"
                  value={values?.remarks}
                  onChange={handleChange}
                />
              </Grid>
            </OPRResponsiveGrid>
          </Box>
        </OPRInnerFormLayout>
      </form>
    </Box>
  )
}
