import {
  Box,
} from '@mui/material'
import { useGetAllStaffTypeQuery, useStaffTypeDeleteMutation } from 'api/entityServices'
import { entityStaffTypeColumn } from 'components/atoms/table/OPRTableConstant'
import { OPRInnerListLayout } from 'components/organism/OPRInnerLayoutList'
import apiEndPoint from 'constants/apiEndPoint'
import { staffTypeColumnMappings } from 'constants/exportColumnMappings'
import { useTranslatedColumnsForPDF } from 'hooks/useTranslatedColumnsForPDF'
import { t } from 'i18next'
import React, { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { routes } from 'routes/routes'
import {
  generateFilterUrl, getAPIWithEntityUrl, getEnv, setRouteValues,
} from 'utils'

function StaffTypeList() {
  const navigate: any = useNavigate()
  const [selelctedDelete, setSelelctedDelete]:any = useState({
    data: {},
    isDelete: false,
    name: '',
  })
  const [filterData, setFilterData]:any = useState({
    pageNumber: 1,
    pageSize: 20,
    totalItems: 0,
    orderByAsc: true,
    sortBy: '',
    SearchText: '',
  })
  const {
    data: allPosts,
    isLoading: isLoadingAllPosts,
    isSuccess: isSuccessAllPosts,
    isError: isErrorAllPosts,
    error: errorAllPosts,
    refetch: refetchAllPosts,
  } = useGetAllStaffTypeQuery(generateFilterUrl(filterData))

  const [deleteStaffTypeById,
    {
      data: deleteStaffTypeResponse,
      error: deleteStaffTypeError,
      isLoading: deleteStaffTypeLoading,
      isSuccess: deleteStaffTypeSuccess,
      isError: deleteStaffTypeIsError,
    }] = useStaffTypeDeleteMutation()
  const sorting = (
    event: React.MouseEvent<unknown>,
    property: keyof any,
  ) => {
    const isAsc = filterData.sortBy === property && filterData.orderByAsc === true
    setFilterData({ ...filterData, orderByAsc: !isAsc, sortBy: property })
    // setOrder(isAsc ? 'desc' : 'asc')
    // setOrderBy(property)
  }

  useEffect(() => {
    setFilterData({ ...filterData, totalItems: allPosts?.totalItems ? allPosts?.totalItems : 0 })
  }, [allPosts?.pageNumber, filterData.sortBy, filterData.orderByAsc, allPosts?.totalItems])

  const onSearch = (e: any, data: any) => {
    setFilterData({ ...filterData, ...data })
  }
  const handlePagination = (pageNumber: number, pageSize: number) => {
    setFilterData({ ...filterData, pageNumber })
  }
  const viewAcoount = (data: any, type:string) => {
    if (type === 'Edit Staff Type') {
      navigate(
        setRouteValues(`${routes.editStaffType}`, {
          id: data.id,
        }),
      )
    } else if (type === 'Delete Staff Type') {
      // deleteStaffTypeById(`Id=${data.id}`)
      setSelelctedDelete({ data, isDelete: true, name: data.staffTypeDescription })
    } else {
      navigate(
        setRouteValues(`${routes.viewStaffType}`, {
          id: data.id,
        }),
      )
    }
    // const id = JSON.stringify(data)
  }

  const handleView = (data: any) => {
    navigate(
      setRouteValues(`${routes.viewStaffType}`, {
        id: data.id,
        view: true,
      }),
    )
  }
  // handle delete
  const handleDelete = (data:any) => {
    deleteStaffTypeById(`Id=${data.id}`)
  }

  return (
    <Box sx={{ display: 'flex' }}>
      <OPRInnerListLayout
        isExport
        Search={decodeURIComponent(filterData.SearchText)}
        addHandleClick={() => navigate(routes.createStaffType)}
        columns={entityStaffTypeColumn(viewAcoount)}
        dataList={JSON.parse(JSON.stringify(allPosts?.records || []))}
        deleteCallBack={handleDelete}
        error={errorAllPosts || deleteStaffTypeError}
        exportProps={{
          data: allPosts?.records,
          fileName: 'Staff Type',
          columns: useTranslatedColumnsForPDF(staffTypeColumnMappings),
          pdf: {
            orientation: 'portrait',
          },
          allRecords: {
            baseURL: getEnv('REACT_APP_UP_BASE_URL', null),
            endpoint: getAPIWithEntityUrl(apiEndPoint.staffTypeList),
            filterData,
          },
        }}
        filterData={filterData}
        handlePagination={handlePagination}
        handleSearch={onSearch}
        isError={isErrorAllPosts || deleteStaffTypeIsError}
        loading={isLoadingAllPosts || deleteStaffTypeLoading}
        rowClickHandler={handleView}
        rowNumber={0}
        selelctedUser={selelctedDelete}
        setSelelctedUser={setSelelctedDelete}
        sortHandleClick={sorting}
        success={deleteStaffTypeSuccess}
        title={t('StaffType')}
      />
    </Box>
  )
}

export default StaffTypeList
