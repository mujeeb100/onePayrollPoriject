import { Box, Grid } from '@mui/material'
import {
  useLazyGetStaffTypeByIdQuery,
  useStaffTypeCreateMutation,
  useStaffTypeUpdateMutation,
} from 'api/entityServices/index'
import OPRInputControl from 'components/molecules/OPRInputControl'
import OPRResponsiveGrid from 'components/molecules/OPRResponsiveGrid'
import OPRTextArea from 'components/molecules/OPRTextArea/OPRTextArea'
import OPRAlertControl from 'components/organism/OPRAlertControl'
import { OPRInnerFormLayout } from 'components/organism/OPRInnerFormLayout'
import { validationSchemaStaffType } from 'constants/validate'
import { useEditable } from 'hooks/useEdit'
import useForm from 'hooks/useForm'
import { t } from 'i18next'
import { useEffect } from 'react'
import { useLocation, useNavigate } from 'react-router-dom'
import { routes } from 'routes/routes'
import { getParamsValue } from 'utils'

interface MessageProps {
  text?: string;
  important?: boolean;
}

export default function StaffTypeForm() {
  const location: any = useLocation()
  const { id, viewUrl } = getParamsValue(location, routes.createStaffType)

  const { isEditable, setEditable } = useEditable()

  const {
    values,
    setValues,
    errors,
    handleChange,
    setErrors,
    handleFormSubmit,
  } = useForm(validationSchemaStaffType)

  const navigate = useNavigate()
  const [
    createStaffType,
    {
      data: createdStaffTypeData,
      error: createdStaffTypeError,
      isLoading: createdStaffTypeLoading,
      isSuccess: createdStaffTypeSuccess,
      isError: createdStaffTypeIsError,
    },
  ] = useStaffTypeCreateMutation()

  const [
    updateStaffType,
    {
      data: updatedDataResponse,
      error: updatedStaffTypeError,
      isLoading: updatedStaffTypeLoading,
      isSuccess: updatedStaffTypeSuccess,
      isError: updatedStaffTypeIsError,
    },
  ] = useStaffTypeUpdateMutation()

  const [
    updateStaffTypeById,
    {
      data: updatedStaffTypeByIdResponse,
      error: updatedStaffTypeByIdError,
      isLoading: updatedStaffTypeByIdLoading,
      isSuccess: updatedStaffTypeByIdSuccess,
      isError: updatedStaffTypeByIdIsError,
    },
  ] = useLazyGetStaffTypeByIdQuery()
  useEffect(() => {
    if (id) {
      updateStaffTypeById(id)
      setEditable(viewUrl)
    }
  }, [])
  useEffect(() => {
    if (id) {
      setValues(updatedStaffTypeByIdResponse?.data)
    } else {
      setValues(location.state ? location.state : {})
    }
  }, [updatedStaffTypeByIdResponse?.data])

  const handleSubmit: any = async () => {
    if (isEditable) {
      if (id === null) {
        await createStaffType({
          staffTypeCode: values?.staffTypeCode,
          staffTypeDescription: values?.staffTypeDescription,
          remarks: values?.remarks || '',
        })
      } else {
        await updateStaffType({
          id: values?.id,
          staffTypeCode: values?.staffTypeCode,
          staffTypeDescription: values?.staffTypeDescription,
          remarks: values?.remarks || '',
        })
      }
    } else {
      setEditable(true)
    }
  }

  async function editStaffType() {
    await updateStaffType({
      id: values?.id,
      staffTypeCode: values?.staffTypeCode,
      staffTypeDescription: values?.staffTypeDescription,
      remarks: values?.remarks || '',
    })
  }

  const onScreenClose:any = (item: any) => {
    setEditable(item)
    setValues({})
  }

  return (
    <Box sx={{ display: 'flex' }}>
      <form
        style={{ display: 'flex', width: '100% ' }}
        onSubmit={(e) => handleFormSubmit(e, handleSubmit)}
      >
        <OPRAlertControl
          error={createdStaffTypeError || updatedStaffTypeError}
          handleEditable={setEditable}
          handleSetValue={setValues}
          handleSubmit={handleSubmit}
          isError={createdStaffTypeError || updatedStaffTypeIsError}
          isLoading={
            createdStaffTypeLoading
            || updatedStaffTypeLoading
            || updatedStaffTypeByIdLoading
          }
          isSuccess={updatedStaffTypeSuccess || createdStaffTypeSuccess}
          name={values?.staffTypeDescription}
          title={t('StaffType')}
          type={id ? 'Update' : 'New'}
        />
        <OPRInnerFormLayout
          error={createdStaffTypeError || updatedStaffTypeError}
          handleCancelClick={() => navigate(-1)}
          handleContinueClick={handleSubmit}
          handleEditable={() => {
            setEditable(true)
          }}
          isBackButton={isEditable}
          isLoading={
            createdStaffTypeLoading
            || updatedStaffTypeLoading
            || updatedStaffTypeByIdLoading
          }
          pageType="detailsPage"
          subtitle={
            isEditable
              ? 'Please check the user details below.'
              : 'All fields are mandatory except those marked optional'
          }
          // title={t('add_staff_type')}
          title={(viewUrl) ? values?.staffTypeDescription : false || ((id) ? values?.staffTypeDescription : t('add_staff_type'))} // Set title based on mode
          onScreenClose={onScreenClose}
        >
          <Box>
            <OPRResponsiveGrid>
              <Grid item md={2} sm={1} xs={1}>
                <OPRInputControl
                  disabled={!!id}
                  error={t(errors?.staffTypeCode)}
                  isEditable={isEditable}
                  label="staff_Type_Code"
                  name="staffTypeCode"
                  value={values?.staffTypeCode}
                  onChange={handleChange}
                />
              </Grid>
              <Grid item md={2} sm={1} xs={1}>
                <OPRInputControl
                  error={t(errors?.staffTypeDescription)}
                  isEditable={isEditable}
                  label="staff_Type_Description"
                  name="staffTypeDescription"
                  value={values?.staffTypeDescription}
                  onChange={handleChange}
                />
              </Grid>
              <Grid item md={4} sm={6} xs={12}>
                <OPRTextArea
                  error={t(errors?.remarks)}
                  isEditable={isEditable}
                  label="remarks"
                  name="remarks"
                  optionalText="optional"
                  value={values?.remarks || ''}
                  onChange={handleChange}
                />
              </Grid>
            </OPRResponsiveGrid>
          </Box>
        </OPRInnerFormLayout>
      </form>
    </Box>
  )
}
