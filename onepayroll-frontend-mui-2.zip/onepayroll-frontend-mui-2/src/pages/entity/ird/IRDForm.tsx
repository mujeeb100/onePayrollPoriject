import { Box, Grid } from '@mui/material'
import {
  useIRDCreateMutation,
  useIRDUpdateMutation,
  useLazyGetIRDByIdQuery,
} from 'api/entityServices'
import OPRInputControl from 'components/molecules/OPRInputControl'
import OPRResponsiveGrid from 'components/molecules/OPRResponsiveGrid'
import OPRTextArea from 'components/molecules/OPRTextArea/OPRTextArea'
import OPRAlertControl from 'components/organism/OPRAlertControl'
import { OPRInnerFormLayout } from 'components/organism/OPRInnerFormLayout'
import { validationSchemaIrd } from 'constants/validate'
import { useEditable } from 'hooks/useEdit'
import useForm from 'hooks/useForm'
import { t } from 'i18next'
import { useEffect } from 'react'
import { useLocation, useNavigate } from 'react-router-dom'
import { routes } from 'routes/routes'
import { getParamsValue } from 'utils'

interface MessageProps {
  text?: string;
  important?: boolean;
}

export default function IRDForm() {
  const location: any = useLocation()
  const { id, viewUrl } = getParamsValue(location, routes.createIrd)

  const { isEditable, setEditable } = useEditable()

  const {
    values,
    setValues,
    errors,
    handleChange,
    setErrors,
    handleFormSubmit,
  } = useForm(validationSchemaIrd)

  const navigate = useNavigate()
  const [
    createIRD,
    {
      data: createdIRDData,
      error: createdIRDError,
      isLoading: createdIRDLoading,
      isSuccess: createdIRDSuccess,
      isError: createdIRDIsError,
    },
  ] = useIRDCreateMutation()

  const [
    updateIRD,
    {
      data: updatedDataResponse,
      error: updatedIRDError,
      isLoading: updatedIRDLoading,
      isSuccess: updatedIRDSuccess,
      isError: updatedIRDIsError,
    },
  ] = useIRDUpdateMutation()

  const [
    updateIRDById,
    {
      data: updatedIRDByIdResponse,
      error: updatedIRDByIdError,
      isLoading: updatedIRDByIdLoading,
      isSuccess: updatedIRDByIdSuccess,
      isError: updatedIRDByIdIsError,
    },
  ] = useLazyGetIRDByIdQuery()

  useEffect(() => {
    if (id) {
      updateIRDById(id)
      setEditable(viewUrl)
    }
  }, [])
  useEffect(() => {
    if (id) {
      setValues(updatedIRDByIdResponse?.data)
    } else {
      setValues(location.state ? location.state : {})
    }
  }, [updatedIRDByIdResponse?.data])

  const handleSubmit: any = async () => {
    if (isEditable) {
      if (id === null) {
        await createIRD({
          corporateTitleCode: values?.corporateTitleCode,
          corporateTitleName: values?.corporateTitleName,
          remarks: values?.remarks || '',

        })
      } else {
        await updateIRD({
          id: values?.id,
          corporateTitleCode: values?.corporateTitleCode,
          corporateTitleName: values?.corporateTitleName,
          remarks: values?.remarks || '',

        })
      }
    } else {
      setEditable(true)
    }
  }

  async function editIRD() {
    await updateIRD({
      id: values.id,
      corporateTitleCode: values.corporateTitleCode,
      corporateTitleName: values.corporateTitleName,
      remarks: values.remarks || '',
    })
  }

  const onScreenClose:any = (item: any) => {
    setEditable(item)
    setValues({})
  }

  return (
    <Box sx={{ display: 'flex' }}>
      <form
        style={{ display: 'flex', width: '100% ' }}
        onSubmit={(e) => handleFormSubmit(e, handleSubmit)}
      >
        <OPRAlertControl
          error={createdIRDError || updatedIRDError}
          handleEditable={setEditable}
          handleSetValue={setValues}
          handleSubmit={handleSubmit}
          isError={createdIRDError || updatedIRDIsError}
          isLoading={
            createdIRDLoading
            || updatedIRDLoading
            || updatedIRDByIdLoading
          }
          isSuccess={updatedIRDSuccess || createdIRDSuccess}
          name={values?.corporateTitleName}
          title="IRD"
          type={id ? 'Update' : 'New'}
        />
        <OPRInnerFormLayout
          error={createdIRDError || updatedIRDError}
          handleCancelClick={() => navigate(-1)}
          handleContinueClick={handleSubmit}
          handleEditable={() => {
            setEditable(true)
          }}
          isBackButton={isEditable}
          isLoading={
            createdIRDLoading
            || updatedIRDLoading
            || updatedIRDByIdLoading
          }
          pageType="detailsPage"
          subtitle={
            isEditable
              ? 'Please check the user details below.'
              : 'All fields are mandatory except those marked optional'
          }
          // title={t('ent_ird_add_btn_title')}
          title={(viewUrl) ? values?.corporateTitleName : false || ((id) ? values?.corporateTitleName : t('ent_ird_add_btn_title'))} // Set title based on mode
          onScreenClose={onScreenClose}
        >
          <Box>
            <OPRResponsiveGrid>
              <Grid item md={2} sm={1} xs={1}>
                <OPRInputControl
                  disabled={!!id}
                  error={t(errors?.corporateTitleCode)}
                  isEditable={isEditable}
                  label="ent_ird_corporate_title_view_code"
                  name="corporateTitleCode"
                  value={values?.corporateTitleCode}
                  onChange={handleChange}
                />
              </Grid>
              <Grid item md={2} sm={1} xs={1}>
                <OPRInputControl
                  error={t(errors?.corporateTitleName)}
                  isEditable={isEditable}
                  label="ent_ird_corporate_title_view_name"
                  name="corporateTitleName"
                  value={values?.corporateTitleName}
                  onChange={handleChange}
                />
              </Grid>
              <Grid item md={4} sm={6} xs={12}>
                <OPRTextArea
                  error={t(errors?.remarks)}
                  isEditable={isEditable}
                  label="remarks"
                  name="remarks"
                  optionalText="optional"
                  value={values?.remarks}
                  onChange={handleChange}
                />
              </Grid>
            </OPRResponsiveGrid>
          </Box>
        </OPRInnerFormLayout>
      </form>
    </Box>
  )
}
