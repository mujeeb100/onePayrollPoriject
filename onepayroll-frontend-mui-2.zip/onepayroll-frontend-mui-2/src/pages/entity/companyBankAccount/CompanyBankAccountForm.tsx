import { Box, Grid } from '@mui/material'
import {
  useCompanyBankAccountCreateMutation,
  useCompanyBankAccountUpdateMutation,
  useLazyGetCompanyBankAccountByIdQuery,
} from 'api/entityServices'
import { useGetAllCurrencyQuery } from 'api/globalServices'
import OPRLabel from 'components/atoms/label/OPRLabel'
import OPRDatePickerControl from 'components/molecules/OPRDatePickerControl/OPRDatePickerControl'
import OPRInputControl from 'components/molecules/OPRInputControl'
import OPRResponsiveGrid from 'components/molecules/OPRResponsiveGrid'
import OPRSelectorControl from 'components/molecules/OPRSelectorControl/OPRSelectorControl'
import OPRAlertControl from 'components/organism/OPRAlertControl'
import { OPRInnerFormLayout } from 'components/organism/OPRInnerFormLayout'
import {
  validationSchemaCompanyBankAcc,
} from 'constants/validate'
import { useEditable } from 'hooks/useEdit'
import useForm from 'hooks/useForm'
import { t } from 'i18next'
import { useEffect, useState } from 'react'
import { useLocation, useNavigate } from 'react-router-dom'
import { routes } from 'routes/routes'
import { formatedYearDate, generateFilterUrl, getParamsValue } from 'utils'

interface MessageProps {
  text?: string;
  important?: boolean;
}

export default function CompanyBanckAccountForm() {
  const location: any = useLocation()
  // const id = getParamsValue(location, routes.createWorkCalender)
  const { id, viewUrl } = getParamsValue(location, routes.createCompanyBankAccount)
  const [mode, setMode] = useState('view') // Default mode is edit
  const { isEditable, setEditable } = useEditable()

  const {
    values,
    setValues,
    errors,
    handleChange,
    setErrors,
    handleFormSubmit,
    handleOnChange,
  } = useForm(validationSchemaCompanyBankAcc)

  const navigate = useNavigate()
  const [
    createCompanyBankAccount,
    {
      data: createdWorkCalenderData,
      error: createdWorkCalenderError,
      isLoading: createdWorkCalenderLoading,
      isSuccess: createdWorkCalenderSuccess,
      isError: createdWorkCalenderIsError,
    },
  ] = useCompanyBankAccountCreateMutation()

  const [
    updateWorkCalender,
    {
      data: updatedDataResponse,
      error: updatedWorkCalenderError,
      isLoading: updatedWorkCalenderLoading,
      isSuccess: updatedWorkCalenderSuccess,
      isError: updatedWorkCalenderIsError,
    },
  ] = useCompanyBankAccountUpdateMutation()

  const [
    updateCompanyBankAccountById,
    {
      data: updatedWorkCalenderByIdResponse,
      error: updatedWorkCalenderByIdError,
      isLoading: updatedWorkCalenderByIdLoading,
      isSuccess: updatedWorkCalenderByIdSuccess,
      isError: updatedWorkCalenderByIdIsError,
    },
  ] = useLazyGetCompanyBankAccountByIdQuery()

  const {
    data: allPostsHC,
  } = useGetAllCurrencyQuery(generateFilterUrl({ pageSize: 250 }))

  useEffect(() => {
    if (id) {
      updateCompanyBankAccountById(id)
      setEditable(viewUrl)
      // setMode('view') // Set mode to view if id is present
    }
  }, [])
  useEffect(() => {
    if (id) {
      setValues(updatedWorkCalenderByIdResponse?.data)
    } else {
      setValues(location.state ? location.state : {})
    }
  }, [updatedWorkCalenderByIdSuccess])

  // reset the values

  const handleSubmit: any = async () => {
    if (isEditable) {
      // List of SCB formats
      const scbFormats = [5, 6, 7, 8] // SCB - PAY (5), SCB - BT (6), SCB - RTGS (7), SCB - DISK (8)

      // Determine if HSBC-related fields should be included
      const isSCBFormat = scbFormats.includes(values?.bankFileFormat)
      const isHSBCMRI = values?.bankFileFormat === 0 // Replace with the actual value if different

      // Define the common data structure
      const commonData = {
        accountNumber: values?.accountNumber,
        bankCode: values?.bankCode,
        bankFileFormat: values?.bankFileFormat,
        bankReference: values?.bankReference,
        branchCode: values?.branchCode,
        companyBankAccountCode: values?.companyBankAccountCode,
        companyBankAccountDescription: values?.companyBankAccountDescription,
        currency: values?.currency,
        status: values?.status,
        swiftCode: values?.swiftCode,
        valueDate: values?.valueDate ? formatedYearDate(values?.valueDate) : null,
        fasterPaymentSystem: values?.fasterPaymentSystem || false,
      }

      // Initialize HSBC-specific data
      let hsbcData = {
        hsbcBusinessIntegratedAccount: values?.hsbcBusinessIntegratedAccount || false,
        hsbcbiaAccountType: values?.hsbcBusinessIntegratedAccount ? values?.hsbcbiaAccountType : '',
        hsbcbiaSuffix: values?.hsbcBusinessIntegratedAccount ? values?.hsbcbiaSuffix : '',
        hsbcifileFileReference: values?.hsbcifileFileReference || null,
        hsbcifilehsbcNetCustomerID: values?.hsbcifilehsbcNetCustomerID || null,
        hsbcmriFileExtension: values?.hsbcmriFileExtension || null,
        hsbcmriPaymentCode: values?.hsbcmriPaymentCode || null,
        hsbcmriPlanCode: values?.hsbcmriPlanCode || null,
        hsbcifilehsbcConnectCustomerId: values?.hsbcifilehsbcConnectCustomerId || null,
        hsbcifilePaymentCode: values?.hsbcifilePaymentCode || null,
      }

      // Adjust HSBC data based on selected bank file format
      if (isSCBFormat) {
        hsbcData = {
          hsbcBusinessIntegratedAccount: false,
          hsbcbiaAccountType: '',
          hsbcbiaSuffix: '',
          hsbcifileFileReference: null,
          hsbcifilehsbcNetCustomerID: null,
          hsbcmriFileExtension: null,
          hsbcmriPaymentCode: null,
          hsbcmriPlanCode: null,
          hsbcifilehsbcConnectCustomerId: null,
          hsbcifilePaymentCode: null,
        }
      } else if (isHSBCMRI) {
        // Optionally handle HSBC MRI-specific logic if needed
        // For example, if you want to ensure HSBC-related fields are included or modified:
        hsbcData = {
          ...hsbcData, // You may add or modify fields specifically for HSBC MRI if needed
        }
      }

      // Combine common data and HSBC-specific data
      const finalData = {
        ...commonData,
        ...hsbcData,
      }

      if (id === null) {
        await createCompanyBankAccount(finalData)
      } else {
        await updateWorkCalender({
          id: values?.id,
          ...finalData,
        })
      }
    } else {
      setEditable(true)
    }
  }

  const onScreenClose:any = (item: any) => {
    setEditable(item)
    setValues({})
  }

  return (
    <Box sx={{ display: 'flex' }}>
      <form
        style={{ display: 'flex', width: '100% ' }}
        onSubmit={(e) => handleFormSubmit(e, handleSubmit)}
      >
        <OPRAlertControl
          customMessage={`${values?.companyBankAccountDescription} has been added`}
          customTitle="New company bank account added"
          error={createdWorkCalenderError || updatedWorkCalenderError}
          handleEditable={setEditable}
          handleSetValue={setValues}
          handleSubmit={handleSubmit}
          isError={createdWorkCalenderError || updatedWorkCalenderError}
          isLoading={
            createdWorkCalenderLoading
            || updatedWorkCalenderLoading
            || updatedWorkCalenderByIdLoading
          }
          isSuccess={updatedWorkCalenderSuccess || createdWorkCalenderSuccess}
          name={t('companyBankAccount')}
          title={t('companyBankAccount')}
          type={id ? 'Update' : 'New'}
        />

        <OPRInnerFormLayout
          error={createdWorkCalenderError || updatedWorkCalenderError}
          handleCancelClick={() => navigate(-1)}
          handleContinueClick={handleSubmit}
          handleEditable={() => {
            setEditable(true)
          }}
          isBackButton={isEditable}
          isLoading={
            createdWorkCalenderLoading
            || updatedWorkCalenderLoading
            || updatedWorkCalenderByIdLoading
          }
          pageType="detailsPage"
          subtitle={
            isEditable
              ? 'Please check the user details below.'
              : 'All fields are mandatory except those marked optional'
          }
          title={((id) ? values?.companyBankAccountDescription : t('add_companyBankAccount'))} // Set title based on mode
          onScreenClose={onScreenClose}

        >
          <Box>
            <OPRResponsiveGrid>
              <div style={{ display: 'block', width: '100%', margin: '0 18px' }}>
                <OPRLabel variant="h2">General Information</OPRLabel>
              </div>
              <Grid item md={2} sm={1} xs={1}>
                <OPRInputControl
                  disabled={!!id}
                  error={t(errors?.companyBankAccountCode)}
                  isEditable={isEditable}
                  label="ent_companyBankAccount_Code"
                  name="companyBankAccountCode"
                  value={values?.companyBankAccountCode}
                  onChange={handleChange}
                />
              </Grid>
              <Grid item md={2} sm={1} xs={1}>
                <OPRInputControl
                  error={t(errors?.companyBankAccountDescription)}
                  isEditable={isEditable}
                  label="ent_companyBankAccount_name"
                  name="companyBankAccountDescription"
                  value={values?.companyBankAccountDescription}
                  onChange={handleChange}
                />
              </Grid>
              <Grid item md={2} sm={1} xs={1}>
                <OPRSelectorControl
                  defaultValue={{ name: 'Active', values: true }}
                  error={errors?.status}
                  isEditable={isEditable}
                  keyName="name"
                  label={t('status')}
                  multiple={false}
                  name="status"
                  options={[{ name: 'Active', values: true }, { name: 'Inactive', values: false }]}
                  placeholder="Select an option"
                  value={[{ name: 'Active', values: true }, { name: 'Inactive', values: false }]?.find((o:any) => o?.values === values?.status) || {}}
                  valueKey="name"
                  onChange={(text:any) => {
                    // handleChange({ target: { name: 'countryLocalization', value: text?.countryCode }, persist: () => {} })
                    // setValues({ ...values, countryLocalization: text })
                    handleOnChange('status', text?.values)
                  }}
                />
              </Grid>

              <div style={{ display: 'block', width: '100%', margin: '30px 20px 20px' }}>
                <OPRLabel variant="h2">Bank Information</OPRLabel>
              </div>
              <Grid item md={2} sm={1} xs={1}>
                <OPRInputControl
                  // disabled={!!id}
                  error={t(errors?.bankCode)}
                  isEditable={isEditable}
                  label="bank_Code"
                  name="bankCode"
                  value={values?.bankCode}
                  onChange={handleChange}
                />
              </Grid>
              <Grid item md={2} sm={1} xs={1}>
                <OPRInputControl
                  // disabled={!!id}
                  error={t(errors?.branchCode)}
                  isEditable={isEditable}
                  label="branch_Code"
                  name="branchCode"
                  value={values?.branchCode}
                  onChange={handleChange}
                />
              </Grid>
              <Grid item md={2} sm={1} xs={1}>
                <OPRInputControl
                  // disabled={!!id}
                  error={t(errors?.accountNumber)}
                  isEditable={isEditable}
                  label="account_Number"
                  name="accountNumber"
                  value={values?.accountNumber}
                  onChange={handleChange}
                />
              </Grid>
              <Grid item md={2} sm={1} xs={1}>
                <OPRInputControl
                  // disabled={!!id}
                  error={t(errors?.swiftCode)}
                  isEditable={isEditable}
                  label="swift_Code"
                  name="swiftCode"
                  optionalText="optional"
                  value={values?.swiftCode}
                  onChange={handleChange}
                />
              </Grid>
              <Grid item md={2} sm={1} xs={1}>
                <OPRSelectorControl
                  error={errors?.currency}
                  isEditable={isEditable}
                  keyName="currencyCode"
                  label="currency_title"
                  multiple={false}
                  name="currency"
                  options={(allPostsHC?.records || [])}
                  placeholder="Select an option"
                  value={(allPostsHC?.records || [])?.find((o:any) => o?.currencyCode === values?.currency) || {}}
                  valueKey="currencyCode"
                  onChange={(text:any) => {
                    handleOnChange('currency', text?.currencyCode)
                  }}
                />
              </Grid>
              <Grid item md={2} sm={1} xs={1}>
                {/* effective end date */}

                <OPRDatePickerControl
                  error={errors?.valueDate}
                  isEditable={isEditable}
                  label={t('Value date')}
                  name="valueDate"
                  optionalText="optional"
                  value={values?.valueDate || null}
                  onChange={(date) => {
                    handleOnChange('valueDate', date)
                  }}
                />
              </Grid>
              <Grid item md={2} sm={1} xs={1}>
                <OPRInputControl
                  // disabled={!!id}
                  error={t(errors?.bankReference)}
                  isEditable={isEditable}
                  label="bank_Reference"
                  name="bankReference"
                  optionalText="optional"
                  value={values?.bankReference}
                  onChange={handleChange}
                />
              </Grid>

              <Grid item md={2} sm={1} xs={1}>
                <OPRSelectorControl
                  error={errors?.bankFileFormat}
                  isEditable={isEditable}
                  keyName="bankFileFormat"
                  label="bank_FileFormat"
                  multiple={false}
                  name="bankFileFormat"
                  optionalText="optional"
                  options={[{ bankFileFormat: 'HSBC MRI', values: 0 },
                    { bankFileFormat: 'HSBC IFILE - Priority Payment', values: 3 },
                    { bankFileFormat: 'HSBC IFILE - ACH Payment', values: 4 },
                    { bankFileFormat: 'SCB - PAY', values: 5 },
                    { bankFileFormat: 'SCB - BT', values: 6 },
                    { bankFileFormat: 'SCB - RTGS', values: 7 },
                    { bankFileFormat: 'SCB - DISK', values: 8 },
                  ]}
                  placeholder="Select an option"
                  value={[{ bankFileFormat: 'HSBC MRI', values: 0 },
                    { bankFileFormat: 'HSBC IFILE - Priority Payment', values: 3 },
                    { bankFileFormat: 'HSBC IFILE - ACH Payment', values: 4 },
                    { bankFileFormat: 'SCB - PAY', values: 5 },
                    { bankFileFormat: 'SCB - BT', values: 6 },
                    { bankFileFormat: 'SCB - RTGS', values: 7 },
                    { bankFileFormat: 'SCB - DISK', values: 8 },
                  ]?.find((o:any) => o?.values === values?.bankFileFormat) || {}}
                  valueKey="bankFileFormat"
                  onChange={(text:any) => {
                    handleOnChange('bankFileFormat', text?.values)
                  }}
                />
              </Grid>
              <Grid item md={2} sm={1} xs={1}>
                <OPRSelectorControl
                  error={errors?.fasterPaymentSystem}
                  isEditable={isEditable}
                  keyName="fasterPaymentSystem"
                  label={t('faster_payment_method')}
                  multiple={false}
                  name="fasterPaymentSystem"
                  optionalText="optional"
                  options={[{ fasterPaymentSystem: 'Yes', values: true }, { fasterPaymentSystem: 'No', values: false }]}
                  placeholder="Select an option"
                  value={[{ fasterPaymentSystem: 'Yes', values: true }, { fasterPaymentSystem: 'No', values: false }]?.find((o:any) => o?.values === values?.fasterPaymentSystem) || {}}
                  valueKey="fasterPaymentSystem"
                  onChange={(text:any) => {
                  // handleChange({ target: { name: 'countryLocalization', value: text?.countryCode }, persist: () => {} })
                  // setValues({ ...values, countryLocalization: text })
                    handleOnChange('fasterPaymentSystem', text?.values)
                  }}
                />
              </Grid>
              {(values?.bankFileFormat === 3 || values?.bankFileFormat === 0 || values?.bankFileFormat === 4)
                            && (
                              <Grid item md={2} sm={1} xs={1}>
                                <OPRSelectorControl
                                  error={errors?.hsbcBusinessIntegratedAccount}
                                  isEditable={isEditable}
                                  keyName="name"
                                  label={t('ent_comp_bank_acct_hsbc_business_integrated_acct')}
                                  multiple={false}
                                  name="hsbcBusinessIntegratedAccount"
                                  optionalText={t('optional')}
                                  options={[{ name: 'Yes', values: true }, { name: 'No', values: false }]}
                                  placeholder="Select an option"
                                  value={[{ name: 'Yes', values: true }, { name: 'No', values: false }]?.find((o:any) => o?.values === values?.hsbcBusinessIntegratedAccount) || {}}
                                  valueKey="name"
                                  onChange={(text:any) => {
                                    // handleChange({ target: { name: 'countryLocalization', value: text?.countryCode }, persist: () => {} })
                                    // setValues({ ...values, countryLocalization: text })
                                    handleOnChange('hsbcBusinessIntegratedAccount', text?.values)
                                  }}
                                />
                              </Grid>
                            )}
              {values?.bankFileFormat !== 5 && values?.hsbcBusinessIntegratedAccount === true && (
                <>
                  <Grid item md={2} sm={1} xs={1}>
                    <OPRInputControl
                      // disabled={!!id}
                      error={t(errors?.hsbcbiaSuffix)}
                      isEditable={isEditable}
                      label="HSBC BIA Suffix"
                      name="hsbcbiaSuffix"
                      value={values?.hsbcbiaSuffix}
                      onChange={handleChange}
                    />
                  </Grid>
                  <Grid item md={2} sm={1} xs={1}>
                    <OPRInputControl
                      // disabled={!!id}
                      error={t(errors?.hsbcbiaAccountType)}
                      isEditable={isEditable}
                      label="ent_comp_bank_acct_hsbc_bia_acct_type"
                      name="hsbcbiaAccountType"
                      value={values?.hsbcbiaAccountType}
                      onChange={handleChange}
                    />
                  </Grid>
                </>
              )}

              {values?.bankFileFormat === 0
                && (
                  <>
                    <Grid item md={2} sm={1} xs={1}>
                      <OPRSelectorControl
                        error={errors?.hsbcmriPlanCode}
                        isEditable={isEditable}
                        keyName="hsbcmriPlanCodeName"
                        label="hsbcmri_PlanCode"
                        multiple={false}
                        name="hsbcmriPlanCode"
                        options={[{ hsbcmriPlanCodeName: 'F - (AutoPay-Out)', hsbcmriPlanvalues: 'F' },
                          { hsbcmriPlanCodeName: 'G - (AutoPay-In)', hsbcmriPlanvalues: 'G' }]}
                        placeholder="Select an option"
                        // value={[{ hsbcmriPlanCode: 'F - (AutoPay-Out)', values: 'F' }, { hsbcmriPlanCode: 'G - (AutoPay-In)', values: 'G' }]?.find((o:any) => o?.values === values?.hsbcmriPlanCode) || {}}
                        value={{
                          hsbcmriPlanCodeName: values?.hsbcmriPlanCode,
                          hsbcmriPlanvalues: values?.hsbcmriPlanCode,
                        }}
                        valueKey="hsbcmriPlanvalues"
                        onChange={(text:any) => {
                          handleOnChange('hsbcmriPlanCode', text?.hsbcmriPlanvalues)
                        }}
                      />
                    </Grid>
                    <Grid item md={2} sm={1} xs={1}>
                      <OPRInputControl
                        // disabled={!!id}
                        error={t(errors?.hsbcmriPaymentCode)}
                        isEditable={isEditable}
                        label="hsbcmri_PaymentCode"
                        name="hsbcmriPaymentCode"
                        value={values?.hsbcmriPaymentCode}
                        onChange={handleChange}
                      />
                    </Grid>
                    <Grid item md={2} sm={1} xs={1}>
                      <OPRSelectorControl
                        error={errors?.hsbcmriFileExtension}
                        isEditable={isEditable}
                        keyName="hsbcmriFileExtension"
                        label="hsbcmri_FileExtension"
                        multiple={false}
                        name="hsbcmriFileExtension"
                        options={[{ hsbcmriFileExtension: '.apc', values: 'apc' }, { hsbcmriFileExtension: '.txt', values: 'txt' }]}
                        placeholder="Select an option"
                        value={[{ hsbcmriFileExtension: '.apc', values: 'apc' }, { hsbcmriFileExtension: '.txt', values: 'txt' }]?.find((o:any) => o?.values === values?.hsbcmriFileExtension) || {}}
                        valueKey="hsbcmriFileExtension"
                        onChange={(text:any) => {
                          handleOnChange('hsbcmriFileExtension', text?.values)
                        }}
                      />
                    </Grid>
                  </>
                )}
              {values?.bankFileFormat === 3
                && (
                  <>
                    <Grid item md={2} sm={1} xs={1}>
                      <OPRInputControl
                        // disabled={!!id}
                        error={t(errors?.hsbcifilehsbcNetCustomerID)}
                        isEditable={isEditable}
                        label="hsbcifilehsbc_NetCustomerID"
                        name="hsbcifilehsbcNetCustomerID"
                        value={values?.hsbcifilehsbcNetCustomerID}
                        onChange={handleChange}
                      />
                    </Grid>
                    <Grid item md={2} sm={1} xs={1}>
                      <OPRInputControl
                        // disabled={!!id}
                        error={t(errors?.hsbcifilehsbcConnectCustomerId)}
                        isEditable={isEditable}
                        label="hsbcifilehsbc_ConnectCustomerId"
                        name="hsbcifilehsbcConnectCustomerId"
                        value={values?.hsbcifilehsbcConnectCustomerId}
                        onChange={handleChange}
                      />
                    </Grid>
                    <Grid item md={2} sm={1} xs={1}>
                      <OPRInputControl
                        // disabled={!!id}
                        error={t(errors?.hsbcifileFileReference)}
                        isEditable={isEditable}
                        label="hsbcifile_FileReference"
                        name="hsbcifileFileReference"
                        value={values?.hsbcifileFileReference}
                        onChange={handleChange}
                      />
                    </Grid>
                    <Grid item md={2} sm={1} xs={1}>
                      <OPRInputControl
                        // disabled={!!id}
                        error={t(errors?.hsbcifilePaymentCode)}
                        isEditable={isEditable}
                        label="hsbcifile_PaymentCode"
                        name="hsbcifilePaymentCode"
                        value={values?.hsbcifilePaymentCode}
                        onChange={handleChange}
                      />
                    </Grid>
                  </>
                )}
            </OPRResponsiveGrid>
          </Box>
        </OPRInnerFormLayout>
      </form>
    </Box>
  )
}
