import { Box, Grid } from '@mui/material'
import {
  useLazyGetRegionByIdQuery,
  useRegionCreateMutation,
  useRegionUpdateMutation,
} from 'api/entityServices/index'
import OPRInputControl from 'components/molecules/OPRInputControl'
import OPRResponsiveGrid from 'components/molecules/OPRResponsiveGrid'
import OPRTextArea from 'components/molecules/OPRTextArea/OPRTextArea'
import OPRAlertControl from 'components/organism/OPRAlertControl'
import { OPRInnerFormLayout } from 'components/organism/OPRInnerFormLayout'
import { validationSchemaRegion } from 'constants/validate'
import { useEditable } from 'hooks/useEdit'
import useForm from 'hooks/useForm'
import { t } from 'i18next'
import { useEffect } from 'react'
import { useLocation, useNavigate } from 'react-router-dom'
import { routes } from 'routes/routes'
import { getParamsValue } from 'utils'

interface MessageProps {
  text?: string;
  important?: boolean;
}

export default function RegionForm() {
  const location: any = useLocation()
  const { id, viewUrl } = getParamsValue(location, routes.createRegion)

  // const id = getParamsValue(location, routes.createRegion)
  const { isEditable, setEditable } = useEditable()

  const {
    values,
    setValues,
    errors,
    handleChange,
    setErrors,
    handleFormSubmit,
  } = useForm(validationSchemaRegion)

  const navigate = useNavigate()
  const [
    createRegion,
    {
      data: createdRegionData,
      error: createdRegionError,
      isLoading: createdRegionLoading,
      isSuccess: createdRegionSuccess,
      isError: createdRegionIsError,
    },
  ] = useRegionCreateMutation()

  const [
    updateRegion,
    {
      data: updatedDataResponse,
      error: updatedRegionError,
      isLoading: updatedRegionLoading,
      isSuccess: updatedRegionSuccess,
      isError: updatedRegionIsError,
    },
  ] = useRegionUpdateMutation()

  const [
    updateRegionById,
    {
      data: updatedRegionByIdResponse,
      error: updatedRegionByIdError,
      isLoading: updatedRegionByIdLoading,
      isSuccess: updatedRegionByIdSuccess,
      isError: updatedRegionByIdIsError,
    },
  ] = useLazyGetRegionByIdQuery()
  useEffect(() => {
    if (id) {
      updateRegionById(id)
      setEditable(viewUrl)
    }
  }, [])
  useEffect(() => {
    if (id) {
      setValues(updatedRegionByIdResponse?.data)
    } else {
      setValues(location.state ? location.state : {})
    }
  }, [updatedRegionByIdResponse?.data])

  const handleSubmit: any = async () => {
    if (isEditable) {
      if (id === null) {
        await createRegion({
          regionCode: values?.regionCode,
          regionDescription: values?.regionDescription,
          remarks: values?.remarks || '',
        })
      } else {
        await updateRegion({
          id: values?.id,
          regionCode: values?.regionCode,
          regionDescription: values?.regionDescription,
          remarks: values?.remarks || '',
        })
      }
    } else {
      setEditable(true)
    }
  }

  async function editRegion() {
    await updateRegion({
      id: values?.id,
      regionCode: values?.regionCode,
      regionDescription: values?.regionDescription,
      remarks: values?.remarks || '',
    })
  }

  const onScreenClose:any = (item: any) => {
    setEditable(item)
    setValues({})
  }

  return (
    <Box sx={{ display: 'flex' }}>
      <form
        style={{ display: 'flex', width: '100% ' }}
        onSubmit={(e) => handleFormSubmit(e, handleSubmit)}
      >
        <OPRAlertControl
          error={createdRegionError || updatedRegionError}
          handleEditable={setEditable}
          handleSetValue={setValues}
          handleSubmit={handleSubmit}
          isError={createdRegionError || updatedRegionIsError}
          isLoading={
            createdRegionLoading
            || updatedRegionLoading
            || updatedRegionByIdLoading
          }
          isSuccess={updatedRegionSuccess || createdRegionSuccess}
          name={values?.regionDescription}
          title={t('region')}
          type={id ? 'Update' : 'New'}
        />
        <OPRInnerFormLayout
          error={createdRegionError || updatedRegionError}
          handleCancelClick={() => navigate(-1)}
          handleContinueClick={handleSubmit}
          handleEditable={() => {
            setEditable(true)
          }}
          isBackButton={isEditable}
          isLoading={
            createdRegionLoading
            || updatedRegionLoading
            || updatedRegionByIdLoading
          }
          pageType="detailsPage"
          subtitle={
            isEditable
              ? 'Please check the user details below.'
              : 'All fields are mandatory except those marked optional'
          }
          // title={t('addRegion')}
          title={(viewUrl) ? values?.regionDescription : false || ((id) ? values?.regionDescription : t('addRegion'))} // Set title based on mode
          onScreenClose={onScreenClose}
        >
          <Box>
            <OPRResponsiveGrid>
              <Grid item md={2} sm={1} xs={1}>
                <OPRInputControl
                  disabled={!!id}
                  error={t(errors?.regionCode)}
                  isEditable={isEditable}
                  label="regionCode"
                  name="regionCode"
                  value={values?.regionCode}
                  onChange={handleChange}
                />
              </Grid>
              <Grid item md={2} sm={1} xs={1}>
                <OPRInputControl
                  error={t(errors?.regionDescription)}
                  isEditable={isEditable}
                  label="regionDescription"
                  name="regionDescription"
                  value={values?.regionDescription}
                  onChange={handleChange}
                />
              </Grid>
              <Grid item md={4} sm={6} xs={12}>
                <OPRTextArea
                  error={t(errors?.remarks)}
                  isEditable={isEditable}
                  label="remarks"
                  name="remarks"
                  optionalText="optional"
                  value={values?.remarks}
                  onChange={handleChange}
                />
              </Grid>
            </OPRResponsiveGrid>
          </Box>
        </OPRInnerFormLayout>
      </form>
    </Box>
  )
}
