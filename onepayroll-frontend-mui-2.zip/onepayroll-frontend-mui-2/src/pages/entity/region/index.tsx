import {
  Box,
} from '@mui/material'
import { useGetAllRegionQuery, useRegionDeleteMutation } from 'api/entityServices'
import { entityRegionColumn } from 'components/atoms/table/OPRTableConstant'
import { OPRInnerListLayout } from 'components/organism/OPRInnerLayoutList'
import apiEndPoint from 'constants/apiEndPoint'
import { regionColumnMappings } from 'constants/exportColumnMappings'
import { useTranslatedColumnsForPDF } from 'hooks/useTranslatedColumnsForPDF'
import { t } from 'i18next'
import React, { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { routes } from 'routes/routes'
import {
  generateFilterUrl, getAPIWithEntityUrl, getEnv, setRouteValues,
} from 'utils'

function RegionList() {
  const navigate: any = useNavigate()
  const [selelctedDelete, setSelelctedDelete]:any = useState({
    data: {},
    isDelete: false,
    name: '',
  })
  const [filterData, setFilterData]:any = useState({
    pageNumber: 1,
    pageSize: 20,
    totalItems: 0,
    orderByAsc: true,
    sortBy: '',
    SearchText: '',
  })
  const {
    data: allPosts,
    isLoading: isLoadingAllPosts,
    isSuccess: isSuccessAllPosts,
    isError: isErrorAllPosts,
    error: errorAllPosts,
    refetch: refetchAllPosts,
  } = useGetAllRegionQuery(generateFilterUrl(filterData))

  const [deleteRegionById,
    {
      data: deleteRegionResponse,
      error: deleteRegionError,
      isLoading: deleteRegionLoading,
      isSuccess: deleteRegionSuccess,
      isError: deleteRegionIsError,
    }] = useRegionDeleteMutation()
  const sorting = (
    event: React.MouseEvent<unknown>,
    property: keyof any,
  ) => {
    const isAsc = filterData.sortBy === property && filterData.orderByAsc === true
    setFilterData({ ...filterData, orderByAsc: !isAsc, sortBy: property })
    // setOrder(isAsc ? 'desc' : 'asc')
    // setOrderBy(property)
  }

  useEffect(() => {
    setFilterData({ ...filterData, totalItems: allPosts?.totalItems ? allPosts?.totalItems : 0 })
  }, [allPosts?.pageNumber, filterData.sortBy, filterData.orderByAsc, allPosts?.totalItems])

  const onSearch = (e: any, data: any) => {
    setFilterData({ ...filterData, ...data })
  }
  const handlePagination = (pageNumber: number, pageSize: number) => {
    setFilterData({ ...filterData, pageNumber })
  }

  const viewAcoount = (data: any, type:string) => {
    if (type === 'Edit region') {
      navigate(
        setRouteValues(`${routes.editRegion}`, {
          id: data.id,
        }),
      )
    } else if (type === 'Delete region') {
      // deleteRegionById(`Id=${data.id}`)
      setSelelctedDelete({ data, isDelete: true, name: data.regionDescription })
    } else {
      navigate(
        setRouteValues(`${routes.viewRegion}`, {
          id: data.id,
        }),
      )
    }
    // const id = JSON.stringify(data)
  }
  const handleView = (data: any) => {
    navigate(
      setRouteValues(`${routes.viewRegion}`, {
        id: data.id,
        view: true,
      }),
    )
  }
  // handle Delete
  const handleDelete = (data:any) => {
    deleteRegionById(`Id=${data.id}`)
  }
  return (
    <Box sx={{ display: 'flex' }}>
      <OPRInnerListLayout
        isExport
        Search={decodeURIComponent(filterData.SearchText)}
        addHandleClick={() => navigate(routes.createRegion)}
        columns={entityRegionColumn(viewAcoount)}
        dataList={JSON.parse(JSON.stringify(allPosts?.records || []))}
        deleteCallBack={handleDelete}
        error={errorAllPosts || deleteRegionError}
        exportProps={{
          data: allPosts?.records,
          fileName: 'Region',
          columns: useTranslatedColumnsForPDF(regionColumnMappings),
          pdf: {
            orientation: 'portrait',
          },
          allRecords: {
            baseURL: getEnv('REACT_APP_UP_BASE_URL', null),
            endpoint: getAPIWithEntityUrl(apiEndPoint.regionList),
            filterData,
          },
        }}
        filterData={filterData}
        handlePagination={handlePagination}
        handleSearch={onSearch}
        isError={isErrorAllPosts || deleteRegionIsError}
        loading={isLoadingAllPosts || deleteRegionLoading}
        rowClickHandler={handleView}
        rowNumber={0}
        selelctedUser={selelctedDelete}
        setSelelctedUser={setSelelctedDelete}
        sortHandleClick={sorting}
        success={deleteRegionSuccess}
        title={t('region')}
      />
    </Box>
  )
}

export default RegionList
