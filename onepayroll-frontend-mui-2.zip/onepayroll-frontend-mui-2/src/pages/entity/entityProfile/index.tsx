import {
  Box,
} from '@mui/material'
import { useEntityProfileDeleteMutation, useGetAllEntityProfileQuery } from 'api/entityServices'
import CustomLoader from 'components/atoms/loader/OPRLoader'
import { CustomDialog } from 'components/atoms/modal/OPRModal'
import { entityProfileColumn } from 'components/atoms/table/OPRTableConstant'
import { OPRDeleteControl } from 'components/molecules/OPRAlertControl/OPRDeleteControl'
import { OPRInnerListLayout } from 'components/organism/OPRInnerLayoutList'
import { t } from 'i18next'
import React, { useEffect, useState } from 'react'
import { useLocation, useNavigate } from 'react-router-dom'
import { routes } from 'routes/routes'
import {
  generateFilterUrl, getParamsValue, setRouteValues,
} from 'utils'

function EntityProfileList({ ProfileId }:any) {
  const [selelctedUser, setSelelctedUser]:any = useState({
    data: {},
    isDelete: false,
    name: '',
  })
  const navigate: any = useNavigate()
  const location: any = useLocation()
  const { id, viewUrl } = getParamsValue(location, routes.createEntityProfile)
  const [filterData, setFilterData]:any = useState({
    pageNumber: 1,
    pageSize: 20,
    totalItems: 0,
    orderByAsc: true,
    sortBy: '',
    SearchText: '',
  })
  const {
    data: allPosts,
    isLoading: isLoadingAllPosts,
    isSuccess: isSuccessAllPosts,
    isError: isErrorAllPosts,
    error: errorAllPosts,
    refetch: refetchAllPosts,
  } = useGetAllEntityProfileQuery(generateFilterUrl(filterData))

  const [deleteEntityProfileById,
    {
      data: deleteEntityProfileResponse,
      error: deleteEntityProfileError,
      isLoading: deleteEntityProfileLoading,
      isSuccess: deleteEntityProfileSuccess,
      isError: deleteEntityProfileIsError,
    }] = useEntityProfileDeleteMutation()

  const sorting = (
    event: React.MouseEvent<unknown>,
    property: keyof any,
  ) => {
    const isAsc = filterData.sortBy === property && filterData.orderByAsc === true
    setFilterData({ ...filterData, orderByAsc: !isAsc, sortBy: property })
  }

  useEffect(() => {
    setFilterData({ ...filterData, totalItems: allPosts?.totalItems ? allPosts?.totalItems : 0 })
  }, [allPosts?.pageNumber, filterData.sortBy, filterData.orderByAsc, allPosts?.totalItems])

  const onSearch = (e: any, data: any) => {
    setFilterData({ ...filterData, ...data })
  }
  const handlePagination = (pageNumber: number, pageSize: number) => {
    setFilterData({ ...filterData, pageNumber })
  }

  const viewAcoount = (data: any, type:string) => {
    if (type === 'edit') {
      navigate(
        setRouteValues(`${routes.editEntityProfile}`, {
          id: data.id,
        }),
      )
    } else if (type === 'delete') {
      deleteEntityProfileById(`Id=${data.id}`)
    } else {
      navigate(
        setRouteValues(`${routes.viewEntityProfile}`, {
          id: data.id,
        }),
      )
    }
  }

  const handleView = (data: any) => {
    navigate(
      setRouteValues(`${routes.viewEntityProfile}`, {
        id: data.id,
        view: true,
      }),
    )
  }

  const deleteEntities = (data:any) => {
    deleteEntityProfileById(`Id=${data.id}`)
  }
  return (
    <Box sx={{ display: 'flex', flexDirection: 'column' }}>
      <CustomDialog
        CustomStyles={{ borderRadius: '16px' }}
        isOpen={isLoadingAllPosts}
        type="loader"
      >
        <CustomLoader text="Processing request" />
      </CustomDialog>
      <OPRDeleteControl
        deleteCallBack={deleteEntities}
        selelctedUser={selelctedUser}
        setSelelctedUser={setSelelctedUser}
        title="Client Group Entities"
      />
      <OPRInnerListLayout
        Search={filterData.SearchText}
        addHandleClick={() => navigate(routes.createEntityProfile)}
        columns={entityProfileColumn(viewAcoount)}
        dataList={JSON.parse(JSON.stringify(allPosts?.records || []))}
        error={errorAllPosts || deleteEntityProfileError}
        filterData={filterData}
        handlePagination={handlePagination}
        handleSearch={onSearch}
        isAdd={false}
        isError={isErrorAllPosts || deleteEntityProfileIsError}
        loading={isLoadingAllPosts || deleteEntityProfileLoading}
        rowClickHandler={handleView}
        rowNumber={0}
        sortHandleClick={sorting}
        success={deleteEntityProfileSuccess}
        title={t('EntityProfile')}
      />
    </Box>
  )
}

export default EntityProfileList
