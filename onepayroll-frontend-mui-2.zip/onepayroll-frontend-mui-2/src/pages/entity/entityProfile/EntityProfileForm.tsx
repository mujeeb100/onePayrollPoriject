import {
  Avatar, Box,
  Grid,
} from '@mui/material'
import { useGetAllCountryQuery, useGetAllCurrencyQuery } from 'api/globalServices'
import OPRButton from 'components/atoms/button/OPRButton'
import OPRLabel from 'components/atoms/label/OPRLabel'
import OPRDatePickerControl from 'components/molecules/OPRDatePickerControl/OPRDatePickerControl'
import OPRInputControl from 'components/molecules/OPRInputControl'
import OPRResponsiveGrid from 'components/molecules/OPRResponsiveGrid'
import OPRSelectorControl from 'components/molecules/OPRSelectorControl/OPRSelectorControl'
import OPRTextArea from 'components/molecules/OPRTextArea/OPRTextArea'
import { t } from 'i18next'
import React, { useEffect, useRef, useState } from 'react'
import { useLocation } from 'react-router-dom'
import { routes } from 'routes/routes'
import { getParamsValue } from 'utils'

import EntityProfile from './entityProfile.json'

interface MessageProps {
  text?: string;
  important?: boolean;
}
const defaultValue = {
  countryLocalization: 'Hong Kong',
  status: 'Active',

}
const EntityProfileForm = React.forwardRef(({
  handleOnChange, errors, handleChange, isEditable, values, setValues, imageByteCode,
  setImageByteCode, selectedEntity, setSelectedEntity, setImage, image,

}:any, ref) => {
  const location: any = useLocation()
  const { id, viewUrl } = getParamsValue(location, routes.createEntityProfile)
  const [selectedPayrollMonth, setSelectedPayrollMonth] = useState(values?.goLivePayrollMonth || '')

  const [mode, setMode] = useState('view') // Default mode is edit
  const [imageValidationError, setImageValidation] = useState('')
  const inputRef = useRef<HTMLInputElement>(null)
  const avatarRef = useRef<HTMLDivElement>(null)
  // const [image, setImage] = useState<string>('')
  // const [imageByteCode, setImageByteCode] = useState<string>('')
  // const [selectedEntity, setSelectedEntity] = useState({})
  const [showButtons, setShowButtons] = useState(false)

  const {
    data: allData,

  } = useGetAllCountryQuery('')
  const {
    data: allPostsCurrency,

  } = useGetAllCurrencyQuery('')

  const handlePayrollMonthChange = (text:any) => {
    const selectedMonth = text?.name || ''
    setSelectedPayrollMonth(selectedMonth)
    handleOnChange('goLivePayrollMonth', selectedMonth)
  }

  const handleImageChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = event.target.files?.[0]
    if (!selectedFile) return

    const allowedTypes = ['image/png', 'image/jpeg', 'image/jpg']
    if (!allowedTypes.includes(selectedFile.type)) {
      setImageValidation('Please select a valid file type. Allowed types: jpeg, png')
      // Clear the input value to ensure the error message displays when selecting the same file type again
      event.target.value = ''
      return
    }
    setImageValidation('')

    if (selectedFile.size > 10 * 1024 * 1024) {
      setImageValidation('Image size should not exceed 10MB')
      // Clear the input value to ensure the error message displays when selecting the same file type again
      event.target.value = ''
      return
    }

    const reader = new FileReader()
    reader.readAsDataURL(selectedFile)
    reader.onload = () => {
      if (typeof reader.result === 'string') {
        const base64Image = reader.result.split(',')[1]
        setImage(reader.result)
        setImageByteCode(base64Image)
        setSelectedEntity((prev:any) => ({ ...prev, companyLogo: base64Image }))
        if (avatarRef.current) {
          avatarRef.current.style.backgroundImage = `url(${reader.result})`
        }
      }
    }
    reader.onerror = (error) => console.error('Error:', error)
  }
  const handleImageInput = () => inputRef.current?.click()
  console.log('aaaaaaaaaaaa', selectedEntity)
  useEffect(() => {
    if (id === null) {
      setValues(defaultValue)
    }
  }, [])
  return (

    <Box sx={{ display: 'flex' }}>

      <Box>
        <div style={{ display: 'block', width: '100%', margin: '30px 0px 20px' }}>
          <OPRLabel variant="h3">General information</OPRLabel>
        </div>
        <OPRResponsiveGrid>
          <Grid item md={2} sm={1} xs={1}>

            <div>
              <Avatar
                ref={avatarRef}
                alt="Company Logo"
                src={image}
                sx={{ width: 100, height: 100 }}
              />
              <input
                ref={inputRef}
                accept="image/png, image/jpeg, image/jpg"
                className="hidden"
                // disabled={location.pathname === routes.viewEntityProfile}
                disabled={isEditable}
                name="companyLogo"
                // style={{ display: location.pathname !== routes.viewEntityProfile ? 'none' : 'block' }}
                style={{ display: 'none' }}
                type="file"
                onChange={handleImageChange}
              />
              {!isEditable && (
                <OPRButton
                  color="primary"
                  sx={{ borderRadius: '110px', marginTop: '20px' }}
                  variant="outlined"
                  onClick={handleImageInput}
                >
                  Change logo
                </OPRButton>
              )}
            </div>
            {imageValidationError && (
              <OPRLabel sx={{ color: '#DA3237' }} variant="body2">
                {imageValidationError}
              </OPRLabel>
            )}
          </Grid>
          <Grid item md={2} sm={1} xs={1} />
          <Grid item md={2} sm={1} xs={1}>
            <OPRInputControl
              disabled={location.pathname !== `${routes.editEntityProfile}`}
              error={t(errors?.entityCode)}
              label="Entity ID"
              name="entityCode"
              value={values?.entityCode}
              onChange={handleChange}
            />
          </Grid>
          <Grid item md={2} sm={1} xs={1}>
            <OPRInputControl
              error={t(errors?.entityName)}
              isEditable={isEditable}
              label="entity_profile_name"
              name="entityName"
              value={values?.entityName}
              onChange={handleChange}
            />
          </Grid>
          <Grid item md={2} sm={1} xs={1}>
            <OPRInputControl
              error={t(errors?.entityLocalName)}
              isEditable={isEditable}
              label="entity_profile_local_name"
              name="entityLocalName"
              optionalText="Optional"
              value={values?.entityLocalName}
              onChange={handleChange}
            />
          </Grid>
          <Grid item md={2} sm={1} xs={1}>
            <OPRInputControl
              error={t(errors?.companyRegistrationNo)}
              isEditable={isEditable}
              label="Company registration number"
              name="companyRegistrationNo"
              optionalText="Optional"
              value={values?.companyRegistrationNo}
              onChange={handleChange}
            />
          </Grid>
          <Grid item md={2} sm={1} xs={1}>
            <OPRSelectorControl
              isEditable
              defaultValue={{ countryName: 'Hong Kong' }}
              keyName="countryName"
              label="Country"
              multiple={false}
              name="countryLocalization"
              options={allData?.records || []}
              placeholder="Select an option"
              value={{
                countryCode: values?.countryLocalization || 'HKD',
                countryName: values?.countryLocalization
                  ? allData?.records.find((record: any) => record.countryCode === values.countryLocalization)?.countryName || 'Hong Kong'
                  : 'Hong Kong',
              }}
              valueKey="countryName"
              onChange={(text:any) => {
                handleOnChange('countryLocalization', text?.countryCode)
              }}
            />

          </Grid>
          <Grid item md={2} sm={1} xs={1}>
            <OPRSelectorControl
              isEditable
              defaultValue={{ name: 'Active', values: 'Active' }}
              disabled={location.pathname !== `${routes.editEntityProfile}`}
              error={errors?.status}
              keyName="name"
              label={t('holiday_calender_status')}
              multiple={false}
              name="status"
              options={[{ name: 'Active', values: 'Active' }, { name: 'Inactive', values: 'Inactive' }]}
              placeholder="Select an option"
              value={[{ name: 'Active', values: 'Active' }, { name: 'Inactive', values: 'Inactive' }]?.find((o:any) => o?.values === values?.status) || {}}
              valueKey="name"
              onChange={(text:any) => {
                handleOnChange('status', text?.values)
              }}
            />
          </Grid>

          <Grid item md={4} sm={6} xs={12}>
            <OPRTextArea
              error={errors?.remarks}
              isEditable={isEditable}
              label={t('holiday_calender_remarks')}
              name="remarks"
              optionalText="Optional"
              value={values?.remarks}
              onChange={handleChange}
            />
          </Grid>
          <div style={{ display: 'block', width: '100%', margin: '30px 20px 20px' }}>
            <OPRLabel variant="h3">Contact information</OPRLabel>
          </div>
          <Grid item md={2} sm={1} xs={1}>
            <OPRInputControl
              error={t(errors?.contactPerson)}
              isEditable={isEditable}
              label="entity_profile_contact_person"
              name="contactPerson"
              optionalText="Optional"
              value={values?.contactPerson}
              onChange={handleChange}
            />
          </Grid>
          <Grid item md={2} sm={1} xs={1}>
            <OPRInputControl
              error={errors?.phoneNumber}
              isEditable={isEditable}
              label="entity_profile_contact_number"
              name="phoneNumber"
              optionalText="Optional"
              value={values?.phoneNumber}
              onChange={handleChange}
            />
          </Grid>
          <Grid item md={2} sm={1} xs={1}>
            <OPRInputControl
              error={t(errors?.emailAddress)}
              isEditable={isEditable}
              label="entity_profile_email"
              name="emailAddress"
              optionalText="Optional"
              value={values?.emailAddress}
              onChange={handleChange}
            />
          </Grid>
          <Grid item md={2} sm={1} xs={1} />
          <Grid item md={2} sm={1} xs={1}>
            <OPRInputControl
              error={t(errors?.registeredAddressLine1)}
              isEditable={isEditable}
              label="entity_profile_registered_address_line_1"
              name="registeredAddressLine1"
              optionalText="Optional"
              value={values?.registeredAddressLine1}
              onChange={handleChange}
            />
          </Grid>
          <Grid item md={2} sm={1} xs={1}>
            <OPRInputControl
              error={t(errors?.registeredAddressLine2)}
              isEditable={isEditable}
              label="entity_profile_registered_address_line_2"
              name="registeredAddressLine2"
              optionalText="Optional"
              value={values?.registeredAddressLine2}
              onChange={handleChange}
            />
          </Grid>
          <Grid item md={2} sm={1} xs={1}>
            <OPRInputControl
              error={t(errors?.registeredAddressLine3)}
              isEditable={isEditable}
              label="entity_profile_registered_address_line_3"
              name="registeredAddressLine3"
              optionalText="Optional"
              value={values?.registeredAddressLine3}
              onChange={handleChange}
            />
          </Grid>

          <Grid item md={2} sm={1} xs={1}>
            <OPRSelectorControl
              isEditable={isEditable}
              keyName="countryName"
              label=" Registered address - Country"
              multiple={false}
              name="registeredAddressCountry"
              options={(allData?.records || [])}
              placeholder="Select an option"
              value={
                { countryName: values?.registeredAddressCountry, countryCode: values?.registeredAddressCountry }
              }
              valueKey="countryCode"
              onChange={(text:any) => {
                handleOnChange('registeredAddressCountry', text?.countryCode)
              }}
            />
          </Grid>
          <div style={{ display: 'block', width: '100%', margin: '30px 20px 20px' }}>
            <OPRLabel variant="h3">Payroll information</OPRLabel>
          </div>
          <Grid item md={2} sm={1} xs={1}>
            <OPRInputControl
              error={errors?.goLivePayrollMonthYear}
              isEditable={isEditable}
              label="Go live payroll year"
              name="goLivePayrollMonthYear"
              optionalText="Optional"
              value={values?.goLivePayrollMonthYear}
              onChange={handleChange}
            />
          </Grid>
          <Grid item md={2} sm={1} xs={1}>
            <OPRSelectorControl
              isEditable={isEditable}
              keyName="name"
              label="Go live payroll month"
              multiple={false}
              name="goLivePayrollMonth"
              optionalText="Optional"
              options={JSON.parse(
                JSON.stringify(EntityProfile?.months || []),
              )}
              placeholder="Select an option"
              value={
                { name: values?.goLivePayrollMonth, id: values?.goLivePayrollMonth }
              }
              valueKey="name"
              // onChange={(text:any) => {
              //   handleOnChange('goLivePayrollMonth', text?.name)
              // }}
              onChange={handlePayrollMonthChange}
            />
          </Grid>

          <Grid item md={2} sm={1} xs={1}>
            <OPRInputControl
              error={t(errors?.currentPayrollMonthYear)}
              isEditable={isEditable}
              label="Current payroll year"
              name="currentPayrollMonthYear"
              optionalText="Optional"
              value={values?.currentPayrollMonthYear}
              onChange={handleChange}
            />
          </Grid>

          <Grid item md={2} sm={1} xs={1}>
            <OPRSelectorControl
              isEditable={isEditable}
              keyName="name"
              label="Current payroll month"
              multiple={false}
              name="currentPayrollMonth"
              optionalText="Optional"
              options={JSON.parse(
                JSON.stringify(EntityProfile?.months || []),
              )}
              placeholder="Select an option"
              value={
                { name: values?.currentPayrollMonth, id: values?.currentPayrollMonth }
              }
              // value={values?.currentPayrollMonth?.name}
              valueKey="name"
              onChange={(text:any) => {
                handleOnChange('currentPayrollMonth', text?.name)
              }}
            />
          </Grid>
          <Grid item md={2} sm={1} xs={1}>
            <OPRSelectorControl
              isEditable={isEditable}
              keyName="currencyName"
              label="entity_profile_base_currency"
              multiple={false}
              name="baseCurrency"
              options={(allPostsCurrency?.records || [])}
              placeholder="Select an option"
              value={
                { currencyName: values?.baseCurrency, currencyCode: values?.baseCurrency }
              }
              valueKey="currencyCode"
              onChange={(text:any) => {
                handleOnChange('baseCurrency', text?.currencyCode)
              }}
            />
          </Grid>
          {selectedPayrollMonth && (
            <Grid item md={2} sm={1} xs={1}>
              <OPRDatePickerControl
                error={errors?.startDateForAuditLogging}
                isEditable={isEditable}
                label={t('Start date for audit logging')}
                name="startDateForAuditLogging"
                value={values?.startDateForAuditLogging || null}
                onChange={(date) => {
                  handleOnChange('startDateForAuditLogging', date)
                }}
              />
            </Grid>
          )}
        </OPRResponsiveGrid>
      </Box>
      {/* </OPRInnerFormLayout> */}
      {/* </form> */}
    </Box>
  )
})
export default EntityProfileForm
