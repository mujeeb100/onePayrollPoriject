import { useTheme } from '@emotion/react'
import {
  Box, FormControlLabel, Radio, RadioGroup,
} from '@mui/material'
import {
  useEntityProfileCreateMutation,
  useEntityProfileUpdateMutation, useGetAllEntityChangeProfileQuery, useLazyGetEntityProfileByIdQuery,
} from 'api/entityServices'
import { ReactComponent as SuccessIcon } from 'assets/svg-icons/Tick.svg'
import { ErrorIcon, Info } from 'assets/svg-images/SvgComponents'
import OPRButton from 'components/atoms/button/OPRButton'
import OPRLabel from 'components/atoms/label/OPRLabel'
import { CustomDialog } from 'components/atoms/modal/OPRModal'
import OPRAlertControl from 'components/organism/OPRAlertControl'
import { OPRInnerFormLayout } from 'components/organism/OPRInnerFormLayout'
import { validationSchemaEntityProfile } from 'constants/validate'
import { useEditable } from 'hooks/useEdit'
import useForm from 'hooks/useForm'
import { useEffect } from 'react'
import * as React from 'react'
import { useLocation, useNavigate } from 'react-router-dom'
import { routes } from 'routes/routes'
import { getParamsValue, setRouteValues } from 'utils'

import EntityProfileForm from './EntityProfileForm'

interface MessageProps {
  text?: string;
  important?: boolean;
}

function EntityProfile() {
  const myRef:any = React.useRef()
  const [isDelete, setIsDelete] = React.useState(false)
  const location: any = useLocation()
  const theme:any = useTheme()
  const navigate = useNavigate()
  const [openModal, setModal] = React.useState(false) // Corrected typo here
  const [deactivate, setDeactivate] = React.useState(false)
  const [showSuccessMessage, setShowSuccessMessage] = React.useState(false)
  const [userRoleOperation, setRoleOperation] = React.useState('')
  const { id, viewUrl } = getParamsValue(location, routes.createEntityProfile)
  const [value, setValue] = React.useState(0)
  const [image, setImage] = React.useState<string>('')
  const [imageByteCode, setImageByteCode] = React.useState<string>('')
  const [selectedEntity, setSelectedEntity] = React.useState({})

  const {
    values,
    setValues,
    errors,
    handleChange,
    setErrors,
    handleFormSubmit,
    handleOnChange,
  } = useForm(validationSchemaEntityProfile)
  const {
    isEditable,
    setEditable,
  } = useEditable()

  const [updateEntityProfileById, {
    data: updatedEntityProfileByIdResponse,
    error: updatedEntityProfileByIdError,
    isLoading: updatedEntityProfileByIdLoading,
    isSuccess: updatedEntityProfileByIdSuccess,
    isError: updatedEntityProfileByIdIsError,
  }] = useLazyGetEntityProfileByIdQuery()

  const [
    updateEntityProfile,
    {
      data: updatedDataResponse,
      error: updatedEntityProfileError,
      isLoading: updatedEntityProfileLoading,
      isSuccess: updatedEntityProfileSuccess,
      isError: updatedEntityProfileIsError,
    },
  ] = useEntityProfileUpdateMutation()

  const [
    createEntityProfile,
    {
      data: createdEntityProfileData,
      error: createdEntityProfileError,
      isLoading: createdEntityProfileLoading,
      isSuccess: createdEntityProfileSuccess,
      isError: createdEntityProfileIsError,
    },
  ] = useEntityProfileCreateMutation()

  useEffect(() => {
    if (id) {
      updateEntityProfileById(id)
      setEditable(viewUrl)
    }
  }, [])
  useEffect(() => {
    if (id) {
      setValues(updatedEntityProfileByIdResponse?.data)
    } else {
      setValues(location.state ? location.state : {})
    }
  }, [updatedEntityProfileByIdResponse?.data])

  useEffect(() => {
    if (updatedEntityProfileByIdResponse) {
      setValues(updatedEntityProfileByIdResponse.data)
      setImage(`data:image/jpg;base64,${updatedEntityProfileByIdResponse.data.companyLogo}`)
      setImageByteCode(updatedEntityProfileByIdResponse.data.companyLogo)
    }
  }, [updatedEntityProfileByIdResponse])

  // const onScreenClose:any = (item: any) => {
  //   setEditable(item)
  //   setValues({})
  // }

  const {
    data: changeEntityProfile,
    error: createchangeEntityProfilesBankAccountError,
    isLoading: isLoadingchangeEntityProfile,
    isSuccess: isSuccesschangeEntityProfile,
    isError: isErrorchangeEntityProfile,
    error: errorchangeEntityProfile,
  } = useGetAllEntityChangeProfileQuery('')

  useEffect(() => {

  }, [changeEntityProfile])

  const handleConfirm = () => {
    if (userRoleOperation === 'Edit Entity') {
      setEditable(true)
      navigate(setRouteValues(`${routes.editEntityProfile}`, { id }))
      setModal(false)
    } else if (userRoleOperation === 'Deactivate Entity') {
      setModal(false)
      setDeactivate(true)
    } else {
      setModal(false)
      setDeactivate(true)
    }
  }

  const handleDeactivateConfirm = () => {
    updateEntityProfile({
      ...updatedEntityProfileByIdResponse.data,
      status: updatedEntityProfileByIdResponse?.data?.status === 'Active' ? 'Inactive' : 'Active',
    })
    setDeactivate(false)
  }
  useEffect(() => {
    if (updatedEntityProfileByIdResponse === true) {
      setShowSuccessMessage(true)
    }
  }, [updatedEntityProfileByIdResponse])

  const handleActivateConfirm = () => {
    updateEntityProfile({
      ...updatedEntityProfileByIdResponse.data,
      status: updatedEntityProfileByIdResponse?.data?.status === 'Active' ? 'Inactive' : 'Active',
    })
    setDeactivate(false)
  }
  const handleBack = () => {
    setEditable(true)
  }
  const handleSubmit = async () => {
    if (isEditable) {
      if (id === null) {
        await createEntityProfile({ ...values, entityCode: values.entityCode.trim() })
      } else {
        await updateEntityProfile({ ...values, companyLogo: imageByteCode })
        // After successful update, update the state with the new companyLogo
        setImageByteCode(values?.companyLogo) // Assuming values.companyLogo contains the updated logo data
      }
    } else {
      setEditable(true)
    }
  }

  return (
    <>
      <OPRAlertControl
        callBack={(type) => {
          // if (type === 'success') {
          //   navigate(-1)
          // }
        }}
        error={createdEntityProfileError || updatedEntityProfileError}
        handleEditable={setEditable}
        handleSetValue={setValues}
        handleSubmit={handleSubmit}
        isError={createdEntityProfileError || updatedEntityProfileError}
        isLoading={
          createdEntityProfileLoading
        || updatedEntityProfileLoading
        || updatedEntityProfileByIdLoading
        }
        isSuccess={updatedEntityProfileSuccess}
        name={values?.entityName}
        title={values?.entityName}
        type={id ? 'Update' : 'New'}
      />
      <Box sx={{ display: 'flex', flexDirection: 'column' }}>
        {openModal && (

          <CustomDialog
            CustomStyles={{ borderRadius: '16px' }}
            isOpen={openModal}
            type="loader"
          >
            <OPRLabel variant="h4">Edit Entity Profile</OPRLabel>
            <RadioGroup
              row
              aria-labelledby="demo-row-radio-buttons-group-label"
              name="row-radio-buttons-group"
              sx={{ display: 'flex', flexDirection: 'column' }}
              value={userRoleOperation}
              onChange={(e) => {
                setRoleOperation(e.target.value)
              }}
            >

              <FormControlLabel control={<Radio />} label="Edit Entity" value="Edit Entity" />
              {/* Render appropriate option based on entity status */}
              {updatedEntityProfileByIdResponse?.data?.status === 'Active' ? (
                <FormControlLabel control={<Radio />} label="Deactivate Entity" value="Deactivate Entity" />
              ) : (
                <FormControlLabel control={<Radio />} label="Activate Entity" value="Activate Entity" />
              )}
            </RadioGroup>
            <Box sx={{
              display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: 5,
            }}
            >
              <OPRButton
                color="info"
                variant="text"
                onClick={() => {
                  setModal(false)
                }}
              >
                Cancel
              </OPRButton>
              <OPRButton
                color="info"
                variant="text"
                onClick={handleConfirm}
              >
                Continue
              </OPRButton>
            </Box>
          </CustomDialog>
        ) }

        {changeEntityProfile === true ? (
          <CustomDialog
            CustomStyles={{ borderRadius: '16px' }}
            isOpen={deactivate}
            type="loader"
          >
            <div style={{ marginBottom: '15px' }}>
              <OPRLabel variant="h5">
                Are you sure you want to
                {' '}
                {updatedEntityProfileByIdResponse?.data?.status === 'Active' ? 'Deactivate' : 'Activate'}
                {' '}
                the entity?
              </OPRLabel>
            </div>
            <Box
              className="pop-up"
              sx={{
                display: 'flex',
                padding: '12px',
                gap: '12px',
                alignItems: 'flex-start',
                borderRadius: '4px',
                alignSelf: 'stretch',
                backgroundColor: `${theme.palette.Invite.main}`,
                marginTop: 1,
              }}
            >
              <Info />
              <OPRLabel
                CustomStyles={{
                  backgroundColor: `${theme.palette.Invite.main}`,
                }}
                backgroundColor={theme.palette.Invite.main}
                variant="body2"
              >
                {updatedEntityProfileByIdResponse?.data?.status === 'Active'
                  ? `Deactivating ${updatedEntityProfileByIdResponse?.data?.entityName} means the users assigned to the entity will no longer have access to the entity.`
                  : `Activating ${updatedEntityProfileByIdResponse?.data?.entityName} means the users assigned to the entity will have access to the entity.`}

              </OPRLabel>
            </Box>
            <Box sx={{
              display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: 5,
            }}
            >
              <OPRButton color="info" variant="text" onClick={() => setDeactivate(false)}>
                Cancel
              </OPRButton>
              <OPRButton
                color="info"
                style={{
                  color: 'var(--red-red-500-da-3237, #DA3237)',
                  borderRadius: '110px',
                  border: '1px solid var(--red-red-500-da-3237, #DA3237)',
                }}
                variant="text"
                onClick={() => {
                  updatedEntityProfileByIdResponse?.data?.status === 'Active' ? handleDeactivateConfirm() : handleActivateConfirm()
                }}
              >
                {updatedEntityProfileByIdResponse?.data?.status === 'Active' ? 'Deactivate' : 'Activate'}

              </OPRButton>
            </Box>
          </CustomDialog>

        ) : (

          <CustomDialog
            CustomStyles={{ borderRadius: '16px' }}
            isOpen={deactivate}
            type="loader"
          >
            <div style={{ marginBottom: '15px' }}>

              <OPRLabel variant="h5">
                {' '}
                {updatedEntityProfileByIdResponse?.data?.status === 'Active'
                  ? 'Unable to deactivate the entity'
                  : 'Unable to activate the entity'}
              </OPRLabel>
            </div>

            <Box
              className="pop-up"
              sx={{
                display: 'flex',
                padding: '12px',
                gap: '12px',
                alignItems: 'flex-start',
                borderRadius: '4px',
                alignSelf: 'stretch',
                backgroundColor: `${theme.palette.Invite.main}`,
                marginTop: 1,
              }}
            >
              <ErrorIcon />
              <OPRLabel
                CustomStyles={{
                  backgroundColor: `${theme.palette.Invite.main}`,
                }}
                backgroundColor={theme.palette.Invite.main}
                variant="body2"
              >
                The action cannot be completed as the entity is still associated with one or more active pay cycle.
              </OPRLabel>
            </Box>
            <Box sx={{
              display: 'flex', justifyContent: 'flex-end', marginTop: 5,
            }}
            >
              <OPRButton color="info" variant="text" onClick={() => setDeactivate(false)}>
                Close
              </OPRButton>
            </Box>
          </CustomDialog>
        )}

        {showSuccessMessage && (
          <CustomDialog
            CustomStyles={{ borderRadius: '16px' }}
            isOpen={isEditable}
            type="loader"
          >
            <div
              className="AtomPopupTitleStrip"
              style={{
                width: '100%', flexDirection: 'column', justifyContent: 'flex-start', alignItems: 'flex-start', gap: 16, display: 'inline-flex',
              }}
            >
              <div
                className="Header"
                style={{
                  alignSelf: 'stretch', justifyContent: 'flex-start', alignItems: 'flex-start', gap: 8, display: 'inline-flex',
                }}
              >
                <div
                  className="Icon"
                  style={{
                    paddingTop: 5, paddingBottom: 5, justifyContent: 'flex-start', alignItems: 'flex-start', display: 'flex',
                  }}
                >
                  <div className="Tick" style={{ width: 24, height: 24, position: 'relative' }}>
                    <SuccessIcon />
                  </div>
                </div>
                <div
                  className="Text"
                  style={{
                    flex: '1 1 0', flexDirection: 'column', justifyContent: 'flex-start', alignItems: 'flex-start', display: 'inline-flex',
                  }}
                >
                  <OPRLabel CustomStyles={{ marginTop: 2 }} variant="h4">
                    Entity
                    {' '}
                    {updatedEntityProfileByIdResponse?.data?.status === 'Active' ? 'Deactivate' : 'Activate'}
                  </OPRLabel>
                  <OPRLabel
                    CustomStyles={{
                      marginTop: '12px',
                      display: 'flex',
                      alignItems: 'center',
                      gap: '12px',
                    }}
                    variant="body1"
                  >
                    {`${updatedEntityProfileByIdResponse?.data?.entityName}  has been ${updatedEntityProfileByIdResponse?.data?.status === 'Active' ? 'Deactivate' : 'Activate'}.`}
                  </OPRLabel>
                </div>
              </div>
            </div>

            <Box sx={{
              display: 'flex', justifyContent: 'flex-end', marginTop: 5,
            }}
            >

              <OPRButton
                color="info"
                variant="text"
                onClick={() => setShowSuccessMessage(false)} // Close the success message dialog
              >
                Close
              </OPRButton>
            </Box>
          </CustomDialog>
        )}

        <OPRInnerFormLayout
          isEditUser
          isHandleContinueClick
          error={false}
          handleCancelClick={() => navigate(-1)}
          handleContinueClick={handleSubmit}
          handleEditable={() => handleBack()}
          handleUserCreate={() => {
            setModal(true)
          }}
          isBackButton={isEditable}
          isLoading={updatedEntityProfileLoading}
          pageType="detailsPage"
          // subtitle={isEditable ? 'Please check the user details below.' : 'All fields are mandatory except those marked optional'}
          subtitle={viewUrl ? `Entity code: ${updatedEntityProfileByIdResponse?.data.entityCode}` : 'All field to mandatory expect those mark optional'}
          title={id ? updatedEntityProfileByIdResponse?.data.entityName : 'Entity code:'}
        // title={id ? `${updatedClientGroupEntitiesByIdResponse?.data?.entityName}` : 'Client Group Profile'}
        >
          <Box>
            <form style={{ display: 'flex', width: '100% ' }} onSubmit={(e) => handleFormSubmit(e, handleSubmit)}>

              <EntityProfileForm
                ref={myRef}
                errors={errors}
                handleChange={handleChange}
                handleOnChange={handleOnChange}
                image={image}
                imageByteCode={imageByteCode}
                isEditable={isEditable}
                profileId={id}
                selectedEntity={selectedEntity}
                setEditable={setEditable}
                setErrors={setErrors}
                setImage={setImage}
                setImageByteCode={setImageByteCode}
                setSelectedEntity={setSelectedEntity}
                setValues={setValues}
                values={values}

              />
            </form>
          </Box>

        </OPRInnerFormLayout>
      </Box>
    </>
  )
}

export default EntityProfile
