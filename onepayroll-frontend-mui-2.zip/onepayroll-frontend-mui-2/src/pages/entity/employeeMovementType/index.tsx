// EmployeeMovement
// import { EmployeeMovementColumnMappings } from 'constants/exportColumnMappings'
import '../../../styles/style.css'

import {
  Box,
} from '@mui/material'
import { useEmployeeMovementDeleteMutation, useGetAllEmployeeMovementQuery } from 'api/entityServices'
import { entityEmployeeMovementTypeColumn } from 'components/atoms/table/OPRTableConstant'
import { OPRInnerListLayout } from 'components/organism/OPRInnerLayoutList'
import apiEndPoint from 'constants/apiEndPoint'
import { EmployeeMovementColumnMappings } from 'constants/exportColumnMappings'
import { useTranslatedColumnsForPDF } from 'hooks/useTranslatedColumnsForPDF'
import { t } from 'i18next'
import React, { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { routes } from 'routes/routes'
import {
  generateFilterUrl, getAPIWithEntityUrl, getEnv, setRouteValues,
} from 'utils'

function EmployeeMovementList() {
  const navigate: any = useNavigate()
  const [selelctedDelete, setSelelctedDelete]:any = useState({
    data: {},
    isDelete: false,
    name: '',
  })
  const [filterData, setFilterData]:any = useState({
    pageNumber: 1,
    pageSize: 20,
    totalItems: 0,
    orderByAsc: true,
    sortBy: '',
    SearchText: '',
  })
  const {
    data: allPosts,
    isLoading: isLoadingAllPosts,
    isSuccess: isSuccessAllPosts,
    isError: isErrorAllPosts,
    error: errorAllPosts,
    refetch: refetchAllPosts,
  } = useGetAllEmployeeMovementQuery(generateFilterUrl(filterData))

  const [deleteEmployeeMovementById,
    {
      data: deleteEmployeeMovementResponse,
      error: deleteEmployeeMovementError,
      isLoading: deleteEmployeeMovementLoading,
      isSuccess: deleteEmployeeMovementSuccess,
      isError: deleteEmployeeMovementIsError,
    }] = useEmployeeMovementDeleteMutation()

  const sorting = (
    event: React.MouseEvent<unknown>,
    property: keyof any,
  ) => {
    const isAsc = filterData.sortBy === property && filterData.orderByAsc === true
    setFilterData({ ...filterData, orderByAsc: !isAsc, sortBy: property })
    // setOrder(isAsc ? 'desc' : 'asc')
    // setOrderBy(property)
  }

  useEffect(() => {
    setFilterData({ ...filterData, totalItems: allPosts?.totalItems ? allPosts?.totalItems : 0 })
  }, [allPosts?.pageNumber, filterData.sortBy, filterData.orderByAsc, allPosts?.totalItems])

  const onSearch = (e: any, data: any) => {
    setFilterData({ ...filterData, ...data })
  }

  const handlePagination = (pageNumber: number, pageSize: number) => {
    setFilterData({ ...filterData, pageNumber })
  }

  const viewAcoount = (data: any, type:string) => {
    if (type === 'Edit movement type') {
      navigate(
        setRouteValues(`${routes.editemployeeMovement}`, {
          id: data.id,
        }),
      )
    } else if (type === 'Delete movement type') {
      // deleteEmployeeMovementById(`Id=${data.id}`)
      setSelelctedDelete({ data, isDelete: true, name: data.movementDescription })
    } else {
      navigate(
        setRouteValues(`${routes.viewemployeeMovement}`, {
          id: data.id,
        }),
      )
    }
  }

  const handleView = (data: any) => {
    navigate(
      setRouteValues(`${routes.viewemployeeMovement}`, {
        id: data.id,
        view: true,
      }),
    )
  }
  // handle Delete
  const handleDelete = (data:any) => {
    deleteEmployeeMovementById(`Id=${data.id}`)
  }
  return (
    <Box className="movment-table" sx={{ display: 'flex' }}>
      <OPRInnerListLayout
        isExport
        Search={decodeURIComponent(filterData.SearchText)}
        addHandleClick={() => navigate(routes.createemployeeMovement)}
        columns={entityEmployeeMovementTypeColumn(viewAcoount)}
        dataList={JSON.parse(JSON.stringify(allPosts?.records || []))}
        deleteCallBack={handleDelete}
        error={errorAllPosts || deleteEmployeeMovementError}
        exportProps={{
          data: allPosts?.records,
          fileName: 'EmployeeMovement',
          columns: useTranslatedColumnsForPDF(EmployeeMovementColumnMappings),
          pdf: {
            orientation: 'portrait',
          },
          allRecords: {
            baseURL: getEnv('REACT_APP_UP_BASE_URL', null),
            endpoint: getAPIWithEntityUrl(apiEndPoint.employeeMovementList),
            filterData,
          },
        }}
        filterData={filterData}
        handlePagination={handlePagination}
        handleSearch={onSearch}
        isError={isErrorAllPosts || deleteEmployeeMovementIsError}
        loading={isLoadingAllPosts || deleteEmployeeMovementLoading}
        rowClickHandler={handleView}
        rowNumber={0}
        selelctedUser={selelctedDelete}
        setSelelctedUser={setSelelctedDelete}
        sortHandleClick={sorting}
        success={deleteEmployeeMovementSuccess}
        title={t('Movement types')}
      />
    </Box>
  )
}

export default EmployeeMovementList
