import '../../../styles/style.css'

import { Box, Grid } from '@mui/material'
import {
  useEmployeeMovementCreateMutation,
  useEmployeeMovementUpdateMutation,
  useLazyGetEmployeeMovementByIdQuery,
} from 'api/entityServices'
import OPRInputControl from 'components/molecules/OPRInputControl'
import OPRResponsiveGrid from 'components/molecules/OPRResponsiveGrid'
import OPRSelectorControl from 'components/molecules/OPRSelectorControl/OPRSelectorControl'
import OPRTextArea from 'components/molecules/OPRTextArea/OPRTextArea'
import OPRAlertControl from 'components/organism/OPRAlertControl'
import { OPRInnerFormLayout } from 'components/organism/OPRInnerFormLayout'
import { validationSchemaEmploymentType } from 'constants/validate'
import { useEditable } from 'hooks/useEdit'
import useForm from 'hooks/useForm'
import { t } from 'i18next'
import { useEffect } from 'react'
import { useLocation, useNavigate } from 'react-router-dom'
import { routes } from 'routes/routes'
import { getParamsValue } from 'utils'

interface MessageProps {
  text?: string;
  important?: boolean;

}
const defaultValues = {
  status: true,
  movementType: '',
  movementDescription: '',
  remarks: '',
}
export default function EmployeeMovementForm() {
  const location: any = useLocation()
  // const id = getParamsValue(location, routes.createEmployeeMovement)
  const { id, viewUrl } = getParamsValue(location, routes.createemployeeMovement)

  const { isEditable, setEditable } = useEditable()

  const {
    values,
    setValues,
    errors,
    handleChange,
    handleOnChange,
    setErrors,
    handleFormSubmit,
  } = useForm(validationSchemaEmploymentType)

  const navigate = useNavigate()
  const [
    createEmployeeMovement,
    {
      data: createdEmployeeMovementData,
      error: createdEmployeeMovementError,
      isLoading: createdEmployeeMovementLoading,
      isSuccess: createdEmployeeMovementSuccess,
      isError: createdEmployeeMovementIsError,
    },
  ] = useEmployeeMovementCreateMutation()

  const [
    updateEmployeeMovement,
    {
      data: updatedDataResponse,
      error: updatedEmployeeMovementError,
      isLoading: updatedEmployeeMovementLoading,
      isSuccess: updatedEmployeeMovementSuccess,
      isError: updatedEmployeeMovementIsError,
    },
  ] = useEmployeeMovementUpdateMutation()

  const [
    updateEmployeeMovementById,
    {
      data: updatedEmployeeMovementByIdResponse,
      error: updatedEmployeeMovementByIdError,
      isLoading: updatedEmployeeMovementByIdLoading,
      isSuccess: updatedEmployeeMovementByIdSuccess,
      isError: updatedEmployeeMovementByIdIsError,
    },
  ] = useLazyGetEmployeeMovementByIdQuery()

  useEffect(() => {
    if (id) {
      updateEmployeeMovementById(id)
      setEditable(viewUrl)
    }
  }, [])
  useEffect(() => {
    if (id) {
      setValues(updatedEmployeeMovementByIdResponse?.data)
    } else {
      setValues(location.state ? location.state : {})
    }
  }, [updatedEmployeeMovementByIdResponse?.data])

  // reset the values
  // useEffect(() => {
  //   if (createdEmployeeMovementSuccess) {
  //     setValues({})
  //   }
  // }, [createdEmployeeMovementSuccess])

  useEffect(() => {
    if (id === null) {
      setValues(defaultValues)
    }
  }, [])

  const handleSubmit: any = async () => {
    if (isEditable) {
      if (id === null) {
        await createEmployeeMovement({
          movementType: values?.movementType,
          movementDescription: values?.movementDescription,
          status: values?.status,
          remarks: values?.remarks || '',

        })
      } else {
        await updateEmployeeMovement({
          id: values?.id,
          movementType: values?.movementType,
          movementDescription: values?.movementDescription,
          status: values?.status,
          remarks: values?.remarks || '',

        })
      }
    } else {
      setEditable(true)
    }
  }

  async function editEmployeeMovement() {
    await updateEmployeeMovement({
      id: values?.id,
      movementType: values?.movementType,
      movementDescription: values?.movementDescription,
      status: values?.status,
      remarks: values?.remarks || '',
    })
  }

  const onScreenClose:any = (item: any) => {
    setEditable(item)
    setValues({})
  }

  return (
    <Box sx={{ display: 'flex' }}>
      <form
        style={{ display: 'flex', width: '100% ' }}
        onSubmit={(e) => handleFormSubmit(e, handleSubmit)}
      >
        <OPRAlertControl
          error={createdEmployeeMovementError || updatedEmployeeMovementError}
          handleEditable={setEditable}
          handleSetValue={setValues}
          handleSubmit={handleSubmit}
          isError={createdEmployeeMovementError || updatedEmployeeMovementIsError}
          isLoading={
            createdEmployeeMovementLoading
            || updatedEmployeeMovementLoading
            || updatedEmployeeMovementByIdLoading
          }
          isSuccess={updatedEmployeeMovementSuccess || createdEmployeeMovementSuccess}
          name={values?.movementDescription}
          title={t('EmployeeMovement')}
          type={id ? 'Update' : 'New'}
        />
        <OPRInnerFormLayout
          error={createdEmployeeMovementError || updatedEmployeeMovementError}
          handleCancelClick={() => navigate(-1)}
          handleContinueClick={handleSubmit}
          handleEditable={() => {
            setEditable(true)
          }}
          isBackButton={isEditable}
          isLoading={
            createdEmployeeMovementLoading
            || updatedEmployeeMovementLoading
            || updatedEmployeeMovementByIdLoading
          }
          pageType="detailsPage"
          subtitle={
            isEditable
              ? 'Please check the user details below.'
              : 'All fields are mandatory except those marked optional'
          }
          title={t('ent_emp_move_type_add_btn_title')}
          onScreenClose={onScreenClose}
        >
          <Box>
            <OPRResponsiveGrid>
              <Grid item md={2} sm={1} xs={1}>
                <OPRInputControl
                  disabled={!!id}
                  error={t(errors?.movementType)}
                  isEditable={isEditable}
                  label="ent_emp_move_type_movement_type"
                  name="movementType"
                  value={values?.movementType}
                  onChange={handleChange}
                />
              </Grid>
              <Grid item className="txt-wrp" md={2} sm={1} xs={1}>
                <OPRInputControl
                  error={t(errors?.movementDescription)}
                  isEditable={isEditable}
                  label="ent_emp_move_type_movement_description"
                  name="movementDescription"
                  value={values?.movementDescription}
                  onChange={handleChange}
                />
              </Grid>
              <Grid item md={2} sm={1} xs={1}>
                <OPRSelectorControl
                  defaultValue={{ name: 'Active', values: true }}
                  error={errors?.status}
                  isEditable={isEditable}
                  keyName="name"
                  label={t('holiday_calender_status')}
                  multiple={false}
                  name="status"
                  options={[{ name: 'Active', values: true }, { name: 'Inactive', values: false }]}
                  placeholder="Select an option"
                  value={[{ name: 'Active', values: true }, { name: 'Inactive', values: false }]?.find((o:any) => o?.values === values?.status) || {}}
                  valueKey="name"
                  onChange={(text:any) => {
                    // handleChange({ target: { name: 'countryLocalization', value: text?.countryCode }, persist: () => {} })
                    // setValues({ ...values, countryLocalization: text })
                    handleOnChange('status', text?.values)
                  }}
                />
              </Grid>

              <Grid item md={4} sm={6} xs={12}>
                <OPRTextArea
                  error={t(errors?.remarks)}
                  isEditable={isEditable}
                  label="remarks"
                  name="remarks"
                  optionalText="optional"
                  value={values?.remarks}
                  onChange={handleChange}
                />
              </Grid>
            </OPRResponsiveGrid>
          </Box>
        </OPRInnerFormLayout>
      </form>
    </Box>
  )
}
