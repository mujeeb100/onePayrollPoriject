import {
  Box, Grid,
} from '@mui/material'
import { useFormulaExpressionsCreateMutation, useFormulaExpressionsUpdateMutation, useLazyGetFormulaExpressionsByIdQuery } from 'api/payRollServices'
import OPRInputControl from 'components/molecules/OPRInputControl'
import OPRResponsiveGrid from 'components/molecules/OPRResponsiveGrid'
import OPRAlertControl from 'components/organism/OPRAlertControl'
import { OPRInnerFormLayout } from 'components/organism/OPRInnerFormLayout'
import { formulaSetupValidationSchema } from 'constants/validate'
import { useEditable } from 'hooks/useEdit'
import useForm from 'hooks/useForm'
import { useEffect, useState } from 'react'
import { useLocation, useNavigate } from 'react-router-dom'
import { routes } from 'routes/routes'
import { getParamsValue } from 'utils'

interface MessageProps {
    text?: string;
    important?: boolean;
  }

export default function StandardFormulaForm() {
  const location: any = useLocation()
  const { id, viewUrl } = getParamsValue(location, routes.createFormulaExpression)
  const [selectedTab, handleTabChange] = useState(0)
  const [isModal, setModal] = useState(false)

  const handleTabChangeEvent = (event: React.SyntheticEvent, newValue: number) => {
    handleTabChange(newValue)
  }
  const {
    isEditable,
    setEditable,
  } = useEditable()
  const [editUser, setEditUser] = useState(false)

  const {
    values,
    setValues,
    errors,
    handleChange,
    setErrors,
    handleFormSubmit,
  } = useForm(formulaSetupValidationSchema)

  const navigate = useNavigate()
  const [createFormulaExpressions, {
    data: createdFormulaExpressionsData,
    error: createdFormulaExpressionsError,
    isLoading: createdFormulaExpressionsLoading,
    isSuccess: createdFormulaExpressionsSuccess,
    isError: createdFormulaExpressionsIsError,
  }] = useFormulaExpressionsCreateMutation()

  const [updateFormulaExpressions, {
    data: updatedDataResponse,
    error: updatedFormulaExpressionsError,
    isLoading: updatedFormulaExpressionsLoading,
    isSuccess: updatedFormulaExpressionsSuccess,
    isError: updatedFormulaExpressionsIsError,
  }] = useFormulaExpressionsUpdateMutation()

  const [updateFormulaExpressionsById, {
    data: updatedFormulaExpressionsByIdResponse,
    error: updatedFormulaExpressionsByIdError,
    isLoading: updatedFormulaExpressionsByIdLoading,
    isSuccess: updatedFormulaExpressionsByIdSuccess,
    isError: updatedFormulaExpressionsByIdIsError,
  }] = useLazyGetFormulaExpressionsByIdQuery()

  useEffect(() => {
    if (id) {
      updateFormulaExpressionsById(id)
      setEditable(viewUrl)
    }
  }, [])

  useEffect(() => {
    if (updatedFormulaExpressionsByIdSuccess) {
      setValues(updatedFormulaExpressionsByIdResponse?.data)
    }
  }, [updatedFormulaExpressionsByIdSuccess])

  const handleSubmit:any = async () => {
    // alert('fdgfd')
    if (isEditable) {
      if (id === null) {
        await createFormulaExpressions({
          expressionCode: values.expressionCode,
          description: values.description,
          expression: values.expression,
        })
      } else {
        await updateFormulaExpressions({
          id: values.id,
          expressionCode: values.expressionCode,
          description: values.description,
          expression: values.expression,
        })
      }
    } else {
      setEditable(true)
    }
  }

  return (
    <Box sx={{ display: 'flex' }}>

      {/* <form style={{ display: 'flex', width: '100% ' }} onSubmit={(e) => handleFormSubmit(e, handleSubmit)}> */}
      <OPRAlertControl
        callBack={(type) => {
          // if (type === 'success') {
          //   navigate(-1)
          // }
        }}
        error={createdFormulaExpressionsError || updatedFormulaExpressionsError}
        handleEditable={setEditable}
        handleSetValue={setValues}
        handleSubmit={handleSubmit}
        isError={createdFormulaExpressionsError || updatedFormulaExpressionsError}
        isLoading={createdFormulaExpressionsLoading || updatedFormulaExpressionsLoading || updatedFormulaExpressionsByIdLoading}
        isSuccess={updatedFormulaExpressionsSuccess || createdFormulaExpressionsSuccess}
        name={values?.FormulaExpressionsName}
        // previousUrl={routes.FormulaExpressions}
        title="Formula Expression"
        type={id ? 'Update' : 'New'}
      />
      <OPRInnerFormLayout
        isEditUser
        isHandleContinueClick
        error={createdFormulaExpressionsError || updatedFormulaExpressionsError}
        handleCancelClick={() => navigate(-1)}
        handleContinueClick={handleSubmit}
        handleEditable={() => {
          setEditable(true)
        }}
        handleUserCreate={() => {
          alert('edit expression')
        }}
        isBackButton={isEditable}
        isLoading={createdFormulaExpressionsLoading || updatedFormulaExpressionsLoading || updatedFormulaExpressionsByIdLoading}
        pageType="detailsPage"
        subtitle={isEditable ? 'Please check the user details below.' : 'All field to mandatory expect those marked optional'}
        title="Expression"
        // onScreenClose={onScreenClose}
      >
        <Box sx={{ borderBottom: 1, borderColor: 'divider' }}>
          <Box sx={{ display: 'flex', flexDirection: 'column' }}>
            <OPRResponsiveGrid>
              <Grid item md={2} sm={1} xs={1}>
                <OPRInputControl
                  error={errors?.expressionCode}
                  isEditable={isEditable}
                  label="Expression code"
                  name="expressionCode"
                  value={values?.expressionCode}
                  onChange={handleChange}
                />
              </Grid>
              <Grid item md={12} sm={1} xs={1}>
                <OPRInputControl
                  error={errors?.description}
                  isEditable={isEditable}
                  label="Expression description"
                  name="description"
                  value={values?.description}
                  onChange={handleChange}
                />
              </Grid>
              <Grid item md={12} sm={1} xs={1}>
                <OPRInputControl
                  multiline
                  error={errors?.expression}
                  isEditable={isEditable}
                  label="Expression"
                  name="expression"
                  value={values?.expression}
                  onChange={handleChange}
                />
              </Grid>
            </OPRResponsiveGrid>

          </Box>
        </Box>
      </OPRInnerFormLayout>
      {/* </form> */}
    </Box>
  )
}
