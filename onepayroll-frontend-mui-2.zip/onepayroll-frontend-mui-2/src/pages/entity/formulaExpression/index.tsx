import {
  Box,
} from '@mui/material'
import {
  useFormulaExpressionsDeleteMutation, useGetAllFormulaExpressionsQuery,
} from 'api/payRollServices'
import { formulaExpressionColumn } from 'components/atoms/table/OPRTableConstant'
import { OPRInnerListLayout } from 'components/organism/OPRInnerLayoutList'
import { t } from 'i18next'
import React, { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { routes } from 'routes/routes'
import {
  generateFilterUrl, setRouteValues,
} from 'utils'

function StandardFormulaList() {
  const navigate: any = useNavigate()
  const [filterData, setFilterData]:any = useState({
    pageNumber: 1,
    pageSize: 20,
    totalItems: 0,
    orderByAsc: true,
    sortBy: '',
    SearchText: '',
  })
  const {
    data: allPosts,
    error: createAllPostsFormulaExpressionsError,
    isLoading: isLoadingAllPosts,
    isSuccess: isSuccessAllPosts,
    isError: isErrorAllPosts,
    error: errorAllPosts,
  } = useGetAllFormulaExpressionsQuery(generateFilterUrl(filterData))
  const [deleteFormulaSetupById,
    {
      data: deleteFormulaExpressionsResponse,
      error: deleteFormulaExpressionsError,
      isLoading: deleteFormulaExpressionsLoading,
      isSuccess: deleteFormulaExpressionsSuccess,
      isError: deleteFormulaExpressionsIsError,
    }] = useFormulaExpressionsDeleteMutation()

  const sorting = (
    event: React.MouseEvent<unknown>,
    property: keyof any,
  ) => {
    const isAsc = filterData.sortBy === property && filterData.orderByAsc === true
    setFilterData({ ...filterData, orderByAsc: !isAsc, sortBy: property })
    // setOrder(isAsc ? 'desc' : 'asc')
    // setOrderBy(property)
  }

  useEffect(() => {
    setFilterData({ ...filterData, totalItems: allPosts?.totalItems ? allPosts?.totalItems : 0 })
  }, [allPosts?.pageNumber, filterData.sortBy, filterData.orderByAsc, allPosts?.totalItems])

  const onSearch = (e: any, data: any) => {
    setFilterData({ ...filterData, ...data })
  }
  const handlePagination = (pageNumber: number, pageSize: number) => {
    setFilterData({ ...filterData, pageNumber })
  }
  const viewAcoount = (data: any, type:string) => {
    if (type === 'Edit formula expression') {
      navigate(
        setRouteValues(`${routes.editFormulaExpression}`, {
          id: data.id,
          view: false,
        }),
      )
    } else if (type === 'Delete formula expreesion') {
      deleteFormulaSetupById(`expressionCode=${data.id}`)
    } else {
      // navigate(
      //   setRouteValues(`${routes.formulaExpressionListing}`, {
      //     id: data.id,
      //     view: true,
      //   }),
      // )
    }
    // const id = JSON.stringify(data)
  }
  const handleView = (data: any) => {
    navigate(
      setRouteValues(`${routes.viewFormulaExpression}`, {
        id: data.id,
        view: true,
      }),
    )
  }
  return (
    <Box sx={{ display: 'flex' }}>
      <OPRInnerListLayout
        Search={filterData.SearchText}
        addHandleClick={() => navigate(routes.createFormulaExpression)}
        columns={formulaExpressionColumn(viewAcoount)}
        dataList={JSON.parse(JSON.stringify(allPosts?.records || []))}
        error={errorAllPosts || deleteFormulaExpressionsError}
        filterData={filterData}
        handlePagination={handlePagination}
        handleSearch={onSearch}
        isError={isErrorAllPosts || deleteFormulaExpressionsIsError}
        loading={isLoadingAllPosts || deleteFormulaExpressionsLoading}
        rowClickHandler={handleView}
        rowNumber={0}
        sortHandleClick={sorting}
        success={deleteFormulaExpressionsSuccess}
        title={t('Formula Expression')}
      />
    </Box>
  )
}

export default StandardFormulaList
