import {
  Box,
} from '@mui/material'
import {
  useGetAllGradeQuery,
  useGradeDeleteMutation,
} from 'api/entityServices'
import { entityGradeColumn } from 'components/atoms/table/OPRTableConstant'
import { OPRInnerListLayout } from 'components/organism/OPRInnerLayoutList'
import apiEndPoint from 'constants/apiEndPoint'
import { gradeColumnMappings } from 'constants/exportColumnMappings'
import { useTranslatedColumnsForPDF } from 'hooks/useTranslatedColumnsForPDF'
import { t } from 'i18next'
import React, { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { routes } from 'routes/routes'
import {
  generateFilterUrl, getAPIWithEntityUrl, getEnv, setRouteValues,
} from 'utils'

function GradeList() {
  const navigate: any = useNavigate()
  const [selelctedDelete, setSelelctedDelete]:any = useState({
    data: {},
    isDelete: false,
    name: '',
  })
  const [filterData, setFilterData]:any = useState({
    pageNumber: 1,
    pageSize: 20,
    totalItems: 0,
    orderByAsc: true,
    sortBy: '',
    SearchText: '',
  })
  const {
    data: allPosts,
    isLoading: isLoadingAllPosts,
    isSuccess: isSuccessAllPosts,
    isError: isErrorAllPosts,
    error: errorAllPosts,
    refetch: refetchAllPosts,
  } = useGetAllGradeQuery(generateFilterUrl(filterData))

  const [deleteGradeById,
    {
      data: deleteGradeResponse,
      error: deleteGradeError,
      isLoading: deleteGradeLoading,
      isSuccess: deleteGradeSuccess,
      isError: deleteGradeIsError,
    }] = useGradeDeleteMutation()
  const sorting = (
    event: React.MouseEvent<unknown>,
    property: keyof any,
  ) => {
    const isAsc = filterData.sortBy === property && filterData.orderByAsc === true
    setFilterData({ ...filterData, orderByAsc: !isAsc, sortBy: property })
    // setOrder(isAsc ? 'desc' : 'asc')
    // setOrderBy(property)
  }

  useEffect(() => {
    setFilterData({ ...filterData, totalItems: allPosts?.totalItems ? allPosts?.totalItems : 0 })
  }, [allPosts?.pageNumber, filterData.sortBy, filterData.orderByAsc, allPosts?.totalItems])

  const onSearch = (e: any, data: any) => {
    setFilterData({ ...filterData, ...data })
  }
  const handlePagination = (pageNumber: number, pageSize: number) => {
    setFilterData({ ...filterData, pageNumber })
  }

  const viewAcoount = (data: any, type:string) => {
    if (type === 'Edit Grade') {
      navigate(
        setRouteValues(`${routes.editGrade}`, {
          id: data.id,
        }),
      )
    } else if (type === 'Delete Grade') {
      setSelelctedDelete({ data, isDelete: true, name: data.gradeDescription })
    } else {
      navigate(
        setRouteValues(`${routes.viewGrade}`, {
          id: data.id,
        }),
      )
    }
  }

  const handleView = (data: any) => {
    navigate(
      setRouteValues(`${routes.viewGrade}`, {
        id: data.id,
        view: true,
      }),
    )
  }
  // handle Delete
  const handleDelete = (data: any) => {
    deleteGradeById(`Id=${data.id}`)
  }

  return (
    <Box sx={{ display: 'flex' }}>
      <OPRInnerListLayout
        isExport
        Search={decodeURIComponent(filterData.SearchText)}
        addHandleClick={() => navigate(routes.createGrade)}
        columns={entityGradeColumn(viewAcoount)}
        dataList={JSON.parse(JSON.stringify(allPosts?.records || []))}
        deleteCallBack={handleDelete}
        error={errorAllPosts || deleteGradeError}
        exportProps={{
          data: allPosts?.records,
          fileName: 'Grade',
          columns: useTranslatedColumnsForPDF(gradeColumnMappings),
          pdf: {
            orientation: 'portrait',
          },
          allRecords: {
            baseURL: getEnv('REACT_APP_UP_BASE_URL', null),
            endpoint: getAPIWithEntityUrl(apiEndPoint.gradeList),
            filterData,
          },
        }}
        filterData={filterData}
        handlePagination={handlePagination}
        handleSearch={onSearch}
        isError={isErrorAllPosts || deleteGradeIsError}
        loading={isLoadingAllPosts || deleteGradeLoading}
        rowClickHandler={handleView}
        rowNumber={0}
        selelctedUser={selelctedDelete}
        setSelelctedUser={setSelelctedDelete}
        sortHandleClick={sorting}
        success={deleteGradeSuccess}
        title={t('ent_grade_title')}
      />
    </Box>
  )
}

export default GradeList
