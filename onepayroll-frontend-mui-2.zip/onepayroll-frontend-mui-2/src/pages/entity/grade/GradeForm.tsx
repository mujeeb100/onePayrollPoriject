import { Box, Grid } from '@mui/material'
import {
  useGradeCreateMutation,
  useGradeUpdateMutation,
  useLazyGetGradeByIdQuery,
} from 'api/entityServices'
import OPRInputControl from 'components/molecules/OPRInputControl'
import OPRResponsiveGrid from 'components/molecules/OPRResponsiveGrid'
import OPRTextArea from 'components/molecules/OPRTextArea/OPRTextArea'
import OPRAlertControl from 'components/organism/OPRAlertControl'
import { OPRInnerFormLayout } from 'components/organism/OPRInnerFormLayout'
import { validationSchemaGrade } from 'constants/validate'
import { useEditable } from 'hooks/useEdit'
import useForm from 'hooks/useForm'
import { t } from 'i18next'
import { useEffect } from 'react'
import { useLocation, useNavigate } from 'react-router-dom'
import { routes } from 'routes/routes'
import { getParamsValue } from 'utils'

interface MessageProps {
  text?: string;
  important?: boolean;
}

export default function GradeForm() {
  const location: any = useLocation()
  const { id, viewUrl } = getParamsValue(location, routes.createGrade)

  const { isEditable, setEditable } = useEditable()

  const {
    values,
    setValues,
    errors,
    handleChange,
    setErrors,
    handleFormSubmit,
  } = useForm(validationSchemaGrade)

  const navigate = useNavigate()
  const [
    createGrade,
    {
      data: createdGradeData,
      error: createdGradeError,
      isLoading: createdGradeLoading,
      isSuccess: createdGradeSuccess,
      isError: createdGradeIsError,
    },
  ] = useGradeCreateMutation()

  const [
    updateGrade,
    {
      data: updatedDataResponse,
      error: updatedGradeError,
      isLoading: updatedGradeLoading,
      isSuccess: updatedGradeSuccess,
      isError: updatedGradeIsError,
    },
  ] = useGradeUpdateMutation()

  const [
    updateGradeById,
    {
      data: updatedGradeByIdResponse,
      error: updatedGradeByIdError,
      isLoading: updatedGradeByIdLoading,
      isSuccess: updatedGradeByIdSuccess,
      isError: updatedGradeByIdIsError,
    },
  ] = useLazyGetGradeByIdQuery()

  useEffect(() => {
    if (id) {
      updateGradeById(id)
      setEditable(viewUrl)
    }
  }, [])
  useEffect(() => {
    if (id) {
      setValues(updatedGradeByIdResponse?.data)
    } else {
      setValues(location.state ? location.state : {})
    }
  }, [updatedGradeByIdResponse?.data])

  const handleSubmit: any = async () => {
    if (isEditable) {
      if (id === null) {
        await createGrade({
          gradeCode: values?.gradeCode,
          gradeDescription: values?.gradeDescription,
          remarks: values?.remarks || '',

        })
      } else {
        await updateGrade({
          id: values?.id,
          gradeCode: values?.gradeCode,
          gradeDescription: values?.gradeDescription,
          remarks: values?.remarks || '',

        })
      }
    } else {
      setEditable(true)
    }
  }

  async function editGrade() {
    await updateGrade({
      id: values.id,
      gradeCode: values.gradeCode,
      gradeDescription: values.gradeDescription,
      remarks: values.remarks || '',
    })
  }

  const onScreenClose:any = (item: any) => {
    setEditable(item)
    setValues({})
  }

  return (
    <Box sx={{ display: 'flex' }}>
      <form
        style={{ display: 'flex', width: '100% ' }}
        onSubmit={(e) => handleFormSubmit(e, handleSubmit)}
      >
        <OPRAlertControl
          error={createdGradeError || updatedGradeError}
          handleEditable={setEditable}
          handleSetValue={setValues}
          handleSubmit={handleSubmit}
          isError={createdGradeError || updatedGradeIsError}
          isLoading={
            createdGradeLoading
            || updatedGradeLoading
            || updatedGradeByIdLoading
          }
          isSuccess={updatedGradeSuccess || createdGradeSuccess}
          name={values?.gradeDescription}
          title="Grade"
          type={id ? 'Update' : 'New'}
        />
        <OPRInnerFormLayout
          error={createdGradeError || updatedGradeError}
          handleCancelClick={() => navigate(-1)}
          handleContinueClick={handleSubmit}
          handleEditable={() => {
            setEditable(true)
          }}
          isBackButton={isEditable}
          isLoading={
            createdGradeLoading
            || updatedGradeLoading
            || updatedGradeByIdLoading
          }
          pageType="detailsPage"
          subtitle={
            isEditable
              ? 'Please check the user details below.'
              : 'All fields are mandatory except those marked optional'
          }
          // title={t('ent_grade_add_btn_title')}
          title={(viewUrl) ? values?.gradeDescription : false || ((id) ? values?.gradeDescription : t('ent_grade_add_btn_title'))} // Set title based on mode
          onScreenClose={onScreenClose}
        >
          <Box>
            <OPRResponsiveGrid>
              <Grid item md={2} sm={1} xs={1}>
                <OPRInputControl
                  disabled={!!id}
                  error={t(errors?.gradeCode)}
                  isEditable={isEditable}
                  label="ent_grade_code"
                  name="gradeCode"
                  value={values?.gradeCode}
                  onChange={handleChange}
                />
              </Grid>
              <Grid item md={2} sm={1} xs={1}>
                <OPRInputControl
                  error={t(errors?.gradeDescription)}
                  isEditable={isEditable}
                  label="ent_grade_description"
                  name="gradeDescription"
                  value={values?.gradeDescription}
                  onChange={handleChange}
                />
              </Grid>
              <Grid item md={4} sm={6} xs={12}>
                <OPRTextArea
                  error={t(errors?.remarks)}
                  isEditable={isEditable}
                  label="Remarks"
                  name="remarks"
                  optionalText="optional"
                  value={values?.remarks}
                  onChange={handleChange}
                />
              </Grid>
            </OPRResponsiveGrid>
          </Box>
        </OPRInnerFormLayout>
      </form>
    </Box>
  )
}
