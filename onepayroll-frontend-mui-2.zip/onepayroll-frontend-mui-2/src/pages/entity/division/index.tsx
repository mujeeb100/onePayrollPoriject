import {
  Box,
} from '@mui/material'
import { useDivisionDeleteMutation, useGetAllDivisionQuery } from 'api/entityServices'
import { entityDivisionColumn } from 'components/atoms/table/OPRTableConstant'
import { OPRInnerListLayout } from 'components/organism/OPRInnerLayoutList'
import apiEndPoint from 'constants/apiEndPoint'
import { divisionColumnMappings } from 'constants/exportColumnMappings'
import { useTranslatedColumnsForPDF } from 'hooks/useTranslatedColumnsForPDF'
import { t } from 'i18next'
import React, { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { routes } from 'routes/routes'
import {
  generateFilterUrl, getAPIWithEntityUrl, getEnv, setRouteValues,
} from 'utils'

function DivisionList() {
  const navigate: any = useNavigate()
  const [selelctedDelete, setSelelctedDelete]:any = useState({
    data: {},
    isDelete: false,
    name: '',
  })
  const [filterData, setFilterData]:any = useState({
    pageNumber: 1,
    pageSize: 20,
    totalItems: 0,
    orderByAsc: true,
    sortBy: '',
    SearchText: '',
  })
  const {
    data: allPosts,
    isLoading: isLoadingAllPosts,
    isSuccess: isSuccessAllPosts,
    isError: isErrorAllPosts,
    error: errorAllPosts,
    refetch: refetchAllPosts,
  } = useGetAllDivisionQuery(generateFilterUrl(filterData))

  const [deleteDivisionById,
    {
      data: deleteDivisionResponse,
      error: deleteDivisionError,
      isLoading: deleteDivisionLoading,
      isSuccess: deleteDivisionSuccess,
      isError: deleteDivisionIsError,
    }] = useDivisionDeleteMutation()

  const sorting = (
    event: React.MouseEvent<unknown>,
    property: keyof any,
  ) => {
    const isAsc = filterData.sortBy === property && filterData.orderByAsc === true
    setFilterData({ ...filterData, orderByAsc: !isAsc, sortBy: property })
    // setOrder(isAsc ? 'desc' : 'asc')
    // setOrderBy(property)
  }

  useEffect(() => {
    setFilterData({ ...filterData, totalItems: allPosts?.totalItems ? allPosts?.totalItems : 0 })
  }, [allPosts?.pageNumber, filterData.sortBy, filterData.orderByAsc, allPosts?.totalItems])

  // const onSearch = (e: any) => {
  //   setFilterData({ ...filterData, SearchText: e.target.value })
  // }

  const onSearch = (e: any, data: any) => {
    setFilterData({ ...filterData, ...data })
  }

  const handlePagination = (pageNumber: number, pageSize: number) => {
    setFilterData({ ...filterData, pageNumber })
  }

  const viewAcoount = (data: any, type:string) => {
    if (type === 'Edit division') {
      navigate(
        setRouteValues(`${routes.editDivision}`, {
          id: data.id,
        }),
      )
    } else if (type === 'Delete division') {
      // deleteDivisionById(`Id=${data.id}`)
      setSelelctedDelete({ data, isDelete: true, name: data.divisionDescription })
    } else {
      navigate(
        setRouteValues(`${routes.viewDivision}`, {
          id: data.id,
        }),
      )
    }
  }
  const handleView = (data: any) => {
    navigate(
      setRouteValues(`${routes.viewDivision}`, {
        id: data.id,
        view: true,
      }),
    )
  }
  // handle delete
  const handleDelete = (data:any) => {
    deleteDivisionById(`Id=${data.id}`)
  }
  return (
    <Box sx={{ display: 'flex' }}>
      <OPRInnerListLayout
        isExport
        Search={decodeURIComponent(filterData.SearchText)}
        addHandleClick={() => navigate(routes.createDivision)}
        columns={entityDivisionColumn(viewAcoount)}
        dataList={JSON.parse(JSON.stringify(allPosts?.records || []))}
        deleteCallBack={handleDelete}
        error={errorAllPosts || deleteDivisionError}
        exportProps={{
          data: allPosts?.records,
          fileName: 'Division',
          columns: useTranslatedColumnsForPDF(divisionColumnMappings),
          pdf: {
            orientation: 'portrait',
          },
          allRecords: {
            baseURL: getEnv('REACT_APP_UP_BASE_URL', null),
            endpoint: getAPIWithEntityUrl(apiEndPoint.divisionList),
            filterData,
          },
        }}
        filterData={filterData}
        handlePagination={handlePagination}
        handleSearch={onSearch}
        isError={isErrorAllPosts || deleteDivisionIsError}
        loading={isLoadingAllPosts || deleteDivisionLoading}
        rowClickHandler={handleView}
        rowNumber={0}
        selelctedUser={selelctedDelete}
        setSelelctedUser={setSelelctedDelete}
        sortHandleClick={sorting}
        success={deleteDivisionSuccess}
        title={t('division')}
      />
    </Box>
  )
}

export default DivisionList
