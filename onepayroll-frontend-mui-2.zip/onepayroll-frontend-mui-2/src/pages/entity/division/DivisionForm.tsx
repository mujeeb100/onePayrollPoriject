import { Box, Grid } from '@mui/material'
import {
  useDivisionCreateMutation,
  useDivisionUpdateMutation,
  useLazyGetDivisionByIdQuery,
} from 'api/entityServices'
import OPRInputControl from 'components/molecules/OPRInputControl'
import OPRResponsiveGrid from 'components/molecules/OPRResponsiveGrid'
import OPRTextArea from 'components/molecules/OPRTextArea/OPRTextArea'
import OPRAlertControl from 'components/organism/OPRAlertControl'
import { OPRInnerFormLayout } from 'components/organism/OPRInnerFormLayout'
import { validationSchemaDivision } from 'constants/validate'
import { useEditable } from 'hooks/useEdit'
import useForm from 'hooks/useForm'
import { t } from 'i18next'
import { useEffect } from 'react'
import { useLocation, useNavigate } from 'react-router-dom'
import { routes } from 'routes/routes'
import { getParamsValue } from 'utils'

interface MessageProps {
  text?: string;
  important?: boolean;
}

export default function DivisionForm() {
  const location: any = useLocation()
  // const id = getParamsValue(location, routes.createDivision)
  const { id, viewUrl } = getParamsValue(location, routes.createDivision)

  const { isEditable, setEditable } = useEditable()

  const {
    values,
    setValues,
    errors,
    handleChange,
    setErrors,
    handleFormSubmit,
  } = useForm(validationSchemaDivision)

  const navigate = useNavigate()
  const [
    createDivision,
    {
      data: createdDivisionData,
      error: createdDivisionError,
      isLoading: createdDivisionLoading,
      isSuccess: createdDivisionSuccess,
      isError: createdDivisionIsError,
    },
  ] = useDivisionCreateMutation()

  const [
    updateDivision,
    {
      data: updatedDataResponse,
      error: updatedDivisionError,
      isLoading: updatedDivisionLoading,
      isSuccess: updatedDivisionSuccess,
      isError: updatedDivisionIsError,
    },
  ] = useDivisionUpdateMutation()

  const [
    updateDivisionById,
    {
      data: updatedDivisionByIdResponse,
      error: updatedDivisionByIdError,
      isLoading: updatedDivisionByIdLoading,
      isSuccess: updatedDivisionByIdSuccess,
      isError: updatedDivisionByIdIsError,
    },
  ] = useLazyGetDivisionByIdQuery()

  useEffect(() => {
    if (id) {
      updateDivisionById(id)
      setEditable(viewUrl)
    }
  }, [])
  useEffect(() => {
    if (id) {
      setValues(updatedDivisionByIdResponse?.data)
    } else {
      setValues(location.state ? location.state : {})
    }
  }, [updatedDivisionByIdResponse?.data])

  // reset the values
  // useEffect(() => {
  //   if (createdDivisionSuccess) {
  //     setValues({})
  //   }
  // }, [createdDivisionSuccess])

  const handleSubmit: any = async () => {
    if (isEditable) {
      if (id === null) {
        await createDivision({
          divisionCode: values?.divisionCode,
          divisionDescription: values?.divisionDescription,
          remarks: values?.remarks || '',

        })
      } else {
        await updateDivision({
          id: values?.id,
          divisionCode: values?.divisionCode,
          divisionDescription: values?.divisionDescription,
          remarks: values?.remarks || '',

        })
      }
    } else {
      setEditable(true)
    }
  }

  async function editDivision() {
    await updateDivision({
      id: values.id,
      divisionCode: values.divisionCode,
      divisionDescription: values.divisionDescription,
      remarks: values.remarks || '',
    })
  }

  const onScreenClose:any = (item: any) => {
    setEditable(item)
    setValues({})
  }

  return (
    <Box sx={{ display: 'flex' }}>
      <form
        style={{ display: 'flex', width: '100% ' }}
        onSubmit={(e) => handleFormSubmit(e, handleSubmit)}
      >
        <OPRAlertControl
          error={createdDivisionError || updatedDivisionError}
          handleEditable={setEditable}
          handleSetValue={setValues}
          handleSubmit={handleSubmit}
          isError={createdDivisionError || updatedDivisionIsError}
          isLoading={
            createdDivisionLoading
            || updatedDivisionLoading
            || updatedDivisionByIdLoading
          }
          isSuccess={updatedDivisionSuccess || createdDivisionSuccess}
          name={values?.divisionDescription}
          title={t('division')}
          type={id ? 'Update' : 'New'}
        />
        <OPRInnerFormLayout
          error={createdDivisionError || updatedDivisionError}
          handleCancelClick={() => navigate(-1)}
          handleContinueClick={handleSubmit}
          handleEditable={() => {
            setEditable(true)
          }}
          isBackButton={isEditable}
          isLoading={
            createdDivisionLoading
            || updatedDivisionLoading
            || updatedDivisionByIdLoading
          }
          pageType="detailsPage"
          subtitle={
            isEditable
              ? 'Please check the user details below.'
              : 'All fields are mandatory except those marked optional'
          }
          // title={t('addDivision')}
          title={(viewUrl) ? values?.divisionDescription : false || ((id) ? values?.divisionDescription : t('addDivision'))} // Set title based on mode
          onScreenClose={onScreenClose}
        >
          <Box>
            <OPRResponsiveGrid>
              <Grid item md={2} sm={1} xs={1}>
                <OPRInputControl
                  disabled={!!id}
                  error={t(errors?.divisionCode)}
                  isEditable={isEditable}
                  label="division_code"
                  name="divisionCode"
                  value={values?.divisionCode}
                  onChange={handleChange}
                />
              </Grid>
              <Grid item md={2} sm={1} xs={1}>
                <OPRInputControl
                  error={t(errors?.divisionDescription)}
                  isEditable={isEditable}
                  label="division_description"
                  name="divisionDescription"
                  value={values?.divisionDescription}
                  onChange={handleChange}
                />
              </Grid>
              <Grid item md={4} sm={6} xs={12}>
                <OPRTextArea
                  error={t(errors?.remarks)}
                  isEditable={isEditable}
                  label="remarks"
                  name="remarks"
                  optionalText="optional"
                  value={values?.remarks}
                  onChange={handleChange}
                />
              </Grid>
            </OPRResponsiveGrid>
          </Box>
        </OPRInnerFormLayout>
      </form>
    </Box>
  )
}
