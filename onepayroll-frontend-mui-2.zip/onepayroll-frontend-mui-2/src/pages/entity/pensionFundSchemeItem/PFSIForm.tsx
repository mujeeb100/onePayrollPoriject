import { Box, Grid } from '@mui/material'
import {
  useGetAllPensionFundSchemeQuery,
  useLazyGetPensionFundSchemeItemByIdQuery,
  usePensionFundSchemeItemCreateMutation,
  usePensionFundSchemeItemUpdateMutation,
} from 'api/entityServices'
import { useGetAllPayItemMasterQuery } from 'api/payRollServices'
import OPRDatePickerControl from 'components/molecules/OPRDatePickerControl/OPRDatePickerControl'
import OPRResponsiveGrid from 'components/molecules/OPRResponsiveGrid'
import OPRSelectorControl from 'components/molecules/OPRSelectorControl/OPRSelectorControl'
import OPRAlertControl from 'components/organism/OPRAlertControl'
import { OPRInnerFormLayout } from 'components/organism/OPRInnerFormLayout'
import {
  validationSchemaPensionFundSchemeItem,
} from 'constants/validate'
import { useEditable } from 'hooks/useEdit'
import useForm from 'hooks/useForm'
import { t } from 'i18next'
import { useEffect, useState } from 'react'
import { useLocation, useNavigate } from 'react-router-dom'
import { routes } from 'routes/routes'
import { generateFilterUrl, getParamsValue } from 'utils'

interface MessageProps {
  text?: string;
  important?: boolean;
}
const defaultValues = {
  status: true,

}

export default function PensionFundSchemeItemForm() {
  const location: any = useLocation()
  const { id, viewUrl } = getParamsValue(location, routes.createPensionFundSchemeItem)
  const [filterData, setFilterData]:any = useState({
    pageNumber: 1,
    pageSize: 1000,
    totalItems: 0,
    orderByAsc: true,
    sortBy: '',
    SearchText: '',
  })
  const { isEditable, setEditable } = useEditable()

  const {
    values,
    setValues,
    errors,
    handleChange,
    handleOnChange,
    setErrors,
    handleFormSubmit,
  } = useForm(validationSchemaPensionFundSchemeItem)

  const navigate = useNavigate()
  // pension fund schem
  const {
    data: getAllPensionfundschemeData,

  } = useGetAllPensionFundSchemeQuery(generateFilterUrl(filterData))

  //   pay item master slice
  const {
    data: getALLpayitemmasterdata,
  } = useGetAllPayItemMasterQuery(generateFilterUrl(filterData))

  const [
    createPensionFundSchemeItem,
    {
      data: createdPensionFundSchemeItemData,
      error: createdPensionFundSchemeItemError,
      isLoading: createdPensionFundSchemeItemLoading,
      isSuccess: createdPensionFundSchemeItemSuccess,
      isError: createdPensionFundSchemeItemIsError,
    },
  ] = usePensionFundSchemeItemCreateMutation()

  const [
    updatePensionFundSchemeItem,
    {
      data: updatedDataResponse,
      error: updatedPensionFundSchemeItemError,
      isLoading: updatedPensionFundSchemeItemLoading,
      isSuccess: updatedPensionFundSchemeItemSuccess,
      isError: updatedPensionFundSchemeItemIsError,
    },
  ] = usePensionFundSchemeItemUpdateMutation()

  const [
    updatePensionFundSchemeItemById,
    {
      data: updatedPensionFundSchemeItemByIdResponse,
      error: updatedPensionFundSchemeItemByIdError,
      isLoading: updatedPensionFundSchemeItemByIdLoading,
      isSuccess: updatedPensionFundSchemeItemByIdSuccess,
      isError: updatedPensionFundSchemeItemByIdIsError,
    },
  ] = useLazyGetPensionFundSchemeItemByIdQuery()

  useEffect(() => {
    if (id) {
      updatePensionFundSchemeItemById(id)
      setEditable(viewUrl)
    }
  }, [])
  useEffect(() => {
    if (id) {
      setValues(updatedPensionFundSchemeItemByIdResponse?.data)
    } else {
      setValues(location.state ? location.state : {})
    }
  }, [updatedPensionFundSchemeItemByIdResponse?.data])

  //   reset the values
  useEffect(() => {
    if (createdPensionFundSchemeItemSuccess) {
      setValues({})
      setErrors({})
    }
  }, [createdPensionFundSchemeItemSuccess])

  useEffect(() => {
    if (id === null) {
      setValues(defaultValues)
    }
  }, [])

  const handleSubmit: any = async () => {
    if (isEditable) {
      if (id === null) {
        await createPensionFundSchemeItem({
          pensionFundSchemeCode: values.pensionFundSchemeCode,
          effectiveStartDate: values.effectiveStartDate,
          effectiveEndDate: values.effectiveEndDate,
          payItemCode: values.payItemCode,
          status: values?.status,
        })
      } else {
        await updatePensionFundSchemeItem({
          id: values?.id,
          pensionFundSchemeCode: values.pensionFundSchemeCode,
          effectiveStartDate: values.effectiveStartDate,
          effectiveEndDate: values.effectiveEndDate,
          payItemCode: values.payItemCode,
          status: values?.status,
        })
      }
    } else {
      setEditable(true)
    }
  }

  async function editPensionFundSchemeItem() {
    await updatePensionFundSchemeItem({
      id: values?.id,
      pensionFundSchemeCode: values.pensionFundSchemeCode,
      effectiveStartDate: values.effectiveStartDate,
      effectiveEndDate: values.effectiveEndDate,
      payItemCode: values.payItemCode,
      status: values?.status,
    })
  }

  const onScreenClose:any = (item: any) => {
    setEditable(item)
    setValues({})
  }
  return (
    <Box sx={{ display: 'flex' }}>
      <form
        style={{ display: 'flex', width: '100% ' }}
        onSubmit={(e) => handleFormSubmit(e, handleSubmit)}
      >
        <OPRAlertControl
          error={createdPensionFundSchemeItemError || updatedPensionFundSchemeItemError}
          handleEditable={setEditable}
          handleSetValue={setValues}
          handleSubmit={handleSubmit}
          isError={createdPensionFundSchemeItemError || updatedPensionFundSchemeItemIsError}
          isLoading={
            createdPensionFundSchemeItemLoading
            || updatedPensionFundSchemeItemLoading
            || updatedPensionFundSchemeItemByIdLoading
          }
          isSuccess={updatedPensionFundSchemeItemSuccess || createdPensionFundSchemeItemSuccess}
          name={t('PensionFundSchemeItem')}
          title={t('PensionFundSchemeItem')}
          type={id ? 'Update' : 'New'}
        />

        <OPRInnerFormLayout
          error={createdPensionFundSchemeItemError || updatedPensionFundSchemeItemError}
          handleCancelClick={() => navigate(-1)}
          handleContinueClick={handleSubmit}
          handleEditable={() => {
            setEditable(true)
          }}
          isBackButton={isEditable}
          isLoading={
            createdPensionFundSchemeItemLoading
            || updatedPensionFundSchemeItemLoading
            || updatedPensionFundSchemeItemByIdLoading
          }
          pageType="detailsPage"
          subtitle={
            isEditable
              ? 'Please check the user details below.'
              : 'All fields are mandatory except those marked optional'
          }
          title={t('add_pension_fund_scheme_item_title')}
          onScreenClose={onScreenClose}

        >
          <Box>
            <OPRResponsiveGrid>
              <Grid item md={2} sm={1} xs={1}>

                {/* pensionfundschemecode */}
                <OPRSelectorControl
                  error={errors?.pensionFundSchemeCode}
                  isEditable={isEditable}
                  keyName="pensionFundSchemeCode"
                  // label="ent_pens_fund_scheme_title"
                  label="Pension fund scheme"
                  multiple={false}
                  name="pensionFundSchemeCode"
                  options={(getAllPensionfundschemeData?.records || [])}
                  placeholder="Select an option"
                  value={(getAllPensionfundschemeData?.records || []).find((o:any) => o.pensionFundSchemeCode === values?.pensionFundSchemeCode)}
                  valueKey="pensionFundSchemeCode"
                  onChange={(text:any) => {
                    // handleChange({ target: { name: 'countryLocalization', value: text?.countryCode }, persist: () => {} })
                    setValues({ ...values, pensionFundSchemeCode: text?.pensionFundSchemeCode })
                  }}
                />
              </Grid>

              <Grid item md={2} sm={1} xs={1}>
                <OPRSelectorControl
                  error={errors?.payItemCode}
                  isEditable={isEditable}
                  keyName="payItemCode"
                  label="Pay item"
                  multiple={false}
                  name="payItemCode"
                  options={(getALLpayitemmasterdata?.records || [])}
                  placeholder="Select an option"
                  value={(getALLpayitemmasterdata?.records || []).find((o:any) => o.payItemCode === values?.payItemCode)}
                  valueKey="payItemCode"
                  onChange={(text:any) => {
                    // handleChange({ target: { name: 'countryLocalization', value: text?.countryCode }, persist: () => {} })
                    setValues({ ...values, payItemCode: text?.payItemCode })
                  }}
                />
              </Grid>
              <Grid item md={2} sm={1} xs={1}>
                <OPRDatePickerControl
                  error={errors?.effectiveStartDate}
                  isEditable={isEditable}
                  // label={t('effectiveStartDate')}
                  label="Effective start date"
                  name="effectiveStartDate"
                  value={values?.effectiveStartDate || null}
                  // value={values?.effectiveStartDate ? values?.effectiveStartDate?.toISOString() : null}
                  onChange={(date) => {
                    handleOnChange('effectiveStartDate', date)
                  }}
                />
              </Grid>
              <Grid item md={2} sm={1} xs={1}>
                <OPRDatePickerControl
                  error={errors?.effectiveEndDate}
                  isEditable={isEditable}
                  // label={t('effectiveEndDate')}
                  label="Effective end date"
                  name="effectiveEndDate"
                  value={values?.effectiveEndDate || null}
                  // value={values?.effectiveEndDate ? values?.effectiveEndDate?.toISOString() : null}
                  onChange={(date) => {
                    handleOnChange('effectiveEndDate', date)
                  }}
                />
              </Grid>

              <Grid item md={2} sm={1} xs={1}>
                {/* status active or inaactive */}
                <OPRSelectorControl
                  defaultValue={{ name: 'Active', values: true }}
                  error={errors?.status}
                  isEditable={isEditable}
                  keyName="name"
                  label={t('status')}
                  multiple={false}
                  name="status"
                  options={[{ name: 'Active', values: true }, { name: 'Inactive', values: false }]}
                  placeholder="Select an option"
                  value={[{ name: 'Active', values: true }, { name: 'Inactive', values: false }]?.find((o:any) => o?.values === values?.status) || {}}
                  valueKey="name"
                  onChange={(text:any) => {
                    // handleChange({ target: { name: 'countryLocalization', value: text?.countryCode }, persist: () => {} })
                    // setValues({ ...values, countryLocalization: text })
                    handleOnChange('status', text?.values)
                  }}
                />
              </Grid>

            </OPRResponsiveGrid>

          </Box>
        </OPRInnerFormLayout>
      </form>
    </Box>
  )
}
