// PensionFundSchemeItem
import {
  Box,
} from '@mui/material'
import { useGetAllPensionFundSchemeItemQuery, usePensionFundSchemeItemDeleteMutation } from 'api/entityServices'
import { entitypensionFundSchemeItemColumn } from 'components/atoms/table/OPRTableConstant'
import { OPRInnerListLayout } from 'components/organism/OPRInnerLayoutList'
import apiEndPoint from 'constants/apiEndPoint'
import { PensionFundSchemeItemColumnMappings } from 'constants/exportColumnMappings'
// import { PensionFundSchemeItemColumnMappings } from 'constants/exportColumnMappings'
import { useTranslatedColumnsForPDF } from 'hooks/useTranslatedColumnsForPDF'
import React, { useEffect, useState } from 'react'
// import { entityPensionFundSchemeItemColumn } from 'components/atoms/table/OPRTableConstant'
import { useNavigate } from 'react-router-dom'
import { routes } from 'routes/routes'
import {
  generateFilterUrl, getAPIWithEntityUrl, getEnv, setRouteValues,
} from 'utils'

function PensionFundSchemeItemList() {
  const navigate: any = useNavigate()
  const [filterData, setFilterData]:any = useState({
    pageNumber: 1,
    pageSize: 20,
    totalItems: 0,
    orderByAsc: true,
    sortBy: '',
    SearchText: '',
  })
  const {
    data: allPosts,
    isLoading: isLoadingAllPosts,
    isSuccess: isSuccessAllPosts,
    isError: isErrorAllPosts,
    error: errorAllPosts,
    refetch: refetchAllPosts,
  } = useGetAllPensionFundSchemeItemQuery(generateFilterUrl(filterData))

  const [deletePensionFundSchemeItemById,
    {
      data: deletePensionFundSchemeItemResponse,
      error: deletePensionFundSchemeItemError,
      isLoading: deletePensionFundSchemeItemLoading,
      isSuccess: deletePensionFundSchemeItemSuccess,
      isError: deletePensionFundSchemeItemIsError,
    }] = usePensionFundSchemeItemDeleteMutation()

  const sorting = (
    event: React.MouseEvent<unknown>,
    property: keyof any,
  ) => {
    const isAsc = filterData.sortBy === property && filterData.orderByAsc === true
    setFilterData({ ...filterData, orderByAsc: !isAsc, sortBy: property })
  }

  useEffect(() => {
    setFilterData({ ...filterData, totalItems: allPosts?.totalItems ? allPosts?.totalItems : 0 })
  }, [allPosts?.pageNumber, filterData.sortBy, filterData.orderByAsc, allPosts?.totalItems])

  const onSearch = (e: any, data: any) => {
    setFilterData({ ...filterData, ...data })
  }

  const handlePagination = (pageNumber: number, pageSize: number) => {
    setFilterData({ ...filterData, pageNumber })
  }

  const viewAcoount = (data: any, type:string) => {
    if (type === 'Edit Pension Fund Scheme Item') {
      navigate(
        setRouteValues(`${routes.editPensionFundSchemeItem}`, {
          id: data.id,
        }),
      )
    } else if (type === 'Delete Pension Fund Scheme Item') {
      deletePensionFundSchemeItemById(`Id=${data.id}`)
    } else {
      navigate(
        setRouteValues(`${routes.viewPensionFundSchemeItem}`, {
          id: data.id,
        }),
      )
    }
  }

  const handleView = (data: any) => {
    navigate(
      setRouteValues(`${routes.viewPensionFundSchemeItem}`, {
        id: data.id,
        view: true,
      }),
    )
  }
  // Update status value to 'Active' or 'Inactive' based on the actual status value
  // const updatedDataList = allPosts?.records.map((record) => ({
  //   ...record,
  //   status: record.status ? 'Active' : 'Inactive',
  // }));

  return (
    <Box sx={{ display: 'flex' }}>
      <OPRInnerListLayout
        isExport
        Search={decodeURIComponent(filterData.SearchText)}
        addHandleClick={() => navigate(routes.createPensionFundSchemeItem)}
        columns={entitypensionFundSchemeItemColumn(viewAcoount)}
        dataList={JSON.parse(JSON.stringify(allPosts?.records || []))}
        error={errorAllPosts || deletePensionFundSchemeItemError}
        exportProps={{
          // data: allPosts?.records?.map((record:any) => ({
          //   ...record,
          //   status: record.status ? 'Active' : 'Inactive',
          // })),
          data: allPosts?.records,
          fileName: 'PensionFundSchemeItem',
          columns: useTranslatedColumnsForPDF(PensionFundSchemeItemColumnMappings),
          pdf: {
            orientation: 'landscape',
          },
          allRecords: {
            baseURL: getEnv('REACT_APP_UP_BASE_URL', null),
            endpoint: getAPIWithEntityUrl(apiEndPoint.pensionFundSchemeItemList),
            filterData,
          },
        }}
        filterData={filterData}
        handlePagination={handlePagination}
        handleSearch={onSearch}
        isError={isErrorAllPosts || deletePensionFundSchemeItemIsError}
        loading={isLoadingAllPosts || deletePensionFundSchemeItemLoading}
        rowClickHandler={handleView}
        rowNumber={0}
        sortHandleClick={sorting}
        success={deletePensionFundSchemeItemSuccess}
        // title={t('pension_fund_scheme_item')}
        title="Pension fund scheme items"
      />
    </Box>
  )
}

export default PensionFundSchemeItemList
