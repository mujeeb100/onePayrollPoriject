// pension fund scheme rule
import 'styles/style.css'

import { Box, Grid } from '@mui/material'
import {
  useLazyGetPensionFundSchemeRuleByIdQuery,
  usePensionFundSchemeRuleCreateMutation,
  usePensionFundSchemeRuleUpdateMutation,
} from 'api/entityServices'
import OPRDatePickerControl from 'components/molecules/OPRDatePickerControl/OPRDatePickerControl'
import OPRInputControl from 'components/molecules/OPRInputControl'
import OPRResponsiveGrid from 'components/molecules/OPRResponsiveGrid'
import OPRAlertControl from 'components/organism/OPRAlertControl'
import { OPRInnerFormLayout } from 'components/organism/OPRInnerFormLayout'
import {
  validationSchemaPensionFundSchemeRule,
} from 'constants/validate'
import { useEditable } from 'hooks/useEdit'
import useForm from 'hooks/useForm'
import { t } from 'i18next'
import moment from 'moment'
import { useEffect } from 'react'
import { useLocation, useNavigate } from 'react-router-dom'
import { routes } from 'routes/routes'
import { formatedYearDate, getParamsValue } from 'utils'

interface MessageProps {
  text?: string;
  important?: boolean;
}
const defaultValues = {
//   status: true,
  relevantIncomeMinAmount: 0,
}

export default function PensionFundSchemeRuleForm() {
  const location: any = useLocation()
  const { id, viewUrl } = getParamsValue(location, routes.createPensionFundSchemeRule)

  const { isEditable, setEditable } = useEditable()

  const {
    values,
    setValues,
    errors,
    handleChange,
    handleOnChange,
    handleDatePickerChange,
    setErrors,
    handleFormSubmit,
  } = useForm(validationSchemaPensionFundSchemeRule)

  const navigate = useNavigate()

  const [
    createPensionFundSchemeRule,
    {
      data: createdPensionFundSchemeRuleData,
      error: createdPensionFundSchemeRuleError,
      isLoading: createdPensionFundSchemeRuleLoading,
      isSuccess: createdPensionFundSchemeRuleSuccess,
      isError: createdPensionFundSchemeRuleIsError,
    },
  ] = usePensionFundSchemeRuleCreateMutation()

  const [
    updatePensionFundSchemeRule,
    {
      data: updatedDataResponse,
      error: updatedPensionFundSchemeRuleError,
      isLoading: updatedPensionFundSchemeRuleLoading,
      isSuccess: updatedPensionFundSchemeRuleSuccess,
      isError: updatedPensionFundSchemeRuleIsError,
    },
  ] = usePensionFundSchemeRuleUpdateMutation()

  const [
    updatePensionFundSchemeRuleById,
    {
      data: updatedPensionFundSchemeRuleByIdResponse,
      error: updatedPensionFundSchemeRuleByIdError,
      isLoading: updatedPensionFundSchemeRuleByIdLoading,
      isSuccess: updatedPensionFundSchemeRuleByIdSuccess,
      isError: updatedPensionFundSchemeRuleByIdIsError,
    },
  ] = useLazyGetPensionFundSchemeRuleByIdQuery()

  useEffect(() => {
    if (id) {
      updatePensionFundSchemeRuleById(id)
      setEditable(viewUrl)
    }
  }, [])
  useEffect(() => {
    if (id) {
      setValues(updatedPensionFundSchemeRuleByIdResponse?.data)
    } else {
      setValues({
        ...location.state,
        relevantIncomeMinAmount: 0,
        relevantIncomeMaxAmount: 999999999,
        yearOfServiceFrom: 0,
        yearOfServiceTo: 99,
        employerContributionRate: 0,
        employeeContributionRate: 0,
        employerFixedContributionAmount: 0,
        employeeFixedContributionAmount: 0,
        employerAnnualContributionCap: 0,
        employeeAnnualContributionCap: 0,
      })
    }
  }, [updatedPensionFundSchemeRuleByIdResponse?.data])

  //   reset the values
  // useEffect(() => {
  //   if (createdPensionFundSchemeRuleSuccess) {
  //     setValues({})
  //     setErrors({})
  //   }
  // }, [createdPensionFundSchemeRuleSuccess])

  //   useEffect(() => {
  //     if (id === null) {
  //       setValues(defaultValues)
  //     }
  //   }, [])
  //   useEffect(() => {
  //     if (id === null) {
  //       setValues(defaultValues)
  //     }
  //   }, [])
  const handleSubmit: any = async () => {
    if (isEditable) {
      if (id === null) {
        await createPensionFundSchemeRule({
          pensionFundSchemeRuleType: values.pensionFundSchemeRuleType || '',
          effectiveStartDate: values.effectiveStartDate ? formatedYearDate(values?.effectiveStartDate) : '',
          effectiveEndDate: values.effectiveEndDate ? formatedYearDate(values?.effectiveEndDate) : '',
          relevantIncomeMinAmount: values.relevantIncomeMinAmount || 0,
          relevantIncomeMaxAmount: Number(values.relevantIncomeMaxAmount) || 0,
          yearOfServiceFrom: Number(values.yearOfServiceFrom) || 0,
          yearOfServiceTo: Number(values.yearOfServiceTo) || 0,
          employerContributionRate:
              Number(values.employerContributionRate) || 0,
          employeeContributionRate:
              Number(values.employeeContributionRate) || 0,
          employerFixedContributionAmount:
              Number(values.employerFixedContributionAmount) || 0,
          employeeFixedContributionAmount:
              Number(values.employeeFixedContributionAmount) || 0,
          employerAnnualContributionCap:
              Number(values.employerAnnualContributionCap) || 0,
          employeeAnnualContributionCap:
              Number(values.employeeAnnualContributionCap) || 0,
        //   ageFrom: Number(values.ageFrom) || 0,
        //   ageTo: Number(values.ageTo) || 0,
        })
      } else {
        await updatePensionFundSchemeRule({
          id: values?.id,
          pensionFundSchemeRuleType: values.pensionFundSchemeRuleType || '',
          effectiveStartDate: values.effectiveStartDate ? formatedYearDate(values?.effectiveStartDate) : '',
          effectiveEndDate: values.effectiveEndDate ? formatedYearDate(values?.effectiveEndDate) : '',
          relevantIncomeMinAmount: values.relevantIncomeMinAmount || 0,
          relevantIncomeMaxAmount: Number(values.relevantIncomeMaxAmount) || 0,
          yearOfServiceFrom: Number(values.yearOfServiceFrom) || 0,
          yearOfServiceTo: Number(values.yearOfServiceTo) || 0,
          employerContributionRate:
            Number(values.employerContributionRate) || 0,
          employeeContributionRate:
            Number(values.employeeContributionRate) || 0,
          employerFixedContributionAmount:
            Number(values.employerFixedContributionAmount) || 0,
          employeeFixedContributionAmount:
            Number(values.employeeFixedContributionAmount) || 0,
          employerAnnualContributionCap:
            Number(values.employerAnnualContributionCap) || 0,
          employeeAnnualContributionCap:
            Number(values.employeeAnnualContributionCap) || 0,
        //   ageFrom: Number(values.ageFrom) || 0,
        //   ageTo: Number(values.ageTo) || 0,
        })
      }
    } else {
      setEditable(true)
    }
  }

  async function editPensionFundSchemeRule() {
    await updatePensionFundSchemeRule({
      id: values?.id,
      pensionFundSchemeRuleType: values.pensionFundSchemeRuleType || '',
      effectiveStartDate: values.effectiveStartDate ? formatedYearDate(values?.effectiveStartDate) : '',
      effectiveEndDate: values.effectiveEndDate ? formatedYearDate(values?.effectiveEndDate) : '',
      relevantIncomeMinAmount: values.relevantIncomeMinAmount || 0,
      relevantIncomeMaxAmount: Number(values.relevantIncomeMaxAmount) || 0,
      yearOfServiceFrom: Number(values.yearOfServiceFrom) || 0,
      yearOfServiceTo: Number(values.yearOfServiceTo) || 0,
      employerContributionRate:
        Number(values.employerContributionRate) || 0,
      employeeContributionRate:
        Number(values.employeeContributionRate) || 0,
      employerFixedContributionAmount:
        Number(values.employerFixedContributionAmount) || 0,
      employeeFixedContributionAmount:
        Number(values.employeeFixedContributionAmount) || 0,
      employerAnnualContributionCap:
        Number(values.employerAnnualContributionCap) || 0,
      employeeAnnualContributionCap:
        Number(values.employeeAnnualContributionCap) || 0,
    //   ageFrom: Number(values.ageFrom) || 0,
    //   ageTo: Number(values.ageTo) || 0,
    })
  }

  const onScreenClose:any = (item: any) => {
    setEditable(item)
    setValues({})
  }

  const handleDateChange = (field:any, date:any) => {
    const newDate = moment(date, 'YYYY-MM-DD', true).isValid() ? moment(date).toDate() : null
    handleDatePickerChange(field, newDate)
  }

  const renderValue = (value:any) => (value === 0 ? '0' : value || ' ')

  return (
    <Box sx={{ display: 'flex' }}>
      <form
        style={{ display: 'flex', width: '100% ' }}
        onSubmit={(e) => handleFormSubmit(e, handleSubmit)}
      >
        <OPRAlertControl
          error={createdPensionFundSchemeRuleError || updatedPensionFundSchemeRuleError}
          handleEditable={setEditable}
          handleSetValue={setValues}
          handleSubmit={handleSubmit}
          isError={createdPensionFundSchemeRuleError || updatedPensionFundSchemeRuleIsError}
          isLoading={
            createdPensionFundSchemeRuleLoading
            || updatedPensionFundSchemeRuleLoading
            || updatedPensionFundSchemeRuleByIdLoading
          }
          isSuccess={updatedPensionFundSchemeRuleSuccess || createdPensionFundSchemeRuleSuccess}
          name={values?.pensionFundSchemeRuleType}
          title={t('PensionFundSchemeRule')}
          type={id ? 'Update' : 'New'}
        />

        <OPRInnerFormLayout
          error={createdPensionFundSchemeRuleError || updatedPensionFundSchemeRuleError}
          handleCancelClick={() => navigate(-1)}
          handleContinueClick={handleSubmit}
          handleEditable={() => {
            setEditable(true)
          }}
          isBackButton={isEditable}
          isLoading={
            createdPensionFundSchemeRuleLoading
            || updatedPensionFundSchemeRuleLoading
            || updatedPensionFundSchemeRuleByIdLoading
          }
          pageType="detailsPage"
          subtitle={
            isEditable
              ? 'Please check the user details below.'
              : 'All fields are mandatory except those marked optional'
          }
          // title={t('Entity_pension_rule_name')}
          title={(viewUrl) ? t('Pension fund scheme rules') : false || ((id) ? values?.pensionFundSchemeRuleType : t('Add Pension fund scheme rules'))} // Set title based on mode
          onScreenClose={onScreenClose}

        >
          <Box>
            <OPRResponsiveGrid>
              {/* pension fund scheme rule */}
              <Grid item xs={12}>
                <div className="ServiceProvider">
                  General information
                </div>
              </Grid>
              <Grid item md={2} sm={1} xs={1}>
                {/* pension fund scheme rule type */}
                <OPRInputControl
                  disabled={!!id}
                  error={errors?.pensionFundSchemeRuleType}
                  isEditable={isEditable}
                  // label={t('ent_pens_fund_scheme_rule_type')}
                  label="Pension fund scheme rule type"
                  name="pensionFundSchemeRuleType"
                  value={values?.pensionFundSchemeRuleType}
                  onChange={handleChange}
                />

              </Grid>
              {/* empty grid */}
              <Grid item md={2} sm={1} xs={1} />
              <Grid item md={2} sm={1} xs={1}>
                {/* effective start date */}
                <OPRDatePickerControl
                  error={errors?.effectiveStartDate}
                  isEditable={isEditable}
                  label="Effective start date"
                  name="effectiveStartDate"
                  value={
                    values?.effectiveStartDate
                      ? moment(values.effectiveStartDate).format('DD MMMM YYYY')
                      : null
                  }
                  onChange={(date) => handleDateChange('effectiveStartDate', date)}
                />
              </Grid>
              <Grid item md={2} sm={1} xs={1}>
                {/* effective end date */}

                <OPRDatePickerControl
                  error={errors?.effectiveEndDate}
                  isEditable={isEditable}
                  // label={t('ent_pens_fund_scheme_rule_rel_inc_min_amt')}
                  label="Effective end date"
                  name="effectiveEndDate"
                  value={
                    values?.effectiveEndDate
                      ? moment(values.effectiveEndDate).format('DD MMMM YYYY')
                      : null
                  }
                  // onChange={(date) => {
                  //   handleOnChange('effectiveEndDate', new Date(date))
                  // }}
                  onChange={(date) => handleDateChange('effectiveEndDate', date)}
                />
              </Grid>
              <Grid item md={2} sm={1} xs={1}>
                {/* relevant income min amount */}
                <OPRInputControl
                  error={errors?.relevantIncomeMinAmount}
                  isEditable={isEditable}
                  // label={t('ent_pens_fund_scheme_rule_rel_inc_max_amt')}
                  label="Relevant income min amount"
                  name="relevantIncomeMinAmount"
                  value={renderValue(values?.relevantIncomeMinAmount)}
                  onChange={handleChange}
                />
              </Grid>
              <Grid item md={2} sm={1} xs={1}>
                {/* relevant income max amount */}
                <OPRInputControl
                  error={errors?.relevantIncomeMaxAmount}
                  isEditable={isEditable}
                  // label={t('ent_pens_fund_scheme_rule_rel_inc_min_amt')}
                  label="Relevant income max amount"
                  name="relevantIncomeMaxAmount"
                  value={renderValue(values?.relevantIncomeMaxAmount)}
                  onChange={handleChange}
                />
              </Grid>
              <Grid item md={2} sm={1} xs={1}>
                {/* year of service from */}
                <OPRInputControl
                  error={errors?.yearOfServiceFrom}
                  isEditable={isEditable}
                  label={t('ent_pens_fund_scheme_rule_yr_serv_from')}
                  name="yearOfServiceFrom"
                  optionalText="optional"
                  value={renderValue(values?.yearOfServiceFrom)}
                  onChange={handleChange}
                />
              </Grid>
              <Grid item md={2} sm={1} xs={1}>
                {/* year of service to */}
                <OPRInputControl
                  error={errors?.yearOfServiceTo}
                  isEditable={isEditable}
                  label={t('ent_pens_fund_scheme_rule_yr_serv_to')}
                  name="yearOfServiceTo"
                  optionalText="optional"
                  value={renderValue(values?.yearOfServiceTo)}
                  onChange={handleChange}
                />
              </Grid>
              <Grid item xs={12}>
                <div className="ServiceProvider">
                  Employer contribution
                </div>
              </Grid>
              <Grid item md={2} sm={1} xs={1}>
                {/* employer contribution rate */}
                <OPRInputControl
                  error={errors?.employerContributionRate}
                  isEditable={isEditable}
                  // label={t('ent_pens_fund_scheme_rule_emplyr_cont_rate')}
                  label="Employer contribution rate (%)"
                  name="employerContributionRate"
                  optionalText="optional"
                  value={renderValue(values?.employerContributionRate)}
                  onChange={handleChange}
                />
              </Grid>
              <Grid item md={2} sm={1} xs={1}>
                {/* employer fixed contribution amount */}
                <OPRInputControl
                  error={errors?.employerFixedContributionAmount}
                  isEditable={isEditable}
                  label={t('ent_pens_fund_scheme_rule_emplyr_fixed_cont_amt')}
                  name="employerFixedContributionAmount"
                  optionalText="optional"
                  value={renderValue(values?.employerFixedContributionAmount)}
                  onChange={handleChange}
                />
              </Grid>
              <Grid item md={2} sm={1} xs={1}>
                {/* employee annual contribution cap */}
                {/* employee annual contribution cap */}
                <OPRInputControl
                  error={errors?.employerAnnualContributionCap}
                  isEditable={isEditable}
                  label={t('ent_pens_fund_scheme_rule_emplyr_annual_cont_cap')}
                  name="employerAnnualContributionCap"
                  optionalText="optional"
                  value={renderValue(values?.employerAnnualContributionCap)}
                  onChange={handleChange}
                />
                {/* <OPRInputControl
                  error={errors?.employerAnnualContributionCap}
                  isEditable={isEditable}
                  label={t('ent_pens_fund_scheme_rule_employee_annual_cont_cap')}
                  name="employerAnnualContributionCap"
                  optionalText="optional"
                  value={values?.employerAnnualContributionCap}
                  onChange={handleChange}
                /> */}
              </Grid>
              <Grid item xs={12}>
                <div className="ServiceProvider">
                  Employee contribution
                </div>
              </Grid>
              <Grid item md={2} sm={1} xs={1}>
                {/* employee fixed contribution amount */}
                <OPRInputControl
                  error={errors?.employeeContributionRate}
                  isEditable={isEditable}
                  // label={t('ent_pens_fund_scheme_rule_employee_cont_rate')}
                  label="Employee contribution rate (%)"
                  name="employeeContributionRate"
                  optionalText="optional"
                  value={renderValue(values?.employeeContributionRate)}
                  onChange={handleChange}
                />
              </Grid>
              <Grid item md={2} sm={1} xs={1}>
                {/* employee fixed contribution amount */}
                <OPRInputControl
                  error={errors?.employeeFixedContributionAmount}
                  isEditable={isEditable}
                  label={t('ent_pens_fund_scheme_rule_employee_fixed_cont_amt')}
                  name="employeeFixedContributionAmount"
                  optionalText="optional"
                  value={renderValue(values?.employeeFixedContributionAmount)}
                  onChange={handleChange}
                />
              </Grid>
              <Grid item md={2} sm={1} xs={1}>
                {/* employee annual contribution cap */}
                <OPRInputControl
                  error={errors?.employeeAnnualContributionCap}
                  isEditable={isEditable}
                  // label={t('ent_pens_fund_scheme_rule_emplyr_annual_cont_cap')}
                  label="Employee annual contribution cap"
                  name="employeeAnnualContributionCap"
                  optionalText="optional"
                  value={renderValue(values?.employeeAnnualContributionCap)}
                  onChange={handleChange}
                />
              </Grid>

            </OPRResponsiveGrid>

          </Box>
        </OPRInnerFormLayout>
      </form>
    </Box>
  )
}
