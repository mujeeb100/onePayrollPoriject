// pension fund schme rule
// PensionFundSchemeRule
import {
  Box,
} from '@mui/material'
import { useGetAllPensionFundSchemeRuleQuery, usePensionFundSchemeRuleDeleteMutation } from 'api/entityServices'
import { entitypensionFundSchemeRuleCols } from 'components/atoms/table/OPRTableConstant'
import { OPRInnerListLayout } from 'components/organism/OPRInnerLayoutList'
import apiEndPoint from 'constants/apiEndPoint'
import { pensionFundSchemeRuleColumnMappings } from 'constants/exportColumnMappings'
import { useTranslatedColumnsForPDF } from 'hooks/useTranslatedColumnsForPDF'
import { t } from 'i18next'
import React, { useEffect, useState } from 'react'
// import { entityPensionFundSchemeRuleColumn } from 'components/atoms/table/OPRTableConstant'
import { useNavigate } from 'react-router-dom'
import { routes } from 'routes/routes'
import {
  generateFilterUrl, getAPIWithEntityUrl, getEnv, setRouteValues,
} from 'utils'

function PensionFundSchemeRuleList() {
  const navigate: any = useNavigate()
  const [filterData, setFilterData]:any = useState({
    pageNumber: 1,
    pageSize: 20,
    totalItems: 0,
    orderByAsc: true,
    sortBy: '',
    SearchText: '',
  })

  const [selelctedDelete, setSelelctedDelete]:any = useState({
    data: {},
    isDelete: false,
    name: '',
  })
  const {
    data: allPosts,
    isLoading: isLoadingAllPosts,
    isSuccess: isSuccessAllPosts,
    isError: isErrorAllPosts,
    error: errorAllPosts,
    refetch: refetchAllPosts,
  } = useGetAllPensionFundSchemeRuleQuery(generateFilterUrl(filterData))

  const [deletePensionFundSchemeRuleById,
    {
      data: deletePensionFundSchemeRuleResponse,
      error: deletePensionFundSchemeRuleError,
      isLoading: deletePensionFundSchemeRuleLoading,
      isSuccess: deletePensionFundSchemeRuleSuccess,
      isError: deletePensionFundSchemeRuleIsError,
    }] = usePensionFundSchemeRuleDeleteMutation()

  const sorting = (
    event: React.MouseEvent<unknown>,
    property: keyof any,
  ) => {
    const isAsc = filterData.sortBy === property && filterData.orderByAsc === true
    setFilterData({ ...filterData, orderByAsc: !isAsc, sortBy: property })
  }

  useEffect(() => {
    setFilterData({ ...filterData, totalItems: allPosts?.totalItems ? allPosts?.totalItems : 0 })
  }, [allPosts?.pageNumber, filterData.sortBy, filterData.orderByAsc, allPosts?.totalItems])

  const onSearch = (e: any, data: any) => {
    setFilterData({ ...filterData, ...data })
  }

  const handlePagination = (pageNumber: number, pageSize: number) => {
    setFilterData({ ...filterData, pageNumber })
  }

  const viewAcoount = (data: any, type:string) => {
    if (type === 'Edit Pension Fund Scheme Rule') {
      navigate(
        setRouteValues(`${routes.editPensionFundSchemeRule}`, {
          id: data.id,
        }),
      )
    } else if (type === 'Delete Pension Fund Scheme Rule') {
      // deletePensionFundSchemeRuleById(`Id=${data.id}`)
      setSelelctedDelete({ data, isDelete: true, name: data.pensionFundSchemeRuleType })
    } else {
      navigate(
        setRouteValues(`${routes.viewPensionFundSchemeRule}`, {
          id: data.id,
        }),
      )
    }
  }

  const handleView = (data: any) => {
    const ensureDefaultValues = (obj: any) => ({
      ...obj,
      relevantIncomeMinAmount: obj.relevantIncomeMinAmount ?? 0,
      relevantIncomeMaxAmount: obj.relevantIncomeMaxAmount ?? 999999999,
      yearOfServiceFrom: obj.yearOfServiceFrom ?? 0,
      yearOfServiceTo: obj.yearOfServiceTo ?? 99,
      employerContributionRate: obj.employerContributionRate ?? 0,
      employeeContributionRate: obj.employeeContributionRate ?? 0,
      employerFixedContributionAmount: obj.employerFixedContributionAmount ?? 0,
      employeeFixedContributionAmount: obj.employeeFixedContributionAmount ?? 0,
      employerAnnualContributionCap: obj.employerAnnualContributionCap ?? 0,
      employeeAnnualContributionCap: obj.employeeAnnualContributionCap ?? 0,
    })

    const dataWithDefaults = ensureDefaultValues(data)

    navigate(
      setRouteValues(`${routes.viewPensionFundSchemeRule}`, {
        id: dataWithDefaults.id,
        view: true,
        ...dataWithDefaults,
      }),
    )
  }
  // handle Delete
  const handleDelete = (data:any) => {
    deletePensionFundSchemeRuleById(`Id=${data.id}`)
  }
  return (
    <Box sx={{ display: 'flex' }}>
      <OPRInnerListLayout
        isExport
        Search={decodeURIComponent(filterData.SearchText)}
        addHandleClick={() => navigate(routes.createPensionFundSchemeRule)}
        columns={entitypensionFundSchemeRuleCols(viewAcoount)}
        dataList={JSON.parse(JSON.stringify(allPosts?.records || []))}
        deleteCallBack={handleDelete}
        error={errorAllPosts || deletePensionFundSchemeRuleError}
        exportProps={{
          data: allPosts?.records,
          fileName: 'PensionFundSchemeRule',
          columns: useTranslatedColumnsForPDF(pensionFundSchemeRuleColumnMappings),
          pdf: {
            orientation: 'landscape',
          },
          allRecords: {
            baseURL: getEnv('REACT_APP_UP_BASE_URL', null),
            endpoint: getAPIWithEntityUrl(apiEndPoint.pensionFundSchemeRuleList),
            filterData,
          },
        }}
        filterData={filterData}
        handlePagination={handlePagination}
        handleSearch={onSearch}
        isError={isErrorAllPosts || deletePensionFundSchemeRuleIsError}
        loading={isLoadingAllPosts || deletePensionFundSchemeRuleLoading}
        rowClickHandler={handleView}
        rowNumber={0}
        selelctedUser={selelctedDelete}
        setSelelctedUser={setSelelctedDelete}
        sortHandleClick={sorting}
        success={deletePensionFundSchemeRuleSuccess}
        title={t('Pension fund scheme rules')}
      />
    </Box>
  )
}

export default PensionFundSchemeRuleList
