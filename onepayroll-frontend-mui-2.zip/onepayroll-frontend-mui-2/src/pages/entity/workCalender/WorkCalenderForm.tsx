import { Box, Grid } from '@mui/material'
import {
  useLazyGetWorkCalenderByIdQuery,
  useWorkCalenderCreateMutation,
  useWorkCalenderUpdateMutation,
} from 'api/entityServices'
import { useGetAllHolidayCalenderQuery } from 'api/globalServices'
import OPRLabel from 'components/atoms/label/OPRLabel'
import OPRInputControl from 'components/molecules/OPRInputControl'
import OPRResponsiveGrid from 'components/molecules/OPRResponsiveGrid'
import OPRSelectorControl from 'components/molecules/OPRSelectorControl/OPRSelectorControl'
import OPRTextArea from 'components/molecules/OPRTextArea/OPRTextArea'
import OPRAlertControl from 'components/organism/OPRAlertControl'
import { OPRInnerFormLayout } from 'components/organism/OPRInnerFormLayout'
import {
  validationSchemaWorkCalender,
} from 'constants/validate'
import { useEditable } from 'hooks/useEdit'
import useForm from 'hooks/useForm'
import { t } from 'i18next'
import { useEffect, useState } from 'react'
import { useLocation, useNavigate } from 'react-router-dom'
import { routes } from 'routes/routes'
import { getParamsValue } from 'utils'

const defaultValue = {
  cawCalculationMethod: null,
  holidayCalendar: null,
  holidaysPaymentOption: null,
  workCalendarCode: null,
  workCalendarName: null,
  hoursPerFullWorkDay: '8.00',
  salaryProrationMethod: null,
  sunday: 'Off Day',
  monday: 'Work Day - Full Day',
  tuesday: 'Work Day - Full Day',
  wednesday: 'Work Day - Full Day',
  thursday: 'Work Day - Full Day',
  friday: 'Work Day - Full Day',
  saturday: 'Off Day',
  remarks: '',
}

interface MessageProps {
  text?: string;
  important?: boolean;
}

export default function WorkCalenderForm() {
  const location: any = useLocation()
  // const id = getParamsValue(location, routes.createWorkCalender)
  const { id, viewUrl } = getParamsValue(location, routes.createWorkCalender)
  const [mode, setMode] = useState('view') // Default mode is edit
  const { isEditable, setEditable } = useEditable()

  const {
    values,
    setValues,
    errors,
    handleChange,
    setErrors,
    handleFormSubmit,
    handleOnChange,
  } = useForm(validationSchemaWorkCalender)

  const navigate = useNavigate()
  const [
    createWorkCalender,
    {
      data: createdWorkCalenderData,
      error: createdWorkCalenderError,
      isLoading: createdWorkCalenderLoading,
      isSuccess: createdWorkCalenderSuccess,
      isError: createdWorkCalenderIsError,
    },
  ] = useWorkCalenderCreateMutation()

  const [
    updateWorkCalender,
    {
      data: updatedDataResponse,
      error: updatedWorkCalenderError,
      isLoading: updatedWorkCalenderLoading,
      isSuccess: updatedWorkCalenderSuccess,
      isError: updatedWorkCalenderIsError,
    },
  ] = useWorkCalenderUpdateMutation()

  const [
    updateWorkCalenderById,
    {
      data: updatedWorkCalenderByIdResponse,
      error: updatedWorkCalenderByIdError,
      isLoading: updatedWorkCalenderByIdLoading,
      isSuccess: updatedWorkCalenderByIdSuccess,
      isError: updatedWorkCalenderByIdIsError,
    },
  ] = useLazyGetWorkCalenderByIdQuery()

  const {
    data: allPostsHC,
  } = useGetAllHolidayCalenderQuery('')

  useEffect(() => {
    if (id) {
      updateWorkCalenderById(id)
      setEditable(viewUrl)
      // setMode('view') // Set mode to view if id is present
    }
  }, [])
  useEffect(() => {
    if (id) {
      setValues(updatedWorkCalenderByIdResponse?.data)
    } else {
      setValues(location.state ? location.state : {})
    }
  }, [updatedWorkCalenderByIdResponse?.data])

  // reset the values
  // useEffect(() => {
  //   if (createdWorkCalenderSuccess) {
  //     setValues({})
  //   }
  // }, [createdWorkCalenderSuccess])

  const handleSubmit: any = async () => {
    if (isEditable) {
      if (id === null) {
        await createWorkCalender({
          cawCalculationMethod: values?.cawCalculationMethod,
          caW_DivideByFixedDays: values?.caW_DivideByFixedDays,
          holidayCalendar: values?.holidayCalendar,
          spM_DivideByFixedDays: values?.spM_DivideByFixedDays,
          spM_ActualDaysMethod: values?.spM_ActualDaysMethod,
          holidaysPaymentOption: values?.holidaysPaymentOption,
          workCalendarCode: values?.workCalendarCode,
          workCalendarName: values?.workCalendarName,
          hoursPerFullWorkDay: values?.hoursPerFullWorkDay,
          salaryProrationMethod: values?.salaryProrationMethod,
          remarks: values?.remarks,
          sunday: values?.sunday,
          monday: values?.monday,
          tuesday: values?.tuesday,
          wednesday: values?.wednesday,
          thursday: values?.thursday,
          friday: values?.friday,
          saturday: values?.saturday,
        })
      } else {
        await updateWorkCalender({
          cawCalculationMethod: values?.cawCalculationMethod,
          caW_DivideByFixedDays: values?.caW_DivideByFixedDays,
          holidayCalendar: values?.holidayCalendar,
          spM_DivideByFixedDays: values?.spM_DivideByFixedDays,
          spM_ActualDaysMethod: values?.spM_ActualDaysMethod,
          holidaysPaymentOption: values?.holidaysPaymentOption,
          workCalendarCode: values?.workCalendarCode,
          workCalendarName: values?.workCalendarName,
          hoursPerFullWorkDay: values?.hoursPerFullWorkDay,
          salaryProrationMethod: values?.salaryProrationMethod,
          remarks: values?.remarks,
          sunday: values?.sunday,
          monday: values?.monday,
          tuesday: values?.tuesday,
          wednesday: values?.wednesday,
          thursday: values?.thursday,
          friday: values?.friday,
          saturday: values?.saturday,
        })
      }
    } else {
      setEditable(true)
    }
  }

  async function editWorkCalender() {
    await updateWorkCalender({
      cawCalculationMethod: values?.cawCalculationMethod,
      caW_DivideByFixedDays: values?.caW_DivideByFixedDays,
      holidayCalendar: values?.holidayCalendar,
      spM_DivideByFixedDays: values?.spM_DivideByFixedDays,
      spM_ActualDaysMethod: values?.spM_ActualDaysMethod,
      holidaysPaymentOption: values?.holidaysPaymentOption,
      workCalendarCode: values?.workCalendarCode,
      workCalendarName: values?.workCalendarName,
      hoursPerFullWorkDay: values?.hoursPerFullWorkDay,
      salaryProrationMethod: values?.salaryProrationMethod,
      remarks: values?.remarks,
      sunday: values?.sunday,
      monday: values?.monday,
      tuesday: values?.tuesday,
      wednesday: values?.wednesday,
      thursday: values?.thursday,
      friday: values?.friday,
      saturday: values?.saturday,
    })
  }

  useEffect(() => {
    if (id === null) {
      setValues(defaultValue)
    }
  }, [])

  const onScreenClose:any = (item: any) => {
    setEditable(item)
    setValues({})
  }

  return (
    <Box sx={{ display: 'flex' }}>
      <form
        style={{ display: 'flex', width: '100% ' }}
        onSubmit={(e) => handleFormSubmit(e, handleSubmit)}
      >
        <OPRAlertControl
          error={createdWorkCalenderError || updatedWorkCalenderError}
          handleEditable={setEditable}
          handleSetValue={setValues}
          handleSubmit={handleSubmit}
          isError={createdWorkCalenderError || updatedWorkCalenderError}
          isLoading={
            createdWorkCalenderLoading
            || updatedWorkCalenderLoading
            || updatedWorkCalenderByIdLoading
          }
          isSuccess={updatedWorkCalenderSuccess || createdWorkCalenderSuccess}
          name={values?.workCalendarName}
          title={t('WorkCalender')}
          type={id ? 'Update' : 'New'}
        />

        <OPRInnerFormLayout
          isHandleContinueClick
          error={createdWorkCalenderError || updatedWorkCalenderError}
          handleCancelClick={() => navigate(-1)}
          handleContinueClick={handleSubmit}
          handleEditable={() => {
            setEditable(true)
          }}
          isBackButton={isEditable}
          isLoading={
            createdWorkCalenderLoading
            || updatedWorkCalenderLoading
            || updatedWorkCalenderByIdLoading
          }
          pageType="detailsPage"
          subtitle={
            isEditable
              ? 'Please check the user details below.'
              : 'All fields are mandatory except those marked optional'
          }
          title={(viewUrl) ? t('WorkCalender') : false || ((id) ? values?.workCalendarName : `${t('add')} ${t('WorkCalender')}`)}
          onScreenClose={onScreenClose}

        >
          <Box>
            <OPRResponsiveGrid>
              <div style={{ display: 'block', width: '100%', margin: '30px 20px 20px' }}>
                <OPRLabel variant="h3">General information</OPRLabel>
              </div>

              <Grid item md={2} sm={1} xs={1}>
                <OPRInputControl
                  disabled={!!id}
                  error={t(errors?.workCalendarCode)}
                  isEditable={isEditable}
                  label="ent_work_calendar_view_code"
                  name="workCalendarCode"
                  value={values?.workCalendarCode}
                  onChange={handleChange}
                />
              </Grid>
              <Grid item md={2} sm={1} xs={1}>
                <OPRInputControl
                  error={t(errors?.workCalendarName)}
                  isEditable={isEditable}
                  label="ent_work_calendar_view_name"
                  name="workCalendarName"
                  value={values?.workCalendarName}
                  onChange={handleChange}
                />
              </Grid>
              <Grid item md={2} sm={1} xs={1}>
                <OPRSelectorControl
                  error={errors?.holidayCalendar}
                  isEditable={isEditable}
                  keyName="holidayCalendarName"
                  label="ent_work_calendar_holiday_calendar"
                  multiple={false}
                  name="holidayCalendar"
                  options={(allPostsHC?.records || [])}
                  placeholder="Select an option"
                  value={(allPostsHC?.records || [])?.find((o:any) => o?.holidayCalendarCode === values?.holidayCalendar) || {}}
                  valueKey="holidayCalendarCode"
                  onChange={(text:any) => {
                    handleOnChange('holidayCalendar', text?.holidayCalendarCode)
                  }}
                />

              </Grid>

              <Grid item md={2} sm={1} xs={1}>
                <OPRSelectorControl
                  error={errors?.holidaysPaymentOption}
                  isEditable={isEditable}
                  keyName="holidayPaymentName"
                  label="ent_work_calendar_holidays_pay_opt"
                  multiple={false}
                  name="holidaysPaymentOption"
                  options={[
                    { holidayPaymentName: 'Paid for Statutory and Public Holidays', holidayPaymentValue: 'Paid for Statutory and Public Holidays' },
                    { holidayPaymentName: 'Paid for only Statutory Holidays', holidayPaymentValue: 'Paid for only Statutory Holidays' },
                  ]}
                  placeholder="Select an option"
                  value={
                    { holidayPaymentName: values?.holidaysPaymentOption, holidayPaymentValue: values?.holidaysPaymentOption }
                  }
                  valueKey="holidayPaymentValue"
                  onChange={(text:any) => {
                    handleOnChange('holidaysPaymentOption', text?.holidayPaymentValue)
                  }}
                />
              </Grid>

              <Grid item md={2} sm={1} xs={1}>
                <OPRSelectorControl
                  error={errors?.salaryProrationMethod}
                  isEditable={isEditable}
                  keyName="salaryProrationMethodName"
                  label="ent_work_calendar_salary_proration_method"
                  multiple={false}
                  name="salaryProrationMethod"
                  options={[
                    { salaryProrationMethodName: 'Base Salary / Calendar Days in the Month', salaryProrationMethodValue: 'Base Salary / Calendar Days in the Month' },
                    { salaryProrationMethodName: 'Base Salary / Working Days in the Month', salaryProrationMethodValue: 'Base Salary / Working Days in the Month' },
                    { salaryProrationMethodName: 'Base Salary / Fixed Days', salaryProrationMethodValue: 'Base Salary / Fixed Days' },
                    { salaryProrationMethodName: 'Base Salary * 12 / Calendar Days in the Year', salaryProrationMethodValue: 'Base Salary * 12 / Calendar Days in the Year' },
                    { salaryProrationMethodName: 'Base Salary * 12 / Working Days in the Year', salaryProrationMethodValue: 'Base Salary * 12 / Working Days in the Year' },
                    { salaryProrationMethodName: 'Base Salary * 12 / Fixed Days', salaryProrationMethodValue: 'Base Salary * 12 / Fixed Days' },

                  ]}
                  placeholder="Select an option"
                  value={
                    { salaryProrationMethodName: values?.salaryProrationMethod, salaryProrationMethodValue: values?.salaryProrationMethod }
                  }
                  valueKey="salaryProrationMethodValue"
                  onChange={(text:any) => {
                    handleOnChange('salaryProrationMethod', text?.salaryProrationMethodValue)
                  }}
                />
              </Grid>

              <Grid item md={2} sm={1} xs={1}>
                <OPRSelectorControl
                  error={errors?.cawCalculationMethod}
                  isEditable={isEditable}
                  keyName="cawCalculationMethodName"
                  label="ent_work_calendar_caw_calculation_method"
                  multiple={false}
                  name="cawCalculationMethod"
                  options={[
                    { cawCalculationMethodName: 'Same as Salary Proration Method', cawCalculationMethodValue: 'Same as Salary Proration Method' },
                    { cawCalculationMethodName: 'Base Salary / Calendar Days in the Month', cawCalculationMethodValue: 'Base Salary / Calendar Days in the Month' },
                    { cawCalculationMethodName: 'Base Salary / Working Days in the Month', cawCalculationMethodValue: 'Base Salary / Working Days in the Month' },
                    { cawCalculationMethodName: 'Base Salary / Fixed Days', cawCalculationMethodValue: 'Base Salary / Fixed Days' },
                    { cawCalculationMethodName: 'Base Salary * 12 / Calendar Days in the Year', cawCalculationMethodValue: 'Base Salary * 12 / Calendar Days in the Year' },
                    { cawCalculationMethodName: 'Base Salary * 12 / Working Days in the Year', cawCalculationMethodValue: 'Base Salary * 12 / Working Days in the Year' },
                    { cawCalculationMethodName: 'Base Salary * 12 / Fixed Days', cawCalculationMethodValue: 'Base Salary * 12 / Fixed Days' },

                  ]}
                  placeholder="Select an option"
                  value={
                    { cawCalculationMethodName: values?.cawCalculationMethod, cawCalculationMethodValue: values?.cawCalculationMethod }
                  }
                  valueKey="cawCalculationMethodValue"
                  onChange={(text:any) => {
                    handleOnChange('cawCalculationMethod', text?.cawCalculationMethodValue)
                  }}
                />
              </Grid>
              {/* spM_ActualDaysMethod */}
              <Grid item md={2} sm={1} xs={1}>
                {['Base Salary / Fixed Days', 'Base Salary * 12 / Fixed Days'].includes(
                  values?.salaryProrationMethod,
                ) && (
                  <OPRInputControl
                    error={t(errors?.spM_DivideByFixedDays)}
                    isEditable={isEditable}
                    label="Salary Proration Method - Divide by Fixed Days"
                    name="spM_DivideByFixedDays"
                    value={values?.spM_DivideByFixedDays}
                    onChange={handleChange}
                    // onChange={(text: any) => setValues({ ...values, spM_ActualDaysMethod: text?.spM_ActualDaysMethod })}

                  />
                )}
              </Grid>
              {/* SPM_ActualDaysMethod */}
              <Grid item md={2} sm={1} xs={1}>
                {['Base Salary / Fixed Days', 'Base Salary * 12 / Fixed Days'].includes(
                  values?.salaryProrationMethod,
                ) && (
                  <OPRSelectorControl
                    error={errors?.spM_ActualDaysMethod}
                    isEditable={isEditable}
                    keyName="SPM_ActualDaysMethodName"
                    label="Salary Proration Method - Actual Days Method"
                    multiple={false}
                    name="spM_ActualDaysMethod"
                    options={[
                      { SPM_ActualDaysMethodName: 'Actual Calendar Days', SPM_ActualDaysMethodValue: 'Actual Calendar Days' },
                      { SPM_ActualDaysMethodName: 'Actual Working Days', SPM_ActualDaysMethodValue: 'Actual Working Days' },
                    ]}
                    placeholder="Select an option"
                    value={
                      { SPM_ActualDaysMethodName: values?.spM_ActualDaysMethod, SPM_ActualDaysMethodValue: values?.spM_ActualDaysMethod }
                    }
                    valueKey="SPM_ActualDaysMethodValue"
                    onChange={(text:any) => {
                      handleOnChange('spM_ActualDaysMethod', text?.SPM_ActualDaysMethodValue)
                    }}
                  />
                )}
              </Grid>
              {/* caW_DivideByFixedDays */}
              <Grid item md={2} sm={1} xs={1}>
                {['Base Salary / Fixed Days', 'Base Salary * 12 / Fixed Days'].includes(
                  values?.cawCalculationMethod,
                ) && (
                  <OPRInputControl
                    error={t(errors?.caW_DivideByFixedDays)}
                    isEditable={isEditable}
                    label="CAW Calculation Method - Divide by Fixed Days"
                    name="caW_DivideByFixedDays"
                    value={values?.caW_DivideByFixedDays}
                    onChange={handleChange}
                  />
                )}

              </Grid>

              <Grid item md={4} sm={6} xs={12}>
                <OPRTextArea
                  error={t(errors?.remarks)}
                  isEditable={isEditable}
                  label="remarks"
                  name="remarks"
                  optionalText="Optional"
                  value={values?.remarks}
                  onChange={handleChange}
                />
              </Grid>

              {/* if condition raw CAW  */}
              {/*
              {values?.cawCalculationMethod === 'Base Salary / Fixed Days'
 || values?.cawCalculationMethod === 'Base Salary * 12 / Fixed Days'
                ? (
                  <Grid item md={2} sm={1} xs={1}>
                    <OPRInputControl
                      disabled={!!id}
                      error={t(errors?.WorkCalenderCode)}
                      isEditable={isEditable}
                      label="CAW CALC"
                      name=""
                      value={values}
                      onChange={handleChange}
                    />
                  </Grid>
                )
                : null} */}

              <div style={{ display: 'block', width: '100%', margin: '30px 20px 20px' }}>
                <OPRLabel variant="h3">Working schedule</OPRLabel>
              </div>

              <Grid item md={2} sm={1} xs={1}>
                <OPRSelectorControl
                  error={errors?.sunday}
                  isEditable={isEditable}
                  keyName="SundayName"
                  label="ent_work_calendar_sunday"
                  multiple={false}
                  name="sunday"
                  options={[
                    { SundayName: 'Work Day - Full Day', SundayValue: 'Work Day - Full Day' },
                    { SundayName: 'Work Day - Half Day', SundayValue: 'Work Day - Half Day' },
                    { SundayName: 'Off Day', SundayValue: 'Off Day' },
                  ]}
                  placeholder="Select an option"
                  value={
                    { SundayName: values?.sunday, SundayValue: values?.sunday }
                  }
                  valueKey="SundayValue"
                  onChange={(text:any) => {
                    handleOnChange('sunday', text?.SundayValue)
                  }}
                />
              </Grid>
              <Grid item md={2} sm={1} xs={1}>
                <OPRSelectorControl
                  error={errors?.monday}
                  isEditable={isEditable}
                  keyName="MondayName"
                  label="ent_work_calendar_monday"
                  multiple={false}
                  name="monday"
                  options={[
                    { MondayName: 'Work Day - Full Day', MondayValue: 'Work Day - Full Day' },
                    { MondayName: 'Work Day - Half Day', MondayValue: 'Work Day - Half Day' },
                    { MondayName: 'Off Day', MondayValue: 'Off Day' },
                  ]}
                  placeholder="Select an option"
                  value={
                    { MondayName: values?.monday, MondayValue: values?.monday }
                  }
                  valueKey="MondayValue"
                  onChange={(text:any) => {
                    handleOnChange('monday', text?.MondayValue)
                  }}
                />
              </Grid>
              <Grid item md={2} sm={1} xs={1}>
                <OPRSelectorControl
                  error={errors?.tuesday}
                  isEditable={isEditable}
                  keyName="TuesdayName"
                  label="ent_work_calendar_tuesday"
                  multiple={false}
                  name="tuesday"
                  options={[
                    { TuesdayName: 'Work Day - Full Day', TuesdayValue: 'Work Day - Full Day' },
                    { TuesdayName: 'Work Day - Half Day', TuesdayValue: 'Work Day - Half Day' },
                    { TuesdayName: 'Off Day', TuesdayValue: 'Off Day' },
                  ]}
                  placeholder="Select an option"
                  value={
                    { TuesdayName: values?.tuesday, TuesdayValue: values?.tuesday }
                  }
                  valueKey="TuesdayValue"
                  onChange={(text:any) => {
                    handleOnChange('tuesday', text?.TuesdayValue)
                  }}
                />
              </Grid>
              <Grid item md={2} sm={1} xs={1}>
                <OPRSelectorControl
                  error={errors?.wednesday}
                  isEditable={isEditable}
                  keyName="WednesdayName"
                  label="ent_work_calendar_wednesday"
                  multiple={false}
                  name="wednesday"
                  options={[
                    { WednesdayName: 'Work Day - Full Day', WednesdayValue: 'Work Day - Full Day' },
                    { WednesdayName: 'Work Day - Half Day', WednesdayValue: 'Work Day - Half Day' },
                    { WednesdayName: 'Off Day', WednesdayValue: 'Off Day' },
                  ]}
                  placeholder="Select an option"
                  value={
                    { WednesdayName: values?.wednesday, WednesdayValue: values?.wednesday }
                  }
                  valueKey="WednesdayValue"
                  onChange={(text:any) => {
                    handleOnChange('wednesday', text?.WednesdayValue)
                  }}
                />
              </Grid>
              <Grid item md={2} sm={1} xs={1}>
                <OPRSelectorControl
                  error={errors?.thursday}
                  isEditable={isEditable}
                  keyName="ThursdayName"
                  label="ent_work_calendar_thursday"
                  multiple={false}
                  name="thursday"
                  options={[
                    { ThursdayName: 'Work Day - Full Day', ThursdayValue: 'Work Day - Full Day' },
                    { ThursdayName: 'Work Day - Half Day', ThursdayValue: 'Work Day - Half Day' },
                    { ThursdayName: 'Off Day', ThursdayValue: 'Off Day' },
                  ]}
                  placeholder="Select an option"
                  value={
                    { ThursdayName: values?.thursday, ThursdayValue: values?.thursday }
                  }
                  valueKey="ThursdayValue"
                  onChange={(text:any) => {
                    handleOnChange('thursday', text?.ThursdayValue)
                  }}
                />
              </Grid>
              <Grid item md={2} sm={1} xs={1}>
                <OPRSelectorControl
                  error={errors?.friday}
                  isEditable={isEditable}
                  keyName="FridayName"
                  label="ent_work_calendar_friday"
                  multiple={false}
                  name="friday"
                  options={[
                    { FridayName: 'Work Day - Full Day', FridayValue: 'Work Day - Full Day' },
                    { FridayName: 'Work Day - Half Day', FridayValue: 'Work Day - Half Day' },
                    { FridayName: 'Off Day', FridayValue: 'Off Day' },
                  ]}
                  placeholder="Select an option"
                  value={
                    { FridayName: values?.friday, FridayValue: values?.friday }
                  }
                  valueKey="FridayValue"
                  onChange={(text:any) => {
                    handleOnChange('friday', text?.FridayValue)
                  }}
                />
              </Grid>
              <Grid item md={2} sm={1} xs={1}>
                <OPRSelectorControl
                  error={errors?.saturday}
                  isEditable={isEditable}
                  keyName="SaturdayName"
                  label="ent_work_calendar_saturday"
                  multiple={false}
                  name="saturday"
                  options={[
                    { SaturdayName: 'Work Day - Full Day', SaturdayValue: 'Work Day - Full Day' },
                    { SaturdayName: 'Work Day - Half Day', SaturdayValue: 'Work Day - Half Day' },
                    { SaturdayName: 'Off Day', SaturdayValue: 'Off Day' },
                  ]}
                  placeholder="Select an option"
                  value={
                    { SaturdayName: values?.saturday, SaturdayValue: values?.saturday }
                  }
                  valueKey="SaturdayValue"
                  onChange={(text:any) => {
                    handleOnChange('saturday', text?.SaturdayValue)
                  }}
                />
              </Grid>

              {/* <Grid item md={2} sm={1} xs={1}>
                <OPRInputControl
                  error={t(errors?.hoursPerFullWorkDay)}
                  isEditable={isEditable}
                  label="ent_work_calendar_hrs_day"
                  name="hoursPerFullWorkDay"
                  value={values?.hoursPerFullWorkDay}
                  onChange={handleChange}
                />
              </Grid> */}
            </OPRResponsiveGrid>
          </Box>
        </OPRInnerFormLayout>
      </form>
    </Box>
  )
}
