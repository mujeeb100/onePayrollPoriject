import { Box } from '@mui/material'
import OPRLabel from 'components/atoms/label/OPRLabel'
import {
  a11yProps,
  CustomTabPanel, StyledTab, StyledTabs,
} from 'components/atoms/tabs'
import { t } from 'i18next'
import React from 'react'

import { PensionFundSchemeCalculation } from './PensionFundCalculation'
import { PensionFundSchemeInformation } from './PensionFundInfo'
import { PensionFundSchemeSettings } from './PensionFundSchemeSettings'

export function Confirmation({
  errors, isEditable, values, handleChange, handleOnChange,
}:any) {
  const handleTabChange = (event: React.SyntheticEvent, newValue: number) => {
    setValue(newValue)
  }
  const [value, setValue] = React.useState(0)
  return (
    <Box sx={{ width: '100%' }}>
      <OPRLabel sx={{ marginTop: '20px', marginBottom: '20px', marginLeft: '10px' }} variant="body2">
        {`  ${t('please_check_details_below')}`}
      </OPRLabel>
      <Box sx={{ borderBottom: 1, borderColor: 'divider' }}>
        <StyledTabs aria-label="basic tabs example" value={value} onChange={handleTabChange}>
          <StyledTab label={t('pensionfund_scheme_step_information')} {...a11yProps(0)} />
          <StyledTab label={t('pensionfund_scheme_step_calculation')} {...a11yProps(1)} />
          <StyledTab label={t('pensionfund_scheme_step_settings')} {...a11yProps(2)} />
        </StyledTabs>
      </Box>
      <CustomTabPanel index={0} value={value}>
        <PensionFundSchemeInformation
          isEditable
          errors={errors}
          handleChange={handleChange}
          handleOnChange={handleOnChange}
          values={values}
        />
      </CustomTabPanel>
      <CustomTabPanel index={1} value={value}>
        <PensionFundSchemeCalculation
          isEditable
          errors={errors}
          handleChange={handleChange}
          handleOnChange={handleOnChange}
          values={values}
        />
      </CustomTabPanel>
      <CustomTabPanel index={2} value={value}>
        <PensionFundSchemeSettings
          isEditable
          errors={errors}
          handleChange={handleChange}
          handleOnChange={handleOnChange}
          values={values}
        />
      </CustomTabPanel>
    </Box>
  )
}
