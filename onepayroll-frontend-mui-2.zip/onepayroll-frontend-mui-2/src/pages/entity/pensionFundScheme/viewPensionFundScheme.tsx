import { Box } from '@mui/material'
import { useLazyGetPensionFundSchemeByIdQuery } from 'api/entityServices'
import { LeftBack } from 'assets/svg-images/SvgComponents'
import OPRLabel from 'components/atoms/label/OPRLabel'
import { entitypensionFundSchemeItemsColumn } from 'components/atoms/table/OPRTableConstant'
import { OPRInnerListLayout } from 'components/organism/OPRInnerLayoutList'
import { validationSchemaUserAccount } from 'constants/validate'
import { useEditable } from 'hooks/useEdit'
import useForm from 'hooks/useForm'
import { t } from 'i18next'
import React, { useEffect, useState } from 'react'
import { useLocation, useNavigate } from 'react-router-dom'
import { routes } from 'routes/routes'
import { getParamsValue, setRouteValues } from 'utils'

import {
  a11yProps,
  CustomTabPanel, StyledTab, StyledTabs,
} from '../../../components/atoms/tabs'
import { PensionFundSchemeCalculation } from './PensionFundCalculation'
import { PensionFundSchemeInformation } from './PensionFundInfo'
import { PensionFundSchemeSettings } from './PensionFundSchemeSettings'

export default function ViewPensionFundScheme() {
  const navigate = useNavigate()
  const location: any = useLocation()
  const { id, viewUrl } = getParamsValue(location, routes.createUserAccounts)
  const [value, setValue] = React.useState(0)
  const [filterData, setFilterData]:any = useState({
    pageNumber: 1,
    pageSize: 20,
    totalItems: 0,
    orderByAsc: true,
    sortBy: '',
    SearchText: '',
  })

  const handleTabChange = (event: React.SyntheticEvent, newValue: number) => {
    setValue(newValue)
  }
  const {
    isEditable,
    setEditable,
  } = useEditable()

  const {
    values,
    setValues,
    errors,
    handleChange,
    handleOnChange,
    setErrors,
    handleFormSubmit,
  } = useForm(validationSchemaUserAccount)

  const [updateUserAccountById, {
    data: updatedCountryByIdResponse,
    error: updatedCountryByIdError,
    isLoading: updatedCountryByIdLoading,
    isSuccess: updatedCountryByIdSuccess,
    isError: updatedCountryByIdIsError,
  }] = useLazyGetPensionFundSchemeByIdQuery()

  useEffect(() => {
    if (id) {
      updateUserAccountById(id)
      setEditable(viewUrl)
      // getUserAdminEntityById(id)
    }
  }, [])

  useEffect(() => {
    if (id) {
      setValues(updatedCountryByIdResponse?.data)
    } else {
      setValues(location.state ? location.state : {})
      // setEditable(false)
    }
  }, [updatedCountryByIdResponse?.data])

  const onScreenClose:any = (item:any) => {
    setEditable(item)
    setValues({})
  }
  const handleEditClick = (data: any) => {
    navigate(
      setRouteValues(`${routes.editPensionFundScheme}`, {
        id: data.id,
        view: true,
      }),
    )
  }
  return (
    <>
      <Box sx={{
        display: 'flex', justifyContent: 'space-between', flexDirection: 'row',
      }}
      >
        <Box sx={{
          display: 'flex', justifyContent: 'flex-start', alignItems: 'center', gap: '25px',
        }}
        >
          <Box
            component="div"
            onClick={() => navigate(-1)}
          >
            <LeftBack />
          </Box>
          <OPRLabel variant="h2">
            {` ${updatedCountryByIdResponse?.data?.pensionFundSchemeCode || ''}`}
          </OPRLabel>
        </Box>
        <Box sx={{
          display: 'flex', justifyContent: 'flex-start', height: 'fit-content',
        }}
        >
          {/* <OPRButton
            color="primary"
            handleClick={handleEditClick}
            style={{ borderRadius: '110px' }}
            variant="outlined"
          >
            Edit pension fund scheme
          </OPRButton> */}
        </Box>
      </Box>
      <Box sx={{ width: '100%' }}>
        <Box sx={{ borderBottom: 1, borderColor: 'divider' }}>
          <StyledTabs aria-label="basic tabs example" value={value} onChange={handleTabChange}>
            <StyledTab label={t('pensionfund_scheme_step_information')} {...a11yProps(0)} />
            <StyledTab label={t('pensionfund_scheme_step_calculation')} {...a11yProps(1)} />
            <StyledTab label={t('pensionfund_scheme_step_settings')} {...a11yProps(2)} />
            <StyledTab label={t('pension_scheme_items')} {...a11yProps(3)} />
          </StyledTabs>
        </Box>
        <CustomTabPanel index={0} value={value}>
          <PensionFundSchemeInformation
            isEditable
            errors={errors}
            handleChange={handleChange}
            handleOnChange={handleOnChange}
            values={values}
          />
        </CustomTabPanel>
        <CustomTabPanel index={1} value={value}>
          <PensionFundSchemeCalculation
            isEditable
            errors={errors}
            handleChange={handleChange}
            handleOnChange={handleOnChange}
            values={values}
          />
        </CustomTabPanel>
        <CustomTabPanel index={2} value={value}>
          <PensionFundSchemeSettings
            isEditable
            errors={errors}
            handleChange={handleChange}
            handleOnChange={handleOnChange}
            values={values}
          />
        </CustomTabPanel>
        <CustomTabPanel index={3} value={value}>
          <Box sx={{ display: 'flex', padding: 0 }}>
            <OPRInnerListLayout
              columns={entitypensionFundSchemeItemsColumn()}
              dataList={JSON.parse(JSON.stringify(updatedCountryByIdResponse?.data?.pensionFundSchemeItems || []))}
              filterData={filterData}
              isHeader={false}
              //   title={t('Entities')}
              // rowClickHandler={handleView}
              rowNumber={0}
            />
          </Box>
        </CustomTabPanel>
      </Box>
    </>
  )
}
