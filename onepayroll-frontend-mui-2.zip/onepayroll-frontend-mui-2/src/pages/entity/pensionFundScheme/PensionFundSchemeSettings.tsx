import { Box, Grid } from '@mui/material'
import OPRLabel from 'components/atoms/label/OPRLabel'
import OPRInputControl from 'components/molecules/OPRInputControl'
import OPRResponsiveGrid from 'components/molecules/OPRResponsiveGrid'
import OPRSelectorControl from 'components/molecules/OPRSelectorControl/OPRSelectorControl'
import OPRTextArea from 'components/molecules/OPRTextArea/OPRTextArea'
import { t } from 'i18next'

export function PensionFundSchemeSettings({
  errors, isEditable, values, handleChange, handleOnChange,
}:any) {
  return (
    <Box>
      <OPRLabel sx={{ marginTop: '20px' }} variant="body2">
        {`  ${t('All fields are mandatory except those marked optional')}`}
      </OPRLabel>
      <OPRResponsiveGrid>
        <div style={{ display: 'block', width: '100%', margin: '30px 18px 0' }}>
          <OPRLabel variant="h2">{t('remittance_settings')}</OPRLabel>
        </div>
        <Grid item md={2} sm={1} xs={1}>
          <OPRInputControl
            error={t(errors?.showRelevantIncomeAmount)}
            isEditable={isEditable}
            label="showRelevant_IncomeAmount"
            name="showRelevantIncomeAmount"
            optionalText="optional"
            value={values?.showRelevantIncomeAmount}
            onChange={handleChange}
          />
        </Grid>
        <Grid item md={4} sm={6} xs={12}>
          <OPRTextArea
            error={t(errors?.remittanceStatementRemarks)}
            isEditable={isEditable}
            label="remittanceStatement_Remarks"
            name="remittanceStatementRemarks"
            optionalText="Optional"
            value={values?.remittanceStatementRemarks}
            onChange={handleChange}
          />
        </Grid>
        <div style={{ display: 'block', width: '100%', margin: '30px 20px 20px' }}>
          <OPRLabel variant="h2">Payroll slip settings</OPRLabel>
        </div>
        <Grid item md={2} sm={1} xs={1}>
          <OPRInputControl
            error={t(errors?.descriptionInPensionFundSection)}
            isEditable={isEditable}
            label="descriptionInPension_FundSection"
            name="descriptionInPensionFundSection"
            value={values?.descriptionInPensionFundSection}
            onChange={handleChange}
          />
        </Grid>
        <Grid item md={2} sm={1} xs={1}>
          <OPRSelectorControl
            error={errors?.showContributionInPensionFundSection}
            isEditable={isEditable}
            keyName="showContributionInPensionFundSection"
            label={t('showContributionIn_PensionFundSection')}
            multiple={false}
            name="showContributionInPensionFundSection"
            options={[{ showContributionInPensionFundSection: 'Yes', values: 'Yes' }, { showContributionInPensionFundSection: 'No', values: 'No' }]}
            placeholder="Select an option"
            value={[{ showContributionInPensionFundSection: 'Yes', values: 'Yes' }, { showContributionInPensionFundSection: 'No', values: 'No' }]?.find((o:any) => o?.values === values?.showContributionInPensionFundSection) || {}}
            valueKey="showContributionInPensionFundSection"
            onChange={(text:any) => {
              handleOnChange('showContributionInPensionFundSection', text?.values)
            }}
          />
        </Grid>
        <Grid item md={2} sm={1} xs={1}>
          <OPRSelectorControl
            error={errors?.showRelevantIncomeInPensionFundSection}
            isEditable={isEditable}
            keyName="showRelevantIncomeInPensionFundSection"
            label={t('showRelevantIncomeIn_PensionFundSection')}
            multiple={false}
            name="showRelevantIncomeInPensionFundSection"
            options={[{ showRelevantIncomeInPensionFundSection: 'Yes', values: 'Yes' }, { showRelevantIncomeInPensionFundSection: 'No', values: 'No' }]}
            placeholder="Select an option"
            value={[{ showRelevantIncomeInPensionFundSection: 'Yes', values: 'Yes' }, { showRelevantIncomeInPensionFundSection: 'No', values: 'No' }]?.find((o:any) => o?.values === values?.showRelevantIncomeInPensionFundSection) || {}}
            valueKey="showRelevantIncomeInPensionFundSection"
            onChange={(text:any) => {
              handleOnChange('showRelevantIncomeInPensionFundSection', text?.values)
            }}
          />
        </Grid>
      </OPRResponsiveGrid>
    </Box>
  )
}
