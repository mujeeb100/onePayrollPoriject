import { Box, Grid } from '@mui/material'
import { useGetAllPensionFundSchemeRuleQuery } from 'api/entityServices'
import { useGetAllPayItemMasterQuery } from 'api/payRollServices'
import OPRLabel from 'components/atoms/label/OPRLabel'
import OPRInputControl from 'components/molecules/OPRInputControl'
import OPRResponsiveGrid from 'components/molecules/OPRResponsiveGrid'
import OPRSelectorControl from 'components/molecules/OPRSelectorControl/OPRSelectorControl'
import { t } from 'i18next'
import { generateFilterUrl } from 'utils'

export function PensionFundSchemeCalculation({
  errors, isEditable, values, handleChange, handleOnChange,
}:any) {
  const {
    data: pensionfundschemeruleData,
  } = useGetAllPensionFundSchemeRuleQuery(generateFilterUrl({ pageSize: 250 }))

  const {
    data: payitemmasterData,
  } = useGetAllPayItemMasterQuery(generateFilterUrl({ pageSize: 250 }))

  // Utility function to remove duplicates
  const removeDuplicates = (arr: any[], key: string) => arr.reduce((acc, current) => {
    const x = acc.find((item:any) => item[key] === current[key])
    if (!x) {
      return acc.concat([current])
    }
    return acc
  }, [])

  // Filter out duplicates based on 'pensionFundSchemeRuleType'
  const uniquePensionFundSchemeRules = removeDuplicates(pensionfundschemeruleData?.records || [], 'pensionFundSchemeRuleType')

  // Sort the unique records alphabetically by 'pensionFundSchemeRuleType'
  const sortedPensionFundSchemeRules = uniquePensionFundSchemeRules.sort((a: any, b: any) => a.pensionFundSchemeRuleType.localeCompare(b.pensionFundSchemeRuleType))

  // Find the current value to display in the dropdown
  const currentValue = sortedPensionFundSchemeRules.find((o: any) => o?.pensionFundSchemeRuleType === values?.schemeRuleType) || {}

  return (
    <Box>
      <OPRLabel sx={{ marginTop: '20px' }} variant="body2">
        {`  ${t('All fields are mandatory except those marked optional')}`}
      </OPRLabel>
      <OPRResponsiveGrid>
        <div style={{ display: 'block', width: '100%', margin: '30px 18px 0' }}>
          <OPRLabel variant="h2">{t('calc_setting')}</OPRLabel>
        </div>
        <Grid item md={2} sm={1} xs={1}>
          <OPRSelectorControl
            error={errors?.schemeRuleType}
            isEditable={isEditable}
            keyName="pensionFundSchemeRuleType"
            label="schemeRule_Type"
            multiple={false}
            name="schemeRuleType"
            options={sortedPensionFundSchemeRules}
            placeholder="Select an option"
            value={currentValue}
            valueKey="pensionFundSchemeRuleType"
            onChange={(text: any) => {
              handleOnChange('schemeRuleType', text?.pensionFundSchemeRuleType)
            }}
          />
        </Grid>
        <Grid item md={2} sm={1} xs={1}>
          <OPRSelectorControl
            error={errors?.roundingType}
            isEditable={isEditable}
            keyName="roundingType"
            label="rounding_Type"
            multiple={false}
            name="roundingType"
            options={[{ roundingType: 'Round to Nearest', values: 'Round to Nearest' }, { roundingType: 'Round Up', values: 'Round Up' }, { roundingType: 'Round Down', values: 'Round Down' }]}
            placeholder="Select an option"
            value={[{ roundingType: 'Round to Nearest', values: 'Round to Nearest' }, { roundingType: 'Round Up', values: 'Round Up' }, { roundingType: 'Round Down', values: 'Round Down' }]?.find((o:any) => o?.values === values?.roundingType) || {}}
            valueKey="roundingType"
            onChange={(text:any) => {
              handleOnChange('roundingType', text?.values)
            }}
          />
        </Grid>
        <Grid item md={2} sm={1} xs={1}>
          <OPRInputControl
            error={t(errors?.decimalPoint)}
            isEditable={isEditable}
            label="decimal_Point"
            name="decimalPoint"
            value={values?.decimalPoint}
            onChange={handleChange}
          />
        </Grid>
        {/* validation nahi hai */}
        {values?.schemeType !== 'MC' && (
          <Grid item md={2} sm={1} xs={1}>
            <OPRSelectorControl
              error={errors?.annualCapStartMonthOption}
              isEditable={isEditable}
              keyName="annualCapStartMonthOption"
              label={t('annualCapStart_MonthOption')}
              multiple={false}
              name="annualCapStartMonthOption"
              optionalText="optional"
              options={
                [{ annualCapStartMonthOption: 'January', values: 'January' },
                  { annualCapStartMonthOption: 'February', values: 'February' },
                  { annualCapStartMonthOption: 'March', values: 'March' },
                  { annualCapStartMonthOption: 'April', values: 'April' },
                  { annualCapStartMonthOption: 'May', values: 'May' },
                  { annualCapStartMonthOption: 'June', values: 'June' },
                  { annualCapStartMonthOption: 'July', values: 'July' },
                  { annualCapStartMonthOption: 'August', values: 'August' },
                  { annualCapStartMonthOption: 'September', values: 'September' },
                  { annualCapStartMonthOption: 'October', values: 'October' },
                  { annualCapStartMonthOption: 'November', values: 'November' },
                  { annualCapStartMonthOption: 'December', values: 'December' },
                ]
              }
              placeholder="Select an option"
              value={[{ annualCapStartMonthOption: 'January', values: 'January' },
                { annualCapStartMonthOption: 'February', values: 'February' },
                { annualCapStartMonthOption: 'March', values: 'March' },
                { annualCapStartMonthOption: 'April', values: 'April' },
                { annualCapStartMonthOption: 'May', values: 'May' },
                { annualCapStartMonthOption: 'June', values: 'June' },
                { annualCapStartMonthOption: 'July', values: 'July' },
                { annualCapStartMonthOption: 'August', values: 'August' },
                { annualCapStartMonthOption: 'September', values: 'September' },
                { annualCapStartMonthOption: 'October', values: 'October' },
                { annualCapStartMonthOption: 'November', values: 'November' },
                { annualCapStartMonthOption: 'December', values: 'December' },
              ].find((o:any) => o?.values === values?.annualCapStartMonthOption) || {}}
              valueKey="annualCapStartMonthOption"
              onChange={(text:any) => {
                handleOnChange('annualCapStartMonthOption', text?.values)
              }}
            />
          </Grid>
        )}
        <Grid item md={2} sm={1} xs={1}>
          <OPRSelectorControl
            error={errors?.schemeJoinDateOption}
            isEditable={isEditable}
            keyName="schemeJoinDateOption"
            label={t('schemeJoin_DateOption')}
            multiple={false}
            name="schemeJoinDateOption"
            options={[{ schemeJoinDateOption: 'Commencement Date', values: 'Commencement Date' }, { schemeJoinDateOption: 'DATE JOIN', values: 'DATE_JOIN' }]}
            placeholder="Select an option"
            value={[{ schemeJoinDateOption: 'Commencement Date', values: 'Commencement Date' }, { schemeJoinDateOption: 'DATE JOIN', values: 'DATE_JOIN' }]?.find((o:any) => o?.values === values?.schemeJoinDateOption) || {}}
            valueKey="schemeJoinDateOption"
            onChange={(text:any) => {
              handleOnChange('schemeJoinDateOption', text?.values)
            }}
          />
        </Grid>
        <div style={{ display: 'block', width: '100%', margin: '30px 20px 20px' }}>
          <OPRLabel variant="h2">{t('emp_calculation')}</OPRLabel>
        </div>
        <Grid item md={2} sm={1} xs={1}>
          <OPRSelectorControl
            error={errors?.employeeContributionPayItemCode}
            isEditable={isEditable}
            keyName="payItemCode"
            label={t('employeeContribution_PayItemCode')}
            multiple={false}
            name="employeeContributionPayItemCode"
            options={payitemmasterData?.records || []}
            placeholder="Select an option"
            value={(payitemmasterData?.records || [])?.find((o:any) => o?.payItemCode === values?.employeeContributionPayItemCode) || {}}
            valueKey="payItemCode"
            onChange={(text:any) => {
              handleOnChange('employeeContributionPayItemCode', text?.payItemCode)
            }}
          />
        </Grid>
        <Grid item md={2} sm={1} xs={1}>
          <OPRSelectorControl
            error={errors?.employeeAccrualContributionPayItemCode}
            isEditable={isEditable}
            keyName="payItemCode"
            label={t('employeeAccrualContribution_PayItemCode')}
            multiple={false}
            name="employeeAccrualContributionPayItemCode"
            optionalText="optional"
            options={payitemmasterData?.records || []}
            placeholder="Select an option"
            value={(payitemmasterData?.records || [])?.find((o:any) => o?.payItemCode === values?.employeeAccrualContributionPayItemCode) || {}}
            valueKey="payItemCode"
            onChange={(text:any) => {
              handleOnChange('employeeAccrualContributionPayItemCode', text?.payItemCode)
            }}
          />
        </Grid>
        <Grid item md={2} sm={1} xs={1}>
          <OPRSelectorControl
            error={errors?.employeeCalculationStartDateOption}
            isEditable={isEditable}
            keyName="employeeCalculationStartDateOption"
            label={t('employeeCalculation_StartDateOption')}
            multiple={false}
            name="employeeCalculationStartDateOption"
            options={[{ employeeCalculationStartDateOption: 'Exact Day', values: 'Exact Day' }, { employeeCalculationStartDateOption: 'Next Month', values: 'Next Month' }]}
            placeholder="Select an option"
            value={[{ employeeCalculationStartDateOption: 'Exact Day', values: 'Exact Day' }, { employeeCalculationStartDateOption: 'Next Month', values: 'Next Month' }]?.find((o:any) => o?.values === values?.employeeCalculationStartDateOption) || {}}
            valueKey="employeeCalculationStartDateOption"
            onChange={(text:any) => {
              handleOnChange('employeeCalculationStartDateOption', text?.values)
            }}
          />
        </Grid>
        <Grid item md={2} sm={1} xs={1}>
          <OPRInputControl
            error={t(errors?.employeeCalculationStartDateDays)}
            isEditable={isEditable}
            label="employeeCalculation_StartDateDays"
            name="employeeCalculationStartDateDays"
            value={values?.employeeCalculationStartDateDays}
            onChange={handleChange}
          />
        </Grid>
        <Grid item md={2} sm={1} xs={1}>
          <OPRInputControl
            error={t(errors?.employeeContributionStartDateDays)}
            isEditable={isEditable}
            label="employeeContribution_StartDateDays"
            name="employeeContributionStartDateDays"
            value={values?.employeeContributionStartDateDays}
            onChange={handleChange}
          />
        </Grid>
        <Grid item md={2} sm={1} xs={1}>
          <OPRSelectorControl
            error={errors?.deductMPFMCForEmployeeContribution}
            isEditable={isEditable}
            keyName="deductMPFMCForEmployeeContribution"
            label={t('deductMPFMCFor_EmployeeContribution')}
            multiple={false}
            name="deductMPFMCForEmployeeContribution"
            options={[{ deductMPFMCForEmployeeContribution: 'Yes', values: 'Yes' }, { deductMPFMCForEmployeeContribution: 'No', values: 'No' }]}
            placeholder="Select an option"
            value={[{ deductMPFMCForEmployeeContribution: 'Yes', values: 'Yes' }, { deductMPFMCForEmployeeContribution: 'No', values: 'No' }]?.find((o:any) => o?.values === values?.deductMPFMCForEmployeeContribution) || {}}
            valueKey="deductMPFMCForEmployeeContribution"
            onChange={(text:any) => {
              handleOnChange('deductMPFMCForEmployeeContribution', text?.values)
            }}
          />
        </Grid>
        <div style={{ display: 'block', width: '100%', margin: '30px 20px 20px' }}>
          <OPRLabel variant="h2">{t('emplr_calc')}</OPRLabel>
        </div>
        <Grid item md={2} sm={1} xs={1}>
          <OPRSelectorControl
            error={errors?.employerContributionPayItemCode}
            isEditable={isEditable}
            keyName="payItemCode"
            label={t('employerContribution_PayItemCode')}
            multiple={false}
            name="employerContributionPayItemCode"
            options={payitemmasterData?.records || []}
            placeholder="Select an option"
            value={(payitemmasterData?.records || [])?.find((o:any) => o?.payItemCode === values?.employerContributionPayItemCode) || {}}
            valueKey="payItemCode"
            onChange={(text:any) => {
              handleOnChange('employerContributionPayItemCode', text?.payItemCode)
            }}
          />
        </Grid>
        <Grid item md={2} sm={1} xs={1}>
          <OPRSelectorControl
            error={errors?.employerAccrualContributionPayItemCode}
            isEditable={isEditable}
            keyName="payItemCode"
            label={t('employerAccrualContribution_PayItemCode')}
            multiple={false}
            name="employerAccrualContributionPayItemCode"
            optionalText="optional"
            options={payitemmasterData?.records || []}
            placeholder="Select an option"
            value={(payitemmasterData?.records || [])?.find((o:any) => o?.payItemCode === values?.employerAccrualContributionPayItemCode) || {}}
            valueKey="payItemCode"
            onChange={(text:any) => {
              handleOnChange('employerAccrualContributionPayItemCode', text?.payItemCode)
            }}
          />
        </Grid>
        <Grid item md={2} sm={1} xs={1}>
          <OPRSelectorControl
            error={errors?.employerCalculationStartDateOption}
            isEditable={isEditable}
            keyName="employerCalculationStartDateOption"
            label={t('employerCalculation_StartDateOption')}
            multiple={false}
            name="employerCalculationStartDateOption"
            options={[{ employerCalculationStartDateOption: 'Exact Day', values: 'Exact Day' }, { employerCalculationStartDateOption: 'Next Month', values: 'Next Month' }]}
            placeholder="Select an option"
            value={[{ employerCalculationStartDateOption: 'Exact Day', values: 'Exact Day' }, { employerCalculationStartDateOption: 'Next Month', values: 'Next Month' }]?.find((o:any) => o?.values === values?.employerCalculationStartDateOption) || {}}
            valueKey="employerCalculationStartDateOption"
            onChange={(text:any) => {
              handleOnChange('employerCalculationStartDateOption', text?.values)
            }}
          />
        </Grid>
        <Grid item md={2} sm={1} xs={1}>
          <OPRInputControl
            error={t(errors?.employerCalculationStartDateDays)}
            isEditable={isEditable}
            label="employerCalculation_StartDateDays"
            name="employerCalculationStartDateDays"
            value={values?.employerCalculationStartDateDays}
            onChange={handleChange}
          />
        </Grid>
        <Grid item md={2} sm={1} xs={1}>
          <OPRInputControl
            error={t(errors?.employerContributionStartDateDays)}
            isEditable={isEditable}
            label="employerContribution_StartDateDays"
            name="employerContributionStartDateDays"
            value={values?.employerContributionStartDateDays}
            onChange={handleChange}
          />
        </Grid>
        <Grid item md={2} sm={1} xs={1}>
          <OPRSelectorControl
            error={errors?.deductMPFMCForEmployerContribution}
            isEditable={isEditable}
            keyName="deductMPFMCForEmployerContribution"
            label={t('deductMPFMCFor_EmployerContribution')}
            multiple={false}
            name="deductMPFMCForEmployerContribution"
            options={[{ deductMPFMCForEmployerContribution: 'Yes', values: 'Yes' }, { deductMPFMCForEmployerContribution: 'No', values: 'No' }]}
            placeholder="Select an option"
            value={[{ deductMPFMCForEmployerContribution: 'Yes', values: 'Yes' }, { deductMPFMCForEmployerContribution: 'No', values: 'No' }]?.find((o:any) => o?.values === values?.deductMPFMCForEmployerContribution) || {}}
            valueKey="deductMPFMCForEmployerContribution"
            onChange={(text:any) => {
              handleOnChange('deductMPFMCForEmployerContribution', text?.values)
            }}
          />
        </Grid>
        <Grid item md={2} sm={1} xs={1}>
          <OPRSelectorControl
            error={errors?.addContributionPeriodToPaymentDescription}
            isEditable={isEditable}
            keyName="addContributionPeriodToPaymentDescription"
            label={t('addContributionPeriod_ToPaymentDescription')}
            multiple={false}
            name="addContributionPeriodToPaymentDescription"
            options={[{ addContributionPeriodToPaymentDescription: 'Yes', values: 'Yes' }, { addContributionPeriodToPaymentDescription: 'No', values: 'No' }]}
            placeholder="Select an option"
            value={[{ addContributionPeriodToPaymentDescription: 'Yes', values: 'Yes' }, { addContributionPeriodToPaymentDescription: 'No', values: 'No' }]?.find((o:any) => o?.values === values?.addContributionPeriodToPaymentDescription) || {}}
            valueKey="addContributionPeriodToPaymentDescription"
            onChange={(text:any) => {
              handleOnChange('addContributionPeriodToPaymentDescription', text?.values)
            }}
          />
        </Grid>
      </OPRResponsiveGrid>
    </Box>
  )
}
