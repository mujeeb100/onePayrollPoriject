import { Box, Grid } from '@mui/material'
import { useGetAllServiceProviderQuery } from 'api/entityServices'
import { useGetAllCurrencyQuery, useGetAllProviderTypeSingleQuery } from 'api/globalServices'
import OPRLabel from 'components/atoms/label/OPRLabel'
import OPRDatePickerControl from 'components/molecules/OPRDatePickerControl/OPRDatePickerControl'
import OPRInputControl from 'components/molecules/OPRInputControl'
import OPRResponsiveGrid from 'components/molecules/OPRResponsiveGrid'
import OPRSelectorControl from 'components/molecules/OPRSelectorControl/OPRSelectorControl'
import OPRTextArea from 'components/molecules/OPRTextArea/OPRTextArea'
import { t } from 'i18next'
import { useEffect, useState } from 'react'
import { useLocation } from 'react-router-dom'
import { routes } from 'routes/routes'
import { generateFilterUrl, getParamsValue } from 'utils'

export function PensionFundSchemeInformation({
  errors, isEditable, values, handleChange, handleOnChange,
}:any) {
  const [filterData, setFilterData]:any = useState({
    ProviderCode: '',
  })
  const location: any = useLocation()
  const { id, viewUrl } = getParamsValue(location, routes.createPensionFundScheme)

  const [selectedProvider, setSelectedProvider]:any = useState(null)
  const [apiSuccess, setApiSuccess] = useState(false) // To track API call success

  // get all serviceprovider API
  const {
    data: serviceProviderData,
  } = useGetAllServiceProviderQuery(generateFilterUrl({ pageSize: 250 }))

  // get single provider type for the  remitteance file formet
  const {
    data: allPostsProviderTypeSingle,
    isLoading: isLoadingAllPostsProviderTypeSingle,
    isSuccess: isProviderTypeSingleSuccess, // Track API call success
    isError: isErrorAllPosts,
    error: errorAllPosts,
    refetch: refetchAllPosts,
  } = useGetAllProviderTypeSingleQuery(generateFilterUrl(filterData))

  useEffect(() => {
    if (serviceProviderData?.records && serviceProviderData.records.length > 0) {
      const defaultProviderCode = (serviceProviderData?.records || []).find((o: any) => o.providerCode === selectedProvider)
      setFilterData({ ProviderCode: defaultProviderCode })
    }
  }, [serviceProviderData])

  useEffect(() => {
    if (isProviderTypeSingleSuccess) {
      if (allPostsProviderTypeSingle?.remittanceStatementFileFormat !== 'HSBC') {
        setApiSuccess(true)
      } else {
        setApiSuccess(false)
      }
    } else {
      setApiSuccess(false)
    }
  }, [isProviderTypeSingleSuccess, allPostsProviderTypeSingle])

  const handleServiceProviderChange = (text: any) => {
    const providerCode = text?.providerCode || ''
    setSelectedProvider(providerCode)
    handleOnChange('serviceProviderCode', providerCode)

    setFilterData({ ProviderCode: providerCode })
    refetchAllPosts()
  }

  // useEffect(() => {
  //   if (selectedProvider) {
  //     const provider = (serviceProviderData?.records || []).find((o: any) => o.providerCode === selectedProvider)
  //     if (provider && provider.remittanceStatementFileFormat === 'HSBC') {
  //       setFilterData({ ProviderCode: provider.providerCode })
  //     } else {
  //       setFilterData({ ProviderCode: '' })
  //     }
  //   }
  // }, [selectedProvider])

  const {
    data: allPostsHC,
  } = useGetAllCurrencyQuery(generateFilterUrl({ pageSize: 250 }))
  return (
    <Box>
      <OPRLabel sx={{ marginTop: '20px' }} variant="body2">
        {`  ${t('All fields are mandatory except those marked optional')}`}
      </OPRLabel>
      <OPRResponsiveGrid>
        <div style={{ display: 'block', width: '100%', margin: '30px 18px 0' }}>
          <OPRLabel variant="h2">{t('gen_info')}</OPRLabel>
        </div>
        <Grid item md={2} sm={1} xs={1}>
          <OPRInputControl
            disabled={!!id}
            error={t(errors?.pensionFundSchemeCode)}
            isEditable={isEditable}
            label="ent_pensionFundScheme_Code"
            name="pensionFundSchemeCode"
            value={values?.pensionFundSchemeCode}
            onChange={handleChange}
          />
        </Grid>
        <Grid item md={2} sm={1} xs={1}>
          <OPRInputControl
            error={t(errors?.schemeDescription)}
            isEditable={isEditable}
            label="ent_scheme_Description"
            name="schemeDescription"
            value={values?.schemeDescription}
            onChange={handleChange}
          />
        </Grid>
        <Grid item md={2} sm={1} xs={1}>
          <OPRSelectorControl
            error={errors?.serviceProviderCode}
            isEditable={isEditable}
            keyName="providerCode"
            label="serviceProvider_Code"
            multiple={false}
            name="serviceProviderCode"
            options={(serviceProviderData?.records || [])}
            placeholder="Select an option"
            value={(serviceProviderData?.records || []).find((o: any) => o.providerCode === values?.serviceProviderCode) || {}}
            valueKey="providerCode"
            onChange={handleServiceProviderChange}
          />
        </Grid>
        <Grid item md={2} sm={1} xs={1}>
          <OPRSelectorControl
            error={errors?.schemeType}
            isEditable={isEditable}
            keyName="schemeType"
            label="scheme_Type"
            multiple={false}
            name="schemeType"
            options={[{ schemeType: 'MC', values: 'MC' }, { schemeType: 'VC', values: 'VC' }, { schemeType: 'ORSO', values: 'ORSO' }]}
            placeholder="Select an option"
            value={[{ schemeType: 'MC', values: 'MC' }, { schemeType: 'VC', values: 'VC' }, { schemeType: 'ORSO', values: 'ORSO' }]?.find((o:any) => o?.values === values?.schemeType) || {}}
            valueKey="schemeType"
            onChange={(text:any) => {
              handleOnChange('schemeType', text?.values)
            }}
          />
        </Grid>
        <Grid item md={2} sm={1} xs={1}>
          <OPRSelectorControl
            defaultValue={{ name: 'Active', values: true }}
            error={errors?.status}
            isEditable={isEditable}
            keyName="name"
            label={t('status')}
            multiple={false}
            name="status"
            options={[{ name: 'Active', values: 'Active' }, { name: 'Inactive', values: 'Inactive' }]}
            placeholder="Select an option"
            value={[{ name: 'Active', values: 'Active' }, { name: 'Inactive', values: 'Inactive' }]?.find((o:any) => o?.values === values?.status) || {}}
            valueKey="name"
            onChange={(text:any) => {
              handleOnChange('status', text?.values)
            }}
          />
        </Grid>
        <Grid item md={4} sm={6} xs={12}>
          <OPRTextArea
            error={t(errors?.remarks)}
            isEditable={isEditable}
            label="remarks"
            name="remarks"
            optionalText="optional"
            value={values?.remarks}
            onChange={handleChange}
          />
        </Grid>
        <div style={{ display: 'block', width: '100%', margin: '30px 20px 20px' }}>
          <OPRLabel variant="h2">{t('scheme_info')}</OPRLabel>
        </div>
        <Grid item md={2} sm={1} xs={1}>
          <OPRInputControl
            error={t(errors?.schemeFileNumber)}
            isEditable={isEditable}
            label="schemeFile_Number"
            name="schemeFileNumber"
            value={values?.schemeFileNumber}
            onChange={handleChange}
          />
        </Grid>
        <Grid item md={2} sm={1} xs={1}>
          <OPRInputControl
            error={t(errors?.subSchemeFileNumber)}
            isEditable={isEditable}
            label="subSchemeFile_Number"
            name="subSchemeFileNumber"
            optionalText="optional"
            value={values?.subSchemeFileNumber}
            onChange={handleChange}
          />
        </Grid>
        <Grid item md={2} sm={1} xs={1}>
          <OPRSelectorControl
            error={errors?.supplementaryScheme}
            isEditable={isEditable}
            keyName="supplementaryScheme"
            label={t('supplementary_Scheme')}
            multiple={false}
            name="supplementaryScheme"
            options={[{ supplementaryScheme: 'Yes', values: 'Yes' }, { supplementaryScheme: 'No', values: 'No' }]}
            placeholder="Select an option"
            value={[{ supplementaryScheme: 'Yes', values: 'Yes' }, { supplementaryScheme: 'No', values: 'No' }]?.find((o:any) => o?.values === values?.supplementaryScheme) || {}}
            valueKey="supplementaryScheme"
            onChange={(text:any) => {
              handleOnChange('supplementaryScheme', text?.values)
            }}
          />
        </Grid>
        <Grid item md={2} sm={1} xs={1}>
          <OPRSelectorControl
            error={errors?.schemeCurrency}
            isEditable={isEditable}
            keyName="currencyCode"
            label={t('scheme_Currency')}
            multiple={false}
            name="schemeCurrency"
            options={(allPostsHC?.records || [])}
            placeholder="Select an option"
            value={(allPostsHC?.records || [])?.find((o:any) => o?.currencyCode === values?.schemeCurrency) || {}}
            valueKey="currencyCode"
            onChange={(text:any) => {
              handleOnChange('schemeCurrency', text?.currencyCode)
            }}
          />
        </Grid>
        <Grid item md={2} sm={1} xs={1}>
          <OPRSelectorControl
            error={errors?.contributionCycle}
            isEditable={isEditable}
            keyName="contributionCycle"
            label={t('contribution_Cycle')}
            multiple={false}
            name="contributionCycle"
            options={[{ contributionCycle: 'Monthly', values: 'Monthly' }, { contributionCycle: 'Bi-Monthly', values: 'Bi-Monthly' }, { contributionCycle: 'Fortnightly', values: 'Fortnightly' }, { contributionCycle: 'Weekly', values: 'Weekly' }]}
            placeholder="Select an option"
            value={[{ contributionCycle: 'Monthly', values: 'Monthly' }, { contributionCycle: 'Bi-Monthly', values: 'Bi-Monthly' }, { contributionCycle: 'Fortnightly', values: 'Fortnightly' }, { contributionCycle: 'Weekly', values: 'Weekly' }]?.find((o:any) => o?.values === values?.contributionCycle) || {}}
            valueKey="contributionCycle"
            onChange={(text:any) => {
              handleOnChange('contributionCycle', text?.values)
            }}
          />
        </Grid>
        <Grid item md={2} sm={1} xs={1}>
          <OPRInputControl
            error={t(errors?.participationNumber)}
            isEditable={isEditable}
            label="participation_Number"
            name="participationNumber"
            optionalText="optional"
            value={values?.participationNumber}
            onChange={handleChange}
          />
        </Grid>
        <Grid item md={2} sm={1} xs={1}>
          <OPRInputControl
            error={t(errors?.memberClass)}
            isEditable={isEditable}
            label="member_Class"
            name="memberClass"
            optionalText="optional"
            value={values?.memberClass}
            onChange={handleChange}
          />
        </Grid>
        {(apiSuccess && filterData.ProviderCode && filterData.serviceProvider !== 'IRD') || (
          <>
            <Grid item md={2} sm={1} xs={1}>
              <OPRSelectorControl
                error={errors?.paymentMethod}
                isEditable={isEditable}
                keyName="paymentMethod"
                label={t('payment_Method')}
                multiple={false}
                name="paymentMethod"
                options={[
                  { paymentMethod: 'D - Direct debit to a nominated bank account', values: 'D' },
                  { paymentMethod: 'B - Direct credit to a HSBC nominated account', values: 'B' },
                  { paymentMethod: 'C - Cheque', values: 'C' },
                ]}
                placeholder="Select an option"
                value={([
                  { paymentMethod: 'D - Direct debit to a nominated bank account', values: 'D' },
                  { paymentMethod: 'B - Direct credit to a HSBC nominated account', values: 'B' },
                  { paymentMethod: 'C - Cheque', values: 'C' },
                ] || []).find((o: any) => o?.values === values?.paymentMethod) || {}}
                valueKey="paymentMethod"
                onChange={(text: any) => {
                  handleOnChange('paymentMethod', text?.values)
                }}
              />
            </Grid>
            <Grid item md={2} sm={1} xs={1}>
              <OPRInputControl
                error={t(errors?.payCentre)}
                isEditable={isEditable}
                label="pay_Centre"
                name="payCentre"
                value={values?.payCentre}
                onChange={handleChange}
              />
            </Grid>
            <Grid item md={2} sm={1} xs={1}>
              <OPRSelectorControl
                error={errors?.formNumber}
                isEditable={isEditable}
                keyName="formNumberName"
                label="form_number"
                multiple={false}
                name="formNumber"
                options={[
                  { formNumberName: 'INB1', formNumberValue: 'INB1' },
                  { formNumberName: 'INB2', formNumberValue: 'INB2' },
                  { formNumberName: 'HAB1', formNumberValue: 'HAB1' },
                  { formNumberName: 'HAB2', formNumberValue: 'HAB2' },
                  { formNumberName: 'INBA', formNumberValue: 'INBA' },
                  { formNumberName: 'HABA', formNumberValue: 'HABA' },
                  { formNumberName: 'INB7', formNumberValue: 'INB7' },
                ]}
                placeholder="Select an option"
                value={{
                  formNumberName: values?.formNumber,
                  formNumberValue: values?.formNumber,
                }}
                valueKey="formNumberValue"
                onChange={(text: any) => {
                  handleOnChange('formNumber', text?.formNumberValue)
                }}
              />
            </Grid>
          </>
        )}
        <div style={{ display: 'block', width: '100%', margin: '30px 20px 20px' }}>
          <OPRLabel variant="h2">{t('surcharge_info')}</OPRLabel>
        </div>
        <Grid item md={2} sm={1} xs={1}>
          <OPRInputControl
            error={t(errors?.surchargePercentage)}
            isEditable={isEditable}
            label="surcharge_Percentage"
            name="surchargePercentage"
            optionalText="optional"
            value={values?.surchargePercentage}
            onChange={handleChange}
          />
        </Grid>
        <Grid item md={2} sm={1} xs={1}>
          <OPRDatePickerControl
            error={errors?.surchargePayDate}
            isEditable={isEditable}
            label={t('surcharge_PayDate')}
            name="surchargePayDate"
            optionalText="optional"
            value={values?.surchargePayDate || null}
            onChange={(date) => {
              handleOnChange('surchargePayDate', date)
            }}
          />
        </Grid>
        <Grid item md={2} sm={1} xs={1}>
          <OPRInputControl
            error={t(errors?.employeeSurchargeAmount)}
            isEditable={isEditable}
            label="employeeSurcharge_Amount"
            name="employeeSurchargeAmount"
            optionalText="optional"
            value={values?.employeeSurchargeAmount}
            onChange={handleChange}
          />
        </Grid>
        <Grid item md={2} sm={1} xs={1}>
          <OPRInputControl
            error={t(errors?.employerSurchargeAmount)}
            isEditable={isEditable}
            label="employerSurcharge_Amount"
            name="employerSurchargeAmount"
            optionalText="optional"
            value={values?.employerSurchargeAmount}
            onChange={handleChange}
          />
        </Grid>
      </OPRResponsiveGrid>
    </Box>
  )
}
