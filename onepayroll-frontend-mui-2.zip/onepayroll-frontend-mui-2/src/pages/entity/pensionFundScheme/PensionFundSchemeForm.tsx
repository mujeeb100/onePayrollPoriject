import { Box } from '@mui/material'
import { useLazyGetPensionFundSchemeByIdQuery, usePensionFundSchemeCreateMutation, usePensionFundSchemeUpdateMutation } from 'api/entityServices'
import { CrossIcon, TickIcon } from 'assets/svg-images/SvgComponents'
import OPRStepper from 'components/atoms/stepper'
import { OPRConfirmationDialog, OPRConfirmationDialogProps } from 'components/molecules/OPRAlertControl/OPRConfirmationDialog'
import { OPRInnerFormLayout } from 'components/organism/OPRInnerFormLayout'
import { validationSchemaPensionfundscheme, validationSchemaPensionfundscheme1, validationSchemaPensionfundscheme2 } from 'constants/validate'
import { useEditable } from 'hooks/useEdit'
import useForm from 'hooks/useForm'
import { useEffect, useRef, useState } from 'react'
import { useTranslation } from 'react-i18next'
import { useLocation, useNavigate } from 'react-router-dom'
import { routes } from 'routes/routes'
import { getParamsValue } from 'utils'

import { Confirmation } from './Confirmation'
import { PensionFundSchemeCalculation } from './PensionFundCalculation'
import { PensionFundSchemeInformation } from './PensionFundInfo'
import { PensionFundSchemeSettings } from './PensionFundSchemeSettings'

const getValidationSchema = (activeState:any, isServiceProviderSuccess:any) => {
  switch (activeState) {
    case 0:
      return validationSchemaPensionfundscheme(isServiceProviderSuccess)
    case 1:
      return validationSchemaPensionfundscheme1
    default:
      return validationSchemaPensionfundscheme2
  }
}
export default function PensionFundSchemeForm() {
  const myRef:any = useRef()
  const location: any = useLocation()
  // const { id, viewUrl } = getParamsValue(location, routes.createPensionFundScheme)
  const { id, viewUrl } = getParamsValue(location, routes.createPensionFundScheme)
  const [activeState, setActiveState] = useState(0)
  const { t } = useTranslation()
  const [isServiceProviderSuccess, setServiceProviderSuccess] = useState(false)
  const { isEditable, setEditable } = useEditable()
  const [validationSchema, setValidationSchema] = useState(
    getValidationSchema(activeState, isServiceProviderSuccess),
  )

  useEffect(() => {
    setValidationSchema(getValidationSchema(activeState, isServiceProviderSuccess))
  }, [activeState, isServiceProviderSuccess])

  const {
    values,
    setValues,
    errors,
    handleChange,
    setErrors,
    handleFormSubmit,
    handleOnChange,
  } = useForm(validationSchema)

  const [confirmDialog, setConfirmDialog] = useState<OPRConfirmationDialogProps>({
    open: false,
    buttonLayout: 'confirm',
    title: '',
    message: '',

  })

  const navigate = useNavigate()
  const [
    createPensionFundScheme,
    {
      data: createdPensionFundSchemeData,
      error: createdPensionFundSchemeError,
      isLoading: createdPensionFundSchemeLoading,
      isSuccess: createdPensionFundSchemeSuccess,
      isError: createdPensionFundSchemeIsError,
    },
  ] = usePensionFundSchemeCreateMutation()

  const [
    updatePensionFund,
    {
      data: updatedPensionFundDataResponse,
      error: updatedPensionFundError,
      isLoading: updatedPensionFundLoading,
      isSuccess: updatedPensionFundSuccess,
      isError: updatedPensionFundIsError,
    },
  ] = usePensionFundSchemeUpdateMutation()

  const [
    updatePensionFundById,
    {
      data: updatedPensionFundByIdResponse,
      error: updatedPensionFundByIdError,
      isLoading: updatedPensionFundByIdLoading,
      isSuccess: updatedPensionFundByIdSuccess,
      isError: updatedPensionFundByIdIsError,
    },
  ] = useLazyGetPensionFundSchemeByIdQuery()

  useEffect(() => {
    if (id) {
      updatePensionFundById(id)
      setEditable(viewUrl)
    }
  }, [])

  useEffect(() => {
    if (id) {
      setValues(updatedPensionFundByIdResponse?.data)
    } else {
      setValues(location.state ? location.state : {})
      // setEditable(viewUrl)
    }
  }, [updatedPensionFundByIdResponse?.data])

  const handleSubmit: any = async () => {
    if (!isEditable) {
      if (id === null) {
        await createPensionFundScheme({
          pensionFundSchemeCode: values?.pensionFundSchemeCode || '',
          schemeDescription: values?.schemeDescription || '',
          serviceProviderCode: values?.serviceProviderCode || '',
          schemeType: values?.schemeType || '',
          status: values?.status || '',
          remarks: values?.remarks || '',
          schemeFileNumber: values?.schemeFileNumber || '',
          subSchemeFileNumber: values?.subSchemeFileNumber || '',
          supplementaryScheme: values?.supplementaryScheme || '',
          schemeCurrency: values?.schemeCurrency || '',
          contributionCycle: values?.contributionCycle || '',
          participationNumber: values?.participationNumber || '',
          referenceNumber: values?.referenceNumber || '',
          memberClass: values?.memberClass || '',
          paymentMethod: values?.paymentMethod,
          payCentre: values?.payCentre || '',
          schemeRuleType: values?.schemeRuleType || '',
          roundingType: values?.roundingType || '',
          decimalPoint: Number(values?.decimalPoint) || 0,
          annualCapStartMonthOption: values?.annualCapStartMonthOption || '',
          schemeJoinDateOption: values?.schemeJoinDateOption || '',
          employeeContributionPayItemCode: values?.employeeContributionPayItemCode || '',
          employeeAccrualContributionPayItemCode: values?.employeeAccrualContributionPayItemCode || '',
          employeeCalculationStartDateOption: values?.employeeCalculationStartDateOption || '',
          employeeCalculationStartDateDays: Number(values?.employeeCalculationStartDateDays) || 0,
          employeeContributionStartDateDays: Number(values?.employeeContributionStartDateDays) || 0,
          deductMPFMCForEmployeeContribution: 'Yes',
          employerContributionPayItemCode: values?.employerContributionPayItemCode || '',
          employerAccrualContributionPayItemCode: values?.employerAccrualContributionPayItemCode || '',
          employerCalculationStartDateOption: values?.employerCalculationStartDateOption,
          employerCalculationStartDateDays: Number(values?.employerCalculationStartDateDays) || 0,
          employerContributionStartDateDays: Number(values?.employerContributionStartDateDays) || 0,
          deductMPFMCForEmployerContribution: values?.deductMPFMCForEmployerContribution || '',
          addContributionPeriodToPaymentDescription: values?.addContributionPeriodToPaymentDescription || '',
          showRelevantIncomeAmount: Number(values?.showRelevantIncomeAmount) || 0,
          remittanceStatementRemarks: values?.remittanceStatementRemarks || '',
          descriptionInPensionFundSection: values?.descriptionInPensionFundSection || '',
          showContributionInPensionFundSection: values?.showContributionInPensionFundSection || '',
          showRelevantIncomeInPensionFundSection: values?.showRelevantIncomeInPensionFundSection || '',
          surchargePercentage: Number(values?.surchargePercentage) || 0,
          surchargePayDate: values?.surchargePayDate || null,
          employeeSurchargeAmount: Number(values?.employeeSurchargeAmount) || 0,
          employerSurchargeAmount: Number(values?.employerSurchargeAmount) || 0,
          draft: false,
          FormNumber: values?.formNumber || 'ab',
        }, {
          // Add the isdraft query string parameter
          isdraft: 'false',
        })
      } else {
        await updatePensionFund({
          id: values.id,
          pensionFundSchemeCode: values?.pensionFundSchemeCode,
          schemeDescription: values?.schemeDescription,
          serviceProviderCode: values?.serviceProviderCode,
          schemeType: values?.schemeType,
          status: values?.status,
          remarks: values?.remarks,
          schemeFileNumber: values?.schemeFileNumber,
          subSchemeFileNumber: values?.subSchemeFileNumber,
          supplementaryScheme: values?.supplementaryScheme,
          schemeCurrency: values?.schemeCurrency,
          contributionCycle: values?.contributionCycle,
          participationNumber: values?.participationNumber,
          referenceNumber: values?.referenceNumber,
          memberClass: values?.memberClass,
          paymentMethod: values?.paymentMethod,
          payCentre: values?.payCentre,
          schemeRuleType: values?.schemeRuleType,
          roundingType: values?.roundingType,
          decimalPoint: Number(values?.decimalPoint) || 0,
          annualCapStartMonthOption: values?.annualCapStartMonthOption,
          schemeJoinDateOption: values?.schemeJoinDateOption,
          employeeContributionPayItemCode: values?.employeeContributionPayItemCode,
          employeeAccrualContributionPayItemCode: values?.employeeAccrualContributionPayItemCode,
          employeeCalculationStartDateOption: values?.employeeCalculationStartDateOption,
          employeeCalculationStartDateDays: Number(values?.employeeCalculationStartDateDays) || 0,
          employeeContributionStartDateDays: Number(values?.employeeContributionStartDateDays) || 0,
          deductMPFMCForEmployeeContribution: 'Yes',
          employerContributionPayItemCode: values?.employerContributionPayItemCode,
          employerAccrualContributionPayItemCode: values?.employerAccrualContributionPayItemCode,
          employerCalculationStartDateOption: values?.employerCalculationStartDateOption,
          employerCalculationStartDateDays: Number(values?.employerCalculationStartDateDays) || 0,
          employerContributionStartDateDays: Number(values?.employerContributionStartDateDays) || 0,
          deductMPFMCForEmployerContribution: values?.deductMPFMCForEmployerContribution || '',
          addContributionPeriodToPaymentDescription: values?.addContributionPeriodToPaymentDescription,
          showRelevantIncomeAmount: Number(values?.showRelevantIncomeAmount) || 0,
          remittanceStatementRemarks: values?.remittanceStatementRemarks,
          descriptionInPensionFundSection: values?.descriptionInPensionFundSection,
          showContributionInPensionFundSection: values?.showContributionInPensionFundSection,
          showRelevantIncomeInPensionFundSection: values?.showRelevantIncomeInPensionFundSection,
          surchargePercentage: Number(values?.surchargePercentage) || 0,
          surchargePayDate: values?.surchargePayDate || null,
          employeeSurchargeAmount: Number(values?.employeeSurchargeAmount) || 0,
          employerSurchargeAmount: Number(values?.employerSurchargeAmount) || 0,
          draft: false,
          FormNumber: values?.formNumber,
        })
      }
    } else {
      setEditable(true)
    }
  }
  useEffect(() => {
    if (id) {
    //   updatePensionFundSchemeById(id)
      setEditable(viewUrl)
      setValues({
        status: 'Active',
        supplementaryScheme: 'No',
        contributionCycle: 'Monthly',
        paymentMethod: 'D',
        decimalPoint: 2,
        schemeJoinDateOption: 'Commencement Date',
        deductMPFMCForEmployeeContribution: 'No',
        employerCalculationStartDateOption: 'Exact Day',
        deductMPFMCForEmployerContribution: 'No',
        addContributionPeriodToPaymentDescription: 'Yes',
        showContributionInPensionFundSection: 'Yes',
        showRelevantIncomeInPensionFundSection: 'Yes',
        roundingType: 'Round to Nearest',
        // employeeCalculationStartDateOption: values?.schemeType === 'MC' ? 'Next Month' : 'Exact Day',
        employerCalculationStartDateDays: 0,
        employerContributionStartDateDays: 0,
        // employeeCalculationStartDateDays: values?.schemeType === 'MC' ? 30 : 0,
        // employeeContributionStartDateDays: values?.schemeType === 'MC' ? 59 : 0,
      })
    }
  }, [])

  // useEffect(() => {
  //   if (values?.schemeType === 'MC') {
  //     setValues({ ...values, employeeCalculationStartDateOption: 'Next Month' })
  //   } else {
  //     setValues({ ...values, employeeCalculationStartDateOption: 'Exact Day' })
  //   }
  // }, [values?.schemeType])

  // useEffect(() => {
  //   setValues((prevValues:any) => ({
  //     ...prevValues,
  //     employeeCalculationStartDateOption: values?.schemeType === 'MC' ? 'Next Month' : 'Exact Day',
  //     employeeCalculationStartDateDays: values?.schemeType === 'MC' ? 30 : 0,
  //     employeeContributionStartDateDays: values?.schemeType === 'MC' ? 59 : 0,
  //     schemeRuleType: values?.schemeType === 'MC' ? 'MPF_VC' : '', // Add this line
  //     employerContributionStartDateDays: values?.schemeType === 'MC' ? 59 : 0,

  //   }))
  // }, [values?.schemeType])

  useEffect(() => {
    if (id === null) {
      setValues((prevValues:any) => ({
        ...prevValues,
        employeeCalculationStartDateOption: values?.schemeType === 'MC' ? 'Next Month' : 'Exact Day',
        employeeCalculationStartDateDays: values?.schemeType === 'MC' ? 30 : 0,
        employeeContributionStartDateDays: values?.schemeType === 'MC' ? 59 : 0,
        schemeRuleType: values?.schemeType === 'MC' ? 'MPF_VC' : '', // Add this line
        employerContributionStartDateDays: values?.schemeType === 'MC' ? 59 : 0,
      }))
    }
  }, [values?.schemeType])

  // useEffect(() => {
  //   if (createdPensionFundSchemeSuccess) {
  //     // Reset form values after successful add operation
  //     setValues({})
  //     setErrors({})
  //   }
  // }, [createdPensionFundSchemeSuccess])

  const createDialog: any = () => {
    setConfirmDialog({
      open: true,
      icon: <CrossIcon />,
      buttonLayout: 'try-again',
      error: (createdPensionFundSchemeError || updatedPensionFundError || updatedPensionFundByIdIsError),
      title: t('Failed to add pension fund scheme'),
      onClose: () => {
        setConfirmDialog({
          open: true,
          buttonLayout: 'confirm',
          infoMessage: t('Are you sure you want to quit without saving your changes? Any unsaved progress will be lost.'),
          title: t('Are you sure you want to quit'),
          onConfirm: () => {
            setConfirmDialog({ ...confirmDialog, open: false })
            navigate(`/${routes.pensionFundScheme}`)
          },
          onCancel: () => {
            setConfirmDialog({ ...confirmDialog, open: false })
            createDialog()
          },
        })
      },
      onTryAgain: () => {
        setConfirmDialog({ ...confirmDialog, open: false })
        handleSubmit()
      },
      onBack: () => {
        setConfirmDialog({ ...confirmDialog, open: false })
      },
    })
  }

  const handlePermissionSubmit: any = async () => {
    if (activeState === 1) {
      setActiveState(activeState + 1)
    } else {
      myRef.current.childMethod()
    }
    // myRef.current.childMethod()
  }

  useEffect(() => {
    const createdPensionFundSchemeSuccessStatus = createdPensionFundSchemeSuccess || false
    const updatedPensionFundSchemeSuccessStatus = updatedPensionFundSuccess || false
    if (createdPensionFundSchemeSuccessStatus || updatedPensionFundSchemeSuccessStatus) {
      if (activeState <= 1) {
        setActiveState(activeState + 1)
      }
    }
  }, [createdPensionFundSchemeSuccess, updatedPensionFundSuccess])

  useEffect(() => {
    if (createdPensionFundSchemeSuccess) {
      setConfirmDialog({
        open: true,
        icon: <TickIcon />,
        buttonLayout: 'add-another',
        title: t('New pension fund scheme added'),
        addAnotherButtonTitle: t('Add another pension fund scheme'),
        message: (
          <>
            <strong>{values?.schemeDescription}</strong>
            {' '}
            {t('has been added.')}
          </>
        ),
        onClose: () => {
          setConfirmDialog({ ...confirmDialog, open: false })
          navigate(`/${routes.pensionFundScheme}`)
        },
        onAddAnother: () => {
          setConfirmDialog({ ...confirmDialog, open: false })
          setEditable(false)
          setValues({
            status: 'Active',
            supplementaryScheme: 'No',
            contributionCycle: 'Monthly',
            paymentMethod: 'D',
            decimalPoint: 2,
            schemeJoinDateOption: 'Commencement Date',
            deductMPFMCForEmployeeContribution: 'No',
            employerCalculationStartDateOption: 'Exact Day',
            deductMPFMCForEmployerContribution: 'No',
            addContributionPeriodToPaymentDescription: 'Yes',
            showContributionInPensionFundSection: 'Yes',
            showRelevantIncomeInPensionFundSection: 'Yes',
            roundingType: 'Round to Nearest',
            employeeCalculationStartDateOption: values?.schemeType === 'MC' ? 'Next Month' : 'Exact Day',
            schemeRuleType: values?.schemeType === 'MC' ? 'MPF_VC' : '',
            employerCalculationStartDateDays: 0,
            employerContributionStartDateDays: 0,
            employeeCalculationStartDateDays: values?.schemeType === 'MC' ? 30 : 0,
            employeeContributionStartDateDays: values?.schemeType === 'MC' ? 59 : 0,
          })
          setActiveState(0)
          setErrors({})
          navigate(routes.createPensionFundScheme, { replace: true })
        },
      })
    }

    if (createdPensionFundSchemeIsError
      || updatedPensionFundIsError || createdPensionFundSchemeError || updatedPensionFundByIdIsError) {
    // error: createdPensionFundSchemeError || updatedPensionFundSchemeError
      createDialog()
    }
  }, [createdPensionFundSchemeData, createdPensionFundSchemeError, createdPensionFundSchemeLoading, createdPensionFundSchemeSuccess, updatedPensionFundSuccess])

  useEffect(() => {
    if (updatedPensionFundSuccess) {
      setConfirmDialog({
        ...confirmDialog,
        open: true,
        buttonLayout: 'close',
        title: t('pension fund scheme udpatd'),
        message: `${values?.schemeDescription} ${t('has been updated.')}`,
        onClose: () => {
          setConfirmDialog({ ...confirmDialog, open: false })
          navigate(`/${routes.pensionFundScheme}`)
        },
      })
    }
  }, [updatedPensionFundSuccess])
  return (
    <Box sx={{ display: 'flex' }}>
      <div
        style={{ display: 'flex', width: '100% ' }}
        // onSubmit={(e) => {
        //   activeState === 0 ? handleFormSubmit(e, handleSubmit) : handlePermissionSubmit()
        // }}
      >
        <OPRConfirmationDialog
          key="confirmation-dialog"
          titleSx={{
            '&::first-letter': {
              textTransform: 'capitalize',
            },
          }}
          {...confirmDialog}
        />
        <OPRInnerFormLayout
          isHandleContinueClick
          isStepper
          // customHeader={(
          //   <OPRLabel label="Add Pension Fund Scheme" variant="h2" />
          // )}
          error={createdPensionFundSchemeError || updatedPensionFundError || updatedPensionFundByIdIsError}
          handleBack={() => { setActiveState(activeState - 1) }}
          handleCancelClick={(e:any) => navigate(-1)}
          handleContinueClick={(e:any) => {
            if (activeState === 3) {
              handleSubmit()
            }

            if (activeState === 0) {
              handleFormSubmit(e, () => {
                window.scrollTo(0, 0)
                setActiveState(activeState + 1)
              })
            }

            if (activeState === 1) {
              handleFormSubmit(e, () => {
                window.scrollTo(0, 0)
                setActiveState(activeState + 1)
              })
            }

            if (activeState === 2) {
              handleFormSubmit(e, () => {
                window.scrollTo(0, 0)
                setActiveState(activeState + 1)
              })
            }
          }}
          handleEditable={setEditable}
          isBackButton={activeState > 0}
          isLoading={createdPensionFundSchemeLoading || updatedPensionFundLoading || updatedPensionFundByIdLoading}
          pageType="detailsPage"
          //   previousPageUrl={routes.pensionFundScheme}
          step={activeState}
          subtitle={
            isEditable
              ? 'Please check the user details below.'
              : 'All field to mandatory expect those mark optional'
          }
          title={t('add_pensionFundScheme')}
        >
          <Box>
            <OPRStepper
              activeStep={activeState}
              steps={[
                t('pensionfund_scheme_step_information'),
                t('pensionfund_scheme_step_calculation'),
                t('pensionfund_scheme_step_settings'),
                t('pensionfund_scheme_step_confirmation'),
              ]}
            />
            {activeState === 0 && (
              <PensionFundSchemeInformation
                errors={errors}
                handleChange={handleChange}
                handleOnChange={handleOnChange}
                isEditable={isEditable}
                values={values}
              />
            )}
            {activeState === 1 && (
              <PensionFundSchemeCalculation
                errors={errors}
                handleChange={handleChange}
                handleOnChange={handleOnChange}
                isEditable={isEditable}
                values={values}
              />
            )}
            {activeState === 2 && (
              <PensionFundSchemeSettings
                errors={errors}
                handleChange={handleChange}
                handleOnChange={handleOnChange}
                isEditable={isEditable}
                values={values}
              />
            )}
            {activeState === 3 && (
              <Confirmation
                errors={errors}
                handleChange={handleChange}
                handleOnChange={handleOnChange}
                isEditable={isEditable}
                values={values}
              />
            )}
          </Box>
        </OPRInnerFormLayout>
      </div>
    </Box>
  )
}
