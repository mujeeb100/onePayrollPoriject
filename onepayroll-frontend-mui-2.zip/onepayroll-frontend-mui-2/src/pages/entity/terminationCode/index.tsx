import {
  Box,
} from '@mui/material'
import { useGetAllTerminationCodeQuery, useTerminationCodeDeleteMutation } from 'api/entityServices'
import { entityTerminationCodeColumn } from 'components/atoms/table/OPRTableConstant'
import { OPRInnerListLayout } from 'components/organism/OPRInnerLayoutList'
import apiEndPoint from 'constants/apiEndPoint'
import { terminationCodeColumnMappings } from 'constants/exportColumnMappings'
import { useTranslatedColumnsForPDF } from 'hooks/useTranslatedColumnsForPDF'
import { t } from 'i18next'
import React, { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { routes } from 'routes/routes'
import {
  generateFilterUrl, getAPIWithEntityUrl, getEnv, setRouteValues,
} from 'utils'

function TerminationCodeList() {
  const navigate: any = useNavigate()
  const [selelctedDelete, setSelelctedDelete]:any = useState({
    data: {},
    isDelete: false,
    name: '',
  })
  const [filterData, setFilterData]:any = useState({
    pageNumber: 1,
    pageSize: 20,
    totalItems: 0,
    orderByAsc: true,
    sortBy: '',
    SearchText: '',
  })
  const {
    data: allPosts,
    isLoading: isLoadingAllPosts,
    isSuccess: isSuccessAllPosts,
    isError: isErrorAllPosts,
    error: errorAllPosts,
    refetch: refetchAllPosts,
  } = useGetAllTerminationCodeQuery(generateFilterUrl(filterData))

  const [deleteTerminationCodeById,
    {
      data: deleteTerminationCodeResponse,
      error: deleteTerminationCodeError,
      isLoading: deleteTerminationCodeLoading,
      isSuccess: deleteTerminationCodeSuccess,
      isError: deleteTerminationCodeIsError,
    }] = useTerminationCodeDeleteMutation()
  const sorting = (
    event: React.MouseEvent<unknown>,
    property: keyof any,
  ) => {
    const isAsc = filterData.sortBy === property && filterData.orderByAsc === true
    setFilterData({ ...filterData, orderByAsc: !isAsc, sortBy: property })
  }

  useEffect(() => {
    setFilterData({ ...filterData, totalItems: allPosts?.totalItems ? allPosts?.totalItems : 0 })
  }, [allPosts?.pageNumber, filterData.sortBy, filterData.orderByAsc, allPosts?.totalItems])

  const onSearch = (e: any, data: any) => {
    setFilterData({ ...filterData, ...data })
  }
  const handlePagination = (pageNumber: number, pageSize: number) => {
    setFilterData({ ...filterData, pageNumber })
  }

  const viewAcoount = (data: any, type:string) => {
    if (type === 'Edit Termination Code') {
      navigate(
        setRouteValues(`${routes.editTerminationCode}`, {
          id: data.id,
        }),
      )
    } else if (type === 'Delete Termination Code') {
      // deleteTerminationCodeById(`Id=${data.id}`)
      setSelelctedDelete({ data, isDelete: true, name: data.terminationReason })
    } else {
      navigate(
        setRouteValues(`${routes.viewTerminationCode}`, {
          id: data.id,
        }),
      )
    }
  }

  const handleView = (data: any) => {
    navigate(
      setRouteValues(`${routes.viewTerminationCode}`, {
        id: data.id,
        view: true,
      }),
    )
  }
  // handle deleteTerminationCode
  const handleDelete = (data:any) => {
    deleteTerminationCodeById(`Id=${data.id}`)
  }
  return (
    <Box sx={{ display: 'flex' }}>
      <OPRInnerListLayout
        isExport
        Search={decodeURIComponent(filterData.SearchText)}
        addHandleClick={() => navigate(routes.createTerminationCode)}
        columns={entityTerminationCodeColumn(viewAcoount)}
        dataList={JSON.parse(JSON.stringify(allPosts?.records || []))}
        deleteCallBack={handleDelete}
        error={errorAllPosts || deleteTerminationCodeError}
        exportProps={{
          data: allPosts?.records,
          fileName: 'Termination Code',
          columns: useTranslatedColumnsForPDF(terminationCodeColumnMappings),
          pdf: {
            orientation: 'portrait',
          },
          allRecords: {
            baseURL: getEnv('REACT_APP_UP_BASE_URL', null),
            endpoint: getAPIWithEntityUrl(apiEndPoint.terminationCodeList),
            filterData,
          },
        }}
        filterData={filterData}
        handlePagination={handlePagination}
        handleSearch={onSearch}
        isError={isErrorAllPosts || deleteTerminationCodeIsError}
        loading={isLoadingAllPosts || deleteTerminationCodeLoading}
        rowClickHandler={handleView}
        rowNumber={0}
        selelctedUser={selelctedDelete}
        setSelelctedUser={setSelelctedDelete}
        sortHandleClick={sorting}
        success={deleteTerminationCodeSuccess}
        title={t('entity_termination_code_name')}
      />
    </Box>
  )
}

export default TerminationCodeList
