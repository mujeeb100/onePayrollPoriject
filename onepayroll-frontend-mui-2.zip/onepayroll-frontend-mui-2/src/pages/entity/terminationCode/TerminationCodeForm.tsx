import { Box, Grid } from '@mui/material'
import {
  useLazyGetTerminationCodeByIdQuery,
  useTerminationCodeCreateMutation,
  useTerminationCodeUpdateMutation,
} from 'api/entityServices/index'
import OPRInputControl from 'components/molecules/OPRInputControl'
import OPRResponsiveGrid from 'components/molecules/OPRResponsiveGrid'
import OPRTextArea from 'components/molecules/OPRTextArea/OPRTextArea'
import OPRAlertControl from 'components/organism/OPRAlertControl'
import { OPRInnerFormLayout } from 'components/organism/OPRInnerFormLayout'
import { validationSchemaTerminationCode } from 'constants/validate'
import { useEditable } from 'hooks/useEdit'
import useForm from 'hooks/useForm'
import { t } from 'i18next'
import { useEffect } from 'react'
import { useLocation, useNavigate } from 'react-router-dom'
import { routes } from 'routes/routes'
import { getParamsValue } from 'utils'

interface MessageProps {
  text?: string;
  important?: boolean;
}

export default function TerminationCodeForm() {
  const location: any = useLocation()
  const { id, viewUrl } = getParamsValue(location, routes.createTerminationCode)

  const { isEditable, setEditable } = useEditable()

  const {
    values,
    setValues,
    errors,
    handleChange,
    setErrors,
    handleFormSubmit,
  } = useForm(validationSchemaTerminationCode)

  const navigate = useNavigate()
  const [
    createTerminationCode,
    {
      data: createdTerminationCodeData,
      error: createdTerminationCodeError,
      isLoading: createdTerminationCodeLoading,
      isSuccess: createdTerminationCodeSuccess,
      isError: createdTerminationCodeIsError,
    },
  ] = useTerminationCodeCreateMutation()

  const [
    updateTerminationCode,
    {
      data: updatedDataResponse,
      error: updatedTerminationCodeError,
      isLoading: updatedTerminationCodeLoading,
      isSuccess: updatedTerminationCodeSuccess,
      isError: updatedTerminationCodeIsError,
    },
  ] = useTerminationCodeUpdateMutation()

  const [
    updateTerminationCodeById,
    {
      data: updatedTerminationCodeByIdResponse,
      error: updatedTerminationCodeByIdError,
      isLoading: updatedTerminationCodeByIdLoading,
      isSuccess: updatedTerminationCodeByIdSuccess,
      isError: updatedTerminationCodeByIdIsError,
    },
  ] = useLazyGetTerminationCodeByIdQuery()

  useEffect(() => {
    if (id) {
      updateTerminationCodeById(id)
      setEditable(viewUrl)
    }
  }, [])
  useEffect(() => {
    if (id) {
      setValues(updatedTerminationCodeByIdResponse?.data)
    } else {
      setValues(location.state ? location.state : {})
    }
  }, [updatedTerminationCodeByIdResponse?.data])
  // useEffect(() => {
  //   if (createdTerminationCodeSuccess) {
  //     // Reset form values after successful add operation
  //     setValues({})
  //   }
  // }, [createdTerminationCodeSuccess])

  const handleSubmit: any = async () => {
    if (isEditable) {
      if (id === null) {
        await createTerminationCode({
          terminationCode: values?.terminationCode,
          terminationReason: values?.terminationReason,
          remarks: values?.remarks || '',
        })
      } else {
        await updateTerminationCode({
          id: values?.id,
          terminationCode: values?.terminationCode,
          terminationReason: values?.terminationReason,
          remarks: values?.remarks || '',
        })
      }
    } else {
      setEditable(true)
    }
  }

  async function editTerminationCode() {
    await updateTerminationCode({
      id: values.id,
      terminationCode: values?.terminationCode,
      terminationReason: values?.terminationReason,
      remarks: values?.remarks || '',
    })
  }

  const onScreenClose:any = (item: any) => {
    setEditable(item)
    setValues({})
  }

  return (
    <Box sx={{ display: 'flex' }}>
      <form
        style={{ display: 'flex', width: '100% ' }}
        onSubmit={(e) => handleFormSubmit(e, handleSubmit)}
      >
        <OPRAlertControl
          error={createdTerminationCodeError || updatedTerminationCodeError}
          handleEditable={setEditable}
          handleSetValue={setValues}
          handleSubmit={handleSubmit}
          isError={
            createdTerminationCodeError || updatedTerminationCodeIsError
          }
          isLoading={
            createdTerminationCodeLoading
            || updatedTerminationCodeLoading
            || updatedTerminationCodeByIdLoading
          }
          isSuccess={
            updatedTerminationCodeSuccess || createdTerminationCodeSuccess
          }
          name={values?.terminationReason}
          title={t('entity_submenu_termination_code_title')}
          type={id ? 'Update' : 'New'}
        />
        <OPRInnerFormLayout
          error={createdTerminationCodeError || updatedTerminationCodeError}
          handleCancelClick={() => navigate(-1)}
          handleContinueClick={handleSubmit}
          handleEditable={() => {
            setEditable(true)
          }}
          isBackButton={isEditable}
          isLoading={
            createdTerminationCodeLoading
            || updatedTerminationCodeLoading
            || updatedTerminationCodeByIdLoading
          }
          pageType="detailsPage"
          subtitle={
            isEditable
              ? 'Please check the user details below.'
              : 'All fields are mandatory except those marked optional'
          }
          // title={t('add_termincation_code')}
          title={(viewUrl) ? t('Termination Code') : false || ((id) ? values?.terminationReason : t('add_termincation_code'))} // Set title based on mode
          onScreenClose={onScreenClose}
        >
          <Box>
            <OPRResponsiveGrid>
              <Grid item md={2} sm={1} xs={1}>
                <OPRInputControl
                  disabled={!!id}
                  error={t(errors?.terminationCode)}
                  isEditable={isEditable}
                  label="termination_code"
                  name="terminationCode"
                  value={values?.terminationCode}
                  onChange={handleChange}
                />
              </Grid>
              <Grid item md={2} sm={1} xs={1}>
                <OPRInputControl
                  error={t(errors?.terminationReason)}
                  isEditable={isEditable}
                  label="termination_description"
                  name="terminationReason"
                  value={values?.terminationReason}
                  onChange={handleChange}
                />
              </Grid>
              <Grid item md={4} sm={6} xs={12}>
                <OPRTextArea
                  error={t(errors?.remarks)}
                  isEditable={isEditable}
                  label="remarks"
                  name="remarks"
                  optionalText="optional"
                  value={values?.remarks}
                  onChange={handleChange}
                />
              </Grid>
            </OPRResponsiveGrid>
          </Box>
        </OPRInnerFormLayout>
      </form>
    </Box>
  )
}
