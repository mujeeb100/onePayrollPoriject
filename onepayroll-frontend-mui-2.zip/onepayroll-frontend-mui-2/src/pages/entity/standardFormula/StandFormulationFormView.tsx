import { Box, Tab, Tabs } from '@mui/material'
import { CustomTabPanel } from 'components/atoms/tabs'
import { OPRInnerFormLayout } from 'components/organism/OPRInnerFormLayout'
import { useState } from 'react'

import StandardFormulaForm from './StandardFormulaForm'
import TermForm from './term/TermForm'

function a11yProps(index: number) {
  return {
    id: `simple-tab-${index}`,
    'aria-controls': `simple-tabpanel-${index}`,
  }
}
export default function StandFormulationFormView(props: any) {
  const [selectedTab, handleTabChange] = useState(0)
  const handleTabChangeEvent = (event: React.SyntheticEvent, newValue: number) => {
    handleTabChange(newValue)
  }
  return (
    <OPRInnerFormLayout
      error={false}
      //   handleCancelClick={() => navigate(-1)}
      //   handleContinueClick={handleSubmit}
      //   handleEditable={() => {
      //     setEditable(true)
      //   }}
      isLoading={false}
      pageType="detailsPage"
      subtitle={true ? 'Please check the user details below.' : 'All field to mandatory expect those marked optional'}
      title="FormulaSetup"
    //   onScreenClose={onScreenClose}
    >
      <Box sx={{ borderBottom: 1, borderColor: 'divider' }}>
        <Tabs aria-label="basic tabs example" value={selectedTab} onChange={handleTabChangeEvent}>
          <Tab label="General" {...a11yProps(0)} />
          <Tab label="Terms" {...a11yProps(1)} />
        </Tabs>
        <Box sx={{ display: 'flex', flexDirection: 'column' }}>
          <CustomTabPanel index={0} value={selectedTab}>
            <StandardFormulaForm />
            {/* <h1>gregee</h1> */}
          </CustomTabPanel>
          <CustomTabPanel index={1} value={selectedTab}>
            <TermForm />
            {/* <h1>Employement EmployeeForm</h1> */}
          </CustomTabPanel>
        </Box>
      </Box>
    </OPRInnerFormLayout>

  )
}
