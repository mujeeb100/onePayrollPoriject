import {
  Box, Grid, Tab, Tabs,
} from '@mui/material'
import { useFormulaSetupCreateMutation, useFormulaSetupUpdateMutation, useLazyGetFormulaSetupByIdQuery } from 'api/payRollServices'
import { RighCaretBlue } from 'assets/svg-images/SvgComponents'
import OPRButton from 'components/atoms/button/OPRButton'
import { CustomDialog } from 'components/atoms/modal/OPRModal'
import { CustomTabPanel } from 'components/atoms/tabs'
import OPRFormHeaderLabel from 'components/molecules/OPRFormHeaderLabel/OPRFormHeaderLabel'
import OPRInputControl from 'components/molecules/OPRInputControl'
import OPRResponsiveGrid from 'components/molecules/OPRResponsiveGrid'
import OPRAlertControl from 'components/organism/OPRAlertControl'
import { OPRInnerFormLayout } from 'components/organism/OPRInnerFormLayout'
import { formulaSetupValidationSchema } from 'constants/validate'
import { useEditable } from 'hooks/useEdit'
import useForm from 'hooks/useForm'
import { useEffect, useState } from 'react'
import { useLocation, useNavigate } from 'react-router-dom'
import { routes } from 'routes/routes'
import { getParamsValue } from 'utils'

import TermList from './term'

interface MessageProps {
    text?: string;
    important?: boolean;
  }
function a11yProps(index: number) {
  return {
    id: `simple-tab-${index}`,
    'aria-controls': `simple-tabpanel-${index}`,
  }
}
export default function StandardFormulaForm() {
  const location: any = useLocation()
  const { id, viewUrl } = getParamsValue(location, routes.createFormulaSetup)
  const [selectedTab, handleTabChange] = useState(0)
  const [isModal, setModal] = useState(false)

  const handleTabChangeEvent = (event: React.SyntheticEvent, newValue: number) => {
    handleTabChange(newValue)
  }
  const {
    isEditable,
    setEditable,
  } = useEditable()
  const [editUser, setEditUser] = useState(false)

  const {
    values,
    setValues,
    errors,
    handleChange,
    setErrors,
    handleFormSubmit,
  } = useForm(formulaSetupValidationSchema)

  const navigate = useNavigate()
  const [createFormulaSetup, {
    data: createdFormulaSetupData,
    error: createdFormulaSetupError,
    isLoading: createdFormulaSetupLoading,
    isSuccess: createdFormulaSetupSuccess,
    isError: createdFormulaSetupIsError,
  }] = useFormulaSetupCreateMutation()

  const [updateFormulaSetup, {
    data: updatedDataResponse,
    error: updatedFormulaSetupError,
    isLoading: updatedFormulaSetupLoading,
    isSuccess: updatedFormulaSetupSuccess,
    isError: updatedFormulaSetupIsError,
  }] = useFormulaSetupUpdateMutation()

  const [updateFormulaSetupById, {
    data: updatedFormulaSetupByIdResponse,
    error: updatedFormulaSetupByIdError,
    isLoading: updatedFormulaSetupByIdLoading,
    isSuccess: updatedFormulaSetupByIdSuccess,
    isError: updatedFormulaSetupByIdIsError,
  }] = useLazyGetFormulaSetupByIdQuery()

  useEffect(() => {
    if (id) {
      updateFormulaSetupById(id)
      setEditable(viewUrl)
    }
  }, [])
  useEffect(() => {
    if (id) {
      setValues(updatedFormulaSetupByIdResponse?.data)
    } else {
      setValues(location.state ? location.state : {})
      // setEditable(false)
    }
  }, [updatedFormulaSetupByIdResponse?.data])

  useEffect(() => {
    if (createdFormulaSetupSuccess) {
      // Reset form values after successful add operation
      setValues({})
      setErrors({})
    }
  }, [createdFormulaSetupSuccess])

  const handleSubmit:any = async () => {
    if (isEditable) {
      if (id === null) {
        await createFormulaSetup({
          formulaCode: values?.formulaCode?.toUpperCase(),
          description: values?.description,
        })
      } else {
        await updateFormulaSetup({
          id: values.id,
          formulaCode: values?.formulaCode?.toUpperCase(),
          description: values?.description,
        })
      }
    } else {
      setEditable(true)
    }
  }

  async function editFormulaSetup() {
    await updateFormulaSetup({
      id: values.id,
      FormulaSetupCode: values.FormulaSetupCode?.toUpperCase(),
      FormulaSetupName: values.FormulaSetupName,
    })
  }

  const onScreenClose:any = (item:any) => {
    setEditable(item)
    setValues({})
  }

  return (
    <Box sx={{ display: 'flex' }}>
      <CustomDialog
        CustomStyles={{ borderRadius: '16px' }}
        isOpen={isModal}
        type="loader"
      >
        <OPRFormHeaderLabel isSubTitle title="Add term" />
        <br />
        <OPRResponsiveGrid>
          <Grid item md={2} sm={1} xs={1}>
            <OPRInputControl
              error={errors?.formulaCode}
              isEditable={editUser}
              label="Formula ID"
              name="formulaCode"
              value={values?.formulaCode}
              onChange={handleChange}
            />
          </Grid>
          <Grid item md={2} sm={1} xs={1}>
            <OPRInputControl
              error={errors?.description}
              isEditable={editUser}
              label="Formula name"
              name="description"
              value={values?.description}
              onChange={handleChange}
            />
          </Grid>
        </OPRResponsiveGrid>
        <Box sx={{
          display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: 2,
        }}
        >
          <OPRButton
            color="info"
            variant="text"
            onClick={() => {
              setEditUser(false)
              setModal(false)
            }}
          >
            Cancel
          </OPRButton>
          <Box>
            {
              editUser && (
                <OPRButton
                  style={{ marginLeft: 'auto' }}
                  variant="text"
                  onClick={() => {
                    setEditUser(false)
                  }}
                >
                  <RighCaretBlue />
                  Back
                </OPRButton>
              )
            }
            <OPRButton
              color="info"
              variant="text"
              onClick={(e:any) => {
                if (editUser) {
                  handleSubmit()
                } else {
                  setEditUser(true)
                }
                // handleFormSubmit(e, handleSubmit)
                // if (isEditable) {
                //   handleFormSubmit(e, handleSubmit)
                // } else {
                //   setEditable(true)
                // }
              }}
            >
              Confirm
            </OPRButton>
          </Box>
        </Box>
      </CustomDialog>
      {/* <form style={{ display: 'flex', width: '100% ' }} onSubmit={(e) => handleFormSubmit(e, handleSubmit)}> */}
      <OPRAlertControl
        callBack={(type) => {
          alert('dgfd')
          // if (type === 'success') {
          //   navigate(-1)
          // }
        }}
        error={createdFormulaSetupError || updatedFormulaSetupError}
        handleEditable={setEditable}
        handleSetValue={setValues}
        handleSubmit={handleSubmit}
        isError={createdFormulaSetupError || updatedFormulaSetupError}
        isLoading={createdFormulaSetupLoading || updatedFormulaSetupLoading || updatedFormulaSetupByIdLoading}
        isSuccess={updatedFormulaSetupSuccess || createdFormulaSetupSuccess}
        name={values?.FormulaSetupName}
        // previousUrl={routes.formulaSetup}
        title="Formula setup"
        type={id ? 'Update' : 'New'}
      />
      <OPRInnerFormLayout
        isEditUser
        isHandleContinueClick
        error={createdFormulaSetupError || updatedFormulaSetupError}
        handleCancelClick={() => navigate(-1)}
        handleContinueClick={handleSubmit}
        handleEditable={() => {
          // setModal(true)
          // setEditable(true)
        }}
        handleUserCreate={() => {
          setModal(true)
        }}
        isBackButton={isEditable}
        isLoading={createdFormulaSetupLoading || updatedFormulaSetupLoading || updatedFormulaSetupByIdLoading}
        pageType="detailsPage"
        subtitle={isEditable ? 'Please check the user details below.' : 'All field to mandatory expect those marked optional'}
        title="Formula Setup"
        onScreenClose={onScreenClose}
      >
        <Box sx={{ borderBottom: 1, borderColor: 'divider' }}>
          {
            viewUrl && (
              <Tabs aria-label="basic tabs example" value={selectedTab} onChange={handleTabChangeEvent}>
                <Tab label="General" {...a11yProps(0)} />
                <Tab label="Terms" {...a11yProps(1)} />
              </Tabs>
            )
          }

          <Box sx={{ display: 'flex', flexDirection: 'column' }}>
            <CustomTabPanel index={0} value={selectedTab}>
              <OPRResponsiveGrid>
                <Grid item md={2} sm={1} xs={1}>
                  <OPRInputControl
                    error={errors?.formulaCode}
                    isEditable={isEditable}
                    label="Formula ID"
                    name="formulaCode"
                    value={values?.formulaCode}
                    onChange={handleChange}
                  />
                </Grid>
                <Grid item md={2} sm={1} xs={1}>
                  <OPRInputControl
                    error={errors?.description}
                    isEditable={isEditable}
                    label="Formula name"
                    name="description"
                    value={values?.description}
                    onChange={handleChange}
                  />
                </Grid>
              </OPRResponsiveGrid>
            </CustomTabPanel>
            {
              viewUrl && (
                <CustomTabPanel index={1} value={selectedTab}>
                  <TermList formulaCode={values?.formulaCode} />
                </CustomTabPanel>
              )
            }

          </Box>
        </Box>
      </OPRInnerFormLayout>
      {/* </form> */}
    </Box>
  )
}
