import { Box, Grid } from '@mui/material'
import { useGetAllFormulaExpressionsQuery, useLazyGetTermByIdQuery, useTermCreateMutation } from 'api/payRollServices'
import OPRFormHeaderLabel from 'components/molecules/OPRFormHeaderLabel/OPRFormHeaderLabel'
import OPRInputControl from 'components/molecules/OPRInputControl'
import OPRResponsiveGrid from 'components/molecules/OPRResponsiveGrid'
import OPRSelectorControl from 'components/molecules/OPRSelectorControl/OPRSelectorControl'
import {
  forwardRef,
} from 'react'

interface MessageProps {
    text?: string;
    important?: boolean;
    isView?: boolean;
  }

const TermForm = forwardRef(({
  errors, values, isEditable, handleChange, handleOnChange, selectedId, setValues,
}:any, ref) => {
  const [createTerms, {
    data: createdTermsData,
    error: createdTermsError,
    isLoading: createdTermsLoading,
    isSuccess: createdTermsSuccess,
    isError: createdTermsIsError,
  }] = useTermCreateMutation()

  const [updateTermsById, {
    data: updatedTermsByIdResponse,
    error: updatedTermsByIdError,
    isLoading: updatedTermsByIdLoading,
    isSuccess: updatedTermsByIdSuccess,
    isError: updatedTermsByIdIsError,
  }] = useLazyGetTermByIdQuery()
  // formula expression
  const {
    data: allPosts,
    error: createAllPostsFormulaExpressionsError,
    isLoading: isLoadingAllPosts,
    isSuccess: isSuccessAllPosts,
    isError: isErrorAllPosts,
    error: errorAllPosts,
  } = useGetAllFormulaExpressionsQuery('')

  return (
    <Box>

      {/* <OPRLabel variant="h4">Add term</OPRLabel> */}

      <OPRFormHeaderLabel isSubTitle title="Add term" />
      <br />
      <OPRResponsiveGrid>
        <Grid item md={12} sm={1} xs={1}>
          <OPRInputControl
            error={errors?.termCode}
            isEditable={isEditable}
            label="Term code"
            name="termCode"
            value={values?.termCode}
            onChange={handleChange}
          />
        </Grid>
        <Grid item md={12} sm={1} xs={1}>
          <OPRInputControl
            error={errors?.description}
            isEditable={isEditable}
            label="Term description"
            name="description"
            value={values?.description}
            onChange={handleChange}
          />
        </Grid>
        <Grid item md={12} sm={1} xs={1}>
          <OPRInputControl
            error={errors?.updateSequence}
            isEditable={isEditable}
            label="Update sequence"
            name="updateSequence"
            value={values?.updateSequence}
            onChange={handleChange}
          />
        </Grid>
        {/* <Grid item md={12} sm={1} xs={1}>
          <OPRSelectorControl
            error={errors?.title}
            isEditable={isEditable}
            keyName="name"
            label="Use existing expression"
            name="name"
            options={[
              { name: 'e.FourOneEightStartDate', value: 'e.FourOneEightStartDate' },
            ]}
            value={[
              { name: 'e.FourOneEightStartDate', value: 'e.FourOneEightStartDate' },
            ]?.find((o:any) => o?.value === values?.expressionCode) || {}}
            valueKey="value"
            onChange={(text:any) => {
              handleOnChange('expressionCode', text?.value)
            }}
          />
        </Grid> */}
        <Grid item md={12} sm={1} xs={1}>
          <OPRSelectorControl
            error={errors?.title}
            isEditable={isEditable}
            keyName="expressionCode"
            label="Use existing expression"
            name="ExpressionCode"
            options={(allPosts?.records || [])}
            placeholder="Select an option"
            value={(allPosts?.records || [])?.find((o:any) => o?.value === values?.expressionCode) || {}}
            valueKey="expressionCode"
            onChange={(text:any) => {
              handleOnChange('expressionCode', text?.value)
            }}
          />
        </Grid>

        <Grid item md={12} sm={1} xs={1}>
          <OPRInputControl
            multiline
            error={errors?.expression}
            isEditable={isEditable}
            label="Expression"
            name="expression"
            value={values?.expression}
            onChange={handleChange}
          />
        </Grid>
      </OPRResponsiveGrid>

    </Box>
  )
})

export default TermForm
