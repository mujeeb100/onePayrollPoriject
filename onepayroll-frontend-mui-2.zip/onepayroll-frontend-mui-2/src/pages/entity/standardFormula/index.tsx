import {
  Box,
} from '@mui/material'
import { useFormulaSetupDeleteMutation, useGetAllFormulaSetupQuery } from 'api/payRollServices'
import { formulaSetupColumn } from 'components/atoms/table/OPRTableConstant'
import { OPRInnerListLayout } from 'components/organism/OPRInnerLayoutList'
import { t } from 'i18next'
import React, { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { routes } from 'routes/routes'
import {
  generateFilterUrl, setRouteValues,
} from 'utils'

function StandardFormulaList() {
  const navigate: any = useNavigate()
  const [filterData, setFilterData]:any = useState({
    pageNumber: 1,
    pageSize: 20,
    totalItems: 0,
    orderByAsc: true,
    sortBy: '',
    SearchText: '',
  })
  const {
    data: allPosts,
    error: createAllPostsBankAccountError,
    isLoading: isLoadingAllPosts,
    isSuccess: isSuccessAllPosts,
    isError: isErrorAllPosts,
    error: errorAllPosts,
  } = useGetAllFormulaSetupQuery(generateFilterUrl(filterData))
  const [deleteFormulaSetupById,
    {
      data: deleteFormulaSetupResponse,
      error: deleteFormulaSetupError,
      isLoading: deleteFormulaSetupLoading,
      isSuccess: deleteFormulaSetupSuccess,
      isError: deleteFormulaSetupIsError,
    }] = useFormulaSetupDeleteMutation()

  const sorting = (
    event: React.MouseEvent<unknown>,
    property: keyof any,
  ) => {
    const isAsc = filterData.sortBy === property && filterData.orderByAsc === true
    setFilterData({ ...filterData, orderByAsc: !isAsc, sortBy: property })
    // setOrder(isAsc ? 'desc' : 'asc')
    // setOrderBy(property)
  }

  useEffect(() => {
    setFilterData({ ...filterData, totalItems: allPosts?.totalItems ? allPosts?.totalItems : 0 })
  }, [allPosts?.pageNumber, filterData.sortBy, filterData.orderByAsc, allPosts?.totalItems])

  const onSearch = (e: any, data: any) => {
    setFilterData({ ...filterData, ...data })
  }
  const handlePagination = (pageNumber: number, pageSize: number) => {
    setFilterData({ ...filterData, pageNumber })
  }
  const viewAcoount = (data: any, type:string) => {
    if (type === 'edit FormulaSetup') {
      navigate(
        setRouteValues(`${routes.editFormulaSetup}`, {
          id: data.id,
        }),
      )
    } else if (type === 'Delete formula') {
      deleteFormulaSetupById(`FormulaCode=${data.ormulaCode}`)
    } else {
      navigate(
        setRouteValues(`${routes.viewFormulaSetup}`, {
          id: data.id,
          view: true,
        }),
      )
    }
    // const id = JSON.stringify(data)
  }
  const handleView = (data: any) => {
    navigate(
      setRouteValues(`${routes.viewFormulaSetup}`, {
        id: data.id,
        view: true,
      }),
    )
  }
  return (
    <Box sx={{ display: 'flex' }}>
      <OPRInnerListLayout
        Search={filterData.SearchText}
        addHandleClick={() => navigate(routes.createFormulaSetup)}
        columns={formulaSetupColumn(viewAcoount)}
        dataList={JSON.parse(JSON.stringify(allPosts?.records || []))}
        error={errorAllPosts || deleteFormulaSetupError}
        filterData={filterData}
        handlePagination={handlePagination}
        handleSearch={onSearch}
        isAdd={false}
        isError={isErrorAllPosts || deleteFormulaSetupIsError}
        loading={isLoadingAllPosts || deleteFormulaSetupLoading}
        rowClickHandler={handleView}
        rowNumber={0}
        sortHandleClick={sorting}
        success={deleteFormulaSetupSuccess}
        title={t('Formula setup')}
      />
    </Box>
  )
}

export default StandardFormulaList
