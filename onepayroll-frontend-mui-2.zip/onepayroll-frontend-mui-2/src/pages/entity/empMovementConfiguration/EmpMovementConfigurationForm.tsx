import { Box, Grid } from '@mui/material'
import {
  useEmployeeMovementConfigurationCreateMutation,
  useEmployeeMovementConfigurationUpdateMutation,
  useGetAllEmployeeMovementQuery,
  useLazyGetEmployeeMovementConfigurationByIdQuery,
} from 'api/entityServices'
import OPRInputControl from 'components/molecules/OPRInputControl'
import OPRResponsiveGrid from 'components/molecules/OPRResponsiveGrid'
import OPRSelectorControl from 'components/molecules/OPRSelectorControl/OPRSelectorControl'
import OPRAlertControl from 'components/organism/OPRAlertControl'
import { OPRInnerFormLayout } from 'components/organism/OPRInnerFormLayout'
import {
  validationSchemaEmployeeMovementConfiguration,
} from 'constants/validate'
import { useEditable } from 'hooks/useEdit'
import useForm from 'hooks/useForm'
import { t } from 'i18next'
import { useEffect, useState } from 'react'
import { useLocation, useNavigate } from 'react-router-dom'
import { routes } from 'routes/routes'
import { getParamsValue } from 'utils'

const defaultValue = {
  movementType: null,
  fieldName: null,
  displaySequence: null,
  mandatory: 'no',
}

interface MessageProps {
  text?: string;
  important?: boolean;
}

export default function EmployeeMovementConfigurationForm() {
  const location: any = useLocation()
  // const id = getParamsValue(location, routes.createEmployeeMovementConfiguration)
  const { id, viewUrl } = getParamsValue(location, routes.createEmployeeMovementConfiguration)
  const [mode, setMode] = useState('view') // Default mode is edit
  const { isEditable, setEditable } = useEditable()

  const {
    values,
    setValues,
    errors,
    handleChange,
    setErrors,
    handleFormSubmit,
    handleOnChange,
  } = useForm(validationSchemaEmployeeMovementConfiguration)

  const navigate = useNavigate()
  const [
    createEmployeeMovementConfiguration,
    {
      data: createdEmployeeMovementConfigurationData,
      error: createdEmployeeMovementConfigurationError,
      isLoading: createdEmployeeMovementConfigurationLoading,
      isSuccess: createdEmployeeMovementConfigurationSuccess,
      isError: createdEmployeeMovementConfigurationIsError,
    },
  ] = useEmployeeMovementConfigurationCreateMutation()

  const [
    updateEmployeeMovementConfiguration,
    {
      data: updatedDataResponse,
      error: updatedEmployeeMovementConfigurationError,
      isLoading: updatedEmployeeMovementConfigurationLoading,
      isSuccess: updatedEmployeeMovementConfigurationSuccess,
      isError: updatedEmployeeMovementConfigurationIsError,
    },
  ] = useEmployeeMovementConfigurationUpdateMutation()

  const [
    updateEmployeeMovementConfigurationById,
    {
      data: updatedEmployeeMovementConfigurationByIdResponse,
      error: updatedEmployeeMovementConfigurationByIdError,
      isLoading: updatedEmployeeMovementConfigurationByIdLoading,
      isSuccess: updatedEmployeeMovementConfigurationByIdSuccess,
      isError: updatedEmployeeMovementConfigurationByIdIsError,
    },
  ] = useLazyGetEmployeeMovementConfigurationByIdQuery()

  const {
    data: allPostsEmpMovementType,
  } = useGetAllEmployeeMovementQuery('')
  useEffect(() => {
    if (id) {
      updateEmployeeMovementConfigurationById(id)
      setEditable(viewUrl)
      // setMode('view') // Set mode to view if id is present
    }
  }, [])
  useEffect(() => {
    if (id) {
      setValues(updatedEmployeeMovementConfigurationByIdResponse?.data)
    } else {
      setValues(location.state ? location.state : {})
    }
  }, [updatedEmployeeMovementConfigurationByIdResponse?.data])

  // reset the values
  useEffect(() => {
    if (createdEmployeeMovementConfigurationSuccess) {
      setValues({})
    }
  }, [createdEmployeeMovementConfigurationSuccess])

  useEffect(() => {
    if (id === null) {
      setValues(defaultValue)
    }
  }, [])
  const handleSubmit: any = async () => {
    if (isEditable) {
      if (id === null) {
        await createEmployeeMovementConfiguration({
          movementType: values?.movementType,
          fieldName: values?.fieldName,
          mandatory: values?.mandatory,
          displaySequence: Number(values.displaySequence) || 0,

        })
      } else {
        await updateEmployeeMovementConfiguration({
          id: values?.id,
          movementType: values?.movementType,
          fieldName: values?.fieldName,
          mandatory: values?.mandatory,
          displaySequence: Number(values.displaySequence) || 0,
        })
      }
    } else {
      setEditable(true)
    }
  }

  async function editEmployeeMovementConfiguration() {
    await updateEmployeeMovementConfiguration({
      id: values?.id,
      movementType: values?.movementType,
      fieldName: values?.fieldName,
      mandatory: values?.mandatory,
      displaySequence: Number(values.displaySequence) || 0,
    })
  }

  const onScreenClose:any = (item: any) => {
    setEditable(item)
    setValues({})
  }

  return (
    <Box sx={{ display: 'flex' }}>
      <form
        style={{ display: 'flex', width: '100% ' }}
        onSubmit={(e) => handleFormSubmit(e, handleSubmit)}
      >
        <OPRAlertControl
          error={createdEmployeeMovementConfigurationError || updatedEmployeeMovementConfigurationError}
          handleEditable={setEditable}
          handleSetValue={setValues}
          handleSubmit={handleSubmit}
          isError={createdEmployeeMovementConfigurationError || updatedEmployeeMovementConfigurationError}
          isLoading={
            createdEmployeeMovementConfigurationLoading
            || updatedEmployeeMovementConfigurationLoading
            || updatedEmployeeMovementConfigurationByIdLoading
          }
          isSuccess={updatedEmployeeMovementConfigurationSuccess || createdEmployeeMovementConfigurationSuccess}
          name={t('ent_emp_movement_configuration_title')}
          title={t('ent_emp_movement_configuration_title')}
          type={id ? 'Update' : 'New'}
        />

        <OPRInnerFormLayout
          error={createdEmployeeMovementConfigurationError || updatedEmployeeMovementConfigurationError}
          handleCancelClick={() => navigate(-1)}
          handleContinueClick={handleSubmit}
          handleEditable={() => {
            setEditable(true)
          }}
          isBackButton={isEditable}
          isLoading={
            createdEmployeeMovementConfigurationLoading
            || updatedEmployeeMovementConfigurationLoading
            || updatedEmployeeMovementConfigurationByIdLoading
          }
          pageType="detailsPage"
          subtitle={
            isEditable
              ? 'Please check the user details below.'
              : 'All fields are mandatory except those marked optional'
          }
          title={(viewUrl) ? t('ent_emp_movement_configuration_title') : false || ((id) ? values?.movementType : `${t('add')} ${t('ent_emp_movement_configuration_title')}`)}
          onScreenClose={onScreenClose}

        >
          <Box>
            <OPRResponsiveGrid>
              <Grid item md={2} sm={1} xs={1}>
                <OPRSelectorControl
                  disabled={!!id}
                  error={errors?.movementType}
                  isEditable={isEditable}
                  keyName="movementType"
                  label="ent_emp_movement_configuration_movement_type"
                  multiple={false}
                  name="movementType"
                  options={(allPostsEmpMovementType?.records || [])}
                  placeholder="Select an option"
                  value={(allPostsEmpMovementType?.records || [])?.find((o:any) => o?.movementType === values?.movementType) || {}}
                  valueKey="movementType"
                  onChange={(text:any) => {
                    handleOnChange('movementType', text?.movementType)
                  }}
                />
              </Grid>

              <Grid item md={2} sm={1} xs={1}>
                <OPRSelectorControl
                  error={errors?.fieldName}
                  isEditable={isEditable}
                  keyName="FieldsName"
                  label="ent_emp_movement_configuration_field_name"
                  multiple={false}
                  name="fieldName"
                  options={[
                    { FieldsName: 'Commencement Date', FieldsValue: 'Commencement Date' },
                    { FieldsName: 'Date Join Group', FieldsValue: 'Date Join Group' },

                    { FieldsName: 'Department', FieldsValue: 'Department' },
                    { FieldsName: 'Cost Center', FieldsValue: 'Cost Center' },
                    { FieldsName: 'Division', FieldsValue: 'Division' },
                    { FieldsName: 'Region', FieldsValue: 'Region' },
                    { FieldsName: 'Team', FieldsValue: 'Team' },
                    { FieldsName: 'IRD Corporate Title', FieldsValue: 'IRD Corporate Title' },
                    { FieldsName: 'Position', FieldsValue: 'Position' },
                    { FieldsName: 'Grade', FieldsValue: 'Grade' },
                    { FieldsName: 'Staff Type', FieldsValue: 'Staff Type' },
                    { FieldsName: 'Last Employment Date', FieldsValue: 'Last Employment Date' },
                    { FieldsName: 'Resignation Date', FieldsValue: 'Resignation Date' },
                    { FieldsName: 'Last Working Date', FieldsValue: 'Last Working Date' },
                    { FieldsName: 'Notice Period End Date', FieldsValue: 'Notice Period End Date' },
                    { FieldsName: 'Pay Through Date', FieldsValue: 'Pay Through Date' },
                    { FieldsName: 'Termination Code', FieldsValue: 'Termination Code' },
                    { FieldsName: 'Termination Reason', FieldsValue: 'Termination Reason' },
                    { FieldsName: 'Basic Pay Unit Base', FieldsValue: 'Basic Pay Unit Base' },
                    { FieldsName: 'Daily Wage', FieldsValue: 'Daily Wage' },
                    { FieldsName: 'Hourly Wage', FieldsValue: 'Hourly Wage' },
                    { FieldsName: 'Work Calendar', FieldsValue: 'Work Calendar' },

                  ]}
                  placeholder="Select an option"
                  value={
                    { FieldsName: values?.fieldName, FieldsValue: values?.fieldName }
                  }
                  valueKey="FieldsValue"
                  onChange={(text:any) => {
                    handleOnChange('fieldName', text?.FieldsValue)
                  }}
                />
              </Grid>

              <Grid item md={2} sm={1} xs={1}>
                <OPRSelectorControl
                  error={errors?.mandatory}
                  isEditable={isEditable}
                  keyName="name"
                  label={t('ent_emp_movement_configuration_mandatory')}
                  multiple={false}
                  name="mandatory"
                  options={[{ name: 'Yes', values: 'yes' }, { name: 'No', values: 'no' }]}
                  placeholder="Select an option"
                  value={[{ name: 'Yes', values: 'yes' }, { name: 'No', values: 'no' }]?.find((o:any) => o?.values === values?.mandatory) || {}}
                  valueKey="name"
                  onChange={(text:any) => {
                    handleOnChange('mandatory', text?.values)
                  }}
                />
              </Grid>

              <Grid item md={2} sm={1} xs={1}>
                <OPRInputControl
                  error={t(errors?.displaySequence)}
                  isEditable={isEditable}
                  label="ent_emp_movement_configuration_dsp"
                  name="displaySequence"
                  value={values?.displaySequence}
                  onChange={handleChange}
                />
              </Grid>

            </OPRResponsiveGrid>
          </Box>
        </OPRInnerFormLayout>
      </form>
    </Box>
  )
}
