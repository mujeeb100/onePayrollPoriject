import ExpandMoreIcon from '@mui/icons-material/ExpandMore'
import {
  Accordion, AccordionDetails, AccordionSummary, Box, Checkbox, Grid,
} from '@mui/material'
import { useLazyGetUserRolePermissionByIdQuery, useUserRolePermissionCreateMutation, useUserRolePermissionUpdateMutation } from 'api/identityServices'
import OPRLabel from 'components/atoms/label/OPRLabel'
import OPRAlertControl from 'components/organism/OPRAlertControl'
import { useEditable } from 'hooks/useEdit'
import React, { useEffect, useImperativeHandle, useState } from 'react'
import { routes } from 'routes/routes'

export const PermissionManager = React.forwardRef(({
  initialPermissions, id, roleCode, callBackHandler, roleName, roleType, activeState, setActiveState, permissionsError, setPermissionsError,
}:any, ref:any) => {
  const [permissions, setPermissions] = useState([])
  // const [permissionsError, setPermissionsError] = useState(false)
  const { isEditable, setEditable } = useEditable()
  const [items, setItems]:any = useState([])

  // Function to add or remove an item
  const toggleItem:any = (item:any) => {
    setItems((prevItems:any) => {
      if (prevItems.includes(item)) {
        // If the item is already in the array, remove it
        return prevItems.filter((i:any) => i !== item)
      }
      // If the item is not in the array, add it
      return [...prevItems, item]
    })
  }
  const [
    createUserRolePermission,
    {
      data: createdUserRolePermissionData,
      error: createdUserRolePermissionError,
      isLoading: createdUserRolePermissionLoading,
      isSuccess: createdUserRolePermissionSuccess,
      isError: createdUserRolePermissionIsError,
    },
  ] = useUserRolePermissionCreateMutation()

  const [
    updateUserRolePermission,
    {
      data: updatedDataResponse,
      error: updatedUserRolePermissionError,
      isLoading: updatedUserRolePermissionLoading,
      isSuccess: updatedUserRolePermissionSuccess,
      isError: updatedUserRolePermissionIsError,
    },
  ] = useUserRolePermissionUpdateMutation()

  const [
    updateUserRolePermissionById,
    {
      data: updatedUserRoleByIdResponse,
      error: updatedUserRolePermissionByIdError,
      isLoading: updatedUserRolePermissionByIdLoading,
      isSuccess: updatedUserRolePermissionByIdSuccess,
      isError: updatedUserRolePermissionByIdIsError,
    },
  ] = useLazyGetUserRolePermissionByIdQuery()
  useImperativeHandle(ref, () => ({
    childMethod() {
      if (findPermission().length === 0) {
        setPermissionsError(true)
      } else {
        createPermission()
      }
    },
    checkPermissionValidation() {
      if (findPermission().length === 0) {
        setPermissionsError(true)
      } else {
        setActiveState(activeState + 1)
      }
    },
  }))
  useEffect(() => {
    if (findPermission().length > 0) {
      setPermissionsError(false)
    }
  }, [findPermission().length])
  useEffect(() => {
    if (updatedUserRolePermissionByIdSuccess) {
      setPermissions(updatedUserRoleByIdResponse.responseData)
    }
  }, [updatedUserRolePermissionByIdSuccess])

  // useEffect(() => {
  //   if (findPermission().length === 0) {
  //     setPermissionsError(true)
  //   }
  // }, [updatedUserRolePermissionByIdSuccess])

  function findPermission() {
    const truePermissions:any = []
    permissions.forEach((group:any) => {
      group.subGroups.forEach((subGroup:any) => {
        subGroup.permissions.forEach((permission:any) => {
          if (permission.status === true) {
            truePermissions.push(permission.permissionCode)
          }
        })
      })
    })
    return truePermissions
  }
  useEffect(() => {
    updateUserRolePermissionById(`${roleCode}&IsSysAdmin=${roleType}`)
  }, [])

  const createPermission = async () => {
    const data = {
      roleCode,
      permissionCode: findPermission(),
      remarks: 'test',
    }

    await createUserRolePermission(data)
  }
  const handleAllPermission = (value:any) => {
    setPermissions((prevPermissions:any) => prevPermissions.map((group:any) => {
      return {
        ...group,
        subGroups: group.subGroups.map((subGroup:any) => ({
          ...subGroup,
          permissions: subGroup.permissions.map((permission:any) => ({
            ...permission,
            status: value,
          })),
        })),
      }

      return group
    }))
  }
  const handleAllHeaderPermission = (groupName:any, value:any) => {
    setPermissions((prevPermissions:any) => prevPermissions.map((group:any) => {
      if (group.groupName === groupName) {
        return {
          ...group,
          subGroups: group.subGroups.map((subGroup:any) => ({
            ...subGroup,
            permissions: subGroup.permissions.map((permission:any) => ({
              ...permission,
              status: value,
            })),
          })),
        }
      }
      return group
    }))
  }

  const handleHeaderPermission = (groupName:any, permissionName:any, value:any) => {
    setPermissions((prevPermissions:any) => prevPermissions.map((group:any) => {
      if (group.groupName === groupName) {
        return {
          ...group,
          subGroups: group.subGroups.map((subGroup:any) => ({
            ...subGroup,
            permissions: subGroup.permissions.map((permission:any) => {
              if (permission.displayName === permissionName) {
                return {
                  ...permission,
                  status: value,
                }
              }
              return permission
            }),
          })),
        }
      }
      return group
    }))
  }

  const handleAllHeaderElementPermission = (groupName:any, subGroupName:any, status:any) => {
    setPermissions((prevPermissions:any) => prevPermissions.map((group:any) => {
      if (group.groupName === groupName) {
        return {
          ...group,
          subGroups: group.subGroups.map((subGroup:any) => {
            if (subGroup.subGroupName === subGroupName) {
              return {
                ...subGroup,
                permissions: subGroup.permissions.map((permission:any) => ({
                  ...permission,
                  status, // Toggle status
                })),
              }
            }
            return subGroup
          }),
        }
      }
      return group
    }))
  }
  const handleHeaderElementPermission = (groupName:any, subGroupName:any, permissionName:any) => {
    setPermissions((prevPermissions:any) => prevPermissions.map((group:any) => {
      if (group.groupName === groupName) {
        return {
          ...group,
          subGroups: group.subGroups.map((subGroup:any) => {
            if (subGroup.subGroupName === subGroupName) {
              return {
                ...subGroup,
                permissions: subGroup.permissions.map((permission:any) => {
                  if (permission.permissionName === permissionName) {
                    return {
                      ...permission,
                      status: !permission.status, // Toggle status
                    }
                  }
                  return permission
                }),
              }
            }
            return subGroup
          }),
        }
      }
      return group
    }))
  }

  const findHeaderPermission = (rowData:any) => {
    const uniqueDisplayNames = new Set()

    rowData.subGroups.forEach((subGroup:any) => {
      subGroup.permissions.forEach((permission:any) => {
        uniqueDisplayNames.add(permission.displayName)
      })
    })

    let uniqueDisplayNamesArray:any = Array.from(uniqueDisplayNames)
    uniqueDisplayNamesArray = ['All', ...uniqueDisplayNamesArray]
    return uniqueDisplayNamesArray
  }
  console.log(roleCode, 'permissions.lengthpermissions.lengthpermissions.length')

  return (
    <Box sx={{ marginTop: 5 }}>
      {permissionsError && (
        <div
          className="HelpText"
          style={{
            width: '100%', color: '#DA3237', fontSize: 14, fontFamily: 'Lato', fontWeight: '400', lineHeight: 5, wordWrap: 'break-word',
          }}
        >
          Please select at least one function and action.
        </div>
      )}
      <OPRAlertControl
        callBack={() => {
          callBackHandler()
        }}
        error={createdUserRolePermissionError || updatedUserRolePermissionError}
        handleEditable={setEditable}
        handleSubmit={() => {
          console.log('gg')
        }}
        isError={createdUserRolePermissionIsError || updatedUserRolePermissionIsError}
        isLoading={createdUserRolePermissionLoading || updatedUserRolePermissionLoading || updatedUserRolePermissionByIdLoading}
        isSuccess={createdUserRolePermissionSuccess || updatedUserRolePermissionSuccess}
        name={roleName || ''}
        previousUrl={routes.userRolesListing}
        title="User roles"
        type={id ? 'Update' : 'New'}
      />
      <label>
        <input
          checked={permissions.every((group:any) => group.subGroups.every((subGroup:any) => subGroup.permissions.every((permission:any) => permission.status)))}
          type="checkbox"
          onChange={(e) => {
            handleAllPermission(e.target.checked)
          }}
        />
        Select All
      </label>
      {permissions.map((group:any, index:any) => (
        <Accordion expanded={items.includes(index)} onChange={() => toggleItem(index)}>
          <div key={group.groupName}>
            <AccordionSummary
              aria-controls="panel1-content"
              expandIcon={<ExpandMoreIcon />}
              id="panel1-header"
              sx={{ padding: 0 }}
            >
              <OPRLabel variant="h2">{group.groupName}</OPRLabel>
            </AccordionSummary>
            <AccordionDetails sx={{ padding: 0 }}>
              <Box sx={{ gap: 2, display: 'flex', alignItems: 'center' }}>
                Select :
                <Grid xs={10}>

                  {
                    findHeaderPermission(group).map((itemList:any) => (
                      <label>
                        <Checkbox
                          checked={itemList === 'All' ? group.subGroups.every((subGroup:any) => subGroup.permissions.every((permission:any) => permission.status))
                          : group.subGroups.every((subGroup:any) => subGroup.permissions.filter((item:any) => item.displayName === itemList).every((permission:any) => permission.status))}
                          onChange={(e) => {
                            itemList === 'All' ? handleAllHeaderPermission(group.groupName, e.target.checked) : handleHeaderPermission(group.groupName, `${itemList}`, e.target.checked)
                          }}
                        />
                        {itemList}
                      </label>
                    ))
                  }
                </Grid>
              </Box>
              <Box sx={{ flexGrow: 1, gap: 2, alignItems: 'center' }}>
                <Grid
                  container
                  columns={{ xs: 1, sm: 8, md: 12 }}
                  spacing={{ xs: 0.5, md: 1.5 }}
                  sx={{ marginLeft: 0 }}
                >
                  {group.subGroups.map((subGroup:any, index:any) => (

                    <Grid md={4} sm={4} xs={2}>
                      <Box sx={{
                        display: 'flex', flexDirection: 'row', color: permissionsError ? '#DA3237' : 'grey', fontSize: 16, fontFamily: 'Lato', fontWeight: '700', wordWrap: 'break-word',
                      }}
                      >
                        <Checkbox
                          checked={subGroup.permissions.every((permission:any) => permission.status)}
                          style={{ color: permissionsError ? '#DA3237' : '', border: 'grey' }}
                          onChange={(e) => handleAllHeaderElementPermission(group.groupName, subGroup.subGroupName, e.target.checked)}
                        />
                        <h4 style={{
                          color: permissionsError ? '#DA3237' : 'rgba(0, 0, 0, 0.87)', fontSize: 16, fontFamily: 'Lato', fontWeight: '700', wordWrap: 'break-word',
                        }}
                        >
                          {subGroup.subGroupName}
                        </h4>
                      </Box>

                      <Box sx={{
                        display: 'flex', flexDirection: 'column', marginLeft: 2, gap: 0.5,
                      }}
                      >
                        {subGroup.permissions.map((permission:any) => (
                          <label style={{
                            color: permissionsError ? '#DA3237' : 'rgba(0, 0, 0, 0.87)', fontSize: 16, fontFamily: 'Lato', fontWeight: '700', wordWrap: 'break-word',
                          }}
                          >
                            <Checkbox
                              checked={permission.status}
                              style={{ color: permissionsError ? '#DA3237' : '', border: 'grey' }}
                              onChange={() => handleHeaderElementPermission(group.groupName, subGroup.subGroupName, permission.permissionName)}
                            />
                            {permission.displayName}
                          </label>
                        ))}
                      </Box>
                    </Grid>

                  ))}
                </Grid>
              </Box>

            </AccordionDetails>
          </div>
        </Accordion>
      ))}
    </Box>
  )
})
