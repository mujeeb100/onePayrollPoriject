import { Grid } from '@mui/material'
import OPRInputControl from 'components/molecules/OPRInputControl'
import OPRResponsiveGrid from 'components/molecules/OPRResponsiveGrid'
import OPRSelectorControl from 'components/molecules/OPRSelectorControl/OPRSelectorControl'

const defaultValues = {
  roleType: false, // Default to Regular User
}

export function UserInformation({
  errors, isEditable, values, handleChange, userList, handleOnChange,
}:any) {
  return (
    <div>
      <OPRResponsiveGrid styles={{ marginTop: 3 }}>
        <Grid item md={2} sm={1} xs={1}>
          <OPRInputControl
            error={errors?.roleCode}
            isEditable={isEditable}
            label="User role ID"
            name="roleCode"
            value={values?.roleCode}
            onChange={handleChange}
          />
          {/* <OPRSelectorControl
            error={errors?.status}
            keyName="roleCode"
            label="User Role ID"
            multiple={false}
            name="roleCode"
            options={userList}
            placeholder="Select an option"
            value={userList?.find((o:any) => o.roleCode === values?.roleCode) || null}
            valueKey="roleCode"
            onChange={(text:any) => {
              handleOnChange('roleCode', text?.roleCode || null)
            }}
          /> */}
        </Grid>
        <Grid item md={2} sm={1} xs={1}>
          <OPRInputControl
            error={errors?.roleName}
            isEditable={isEditable}
            label="User role name"
            name="roleName"
            value={values?.roleName}
            onChange={handleChange}
          />
        </Grid>

        <Grid item md={2} sm={1} xs={1}>
          {/* <OPRInputControl
            error={errors?.roleType}
            isEditable={isEditable}
            label="User role type"
            name="roleType"
            value={values?.roleType}
            onChange={handleChange}
          /> */}

          {/* changes role type with boolean value */}
          <OPRSelectorControl
            defaultValue={{ roleTypeName: 'Regular User', roleTypeValue: false }}
            error={errors?.roleType}
            isEditable={isEditable}
            keyName="roleTypeName"
            label="User role type"
            multiple={false}
            name="roleType"
            options={[
              { roleTypeName: 'System Admin', roleTypeValue: true },
              { roleTypeName: 'Regular User', roleTypeValue: false },
            ]}
            placeholder="Select an option"
            value={[
              { roleTypeName: 'System Admin', roleTypeValue: true },
              { roleTypeName: 'Regular User', roleTypeValue: false },
            ].find((o:any) => o?.roleTypeValue === values?.roleType)}
            valueKey="roleTypeName"
            onChange={(text:any) => {
              // handleChange({ target: { name: 'providerType', value: text?.providerTypeValue }, persist: () => {} })
              // setValues({ ...values, providerType: text })
              handleOnChange('roleType', text?.roleTypeValue)
            }}
          />
        </Grid>
        <Grid item md={2} sm={1} xs={1} />
        <Grid item md={4} sm={1} xs={1}>
          <OPRInputControl
            multiline
            error={errors?.remarks}
            isEditable={isEditable}
            label="Remarks"
            name="remarks"
            optionalText="Optional"
            rows={5}
            value={values?.remarks}
            onChange={handleChange}
          />
        </Grid>
      </OPRResponsiveGrid>
    </div>
  )
}
