import { Box } from '@mui/material'
import {
  useGetAllUserRoleQuery, useLazyGetUserRoleByIdQuery, useUserRoleCreateMutation, useUserRoleUpdateMutation,
} from 'api/identityServices'
import { LeftCaret, RighCaretBlue } from 'assets/svg-images/SvgComponents'
import OPRButton from 'components/atoms/button/OPRButton'
import OPRStepper from 'components/atoms/stepper'
import CancelAlert from 'components/molecules/OPRAlertControl/CancelAlert'
import OPRAlertControl from 'components/organism/OPRAlertControl'
import { OPRInnerFormLayout } from 'components/organism/OPRInnerFormLayout'
import { defaultPageSize } from 'constants/index'
import { validationUserRolesSchema } from 'constants/validate'
import { useEditable } from 'hooks/useEdit'
import useForm from 'hooks/useForm'
import { useEffect, useRef, useState } from 'react'
import { useTranslation } from 'react-i18next'
import { useLocation, useNavigate } from 'react-router-dom'
import { routes } from 'routes/routes'
import { generateFilterUrl, getParamsValue } from 'utils'

import rowData from './const'
import { PermissionManager } from './PermissionManager'
import { UserInformation } from './UserInformation'

interface MessageProps {
  text?: string
  important?: boolean
}

export default function UserRolesForm() {
  const initialState = {
    id: '',
    roleCode: '',
    roleName: '',
    roleType: '',
    remarks: '',
  }
  const myRef:any = useRef()
  const location: any = useLocation()
  const { id, viewUrl } = getParamsValue(location, routes.createUserRole)
  const [activeState, setActiveState] = useState(0)
  const { t } = useTranslation()
  const { isEditable, setEditable } = useEditable()
  const [isCancel, setCancel]:any = useState(false)
  const [permissionsError, setPermissionsError] = useState(false)
  const {
    values,
    setValues,
    errors,
    handleChange,
    setErrors,
    handleFormSubmit,
    handleOnChange,
  } = useForm(validationUserRolesSchema)

  const navigate = useNavigate()
  const [
    createUserRole,
    {
      data: createdUserRoleData,
      error: createdUserRoleError,
      isLoading: createdUserRoleLoading,
      isSuccess: createdUserRoleSuccess,
      isError: createdUserRoleIsError,
    },
  ] = useUserRoleCreateMutation()

  const {
    data: allUserRoles,
    error: createAllPostsBankAccountError,
    isLoading: isLoadingAllUserRoles,
    isSuccess: isSuccessAllPosts,
    isError: isErrorAllPosts,
    error: errorAllPosts,
  } = useGetAllUserRoleQuery(generateFilterUrl(defaultPageSize))

  const [
    updateUserRole,
    {
      data: updatedDataResponse,
      error: updatedUserRoleError,
      isLoading: updatedUserRoleLoading,
      isSuccess: updatedUserRoleSuccess,
      isError: updatedUserRoleIsError,
    },
  ] = useUserRoleUpdateMutation()

  const [
    updateUserRoleById,
    {
      data: updatedUserRoleByIdResponse,
      error: updatedUserRoleByIdError,
      isLoading: updatedUserRoleByIdLoading,
      isSuccess: updatedUserRoleByIdSuccess,
      isError: updatedUserRoleByIdIsError,
    },
  ] = useLazyGetUserRoleByIdQuery()
  const defaultValues = {
    roleType: false, // Default to Regular User
  }
  useEffect(() => {
    // Ensure default value is set if not already
    if (values?.roleType === undefined) {
      handleOnChange('roleType', defaultValues?.roleType)
    }
  }, [values, handleOnChange])
  useEffect(() => {
    if (id && updatedUserRoleByIdSuccess) {
      setValues(updatedUserRoleByIdResponse?.responseData)
    } else {
      setValues({})
      // setEditable(false)
    }
  }, [updatedUserRoleByIdSuccess])

  const handleSubmit: any = async () => {
    if (isEditable) {
      if (id === null) {
        await createUserRole({ ...values })
      } else {
        await updateUserRole(values)
      }
    } else {
      setEditable(true)
    }
  }
  useEffect(() => {
    if (id) {
      updateUserRoleById(id)
      setEditable(viewUrl)
    }
  }, [])

  // useEffect(() => {
  //   if (createdUserRoleSuccess) {
  //     // Reset form values after successful add operation
  //     // setValues({})
  //     // setErrors({})
  //   }
  // }, [createdUserRoleSuccess])

  const handlePermissionSubmit: any = async () => {
    // alert('dffdh')
    // if (activeState === 1) {
    //   setActiveState(activeState + 1)
    // } else {
    //   activeState === 2 ? myRef.current.childMethod() : myRef.current.checkPermissionValidation()
    // }
    activeState === 2 ? myRef.current.childMethod() : myRef.current.checkPermissionValidation()
    // myRef.current.childMethod()
  }

  useEffect(() => {
    const createdUserRoleSuccessStatus = createdUserRoleSuccess || false
    const updatedUserRoleSuccessStatus = updatedUserRoleSuccess || false
    if (createdUserRoleSuccessStatus || updatedUserRoleSuccessStatus) {
      if (activeState <= 1) {
        setActiveState(activeState + 1)
      }
    }
  }, [createdUserRoleSuccess, updatedUserRoleSuccess])

  return (
    <>
      <Box sx={{ display: 'flex' }}>
        <div
          style={{ display: 'flex', width: '100% ' }}
        // onSubmit={(e) => {
        //   activeState === 0 ? handleFormSubmit(e, handleSubmit) : handlePermissionSubmit()
        // }}
        >
          <CancelAlert
            callBack={() => {
              navigate(-1)
            }}
            handleCancel={() => {
              setCancel(false)
            }}
            isCancel={isCancel}
          />
          <OPRAlertControl
            error={createdUserRoleError || updatedUserRoleByIdError}
            handleEditable={setEditable}
            handleSetValue={setValues}
            handleSubmit={handleSubmit}
            isError={createdUserRoleIsError || updatedUserRoleIsError}
            isLoading={createdUserRoleLoading || updatedUserRoleLoading || updatedUserRoleByIdLoading}
            isSuccess={false}
            name={values?.roleName}
            title="User roles"
            type={id ? 'Update' : 'New'}
            // previousUrl="/user-roles-listing"

          />
          <OPRInnerFormLayout
            isHandleContinueClick
            // customHeader={(
            //   <OPRLabel label="Add User Role" variant="h2" />
            // )}
            isStepper
            error={createdUserRoleError || updatedUserRoleError}
            handleBack={() => {
              if (activeState === 0) {
                setEditable(!isEditable)
              } else {
                setActiveState(activeState - 1)
              }
            }}
            handleCancelClick={() => navigate(-1)}
            handleContinueClick={(e:any) => {
              if (activeState === 0) {
                handleFormSubmit(e, handleSubmit)
                return
              }
              if (activeState === 2 || activeState === 1) {
                handlePermissionSubmit()
                return
              }
              setActiveState(activeState + 1)
            // activeState === 2 ? handlePermissionSubmit : handleFormSubmit(e, handleSubmit)
            }}
            handleEditable={setEditable}
            isBackButton={isEditable}
            isConfirm={activeState === 2}
            isLoading={createdUserRoleLoading || updatedUserRoleLoading || updatedUserRoleByIdLoading}
            pageType="detailsPage"
            previousPageUrl={routes.userRolesListing}
            subtitle={
              isEditable
                ? 'Please check the user details below.'
                : 'All field to mandatory expect those mark optional'
            }
            title={id ? values?.roleName : 'User role'}
          >
            <Box>
              <OPRStepper
                activeStep={activeState}
                steps={[
                  t('userRoles_progress_step_user_role_information'),
                  t('userRoles_progress_step_access_matrix'),
                  t('userRoles_progress_step_confirmation'),
                ]}
              />
              {activeState === 0 && (
                <UserInformation
                  errors={errors}
                  handleChange={handleChange}
                  handleOnChange={handleOnChange}
                  isEditable={isEditable}
                  userList={JSON.parse(JSON.stringify(allUserRoles?.data || []))}
                  values={values}
                />
              )}
              {activeState === 2 && (
                <>
                  <UserInformation
                    errors={errors}
                    handleOnChange={handleOnChange}
                    isEditable={isEditable}
                    userList={rowData}
                    values={values}

                  // handleChange={handleChange}
                  />
                  {/* <PermissionManager
                  ref={myRef}
                  initialPermissions={rowData || []}
                  roleCode={values}
                /> */}
                </>
              )}
              {(activeState === 1 || activeState === 2) && (
                <PermissionManager
                  ref={myRef}
                  activeState={activeState}
                  callBackHandler={() => {
                    setEditable(false)
                    setActiveState(0)
                  }}
                  id={id}
                  initialPermissions={rowData || []}
                  permissionsError={permissionsError}
                  roleCode={values?.roleCode}
                  roleName={values?.roleName}
                  roleType={values?.roleType}
                  setActiveState={setActiveState}
                  setPermissionsError={setPermissionsError}
                />
              )}

            </Box>
          </OPRInnerFormLayout>

        </div>
      </Box>
      {viewUrl && (
        <Box sx={{
          display: 'flex', alignItems: 'center', flexDirection: 'row', justifyContent: 'space-between', mt: 6,
        }}
        >
          <OPRButton color="info" variant="text" onClick={() => setCancel(true)}>
            Cancel
          </OPRButton>

          <>
            {activeState === 0 ? null : (
              <OPRButton
                style={{ marginLeft: 'auto' }}
                variant="text"
                onClick={() => {
                  if (activeState > 0) {
                    setActiveState(activeState - 1)
                  }
                }}
              >
                <RighCaretBlue />
                Back
              </OPRButton>
            )}
            {activeState === 2 ? null : (
              <OPRButton
                handleClick={() => {
                  setActiveState(activeState + 1)
                }}
                type="submit"
                variant="contained"
              >
                {activeState === 3 ? 'Confirm' : 'Continue'}
                <LeftCaret />
              </OPRButton>
            )}
          </>
        </Box>
      )}
    </>
  )
}
