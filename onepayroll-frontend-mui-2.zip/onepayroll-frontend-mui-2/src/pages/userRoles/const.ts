const rowData = [
  {
    groupName: 'Global Settings',
    subGroups: [
      {
        subGroupName: 'Country Settings',
        permissions: [
          {
            permissionCode: 1001,
            permissionName: 'Country_Create',
            displayName: 'Add',
            status: false,
          },
          {
            permissionCode: 1002,
            permissionName: 'Country_View',
            displayName: 'View',
            status: false,
          },
          {
            permissionCode: 1003,
            permissionName: 'Country_Update',
            displayName: 'Edit',
            status: false,
          },
          {
            permissionCode: 1004,
            permissionName: 'Country_Delete',
            displayName: 'Delete',
            status: false,
          },
        ],
      },
      {
        subGroupName: 'Currency Settings',
        permissions: [
          {
            permissionCode: 1005,
            permissionName: 'Currency_Create',
            displayName: 'Add',
            status: false,
          },
          {
            permissionCode: 1006,
            permissionName: 'Currency_View',
            displayName: 'View',
            status: false,
          },
          {
            permissionCode: 1007,
            permissionName: 'Currency_Update',
            displayName: 'Edit',
            status: false,
          },
          {
            permissionCode: 1008,
            permissionName: 'Currency_Delete',
            displayName: 'Delete',
            status: false,
          },
        ],
      },
      {
        subGroupName: 'HolidayCalendar Settings',
        permissions: [
          {
            permissionCode: 1009,
            permissionName: 'HolidayCalendar_Create',
            displayName: 'Add',
            status: false,
          },
          {
            permissionCode: 1010,
            permissionName: 'HolidayCalendar_View',
            displayName: 'View',
            status: false,
          },
          {
            permissionCode: 1011,
            permissionName: 'HolidayCalendar_Update',
            displayName: 'Edit',
            status: false,
          },
          {
            permissionCode: 1012,
            permissionName: 'HolidayCalendar_Delete',
            displayName: 'Delete',
            status: false,
          },
        ],
      },
      {
        subGroupName: 'HolidayDate Settings',
        permissions: [
          {
            permissionCode: 1013,
            permissionName: 'HolidayDate_Create',
            displayName: 'Add',
            status: false,
          },
          {
            permissionCode: 1014,
            permissionName: 'HolidayDate_View',
            displayName: 'View',
            status: false,
          },
          {
            permissionCode: 1015,
            permissionName: 'HolidayDate_Update',
            displayName: 'Edit',
            status: false,
          },
          {
            permissionCode: 1016,
            permissionName: 'HolidayDate_Delete',
            displayName: 'Delete',
            status: false,
          },
        ],
      },
      {
        subGroupName: 'Nationality Settings',
        permissions: [
          {
            permissionCode: 1017,
            permissionName: 'Nationality_Create',
            displayName: 'Add',
            status: false,
          },
          {
            permissionCode: 1018,
            permissionName: 'Nationality_View',
            displayName: 'View',
            status: false,
          },
          {
            permissionCode: 1019,
            permissionName: 'Nationality_Update',
            displayName: 'Edit',
            status: false,
          },
          {
            permissionCode: 1020,
            permissionName: 'Nationality_Delete',
            displayName: 'Delete',
            status: false,
          },
        ],
      },
      {
        subGroupName: 'PaymentMethod Settings',
        permissions: [
          {
            permissionCode: 1021,
            permissionName: 'PaymentMethod_Create',
            displayName: 'Add',
            status: false,
          },
          {
            permissionCode: 1022,
            permissionName: 'PaymentMethod_View',
            displayName: 'View',
            status: false,
          },
          {
            permissionCode: 1023,
            permissionName: 'PaymentMethod_Update',
            displayName: 'Edit',
            status: false,
          },
          {
            permissionCode: 1024,
            permissionName: 'PaymentMethod_Delete',
            displayName: 'Delete',
            status: false,
          },
        ],
      },
      {
        subGroupName: 'PensionFundSchemeRule Settings',
        permissions: [
          {
            permissionCode: 1025,
            permissionName: 'PensionFundSchemeRule_Create',
            displayName: 'Add',
            status: false,
          },
          {
            permissionCode: 1026,
            permissionName: 'PensionFundSchemeRule_View',
            displayName: 'View',
            status: false,
          },
          {
            permissionCode: 1027,
            permissionName: 'PensionFundSchemeRule_Update',
            displayName: 'Edit',
            status: false,
          },
          {
            permissionCode: 1028,
            permissionName: 'PensionFundSchemeRule_Delete',
            displayName: 'Delete',
            status: false,
          },
        ],
      },
      {
        subGroupName: 'PensionFundTerminationCode Settings',
        permissions: [
          {
            permissionCode: 1029,
            permissionName: 'PensionFundTerminationCode_Create',
            displayName: 'Add',
            status: false,
          },
          {
            permissionCode: 1030,
            permissionName: 'PensionFundTerminationCode_View',
            displayName: 'View',
            status: false,
          },
          {
            permissionCode: 1031,
            permissionName: 'PensionFundTerminationCode_Update',
            displayName: 'Edit',
            status: false,
          },
          {
            permissionCode: 1032,
            permissionName: 'PensionFundTerminationCode_Delete',
            displayName: 'Delete',
            status: false,
          },
        ],
      },
      {
        subGroupName: 'ProviderType Settings',
        permissions: [
          {
            permissionCode: 1033,
            permissionName: 'ProviderType_Create',
            displayName: 'Add',
            status: false,
          },
          {
            permissionCode: 1034,
            permissionName: 'ProviderType_View',
            displayName: 'View',
            status: false,
          },
          {
            permissionCode: 1035,
            permissionName: 'ProviderType_Update',
            displayName: 'Edit',
            status: false,
          },
          {
            permissionCode: 1036,
            permissionName: 'ProviderType_Delete',
            displayName: 'Delete',
            status: false,
          },
        ],
      },
      {
        subGroupName: 'SettingTemplate Settings',
        permissions: [
          {
            permissionCode: 1037,
            permissionName: 'SettingTemplate_Create',
            displayName: 'Add',
            status: false,
          },
          {
            permissionCode: 1038,
            permissionName: 'SettingTemplate_View',
            displayName: 'View',
            status: false,
          },
          {
            permissionCode: 1039,
            permissionName: 'SettingTemplate_Update',
            displayName: 'Edit',
            status: false,
          },
          {
            permissionCode: 1040,
            permissionName: 'SettingTemplate_Delete',
            displayName: 'Delete',
            status: false,
          },
        ],
      },
      {
        subGroupName: 'PayCycleStatus Settings',
        permissions: [
          {
            permissionCode: 1490,
            permissionName: 'PayCycleStatus_Create',
            displayName: 'Add',
            status: false,
          },
          {
            permissionCode: 1491,
            permissionName: 'PayCycleStatus_Delete',
            displayName: 'Delete',
            status: false,
          },
          {
            permissionCode: 1492,
            permissionName: 'PayCycleStatus_Update',
            displayName: 'Edit',
            status: false,
          },
        ],
      },
      {
        subGroupName: 'PayType Settings',
        permissions: [
          {
            permissionCode: 1493,
            permissionName: 'PayType_Create',
            displayName: 'Add',
            status: false,
          },
          {
            permissionCode: 1494,
            permissionName: 'PayType_Delete',
            displayName: 'Delete',
            status: false,
          },
          {
            permissionCode: 1495,
            permissionName: 'PayType_Update',
            displayName: 'Edit',
            status: false,
          },
        ],
      },
    ],
  },
  {
    groupName: 'EmployeeService',
    subGroups: [
      {
        subGroupName: 'EmployeeAverageWage Settings',
        permissions: [
          {
            permissionCode: 1101,
            permissionName: 'EmployeeAverageWage_Create',
            displayName: 'Add',
            status: false,
          },
          {
            permissionCode: 1102,
            permissionName: 'EmployeeAverageWage_View',
            displayName: 'View',
            status: false,
          },
          {
            permissionCode: 1103,
            permissionName: 'EmployeeAverageWage_Update',
            displayName: 'Edit',
            status: false,
          },
          {
            permissionCode: 1104,
            permissionName: 'EmployeeAverageWage_Delete',
            displayName: 'Delete',
            status: false,
          },
        ],
      },
      {
        subGroupName: 'EmployeeBankAccount Settings',
        permissions: [
          {
            permissionCode: 1105,
            permissionName: 'EmployeeBankAccount_Create',
            displayName: 'Add',
            status: false,
          },
          {
            permissionCode: 1106,
            permissionName: 'EmployeeBankAccount_View',
            displayName: 'View',
            status: false,
          },
          {
            permissionCode: 1107,
            permissionName: 'EmployeeBankAccount_Update',
            displayName: 'Edit',
            status: false,
          },
          {
            permissionCode: 1108,
            permissionName: 'EmployeeBankAccount_Delete',
            displayName: 'Delete',
            status: false,
          },
        ],
      },
      {
        subGroupName: 'EmployeeMovement Settings',
        permissions: [
          {
            permissionCode: 1109,
            permissionName: 'EmployeeMovement_Create',
            displayName: 'Add',
            status: false,
          },
          {
            permissionCode: 1110,
            permissionName: 'EmployeeMovement_View',
            displayName: 'View',
            status: false,
          },
          {
            permissionCode: 1111,
            permissionName: 'EmployeeMovement_Update',
            displayName: 'Edit',
            status: false,
          },
          {
            permissionCode: 1112,
            permissionName: 'EmployeeMovement_Delete',
            displayName: 'Delete',
            status: false,
          },
        ],
      },
      {
        subGroupName: 'EmployeePensionFund Settings',
        permissions: [
          {
            permissionCode: 1113,
            permissionName: 'EmployeePensionFund_Create',
            displayName: 'Add',
            status: false,
          },
          {
            permissionCode: 1114,
            permissionName: 'EmployeePensionFund_View',
            displayName: 'View',
            status: false,
          },
          {
            permissionCode: 1115,
            permissionName: 'EmployeePensionFund_Update',
            displayName: 'Edit',
            status: false,
          },
          {
            permissionCode: 1116,
            permissionName: 'EmployeePensionFund_Delete',
            displayName: 'Delete',
            status: false,
          },
        ],
      },
      {
        subGroupName: 'EmployeeQuarters Settings',
        permissions: [
          {
            permissionCode: 1117,
            permissionName: 'EmployeeQuarters_Create',
            displayName: 'Add',
            status: false,
          },
          {
            permissionCode: 1118,
            permissionName: 'EmployeeQuarters_View',
            displayName: 'View',
            status: false,
          },
          {
            permissionCode: 1119,
            permissionName: 'EmployeeQuarters_Update',
            displayName: 'Edit',
            status: false,
          },
          {
            permissionCode: 1120,
            permissionName: 'EmployeeQuarters_Delete',
            displayName: 'Delete',
            status: false,
          },
        ],
      },
      {
        subGroupName: 'EmployeeSnapshot Settings',
        permissions: [
          {
            permissionCode: 1121,
            permissionName: 'EmployeeSnapshot_Create',
            displayName: 'Add',
            status: false,
          },
          {
            permissionCode: 1122,
            permissionName: 'EmployeeSnapshot_View',
            displayName: 'View',
            status: false,
          },
          {
            permissionCode: 1123,
            permissionName: 'EmployeeSnapshot_Update',
            displayName: 'Edit',
            status: false,
          },
          {
            permissionCode: 1124,
            permissionName: 'EmployeeSnapshot_Delete',
            displayName: 'Delete',
            status: false,
          },
        ],
      },
      {
        subGroupName: 'Person Settings',
        permissions: [
          {
            permissionCode: 1125,
            permissionName: 'Person_Create',
            displayName: 'Add',
            status: false,
          },
          {
            permissionCode: 1126,
            permissionName: 'Person_View',
            displayName: 'View',
            status: false,
          },
          {
            permissionCode: 1127,
            permissionName: 'Person_Update',
            displayName: 'Edit',
            status: false,
          },
          {
            permissionCode: 1128,
            permissionName: 'Person_Delete',
            displayName: 'Delete',
            status: false,
          },
        ],
      },
    ],
  },
  {
    groupName: 'ClientGroup Settings',
    subGroups: [
      {
        subGroupName: 'ClientGroupProfile Settings',
        permissions: [
          {
            permissionCode: 1201,
            permissionName: 'ClientGroupProfile_Create',
            displayName: 'Add',
            status: false,
          },
          {
            permissionCode: 1202,
            permissionName: 'ClientGroupProfile_View',
            displayName: 'View',
            status: false,
          },
          {
            permissionCode: 1203,
            permissionName: 'ClientGroupProfile_Update',
            displayName: 'Edit',
            status: false,
          },
          {
            permissionCode: 1204,
            permissionName: 'ClientGroupProfile_Delete',
            displayName: 'Delete',
            status: false,
          },
          {
            permissionCode: 1205,
            permissionName: 'ClientGroupProfile_ChangeStatus',
            displayName: '',
            status: false,
          },
        ],
      },
    ],
  },
  {
    groupName: 'ClientEntity Settings',
    subGroups: [
      {
        subGroupName: 'ClientGroupEntity Settings',
        permissions: [
          {
            permissionCode: 1206,
            permissionName: 'ClientGroupEntity_Create',
            displayName: 'Add',
            status: false,
          },
          {
            permissionCode: 1207,
            permissionName: 'ClientGroupEntity_View',
            displayName: 'View',
            status: false,
          },
          {
            permissionCode: 1208,
            permissionName: 'ClientGroupEntity_Update',
            displayName: 'Edit',
            status: false,
          },
          {
            permissionCode: 1209,
            permissionName: 'ClientGroupEntity_Delete',
            displayName: 'Delete',
            status: false,
          },
          {
            permissionCode: 1210,
            permissionName: 'ClientGroupEntity_ChangeStatus',
            displayName: '',
            status: false,
          },
        ],
      },
    ],
  },
  {
    groupName: '',
    subGroups: [
      {
        subGroupName: 'Authorization Settings',
        permissions: [
          {
            permissionCode: 1301,
            permissionName: 'Authorization_CheckPermission',
            displayName: '',
            status: false,
          },
        ],
      },
    ],
  },
  {
    groupName: 'UserAdministratio',
    subGroups: [
      {
        subGroupName: 'UserAdministration Settings',
        permissions: [
          {
            permissionCode: 1302,
            permissionName: 'UserAdministration_Create',
            displayName: 'Add',
            status: false,
          },
          {
            permissionCode: 1303,
            permissionName: 'UserAdministration_View',
            displayName: 'View',
            status: false,
          },
          {
            permissionCode: 1304,
            permissionName: 'UserAdministration_Update',
            displayName: 'Edit',
            status: false,
          },
          {
            permissionCode: 1305,
            permissionName: 'UserAdministration_Delete',
            displayName: 'Delete',
            status: false,
          },
        ],
      },
      {
        subGroupName: 'UserRole Settings',
        permissions: [
          {
            permissionCode: 1306,
            permissionName: 'UserRole_Create',
            displayName: 'Add',
            status: false,
          },
          {
            permissionCode: 1307,
            permissionName: 'UserRole_View',
            displayName: 'View',
            status: false,
          },
          {
            permissionCode: 1308,
            permissionName: 'UserRole_Update',
            displayName: 'Edit',
            status: false,
          },
          {
            permissionCode: 1309,
            permissionName: 'UserRole_Delete',
            displayName: 'Delete',
            status: false,
          },
        ],
      },
      {
        subGroupName: 'UserPermission Settings',
        permissions: [
          {
            permissionCode: 1310,
            permissionName: 'UserPermission_Create',
            displayName: 'Add',
            status: false,
          },
          {
            permissionCode: 1311,
            permissionName: 'UserPermission_View',
            displayName: 'View',
            status: false,
          },
          {
            permissionCode: 1312,
            permissionName: 'UserPermission_Update',
            displayName: 'Edit',
            status: false,
          },
          {
            permissionCode: 1313,
            permissionName: 'UserPermission_Delete',
            displayName: 'Delete',
            status: false,
          },
        ],
      },
      {
        subGroupName: 'UserRolePermission Settings',
        permissions: [
          {
            permissionCode: 1314,
            permissionName: 'UserRolePermission_CreateOrUpdate',
            displayName: 'Add',
            status: false,
          },
          {
            permissionCode: 1315,
            permissionName: 'UserRolePermission_View',
            displayName: 'View',
            status: false,
          },
          {
            permissionCode: 1316,
            permissionName: 'UserRolePermission_Delete',
            displayName: 'Delete',
            status: false,
          },
        ],
      },
      {
        subGroupName: 'UserAdmin Settings',
        permissions: [
          {
            permissionCode: 1317,
            permissionName: 'UserAdmin_Create',
            displayName: 'Add',
            status: false,
          },
          {
            permissionCode: 1318,
            permissionName: 'UserAdmin_View',
            displayName: 'View',
            status: false,
          },
          {
            permissionCode: 1319,
            permissionName: 'UserAdmin_Update',
            displayName: 'Edit',
            status: false,
          },
          {
            permissionCode: 1320,
            permissionName: 'UserAdmin_Delete',
            displayName: 'Delete',
            status: false,
          },
          {
            permissionCode: 1321,
            permissionName: 'UserAdmin_CreateBulk',
            displayName: 'Add',
            status: false,
          },
        ],
      },
    ],
  },
  {
    groupName: 'Entity management',
    subGroups: [
      {
        subGroupName: 'Entity_CompanyBankAccount Settings',
        permissions: [
          {
            permissionCode: 1401,
            permissionName: 'Entity_CompanyBankAccount_Create',
            displayName: 'Add',
            status: false,
          },
          {
            permissionCode: 1402,
            permissionName: 'Entity_CompanyBankAccount_View',
            displayName: 'View',
            status: false,
          },
          {
            permissionCode: 1403,
            permissionName: 'Entity_CompanyBankAccount_Update',
            displayName: 'Edit',
            status: false,
          },
          {
            permissionCode: 1404,
            permissionName: 'Entity_CompanyBankAccount_Delete',
            displayName: 'Delete',
            status: false,
          },
        ],
      },
      {
        subGroupName: 'Entity_CostCenter Settings',
        permissions: [
          {
            permissionCode: 1405,
            permissionName: 'Entity_CostCenter_Create',
            displayName: 'Add',
            status: false,
          },
          {
            permissionCode: 1406,
            permissionName: 'Entity_CostCenter_View',
            displayName: 'View',
            status: false,
          },
          {
            permissionCode: 1407,
            permissionName: 'Entity_CostCenter_Update',
            displayName: 'Edit',
            status: false,
          },
          {
            permissionCode: 1408,
            permissionName: 'Entity_CostCenter_Delete',
            displayName: 'Delete',
            status: false,
          },
        ],
      },
      {
        subGroupName: 'Entity_CurrencyExchange Settings',
        permissions: [
          {
            permissionCode: 1409,
            permissionName: 'Entity_CurrencyExchange_Create',
            displayName: 'Add',
            status: false,
          },
          {
            permissionCode: 1410,
            permissionName: 'Entity_CurrencyExchange_View',
            displayName: 'View',
            status: false,
          },
          {
            permissionCode: 1411,
            permissionName: 'Entity_CurrencyExchange_Update',
            displayName: 'Edit',
            status: false,
          },
          {
            permissionCode: 1412,
            permissionName: 'Entity_CurrencyExchange_Delete',
            displayName: 'Delete',
            status: false,
          },
        ],
      },
      {
        subGroupName: 'Entity_Department Settings',
        permissions: [
          {
            permissionCode: 1413,
            permissionName: 'Entity_Department_Create',
            displayName: 'Add',
            status: false,
          },
          {
            permissionCode: 1414,
            permissionName: 'Entity_Department_View',
            displayName: 'View',
            status: false,
          },
          {
            permissionCode: 1415,
            permissionName: 'Entity_Department_Update',
            displayName: 'Edit',
            status: false,
          },
          {
            permissionCode: 1416,
            permissionName: 'Entity_Department_Delete',
            displayName: 'Delete',
            status: false,
          },
        ],
      },
      {
        subGroupName: 'Entity_Division Settings',
        permissions: [
          {
            permissionCode: 1417,
            permissionName: 'Entity_Division_Create',
            displayName: 'Add',
            status: false,
          },
          {
            permissionCode: 1418,
            permissionName: 'Entity_Division_View',
            displayName: 'View',
            status: false,
          },
          {
            permissionCode: 1419,
            permissionName: 'Entity_Division_Update',
            displayName: 'Edit',
            status: false,
          },
          {
            permissionCode: 1420,
            permissionName: 'Entity_Division_Delete',
            displayName: 'Delete',
            status: false,
          },
        ],
      },
      {
        subGroupName: 'Entity_EmployeeMovementConfiguration Settings',
        permissions: [
          {
            permissionCode: 1421,
            permissionName: 'Entity_EmployeeMovementConfiguration_Create',
            displayName: 'Add',
            status: false,
          },
          {
            permissionCode: 1422,
            permissionName: 'Entity_EmployeeMovementConfiguration_View',
            displayName: 'View',
            status: false,
          },
          {
            permissionCode: 1423,
            permissionName: 'Entity_EmployeeMovementConfiguration_Update',
            displayName: 'Edit',
            status: false,
          },
          {
            permissionCode: 1424,
            permissionName: 'Entity_EmployeeMovementConfiguration_Delete',
            displayName: 'Delete',
            status: false,
          },
        ],
      },
      {
        subGroupName: 'Entity_EmployeeMovements Settings',
        permissions: [
          {
            permissionCode: 1425,
            permissionName: 'Entity_EmployeeMovements_Create',
            displayName: 'Add',
            status: false,
          },
          {
            permissionCode: 1426,
            permissionName: 'Entity_EmployeeMovements_View',
            displayName: 'View',
            status: false,
          },
          {
            permissionCode: 1427,
            permissionName: 'Entity_EmployeeMovements_Update',
            displayName: 'Edit',
            status: false,
          },
          {
            permissionCode: 1428,
            permissionName: 'Entity_EmployeeMovements_Delete',
            displayName: 'Delete',
            status: false,
          },
        ],
      },
      {
        subGroupName: 'Entity_EmployeeMovementType Settings',
        permissions: [
          {
            permissionCode: 1429,
            permissionName: 'Entity_EmployeeMovementType_Create',
            displayName: 'Add',
            status: false,
          },
          {
            permissionCode: 1430,
            permissionName: 'Entity_EmployeeMovementType_View',
            displayName: 'View',
            status: false,
          },
          {
            permissionCode: 1431,
            permissionName: 'Entity_EmployeeMovementType_Update',
            displayName: 'Edit',
            status: false,
          },
          {
            permissionCode: 1432,
            permissionName: 'Entity_EmployeeMovementType_Delete',
            displayName: 'Delete',
            status: false,
          },
        ],
      },
      {
        subGroupName: 'Entity_EntityProfile Settings',
        permissions: [
          {
            permissionCode: 1433,
            permissionName: 'Entity_EntityProfile_Create',
            displayName: 'Add',
            status: false,
          },
          {
            permissionCode: 1434,
            permissionName: 'Entity_EntityProfile_View',
            displayName: 'View',
            status: false,
          },
          {
            permissionCode: 1435,
            permissionName: 'Entity_EntityProfile_Update',
            displayName: 'Edit',
            status: false,
          },
          {
            permissionCode: 1436,
            permissionName: 'Entity_EntityProfile_Delete',
            displayName: 'Delete',
            status: false,
          },
        ],
      },
      {
        subGroupName: 'Entity_EntitySettings Settings',
        permissions: [
          {
            permissionCode: 1437,
            permissionName: 'Entity_EntitySettings_Create',
            displayName: 'Add',
            status: false,
          },
          {
            permissionCode: 1438,
            permissionName: 'Entity_EntitySettings_View',
            displayName: 'View',
            status: false,
          },
          {
            permissionCode: 1439,
            permissionName: 'Entity_EntitySettings_Update',
            displayName: 'Edit',
            status: false,
          },
          {
            permissionCode: 1440,
            permissionName: 'Entity_EntitySettings_Delete',
            displayName: 'Delete',
            status: false,
          },
        ],
      },
      {
        subGroupName: 'Entity_Grade Settings',
        permissions: [
          {
            permissionCode: 1441,
            permissionName: 'Entity_Grade_Create',
            displayName: 'Add',
            status: false,
          },
          {
            permissionCode: 1442,
            permissionName: 'Entity_Grade_View',
            displayName: 'View',
            status: false,
          },
          {
            permissionCode: 1443,
            permissionName: 'Entity_Grade_Update',
            displayName: 'Edit',
            status: false,
          },
          {
            permissionCode: 1444,
            permissionName: 'Entity_Grade_Delete',
            displayName: 'Delete',
            status: false,
          },
        ],
      },
      {
        subGroupName: 'Entity_IRDCorporateTitle Settings',
        permissions: [
          {
            permissionCode: 1445,
            permissionName: 'Entity_IRDCorporateTitle_Create',
            displayName: 'Add',
            status: false,
          },
          {
            permissionCode: 1446,
            permissionName: 'Entity_IRDCorporateTitle_View',
            displayName: 'View',
            status: false,
          },
          {
            permissionCode: 1447,
            permissionName: 'Entity_IRDCorporateTitle_Update',
            displayName: 'Edit',
            status: false,
          },
          {
            permissionCode: 1448,
            permissionName: 'Entity_IRDCorporateTitle_Delete',
            displayName: 'Delete',
            status: false,
          },
        ],
      },
      {
        subGroupName: 'Entity_PensionFundScheme Settings',
        permissions: [
          {
            permissionCode: 1449,
            permissionName: 'Entity_PensionFundScheme_Create',
            displayName: 'Add',
            status: false,
          },
          {
            permissionCode: 1450,
            permissionName: 'Entity_PensionFundScheme_View',
            displayName: 'View',
            status: false,
          },
          {
            permissionCode: 1451,
            permissionName: 'Entity_PensionFundScheme_Update',
            displayName: 'Edit',
            status: false,
          },
          {
            permissionCode: 1452,
            permissionName: 'Entity_PensionFundScheme_Delete',
            displayName: 'Delete',
            status: false,
          },
        ],
      },
      {
        subGroupName: 'Entity_PensionFundSchemeItem Settings',
        permissions: [
          {
            permissionCode: 1454,
            permissionName: 'Entity_PensionFundSchemeItem_Create',
            displayName: 'Add',
            status: false,
          },
          {
            permissionCode: 1455,
            permissionName: 'Entity_PensionFundSchemeItem_View',
            displayName: 'View',
            status: false,
          },
          {
            permissionCode: 1456,
            permissionName: 'Entity_PensionFundSchemeItem_Update',
            displayName: 'Edit',
            status: false,
          },
          {
            permissionCode: 1457,
            permissionName: 'Entity_PensionFundSchemeItem_Delete',
            displayName: 'Delete',
            status: false,
          },
        ],
      },
      {
        subGroupName: 'Entity_PensionFundSchemeRule Settings',
        permissions: [
          {
            permissionCode: 1458,
            permissionName: 'Entity_PensionFundSchemeRule_Create',
            displayName: 'Add',
            status: false,
          },
          {
            permissionCode: 1459,
            permissionName: 'Entity_PensionFundSchemeRule_View',
            displayName: 'View',
            status: false,
          },
          {
            permissionCode: 1460,
            permissionName: 'Entity_PensionFundSchemeRule_Update',
            displayName: 'Edit',
            status: false,
          },
          {
            permissionCode: 1461,
            permissionName: 'Entity_PensionFundSchemeRule_Delete',
            displayName: 'Delete',
            status: false,
          },
        ],
      },
      {
        subGroupName: 'Entity_Position Settings',
        permissions: [
          {
            permissionCode: 1462,
            permissionName: 'Entity_Position_Create',
            displayName: 'Add',
            status: false,
          },
          {
            permissionCode: 1463,
            permissionName: 'Entity_Position_View',
            displayName: 'View',
            status: false,
          },
          {
            permissionCode: 1464,
            permissionName: 'Entity_Position_Update',
            displayName: 'Edit',
            status: false,
          },
          {
            permissionCode: 1465,
            permissionName: 'Entity_Position_Delete',
            displayName: 'Delete',
            status: false,
          },
        ],
      },
      {
        subGroupName: 'Entity_Region Settings',
        permissions: [
          {
            permissionCode: 1466,
            permissionName: 'Entity_Region_Create',
            displayName: 'Add',
            status: false,
          },
          {
            permissionCode: 1467,
            permissionName: 'Entity_Region_View',
            displayName: 'View',
            status: false,
          },
          {
            permissionCode: 1468,
            permissionName: 'Entity_Region_Update',
            displayName: 'Edit',
            status: false,
          },
          {
            permissionCode: 1469,
            permissionName: 'Entity_Region_Delete',
            displayName: 'Delete',
            status: false,
          },
        ],
      },
      {
        subGroupName: 'Entity_ServiceProvider Settings',
        permissions: [
          {
            permissionCode: 1470,
            permissionName: 'Entity_ServiceProvider_Create',
            displayName: 'Add',
            status: false,
          },
          {
            permissionCode: 1471,
            permissionName: 'Entity_ServiceProvider_View',
            displayName: 'View',
            status: false,
          },
          {
            permissionCode: 1472,
            permissionName: 'Entity_ServiceProvider_Update',
            displayName: 'Edit',
            status: false,
          },
          {
            permissionCode: 1473,
            permissionName: 'Entity_ServiceProvider_Delete',
            displayName: 'Delete',
            status: false,
          },
        ],
      },
      {
        subGroupName: 'Entity_StaffType Settings',
        permissions: [
          {
            permissionCode: 1474,
            permissionName: 'Entity_StaffType_Create',
            displayName: 'Add',
            status: false,
          },
          {
            permissionCode: 1475,
            permissionName: 'Entity_StaffType_View',
            displayName: 'View',
            status: false,
          },
          {
            permissionCode: 1476,
            permissionName: 'Entity_StaffType_Update',
            displayName: 'Edit',
            status: false,
          },
          {
            permissionCode: 1477,
            permissionName: 'Entity_StaffType_Delete',
            displayName: 'Delete',
            status: false,
          },
        ],
      },
      {
        subGroupName: 'Entity_Team Settings',
        permissions: [
          {
            permissionCode: 1478,
            permissionName: 'Entity_Team_Create',
            displayName: 'Add',
            status: false,
          },
          {
            permissionCode: 1479,
            permissionName: 'Entity_Team_View',
            displayName: 'View',
            status: false,
          },
          {
            permissionCode: 1480,
            permissionName: 'Entity_Team_Update',
            displayName: 'Edit',
            status: false,
          },
          {
            permissionCode: 1481,
            permissionName: 'Entity_Team_Delete',
            displayName: 'Delete',
            status: false,
          },
        ],
      },
      {
        subGroupName: 'Entity_TerminationCode Settings',
        permissions: [
          {
            permissionCode: 1482,
            permissionName: 'Entity_TerminationCode_Create',
            displayName: 'Add',
            status: false,
          },
          {
            permissionCode: 1483,
            permissionName: 'Entity_TerminationCode_View',
            displayName: 'View',
            status: false,
          },
          {
            permissionCode: 1484,
            permissionName: 'Entity_TerminationCode_Update',
            displayName: 'Edit',
            status: false,
          },
          {
            permissionCode: 1485,
            permissionName: 'Entity_TerminationCode_Delete',
            displayName: 'Delete',
            status: false,
          },
        ],
      },
      {
        subGroupName: 'Entity_WorkCalendar Settings',
        permissions: [
          {
            permissionCode: 1486,
            permissionName: 'Entity_WorkCalendar_Create',
            displayName: 'Add',
            status: false,
          },
          {
            permissionCode: 1487,
            permissionName: 'Entity_WorkCalendar_View',
            displayName: 'View',
            status: false,
          },
          {
            permissionCode: 1488,
            permissionName: 'Entity_WorkCalendar_Update',
            displayName: 'Edit',
            status: false,
          },
          {
            permissionCode: 1489,
            permissionName: 'Entity_WorkCalendar_Delete',
            displayName: 'Delete',
            status: false,
          },
        ],
      },
    ],
  },
  {
    groupName: 'IntegrationService',
    subGroups: [
      {
        subGroupName: 'Integration',
        permissions: [
          {
            permissionCode: 1601,
            permissionName: 'Integration_Integration_Create',
            displayName: 'Add',
            status: false,
          },
          {
            permissionCode: 1602,
            permissionName: 'Integration_Integration_View',
            displayName: 'View',
            status: false,
          },
          {
            permissionCode: 1603,
            permissionName: 'Integration_Integration_Update',
            displayName: 'Update',
            status: false,
          },
          {
            permissionCode: 1604,
            permissionName: 'Integration_Integration_Delete',
            displayName: 'Delete',
            status: false,
          },
          {
            permissionCode: 1605,
            permissionName: 'Integration_Integration_Download',
            displayName: 'Download',
            status: false,
          },
          {
            permissionCode: 1606,
            permissionName: 'Integration_Integration_Upload',
            displayName: 'Upload',
            status: false,
          },
        ],
      },
    ],
  },
  {
    groupName: 'ReportingService',
    subGroups: [
      {
        subGroupName: 'BankFile',
        permissions: [
          {
            permissionCode: 1701,
            permissionName: 'Reporting_BankFile_Create',
            displayName: 'Add',
            status: false,
          },
          {
            permissionCode: 1702,
            permissionName: 'Reporting_BankFile_View',
            displayName: 'View',
            status: false,
          },
          {
            permissionCode: 1703,
            permissionName: 'Reporting_BankFile_Update',
            displayName: 'Update',
            status: false,
          },
          {
            permissionCode: 1704,
            permissionName: 'Reporting_BankFile_Delete',
            displayName: 'Delete',
            status: false,
          },
          {
            permissionCode: 1705,
            permissionName: 'Reporting_BankFile_Download',
            displayName: 'Download',
            status: false,
          },
        ],
      },
      {
        subGroupName: 'ReportDesigns',
        permissions: [
          {
            permissionCode: 1706,
            permissionName: 'Reporting_ReportDesigns_Create',
            displayName: 'Add',
            status: false,
          },
          {
            permissionCode: 1707,
            permissionName: 'Reporting_ReportDesigns_View',
            displayName: 'View',
            status: false,
          },
          {
            permissionCode: 1708,
            permissionName: 'Reporting_ReportDesigns_Update',
            displayName: 'Update',
            status: false,
          },
          {
            permissionCode: 1709,
            permissionName: 'Reporting_ReportDesigns_Delete',
            displayName: 'Delete',
            status: false,
          },
          {
            permissionCode: 1710,
            permissionName: 'Reporting_ReportDesigns_Download',
            displayName: 'Download',
            status: false,
          },
          {
            permissionCode: 1711,
            permissionName: 'Reporting_ReportDesigns_Upload',
            displayName: 'Upload',
            status: false,
          },
        ],
      },
      {
        subGroupName: 'ReportGroups',
        permissions: [
          {
            permissionCode: 1712,
            permissionName: 'Reporting_ReportGroups_Create',
            displayName: 'Add',
            status: false,
          },
          {
            permissionCode: 1713,
            permissionName: 'Reporting_ReportGroups_View',
            displayName: 'View',
            status: false,
          },
          {
            permissionCode: 1714,
            permissionName: 'Reporting_ReportGroups_Update',
            displayName: 'Update',
            status: false,
          },
          {
            permissionCode: 1715,
            permissionName: 'Reporting_ReportGroups_Delete',
            displayName: 'Delete',
            status: false,
          },
        ],
      },
      {
        subGroupName: 'Reporting',
        permissions: [
          {
            permissionCode: 1716,
            permissionName: 'Reporting_Reporting_Create',
            displayName: 'Add',
            status: false,
          },
          {
            permissionCode: 1717,
            permissionName: 'Reporting_Reporting_View',
            displayName: 'View',
            status: false,
          },
          {
            permissionCode: 1718,
            permissionName: 'Reporting_Reporting_Update',
            displayName: 'Update',
            status: false,
          },
          {
            permissionCode: 1719,
            permissionName: 'Reporting_Reporting_Delete',
            displayName: 'Delete',
            status: false,
          },
          {
            permissionCode: 1720,
            permissionName: 'Reporting_Reporting_Download',
            displayName: 'Download',
            status: false,
          },
        ],
      },
      {
        subGroupName: 'Test',
        permissions: [
          {
            permissionCode: 1721,
            permissionName: 'Reporting_Test_Create',
            displayName: 'Add',
            status: false,
          },
          {
            permissionCode: 1722,
            permissionName: 'Reporting_Test_View',
            displayName: 'View',
            status: false,
          },
          {
            permissionCode: 1723,
            permissionName: 'Reporting_Test_Update',
            displayName: 'Update',
            status: false,
          },
          {
            permissionCode: 1724,
            permissionName: 'Reporting_Test_Delete',
            displayName: 'Delete',
            status: false,
          },
        ],
      },
    ],
  },
]
export default rowData
