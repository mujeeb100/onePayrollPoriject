import { Stack } from '@mui/material'
import Box from '@mui/material/Box'
import OPRCheckbox from 'components/atoms/checkbox/OPRCheckbox'
import * as React from 'react'

export default function IndeterminateCheckbox() {
  const [checked, setChecked] = React.useState([true, false])
  const [master, setMaster] = React.useState({
    all: false,
    view: false,
    add: false,
    edit: false,
    delete: false,
  })
  const [selectTemplate, setSelectTemplate] = React.useState({
    selectTemplate: false,
    view: false,
    add: false,
    edit: false,
    delete: false,
  })

  //   const [entity, setEntity] = React.useState({
  //     title: 'Entity',
  //     names: ['entity_all', 'entity_view', 'entity_add', 'entity_edit', 'entity_delete'],
  //     checkedStatus: {
  //       all: false,
  //       view: false,
  //       add: false,
  //       edit: false,
  //       delete: false,
  //     },
  //     children: {
  //       companyBankAccount: {
  //         title: 'Company Bank Account',
  //         names: ['companyBankAccount_all', 'companyBankAccount_view', 'companyBankAccount_add', 'companyBankAccount_edit', 'companyBankAccount_delete'],
  //         checkedStatus: {
  //           companyBankAccount: false,
  //           view: false,
  //           add: false,
  //           edit: false,
  //           delete: false,
  //         },

  //       },
  //       entitySetting: {
  //         title: 'Entity Setting',
  //         names: ['entitySetting_all', 'entitySetting_view', 'entitySetting_add', 'entitySetting_edit', 'entitySetting_delete'],
  //         checkedStatus: {
  //           entitySetting: false,
  //           view: false,
  //           add: false,
  //           edit: false,
  //           delete: false,
  //         },
  //       },
  //     },
  //   })

  const selectTemplateOnChange = (
    event: React.ChangeEvent<HTMLInputElement>,
  ) => {
    const target = event.target.checked

    switch (event.target.name) {
      case 'settingTemplate':
        setSelectTemplate({
          selectTemplate: target,
          view: target,
          add: target,
          edit: target,
          delete: target,
        })
        break
      case 'view':
        setSelectTemplate({
          ...selectTemplate,
          view: target,
          selectTemplate: target,
        })
        break
      case 'add':
        setSelectTemplate({
          ...selectTemplate,
          add: target,
          selectTemplate: target,
        })
        break
      case 'edit':
        setSelectTemplate({
          ...selectTemplate,
          edit: target,
          selectTemplate: target,
        })
        break
      case 'delete':
        setSelectTemplate({
          ...selectTemplate,
          delete: target,
          selectTemplate: target,
        })
        break
      default:
        break
    }
  }

  const masterOnChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const target = event.target.checked

    switch (event.target.name) {
      case 'all':
        setMaster({
          view: target, add: target, edit: target, delete: target, all: target,
        })
        setSelectTemplate({
          selectTemplate: target,
          view: target,
          add: target,
          edit: target,
          delete: target,
        })
        break
      case 'masterView':
        setMaster({ ...master, view: target, all: target })
        setSelectTemplate({ ...selectTemplate, view: target, selectTemplate: target })
        break
      case 'masterAdd':
        setMaster({ ...master, add: target, all: target })
        setSelectTemplate({ ...selectTemplate, add: target, selectTemplate: target })
        break
      case 'masterEdit':
        setMaster({ ...master, edit: target, all: target })
        setSelectTemplate({ ...selectTemplate, edit: target, selectTemplate: target })
        break
      case 'masterDelete':
        setMaster({ ...master, delete: target, all: target })
        setSelectTemplate({ ...selectTemplate, delete: target, selectTemplate: target })
        break
      default:
        break
    }
  }

  const handleChange2 = (event: React.ChangeEvent<HTMLInputElement>) => {
    setChecked([event.target.checked, checked[1]])
  }

  const handleChange3 = (event: React.ChangeEvent<HTMLInputElement>) => {
    setChecked([checked[0], event.target.checked])
  }

  const children = (
    <Box sx={{ display: 'flex', flexDirection: 'row', ml: 4 }}>
      <Stack>
        <OPRCheckbox
          checked={selectTemplate.view}
          label="View"
          name="view"
          onChange={selectTemplateOnChange}
        />
        <OPRCheckbox
          checked={selectTemplate.add}
          label="Add"
          name="add"
          onChange={selectTemplateOnChange}
        />
      </Stack>
      <Stack>
        <OPRCheckbox
          checked={selectTemplate.edit}
          label="Edit"
          name="edit"
          onChange={selectTemplateOnChange}
        />
        <OPRCheckbox
          checked={selectTemplate.delete}
          label="Delete"
          name="delete"
          onChange={selectTemplateOnChange}
        />
      </Stack>
    </Box>
  )

  const masterChildren = (
    <>
      <OPRCheckbox
        checked={master.view}
        label="View"
        name="masterView"
        onChange={masterOnChange}
      />
      <OPRCheckbox
        checked={master.add}
        label="Add"
        name="masterAdd"
        onChange={masterOnChange}
      />
      <OPRCheckbox
        checked={master.edit}
        label="Edit"
        name="masterEdit"
        onChange={masterOnChange}
      />
      <OPRCheckbox
        checked={master.delete}
        label="Delete"
        name="masterDelete"
        onChange={masterOnChange}
      />
    </>
  )

  // When all the states are true, parent checkbox would be checked
  // When all the states are false, parent checkbox would be unchecked
  const getCheckedState = () => checked.every((value) => value === true)

  const getCheckedMasterStatus = (masterCheckbox: {
    view: boolean
    add: boolean
    edit: boolean
    delete: boolean
  }) => Object.entries(masterCheckbox).every(([_, value]) => value === true)

  const getMasterChecked = () => Object.entries(master).every(([_, value]) => value === true)
  // When any of the state is true, then parent checkbox would be indeterminate.
  // When all the states are false, then parent checkbox would be unchecked.
  const getIndeterminateState = () => checked.some((value) => value === true)
  const getIndeterminateState2 = (currentCheckbox: {
    view: boolean
    add: boolean
    edit: boolean
    delete: boolean
  }) => Object.entries(currentCheckbox).some(([_, value]) => value === true)

  return (
    <div>
      <Box sx={{ display: 'flex', flexDirection: 'row' }}>
        <OPRCheckbox
          checked={getCheckedMasterStatus(master)}
          indeterminate={
            getCheckedMasterStatus(master) ? false : getIndeterminateState2(master)
          }
          label="All"
          name="all"
          onChange={masterOnChange}
        />
        {masterChildren}
      </Box>
      <Box sx={{ display: 'flex', flexDirection: 'row' }}>
        <Box sx={{ flexBasis: 'auto' }}>
          <OPRCheckbox
            checked={getCheckedMasterStatus(selectTemplate)}
            indeterminate={
              getCheckedMasterStatus(selectTemplate)
                ? false
                : getIndeterminateState2(selectTemplate)
            }
            label="Setting Template"
            name="settingTemplate"
            onChange={selectTemplateOnChange}
          />
          {children}
        </Box>
        <Box sx={{ flexBasis: 'auto' }}>
          <OPRCheckbox
            checked={getCheckedMasterStatus(selectTemplate)}
            indeterminate={
              getCheckedMasterStatus(selectTemplate)
                ? false
                : getIndeterminateState2(selectTemplate)
            }
            label="Setting Template"
            name="settingTemplate"
            onChange={selectTemplateOnChange}
          />
          {children}
        </Box>
      </Box>
    </div>
  )
}
