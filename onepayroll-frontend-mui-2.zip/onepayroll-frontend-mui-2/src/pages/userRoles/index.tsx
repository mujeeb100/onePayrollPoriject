import { Box, Grid } from '@mui/material'
import { useGetAllUserRoleQuery, useUserRoleDeleteMutation } from 'api/identityServices'
import OPRMultiSelect from 'components/atoms/multiSelectCheckbox/OPRMultiSelectCheckbox'
import { userRolesColumn } from 'components/atoms/table/OPRTableConstant'
import { OPRDeleteControl } from 'components/molecules/OPRAlertControl/OPRDeleteControl'
import { OPRInnerListLayout } from 'components/organism/OPRInnerLayoutList'
import apiEndPoint from 'constants/apiEndPoint'
import { userRoleColumnMappings } from 'constants/exportColumnMappings'
import { useTranslatedColumnsForPDF } from 'hooks/useTranslatedColumnsForPDF'
import { t } from 'i18next'
import React, { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { routes } from 'routes/routes'
import { TRoleTypes } from 'types'
import {
  generateFilterUrl, getAPIWithEntityUrl, getEnv, setRouteValues,
} from 'utils'

function UserRoles() {
  const navigate: any = useNavigate()
  const [selectedOptions, setSelectedOptions] = useState<any>([])
  const [listOfOptions, setListOfOptions] = useState<TRoleTypes[]>([])
  const [value, setValue]:any = useState()
  const [selelctedUser, setSelelctedUser]:any = useState({
    data: {},
    isDelete: false,
    name: '',
  })

  const [filterData, setFilterData]: any = useState({
    pageNumber: 1,
    pageSize: 20,
    totalItems: 0,
    orderByAsc: true,
    sortBy: '',
    SearchText: '',
  })
  const systemAdminOption:any = [
    { name: 'System Admin', value: 'System Admin' },
    { name: 'Regular User', value: 'Regular User' },
  ]
  const modifiedData = (filterData:any) => {
    const data = filterData.roleType?.map((role:any) => {
      const option = systemAdminOption.find((opt:any) => opt.value === role)
      return option ? option.name === 'System Admin' : false
    })
    const filterDataValue = {
      ...filterData,
      roleType: data,
    }
    return filterDataValue
  }
  const {
    data: allUserRoles,
    error: createAllPostsBankAccountError,
    isLoading: isLoadingAllUserRoles,
    isSuccess: isSuccessAllPosts,
    isError: isErrorAllPosts,
    error: errorAllPosts,
  } = useGetAllUserRoleQuery(generateFilterUrl(modifiedData(filterData)))
  const [
    deleteUserRoleById,
    {
      data: deleteUserRoleResponse,
      error: deleteUserRoleError,
      isLoading: deleteUserRoleLoading,
      isSuccess: deleteUserRoleSuccess,
      isError: deleteUserRoleIsError,
    },
  ] = useUserRoleDeleteMutation()

  useEffect(() => {
    if (allUserRoles) {
      const listOfOptions = allUserRoles?.data.map((item: any) => ({
        roleCode: item.roleCode,
        roleName: item.remarks,
      }))
      setListOfOptions(listOfOptions)
    }
  }, [allUserRoles])

  useEffect(() => {
    if (selectedOptions.length > 0) {
      // How can I pass multiple values at once for filtering the result?
      // const selectedRole = selectedOptions.map((item: any) => item.roleCode)
      // setFilterData({ ...filterData, SearchText: selectedRole })
    }
  }, [selectedOptions])

  const sorting = (event: React.MouseEvent<unknown>, property: keyof any) => {
    const isAsc = filterData.sortBy === property && filterData.orderByAsc === true
    setFilterData({ ...filterData, orderByAsc: !isAsc, sortBy: property })
    // setOrder(isAsc ? 'desc' : 'asc')
    // setOrderBy(property)
  }

  useEffect(() => {
    setFilterData({
      ...filterData,
      totalItems: allUserRoles?.totalItems ? allUserRoles?.totalItems : 0,
    })
  }, [
    allUserRoles?.pageNumber,
    filterData.sortBy,
    filterData.orderByAsc,
    allUserRoles?.totalItems,
  ])

  const onSearch = (e: any, data: any) => {
    setFilterData({ ...filterData, ...data })
  }
  const handlePagination = (pageNumber: number, pageSize: number) => {
    setFilterData({ ...filterData, pageNumber })
  }
  const viewAcoount = (data: any, type: string) => {
    if (type === 'Edit user role') {
      navigate(
        setRouteValues(`${routes.editUserRole}`, {
          id: data.id,
        }),
      )
    } else if (type === 'Delete user role') {
      setSelelctedUser({ data, isDelete: true, name: data.roleName })
    } else {
      navigate(
        setRouteValues(`${routes.viewUserRole}`, {
          id: data.id,
          view: true,
        }),
      )
    }
    // if (type === 'Edit user role') navigate(`${routes.editUserRole}`, { state: data.id })
    // const id = JSON.stringify(data)
  }

  const handleView = (data: any) => {
    navigate(
      setRouteValues(`${routes.viewUserRole}`, {
        id: data.id,
        view: true,
      }),
    )
  }

  const renderValue = (selected: string[]) => {
    if (selected.length === 0) {
      return <span>{t('user_role_types_placeholder')}</span>
    }

    return (
      <span
        style={{ display: 'flex', justifyContent: 'space-between' }}
      >
        <span style={{ color: 'white' }}>
          {t('user_role_types_placeholder')}
          {' '}
        </span>
        <span
          style={{
            backgroundColor: 'white',
            color: '#00308F',
            height: '24px',
            width: '24px',
            borderRadius: '50%',
            textAlign: 'center',
          }}
        >
          {selected.length}
        </span>
      </span>
    )
  }

  const filterLayout = () => (
    // <MultipleSelectCheckmarks
    //   listOfOptions={listOfOptions}
    //   renderValue={renderValue}
    //   selectedOptions={selectedOptions}
    //   setSelectedOptions={setSelectedOptions}
    // />
    // <Grid item md={2} sm={1} xs={1}>
    //   <OPRSelectorControl
    //     // error={errors.excludeEmployees}
    //     keyName="name"
    //     label="Include/Exclude"
    //     multiple={false}
    //     name="name"
    //     options={systemAdminOption}
    //     placeholder="Select an option"
    //     value={systemAdminOption.find((o:any) => o?.value === value)}
    //     valueKey="value"
    //     onChange={(text:any) => {
    //       // handleOnChange('excludeEmployees', text?.value)
    //     }}
    //   />
    // </Grid>
    <Grid item md={2} sm={1} xs={1}>
      <OPRMultiSelect
        // error={errors?.payItems}
        label="User Role Type"
        name="name"
        options={systemAdminOption || []}
        placeholder="Select an option"
        value={filterData?.roleType} // Ensure value is initialized as an array
        onChange={(selectedFormat:any) => {
          setFilterData({ ...filterData, roleType: selectedFormat })

          // handleOnChange('payItems', selectedFormat)
          // setFilterCriteria({
          //   ...filterCriteria,
          //   payCycleCode: selectedFormat,
          // })
        }}
      />
    </Grid>
  )
  const deleteRole = (data:any) => {
    deleteUserRoleById(`userRoleId=${data.id}`)
  }

  return (
    <Box sx={{ display: 'flex' }}>
      <OPRDeleteControl
        deleteCallBack={deleteRole}
        selelctedUser={selelctedUser}
        setSelelctedUser={setSelelctedUser}
        title="User role"
      />
      <OPRInnerListLayout
        isExport
        Search={filterData.SearchText}
        addHandleClick={() => navigate(routes.createUserRole)}
        columns={userRolesColumn(viewAcoount)}
        dataList={JSON.parse(JSON.stringify(allUserRoles?.data || []))}
        exportProps={{
          data: allUserRoles?.data,
          fileName: 'userRoles',
          columns: useTranslatedColumnsForPDF(userRoleColumnMappings),
          pdf: {
            orientation: 'landscape',
          },
          allRecords: {
            baseURL: getEnv('REACT_APP_MP_BASE_URL', null),
            endpoint: getAPIWithEntityUrl(apiEndPoint.userRoleList),
            filterData,
          },
        }}
        filterData={filterData}
        filterLayout={filterLayout}
        handlePagination={handlePagination}
        handleSearch={onSearch}
        loading={isLoadingAllUserRoles || deleteUserRoleLoading}
        rowClickHandler={handleView}
        rowNumber={0}
        sortHandleClick={sorting}
        title={t('user_roles_page_title')}
      />
    </Box>
  )
}

export default UserRoles
