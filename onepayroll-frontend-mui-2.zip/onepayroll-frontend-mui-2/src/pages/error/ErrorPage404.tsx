import { Box } from '@mui/material'
import OPRPageHeader from 'components/molecules/OPRPageHeader'

function ErrorPage404() {
  return (
    <Box sx={{ display: 'flex' }}>
      <OPRPageHeader
        subTitle="lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua." // prettier-ignore
        subTitleComponent="p"
        subTitleVariant="subtitle1"
        title="404 - Page not found"
        titleComponent="h1"
        titleVariant="h3"
      />
    </Box>
  )
}

export default ErrorPage404
