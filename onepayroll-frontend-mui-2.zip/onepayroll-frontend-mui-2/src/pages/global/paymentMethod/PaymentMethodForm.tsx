import { Box, Grid } from '@mui/material'
import {
  useGetAllCountryQuery,
  useLazyGetPaymentMethodByIdQuery,
  usePaymentMethodCreateMutation,
  usePaymentMethodUpdateMutation,
} from 'api/globalServices'
import OPRInputControl from 'components/molecules/OPRInputControl'
import OPRResponsiveGrid from 'components/molecules/OPRResponsiveGrid'
import OPRSelectorControl from 'components/molecules/OPRSelectorControl/OPRSelectorControl'
import OPRAlertControl from 'components/organism/OPRAlertControl'
import { OPRInnerFormLayout } from 'components/organism/OPRInnerFormLayout'
import { validationSchemaPaymentMethod } from 'constants/validate'
import { useEditable } from 'hooks/useEdit'
import useForm from 'hooks/useForm'
import { t } from 'i18next'
import { useEffect, useState } from 'react'
import { useLocation, useNavigate } from 'react-router-dom'
import { routes } from 'routes/routes'
import { generateFilterUrl, getParamsValue } from 'utils'

interface MessageProps {
  text?: string;
  important?: boolean;
}

const defaultValues = {
  countryLocalization: 'HKG',
  paymentMethodCode: '', // Add any other default values if needed
  paymentMethodName: '',
  remarks: '',
}

export default function PaymentMethodForm() {
  const location: any = useLocation()
  // const id = getParamsValue(location, routes.createPaymentMethod)
  const { id, viewUrl } = getParamsValue(location, routes.createPaymentMethod)

  const { isEditable, setEditable } = useEditable()
  const [filterData, setFilterData]:any = useState({
    pageNumber: 1,
    pageSize: 1000,
    totalItems: 0,
    orderByAsc: true,
    sortBy: '',
    SearchText: '',
  })
  // countrylist
  const {
    data: allData,

  } = useGetAllCountryQuery(generateFilterUrl(filterData))

  const {
    values,
    setValues,
    errors,
    handleChange,
    setErrors,
    handleOnChange,
    handleFormSubmit,
  } = useForm(validationSchemaPaymentMethod)

  const navigate = useNavigate()
  const [
    createPaymentMethod,
    {
      data: createdPaymentMethodData,
      error: createdPaymentMethodError,
      isLoading: createdPaymentMethodLoading,
      isSuccess: createdPaymentMethodSuccess,
      isError: createdPaymentMethodIsError,
    },
  ] = usePaymentMethodCreateMutation()

  const [
    updatePaymentMethod,
    {
      data: updatedDataResponse,
      error: updatedPaymentMethodError,
      isLoading: updatedPaymentMethodLoading,
      isSuccess: updatedPaymentMethodSuccess,
      isError: updatedPaymentMethodIsError,
    },
  ] = usePaymentMethodUpdateMutation()

  const [
    updatePaymentMethodById,
    {
      data: updatedPaymentMethodByIdResponse,
      error: updatedPaymentMethodByIdError,
      isLoading: updatedPaymentMethodByIdLoading,
      isSuccess: updatedPaymentMethodByIdSuccess,
      isError: updatedPaymentMethodByIdIsError,
    },
  ] = useLazyGetPaymentMethodByIdQuery()

  useEffect(() => {
    if (id) {
      updatePaymentMethodById(id)
      setEditable(viewUrl)// changes
    }
  }, [])
  useEffect(() => {
    if (id) {
      setValues(updatedPaymentMethodByIdResponse?.data)
    } else {
      setValues(location.state ? location.state : {})
    }
  }, [updatedPaymentMethodByIdResponse?.data])

  // useEffect(() => {
  //   if (createdPaymentMethodSuccess) {
  //     // Reset form values after successful add operation
  //     setValues({})
  //     setErrors({})
  //   }
  // }, [createdPaymentMethodSuccess])

  useEffect(() => {
    if (id === null) {
      setValues(defaultValues)
    }
  }, [])

  const handleSubmit: any = async () => {
    if (isEditable) {
      if (id === null) {
        await createPaymentMethod({
          countryLocalization: values?.countryLocalization,
          paymentMethodCode: values?.paymentMethodCode,
          paymentMethodName: values?.paymentMethodName,
          remarks: values?.remarks || '',
        })
      } else {
        await updatePaymentMethod({
          id: values?.id,
          countryLocalization: values?.countryLocalization,
          paymentMethodCode: values?.paymentMethodCode,
          paymentMethodName: values?.paymentMethodName,
          remarks: values?.remarks || '',
        })
      }
    } else {
      setEditable(true)
    }
  }

  async function editPaymentMethod() {
    await updatePaymentMethod({
      id: values?.id,
      countryLocalization: values?.countryLocalization,
      paymentMethodCode: values?.paymentMethodCode,
      paymentMethodName: values?.paymentMethodName,
      remarks: values?.remarks || '',
    })
  }

  const onScreenClose: any = (item: any) => {
    setEditable(item)
    setValues({})
  }

  const handleCancelClick = (obj:any) => {
    setValues({
      ...obj,
      countryLocalization:
      'HKG',
    })
  }

  return (
    <Box sx={{ display: 'flex' }}>
      <form
        style={{ display: 'flex', width: '100% ' }}
        onSubmit={(e) => handleFormSubmit(e, handleSubmit)}
      >
        <OPRAlertControl
          error={createdPaymentMethodError || updatedPaymentMethodError}
          handleEditable={setEditable}
          handleSetValue={handleCancelClick}
          handleSubmit={handleSubmit}
          isError={createdPaymentMethodError || updatedPaymentMethodError}
          isLoading={
            createdPaymentMethodLoading
            || updatedPaymentMethodLoading
            || updatedPaymentMethodByIdLoading
          }
          isSuccess={updatedPaymentMethodSuccess || createdPaymentMethodSuccess}
          name={values?.paymentMethodName}
          title="Payment Method"
          type={id ? 'Update' : 'New'}
        />
        <OPRInnerFormLayout
          error={createdPaymentMethodError || updatedPaymentMethodError}
          handleCancelClick={() => navigate(-1)}
          handleContinueClick={handleSubmit}
          handleEditable={() => {
            setEditable(true)
          }}
          isBackButton={isEditable}
          isLoading={
            createdPaymentMethodLoading
            || updatedPaymentMethodLoading
            || updatedPaymentMethodByIdLoading
          }
          pageType="detailsPage"
          subtitle={
            isEditable
              ? 'Please check the user details below.'
              : 'All fields are mandatory except those marked optional'
          }
          // title="Payment Method"
          title={(viewUrl) ? t('Payment Method') : false || ((id) ? values?.paymentMethodName : t('Add Payment Method'))} // Set title based on mode
          onScreenClose={onScreenClose}
        >
          <Box>
            <OPRResponsiveGrid>
              <Grid item md={2} sm={1} xs={1}>
                <OPRInputControl
                  error={errors?.paymentMethodCode}
                  isEditable={isEditable}
                  // label={t('payment_method_code')}
                  label="Payment Method ID"
                  name="paymentMethodCode"
                  value={values?.paymentMethodCode}
                  onChange={handleChange}
                />
              </Grid>
              <Grid item md={2} sm={1} xs={1}>
                <OPRInputControl
                  error={errors?.paymentMethodName}
                  isEditable={isEditable}
                  label={t('payment_method_name')}
                  name="paymentMethodName"
                  value={values?.paymentMethodName}
                  onChange={handleChange}
                />
              </Grid>
              <Grid item md={2} sm={1} xs={1}>

                <OPRSelectorControl
                  defaultValue={{ countryCode: 'Hong Kong', countryName: 'Hong Kong' }}
                  error={errors?.countryLocalization}
                  isEditable={isEditable}
                  keyName="countryName"
                  label="country_localization_title"
                  multiple={false}
                  name="countryLocalization"
                  options={(allData?.records || [])}
                  placeholder="Select an option"
                  value={
                    { countryName: values?.countryLocalization, countryCode: values?.countryLocalization }
                  }
                  // value={(allData?.records || []).find((o:any) => o.countryCode === values?.countryLocalization)}
                  valueKey="countryCode"
                  onChange={(text:any) => {
                    // handleChange({ target: { name: 'countryLocalization', value: text?.countryCode }, persist: () => {} })
                    // setValues({ ...values, countryLocalization: text?.countryCode })
                    handleOnChange('countryLocalization', text?.countryCode)
                  }}
                />

              </Grid>
              <Grid item md={2} sm={1} xs={1}>
                <OPRInputControl
                  error={errors?.remarks}
                  isEditable={isEditable}
                  label={t('payment_method_remarks')}
                  name="remarks"
                  optionalText="optional"
                  value={values?.remarks}
                  onChange={handleChange}
                />
              </Grid>
            </OPRResponsiveGrid>
          </Box>
        </OPRInnerFormLayout>
      </form>
    </Box>
  )
}
