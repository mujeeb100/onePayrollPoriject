import {
  Box,
} from '@mui/material'
import { useGetAllStandardExpressionQuery } from 'api/globalServices'
import { standardExpressionColumn } from 'components/atoms/table/OPRTableConstant'
import { OPRInnerListLayout } from 'components/organism/OPRInnerLayoutList'
import React, { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { generateFilterUrl } from 'utils'

function StandardExpressionList() {
  const navigate: any = useNavigate()
  const [filterData, setFilterData]:any = useState({
    pageNumber: 1,
    pageSize: 20,
    totalItems: 0,
    orderByAsc: true,
    sortBy: '',
    SearchText: '',
  })
  const {
    data: allPosts,
    isLoading: isLoadingAllPosts,
    isSuccess: isSuccessAllPosts,
    isError: isErrorAllPosts,
    error: errorAllPosts,
    refetch: refetchAllPosts,
  } = useGetAllStandardExpressionQuery(generateFilterUrl(filterData))

  //   const [deleteStandardExpressionById,
  //     {
  //       data: deleteStandardExpressionResponse,
  //       error: deleteStandardExpressionError,
  //       isLoading: deleteStandardExpressionLoading,
  //       isSuccess: deleteStandardExpressionSuccess,
  //       isError: deleteStandardExpressionIsError,
  //     }] = useStandardExpressionDeleteMutation()
  const sorting = (
    event: React.MouseEvent<unknown>,
    property: keyof any,
  ) => {
    const isAsc = filterData.sortBy === property && filterData.orderByAsc === true
    setFilterData({ ...filterData, orderByAsc: !isAsc, sortBy: property })
    // setOrder(isAsc ? 'desc' : 'asc')
    // setOrderBy(property)
  }

  useEffect(() => {
    setFilterData({ ...filterData, totalItems: allPosts?.totalItems ? allPosts?.totalItems : 0 })
  }, [allPosts?.pageNumber, filterData.sortBy, filterData.orderByAsc, allPosts?.totalItems])

  const onSearch = (e: any, data: any) => {
    setFilterData({ ...filterData, ...data })
  }
  const handlePagination = (pageNumber: number, pageSize: number) => {
    setFilterData({ ...filterData, pageNumber })
  }
  return (
    <Box sx={{ display: 'flex' }}>
      <OPRInnerListLayout
        Search={filterData.SearchText}
        columns={standardExpressionColumn(() => ({}))}
        dataList={JSON.parse(JSON.stringify(allPosts?.records || []))}
        filterData={filterData}
        handlePagination={handlePagination}
        handleSearch={onSearch}
        loading={isLoadingAllPosts}
        sortHandleClick={sorting}
        title="Standard Expression"
      />
    </Box>
  )
}

export default StandardExpressionList
