import {
  Box,
} from '@mui/material'
import { data } from 'components/atoms/table/mockData'
import { OPRTableConstant } from 'components/atoms/table/OPRTableConstant'
import { OPRInnerListLayout } from 'components/organism/OPRInnerLayoutList'
import React from 'react'

function PersonSetting() {
  return (
    <Box sx={{ display: 'flex' }}>
      <OPRInnerListLayout columns={OPRTableConstant(() => ({}))} dataList={data} title="Person" />
    </Box>
  )
}

export default PersonSetting
