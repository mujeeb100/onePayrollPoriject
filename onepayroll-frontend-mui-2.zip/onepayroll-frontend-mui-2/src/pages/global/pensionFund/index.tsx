import {
  Box,
} from '@mui/material'
import { useGetAllGlobalPensionFundSchemeRuleQuery, useGlobalPensionFundSchemeRuleDeleteMutation } from 'api/globalServices'
import { pensionFundColumn } from 'components/atoms/table/OPRTableConstant'
import { OPRInnerListLayout } from 'components/organism/OPRInnerLayoutList'
import { t } from 'i18next'
import React, { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { routes } from 'routes/routes'
import {
  generateFilterUrl, setRouteValues,
} from 'utils'

function GlobalPensionFundSchemeRuleList() {
  const navigate: any = useNavigate()
  const [filterData, setFilterData]:any = useState({
    pageNumber: 1,
    pageSize: 20,
    totalItems: 0,
    orderByAsc: true,
    sortBy: '',
    SearchText: '',
  })
  const {
    data: allPosts,
    error: createAllPostsBankAccountError,
    isLoading: isLoadingAllPosts,
    isSuccess: isSuccessAllPosts,
    isError: isErrorAllPosts,
    error: errorAllPosts,
  } = useGetAllGlobalPensionFundSchemeRuleQuery(generateFilterUrl(filterData))
  const [deleteGlobalPensionFundSchemeRuleById,
    {
      data: deleteGlobalPensionFundSchemeRuleResponse,
      error: deleteGlobalPensionFundSchemeRuleError,
      isLoading: deleteGlobalPensionFundSchemeRuleLoading,
      isSuccess: deleteGlobalPensionFundSchemeRuleSuccess,
      isError: deleteGlobalPensionFundSchemeRuleIsError,
    }] = useGlobalPensionFundSchemeRuleDeleteMutation()

  const sorting = (
    event: React.MouseEvent<unknown>,
    property: keyof any,
  ) => {
    const isAsc = filterData.sortBy === property && filterData.orderByAsc === true
    setFilterData({ ...filterData, orderByAsc: !isAsc, sortBy: property })
  }

  useEffect(() => {
    setFilterData({ ...filterData, totalItems: allPosts?.totalItems ? allPosts?.totalItems : 0 })
  }, [allPosts?.pageNumber, filterData.sortBy, filterData.orderByAsc, allPosts?.totalItems])

  const onSearch = (e: any, data: any) => {
    setFilterData({ ...filterData, ...data })
  }
  const handlePagination = (pageNumber: number, pageSize: number) => {
    setFilterData({ ...filterData, pageNumber })
  }

  // viewAcoount  spelling mistake
  const viewAcoount = (data: any, type:string) => {
    if (type === 'edit') {
      navigate(
        setRouteValues(`${routes.editGlobalPensionFundSchemeRule}`, {
          id: data.id,
        }),
      )
    } else if (type === 'delete') {
      deleteGlobalPensionFundSchemeRuleById(`Id=${data.id}`)
    } else {
      navigate(
        setRouteValues(`${routes.viewGlobalPensionFundSchemeRule}`, {
          id: data.id,
          view: true,
        }),
      )
    }
  }

  const handleView = (data: any) => {
    navigate(
      setRouteValues(`${routes.viewGlobalPensionFundSchemeRule}`, {
        id: data.id,
        view: true,
      }),
    )
  }

  return (
    <Box sx={{ display: 'flex' }}>
      <OPRInnerListLayout
        Search={decodeURIComponent(filterData.SearchText)}
        addHandleClick={() => navigate(routes.createGlobalPensionFundSchemeRule)}
        columns={pensionFundColumn(viewAcoount)}
        dataList={JSON.parse(JSON.stringify(allPosts?.records || []))}
        error={errorAllPosts || deleteGlobalPensionFundSchemeRuleError}
        filterData={filterData}
        handlePagination={handlePagination}
        handleSearch={onSearch}
        loading={isLoadingAllPosts || deleteGlobalPensionFundSchemeRuleLoading}
        rowClickHandler={handleView}
        rowNumber={0}
        sortHandleClick={sorting}
        success={deleteGlobalPensionFundSchemeRuleSuccess}
        title={t('pension_fund_title')}
      />
    </Box>
  )
}

export default GlobalPensionFundSchemeRuleList
