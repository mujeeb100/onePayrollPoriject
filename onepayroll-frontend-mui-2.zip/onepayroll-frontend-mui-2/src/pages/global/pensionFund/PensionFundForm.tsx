import { Box, Grid } from '@mui/material'
import {
  useGetAllCountryQuery, useGlobalPensionFundSchemeRuleCreateMutation, useGlobalPensionFundSchemeRuleUpdateMutation, useLazyGetGlobalPensionFundSchemeRuleByIdQuery,
} from 'api/globalServices'
import OPRDatePickerControl from 'components/molecules/OPRDatePickerControl/OPRDatePickerControl'
import OPRInputControl from 'components/molecules/OPRInputControl'
import OPRResponsiveGrid from 'components/molecules/OPRResponsiveGrid'
import OPRSelectorControl from 'components/molecules/OPRSelectorControl/OPRSelectorControl'
import OPRAlertControl from 'components/organism/OPRAlertControl'
import { OPRInnerFormLayout } from 'components/organism/OPRInnerFormLayout'
import { validationPFSR } from 'constants/validate'
import { useEditable } from 'hooks/useEdit'
import useForm from 'hooks/useForm'
import { t } from 'i18next'
import { useEffect, useState } from 'react'
import { useLocation, useNavigate } from 'react-router-dom'
import { routes } from 'routes/routes'
import { generateFilterUrl, getParamsValue } from 'utils'

const defaultValue = {
  countryLocalization: 'Hong Kong',
  pensionFundSchemeRuleType: null,
  relevantIncomeMinAmount: '0',
  relevantIncomeMaxAmount: '999999999',
  ageFrom: '0',
  ageTo: '99',
  employerContributionRate: '0',
  employeeContributionRate: '0',
  employerFixedContributionAmount: '0',
  employeeFixedContributionAmount: '0',
  employerAnnualContributionCap: '0',
  employeeAnnualContributionCap: '0',
}

interface MessageProps {
  text?: string;
  important?: boolean;
}

export default function GlobalPensionFundSchemeRuleForm() {
  const location: any = useLocation()
  const { id, viewUrl } = getParamsValue(location, routes.createGlobalPensionFundSchemeRule)
  const {
    isEditable,
    setEditable,
  } = useEditable()

  const [filterData, setFilterData]:any = useState({
    pageNumber: 1,
    pageSize: 1000,
    totalItems: 0,
    orderByAsc: true,
    sortBy: '',
    SearchText: '',
  })

  const {
    data: allData,

  } = useGetAllCountryQuery(generateFilterUrl(filterData))

  const {
    values,
    setValues,
    errors,
    handleChange,
    setErrors,
    handleFormSubmit,
    handleOnChange,
  } = useForm(validationPFSR)

  const navigate = useNavigate()
  const [createGlobalPensionFundSchemeRule, {
    data: createdGlobalPensionFundSchemeRuleData,
    error: createdGlobalPensionFundSchemeRuleError,
    isLoading: createdGlobalPensionFundSchemeRuleLoading,
    isSuccess: createdGlobalPensionFundSchemeRuleSuccess,
    isError: createdGlobalPensionFundSchemeRuleIsError,
  }] = useGlobalPensionFundSchemeRuleCreateMutation()

  const [updateGlobalPensionFundSchemeRule, {
    data: updatedDataResponse,
    error: updatedGlobalPensionFundSchemeRuleError,
    isLoading: updatedGlobalPensionFundSchemeRuleLoading,
    isSuccess: updatedGlobalPensionFundSchemeRuleSuccess,
    isError: updatedGlobalPensionFundSchemeRuleIsError,
  }] = useGlobalPensionFundSchemeRuleUpdateMutation()

  const [updateGlobalPensionFundSchemeRuleById, {
    data: updatedGlobalPensionFundSchemeRuleByIdResponse,
    error: updatedGlobalPensionFundSchemeRuleByIdError,
    isLoading: updatedGlobalPensionFundSchemeRuleByIdLoading,
    isSuccess: updatedGlobalPensionFundSchemeRuleByIdSuccess,
    isError: updatedGlobalPensionFundSchemeRuleByIdIsError,
  }] = useLazyGetGlobalPensionFundSchemeRuleByIdQuery()

  useEffect(() => {
    if (id) {
      updateGlobalPensionFundSchemeRuleById(id)
      setEditable(viewUrl)
    }
  }, [])
  useEffect(() => {
    if (id) {
      setValues(updatedGlobalPensionFundSchemeRuleByIdResponse?.data)
    } else {
      setValues(location.state ? location.state : {})
    }
  }, [updatedGlobalPensionFundSchemeRuleByIdResponse?.data])

  // useEffect(() => {
  //   if (createdGlobalPensionFundSchemeRuleSuccess) {
  //     // Reset form values after successful add operation
  //     setValues({})
  //     setErrors({})
  //   }
  // }, [createdGlobalPensionFundSchemeRuleSuccess])

  useEffect(() => {
    if (id === null) {
      setValues(defaultValue)
    }
  }, [])

  const handleSubmit: any = async () => {
    if (isEditable) {
      if (id === null) {
        await createGlobalPensionFundSchemeRule({
          countryLocalization: values?.countryLocalization,
          pensionFundSchemeRuleType: values?.pensionFundSchemeRuleType,
          effectiveStartDate: values?.effectiveStartDate,
          effectiveEndDate: values?.effectiveEndDate,
          relevantIncomeMinAmount: values?.relevantIncomeMinAmount?.toString(),
          relevantIncomeMaxAmount: values?.relevantIncomeMaxAmount?.toString(),
          ageFrom: values?.ageFrom?.toString(),
          ageTo: values?.ageTo?.toString(),
          employerContributionRate: values?.employerContributionRate?.toString(),
          employeeContributionRate: values?.employeeContributionRate?.toString(),
          employerFixedContributionAmount: values?.employerFixedContributionAmount?.toString(),
          employeeFixedContributionAmount: values?.employeeFixedContributionAmount?.toString(),

        })
      } else {
        await updateGlobalPensionFundSchemeRule({
          id: values.id,
          countryLocalization: values.countryLocalization,
          pensionFundSchemeRuleType: values.pensionFundSchemeRuleType,
          effectiveStartDate: values?.effectiveStartDate,
          effectiveEndDate: values?.effectiveEndDate,
          relevantIncomeMinAmount: values?.relevantIncomeMinAmount?.toString(),
          relevantIncomeMaxAmount: values?.relevantIncomeMaxAmount?.toString(),
          ageFrom: values?.ageFrom?.toString(),
          ageTo: values?.ageTo?.toString(),
          employerContributionRate: values?.employerContributionRate?.toString(),
          employeeContributionRate: values?.employeeContributionRate?.toString(),
          employerFixedContributionAmount: values?.employerFixedContributionAmount?.toString(),
          employeeFixedContributionAmount: values?.employeeFixedContributionAmount?.toString(),

        })
      }
    } else {
      setEditable(true)
    }
  }

  async function editGlobalPensionFundSchemeRule() {
    await updateGlobalPensionFundSchemeRule({
      id: values.id,
      countryLocalization: values.countryLocalization,
      pensionFundSchemeRuleType: values.pensionFundSchemeRuleType,
      effectiveStartDate: values?.effectiveStartDate,
      effectiveEndDate: values?.effectiveEndDate,
      relevantIncomeMinAmount: values?.relevantIncomeMinAmount,
      relevantIncomeMaxAmount: values?.relevantIncomeMaxAmount,
      ageFrom: values?.ageFrom,
      ageTo: values?.ageTo,
      employerContributionRate: values?.employerContributionRate,
      employeeContributionRate: values?.employeeContributionRate,
      employerFixedContributionAmount: values?.employerFixedContributionAmount,
      employeeFixedContributionAmount: values?.employeeFixedContributionAmount,

    })
  }

  const onScreenClose: any = (item: any) => {
    setEditable(item)
    setValues({})
  }

  return (
    <Box sx={{ display: 'flex' }}>
      <form style={{ display: 'flex', width: '100% ' }} onSubmit={(e) => handleFormSubmit(e, handleSubmit)}>
        <OPRAlertControl
          error={createdGlobalPensionFundSchemeRuleError || updatedGlobalPensionFundSchemeRuleError}
          handleEditable={setEditable}
          handleSetValue={setValues}
          handleSubmit={handleSubmit}
          isError={createdGlobalPensionFundSchemeRuleError || updatedGlobalPensionFundSchemeRuleError}
          isLoading={createdGlobalPensionFundSchemeRuleLoading || updatedGlobalPensionFundSchemeRuleLoading || updatedGlobalPensionFundSchemeRuleByIdLoading}
          isSuccess={updatedGlobalPensionFundSchemeRuleSuccess || createdGlobalPensionFundSchemeRuleSuccess}
          name={values?.pensionFundSchemeRuleType}
          title={t('pension_fund_title')}
          type={id ? 'Update' : 'New'}
        />
        <OPRInnerFormLayout
          error={createdGlobalPensionFundSchemeRuleError || updatedGlobalPensionFundSchemeRuleError}
          handleCancelClick={() => navigate(-1)}
          handleContinueClick={handleSubmit}
          handleEditable={() => {
            setEditable(true)
          }}
          isBackButton={isEditable}
          isLoading={createdGlobalPensionFundSchemeRuleLoading || updatedGlobalPensionFundSchemeRuleLoading || updatedGlobalPensionFundSchemeRuleByIdLoading}
          pageType="detailsPage"
          subtitle={isEditable ? 'Please check the user details below.' : 'All fields are mandatory except those marked optional'}
          title={(viewUrl) ? t('pension_fund_title') : false || ((id) ? values?.pensionFundSchemeRuleType : `${t('add')} ${t('pension_fund_title')}`)}
          onScreenClose={onScreenClose}
        >
          <Box>
            <OPRResponsiveGrid>
              <Grid item md={2} sm={1} xs={1}>
                <OPRSelectorControl
                  defaultValue={{ countryCode: 'Hong Kong', countryName: 'Hong Kong' }}
                  isEditable={isEditable}
                  keyName="countryName"
                  label="country_localization_title"
                  multiple={false}
                  name="countryLocalization"
                  options={(allData?.records || [])}
                  placeholder="Select an option"
                  value={
                    { countryName: values?.countryLocalization, countryCode: values?.countryLocalization }
                  }
                  // value={(allData?.records || [])?.find((o:any) => o?.countryCode === values?.countryLocalization) || {}}
                  valueKey="countryCode"
                  onChange={(text:any) => {
                    handleOnChange('countryLocalization', text?.countryCode)
                  }}
                />

              </Grid>
              <Grid item md={2} sm={1} xs={1}>
                <OPRInputControl
                  error={errors?.pensionFundSchemeRuleType}
                  isEditable={isEditable}
                  label={t('Pension Fund Scheme Rule Type')}
                  name="pensionFundSchemeRuleType"
                  value={values?.pensionFundSchemeRuleType?.toUpperCase()}
                  onChange={handleChange}
                />
              </Grid>
              <Grid item md={2} sm={1} xs={1}>
                <OPRDatePickerControl
                  error={errors?.effectiveStartDate}
                  isEditable={isEditable}
                  label={t('pension_fund_start_date')}
                  name="effectiveStartDate"
                  // value={values?.effectiveStartDate ? values?.effectiveStartDate?.toISOString() : null}
                  value={values?.effectiveStartDate || null}
                  onChange={(date) => {
                    handleOnChange('effectiveStartDate', date)
                  }}
                />
              </Grid>
              <Grid item md={2} sm={1} xs={1}>

                <OPRDatePickerControl
                  error={errors?.effectiveEndDate}
                  isEditable={isEditable}
                  label={t('Effective End Date')}
                  name="effectiveEndDate"
                  value={values?.effectiveEndDate || null}
                  onChange={(date) => {
                    handleOnChange('effectiveEndDate', date)
                  }}
                />

              </Grid>

              <Grid item md={2} sm={1} xs={1}>
                <OPRInputControl
                  error={errors?.relevantIncomeMinAmount}
                  isEditable={isEditable}
                  label={t('pension_fund_end_min_amount')}
                  name="relevantIncomeMinAmount"
                  value={values?.relevantIncomeMinAmount}
                  onChange={handleChange}
                />
              </Grid>
              <Grid item md={2} sm={1} xs={1}>
                <OPRInputControl
                  error={errors?.relevantIncomeMaxAmount}
                  isEditable={isEditable}
                  label={t('pension_fund_end_max_amount')}
                  name="relevantIncomeMaxAmount"
                  value={values?.relevantIncomeMaxAmount}
                  onChange={handleChange}
                />
              </Grid>
              <Grid item md={2} sm={1} xs={1}>
                <OPRInputControl
                  error={errors?.ageFrom}
                  isEditable={isEditable}
                  label={t('pesion_fund_age_from')}
                  name="ageFrom"
                  optionalText="Optional"
                  value={values?.ageFrom}
                  onChange={handleChange}
                />
              </Grid>

              <Grid item md={2} sm={1} xs={1}>
                <OPRInputControl
                  error={errors?.ageTo}
                  isEditable={isEditable}
                  label={t('pesion_fund_age_to')}
                  name="ageTo"
                  optionalText="Optional"
                  value={values?.ageTo}
                  onChange={handleChange}
                />
              </Grid>

              <Grid item md={2} sm={1} xs={1}>
                <OPRInputControl
                  error={errors?.employerContributionRate}
                  isEditable={isEditable}
                  label={t('pesion_fund_employer_contribution_rate')}
                  name="employerContributionRate"
                  optionalText="Optional"
                  value={values?.employerContributionRate}
                  onChange={handleChange}
                />
              </Grid>

              <Grid item md={2} sm={1} xs={1}>
                <OPRInputControl
                  error={errors?.employeeContributionRate}
                  isEditable={isEditable}
                  label={t('pesion_fund_employee_contribution_rate')}
                  name="employeeContributionRate"
                  optionalText="Optional"
                  value={values?.employeeContributionRate}
                  onChange={handleChange}
                />
              </Grid>

              <Grid item md={2} sm={1} xs={1}>
                <OPRInputControl
                  error={errors?.employerFixedContributionAmount}
                  isEditable={isEditable}
                  label={t('pesion_fund_employer_contribution_amount')}
                  name="employerFixedContributionAmount"
                  optionalText="Optional"
                  value={values?.employerFixedContributionAmount}
                  onChange={handleChange}
                />
              </Grid>

              <Grid item md={2} sm={1} xs={1}>
                <OPRInputControl
                  error={errors?.employeeFixedContributionAmount}
                  isEditable={isEditable}
                  label={t('pesion_fund_employee_contribution_amount')}
                  name="employeeFixedContributionAmount"
                  optionalText="Optional"
                  value={values?.employeeFixedContributionAmount}
                  onChange={handleChange}
                />
              </Grid>

              <Grid item md={2} sm={1} xs={1}>
                <OPRInputControl
                  error={errors?.employerAnnualContributionCap}
                  isEditable={isEditable}
                  label={t('ent_pens_fund_scheme_rule_emplyr_annual_cont_cap')}
                  name="employerAnnualContributionCap"
                  optionalText="optional"
                  value={values?.employerAnnualContributionCap}
                  onChange={handleChange}
                />
              </Grid>
              <Grid item md={2} sm={1} xs={1}>
                <OPRInputControl
                  error={errors?.employeeAnnualContributionCap}
                  isEditable={isEditable}
                  // label={t('ent_pens_fund_scheme_rule_emplyr_annual_cont_cap')}
                  label="Employee annual contribution cap"
                  name="employeeAnnualContributionCap"
                  optionalText="optional"
                  value={values?.employeeAnnualContributionCap}
                  onChange={handleChange}
                />
              </Grid>

            </OPRResponsiveGrid>
          </Box>
        </OPRInnerFormLayout>
      </form>
    </Box>
  )
}
