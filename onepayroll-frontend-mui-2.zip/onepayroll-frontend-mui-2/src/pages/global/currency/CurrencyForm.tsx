import { Box, Grid } from '@mui/material'
import {
  useCurrencyCreateMutation,
  useCurrencyUpdateMutation,
  useLazyGetCurrencyByIdQuery,
} from 'api/globalServices/index'
import OPRInputControl from 'components/molecules/OPRInputControl'
import OPRResponsiveGrid from 'components/molecules/OPRResponsiveGrid'
import OPRAlertControl from 'components/organism/OPRAlertControl'
import { OPRInnerFormLayout } from 'components/organism/OPRInnerFormLayout'
import { validationSchemaCurrency } from 'constants/validate'
import { useEditable } from 'hooks/useEdit'
import useForm from 'hooks/useForm'
import { t } from 'i18next'
import { useEffect } from 'react'
import { useLocation, useNavigate } from 'react-router-dom'
import { routes } from 'routes/routes'
import { getParamsValue } from 'utils'

interface MessageProps {
  text?: string;
  important?: boolean;
}

export default function CurrencyForm() {
  const location: any = useLocation()
  const { id, viewUrl } = getParamsValue(location, routes.createCurrency)// changes
  const {
    isEditable,
    setEditable,
  } = useEditable()

  const {
    values,
    setValues,
    errors,
    handleChange,
    setErrors,
    handleFormSubmit,
  } = useForm(validationSchemaCurrency)

  const navigate = useNavigate()

  const [
    createCurrency,
    {
      data: createdCurrencyData,
      error: createdCurrencyError,
      isLoading: createdCurrencyLoading,
      isSuccess: createdCurrencySuccess,
      isError: createdCurrencyIsError,
    },
  ] = useCurrencyCreateMutation()

  const [
    updateCurrency,
    {
      data: updatedCurrencyDataResponse,
      error: updatedCurrencyError,
      isLoading: updatedCurrencyLoading,
      isSuccess: updatedCurrencySuccess,
      isError: updatedCurrencyIsError,
    },
  ] = useCurrencyUpdateMutation()

  const [updateCurrencyById, {
    data: updatedCurrencyByIdResponse,
    error: updatedCurrencyByIdError,
    isLoading: updatedCurrencyByIdLoading,
    isSuccess: updatedCurrencyByIdSuccess,
    isError: updatedCurrencyByIdIsError,
  }] = useLazyGetCurrencyByIdQuery()

  useEffect(() => {
    if (id) {
      updateCurrencyById(id)
      setEditable(viewUrl)// changes
    }
  }, [])
  useEffect(() => {
    if (id) {
      setValues(updatedCurrencyByIdResponse?.data)
    } else {
      setValues(location.state ? location.state : {}) // changes else
    }
  }, [updatedCurrencyByIdResponse?.data])

  // useEffect(() => {
  //   if (createdCurrencySuccess) {
  //     // Reset form values after successful add operation
  //     setValues({})
  //     setErrors({})
  //   }
  // }, [createdCurrencySuccess])

  const handleSubmit = async () => {
    if (isEditable) {
      if (id === null) {
        await createCurrency({
          currencyCode: values?.currencyCode,
          currencyName: values?.currencyName,
          currencySymbol: values?.currencySymbol,
        })
      } else {
        await updateCurrency({
          id: values?.id,
          currencyCode: values?.currencyCode,
          currencyName: values?.currencyName,
          currencySymbol: values?.currencySymbol,
        })
      }
    } else {
      setEditable(true)
    }
  }

  async function editCurrency() {
    await updateCurrency({
      id: values?.id,
      currencyCode: values?.currencyCode,
      currencyName: values?.currencyName,
      currencySymbol: values?.currencySymbol,
    })
  }

  const onScreenClose:any = (item:any) => {
    setEditable(item)
    setValues({})
  }

  return (
    <Box sx={{ display: 'flex' }}>
      <form
        style={{ display: 'flex', width: '100% ' }}
        onSubmit={(e) => handleFormSubmit(e, handleSubmit)}
      >
        <OPRAlertControl
          error={createdCurrencyError || updatedCurrencyError}
          handleEditable={setEditable}
          handleSetValue={setValues}
          handleSubmit={handleSubmit}
          isError={createdCurrencyError || updatedCurrencyError}
          isLoading={createdCurrencyLoading || updatedCurrencyLoading || updatedCurrencyByIdLoading}
          isSuccess={updatedCurrencySuccess || createdCurrencySuccess}
          name={values?.currencyName}
          title={t('currency_title')}
          type={id ? 'Update' : 'New'}
        />
        <OPRInnerFormLayout
          error={createdCurrencyError || updatedCurrencyError}
          handleCancelClick={() => navigate(-1)}
          handleContinueClick={handleSubmit}
          handleEditable={() => {
            setEditable(true)
          }}
          isBackButton={isEditable}
          isLoading={createdCurrencyLoading || updatedCurrencyLoading || updatedCurrencyByIdLoading}
          pageType="detailsPage"
          subtitle={isEditable ? 'Please check the user details below.' : 'All fields are mandatory except those marked optional'}
          // title={t('currency_title')}
          title={(viewUrl) ? t('Currency') : false || ((id) ? values?.currencyName : t('Add Currency'))} // Set title based on mode
          onScreenClose={onScreenClose}
        >
          <Box>
            <OPRResponsiveGrid>
              <Grid item md={2} sm={1} xs={1}>
                <OPRInputControl
                  error={errors?.currencyCode}
                  isEditable={isEditable}
                  // label={t('currency_code')}
                  label="Currency ID"
                  name="currencyCode"
                  value={values?.currencyCode?.toUpperCase()}
                  onChange={handleChange}
                />
              </Grid>
              <Grid item md={2} sm={1} xs={1}>
                <OPRInputControl
                  error={errors?.currencyName}
                  isEditable={isEditable}
                  label={t('currency_name')}
                  name="currencyName"
                  value={values?.currencyName}
                  onChange={handleChange}
                />
              </Grid>
              <Grid item md={2} sm={1} xs={1}>
                <OPRInputControl
                  error={errors?.currencySymbol}
                  isEditable={isEditable}
                  label={t('currency_symbol')}
                  name="currencySymbol"
                  value={values?.currencySymbol}
                  onChange={handleChange}
                />
              </Grid>
            </OPRResponsiveGrid>
          </Box>
        </OPRInnerFormLayout>
      </form>
    </Box>
  )
}
