import { Box, Grid } from '@mui/material'
import { useCountryCreateMutation, useCountryUpdateMutation, useLazyGetCountryByIdQuery } from 'api/globalServices'
import OPRInputControl from 'components/molecules/OPRInputControl'
import OPRResponsiveGrid from 'components/molecules/OPRResponsiveGrid'
import OPRAlertControl from 'components/organism/OPRAlertControl'
import { OPRInnerFormLayout } from 'components/organism/OPRInnerFormLayout'
import { validationSchema } from 'constants/validate'
import { useEditable } from 'hooks/useEdit'
import useForm from 'hooks/useForm'
import { useEffect } from 'react'
import { useLocation, useNavigate } from 'react-router-dom'
import { routes } from 'routes/routes'
import { getParamsValue } from 'utils'

interface MessageProps {
    text?: string;
    important?: boolean;
  }

export default function CountryForm() {
  const location: any = useLocation()
  const { id, viewUrl } = getParamsValue(location, routes.createCountry)
  const {
    isEditable,
    setEditable,
  } = useEditable()

  const {
    values,
    setValues,
    errors,
    handleChange,
    setErrors,
    handleFormSubmit,
  } = useForm(validationSchema)

  const navigate = useNavigate()
  const [createCountry, {
    data: createdCountryData,
    error: createdCountryError,
    isLoading: createdCountryLoading,
    isSuccess: createdCountrySuccess,
    isError: createdCountryIsError,
  }] = useCountryCreateMutation()

  const [updateCountry, {
    data: updatedDataResponse,
    error: updatedCountryError,
    isLoading: updatedCountryLoading,
    isSuccess: updatedCountrySuccess,
    isError: updatedCountryIsError,
  }] = useCountryUpdateMutation()

  const [updateCountryById, {
    data: updatedCountryByIdResponse,
    error: updatedCountryByIdError,
    isLoading: updatedCountryByIdLoading,
    isSuccess: updatedCountryByIdSuccess,
    isError: updatedCountryByIdIsError,
  }] = useLazyGetCountryByIdQuery()

  useEffect(() => {
    if (id) {
      updateCountryById(id)
      setEditable(viewUrl)
    }
  }, [])
  useEffect(() => {
    if (id) {
      setValues(updatedCountryByIdResponse?.data)
    } else {
      setValues(location.state ? location.state : {})
      // setEditable(false)
    }
  }, [updatedCountryByIdResponse?.data])

  useEffect(() => {
    if (createdCountrySuccess) {
      // Reset form values after successful add operation
      setValues({})
      setErrors({})
    }
  }, [createdCountrySuccess])

  const handleSubmit:any = async () => {
    if (isEditable) {
      if (id === null) {
        await createCountry({
          countryCode: values?.countryCode?.toUpperCase(),
          countryName: values?.countryName,
        })
      } else {
        await updateCountry({
          id: values.id,
          countryCode: values.countryCode?.toUpperCase(),
          countryName: values.countryName,
        })
      }
    } else {
      setEditable(true)
    }
  }

  async function editCountry() {
    await updateCountry({
      id: values.id,
      countryCode: values.countryCode?.toUpperCase(),
      countryName: values.countryName,
    })
  }

  const onScreenClose:any = (item:any) => {
    setEditable(item)
    setValues({})
  }
  return (
    <Box sx={{ display: 'flex' }}>
      <form style={{ display: 'flex', width: '100% ' }} onSubmit={(e) => handleFormSubmit(e, handleSubmit)}>
        <OPRAlertControl
          callBack={(type) => {
            // if (type === 'success') {
            //   navigate(-1)
            // }
          }}
          error={createdCountryError || updatedCountryError}
          handleEditable={setEditable}
          handleSetValue={setValues}
          handleSubmit={handleSubmit}
          isError={createdCountryError || updatedCountryError}
          isLoading={createdCountryLoading || updatedCountryLoading || updatedCountryByIdLoading}
          isSuccess={updatedCountrySuccess || createdCountrySuccess}
          name={id ? values?.countryName : createdCountryData?.data?.countryName}
          previousUrl={routes.country}
          title="Country"
          type={id ? 'Update' : 'New'}
        />
        <OPRInnerFormLayout
          error={createdCountryError || updatedCountryError}
          handleCancelClick={() => navigate(-1)}
          handleContinueClick={handleSubmit}
          handleEditable={() => {
            setEditable(true)
          }}
          isBackButton={isEditable}
          isLoading={createdCountryLoading || updatedCountryLoading || updatedCountryByIdLoading}
          pageType="detailsPage"
          subtitle={isEditable ? 'Please check the user details below.' : 'All field to mandatory expect those marked optional'}
          title="Country"
          onScreenClose={onScreenClose}
        >
          <Box>
            <OPRResponsiveGrid>
              <Grid item md={2} sm={1} xs={1}>
                <OPRInputControl
                  disabled={!!id}
                  error={errors?.countryCode}
                  isEditable={isEditable}
                  label="Country ID"
                  name="countryCode"
                  value={values?.countryCode?.toUpperCase()}
                  onChange={handleChange}
                />
              </Grid>
              <Grid item md={2} sm={1} xs={1}>
                <OPRInputControl error={errors?.countryName} isEditable={isEditable} label="Country Name" name="countryName" value={values?.countryName} onChange={handleChange} />
              </Grid>
            </OPRResponsiveGrid>
          </Box>
        </OPRInnerFormLayout>
      </form>
    </Box>
  )
}
