import '../../../styles/style.css'

import {
  Box,
} from '@mui/material'
import {
  useGetAllProviderTypeQuery, useProviderTypeDeleteMutation,
} from 'api/globalServices'
import { providerTypeColumn } from 'components/atoms/table/OPRTableConstant'
import { OPRInnerListLayout } from 'components/organism/OPRInnerLayoutList'
import { t } from 'i18next'
import React, { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { routes } from 'routes/routes'
import { generateFilterUrl, setRouteValues } from 'utils'

function ProviderTypeList() {
  const navigate: any = useNavigate()
  const [selelctedDelete, setSelelctedDelete]:any = useState({
    data: {},
    isDelete: false,
    name: '',
  })
  const [filterData, setFilterData]:any = useState({
    pageNumber: 1,
    pageSize: 20,
    totalItems: 0,
    orderByAsc: true,
    sortBy: '',
    SearchText: '',
  })
  const {
    data: allPosts,
    isLoading: isLoadingAllPosts,
    isSuccess: isSuccessAllPosts,
    isError: isErrorAllPosts,
    error: errorAllPosts,
    refetch: refetchAllPosts,
  } = useGetAllProviderTypeQuery(generateFilterUrl(filterData))

  const [deleteProviderTypeById,
    {
      data: deleteProviderTypeResponse,
      error: deleteProviderTypeError,
      isLoading: deleteProviderTypeLoading,
      isSuccess: deleteProviderTypeSuccess,
      isError: deleteProviderTypeIsError,
    }] = useProviderTypeDeleteMutation()
  const sorting = (
    event: React.MouseEvent<unknown>,
    property: keyof any,
  ) => {
    const isAsc = filterData.sortBy === property && filterData.orderByAsc === true
    setFilterData({ ...filterData, orderByAsc: !isAsc, sortBy: property })
    // setOrder(isAsc ? 'desc' : 'asc')
    // setOrderBy(property)
  }

  useEffect(() => {
    setFilterData({ ...filterData, totalItems: allPosts?.totalItems ? allPosts?.totalItems : 0 })
  }, [allPosts?.pageNumber, filterData.sortBy, filterData.orderByAsc, allPosts?.totalItems])

  const onSearch = (e: any, data: any) => {
    setFilterData({ ...filterData, ...data })
  }
  const handlePagination = (pageNumber: number, pageSize: number) => {
    setFilterData({ ...filterData, pageNumber })
  }
  const viewAcoount = (data:any, type:string) => {
    if (type === 'Edit Provider type') {
      // navigate(routes.createProviderType, { state: data })
      navigate(
        setRouteValues(`${routes.editProviderType}`, {
          id: data.id,
        }),
      )
    } else if (
      type === 'Delete Provider type'
    ) {
      setSelelctedDelete({ data, isDelete: true, name: data.providerName })
    } else {
      navigate(
        setRouteValues(`${routes.viewProviderType}`, {
          id: data.id,
          view: true,
        }),
      )
    }
  }

  const handleView = (data: any) => {
    navigate(
      setRouteValues(`${routes.viewProviderType}`, {
        id: data.id,
        view: true,
      }),
    )
  }

  const handleDelete = (data:any) => {
    deleteProviderTypeById(`Id=${data.id}`)
  }

  return (
    <Box className="movment-table" sx={{ display: 'flex' }}>
      <OPRInnerListLayout
        Search={decodeURIComponent(filterData.SearchText)}
        addHandleClick={() => navigate(routes.createProviderType)}
        columns={providerTypeColumn(viewAcoount)}
        dataList={JSON.parse(JSON.stringify(allPosts?.records || []))}
        deleteCallBack={handleDelete}
        error={errorAllPosts || deleteProviderTypeError}
        filterData={filterData}
        handlePagination={handlePagination}
        handleSearch={onSearch}
        isError={isErrorAllPosts || deleteProviderTypeIsError}
        loading={isLoadingAllPosts || deleteProviderTypeLoading}
        rowClickHandler={handleView}
        rowNumber={0}
        selelctedUser={selelctedDelete}
        setSelelctedUser={setSelelctedDelete}
        sortHandleClick={sorting}
        success={deleteProviderTypeSuccess}
        title={t('Provider Type')}
      />
    </Box>
  )
}

export default ProviderTypeList
