import '../../../styles/style.css'

import { Box, Grid } from '@mui/material'
import {
  useGetAllCountryQuery,
  useLazyGetProviderTypeByIdQuery,
  useProviderTypeCreateMutation,
  useProviderTypeUpdateMutation,
} from 'api/globalServices'
import OPRInputControl from 'components/molecules/OPRInputControl'
import OPRResponsiveGrid from 'components/molecules/OPRResponsiveGrid'
import OPRSelectorControl from 'components/molecules/OPRSelectorControl/OPRSelectorControl'
import OPRTextArea from 'components/molecules/OPRTextArea/OPRTextArea'
import OPRAlertControl from 'components/organism/OPRAlertControl'
import { OPRInnerFormLayout } from 'components/organism/OPRInnerFormLayout'
import { validationSchemaProviderType } from 'constants/validate'
import { useEditable } from 'hooks/useEdit'
import useForm from 'hooks/useForm'
import { t } from 'i18next'
import { useEffect, useState } from 'react'
import { useLocation, useNavigate } from 'react-router-dom'
import { routes } from 'routes/routes'
import { generateFilterUrl, getParamsValue } from 'utils'

interface MessageProps {
  text?: string;
  important?: boolean;
}

const defaultValues = {
  countryLocalization: 'Hong Kong',
  providerType: '',
  providerCode: '',
  providerName: '',
  remittanceStatementReportFormat: '',
  remittanceStatementFileFormat: '',
  remittanceStatementTerminationCode: '',
  remarks: '',
}

export default function ProviderTypeForm() {
  const location: any = useLocation()
  const { id, viewUrl } = getParamsValue(location, routes.createProviderType)// changes

  const { isEditable, setEditable } = useEditable()
  const [filterData, setFilterData]:any = useState({
    pageNumber: 1,
    pageSize: 1000,
    totalItems: 0,
    orderByAsc: true,
    sortBy: '',
    SearchText: '',
  })

  // countrylist
  const {
    data: allData,

  } = useGetAllCountryQuery(generateFilterUrl(filterData))
  const {
    values,
    setValues,
    errors,
    handleChange,
    setErrors,
    handleOnChange,
    handleFormSubmit,
  } = useForm(validationSchemaProviderType)

  const navigate = useNavigate()
  const [
    createProviderType,
    {
      data: createdProviderTypeData,
      error: createdProviderTypeError,
      isLoading: createdProviderTypeLoading,
      isSuccess: createdProviderTypeSuccess,
      isError: createdProviderTypeIsError,
    },
  ] = useProviderTypeCreateMutation()

  const [
    updateProviderType,
    {
      data: updatedDataResponse,
      error: updatedProviderTypeError,
      isLoading: updatedProviderTypeLoading,
      isSuccess: updatedProviderTypeSuccess,
      isError: updatedProviderTypeIsError,
    },
  ] = useProviderTypeUpdateMutation()

  const [
    updateProviderTypeById,
    {
      data: updatedProviderTypeByIdResponse,
      error: updatedProviderTypeByIdError,
      isLoading: updatedProviderTypeByIdLoading,
      isSuccess: updatedProviderTypeByIdSuccess,
      isError: updatedProviderTypeByIdIsError,
    },
  ] = useLazyGetProviderTypeByIdQuery()

  useEffect(() => {
    if (id) {
      updateProviderTypeById(id)
      setEditable(viewUrl)// changes
    }
  }, [])
  useEffect(() => {
    if (id) {
      setValues(
        updatedProviderTypeByIdResponse?.data,
      )
      // countryLocalization: updatedProviderTypeByIdResponse?.data?.countryLocalization || 'Hong Kong',
    } else {
      setValues(location.state ? location.state : {})
      // setEditable(false)
    }
  }, [updatedProviderTypeByIdResponse?.data])
  // useEffect(() => {
  //   if (location.pathname === routes.editProviderType) {
  //     setValues(location.state ? location.state : {})
  //     setEditable(false)
  //   }
  // }, [])

  // reset th evalues
  useEffect(() => {
    if (values.providerType !== 'Pension Fund') {
      setValues((prev: any) => ({
        ...prev,
        remittanceStatementReportFormat: '',
        remittanceStatementFileFormat: '',
        remittanceStatementTerminationCode: '',
      }))
    }
    // if (id === null) {
    //   setValues(defaultValues)
    // }
  }, [values.providerType])

  useEffect(() => {
    if (id === null) {
      setValues(defaultValues)
    }
  }, [])

  // useEffect(() => {
  //   if (createdProviderTypeSuccess) {
  //     // Reset form values after successful add operation
  //     setValues({})
  //     setErrors({})
  //   }
  // }, [createdProviderTypeSuccess])

  const handleSubmit: any = async () => {
    if (isEditable) {
      if (id === null) {
        await createProviderType({
          countryLocalization: values?.countryLocalization,
          providerType: values?.providerType,
          providerCode: values?.providerCode,
          providerName: values?.providerName,
          remittanceStatementReportFormat: values?.remittanceStatementReportFormat,
          remittanceStatementFileFormat: values?.remittanceStatementFileFormat,
          remittanceStatementTerminationCode:
          values?.remittanceStatementTerminationCode,
          remarks: values?.remarks || '',
        })
      } else {
        await updateProviderType({
          id: values?.id,
          countryLocalization: values?.countryLocalization,
          providerType: values?.providerType,
          providerCode: values?.providerCode,
          providerName: values?.providerName,
          remittanceStatementReportFormat: values?.remittanceStatementReportFormat,
          remittanceStatementFileFormat: values?.remittanceStatementFileFormat,
          remittanceStatementTerminationCode:
            values?.remittanceStatementTerminationCode,
          remarks: values?.remarks || '',
        })
      }
    } else {
      setEditable(true)
    }
  }

  async function editProviderType() {
    await updateProviderType({
      id: values?.id,
      countryLocalization: values?.countryLocalization,
      providerType: values?.providerType,
      providerCode: values?.providerCode,
      providerName: values?.providerName,
      remittanceStatementReportFormat: values?.remittanceStatementReportFormat,
      remittanceStatementFileFormat: values?.remittanceStatementFileFormat,
      remittanceStatementTerminationCode:
        values?.remittanceStatementTerminationCode,
      remarks: values?.remarks,
    })
  }

  const onScreenClose: any = (item: any) => {
    setEditable(item)
    setValues({})
  }

  const handleCancelClick = () => {
    setValues({ ...defaultValues })
  }
  return (
    <Box sx={{ display: 'flex' }}>
      <form
        style={{ display: 'flex', width: '100% ' }}
        onSubmit={(e) => handleFormSubmit(e, handleSubmit)}
      >
        <OPRAlertControl
          error={createdProviderTypeError || updatedProviderTypeError}
          handleEditable={setEditable}
          handleSetValue={handleCancelClick}
          handleSubmit={handleSubmit}
          isError={createdProviderTypeError || updatedProviderTypeError}
          isLoading={
            createdProviderTypeLoading
            || updatedProviderTypeLoading
            || updatedProviderTypeByIdLoading
          }
          isSuccess={updatedProviderTypeSuccess || createdProviderTypeSuccess}
          name={values?.providerCode}
          title="ProviderType"
          type={id ? 'Update' : 'New'}
        />
        <OPRInnerFormLayout
          error={createdProviderTypeError || updatedProviderTypeError}
          handleCancelClick={() => navigate(-1)}
          handleContinueClick={handleSubmit}
          handleEditable={() => {
            setEditable(true)
          }}
          isBackButton={isEditable}
          isLoading={
            createdProviderTypeLoading
            || updatedProviderTypeLoading
            || updatedProviderTypeByIdLoading
          }
          pageType="detailsPage"
          subtitle={
            isEditable
              ? 'Please check the user details below.'
              : 'All fields are mandatory except those marked optional'
          }
          // title="ProviderType"
          title={(viewUrl) ? t('ProviderType') : false || ((id) ? values?.providerName : t('Add Provider Type'))} // Set title based on mode
          onScreenClose={onScreenClose}
        >
          <Box>
            <OPRResponsiveGrid>
              <Grid item md={2} sm={1} xs={1}>

                <OPRSelectorControl
                  defaultValue={{ countryName: 'Hong Kong' }}
                  error={errors?.countryLocalization}
                  isEditable={isEditable}
                  keyName="countryName"
                  label="country_localization_title"
                  multiple={false}
                  name="countryLocalization"
                  options={allData?.records || []}
                  placeholder="Select an option"
                  value={{ countryCode: values?.countryLocalization, countryName: values?.countryLocalization }}
                  valueKey="countryCode"
                  onChange={(text: any) => {
                    setValues({ ...values, countryLocalization: text?.countryName })
                  }}
                />
              </Grid>
              <Grid item md={2} sm={1} xs={1}>

                <OPRSelectorControl
                  error={errors?.providerType}
                  isEditable={isEditable}
                  keyName="providerTypeName"
                  label="Type"
                  multiple={false}
                  name="providerType"
                  options={[
                    { providerTypeName: 'Pension Fund', providerTypeValue: 'Pension Fund' },
                    { providerTypeName: 'Inland Revenue', providerTypeValue: 'Inland Revenue' },
                    { providerTypeName: 'Healthcare', providerTypeValue: 'Healthcare' },
                    { providerTypeName: 'Singapore', providerTypeValue: 'Singapore' },
                    { providerTypeName: 'Malaysia', providerTypeValue: 'Malaysia' },
                    { providerTypeName: 'Indonesia', providerTypeValue: 'Indonesia' },
                  ]}
                  placeholder="Select an option"
                  value={
                    {
                      providerTypeName: values?.providerType,
                      providerTypeValue: values?.providerType,
                    }
                  }
                  valueKey="providerTypeValue"
                  onChange={(text:any) => {
                    // handleChange({ target: { name: 'providerType', value: text?.providerTypeValue }, persist: () => {} })
                    // setValues({ ...values, providerType: text })
                    handleOnChange('providerType', text?.providerTypeValue)
                  }}
                />
              </Grid>
              <Grid item md={2} sm={1} xs={1}>
                <OPRInputControl
                  disabled={!!id}
                  error={errors?.providerCode}
                  isEditable={isEditable}
                  // label={t('provider_code')}
                  label="Provider ID"
                  name="providerCode"
                  value={values?.providerCode}
                  onChange={handleChange}
                />
              </Grid>
              <Grid item className="txt-wrp" md={2} sm={1} xs={1}>
                <OPRInputControl
                  error={errors?.providerName}
                  isEditable={isEditable}
                  label={t('Provider Name')}
                  name="providerName"
                  value={values?.providerName}
                  onChange={handleChange}
                />
              </Grid>
              {values?.providerType === 'Pension Fund' && (
                <>
                  <Grid item md={2} sm={1} xs={1}>

                    <OPRSelectorControl
                      error={errors?.remittanceStatementReportFormat}
                      isEditable={isEditable}
                      keyName="remittanceName"
                      label="Remittance Statement Format"
                      multiple={false}
                      name="remittanceStatementReportFormat"
                      options={[
                        { remittanceName: 'Pension Fund', remittanceValue: 'Pension Fund' },
                        { remittanceName: 'Healthcare', remittanceValue: 'Healthcare' },
                        { remittanceName: 'Singapore', remittanceValue: 'Singapore' },
                        { remittanceName: 'Malaysia', remittanceValue: 'Malaysia' },
                        { remittanceName: 'Indonesia', remittanceValue: 'Indonesia' },
                      ]}
                      placeholder="Select an option"
                      value={
                        { remittanceName: values?.remittanceStatementReportFormat, remittanceValue: values?.remittanceStatementReportFormat }
                      }
                      valueKey="remittanceValue"
                      onChange={(text:any) => {
                        // handleChange({ target: { name: 'remittanceStatementReportFormat', value: text?.remittanceValue }, persist: () => {} })
                        // setValues({ ...values, remittanceStatementReportFormat: text })
                        handleOnChange('remittanceStatementReportFormat', text?.remittanceValue)
                      }}
                    />
                  </Grid>
                  <Grid item md={2} sm={1} xs={1}>

                    <OPRSelectorControl
                      isEditable={isEditable}
                      keyName="remittanceFileName"
                      label="Remittance File Format"
                      multiple={false}
                      name="remittanceStatementFileFormat"
                      optionalText={t('optional')}
                      options={[
                        { remittanceFileName: 'HSBC', reremittanceFileValue: 'HSBC' },
                        { remittanceFileName: 'Manulife', reremittanceFileValue: 'Manulife' },
                        { remittanceFileName: 'AIA', reremittanceFileValue: 'AIA' },
                        { remittanceFileName: 'eMPF', reremittanceFileValue: 'eMPF' },
                      ]}
                      placeholder="Select an option"
                      value={
                        { remittanceFileName: values?.remittanceStatementFileFormat, reremittanceFileValue: values?.remittanceStatementFileFormat }
                      }
                      valueKey="reremittanceFileValue"
                      onChange={(text:any) => {
                        // handleChange({ target: { name: 'remittanceStatementFileFormat', value: text?.reremittanceFileValue }, persist: () => {} })
                        // setValues({ ...values, remittanceStatementFileFormat: text })
                        handleOnChange('remittanceStatementFileFormat', text?.reremittanceFileValue)
                      }}
                    />
                  </Grid>
                  <Grid item md={2} sm={1} xs={1}>

                    <OPRSelectorControl
                      isEditable={isEditable}
                      keyName="remittanceTerminationName"
                      label="Remittance Statement Termination Code"
                      multiple={false}
                      name="remittanceStatementTerminationCode"
                      optionalText={t('optional')}
                      options={[
                        { remittanceTerminationName: 'Pension Fund', remittanceTerminationValue: 'Pension Fund' },
                        { remittanceTerminationName: 'Healthcare', remittanceTerminationValue: 'Healthcare' },
                        { remittanceTerminationName: 'Singapore', remittanceTerminationValue: 'Singapore' },
                        { remittanceTerminationName: 'Malaysia', remittanceTerminationValue: 'Malaysia' },
                        { remittanceTerminationName: 'Indonesia', remittanceTerminationValue: 'Indonesia' },
                      ]}
                      value={
                        { remittanceTerminationName: values?.remittanceStatementTerminationCode, remittanceTerminationValue: values?.remittanceStatementTerminationCode }
                      }
                      valueKey="remittanceTerminationValue"
                      onChange={(text:any) => {
                        // handleChange({ target: { name: 'remittanceStatementTerminationCode', value: text?.remittanceTerminationValue }, persist: () => {} })
                        // setValues({ ...values, remittanceStatementTerminationCode: text })
                        handleOnChange('remittanceStatementTerminationCode', text?.remittanceTerminationValue)
                      }}
                    />
                  </Grid>
                </>
              )}

              <Grid item md={4} sm={6} xs={12}>
                <OPRTextArea
                  error={t(errors?.remarks)}
                  isEditable={isEditable}
                  label="remarks"
                  name="remarks"
                  optionalText="optional"
                  value={values?.remarks}
                  onChange={handleChange}
                />
              </Grid>
            </OPRResponsiveGrid>
          </Box>
        </OPRInnerFormLayout>
      </form>
    </Box>
  )
}
