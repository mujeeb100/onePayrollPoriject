import { Box, Grid } from '@mui/material'
import { useHolidayCalenderCreateMutation, useHolidayCalenderUpdateMutation, useLazyGetHolidayCalenderByIdQuery } from 'api/globalServices'
import OPRInputControl from 'components/molecules/OPRInputControl'
import OPRResponsiveGrid from 'components/molecules/OPRResponsiveGrid'
import OPRSelectorControl from 'components/molecules/OPRSelectorControl/OPRSelectorControl'
import OPRTextArea from 'components/molecules/OPRTextArea/OPRTextArea'
import OPRAlertControl from 'components/organism/OPRAlertControl'
import { OPRInnerFormLayout } from 'components/organism/OPRInnerFormLayout'
import { validationSchemaHolidayCalender } from 'constants/validate'
import { useEditable } from 'hooks/useEdit'
import useForm from 'hooks/useForm'
import { t } from 'i18next'
import { useEffect, useState } from 'react'
import { useLocation, useNavigate } from 'react-router-dom'
import { routes } from 'routes/routes'
import { getParamsValue } from 'utils'

import { DateAddModal } from './AddDatesModal'

const defaultValue = {
  holidayCalendarCode: null,
  holidayCalendarName: null,
  status: true,
  remarks: '',
}
interface MessageProps {
  text?: string;
  important?: boolean;
}

export default function HolidayCalenderForm() {
  const location: any = useLocation()
  const [userModal, setUserModal]:any = useState(false)
  const { id, viewUrl } = getParamsValue(location, routes.createHolidayCalender)
  const {
    isEditable,
    setEditable,
  } = useEditable()

  const {
    values,
    setValues,
    errors,
    handleChange,
    setErrors,
    handleFormSubmit,
    handleOnChange,
  } = useForm(validationSchemaHolidayCalender)

  const navigate = useNavigate()
  const [createHolidayCalender, {
    data: createdHolidayCalenderData,
    error: createdHolidayCalenderError,
    isLoading: createdHolidayCalenderLoading,
    isSuccess: createdHolidayCalenderSuccess,
    isError: createdHolidayCalenderIsError,
  }] = useHolidayCalenderCreateMutation()

  const [updateHolidayCalender, {
    data: updatedDataResponse,
    error: updatedHolidayCalenderError,
    isLoading: updatedHolidayCalenderLoading,
    isSuccess: updatedHolidayCalenderSuccess,
    isError: updatedHolidayCalenderIsError,
  }] = useHolidayCalenderUpdateMutation()

  const [updateHolidayCalenderById, {
    data: updatedHolidayCalenderByIdResponse,
    error: updatedHolidayCalenderByIdError,
    isLoading: updatedHolidayCalenderByIdLoading,
    isSuccess: updatedHolidayCalenderByIdSuccess,
    isError: updatedHolidayCalenderByIdIsError,
  }] = useLazyGetHolidayCalenderByIdQuery()

  useEffect(() => {
    if (id) {
      updateHolidayCalenderById(id)
      setEditable(viewUrl)
    }
  }, [])
  useEffect(() => {
    if (id) {
      setValues(updatedHolidayCalenderByIdResponse?.data)
    } else {
      setValues(location.state ? location.state : {})
    }
  }, [updatedHolidayCalenderByIdResponse?.data])

  // useEffect(() => {
  //   if (createdHolidayCalenderSuccess) {
  //     // Reset form values after successful add operation
  //     setValues({})
  //     setErrors({})
  //   }
  // }, [createdHolidayCalenderSuccess])

  const handleSubmit: any = async () => {
    if (isEditable) {
      if (id === null) {
        await createHolidayCalender({
          holidayCalendarCode: values?.holidayCalendarCode?.toUpperCase(),
          holidayCalendarName: values?.holidayCalendarName,
          status: values?.status,
          remarks: values?.remarks,
        })
      } else {
        await updateHolidayCalender({
          id: values.id,
          holidayCalendarCode: values.holidayCalendarCode?.toUpperCase(),
          holidayCalendarName: values.holidayCalendarName,
          status: values?.status,
          remarks: values?.remarks,
        })
      }
    } else {
      setEditable(true)
    }
  }

  async function editHolidayCalender() {
    await updateHolidayCalender({
      id: values.id,
      holidayCalendarCode: values.holidayCalendarCode?.toUpperCase(),
      holidayCalendarName: values.holidayCalendarName,
      status: values?.status,
      remarks: values?.remarks,
    })
  }
  useEffect(() => {
    if (id === null) {
      setValues(defaultValue)
    }
  }, [])

  const onScreenClose: any = (item: any) => {
    setEditable(item)
    setValues({})
  }

  return (
    <Box sx={{ display: 'flex' }}>
      <DateAddModal
        entity={updatedHolidayCalenderByIdResponse?.data}
        handleClose={() => {
          setUserModal(false)
        }}
        handleOpen={() => setUserModal(true)}
        isOpen={userModal}
      />
      <form style={{ display: 'flex', width: '100% ' }} onSubmit={(e) => handleFormSubmit(e, handleSubmit)}>
        <OPRAlertControl
          error={createdHolidayCalenderError || updatedHolidayCalenderError}
          handleEditable={setEditable}
          handleSetValue={setValues}
          handleSubmit={handleSubmit}
          isError={createdHolidayCalenderError || updatedHolidayCalenderError}
          isLoading={createdHolidayCalenderLoading || updatedHolidayCalenderLoading || updatedHolidayCalenderByIdLoading}
          isSuccess={updatedHolidayCalenderSuccess || createdHolidayCalenderSuccess}
          name={values?.holidayCalendarName}
          title={t('holiday_calender_title')}
          type={id ? 'Update' : 'New'}
        />
        <OPRInnerFormLayout
          // error={createdHolidayCalenderError || updatedHolidayCalenderError}
          handleAddDate={() => setUserModal(true)}
          handleCancelClick={() => navigate(-1)}
          handleContinueClick={handleSubmit}
          handleEditable={() => {
            setEditable(true)
          }}
          isAddDate={!!id}
          isBackButton={isEditable}
          isLoading={createdHolidayCalenderLoading || updatedHolidayCalenderLoading || updatedHolidayCalenderByIdLoading}
          pageType="detailsPage"
          subtitle={isEditable ? 'Please check the user details below.' : 'All fields are mandatory except those marked optional'}
          title={t('holiday_calender_title')}
          onScreenClose={onScreenClose}
        >
          <Box>
            <OPRResponsiveGrid>
              <Grid item md={2} sm={1} xs={1}>
                <OPRInputControl
                  disabled={!!id}
                  error={errors?.holidayCalendarCode}
                  isEditable={isEditable}
                  // label={t('holiday_calender_code')}
                  label="Holiday Calendar ID"
                  name="holidayCalendarCode"
                  value={values?.holidayCalendarCode?.toUpperCase()}
                  onChange={handleChange}
                />
              </Grid>
              <Grid item md={2} sm={1} xs={1}>
                <OPRInputControl
                  error={errors?.holidayCalendarName}
                  isEditable={isEditable}
                  label={t('holiday_calender_name')}
                  name="holidayCalendarName"
                  value={values?.holidayCalendarName}
                  onChange={handleChange}
                />
              </Grid>
              <Grid item md={2} sm={1} xs={1}>
                <OPRSelectorControl
                  error={errors?.status}
                  isEditable={isEditable}
                  keyName="name"
                  label={t('holiday_calender_status')}
                  multiple={false}
                  name="status"
                  options={[{ name: 'Active', values: true }, { name: 'Inactive', values: false }]}
                  placeholder="Select an option"
                  value={[{ name: 'Active', values: true }, { name: 'Inactive', values: false }]?.find((o:any) => o?.values === values?.status) || {}}
                  valueKey="name"
                  onChange={(text:any) => {
                    handleOnChange('status', text?.values)
                  }}
                />
              </Grid>
              <Grid item md={4} sm={6} xs={12}>
                <OPRTextArea
                  error={t(errors?.remarks)}
                  isEditable={isEditable}
                  label={t('holiday_calender_remarks')}
                  name="remarks"
                  optionalText="Optional"
                  value={values?.remarks}
                  onChange={handleChange}
                />
              </Grid>
            </OPRResponsiveGrid>
          </Box>
        </OPRInnerFormLayout>
      </form>
    </Box>
  )
}
