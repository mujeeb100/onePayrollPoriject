import {
  Box,
} from '@mui/material'
import { useGetAllHolidayCalenderQuery, useHolidayCalenderDeleteMutation } from 'api/globalServices'
import { holidayCalenderColumn } from 'components/atoms/table/OPRTableConstant'
import { OPRInnerListLayout } from 'components/organism/OPRInnerLayoutList'
import { t } from 'i18next'
import React, { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { routes } from 'routes/routes'
import {
  generateFilterUrl, setRouteValues,
} from 'utils'

function HolidayCalenderList() {
  const navigate: any = useNavigate()
  const [filterData, setFilterData]:any = useState({
    pageNumber: 1,
    pageSize: 20,
    totalItems: 0,
    orderByAsc: true,
    sortBy: '',
    SearchText: '',
  })
  const {
    data: allPosts,
    error: createAllPostsBankAccountError,
    isLoading: isLoadingAllPosts,
    isSuccess: isSuccessAllPosts,
    isError: isErrorAllPosts,
    error: errorAllPosts,
  } = useGetAllHolidayCalenderQuery(generateFilterUrl(filterData))
  const [deleteHolidayCalenderById,
    {
      data: deleteHolidayCalenderResponse,
      error: deleteHolidayCalenderError,
      isLoading: deleteHolidayCalenderLoading,
      isSuccess: deleteHolidayCalenderSuccess,
      isError: deleteHolidayCalenderIsError,
    }] = useHolidayCalenderDeleteMutation()

  const sorting = (
    event: React.MouseEvent<unknown>,
    property: keyof any,
  ) => {
    const isAsc = filterData.sortBy === property && filterData.orderByAsc === true
    setFilterData({ ...filterData, orderByAsc: !isAsc, sortBy: property })
  }

  useEffect(() => {
    setFilterData({ ...filterData, totalItems: allPosts?.totalItems ? allPosts?.totalItems : 0 })
  }, [allPosts?.pageNumber, filterData.sortBy, filterData.orderByAsc, allPosts?.totalItems])

  const onSearch = (e: any, data: any) => {
    setFilterData({ ...filterData, ...data })
  }
  const handlePagination = (pageNumber: number, pageSize: number) => {
    setFilterData({ ...filterData, pageNumber })
  }

  // viewAcoount  spelling mistake
  const viewAcoount = (data: any, type:string) => {
    if (type === 'edit') {
      navigate(
        setRouteValues(`${routes.editHolidayCalender}`, {
          id: data.id,
        }),
      )
    } else if (type === 'delete') {
      deleteHolidayCalenderById(`Id=${data.id}`)
    } else {
      navigate(
        setRouteValues(`${routes.viewHolidayCalender}`, {
          id: data.id,
          view: true,
        }),
      )
    }
  }
  const handleView = (data: any) => {
    navigate(
      setRouteValues(`${routes.viewHolidayCalender}`, {
        id: data.id,
        view: true,
      }),
    )
  }

  return (
    <Box sx={{ display: 'flex' }}>
      <OPRInnerListLayout
        Search={decodeURIComponent(filterData.SearchText)}
        addHandleClick={() => navigate(routes.createHolidayCalender)}
        columns={holidayCalenderColumn(viewAcoount)}
        dataList={JSON.parse(JSON.stringify(allPosts?.records || []))}
        error={errorAllPosts || deleteHolidayCalenderError}
        filterData={filterData}
        handlePagination={handlePagination}
        handleSearch={onSearch}
        loading={isLoadingAllPosts || deleteHolidayCalenderLoading}
        rowClickHandler={handleView}
        rowNumber={0}
        sortHandleClick={sorting}
        success={deleteHolidayCalenderSuccess}
        title={t('holiday_calender_title')}
      />
    </Box>
  )
}

export default HolidayCalenderList
