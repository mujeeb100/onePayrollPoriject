import { useTheme } from '@emotion/react'
import {
  Box, Grid,
} from '@mui/material'
import { useHolidayDatesCreateMutation } from 'api/globalServices'
import { LeftCaret } from 'assets/svg-images/SvgComponents'
import OPRButton from 'components/atoms/button/OPRButton'
import OPRLabel from 'components/atoms/label/OPRLabel'
import OPRDatePickerControl from 'components/molecules/OPRDatePickerControl/OPRDatePickerControl'
import OPRResponsiveGrid from 'components/molecules/OPRResponsiveGrid'
import OPRSelectorControl from 'components/molecules/OPRSelectorControl/OPRSelectorControl'
import { validationSchemaHolidayCalenderDates } from 'constants/validate'
import useForm from 'hooks/useForm'
import { t } from 'i18next'
import React, { useState } from 'react'

import { CustomDialog } from '../../../components/atoms/modal/OPRModal'
import OPRAlertControl from '../../../components/organism/OPRAlertControl'

type DateAddModalProps = {
    onClick?: () => void;
    handleClose: () => void;
    isOpen: boolean;
    handleOpen: () => void;
    entity?: any;
  };

export function DateAddModal({
  onClick, isOpen, entity, handleClose, handleOpen,
}: DateAddModalProps) {
  const theme:any = useTheme()
  const [steps, setSteps] = useState(0)
  const [userRoleOperation, setRoleOperation]:any = React.useState('')
  const [checkedValue, setCheckedValue] = React.useState<any[]>([])
  const [selected, setSelected] = React.useState<readonly number[]>([])
  const [isCancel, setIsCancel] = useState(false)
  const {
    values,
    setValues,
    errors,
    handleChange,
    setErrors,
    handleFormSubmit,
    handleOnChange,
  } = useForm(validationSchemaHolidayCalenderDates)
  const [filterData, setFilterData]:any = useState({
    pageNumber: 1,
    pageSize: 200,
    totalItems: 0,
    orderByAsc: true,
    sortBy: '',
    SearchText: '',
  })
  const [createHolidayCalenderDates, {
    data: createdHolidayCalenderDatesData,
    error: createdHolidayCalenderDatesError,
    isLoading: createdHolidayCalenderDatesLoading,
    isSuccess: createdHolidayCalenderDatesSuccess,
    isError: createdHolidayCalenderDatesIsError,
  }] = useHolidayDatesCreateMutation()
  const handleSubmit = async () => {
    handleClose()
    // const formatDate = (date:any) => {
    //   const d = new Date(date)
    //   return `${d.getFullYear()}-${(`0${d.getMonth() + 1}`).slice(-2)}-${(`0${d.getDate()}`).slice(-2)}`
    // }

    const formatDate = (date: any) => {
      const d = new Date(date)
      return `${(`0${d.getMonth() + 1}`).slice(-2)}/${(`0${d.getDate()}`).slice(-2)}/${d.getFullYear()}`
    }

    await createHolidayCalenderDates({
      holidayCalendarId: entity?.id,
      fromDate: values?.fromDate ? formatDate(values?.fromDate) : '',
      toDate: values?.toDate ? formatDate(values?.toDate) : '',
      holidayType: Number(values?.holidayType?.id),
    })
  }
  return (
    <Box>
      <OPRAlertControl
        isCustomError
        callBack={() => {
          handleClose()
          setValues({})
          setSteps(0)
        }}
        customBack={() => {
          handleOpen()
        }}
        // customMessage={`${userItem?.username} has been added to ${entity?.entityName}`}
        error={createdHolidayCalenderDatesError}
        handleSubmit={handleSubmit}
        isError={createdHolidayCalenderDatesError}
        isLoading={createdHolidayCalenderDatesLoading}
        isSuccess={createdHolidayCalenderDatesSuccess}
        name={`${entity?.holidayCalendarName}`}
        title="Holiday Dates"
        type="New"
      />
      <CustomDialog
        CustomStyles={{ borderRadius: '16px' }}
        isOpen={isOpen}
        type="loader"
      >
        <OPRLabel sx={{ marginBottom: '10px' }} variant="h4">{t('Add Dates')}</OPRLabel>
        <Box>
          <OPRResponsiveGrid>
            <Grid item md={4} sm={1} xs={1}>
              <OPRDatePickerControl
                error={errors?.fromDate}
                label={t('From date')}
                name="fromDate"
                value={values?.fromDate || null}
                onChange={(date) => {
                  handleOnChange('fromDate', date)
                }}
              />
            </Grid>
            <Grid item md={4} sm={1} xs={1}>
              <OPRDatePickerControl
                error={errors?.toDate}
                label={t('To date')}
                name="toDate"
                value={values?.toDate || null}
                onChange={(date) => {
                  handleOnChange('toDate', date)
                }}
              />
            </Grid>
            <Grid item md={4} sm={1} xs={1}>
              <OPRSelectorControl
                error={errors?.holidayType}
                keyName="label"
                label={t('holiday_Type')}
                multiple={false}
                name="holidayType"
                options={[{ id: '1', label: 'Statutory Holiday' }, { id: '2', label: 'Public Holiday' }]}
                placeholder="Select"
                value={[{ id: '1', label: 'Statutory Holiday' }, { id: '2', label: 'Public Holiday' }].find((o:any) => o?.id === values?.holidayType?.id)}
                valueKey="id"
                onChange={(text:any) => {
                  handleOnChange('holidayType', text)
                }}
              />
            </Grid>
          </OPRResponsiveGrid>
        </Box>
        <Box sx={{
          display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: 5,
        }}
        >
          <OPRButton
            color="info"
            variant="text"
            onClick={() => {
              if (steps > 0) {
                setIsCancel(true)
                handleClose()
              } else {
                handleClose()
                setSelected([])
                setCheckedValue([])
                setValues({})
                setSteps(0)
              }
            }}
          >
            Cancel
          </OPRButton>
          <OPRButton
            variant="contained"
            onClick={() => {
              if (values?.fromDate && values?.toDate) {
                handleSubmit()
              }
            }}
          >
            Confirm
            <LeftCaret />
          </OPRButton>

        </Box>
      </CustomDialog>
    </Box>
  )
}
