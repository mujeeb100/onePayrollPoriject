import { Box } from '@mui/material'
import {
  useGetAllNationalityQuery,
  useNationalityDeleteMutation,
} from 'api/globalServices'
import { nationalityColumn } from 'components/atoms/table/OPRTableConstant'
import { OPRInnerListLayout } from 'components/organism/OPRInnerLayoutList'
import { t } from 'i18next'
import React, { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { routes } from 'routes/routes'
import {
  generateFilterUrl,
  setRouteValues,
} from 'utils'

function NationalityList() {
  const navigate: any = useNavigate()
  const [selelctedDelete, setSelelctedDelete]:any = useState({
    data: {},
    isDelete: false,
    name: '',
  })
  const [filterData, setFilterData]: any = useState({
    pageNumber: 1,
    pageSize: 20,
    totalItems: 0,
    orderByAsc: true,
    sortBy: '',
    SearchText: '',
  })
  const {
    data: allPosts,
    isLoading: isLoadingAllPosts,
    isSuccess: isSuccessAllPosts,
    isError: isErrorAllPosts,
    error: errorAllPosts,
    refetch: refetchAllPosts,
  } = useGetAllNationalityQuery(generateFilterUrl(filterData))
  const [
    deleteNationalityById,
    {
      data: deleteNationalityResponse,
      error: deleteNationalityError,
      isLoading: deleteNationalityLoading,
      isSuccess: deleteNationalitySuccess,
      isError: deleteNationalityIsError,
    },
  ] = useNationalityDeleteMutation()
  const sorting = (event: React.MouseEvent<unknown>, property: keyof any) => {
    const isAsc = filterData.sortBy === property && filterData.orderByAsc === true
    setFilterData({ ...filterData, orderByAsc: !isAsc, sortBy: property })
    // setOrder(isAsc ? 'desc' : 'asc')
    // setOrderBy(property)
  }

  useEffect(() => {
    setFilterData({
      ...filterData,
      totalItems: allPosts?.totalItems ? allPosts?.totalItems : 0,
    })
  }, [
    allPosts?.pageNumber,
    filterData.sortBy,
    filterData.orderByAsc,
    allPosts?.totalItems,
  ])

  const onSearch = (e: any, data: any) => {
    setFilterData({ ...filterData, ...data })
  }
  const handlePagination = (pageNumber: number, pageSize: number) => {
    setFilterData({ ...filterData, pageNumber })
  }

  const viewAcoount = (data: any, type:string) => {
    if (type === 'Edit Nationality') {
      navigate(
        setRouteValues(`${routes.editNationality}`, {
          id: data.id,
        }),
      )
    } else if (type === 'Delete Nationality') {
      // deleteNationalityById(`Id=${data.id}`)
      setSelelctedDelete({ data, isDelete: true, name: data.nationalityCode })
    } else {
      navigate(
        setRouteValues(`${routes.viewNationality}`, {
          id: data.id,
          view: true,
        }),
      )
    }
  }

  const handleView = (data: any) => {
    navigate(
      setRouteValues(`${routes.viewNationality}`, {
        id: data.id,
        view: true,
      }),
    )
  }
  // handle delete
  const handleDelete = (data:any) => {
    deleteNationalityById(`Id=${data.id}`)
  }

  return (
    <Box sx={{ display: 'flex' }}>
      <OPRInnerListLayout
        Search={filterData.SearchText}
        addHandleClick={() => navigate(routes.createNationality)}
        columns={nationalityColumn(viewAcoount)}
        dataList={JSON.parse(JSON.stringify(allPosts?.records || []))}
        deleteCallBack={handleDelete}
        error={errorAllPosts || deleteNationalityError}
        filterData={filterData}
        handlePagination={handlePagination}
        handleSearch={onSearch}
        isError={isErrorAllPosts || deleteNationalityIsError}
        loading={isLoadingAllPosts || deleteNationalityLoading}
        rowClickHandler={handleView}
        rowNumber={0}
        selelctedUser={selelctedDelete}
        setSelelctedUser={setSelelctedDelete}
        sortHandleClick={sorting}
        success={deleteNationalitySuccess}
        title={t('Nationality')}
      />
    </Box>
  )
}

export default NationalityList
