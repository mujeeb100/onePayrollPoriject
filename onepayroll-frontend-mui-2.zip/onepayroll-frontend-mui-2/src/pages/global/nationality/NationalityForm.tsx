import { Box, Grid } from '@mui/material'
import {
  useLazyGetNationalityByIdQuery,
  useNationalityCreateMutation,
  useNationalityUpdateMutation,
} from 'api/globalServices'
import OPRInputControl from 'components/molecules/OPRInputControl'
import OPRResponsiveGrid from 'components/molecules/OPRResponsiveGrid'
import OPRAlertControl from 'components/organism/OPRAlertControl'
import { OPRInnerFormLayout } from 'components/organism/OPRInnerFormLayout'
import {
  validationSchemaNationality,
} from 'constants/validate'
import { useEditable } from 'hooks/useEdit'
import useForm from 'hooks/useForm'
import { t } from 'i18next'
import { useEffect } from 'react'
import { useLocation, useNavigate } from 'react-router-dom'
import { routes } from 'routes/routes'
import { getParamsValue } from 'utils'

interface MessageProps {
  text?: string;
  important?: boolean;
}

export default function NationalityForm() {
  const location: any = useLocation()
  const { id, viewUrl } = getParamsValue(location, routes.createNationality)
  const { isEditable, setEditable } = useEditable()

  const {
    values,
    setValues,
    errors,
    handleChange,
    setErrors,
    handleFormSubmit,
  } = useForm(validationSchemaNationality)

  const navigate = useNavigate()
  const [
    createNationality,
    {
      data: createdNationalityData,
      error: createdNationalityError,
      isLoading: createdNationalityLoading,
      isSuccess: createdNationalitySuccess,
      isError: createdNationalityIsError,
    },
  ] = useNationalityCreateMutation()

  const [
    updateNationality,
    {
      data: updatedDataResponse,
      error: updatedNationalityError,
      isLoading: updatedNationalityLoading,
      isSuccess: updatedNationalitySuccess,
      isError: updatedNationalityIsError,
    },
  ] = useNationalityUpdateMutation()

  const [
    updateNationalityById,
    {
      data: updatedNationalityByIdResponse,
      error: updatedNationalityByIdError,
      isLoading: updatedNationalityByIdLoading,
      isSuccess: updatedNationalityByIdSuccess,
      isError: updatedNationalityByIdIsError,
    },
  ] = useLazyGetNationalityByIdQuery()

  useEffect(() => {
    if (id) {
      updateNationalityById(id)
      setEditable(viewUrl)// changes
    }
  }, [])
  useEffect(() => {
    if (id) {
      setValues(updatedNationalityByIdResponse?.data)
    } else {
      setValues(location.state ? location.state : {})
      // setEditable(false)
    }
  }, [updatedNationalityByIdResponse?.data])

  // useEffect(() => {
  //   if (createdNationalitySuccess) {
  //     // Reset form values after successful add operation
  //     setValues({})
  //     setErrors({})
  //   }
  // }, [createdNationalitySuccess])

  const handleSubmit: any = async () => {
    if (isEditable) {
      if (id === null) {
        await createNationality({
          nationalityCode: values?.nationalityCode,
          nationalityName: values?.nationalityName,
        })
      } else {
        await updateNationality({
          id: values.id,
          nationalityCode: values.nationalityCode,
          nationalityName: values.nationalityName,
        })
      }
    } else {
      setEditable(true)
    }
  }

  async function editNationality() {
    await updateNationality({
      id: values?.id,
      nationalityCode: values?.nationalityCode,
      nationalityName: values?.nationalityName,
    })
  }

  const onScreenClose: any = (item: any) => {
    setEditable(item)
    setValues({})
  }

  return (
    <Box sx={{ display: 'flex' }}>
      <form
        style={{ display: 'flex', width: '100% ' }}
        onSubmit={(e) => handleFormSubmit(e, handleSubmit)}
      >
        <OPRAlertControl
          error={createdNationalityError || updatedNationalityError}
          handleEditable={setEditable}
          handleSetValue={setValues}
          handleSubmit={handleSubmit}
          isError={createdNationalityError || updatedNationalityError}
          isLoading={
            createdNationalityLoading
            || updatedNationalityLoading
            || updatedNationalityByIdLoading
          }
          isSuccess={updatedNationalitySuccess || createdNationalitySuccess}
          name={values?.nationalityName}
          title="Nationality"
          type={id ? 'Update' : 'New'}
        />
        <OPRInnerFormLayout
          error={createdNationalityError || updatedNationalityError}
          handleCancelClick={() => navigate(-1)}
          handleContinueClick={handleSubmit}
          handleEditable={() => {
            setEditable(true)
          }}
          isBackButton={isEditable}
          isLoading={
            createdNationalityLoading
            || updatedNationalityLoading
            || updatedNationalityByIdLoading
          }
          pageType="detailsPage"
          subtitle={
            isEditable
              ? 'Please check the user details below.'
              : 'All fields are mandatory except those marked optional'
          }
          // title="Nationality"
          title={(viewUrl) ? t('Nationality') : false || ((id) ? values?.nationalityName : t('Add Nationality'))} // Set title based on mode
          onScreenClose={onScreenClose}
        >
          <Box>
            <OPRResponsiveGrid>
              <Grid item md={2} sm={1} xs={1}>
                <OPRInputControl
                  disabled={!!id}
                  error={errors?.nationalityCode}
                  isEditable={isEditable}
                  label="Nationality ID"
                  name="nationalityCode"
                  value={values?.nationalityCode}
                  onChange={handleChange}
                />
              </Grid>
              <Grid item md={2} sm={1} xs={1}>
                <OPRInputControl
                  error={errors?.nationalityName}
                  isEditable={isEditable}
                  label="Nationality Name"
                  name="nationalityName"
                  value={values?.nationalityName}
                  onChange={handleChange}
                />
              </Grid>
            </OPRResponsiveGrid>
          </Box>
        </OPRInnerFormLayout>
      </form>
    </Box>
  )
}
