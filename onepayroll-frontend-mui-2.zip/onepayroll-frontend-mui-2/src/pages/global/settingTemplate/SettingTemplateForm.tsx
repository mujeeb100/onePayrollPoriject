import { Box, Grid } from '@mui/material'
import {
  useGetAllCountryQuery,
  useLazyGetSettingTemplateByIdQuery,
  useSettingTemplateCreateMutation,
  useSettingTemplateUpdateMutation,
} from 'api/globalServices'
import OPRInputControl from 'components/molecules/OPRInputControl'
import OPRResponsiveGrid from 'components/molecules/OPRResponsiveGrid'
import OPRSelectorControl from 'components/molecules/OPRSelectorControl/OPRSelectorControl'
import OPRAlertControl from 'components/organism/OPRAlertControl'
import { OPRInnerFormLayout } from 'components/organism/OPRInnerFormLayout'
import { validationSchemaSettingTemplate } from 'constants/validate'
import { useEditable } from 'hooks/useEdit'
import useForm from 'hooks/useForm'
import { t } from 'i18next'
import { useEffect, useState } from 'react'
import { useLocation, useNavigate } from 'react-router-dom'
import { routes } from 'routes/routes'
import { generateFilterUrl, getParamsValue } from 'utils'

interface MessageProps {
  text?: string;
  important?: boolean;
}

const DEFAULT_COUNTRY_LOCALIZATION = {
  countryLocalization: 'Hong Kong',
}

export default function SettingTemplateForm() {
  const location: any = useLocation()
  const { id, viewUrl } = getParamsValue(location, routes.createSettingTemplate)// changes

  const { isEditable, setEditable } = useEditable()
  const [filterData, setFilterData]:any = useState({
    pageNumber: 1,
    pageSize: 1000,
    totalItems: 0,
    orderByAsc: true,
    sortBy: '',
    SearchText: '',
  })

  // countrylist
  const {
    data: allData,

  } = useGetAllCountryQuery(generateFilterUrl(filterData))

  const {
    values,
    setValues,
    errors,
    handleChange,
    handleOnChange,
    setErrors,
    handleFormSubmit,
  } = useForm(validationSchemaSettingTemplate)

  const navigate = useNavigate()
  const [
    createSettingTemplate,
    {
      data: createdSettingTemplateData,
      error: createdSettingTemplateError,
      isLoading: createdSettingTemplateLoading,
      isSuccess: createdSettingTemplateSuccess,
      isError: createdSettingTemplateIsError,
    },
  ] = useSettingTemplateCreateMutation()

  const [
    updateSettingTemplate,
    {
      data: updatedDataResponse,
      error: updatedSettingTemplateError,
      isLoading: updatedSettingTemplateLoading,
      isSuccess: updatedSettingTemplateSuccess,
      isError: updatedSettingTemplateIsError,
    },
  ] = useSettingTemplateUpdateMutation()

  const [
    updateSettingTemplateById,
    {
      data: updatedSettingTemplateByIdResponse,
      error: updatedSettingTemplateByIdError,
      isLoading: updatedSettingTemplateByIdLoading,
      isSuccess: updatedSettingTemplateByIdSuccess,
      isError: updatedSettingTemplateByIdIsError,
    },
  ] = useLazyGetSettingTemplateByIdQuery()

  useEffect(() => {
    if (id) {
      updateSettingTemplateById(id)
      setEditable(viewUrl)// changes
    }
  }, [])
  useEffect(() => {
    if (id) {
      setValues(updatedSettingTemplateByIdResponse?.data)
    } else {
      setValues(location.state ? location.state : {}) // changes else
    }
  }, [updatedSettingTemplateByIdResponse?.data])

  const handleSubmit: any = async () => {
    if (isEditable) {
      if (id === null) {
        await createSettingTemplate({
          settingCode: values?.settingCode,
          settingName: values?.settingName,
          countryLocalization: values?.countryLocalization,
          settingLevel: values?.settingLevel,
          category: values?.category,
          remarks: values?.remarks || '',
        })
      } else {
        await updateSettingTemplate({
          id: values.id,
          settingCode: values?.settingCode,
          settingName: values?.settingName,
          countryLocalization: values?.countryLocalization,
          settingLevel: values?.settingLevel,
          category: values?.category,
          remarks: values?.remarks || '',
        })
      }
    } else {
      setEditable(true)
    }
  }

  async function editSettingTemplate() {
    await updateSettingTemplate({
      id: values.id,
      settingCode: values?.settingCode,
      settingName: values?.settingName,
      countryLocalization: values?.countryLocalization,
      settingLevel: values?.settingLevel,
      category: values?.category,
      remarks: values?.remarks || '',
    })
  }

  const onScreenClose: any = (item: any) => {
    setEditable(item)
    setValues({})
  }

  const options = [
    { settingName: 'Global Level', settingValue: 'Global Level' },
    { settingName: 'Entity Level', settingValue: 'Entity Level' },
  ]
  return (
    <Box sx={{ display: 'flex' }}>
      <form
        style={{ display: 'flex', width: '100% ' }}
        onSubmit={(e) => handleFormSubmit(e, handleSubmit)}
      >
        <OPRAlertControl
          error={createdSettingTemplateError || updatedSettingTemplateError}
          handleEditable={setEditable}
          handleSetValue={setValues}
          handleSubmit={handleSubmit}
          isError={createdSettingTemplateError || updatedSettingTemplateError}
          isLoading={
            createdSettingTemplateLoading
            || updatedSettingTemplateLoading
            || updatedSettingTemplateByIdLoading
          }
          isSuccess={
            updatedSettingTemplateSuccess || createdSettingTemplateSuccess
          }
          name={values?.settingName}
          title="SettingTemplate"
          type={id ? 'Update' : 'New'}
        />
        <OPRInnerFormLayout
          error={createdSettingTemplateError || updatedSettingTemplateError}
          handleCancelClick={() => navigate(-1)}
          handleContinueClick={handleSubmit}
          handleEditable={() => {
            setEditable(true)
          }}
          isBackButton={isEditable}
          isLoading={
            createdSettingTemplateLoading
            || updatedSettingTemplateLoading
            || updatedSettingTemplateByIdLoading
          }
          pageType="detailsPage"
          subtitle={
            isEditable
              ? 'Please check the user details below.'
              : 'All fields are mandatory except those marked optional'
          }
          // title="SettingTemplate"
          title={(viewUrl) ? t('SettingTemplate') : false || ((id) ? values?.settingName : t('Add Setting Template'))} // Set title based on mode
          onScreenClose={onScreenClose}
        >
          <Box>
            <OPRResponsiveGrid>
              <Grid item md={2} sm={1} xs={1}>
                <OPRInputControl
                  disabled={!!id}
                  error={errors?.settingCode}
                  isEditable={isEditable}
                  // label={t('setting_template_code')}
                  label="Setting ID"
                  name="settingCode"
                  value={values?.settingCode}
                  onChange={handleChange}
                />
              </Grid>
              <Grid item md={2} sm={1} xs={1}>
                <OPRInputControl
                  error={errors?.settingName}
                  isEditable={isEditable}
                  label={t('setting_template_name')}
                  name="settingName"
                  value={values?.settingName}
                  onChange={handleChange}
                />
              </Grid>
              <Grid item md={2} sm={1} xs={1}>

                <OPRSelectorControl
                  defaultValue={DEFAULT_COUNTRY_LOCALIZATION}
                  error={errors?.countryLocalization}
                  isEditable={isEditable}
                  keyName="countryName"
                  label="country_localization_title"
                  multiple={false}
                  name="countryLocalization"
                  options={(allData?.records || [])}
                  placeholder="Select an option"
                  // value={
                  //   { countryName: values?.countryLocalization, countryCode: values?.countryLocalization }
                  // }
                  value={(allData?.records || []).find((o:any) => o.countryCode === values?.countryLocalization)}
                  valueKey="countryCode"
                  onChange={(text:any) => {
                    // handleChange({ target: { name: 'countryLocalization', value: text?.countryCode }, persist: () => {} })
                    // setValues({ ...values, countryLocalization: text?.countryCode })
                    handleOnChange('countryLocalization', text?.countryCode)
                  }}
                />
              </Grid>
              <Grid item md={2} sm={1} xs={1}>
                <OPRSelectorControl
                  error={errors?.settingLevel}
                  isEditable={isEditable}
                  keyName="settingName"
                  label="setting_level"
                  multiple={false}
                  name="settingLevel"
                  options={[
                    { settingName: 'Global Level', settingValues: 'GLOBAL LEVEL' },
                    { settingName: 'Entity Level', settingValues: 'ENTITY LEVEL' },
                  ]}
                  placeholder="Select an option"
                  value={
                    { settingName: values?.settingLevel, settingValues: values?.settingLevel }
                  }
                  // value={[
                  //   { settingName: 'Global Level', settingValues: 'GLOBAL LEVEL' },
                  //   { settingName: 'Entity Level', settingValues: 'ENTITY LEVEL' },
                  // ].find((o:any) => o.settingValues === values?.settingLevel?.trim()) || {}}
                  valueKey="settingValues"
                  onChange={(text:any) => {
                    // Update the state with the selected values
                    // setValues({ ...values, settingLevel: text?.settingValues })
                    handleOnChange('settingLevel', text?.settingValues)
                  }}
                />

              </Grid>
              <Grid item md={2} sm={1} xs={1}>
                <OPRInputControl
                  error={errors?.category}
                  isEditable={isEditable}
                  label={t('category')}
                  name="category"
                  value={values?.category}
                  onChange={handleChange}
                />
              </Grid>

              <Grid item md={2} sm={1} xs={1}>
                <OPRInputControl
                  error={errors?.remarks}
                  isEditable={isEditable}
                  label={t('setting_remarks')}
                  name="remarks"
                  optionalText="optional"
                  value={values?.remarks}
                  onChange={handleChange}
                />
              </Grid>
            </OPRResponsiveGrid>
          </Box>
        </OPRInnerFormLayout>
      </form>
    </Box>
  )
}
