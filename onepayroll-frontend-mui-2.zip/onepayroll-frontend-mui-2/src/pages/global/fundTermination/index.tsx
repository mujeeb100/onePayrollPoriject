import {
  Box,
} from '@mui/material'
import {
  useGetAllPensionFundTerminationQuery,
  usePensionFundTerminationDeleteMutation,
} from 'api/globalServices'
import { pensionFundTerminationColumn } from 'components/atoms/table/OPRTableConstant'
import { OPRInnerListLayout } from 'components/organism/OPRInnerLayoutList'
import { t } from 'i18next'
import React, { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { routes } from 'routes/routes'
import { generateFilterUrl, setRouteValues } from 'utils'

function PensionFundTerminationList() {
  const navigate: any = useNavigate()
  const [selelctedDelete, setSelelctedDelete]:any = useState({
    data: {},
    isDelete: false,
    name: '',
  })
  const [filterData, setFilterData]:any = useState({
    pageNumber: 1,
    pageSize: 20,
    totalItems: 0,
    orderByAsc: false,
    sortBy: '',
    SearchText: '',
  })
  const {
    data: allPosts,
    isLoading: isLoadingAllPosts,
    isSuccess: isSuccessAllPosts,
    isError: isErrorAllPosts,
    error: errorAllPosts,
    refetch: refetchAllPosts,
  } = useGetAllPensionFundTerminationQuery(generateFilterUrl(filterData))
  const [deletePensionFundTerminationById,
    {
      data: deletePensionFundTerminationResponse,
      error: deletePensionFundTerminationError,
      isLoading: deletePensionFundTerminationLoading,
      isSuccess: deletePensionFundTerminationSuccess,
      isError: deletePensionFundTerminationIsError,
    }] = usePensionFundTerminationDeleteMutation()

  const sorting = (
    event: React.MouseEvent<unknown>,
    property: keyof any,
  ) => {
    const isAsc = filterData.sortBy === property && filterData.orderByAsc === true
    setFilterData({ ...filterData, orderByAsc: !isAsc, sortBy: property })
    // setOrder(isAsc ? 'desc' : 'asc')
    // setOrderBy(property)
  }

  useEffect(() => {
    setFilterData({ ...filterData, totalItems: allPosts?.totalItems ? allPosts?.totalItems : 0 })
  }, [allPosts?.pageNumber, filterData.sortBy, filterData.orderByAsc, allPosts?.totalItems])

  const onSearch = (e: any, data: any) => {
    setFilterData({ ...filterData, ...data })
  }

  const handlePagination = (pageNumber: number, pageSize: number) => {
    setFilterData({ ...filterData, pageNumber })
  }
  const viewAcoount = (data: any, type:string) => {
    if (type === 'edit') {
      navigate(
        setRouteValues(`${routes.editPensionFundTermination}`, {
          id: data.id,
        }),
      )
    } else if (type === 'delete') {
      // deletePensionFundTerminationById(`Id=${data.id}`)
      setSelelctedDelete({ data, isDelete: true, name: data.terminationCode })
    } else {
      navigate(
        setRouteValues(`${routes.viewPensionFundTermination}`, {
          id: data.id,
          view: true,
        }),
      )
    }
    // const id = JSON.stringify(data)
  }
  const handleView = (data: any) => {
    navigate(
      setRouteValues(`${routes.viewPensionFundTermination}`, {
        id: data.id,
        view: true,
      }),
    )
  }
  // handle delete
  const handleDelete = (data:any) => {
    deletePensionFundTerminationById(`Id=${data.id}`)
  }

  return (
    <Box sx={{ display: 'flex' }}>
      <OPRInnerListLayout
        Search={decodeURIComponent(filterData.SearchText)}
        addHandleClick={() => navigate(routes.createPensionFundTermination)}
        columns={pensionFundTerminationColumn(viewAcoount)}
        dataList={JSON.parse(JSON.stringify(allPosts?.records || []))}
        deleteCallBack={handleDelete}
        error={errorAllPosts || deletePensionFundTerminationError}
        filterData={filterData}
        handlePagination={handlePagination}
        handleSearch={onSearch}
        isError={isErrorAllPosts || deletePensionFundTerminationIsError}
        loading={isLoadingAllPosts || deletePensionFundTerminationLoading}
        rowClickHandler={handleView}
        rowNumber={0}
        selelctedUser={selelctedDelete}
        setSelelctedUser={setSelelctedDelete}
        sortHandleClick={sorting}
        success={deletePensionFundTerminationSuccess}
        title={t('Pension Fund Termination Code')}
      />
    </Box>
  )
}

export default PensionFundTerminationList
