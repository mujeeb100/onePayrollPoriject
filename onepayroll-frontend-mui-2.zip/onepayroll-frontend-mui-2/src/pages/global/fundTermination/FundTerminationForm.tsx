import { Box, Grid } from '@mui/material'
import {
  useGetAllCountryQuery,
  useLazyGetPensionFundTerminationByIdQuery,
  usePensionFundTerminationCreateMutation,
  usePensionFundTerminationUpdateMutation,
} from 'api/globalServices/index'
import OPRInputControl from 'components/molecules/OPRInputControl'
import OPRResponsiveGrid from 'components/molecules/OPRResponsiveGrid'
import OPRSelectorControl from 'components/molecules/OPRSelectorControl/OPRSelectorControl'
import OPRTextArea from 'components/molecules/OPRTextArea/OPRTextArea'
import OPRAlertControl from 'components/organism/OPRAlertControl'
import { OPRInnerFormLayout } from 'components/organism/OPRInnerFormLayout'
import { validationSchemaPensionFundTermination } from 'constants/validate'
import { useEditable } from 'hooks/useEdit'
import useForm from 'hooks/useForm'
import { t } from 'i18next'
import { useEffect, useState } from 'react'
import { useLocation, useNavigate } from 'react-router-dom'
import { routes } from 'routes/routes'
import { generateFilterUrl, getParamsValue } from 'utils'

const defaultValue = {
  // countryLocalization: 'Hong Kong',
  status: true,

}

interface MessageProps {
  text?: string;
  important?: boolean;
}

export default function PensionFundTerminationForm() {
  const location: any = useLocation()
  const { id, viewUrl } = getParamsValue(location, routes.createPensionFundTermination)// changes
  const {
    isEditable,
    setEditable,
  } = useEditable()
  const [filterData, setFilterData]:any = useState({
    pageNumber: 1,
    pageSize: 1000,
    totalItems: 0,
    orderByAsc: true,
    sortBy: '',
    SearchText: '',
  })

  const {
    values,
    setValues,
    errors,
    handleChange,
    setErrors,
    handleFormSubmit,
    handleOnChange,
  } = useForm(validationSchemaPensionFundTermination)

  const navigate = useNavigate()

  const [
    createPensionFundTermination,
    {
      data: createdPensionFundTerminationData,
      error: createdPensionFundTerminationError,
      isLoading: createdPensionFundTerminationLoading,
      isSuccess: createdPensionFundTerminationSuccess,
      isError: createdPensionFundTerminationIsError,
    },
  ] = usePensionFundTerminationCreateMutation()

  const [
    updatePensionFundTermination,
    {
      data: updatedPensionFundTerminationDataResponse,
      error: updatedPensionFundTerminationError,
      isLoading: updatedPensionFundTerminationLoading,
      isSuccess: updatedPensionFundTerminationSuccess,
      isError: updatedPensionFundTerminationIsError,
    },
  ] = usePensionFundTerminationUpdateMutation()

  const [updatePensionFundTerminationById, {
    data: updatedPensionFundTerminationByIdResponse,
    error: updatedPensionFundTerminationByIdError,
    isLoading: updatedPensionFundTerminationByIdLoading,
    isSuccess: updatedPensionFundTerminationByIdSuccess,
    isError: updatedPensionFundTerminationByIdIsError,
  }] = useLazyGetPensionFundTerminationByIdQuery()

  const {
    data: allData,

  } = useGetAllCountryQuery(generateFilterUrl(filterData))

  useEffect(() => {
    if (id) {
      updatePensionFundTerminationById(id)
      setEditable(viewUrl)// changes
    }
  }, [])
  useEffect(() => {
    if (id) {
      setValues(updatedPensionFundTerminationByIdResponse?.data)
    } else {
      setValues(location.state ? location.state : {}) // changes else
    }
  }, [updatedPensionFundTerminationByIdResponse?.data])
  useEffect(() => {
    if (id === null) {
      setValues(defaultValue)
    }
  }, [])
  // useEffect(() => {
  //   if (createdPensionFundTerminationSuccess) {
  //     // Reset form values after successful add operation
  //     setValues({})
  //     setErrors({})
  //   }
  // }, [createdPensionFundTerminationSuccess])

  const handleSubmit = async () => {
    if (isEditable) {
      if (id === null) {
        await createPensionFundTermination({
          countryLocalization: values?.countryLocalization,
          serviceProviderCode: values?.serviceProviderCode,
          terminationCode: values?.terminationCode,
          terminationDescription: values?.terminationDescription,
          terminationLocalDescription: values?.terminationLocalDescription,
          status: values?.status,
        })
      } else {
        await updatePensionFundTermination({
          id: values?.id,
          countryLocalization: values?.countryLocalization,
          serviceProviderCode: values?.serviceProviderCode,
          terminationCode: values?.terminationCode,
          terminationDescription: values?.terminationDescription,
          terminationLocalDescription: values?.terminationLocalDescription,
          status: values?.status,
        })
      }
    } else {
      setEditable(true)
    }
  }

  async function editPensionFundTermination() {
    await updatePensionFundTermination({
      id: values?.id,
      countryLocalization: values?.countryLocalization,
      serviceProviderCode: values?.serviceProviderCode,
      terminationCode: values?.terminationCode,
      terminationDescription: values?.terminationDescription,
      terminationLocalDescription: values?.terminationLocalDescription,
      status: values?.status,
    })
  }

  const onScreenClose:any = (item:any) => {
    setEditable(item)
    setValues({})
  }

  const handleCancelClick = (obj:any) => {
    setValues({
      ...obj,
      // countryLocalization:
      // 'Hong Kong',
      status: true,
    })
  }

  return (
    <Box sx={{ display: 'flex' }}>
      <form
        style={{ display: 'flex', width: '100% ' }}
        onSubmit={(e) => handleFormSubmit(e, handleSubmit)}
      >
        <OPRAlertControl
          error={createdPensionFundTerminationError || updatedPensionFundTerminationError}
          handleEditable={setEditable}
          handleSetValue={handleCancelClick}
          handleSubmit={handleSubmit}
          isError={createdPensionFundTerminationError || updatedPensionFundTerminationError}
          isLoading={createdPensionFundTerminationLoading || updatedPensionFundTerminationLoading || updatedPensionFundTerminationByIdLoading}
          isSuccess={updatedPensionFundTerminationSuccess || createdPensionFundTerminationSuccess}
          name={id ? values?.terminationCode : createdPensionFundTerminationData?.data?.terminationCode}
          title={t('pf_termination_code_title')}
          type={id ? 'Update' : 'New'}
        />
        <OPRInnerFormLayout
          error={createdPensionFundTerminationError || updatedPensionFundTerminationError}
          handleCancelClick={() => navigate(-1)}
          handleContinueClick={handleSubmit}
          handleEditable={() => {
            setEditable(true)
          }}
          isBackButton={isEditable}
          isLoading={createdPensionFundTerminationLoading || updatedPensionFundTerminationLoading || updatedPensionFundTerminationByIdLoading}
          pageType="detailsPage"
          subtitle={isEditable ? 'Please check the user details below.' : 'All fields are mandatory except those marked optional'}
          // title={t('PensionFundTermination_title')}
          title={(viewUrl) ? t('pf_termination_code_title') : false || ((id) ? values?.terminationCode : `${t('add')} ${t('pf_termination_code_title')}`)} // Set title based on mode
          onScreenClose={onScreenClose}
        >
          <Box>
            <OPRResponsiveGrid>
              <Grid item md={2} sm={1} xs={1}>
                <OPRSelectorControl
                  // defaultValue={{ countryCode: 'Hong Kong', countryName: 'Hong Kong' }}
                  error={errors?.countryLocalization}
                  isEditable={isEditable}
                  keyName="countryName"
                  label="country_localization_title"
                  multiple={false}
                  name="countryLocalization"
                  options={([...allData?.records || []]).sort((a, b) => a.countryName.localeCompare(b.countryName))}
                  placeholder="Select an option"
                  value={
                    { countryName: values?.countryLocalization, countryCode: values?.countryLocalization }
                  }
                  // value={(allData?.records || [])?.find((o:any) => o?.countryCode === values?.countryLocalization) || {}}
                  valueKey="countryCode"
                  onChange={(text:any) => {
                    handleOnChange('countryLocalization', text?.countryCode)
                  }}
                />
              </Grid>

              <Grid item md={2} sm={1} xs={1}>
                <OPRInputControl
                  error={errors?.serviceProviderCode}
                  isEditable={isEditable}
                  label={t('ent_pens_fund_scheme_provider_code')}
                  name="serviceProviderCode"
                  value={values?.serviceProviderCode}
                  onChange={handleChange}
                />
              </Grid>
              <Grid item md={2} sm={1} xs={1}>
                <OPRInputControl
                  error={errors?.terminationCode}
                  isEditable={isEditable}
                  // label={t('employee_profile_termination_code')}
                  label="Termination ID"
                  name="terminationCode"
                  value={values?.terminationCode}
                  onChange={handleChange}
                />
              </Grid>
              <Grid item md={2} sm={1} xs={1}>
                <OPRSelectorControl
                  defaultValue={{ name: 'Active', values: true }}
                  error={errors?.status}
                  isEditable={isEditable}
                  keyName="name"
                  label={t('status')}
                  multiple={false}
                  name="status"
                  options={[{ name: 'Active', values: true }, { name: 'Inactive', values: false }]}
                  placeholder="Select an option"
                  value={[{ name: 'Active', values: true }, { name: 'Inactive', values: false }]?.find((o:any) => o?.values === values?.status) || {}}
                  valueKey="name"
                  onChange={(text:any) => {
                    // handleChange({ target: { name: 'countryLocalization', value: text?.countryCode }, persist: () => {} })
                    // setValues({ ...values, countryLocalization: text })
                    handleOnChange('status', text?.values)
                  }}
                />
              </Grid>
              <Grid item md={2} sm={6} xs={12}>
                <OPRTextArea
                  error={errors?.terminationDescription}
                  isEditable={isEditable}
                  label={t('termination_desc')}
                  name="terminationDescription"
                  value={values?.terminationDescription}
                  onChange={handleChange}
                />
              </Grid>
              <Grid item md={2} sm={6} xs={12}>
                <OPRTextArea
                  error={errors?.terminationLocalDescription}
                  isEditable={isEditable}
                  label={t('termination_local_desc')}
                  name="terminationLocalDescription"
                  optionalText="Optional"
                  value={values?.terminationLocalDescription}
                  onChange={handleChange}
                />
              </Grid>

            </OPRResponsiveGrid>
          </Box>
        </OPRInnerFormLayout>
      </form>
    </Box>
  )
}
