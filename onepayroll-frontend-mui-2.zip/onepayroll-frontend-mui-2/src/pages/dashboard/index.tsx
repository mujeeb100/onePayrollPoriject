import { useState } from 'react'

function DashboardComponent() {
  const [open, setOpen] = useState(false)

  return (
    <>
    </>
  )
}

export default DashboardComponent
