import { Grid } from '@mui/material'
import OPRInputControl from 'components/molecules/OPRInputControl'
import OPRResponsiveGrid from 'components/molecules/OPRResponsiveGrid'
import OPRSelectorControl from 'components/molecules/OPRSelectorControl/OPRSelectorControl'

function ExportCriteria({
  handleOnChange, errors, handleChange, isEditable, values, setValues,
}:any) {
  return (
    <div style={{ gap: 20, display: 'flex', flexDirection: 'column' }}>
      {/* <div style={{
        width: '100%', color: '#3B3839', fontSize: 16, fontFamily: 'Lato', fontWeight: '400', wordWrap: 'break-word',
      }}
      >
        Payroll Summary Report, Payroll Summary Report by Cost Center, Payroll Summary Report by Charge Cost Center, MPF Remittance Statement, ORSO Contribution Listing
      </div> */}
      <div style={{
        width: '100%', color: '#3B3839', fontSize: 16, fontFamily: 'Lato', fontWeight: '400', wordWrap: 'break-word',
      }}
      >
        All fields are mandatory except those marked optional.
      </div>
      <div>
        <OPRResponsiveGrid>
          <Grid item md={2} sm={1} xs={1}>
            <OPRSelectorControl
              error={errors?.exportOptions}
              isEditable={isEditable}
              keyName="ExportName"
              label="Export file format"
              multiple={false}
              name="ExportName"
              options={[
                { ExportName: 'Individual PDF File', ExportValue: 1 },
                { ExportName: 'Zip File', ExportValue: 3 },
              ]}
              placeholder="Select an option"
              value={
                [
                  { ExportName: 'Individual PDF File', ExportValue: 1 },
                  { ExportName: 'Zip File', ExportValue: 3 },
                ]?.find((o:any) => o?.ExportValue === values?.exportOptions) || {}
              }
              valueKey="ExportValue"
              onChange={(text:any) => {
                handleOnChange('exportOptions', text?.ExportValue)
              }}
            />
          </Grid>

          {/* {values?.exportOptions === 2 && ( // Checking for the ExportValue of Single PDF File
            <Grid item md={2} sm={1} xs={1}>
              <OPRInputControl
                error={errors?.userFilePassword}
                isEditable={isEditable}
                label="Password for Single PDF File"
                name="userFilePassword"
                value={values?.userFilePassword}
                onChange={handleChange}
              />
            </Grid>
          )} */}
          {values?.exportOptions === 3 && ( // Checking for the ExportValue of Single PDF File
            <Grid item md={2} sm={1} xs={1}>
              <OPRInputControl
                error={errors?.zipPassword}
                isEditable={isEditable}
                label="Password for ZIP File"
                name="zipPassword"
                optionalText="Optional"
                value={values?.zipPassword}
                onChange={handleChange}
              />
            </Grid>
          )}
        </OPRResponsiveGrid>
      </div>
    </div>
  )
}

export default ExportCriteria
