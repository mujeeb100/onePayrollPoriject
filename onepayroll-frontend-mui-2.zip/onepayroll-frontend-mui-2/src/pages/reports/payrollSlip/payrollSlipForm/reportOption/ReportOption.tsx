import { Grid } from '@mui/material'
import OPRDatePickerControl from 'components/molecules/OPRDatePickerControl/OPRDatePickerControl'
import OPRResponsiveGrid from 'components/molecules/OPRResponsiveGrid'
import OPRSelectorControl from 'components/molecules/OPRSelectorControl/OPRSelectorControl'
import React from 'react'

function ReportOption({
  handleOnChange, errors, handleChange, isEditable, values, setValues,
}:any) {
  return (
    <div style={{ gap: 20, display: 'flex', flexDirection: 'column' }}>

      <div style={{
        width: '100%', color: '#3B3839', fontSize: 16, fontFamily: 'Lato', fontWeight: '400', wordWrap: 'break-word',
      }}
      >
        All fields are mandatory except those marked optional.
      </div>
      <div>
        <OPRResponsiveGrid>

          <Grid item md={2} sm={1} xs={1}>
            <OPRSelectorControl
              error={errors?.sortingOption} // Add error handling if needed
              isEditable={isEditable}
              keyName="SortName"
              label="Ordering"
              multiple={false}
              name="sortingOption"
              optionalText="Optional"
              options={[
                { SortName: 'Employee Code', SortValue: 'Employee Code' },
                { SortName: 'Employee Name', SortValue: 'Employee Name' },
                { SortName: 'Department Code', SortValue: 'Department Code' },
                { SortName: 'Cost Center Code', SortValue: 'Cost Center Code' },
                { SortName: 'Commencement Date', SortValue: 'Commencement Date' },
              ]}
              placeholder="Select an option"
              value={
                { SortName: values?.sortingOption, SortValue: values?.sortingOption }
              }
              valueKey="SortValue"
              onChange={(text: any) => {
                handleOnChange('sortingOption', text?.SortValue)
              }}
            />
          </Grid>

          <Grid item md={2} sm={1} xs={1} />
          {/* paycycleStartDate */}
          <Grid item md={2} sm={1} xs={1}>
            <OPRDatePickerControl
              error={errors?.payDate}
              isEditable={isEditable}
              label="Pay date"
              name="payDate"
              optionalText="Optional"
              value={values?.payDate || null}
              onChange={(date) => {
                handleOnChange('payDate', date)
              }}
            />
          </Grid>
          {/* paycycleEndDate */}
          <Grid item md={2} sm={1} xs={1}>
            <OPRDatePickerControl
              error={errors?.dateToTrustee}
              isEditable={isEditable}
              label="Date to trustee"
              name="dateToTrustee"
              optionalText="Optional"
              value={values?.dateToTrustee || null}
              onChange={(date) => {
                handleOnChange('dateToTrustee', date)
              }}
            />
          </Grid>

          <Grid item md={2} sm={1} xs={1}>
            <OPRSelectorControl
              error={errors?.relevantIncomeIndicator}
              isEditable={isEditable}
              keyName="IncomeName"
              label="Relevant income indicator"
              multiple={false}
              name="relevantIncomeIndicator"
              optionalText="Optional"
              options={[
                { IncomeName: 'No indicator', IncomeValue: 'No indicator' },
                { IncomeName: 'MC Only (*)', IncomeValue: 'MC Only (*)' },
                { IncomeName: 'VC Only (#)', IncomeValue: 'VC Only (#)' },
                { IncomeName: 'ORSO Only (^)', IncomeValue: 'ORSO Only (^)' },
                { IncomeName: 'MC and VC (* #)', IncomeValue: 'MC and VC (* #)' },
                { IncomeName: 'MC and ORSO (* ^)', IncomeValue: 'MC and ORSO (* ^)' },
                { IncomeName: 'MC and VC and ORSO (* # ^)', IncomeValue: 'MC and VC and ORSO (* # ^)' },
              ]}
              placeholder="Select an option"
              value={
                { IncomeName: values?.relevantIncomeIndicator, IncomeValue: values?.relevantIncomeIndicator }
              }
              valueKey="IncomeValue"
              onChange={(text:any) => {
                handleOnChange('relevantIncomeIndicator', text?.IncomeValue)
              }}
            />
          </Grid>
          <Grid item md={2} sm={1} xs={1} />
        </OPRResponsiveGrid>
      </div>
    </div>
  )
}

export default ReportOption
