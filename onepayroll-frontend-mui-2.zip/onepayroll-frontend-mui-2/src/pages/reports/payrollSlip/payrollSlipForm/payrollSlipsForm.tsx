import { Box } from '@mui/material'
import { useGetAllEmployeeProfileQuery } from 'api/employeeServices'
import { useGetAllReportGroupQuery } from 'api/reportingServices'
import { useGeneratePayrollSlipCreateMutation, useGeneratePayrollSlipUpdateMutation } from 'api/reports'
import OPRLabel from 'components/atoms/label/OPRLabel'
import OPRStepper from 'components/atoms/stepper'
import OPRAlertControl from 'components/organism/OPRAlertControl'
import { OPRInnerFormLayout } from 'components/organism/OPRInnerFormLayout'
import { validationSchemaPayrollSlip, validationSchemaPayrollSlip1, validationSchemaPayrollSlip2 } from 'constants/validate'
import { useEditable } from 'hooks/useEdit'
import useForm from 'hooks/useForm'
import { t } from 'i18next'
import React, { useEffect, useRef, useState } from 'react'
import { useLocation, useNavigate } from 'react-router-dom'
import { formatedYearDate, generateFilterUrl } from 'utils'
import { ValidationError } from 'yup'

import ExportCriteria from './exportCriteria/ExportCriteria'
import FilteringCriteria from './filteringCriteria/FilteringCriteria'
import ReportOption from './reportOption/ReportOption'

const validationSchema = (activeStep:any) => {
  switch (activeStep) {
    case 0:
      return validationSchemaPayrollSlip
    case 1:
      return validationSchemaPayrollSlip1
    case 2:
      return validationSchemaPayrollSlip2
    default:
      return validationSchemaPayrollSlip
  }
}

function PayrollSlipsForm({ selectedId }: { selectedId: any; id: any }) {
  const myRef:any = useRef()
  const [activeState, setActiveState] = useState(0)
  const { isEditable, setEditable } = useEditable()
  const [employees, setEmployees]:any = useState([])
  const [selectAll, setSelectAll] = useState(false)
  const [selectedCodes, setSelectedCodes] = useState<string[]>([])
  const location: any = useLocation()
  // const { id, viewUrl } = getParamsValue(location, routes.createUserRole)
  const [filterCriteria, setFilterCriteria] = useState({})
  const [filterData, setFilterData]:any = useState({
    pageNumber: 1,
    pageSize: 1000,
    totalItems: 0,
    orderByAsc: false,
    sortBy: '',
    SearchText: '',
  })
  const id = ''
  const {
    values,
    setValues,
    errors,
    handleChange,
    setErrors,
    handleFormSubmit,
    handleOnChange,
  } = useForm(validationSchema(activeState))
  const navigate = useNavigate()
  const {
    data: employeeDataList,
    isLoading: isLoadingEmployeeDataList,
    isSuccess: isSuccessEmployeeDataList,
    isError: isErrorEmployeeDataList,
    error: errorEmployeeDataList,
    refetch: refetchEmployeeDataList,
  } = useGetAllEmployeeProfileQuery(generateFilterUrl({
    EffectiveDate: '10/10/2040',
    pageSize: 10000,
  }))
  const {
    data: allReportGroupView,
    error: createAllReportGroupViewError,
    isLoading: isLoadingAllReportGroupView,
    isSuccess: isSuccessAllReportGroupView,
    isError: isErrorAllReportGroupView,
  } = useGetAllReportGroupQuery(generateFilterUrl(filterData))

  // console.log('First record id:', allReportGroupView?.records[0].id)

  const [
    createGeneratePayrollSlip,
    {
      data: createdGeneratePayrollSlipDataResponse,
      error: createdGeneratePayrollSlipError,
      isLoading: createdGeneratePayrollSlipLoading,
      isSuccess: createdGeneratePayrollSlipSuccess,
      isError: createdGeneratePayrollSlipIsError,
    },
  ] = useGeneratePayrollSlipCreateMutation()

  const [
    updateGeneratePayrollSlip,
    {
      data: updatedGeneratePayrollSlipDataResponse,
      error: updatedGeneratePayrollSlipError,
      isLoading: updatedGeneratePayrollSlipLoading,
      isSuccess: updatedGeneratePayrollSlipSuccess,
      isError: updatedGeneratePayrollSlipIsError,
    },
  ] = useGeneratePayrollSlipUpdateMutation()

  useEffect(() => {
    if (isSuccessEmployeeDataList) {
      setEmployees(JSON.parse(JSON.stringify(employeeDataList?.records || [])))
    }
  }, [isSuccessEmployeeDataList])

  const handleCheckboxChange = (event: React.ChangeEvent<HTMLInputElement>, code: string) => {
    const { checked } = event.target
    if (checked) {
      setSelectedCodes([...selectedCodes, code])
    } else {
      setSelectedCodes(selectedCodes.filter((selectedCode) => selectedCode !== code))
    }
  }
  const handleRemoveEmployee = (codeToRemove: string) => {
    // Filter out the selected employee code to remove it from the selectedCodes state
    setSelectedCodes(selectedCodes.filter((code) => code !== codeToRemove))
  }
  const handleSelectAllChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const { checked } = event.target
    if (checked) {
      setSelectedCodes(employees.map((employee:any) => employee.employeeCode))
    } else {
      setSelectedCodes([])
    }
    setSelectAll(checked)
  }

  // const handleSubmit: any = async () => {
  //   if (isEditable) {
  //     if (id === null) {
  //       await createGeneratePayrollSlip(values)
  //     } else {
  //       await updateGeneratePayrollSlip(values)
  //     }
  //   } else {
  //     setEditable(true)
  //   }
  // }

  const handleSubmit = async () => {
    const data = {
      reportRequirements: [
        {
          entityId: location.state.entityId,
          reportType: 'Payslip',
          // reportName: location.state.reportName,
          reportDesignId: location.state.id,
          payslipPayrollDto: {
            // receivePayslipMethods: values?.receivePayslipMethods,
            receivePayslipMethods: values?.receivePayslipMethods,
            sortingOption: values?.sortingOption,
            // payDate: values?.payDate,
            payDate: values?.payDate ? formatedYearDate(values?.payDate) : null,
            dateToTrustee: values?.dateToTrustee ? formatedYearDate(values?.dateToTrustee) : null,
            // dateToTrustee: values?.dateToTrustee,
            relevantIncomeIndicator: values?.relevantIncomeIndicator,
            // exportOptions: values?.exportOptions,
            // userFilePassword: values?.userFilePassword,
            exportOptions: values?.exportOptions, // Set exportOptions to 0
            userFilePassword: values?.userFilePassword,
          },

          zipOptionsDto: {
            exportToSingleZipFile: values?.exportToSingleZipFile,
            zipPassword: values?.zipPassword || '',
          },

          currentPayCycle: {
            year: values?.payCycleYear,
            month: values?.payCycleMonth?.label, // Extracting only the month label
            // codes: values?.payCycleCode?.label ? [values?.payCycleCode.label] : [], // Extracting only the code label and putting it in an array
            codes: values?.payCycleCode,
          },
          // previousPayCycle: {
          //   year: values?.ayCycleYear,
          //   month: values?.payCycleMonth,
          //   codes: values?.payCycleCode,
          // },

          employees: values?.excludeEmployees === 'Include' ? [...selectedCodes] : [],
          excludeEmployees: values?.excludeEmployees === 'Exclude' ? [...selectedCodes] : [],
          // departments: values?.departmentCodes || ['H033', 'H022'],
          // costCenters: Array.isArray(values?.costCenterCodes) ? values?.costCenterCodes : [values?.costCenterCodes],
          // costCenters: values?.costCenterCodes ? [values?.costCenterCodes] : [],
          costCenters: values?.costCenterCode,
          departments: values?.departmentCode,

        },
      ],
    }

    await createGeneratePayrollSlip(data)
  }

  const handleContinueClick = async (e: React.FormEvent) => {
    e.preventDefault()
    const schema = validationSchema(activeState)
    try {
      await schema.validate(values, { abortEarly: false })
      if (activeState === 2) {
        handleFormSubmit(e, handleSubmit)
        return
      }
      setActiveState((prevActiveState) => prevActiveState + 1)
    } catch (validationErrors) {
      if (validationErrors instanceof ValidationError) {
        const errors = validationErrors.inner.reduce((acc: Record<string, string>, error) => ({ ...acc, [error.path!]: error.message }), {})
        setErrors(errors)
      }
    }
  }

  return (
    <Box sx={{ display: 'flex' }}>
      <div
        style={{ display: 'flex', width: '100% ' }}
      >

        <OPRAlertControl
          customMessage="Payroll slip generation has been submitted.
          Please refer to the report listing for more information."
          customTitle="Payroll slip generation submitted"
          error={createdGeneratePayrollSlipError || updatedGeneratePayrollSlipError}
          handleEditable={setEditable}
          handleSetValue={setValues}
          handleSubmit={handleSubmit}
          isError={createdGeneratePayrollSlipIsError || updatedGeneratePayrollSlipIsError}
          isLoading={createdGeneratePayrollSlipLoading || updatedGeneratePayrollSlipLoading}
          isSuccess={createdGeneratePayrollSlipSuccess || updatedGeneratePayrollSlipSuccess}
          name=""
          title="Generate payroll slip"
          type={id ? 'Update' : 'New'}
        />
        <OPRInnerFormLayout
          isHandleContinueClick
          isStepper
          customHeader={(
            <OPRLabel label="Generate payroll slip" variant="h2" />
          )}
          error={createdGeneratePayrollSlipError || updatedGeneratePayrollSlipError}
          handleBack={() => { setActiveState(activeState - 1) }}
          handleCancelClick={() => navigate(-1)}
          handleContinueClick={handleContinueClick}
          handleEditable={setEditable}
          isBackButton={activeState > 0}
          isLoading={false}
          title="Generate Group 1"
          // pageType="detailsPage"
          //   previousPageUrl={routes.userRolesListing}
          // subtitle={
          //   isEditable
          //     ? 'Please check the user details below.'
          //     : 'Select specific group of employees to run payroll processing. All fields are mandatory except those marked optional.'
          // }
          // title={t('Run payroll')}
        >

          <Box>
            <OPRStepper
              activeStep={activeState}
              steps={[
                t('Filtering criteria'),
                t('Sorting & general criteria'),
                t('Export criteria'),

              ]}
            />
            <br />

            {activeState === 0 && (
              <FilteringCriteria
                isIndividualPage
                employees={employees}
                errors={errors}
                filterCriteria={filterCriteria}
                handleChange={handleChange}
                handleCheckboxChange={handleCheckboxChange}
                handleOnChange={handleOnChange}
                handleRemoveEmployee={handleRemoveEmployee}
                handleSelectAllChange={handleSelectAllChange}
                isEditable={isEditable}
                selectAll={selectAll}
                selectedCodes={selectedCodes}
                setFilterCriteria={setFilterCriteria}
                values={values}
              />
            )}
            {activeState === 1 && (
              <ReportOption
                errors={errors}
                handleChange={handleChange}
                handleCheckboxChange={handleCheckboxChange}
                handleOnChange={handleOnChange}
                handleRemoveEmployee={handleRemoveEmployee}
                handleSelectAllChange={handleSelectAllChange}
                isEditable={isEditable}
                selectAll={selectAll}
                selectedCodes={selectedCodes}
                values={values}
              />
            )}
            {activeState === 2 && (
              <ExportCriteria
                errors={errors}
                handleChange={handleChange}
                handleCheckboxChange={handleCheckboxChange}
                handleOnChange={handleOnChange}
                handleRemoveEmployee={handleRemoveEmployee}
                handleSelectAllChange={handleSelectAllChange}
                isEditable={isEditable}
                selectAll={selectAll}
                selectedCodes={selectedCodes}
                values={values}
              />
            )}
          </Box>
        </OPRInnerFormLayout>
      </div>
    </Box>
  )
}

export default PayrollSlipsForm
