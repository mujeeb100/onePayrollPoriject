import {
  Box,
} from '@mui/material'
import {
  useGeneratePayrollSlipDeleteMutation, useGetAllGeneratePayrollSlipQuery,
  useGetAllReportSlipModalQuery,
} from 'api/reports'
import { RightDirection } from 'assets/svg-images/SvgComponents'
import OPRButton from 'components/atoms/button/OPRButton'
import { CustomDialog } from 'components/atoms/modal/OPRModal'
import { payrollSlipColumn } from 'components/atoms/table/OPRTableConstant'
import { OPRInnerListLayout } from 'components/organism/OPRInnerLayoutList'
import { reportCodeType } from 'constants/index'
import { t } from 'i18next'
import React, { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { routes } from 'routes/routes'
import {
  generateFilterUrl,
} from 'utils'

function PayrollSlipList() {
  const [selectedId, setSelectedId] = useState(null)
  const navigate: any = useNavigate()
  const [isModalOpen, setIsModalOpen] = useState(false)
  const [steps, setSteps] = useState(0)
  const [isEditables, setIsEditables] = useState(false)

  const [filterData, setFilterData]:any = useState({
    pageNumber: 1,
    pageSize: 1000,
    totalItems: 0,
    orderByAsc: false,
    sortBy: '',
    SearchText: '',
    reportTypeCode: reportCodeType.PASP,

  })
  // const [reportData, setReportData]:any = useState({
  //   searchText: 'payslip',

  // })

  // const {
  //   data: allDownloadFile,
  //   error: createAllDownloadFileError,
  //   isLoading: isLoadingAllDownloadFile,
  //   isSuccess: isSuccessAllDownloadFile,
  //   isError: isErrorAllDownloadFile,
  //   error: errorAllDownloadFile,
  // } = useGetAllReportDownloadQuery()

  // const handleFileDownload :any = async (rowData: any) => {
  //   // Check if the necessary data is available
  //   if (allDownloadFile && allDownloadFile.data) {
  //     // Perform actions with the data here
  //     alert(allReportModal.data) // For example, log the data
  //   } else {
  //     alert('Error: Data not available for file download.')
  //   }
  // }
  // const handleFileDownload = async () => {
  //   await allDownloadFile()
  // }

  const {
    data: allPosts,
    error: createAllPostsBankAccountError,
    isLoading: isLoadingAllPosts,
    isSuccess: isSuccessAllPosts,
    isError: isErrorAllPosts,
    error: errorAllPosts,
  } = useGetAllGeneratePayrollSlipQuery(generateFilterUrl(filterData), {
    pollingInterval: 5000,
  })

  const {
    data: allReportModal,
    error: createAllReportModalBankAccountError,
    isLoading: isLoadingAllReportModal,
    isSuccess: isSuccessAllReportModal,
    isError: isErrorAllReportModal,
    error: errorAllReportModal,
  } = useGetAllReportSlipModalQuery(generateFilterUrl({
    searchText: 'payslip',
  }))

  const [deletePayrollSlipById,
    {
      data: deletePayrollSlipResponse,
      error: deletePayrollSlipError,
      isLoading: deletePayrollSlipLoading,
      isSuccess: deletePayrollSlipSuccess,
      isError: deletePayrollSlipIsError,
    }] = useGeneratePayrollSlipDeleteMutation()

  const sorting = (
    event: React.MouseEvent<unknown>,
    property: keyof any,
  ) => {
    const isAsc = filterData.sortBy === property && filterData.orderByAsc === true
    setFilterData({ ...filterData, orderByAsc: !isAsc, sortBy: property })
    // setOrder(isAsc ? 'desc' : 'asc')
    // setOrderBy(property)
  }

  useEffect(() => {
    setFilterData({ ...filterData, totalItems: allPosts?.totalItems ? allPosts?.totalItems : 0 })
  }, [allPosts?.pageNumber, filterData.sortBy, filterData.orderByAsc, allPosts?.totalItems])

  const onSearch = (e: any, data: any) => {
    setFilterData({ ...filterData, ...data })
  }
  const handlePagination = (pageNumber: number, pageSize: number) => {
    setFilterData({ ...filterData, pageNumber })
  }
  const viewAcoount = (data: any, type:string) => {

  }
  const handleView = (data:any) => {
    setIsModalOpen(true) // Open the modal when handleView is called
  }

  const handleClose = () => {
    setIsModalOpen(false) // Close the modal
  }

  const handleResume = () => {
    if (steps === 0) {
      setIsEditables(true)
      setSteps((prev) => prev + 1)
    } else if (steps === 1) {
      // handleSubmit()
      handleClose()
    } else {
      handleClose()
      // setValues({})
      setSteps(0)
    }
    navigate(routes.createPayrollSlip)
    // navigate(routes.createRunPayroll)
  }

  const handleRedirect = (reportTypeId: any) => {
    // Assuming the API page route is '/api/:reportId'
    navigate(routes.createPayrollSlip)
  }

  useEffect(() => {
    if (isSuccessAllPosts && allPosts && allPosts.records && allPosts.records.length > 0) {
      // Assuming you want to select the first item from allPosts
      setSelectedId(allPosts.records[0].id)
    }
  }, [isSuccessAllPosts, allPosts])

  // Set selectedId based on allReportModal data
  useEffect(() => {
    if (isSuccessAllReportModal && allReportModal && allReportModal.records && allReportModal.records.length > 0) {
      // Assuming you want to select the first item from allReportModal
      setSelectedId(allReportModal.records[0].id)
    }
  }, [isSuccessAllReportModal, allReportModal])

  return (
    <>
      <Box sx={{
        display: 'flex', justifyContent: 'space-between', flexDirection: 'row',
      }}
      >
        <Box sx={{
          display: 'flex', justifyContent: 'flex-start', alignItems: 'center', gap: '25px',
        }}
        />
        <Box sx={{
          display: 'flex', justifyContent: 'flex-start', height: 'fit-content',
        }}
        >
          <OPRButton
            color="primary"
            handleClick={handleView}
            style={{ borderRadius: '110px' }}
            variant="contained"
          >
            Generate payroll slip
          </OPRButton>
        </Box>
      </Box>
      <Box sx={{ display: 'flex' }}>
        {/* <PayrollSlipsForm /> */}
        <CustomDialog
          // isResume
          CustomStyles={{ borderRadius: '16px' }}
          closeTitle="cancel"
          handleBack={() => {
            setSteps((prev) => prev - 1)
            setIsEditables(false)
          }}
          handleClose={() => {
            handleClose()
            // setValues({})
            setIsEditables(false)
            setSteps(0)
          }}
          handleResume={handleResume}
          isBackButton={steps > 0}
          isOpen={isModalOpen}
          // resumeTitle={steps === 1 ? 'bulk_upload_data_continue' : 'Run payroll'}
          subtitle=""

        >

          <>
            {/* other JSX */}
            {isSuccessAllReportModal && (
              <GroupSelectionList reportModalData={JSON.parse(JSON.stringify(allReportModal?.records || []))} />
            )}
          </>

        </CustomDialog>
        <OPRInnerListLayout
          Search={filterData.SearchText}
          addHandleClick={() => navigate(routes.createPayrollSlip)}
          columns={payrollSlipColumn(viewAcoount)}
          dataList={JSON.parse(JSON.stringify(allPosts?.records || []))}
          error={errorAllPosts || deletePayrollSlipError}
          filterData={filterData}
          // handleFileDownload={handleFileDownload}
          handlePagination={handlePagination}
          handleSearch={onSearch}
          isAdd={false}
          isError={isErrorAllPosts || deletePayrollSlipIsError}
          loading={isLoadingAllPosts || deletePayrollSlipLoading}
          // rowClickHandler={handleView}
          // rowNumber={0}
          sortHandleClick={sorting}
          success={deletePayrollSlipSuccess}
          title={t('Payroll slips')}
        />
      </Box>
    </>
  )
}

export default PayrollSlipList

function GroupSelectionList({ reportModalData }: any) {
  const [selectedId, setSelectedId] = useState()

  const navigate: any = useNavigate()
  // const handleViewRecord = (data:any) => {
  //   // navigate(`${routes.createPayrollSlip}?id=${data.id}`)
  //   navigate(routes.createPayrollSlip, {
  //     state: { id: data.id },
  //   })
  // }
  const handleViewRecord = (data: any) => {
    navigate(`${routes.createPayrollSlip}`, { state: data })
  }

  return (
    <>
      <div>
        <div
          style={{
            width: '100%',
            color: '#3B3839',
            fontSize: 24,
            fontFamily: 'Lato',
            fontWeight: '700',
            wordWrap: 'break-word',
          }}
        >
          Select report
        </div>
        <div style={{ overflowY: 'scroll', height: 400 }}>
          {reportModalData.map((item: any, index: number) => (
            <div
              style={{
                width: '100%',
                justifyContent: 'flex-start',
                alignItems: 'center',
                gap: 16,
                display: 'inline-flex',
                borderBottom: '1px solid #E0E0E0',
              }}
            >
              <div
                style={{
                  flex: '1 1 0',
                  flexDirection: 'column',
                  justifyContent: 'flex-start',
                  alignItems: 'flex-start',
                  display: 'inline-flex',
                }}
              >
                <div
                  style={{
                    alignSelf: 'stretch',
                    paddingTop: 12,
                    paddingBottom: 12,
                    paddingLeft: 8,
                    justifyContent: 'flex-start',
                    alignItems: 'flex-start',
                    gap: 8,
                    display: 'inline-flex',
                  }}
                >
                  <div
                    style={{
                      flex: '1 1 0',
                      flexDirection: 'column',
                      justifyContent: 'flex-start',
                      alignItems: 'flex-start',
                      display: 'inline-flex',
                    }}
                  >
                    <div
                      style={{
                        alignSelf: 'stretch',
                        color: '#3B3839',
                        fontSize: 16,
                        fontFamily: 'Lato',
                        fontWeight: '700',
                        wordWrap: 'break-word',
                      }}
                    >
                      {item.reportName}
                    </div>
                    <div
                      style={{
                        alignSelf: 'stretch',
                        color: '#666364',
                        fontSize: 14,
                        fontFamily: 'Lato',
                        fontWeight: '400',
                        wordWrap: 'break-word',
                      }}
                    >
                      {item.reportName}
                    </div>
                  </div>
                </div>
              </div>
              <div
                style={{
                  fontSize: '12px',
                  borderRadius: '12px',
                  justifyContent: 'flex-start',
                  alignItems: 'flex-start',
                  gap: 16,
                  display: 'flex',
                  color: item.isStandard ? '#000000' : '#0000FF', // Black for Standard, Blue for Custom
                  background: item.isStandard ? '#E8E6E7' : '#E9F4FF',
                }}
              >
                {item.isStandard ? 'Standard' : 'Custom'}

              </div>
              <div
                style={{
                  justifyContent: 'flex-start',
                  alignItems: 'flex-start',
                  gap: 16,
                  display: 'flex',
                }}
              >
                <OPRButton color="secondary" variant="text" onClick={() => handleViewRecord(item)}>
                  <RightDirection />
                </OPRButton>

              </div>
            </div>
          ))}
        </div>
      </div>

      {/* <PayrollSlipsForm selectedId={selectedId} /> */}
    </>
  )
}
