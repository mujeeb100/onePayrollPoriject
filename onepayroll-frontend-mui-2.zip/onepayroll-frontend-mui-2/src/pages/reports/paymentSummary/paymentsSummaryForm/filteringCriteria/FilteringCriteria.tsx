import { Box, Divider, Grid } from '@mui/material'
import { useGetAllCompanyBankAccountQuery, useGetAllCostCenterQuery, useGetAllDepartmentQuery } from 'api/entityServices'
import {
  useGetAllPayCycleMasterDropDownQuery, useGetAllPayItemMasterQuery,
} from 'api/payRollServices'
import { EmpIcon, MenuKebab } from 'assets/svg-images/SvgComponents'
import OPRButton from 'components/atoms/button/OPRButton'
import OPRLabel from 'components/atoms/label/OPRLabel'
import { CustomDialog } from 'components/atoms/modal/OPRModal'
import OPRMultiSelect from 'components/atoms/multiSelectCheckbox/OPRMultiSelectCheckbox'
import OPRInputControl from 'components/molecules/OPRInputControl'
import OPRResponsiveGrid from 'components/molecules/OPRResponsiveGrid'
import OPRSearchIcon from 'components/molecules/OPRSearchIcon'
import OPRSelectorControl from 'components/molecules/OPRSelectorControl/OPRSelectorControl'
import CustomCheckbox from 'pages/employee/EmployeeCheckbox'
import { useState } from 'react'
import { useLocation, useNavigate } from 'react-router-dom'
import { routes } from 'routes/routes'
import { generateFilterUrl, getParamsValue } from 'utils'

interface Option {
  value: string; // Assuming value is of type string, adjust as necessary
  // Add other properties as needed
}

function FilteringCriteria({
  setErrors,
  selectedId, isFinalComponent, employees, selectedCodes, handleRemoveEmployee,
  handleCheckboxChange, handleSelectAllChange, selectAll, handleOnChange, errors, handleChange, isEditable, values, setValues, payCycleData, payCycleCodeList, // New prop
}:any) {
  const location: any = useLocation()
  const [selectedEmployeeCodes, setSelectedEmployeeCodes] = useState<string[]>([])
  const [isEmployeeModalOpen, setIsEmployeeModalOpen] = useState(false)
  const [empSearchData, setempSearchData] = useState({
    SearchText: '',
  })
  const [filterData, setFilterData]:any = useState({
    pageNumber: 1,
    pageSize: 20,
    totalItems: 0,
    orderByAsc: true,
    sortBy: '',
    SearchText: '',
  })
  const [valueDateError, setValueDateError] = useState('')
  const { viewUrl } = getParamsValue(location, routes.createPayCycleAdministration)

  const [isEditables, setIsEditables] = useState(false)
  // const [payCycleCodeList, setPayCycleCodeList] = useState([])
  const [status, setStatus] = useState<number[]>([]) // Array to hold statuses (3, 4, etc.)
  const [selectedPayCycleCodes, setSelectedPayCycleCodes] = useState([])
  const navigate = useNavigate()

  const {
    data: allCompanyBank,

  } = useGetAllCompanyBankAccountQuery(generateFilterUrl(filterData))

  const {
    data: allDepartment,
  } = useGetAllDepartmentQuery('')

  const departmentList = allDepartment?.records?.map((item:any) => ({
    name: `${item.departmentCode} - ${item.departmentDescription || ''}`,
    value: item.departmentCode,
  }))
  const {
    data: payCycleMonthDropdown,
  } = useGetAllPayCycleMasterDropDownQuery('')

  const monthOptions = payCycleMonthDropdown?.months?.map((month: any) => ({
    label: month.label, // Adjust this to use the correct property
    value: month.label, // Adjust this to use the correct property
  }))
  const {
    data: allPayItems,
  } = useGetAllPayItemMasterQuery('')

  const payItemsList = allPayItems?.records?.map((item:any) => ({
    name: `${item.payItemCode} - ${item.payItemName || ''}`,
    value: item.payItemCode,
  }))

  const {
    data: allCostCenter,
  } = useGetAllCostCenterQuery('')

  const costCenterList = allCostCenter?.records?.map((item:any) => ({
    name: `${item.costCenterCode} - ${item.costCenterDescription || ''}`,
    value: item.costCenterCode,
  }))

  const handleEmployeeSelection = (selectedCodes: string[]) => {
    setSelectedEmployeeCodes(selectedCodes)
  }
  const handleContinue = () => {
    // Handle continue button click, e.g., save data or perform any action
    handleEmployeeModalClose()
  }

  // Function to handle closing the employee modal
  const handleEmployeeModalClose = () => {
    setIsEmployeeModalOpen(false)
  }

  // Function to handle opening the employee modal
  const handleEmployeeModalOpen = () => {
    setIsEmployeeModalOpen(true)
  }
  const onSearch = (e: any) => {
    setempSearchData({ ...empSearchData, SearchText: e.target.value })
  }
  // Filter employees based on the search text
  const filteredEmployees = employees?.filter((employee: any) => employee?.employeeProfile?.displayName?.toLowerCase().includes(empSearchData?.SearchText?.toLowerCase()) || employee?.employeeCode?.toLowerCase().includes(empSearchData?.SearchText?.toLowerCase()))

  const selectedEmployees = selectedCodes?.map((code:any) => {
    const employee = employees?.find((emp:any) => emp.employeeCode === code)

    if (employee) {
      return (
        <Box
          key={code}
          style={{
            display: 'flex', alignItems: 'center', justifyContent: 'space-between', margin: '5px 20px',
          }}
        >
          <Box>
            <OPRLabel label={`${employee.employeeProfile.displayName} `} variant="subtitle2" />
            <OPRLabel label={employee.employeeCode} variant="body2" />
          </Box>

          <Box>
            <OPRButton variant="text" onClick={() => handleRemoveEmployee(code)}><MenuKebab /></OPRButton>
          </Box>
        </Box>
      )
    }

    return null
  })

  // Function to handle employee inclusion/exclusion based on dropdown selection
  const handleEmployeeInclusion = (selectedCodes: string[], includeExclude: string) => {
    if (includeExclude === 'Include') {
    // If 'Include' is selected, add the selected employees to the list
      const updatedSelectedEmployees = [...selectedEmployeeCodes, ...selectedCodes]
      setSelectedEmployeeCodes(updatedSelectedEmployees)
    } else if (includeExclude === 'Exclude') {
    // If 'Exclude' is selected, filter out the selected employees from the list
      const updatedSelectedEmployees = selectedEmployeeCodes.filter((code) => !selectedCodes.includes(code))
      setSelectedEmployeeCodes(updatedSelectedEmployees)
    }
  }

  const handleIncludeExcludeChangeAndOnChange = (fieldName: any, value: string) => {
    // Call handleIncludeExcludeChange function
    handleEmployeeInclusion(fieldName, value)

    // Call onChange event handler if it exists
    if (handleOnChange) {
      handleOnChange(fieldName, value)
    }
  }

  const handleCompanyBankAccountChange = (selectedOption: any) => {
    const selectedAccount = allCompanyBank?.records?.find(
      (option: any) => option?.companyBankAccountCode === selectedOption?.companyBankAccountCode,
    )
    if (!selectedAccount) return

    const valueDate = new Date(selectedAccount.valueDate)
    // Create a new date instance with the current date in local timezone
    const today = new Date()
    today.setHours(0, 0, 0, 0) // Ensure time part is set to 00:00:00 for comparison

    if (valueDate >= today) {
      setErrors((prevErrors: any) => ({
        ...prevErrors,
        companyBankAccountCode: '',
      }))
    } else {
      setErrors((prevErrors: any) => ({
        ...prevErrors,
        companyBankAccountCode: 'Value Date must be today or in the future.',
      }))
    }

    // Update all form values
    setValues((prevValues: any) => ({
      ...prevValues,
      companyBankAccountCode: selectedOption.companyBankAccountCode,
    }))
  }

  return (
    <div style={{ gap: 20, display: 'flex', flexDirection: 'column' }}>

      <div style={{
        width: '100%', color: '#3B3839', fontSize: 16, fontFamily: 'Lato', fontWeight: '400', wordWrap: 'break-word',
      }}
      >
        All fields are mandatory except those marked optional.
      </div>
      <div>
        <OPRResponsiveGrid>

          <Grid item md={2} sm={1} xs={1}>
            <OPRInputControl
              error={errors?.payCycleYear}
              isEditable={isEditable}
              label="Pay Year"
              name="payCycleYear"
              value={values?.payCycleYear}
              onChange={handleChange}
            />
          </Grid>

          {/* <Grid item md={2} sm={1} xs={1}>
            <OPRSelectorControl
              error={errors?.payCycleMonth}
              isEditable={isEditable}
              keyName="label"
              label="Pay Cycle Month"
              multiple={false}
              name="payCycleMonth"
              options={JSON.stringify(payCycleMonthDropdown?.months || [])}
              placeholder="Select an option"
              value={values?.payCycleMonth}
              valueKey="id"
              onChange={(text:any) => {
                handleOnChange('payCycleMonth', text)
              }}
            />
          </Grid> */}

          <Grid item md={2} sm={1} xs={1}>
            <OPRSelectorControl
              error={errors?.payCycleMonth}
              isEditable={isEditable}
              keyName="label"
              label="Pay Cycle Month"
              multiple={false}
              name="payCycleMonth"
              options={monthOptions || []}
              placeholder="Select an option"
              value={values?.payCycleMonth}
              valueKey="value"
              onChange={(selectedOption: any) => {
                handleOnChange('payCycleMonth', selectedOption)
              }}
            />
          </Grid>

          <Grid item md={2} sm={1} xs={1}>
            <OPRMultiSelect
              error={errors?.payCycleCode}
              label="Pay cycle code"
              name="payCycleCode"
              options={payCycleCodeList || []}
              placeholder="Select an option"
              value={values?.payCycleCode || []} // Ensure value is initialized as an array
              onChange={(selectedFormat: any) => {
                handleOnChange('payCycleCode', selectedFormat)
                setSelectedPayCycleCodes(selectedFormat) // Update state with selected codes
              }}
            />
          </Grid>

          <Grid item md={2} sm={1} xs={1}>
            <OPRSelectorControl
              error={errors.companyBankAccountCode}
              isEditable={isEditable}
              keyName="companyBankAccountCode"
              label="Company bank account"
              multiple={false}
              name="companyBankAccountCode"
              options={(allCompanyBank?.records || [])}
              placeholder="Select an option"
              value={(allCompanyBank?.records || []).find((option:any) => option.companyBankAccountCode === values?.companyBankAccountCode)}
              valueKey="companyBankAccountCode"
              onChange={handleCompanyBankAccountChange}
            />
          </Grid>

          <Grid item md={2} sm={1} xs={1}>
            <OPRMultiSelect
              error={errors?.departmentCode}
              label="Department"
              name="departmentCode"
              optionalText="Optional"
              options={departmentList || []}
              placeholder="Select an option"
              value={values?.departmentCode || []} // Ensure value is initialized as an array
              onChange={(selectedFormat) => {
                handleOnChange('departmentCode', selectedFormat)
              }}
            />
          </Grid>
          <Grid item md={2} sm={1} xs={1}>
            <OPRMultiSelect
              error={errors?.costCenterCode}
              label="Cost Center"
              name="costCenterCode"
              optionalText="Optional"
              options={costCenterList || []}
              placeholder="Select an option"
              value={values?.costCenterCode || []} // Ensure value is initialized as an array
              onChange={(selectedFormat) => {
                handleOnChange('costCenterCode', selectedFormat)
              }}
            />
          </Grid>

          <Grid item md={2} sm={1} xs={1}>
            <OPRMultiSelect
              error={errors?.payGroupCode}
              label="Pay Item"
              name="payGroupCode"
              optionalText="Optional"
              options={payItemsList || []}
              placeholder="Select an option"
              value={values?.payGroupCode || []} // Ensure value is initialized as an array
              onChange={(selectedFormat) => {
                handleOnChange('payGroupCode', selectedFormat)
              }}
            />
          </Grid>
          {/* <Grid item md={2} sm={1} xs={1}>
            <OPRSelectorControl
              error={errors?.payGroupCode}
              isEditable={isEditable}
              keyName="payGroupName"
              label="Pay Item"
              multiple={false}
              name="payGroupCode"
              optionalText="Optional"
              options={(allPayGroup?.records || [])}
              placeholder="Select an option"
              value={(allPayGroup?.records || [])?.find((o:any) => o?.payGroupCode === values?.PayItems) || null}
              valueKey="payGroupCode"
              onChange={(text:any) => {
                handleOnChange('PayItems', text?.payGroupCode)
                // setValues({ ...values, PayItems: text?.payGroupCode || '' })
              }}
            />
          </Grid> */}

          <Grid item md={2} sm={1} xs={1} />

          <div style={{ display: 'block', width: '100%', margin: '40px 20px 20px' }}>
            {isFinalComponent ? (
              <OPRLabel variant="h3">Employee</OPRLabel>

            ) : (
              <>
                <OPRLabel variant="h3">Employee</OPRLabel>
                <OPRLabel variant="body2">If no employee is selected, the system will process payroll for all employees for the selected pay cycles.</OPRLabel>
              </>
            )}
            <Box sx={{ display: 'block', justifyContent: 'space-between', marginTop: '20px' }}>
              <Grid item md={2} sm={1} xs={1}>
                <OPRSelectorControl
                  error={errors?.excludeEmployees} // Add error handling if needed
                  isEditable={isEditable}
                  keyName="IncExcName"
                  label="Include/Exclude"
                  multiple={false}
                  name="excludeEmployees"
                  options={[
                    { IncExcName: 'Include', IncExcValue: 'Include' },
                    { IncExcName: 'Exclude', IncExcValue: 'Exclude' },
                  ]}
                  placeholder="Select an option"
                  value={
                    { IncExcName: values?.excludeEmployees, IncExcValue: values?.excludeEmployees }
                  }
                  valueKey="IncExcValue"
                  onChange={(text: any) => {
                    handleIncludeExcludeChangeAndOnChange('excludeEmployees', text?.IncExcValue)
                  }}
                />
              </Grid>

            </Box>
            {/* Check if selectedEmployees array has any selected employees */}
            {selectedEmployees?.length > 0 ? (
            // Render only if there are selected employees
              selectedEmployees
            ) : (
            // Render the buttons if no employees are selected

              <Box sx={{ display: 'block', justifyContent: 'space-between', marginTop: '80px' }}>
                <Box
                  className="pop-up"
                  sx={{
                    display: 'flex',

                    gap: '12px',
                    alignItems: 'center',
                    borderRadius: '4px',
                    alignSelf: 'stretch',
                    justifyContent: 'center',
                    marginTop: 1,
                  }}
                >
                  <EmpIcon />
                  <OPRLabel variant="body2">

                    No employee is selected

                  </OPRLabel>
                </Box>

                {!isFinalComponent && ( // Render the button only if it's not the third component
                  <OPRButton
                    disabled={isFinalComponent && (selectedEmployeeCodes.length === 0 || selectedCodes.length > 0)}
                    sx={{ margin: '0px auto', display: 'flex' }}
                    variant="text"
                    onClick={handleEmployeeModalOpen}
                  >
                    Select Employee
                  </OPRButton>
                )}

              </Box>
            )}
          </div>
          {selectedCodes.length > 0 && (
            <div style={{
              borderRadius: '4px',
              background: '#E9F4FF',
              width: '100%',
              padding: '10px',
            }}
            >
              <OPRLabel
                variant="body2"
              >

                <>
                  Total selected employees:
                  {' '}
                  {selectedCodes.length}
                </>

              </OPRLabel>
            </div>
          )}
          <CustomDialog
            isResume
            closeTitle="Cancel"
            handleClose={handleEmployeeModalClose}
            handleResume={handleContinue} // Pass handleContinue here
            isOpen={isEmployeeModalOpen}
            resumeTitle="Continue"
            title="Select employee"
            onSelection={handleEmployeeSelection}
          >
            <Box>
              <OPRLabel CustomStyles={{ marginBottom: '15px' }} variant="body2">Search for an existing employee</OPRLabel>
              <OPRSearchIcon placeholder="Search " value={empSearchData.SearchText} onChange={onSearch} />
              <Divider />
            </Box>
            <Box sx={{ }}>
              <Box>
                <div>

                  {/* Pass handleEmployeeSelection as a prop to CustomCheckbox */}
                  <CustomCheckbox
                    employees={filteredEmployees}
                    handleCheckboxChange={handleCheckboxChange}
                    handleRemoveEmployee={handleRemoveEmployee}
                    handleSelectAllChange={handleSelectAllChange}
                    selectAll={selectAll}
                    selectedCodes={selectedCodes}
                    onChange={handleEmployeeSelection}
                  />
                </div>
              </Box>
            </Box>
          </CustomDialog>

        </OPRResponsiveGrid>
      </div>
    </div>
  )
}

export default FilteringCriteria
