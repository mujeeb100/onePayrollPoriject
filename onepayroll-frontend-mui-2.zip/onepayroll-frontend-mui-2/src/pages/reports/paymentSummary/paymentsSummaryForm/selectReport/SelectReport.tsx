import React from 'react'

import ReportGroupList from '../reportGroupComponent'

function SelectReport() {
  return (
    <div style={{ width: '100%' }}>
      <div style={{
        width: '100%', color: '#3B3839', fontSize: 16, fontFamily: 'Lato', fontWeight: '400', wordWrap: 'break-word',
      }}
      >
        Start by selecting at least 1 report
      </div>
      <br />
      <ReportGroupList />
    </div>
  )
}

export default SelectReport
