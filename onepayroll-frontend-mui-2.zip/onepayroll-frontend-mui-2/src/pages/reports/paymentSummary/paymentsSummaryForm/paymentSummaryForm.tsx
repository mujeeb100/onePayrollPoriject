import { Box } from '@mui/material'
import { useGetAllEmployeeProfileQuery } from 'api/employeeServices'
import { useGetAllPayCycleMasterQuery } from 'api/payRollServices'
import { usePaymentSummaryCreateMutation } from 'api/reports'
import OPRLabel from 'components/atoms/label/OPRLabel'
import OPRStepper from 'components/atoms/stepper'
import OPRAlertControl from 'components/organism/OPRAlertControl'
import { OPRInnerFormLayout } from 'components/organism/OPRInnerFormLayout'
import { validationSchemaPaymentSummary, validationSchemaPaymentSummary1 } from 'constants/validate'
import { useEditable } from 'hooks/useEdit'
import useForm from 'hooks/useForm'
import { t } from 'i18next'
import React, { useEffect, useRef, useState } from 'react'
import { useLocation, useNavigate } from 'react-router-dom'
import { routes } from 'routes/routes'
import { generateFilterUrl, getParamsValue } from 'utils'
import { ValidationError } from 'yup'

import ExportCriteria from './exportCriteria/ExportCriteria'
import FilteringCriteria from './filteringCriteria/FilteringCriteria'

const validationSchema = (activeStep:any) => {
  switch (activeStep) {
    case 0:
      return validationSchemaPaymentSummary
    case 1:
      return validationSchemaPaymentSummary1
    default:
      return validationSchemaPaymentSummary
  }
}

function PayrollSlipsForm({ selectedId }:any) {
  const myRef:any = useRef()
  const [activeState, setActiveState] = useState(0)
  const { isEditable, setEditable } = useEditable()
  const [employees, setEmployees]:any = useState([])
  const [selectAll, setSelectAll] = useState(false)
  const [selectedCodes, setSelectedCodes] = useState<string[]>([])
  const location: any = useLocation()
  const { id, viewUrl } = getParamsValue(location, routes.createUserRole)
  const [filterCriteria, setFilterCriteria] = useState({})

  const [payCycleData, setPayCycleData] = useState<any>([])
  const [selectedPayCycleCodes, setSelectedPayCycleCodes] = useState<any[]>([])
  const [payCycleCodeList, setPayCycleCodeList] = useState([])

  const { state } = location // Destructure state from location
  const {
    values,
    setValues,
    errors,
    handleChange,
    setErrors,
    handleFormSubmit,
    handleOnChange,
  } = useForm(validationSchema(activeState))
  const navigate = useNavigate()
  const {
    data: employeeDataList,
    isLoading: isLoadingEmployeeDataList,
    isSuccess: isSuccessEmployeeDataList,
    isError: isErrorEmployeeDataList,
    error: errorEmployeeDataList,
    refetch: refetchEmployeeDataList,
  } = useGetAllEmployeeProfileQuery(generateFilterUrl({
    EffectiveDate: '10/10/2040',
    pageSize: 10000,
  }))

  const [
    createPaymentSummary,
    {
      data: createdPaymentSummaryDataResponse,
      error: createdPaymentSummaryError,
      isLoading: createdPaymentSummaryLoading,
      isSuccess: createdPaymentSummarySuccess,
      isError: createdPaymentSummaryIsError,
    },
  ] = usePaymentSummaryCreateMutation()

  const {
    data: payCycleDataView,
    isLoading: isLoadingPayCycleData,
    isUninitialized: isUninitializedPayCycleData,
    isFetching: isFetchingPayCycleData,
    isSuccess: isSuccessPayCycleData,
    isError: isPayCycleDataError,
    error: payCycleDataError,
    refetch: refetchPayCycleData,
  } = useGetAllPayCycleMasterQuery(generateFilterUrl({
    yearFrom: values.payCycleYear,
    YearTo: values.payCycleYear,
    months: values?.payCycleMonth?.value,
    statuses: '3,4',
  }))

  useEffect(() => {
    if (values.payCycleYear && values.payCycleMonth) {
      refetchPayCycleData()
    }
  }, [values.payCycleYear, values.payCycleMonth, refetchPayCycleData])

  useEffect(() => {
    if (payCycleDataView) {
      const payCycleCodes = payCycleDataView?.records?.map((item:any) => ({
        name: item?.payCycleCode,
        value: item?.payCycleCode,
      }))
      setPayCycleCodeList(payCycleCodes)
    }
  }, [payCycleData])
  // distinct payCycle
  // useEffect(() => {
  //   if (payCycleDataView) {
  //     const uniquePayCycleCodes:any = Array.from(new Set(
  //       payCycleDataView.records.map((item: any) => item.payCycleCode), // Extract payCycleCode values
  //     )).map((code: any) => ({
  //       name: code,
  //       value: code,
  //     }))
  //     setPayCycleCodeList(uniquePayCycleCodes)
  //   }
  // }, [payCycleDataView])

  useEffect(() => {
    // Update selectedPayCycleCodes when payCycleData changes
    const selectedCodes = payCycleData
      .filter((item: any) => values.payCycleCode?.includes(item?.payCycleCode))
      .map((item: any) => item?.payCycleCode)
    setSelectedPayCycleCodes(selectedCodes)
  }, [payCycleData, values.payCycleCode])

  useEffect(() => {
    if (isSuccessPayCycleData) {
      setPayCycleData(payCycleDataView?.records || [])
    }
  }, [isSuccessPayCycleData, payCycleDataView])

  useEffect(() => {
    if (isSuccessEmployeeDataList) {
      setEmployees(JSON.parse(JSON.stringify(employeeDataList?.records || [])))
    }
  }, [isSuccessEmployeeDataList])

  const handleCheckboxChange = (event: React.ChangeEvent<HTMLInputElement>, code: string) => {
    const { checked } = event.target
    if (checked) {
      setSelectedCodes([...selectedCodes, code])
    } else {
      setSelectedCodes(selectedCodes.filter((selectedCode) => selectedCode !== code))
    }
  }
  const handleRemoveEmployee = (codeToRemove: string) => {
    // Filter out the selected employee code to remove it from the selectedCodes state
    setSelectedCodes(selectedCodes.filter((code) => code !== codeToRemove))
  }
  const handleSelectAllChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const { checked } = event.target
    if (checked) {
      setSelectedCodes(employees.map((employee:any) => employee.employeeCode))
    } else {
      setSelectedCodes([])
    }
    setSelectAll(checked)
  }

  const handleSubmit = async () => {
    const data = {
      reportRequirements: [
        {
          reportType: 'Payment Summary Report',
          // reportDesignId: location?.state?.id,
          CompanyBankAccountCode: values?.companyBankAccountCode,
          // valueDate: values?.ValueDate,
          GenerateInterfaceFile: values?.GenerateInterfaceFile,
          payslipPayrollDto: {
            sortingOption: values?.sortingOption,
          },
          exportOptionsDto: {
            exportFileFormat: parseInt(values?.exportFileFormat, 10),
            exportFileName: values?.exportFileName,
          },
          currentPayCycle: {
            year: values?.payCycleYear,
            month: values?.payCycleMonth?.label, // Extracting only the month label
            codes: values?.payCycleCode,
          },
          employees: values?.excludeEmployees === 'Include' ? [...selectedCodes] : [],
          excludeEmployees: values?.excludeEmployees === 'Exclude' ? [...selectedCodes] : [],
          // costCenters: values?.costCenterCodes ? [values?.costCenterCodes] : [],
          // departments: values?.departmentCodes ? [values?.departmentCodes] : [],
          costCenters: values?.costCenterCode,
          departments: values?.departmentCode,
          PayItems: values?.payGroupCode,

          // PayItems: Array.isArray(values?.payGroupCode) ? values?.payGroupCode : [values?.payGroupCode],

        },
      ],
    }

    await createPaymentSummary(data)
  }

  const handleContinueClick = async (e: React.FormEvent) => {
    e.preventDefault()
    const schema = validationSchema(activeState)
    try {
      await schema.validate(values, { abortEarly: false })
      if (activeState === 1) {
        handleFormSubmit(e, handleSubmit)
        return
      }
      setActiveState((prevActiveState) => prevActiveState + 1)
    } catch (validationErrors) {
      if (validationErrors instanceof ValidationError) {
        const errors = validationErrors.inner.reduce((acc, error) => ({ ...acc, [error.path!]: error.message }), {})
        setErrors(errors)
      }
    }
  }

  return (
    <Box sx={{ display: 'flex' }}>
      <div
        style={{ display: 'flex', width: '100% ' }}
      >

        <OPRAlertControl
          customMessage="Payment summary report generation has been submitted.
          Please refer to the report listing for more information."
          customTitle="Report generation submitted"
          error={createdPaymentSummaryError}
          handleEditable={setEditable}
          handleSetValue={setValues}
          handleSubmit={handleSubmit}
          isError={createdPaymentSummaryIsError}
          isLoading={createdPaymentSummaryLoading}
          isSuccess={createdPaymentSummarySuccess}
          name="generate report"
          title="Report generation "
          type={id ? 'Update' : 'New'}
        />
        <OPRInnerFormLayout
          isHandleContinueClick
          isStepper
          customHeader={(
            <OPRLabel label="Generate Payment Summary Report" variant="h2" />
          )}
          error={createdPaymentSummaryError}
          handleBack={() => { setActiveState(activeState - 1) }}
          handleCancelClick={() => navigate(-1)}
          handleContinueClick={handleContinueClick}
          handleEditable={setEditable}
          isBackButton={activeState > 0}
          isLoading={false}
          // pageType="detailsPage"
          // //   previousPageUrl={routes.userRolesListing}
          // subtitle={
          //   isEditable
          //     ? 'Please check the user details below.'
          //     : ''
          // }
          title="Generate Payment Summary Report"
        >

          <Box>
            <OPRStepper
              activeStep={activeState}
              steps={[
                t('Filtering criteria'),
                t('Report option'),

              ]}
            />
            <br />

            {activeState === 0 && (
              <FilteringCriteria
                isIndividualPage
                employees={employees}
                errors={errors}
                filterCriteria={filterCriteria}
                handleChange={handleChange}
                handleCheckboxChange={handleCheckboxChange}
                handleOnChange={handleOnChange}
                handleRemoveEmployee={handleRemoveEmployee}
                handleSelectAllChange={handleSelectAllChange}
                isEditable={isEditable}
                payCycleCodeList={payCycleCodeList}
                payCycleData={payCycleData} // Pass the pay cycle data
                selectAll={selectAll}
                selectedCodes={selectedCodes}
                setErrors={setErrors}
                setFilterCriteria={setFilterCriteria}
                setValues={setValues}
                values={values}

              />
            )}

            {activeState === 1 && (
              <ExportCriteria
                errors={errors}
                handleChange={handleChange}
                handleCheckboxChange={handleCheckboxChange}
                handleOnChange={handleOnChange}
                handleRemoveEmployee={handleRemoveEmployee}
                handleSelectAllChange={handleSelectAllChange}
                isEditable={isEditable}
                payCycleData={payCycleData} // Pass the pay cycle data
                selectAll={selectAll}
                selectedCodes={selectedCodes}
                selectedPayCycleCodes={selectedPayCycleCodes} // Pass the selected pay cycle codes
                setValues={setValues}
                values={values}

              />
            )}
          </Box>
        </OPRInnerFormLayout>
      </div>
    </Box>
  )
}

export default PayrollSlipsForm
