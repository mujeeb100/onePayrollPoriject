import {
  Button, Dialog, DialogActions, DialogContent, DialogContentText, DialogTitle, Grid,
} from '@mui/material'
import OPRMultiSelect from 'components/atoms/multiSelectCheckbox/OPRMultiSelectCheckbox'
import OPRResponsiveGrid from 'components/molecules/OPRResponsiveGrid'
import OPRSelectorControl from 'components/molecules/OPRSelectorControl/OPRSelectorControl'
import { useEffect, useState } from 'react'

function ExportCriteria({
  handleOnChange, errors, handleChange, isEditable, values, setValues, selectedPayCycleCodes, payCycleData, // New prop
}: any) {
  const [isYesEnabled, setIsYesEnabled] = useState(true)
  const [isNoEnabled, setIsNoEnabled] = useState(true)
  const [openDialog, setOpenDialog] = useState(false)

  useEffect(() => {
    const selectedStatuses = selectedPayCycleCodes.map((code: any) => {
      const payCycle = payCycleData.find((cycle: any) => cycle.payCycleCode === code)

      return payCycle ? payCycle.statusId : null
    }).filter((status: any) => status !== null)

    const hasStatus3 = selectedStatuses.includes(3) // locked status
    const hasStatus4 = selectedStatuses.includes(4) // finalized

    if (hasStatus3 && hasStatus4) {
      setIsYesEnabled(false)
      setIsNoEnabled(true)
      setValues((prevValues: any) => ({
        ...prevValues,
        GenerateInterfaceFile: false, // Automatically select 'No'
      }))
    } else if (hasStatus4) {
      setIsYesEnabled(true)
      setIsNoEnabled(false)
      setValues((prevValues: any) => ({
        ...prevValues,
        GenerateInterfaceFile: true, // Automatically select 'Yes'
      }))
    } else if (hasStatus3) {
      setIsYesEnabled(false)
      setIsNoEnabled(true)
      setValues((prevValues: any) => ({
        ...prevValues,
        GenerateInterfaceFile: false, // Automatically select 'No' if status 3 is present
      }))
    } else {
      setIsYesEnabled(true)
      setIsNoEnabled(true)
      setValues((prevValues: any) => ({
        ...prevValues,
        GenerateInterfaceFile: false, // Automatically select 'No' if neither status 3 nor status 4 is present
      }))
    }
  }, [selectedPayCycleCodes, payCycleData])
  const handleGenerateInterfaceFileChange = (text: any) => {
    if (text?.values === true && selectedPayCycleCodes.some((code: any) => {
      const payCycle = payCycleData.find((cycle: any) => cycle.payCycleCode === code)
      return payCycle ? payCycle.statusId === 3 : false
    })) {
      setOpenDialog(true) // Show dialog when user tries to select 'Yes' for locked status
      return
    }
    handleOnChange('GenerateInterfaceFile', text?.values)
  }

  const handleDialogClose = () => {
    setOpenDialog(false)
  }
  return (
    <div style={{ gap: 20, display: 'flex', flexDirection: 'column' }}>
      <div style={{
        width: '100%', color: '#3B3839', fontSize: 16, fontFamily: 'Lato', fontWeight: '400', wordWrap: 'break-word',
      }}
      >
        All fields are mandatory except those marked optional.
      </div>
      <div>
        <OPRResponsiveGrid>
          <Grid item md={2} sm={1} xs={1}>
            <OPRSelectorControl
              error={errors?.GenerateInterfaceFile}
              isEditable={isEditable}
              keyName="GenerateInterfaceFile"
              label="Generate interface file"
              multiple={false}
              name="GenerateInterfaceFile"
              options={[
                { GenerateInterfaceFile: 'Yes', values: true, disabled: !isYesEnabled },
                { GenerateInterfaceFile: 'No', values: false, disabled: !isNoEnabled },
              ]}
              placeholder="Select an option"
              value={[
                { GenerateInterfaceFile: 'Yes', values: true, disabled: !isYesEnabled },
                { GenerateInterfaceFile: 'No', values: false, disabled: !isNoEnabled },
              ]?.find((o) => o?.values === values?.GenerateInterfaceFile) || {}}
              valueKey="GenerateInterfaceFile"
              onChange={handleGenerateInterfaceFileChange}
            />
          </Grid>

          {/* <Grid item md={2} sm={1} xs={1}>
            <OPRSelectorControl
              error={errors?.exportFileFormat}
              isEditable={isEditable}
              keyName="ExportName"
              label="Export file format"
              multiple={false}
              name="ExportName"
              options={[
                { ExportName: 'PDF', ExportValue: 0 },
                { ExportName: 'Excel', ExportValue: 1 },

              ]}
              placeholder="Select an option"
              value={
                [
                  { ExportName: 'PDF', ExportValue: 0 },
                  { ExportName: 'Excel', ExportValue: 1 },
                ]?.find((o:any) => o?.ExportValue === values?.exportFileFormat) || {}
              }
              valueKey="ExportValue"
              onChange={(text:any) => {
                handleOnChange('exportFileFormat', text?.ExportValue)
              }}
            />
          </Grid> */}

          <Grid item md={2} sm={1} xs={1}>
            <OPRMultiSelect
              error={errors?.exportFileFormat}
              label="Export file format"
              name="exportOptions"
              options={[
                { name: 'PDF', value: '0' },
                { name: 'Formatted EXCEL', value: '1' },
                { name: 'EXCEL in raw format', value: '2' },
              ]}
              placeholder="Select an option"
              value={values?.exportFileFormat || []}
              onChange={(selectedFormat:any) => {
                handleOnChange('exportFileFormat', selectedFormat)
              }}
            />
          </Grid>
          {/*
          <Grid item md={2} sm={1} xs={1}>
            <OPRSelectorControl
              error={errors?.exportOptions}
              isEditable={isEditable}
              keyName="ExportName"
              label="Rounding option"
              multiple={false}
              name="exportOptions"
              options={[

                { ExportName: 'RoundNearest(No decimal)', ExportValue: 'RoundNearest(No decimal)' },
                { ExportName: 'Round Down(No decimal)', ExportValue: 'Excel' },
                { ExportName: 'Round Up(No decimal)', ExportValue: 'Round Up(No decimal)' },
                { ExportName: 'Round Nearest(1 decimal)', ExportValue: 'Round Nearest(1 decimal)' },
                { ExportName: 'Round Down(1 decimal)', ExportValue: 'Round Down(1 decimal)' },
                { ExportName: 'Round Up(1 decimal)', ExportValue: 'Round Up(1 decimal)' },

              ]}
              placeholder="Select an option"
              value={
                { ExportName: values?.exportOptions, ExportValue: values?.exportOptions }
              }
              valueKey="ExportValue"
              onChange={(text:any) => {
                handleOnChange('exportOptions', text?.ExportValue)
              }}
            />
          </Grid> */}

          <Grid item md={2} sm={1} xs={1}>
            <OPRSelectorControl
              error={errors?.sortingOption} // Add error handling if needed
              isEditable={isEditable}
              keyName="SortName"
              label="Employee sorting order"
              multiple={false}
              name="sortingOption"
              optionalText="Optional"
              options={[
                { SortName: 'Employee Code', SortValue: 'Employee Code' },
                { SortName: 'Employee Name', SortValue: 'Employee Name' },
                { SortName: 'Department Code', SortValue: 'Department Code' },
                { SortName: 'Cost Center Code', SortValue: 'Cost Center Code' },
                { SortName: 'Commencement Date', SortValue: 'Commencement Date' },
              ]}
              placeholder="Select an option"
              value={
                { SortName: values?.sortingOption, SortValue: values?.sortingOption }
              }
              valueKey="SortValue"
              onChange={(text: any) => {
                handleOnChange('sortingOption', text?.SortValue)
              }}
            />
          </Grid>
        </OPRResponsiveGrid>
      </div>
      <Dialog open={openDialog} onClose={handleDialogClose}>
        <DialogTitle>Warning</DialogTitle>
        <DialogContent>
          <DialogContentText>
            User is not allowed to choose "Yes" for a locked pay cycle code.
          </DialogContentText>
        </DialogContent>
        <DialogActions>
          <Button color="primary" onClick={handleDialogClose}>
            OK
          </Button>
        </DialogActions>
      </Dialog>
    </div>
  )
}

export default ExportCriteria
