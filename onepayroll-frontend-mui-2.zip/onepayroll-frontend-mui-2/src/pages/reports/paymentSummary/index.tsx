import {
  Box,
} from '@mui/material'
import {
  useGeneratePayrollSlipDeleteMutation,
  useGetAllGeneratePayrollSlipQuery,
} from 'api/reports'
import OPRButton from 'components/atoms/button/OPRButton'
import { payrollSlipColumn } from 'components/atoms/table/OPRTableConstant'
import { OPRInnerListLayout } from 'components/organism/OPRInnerLayoutList'
import { reportCodeType } from 'constants/index'
import React, { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { routes } from 'routes/routes'
import {
  generateFilterUrl,
} from 'utils'

function PaymentSummaryList() {
  const navigate: any = useNavigate()
  const [isModalOpen, setIsModalOpen] = useState(false)
  const [steps, setSteps] = useState(0)
  const [isEditables, setIsEditables] = useState(false)

  const [filterData, setFilterData]:any = useState({
    pageNumber: 1,
    pageSize: 20,
    totalItems: 0,
    orderByAsc: false,
    sortBy: '',
    SearchText: '',
    reportTypeCode: reportCodeType.PASR,

  })
  // const entityId = '9cd7e909-ba68-4fa1-b205-117891f51b64'
  // const id = '1f32d7c2-7cdf-482d-bdb4-b9b187a6ffb4'
  // const generationRef = '20240424052517'

  // // Define the parameters object in the desired format
  // const parameters = {
  //   id,
  //   entityId,
  //   generationRef,
  // }

  // // Generate the filter URL using the parameters
  // const filterUrl = generateFilterUrl(parameters)

  // // Use the filter URL in the query hook
  // const {
  //   data: allDownloadFile,
  //   error: createAllDownloadFileError,
  //   isLoading: isLoadingAllDownloadFile,
  //   isSuccess: isSuccessAllDownloadFile,
  //   isError: isErrorAllDownloadFile,
  //   error: errorAllDownloadFile,
  // } = useGetAllReportDownloadQuery(filterUrl)

  // // Download file function
  // const handleFileDownload = (rowData: any) => {
  //   try {
  //     // Check if allPosts contains the necessary data
  //     if (allDownloadFile && allDownloadFile.data) {
  //       // Extract the downloadUrl from the rowData or any other relevant source
  //       // For example, if rowData contains the downloadUrl directly
  //       const { downloadUrl } = rowData // Adjust this according to your data structure

  //       // Ensure the downloadUrl is valid
  //       if (downloadUrl) {
  //         // Open the downloadUrl in a new window/tab to trigger the download
  //         window.open(downloadUrl)
  //       } else {
  //         alert('Error: Download URL is missing.')
  //       }
  //     } else {
  //       alert('Error: No data available for file download.')
  //     }
  //   } catch (error) {
  //     console.error('Error downloading file:', error)
  //     // Handle errors, show error message, etc.
  //   }
  // }

  const {
    data: allPosts,
    error: createAllPostsBankAccountError,
    isLoading: isLoadingAllPosts,
    isSuccess: isSuccessAllPosts,
    isError: isErrorAllPosts,
    error: errorAllPosts,
  } = useGetAllGeneratePayrollSlipQuery(generateFilterUrl(filterData), {
    pollingInterval: 5000,
  })

  const [deletePaymentSummaryById,
    {
      data: deletePaymentSummaryResponse,
      error: deletePaymentSummaryError,
      isLoading: deletePaymentSummaryLoading,
      isSuccess: deletePaymentSummarySuccess,
      isError: deletePaymentSummaryIsError,
    }] = useGeneratePayrollSlipDeleteMutation()

  const sorting = (
    event: React.MouseEvent<unknown>,
    property: keyof any,
  ) => {
    const isAsc = filterData.sortBy === property && filterData.orderByAsc === true
    setFilterData({ ...filterData, orderByAsc: !isAsc, sortBy: property })
    // setOrder(isAsc ? 'desc' : 'asc')
    // setOrderBy(property)
  }

  useEffect(() => {
    setFilterData({ ...filterData, totalItems: allPosts?.totalItems ? allPosts?.totalItems : 0 })
  }, [allPosts?.pageNumber, filterData.sortBy, filterData.orderByAsc, allPosts?.totalItems])

  const onSearch = (e: any, data: any) => {
    setFilterData({ ...filterData, ...data })
  }
  const handlePagination = (pageNumber: number, pageSize: number) => {
    setFilterData({ ...filterData, pageNumber })
  }
  const viewAcoount = (data: any, type:string) => {

  }
  const handleView = (data:any) => {
    navigate(`${routes.createPaymentSummary}`)
  }

  return (
    <>
      <Box sx={{
        display: 'flex', justifyContent: 'space-between', flexDirection: 'row',
      }}
      >
        <Box sx={{
          display: 'flex', justifyContent: 'flex-start', alignItems: 'center', gap: '25px',
        }}
        />
        <Box sx={{
          display: 'flex', justifyContent: 'flex-start', height: 'fit-content',
        }}
        >
          <OPRButton
            color="primary"
            handleClick={handleView}
            style={{ borderRadius: '110px' }}
            variant="contained"
          >
            Generate report
          </OPRButton>
        </Box>
      </Box>
      <Box sx={{ display: 'flex' }}>

        <OPRInnerListLayout
          Search={filterData.SearchText}
          addHandleClick={() => navigate(routes.createPaymentSummary)}
          columns={payrollSlipColumn(viewAcoount)}
          dataList={JSON.parse(JSON.stringify(allPosts?.records || []))}
          error={errorAllPosts || deletePaymentSummaryError}
          filterData={filterData}
          // handleFileDownload={handleFileDownload}
          handlePagination={handlePagination}
          handleSearch={onSearch}
          isAdd={false}
          isError={isErrorAllPosts || deletePaymentSummaryIsError}
          loading={isLoadingAllPosts || deletePaymentSummaryLoading}
          sortHandleClick={sorting}
          success={deletePaymentSummarySuccess}
          title="Payment summary reports"
        />
      </Box>
    </>
  )
}

export default PaymentSummaryList
