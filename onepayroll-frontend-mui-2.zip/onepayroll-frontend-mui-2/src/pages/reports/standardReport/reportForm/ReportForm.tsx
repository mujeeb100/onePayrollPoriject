import { useGetAllPensionFundSchemeQuery } from 'api/entityServices'
import { useGetAllStandardReportGroupQuery, useStandardReportCreateMutation, useStandardReportUpdateMutation } from 'api/reports'
import OPRLabel from 'components/atoms/label/OPRLabel'
import OPRStepper from 'components/atoms/stepper'
import OPRAlertControl from 'components/organism/OPRAlertControl'
import { OPRInnerFormLayout } from 'components/organism/OPRInnerFormLayout'
import { standardReportValidationSchema } from 'constants/validate'
import { useEditable } from 'hooks/useEdit'
import useForm from 'hooks/useForm'
import { t } from 'i18next'
import { useEffect, useState } from 'react'
import { useLocation } from 'react-router-dom'
import { routes } from 'routes/routes'
import { generateFilterUrl, getParamsGenerateReport } from 'utils'

import {
  dataTransformation,
  exportCriteriaCallBack, filterCriteriaCallBack, filterDataUpdate, filterObjectsByIDs, findSchemTypeForValidation,
  transformedData,
  transformedDataGRP4,
} from './data'
import ExportCriteria from './exportCriteria/ExportCriteria'
import FilteringCriteria from './filteringCriteria/FilteringCriteria'
import GenerateReport from './generateReport/GenerateReport'
import ReportGroupList from './reportGroupComponent'
import ReportOption from './reportOption/ReportOption'
import {
  arraysMatchReportTypeCode,
  checkMPFValidation, groupCode1, groupCode2, groupCode3, groupCode4, handleFinalSubmit, schemaExportCriteria, useStateWithCallback,
} from './reportOption/validate'

function ReportForm() {
  const custom = true
  const [selectedCodes, setSelectedCodes]:any = useState<string[]>([])
  const [selectAll, setSelectAll]:any = useState(false)
  const [activeState, setActiveState] = useState(0)
  const { isEditable, setEditable } = useEditable()
  const [filterCriteria, setFilterCriteria] = useState({})
  const [exportCriteria, setExportCriteria]:any = useState({})
  const [exportCriteriaError, setExportCriteriarror]:any = useStateWithCallback({})
  const [rowData, setRowData] = useState<any>(null)
  const [reportOptionError, setReportOptionError]:any = useStateWithCallback({})
  // const [reportOptionError, setReportOptionError]:any = useState(0)
  const [dataList, setdataList]:any = useStateWithCallback({
    reportRequirements: [],
  })
  const location: any = useLocation()
  const checkValidation = () => {
    if (exportCriteria?.exportToSingleZipFile && !exportCriteria?.zipPassword) {
      setExportCriteriarror({ ...exportCriteriaError, zipPassword: 'required' })
      return
    }
    if (exportCriteria?.exportToSingleZipFile && !exportCriteria?.zipFileName) {
      setExportCriteriarror({ ...exportCriteriaError, zipFileName: 'required' })
      return
    }
    setExportCriteria({})
  }
  const handleExportCriteriaSubmit:any = (schema:any, values:any, successCallback:any) => {
    schema
      .validate(values, { abortEarly: false })
      .then(() => {
        setExportCriteriarror({})
        successCallback(values)
      })
      .catch(async (err:any) => {
        if (err.name === 'ValidationError') {
          const errs = await schema.validate(values, { abortEarly: false }).catch((err:any) => {
            const errors = err.inner.flatMap((e:any) => ({ [e.path]: e.errors[0] })).reduce((result:any, current:any) => Object.assign(result, current), {})
            return errors
          // Update form errors state:
          })
          setExportCriteriarror(errs)
        }
      })
  }
  useEffect(() => {
    console.log(handleExportCriteriaSubmit(schemaExportCriteria, exportCriteria, () => {
    }))
  }, [exportCriteria?.zipPassword, exportCriteria?.zipFileName])

  const { id, viewUrl } = getParamsGenerateReport(location, routes.standardReportsGenerate)

  // const [refetchAllPosts, {
  //   data: allReportModal,
  //   error: createAllReportModalBankAccountError,
  //   isLoading: isLoadingAllReportModal,
  //   isSuccess: isSuccessAllReportModal,
  //   isError: isErrorAllReportModal,
  //   error: errorAllReportModal,
  // }] = useGetAllReportSlipModalQuery()
  // const [
  //   refetchAllPosts1,
  //   {
  //     data: allPosts1,
  //     isLoading: isLoadingAllPosts1,
  //     isSuccess: isSuccessAllPosts1,
  //     isError: isErrorAllPosts1,
  //     error: errorAllPosts1,
  //   },
  // ] = useGetAllReportSlipModalQuery()

  const {
    data: allPosts,
    error: createAllPostsBankAccountError,
    isLoading: isLoadingAllPosts,
    isSuccess: isSuccessAllPosts,
    isError: isErrorAllPosts,
    error: errorAllPosts,
  } = useGetAllStandardReportGroupQuery(`&isTemplate=${viewUrl}&groupId=${id}`)

  const {
    data: allPostsSchemNumber,
    isLoading: isLoadingAllPostsSchemNumber,
    isSuccess: isSuccessAllPostsSchemNumber,
    isError: isErrorAllPostsSchemNumber,
    error: errorAllPostsSchemNumber,
    refetch: refetchAllPostsSchemNumber,
  } = useGetAllPensionFundSchemeQuery(generateFilterUrl(''))

  const [createStandardReport, {
    data: createdStandardReportData,
    error: createdStandardReportError,
    isLoading: createdStandardReportLoading,
    isSuccess: createdStandardReportSuccess,
    isError: createdStandardReportIsError,
  }] = useStandardReportCreateMutation()
  const [updateStandardReport, {
    data: updateStandardReportData,
    error: updateStandardReportError,
    isLoading: updateStandardReportLoading,
    isSuccess: updateStandardReportSuccess,
    isError: updateStandardReportIsError,
  }] = useStandardReportUpdateMutation()
  const {
    values,
    setValues,
    errors,
    handleChange,
    setErrors,
    handleFormSubmit,
  } = useForm(standardReportValidationSchema)
  useEffect(() => {
    // if (viewUrl) {
    //   setExportCriteria({
    //     ...rowData[0].zipOptionsDto, ...rowData[0].exportOptionsDto,
    //   })
    // }
  }, [])
  useEffect(() => {
    if (isSuccessAllPosts) {
      if (allPosts?.records[0]?.code === 'GRP4') {
        if (viewUrl) {
          const data = allPosts?.records[0] || []
          const singleValueArray = data?.reportRequirements?.map((obj:any, index:any) => obj.reportType)
          const transferData = transformedData(allPosts?.records[0]?.reportTypes)
          data.reportTypes = transferData

          setdataList(data)
          setSelectedCodes(singleValueArray)
          // checking purpose
          setSelectAll(true)
        } else {
          const data:any = allPosts?.records[0] || []
          const transferData = transformedDataGRP4(allPosts?.records[0]?.reportTypes)
          // data.reportTypes = transferData

          setdataList(dataTransformation({ ...data, reportTypes: transferData }))
        }
      } else if (viewUrl) {
        const data = allPosts?.records[0] || []
        const singleValueArray = data?.reportRequirements?.map((obj:any) => obj.reportType)

        setdataList(allPosts?.records[0] || [])
        setSelectedCodes(singleValueArray)
        // checking purpose
        setSelectAll(true)
      } else {
        setdataList(dataTransformation(allPosts?.records[0] || []))
      }
    }
  }, [isSuccessAllPosts])

  useEffect(() => {
    if (dataList.reportRequirements?.length === selectedCodes?.length && isSuccessAllPosts) {
      setSelectAll(true)
    } else {
      setSelectAll(false)
    }
  }, [selectedCodes])
  useEffect(() => {
    if (activeState === 0 && isSuccessAllPosts) {
      if (allPosts?.records[0]?.code === 'GRP4') {
        if (viewUrl) {
          const data = allPosts?.records[0] || []
          const singleValueArray = data?.reportRequirements?.map((obj:any) => obj.reportType)
          const transferData = transformedData(allPosts?.records[0]?.reportTypes)

          data.reportTypes = transferData

          setdataList(data)
          setSelectedCodes(singleValueArray)
          // checking purpose
          setSelectAll(true)
        } else {
          const data:any = allPosts?.records[0] || []
          const transferData = transformedData(allPosts?.records[0]?.reportTypes)
          // data.reportTypes = transferData

          setdataList(dataTransformation({ ...data, reportTypes: transferData }))
        }
      } else if (viewUrl) {
        const data = allPosts?.records[0] || []
        const singleValueArray = data?.reportRequirements?.map((obj:any) => obj.reportType)

        setdataList(allPosts?.records[0] || [])
        setSelectedCodes(singleValueArray)
        // checking purpose
        setSelectAll(true)
      } else {
        setdataList(dataTransformation(allPosts?.records[0] || []))
      }
    }
  }, [activeState])

  // useEffect(() => {
  //   if (allPosts?.records[0]?.code === 'GRP4') {
  //     setdataList(dataTransformation(allPosts?.records[0] || [], allPosts?.records[0]?.code))
  //   }
  // }, [])

  const saveTemplate = (data:any) => {
    setdataList(data)
  }
  const validatReport = () => {

  }

  const areAllValuesTrue:any = (obj:any) => Object.values(obj).every((value:any) => value.isValidate === true)
  const errorSetUp = (error:any) => {
    const { length } = Object.keys(reportOptionError)
    setReportOptionError({ ...reportOptionError, ...error }, (newState:any) => {
    })
    // if (error.isValidate && length === 1) {
    //   setActiveState(activeState + 1)
    // }
  }
  const handleSingleReportError = (key:any, value:any) => {
    // const data = error
    setReportOptionError({
      ...reportOptionError,
      [key]: value || {
        isValidate: true,
      },
    })
  }

  const successCallback = (data:any) => {
    setActiveState(activeState + 1)
  }
  const dataViewFilter = dataList?.reportRequirements?.map((item:any) => item.code)
  useEffect(() => {
    if (viewUrl) {
      const object = dataViewFilter?.reduce((acc:any, currentValue:any) => {
        acc[currentValue] = { isValidate: true }
        return acc
      }, {})
      setReportOptionError(object)
    } else {
      const object = dataViewFilter?.reduce((acc:any, currentValue:any) => {
        if (currentValue.trim() === 'PFRS') {
          acc[currentValue] = { isValidate: true }
        } else {
          acc[currentValue] = { isValidate: false }
        }
        return acc
      }, {})
      setReportOptionError(object)
    }
  }, [dataList?.reportRequirements?.length])

  const submitReport = () => {
    if (activeState === 0) {
      const filteredObjects = filterObjectsByIDs(dataList?.reportRequirements, selectedCodes, allPosts?.records[0]?.code)

      if (selectedCodes.length > 0) {
        const { currentPayCycle, previousPayCycle }:any = dataList.reportRequirements[0]

        if (arraysMatchReportTypeCode(groupCode1, dataViewFilter)) {
          setValues({
            payCycleYearFrom: previousPayCycle?.year,
            payCycleYearTo: currentPayCycle?.year,
            payCycleMonthFrom: previousPayCycle?.month,
            payCycleMonthTo: currentPayCycle?.month,
            payCycleCode: previousPayCycle?.codes,
          })
        }
        if (arraysMatchReportTypeCode(groupCode2, dataViewFilter)) {
          setValues({
            payCycleYearFrom: '2024',
            payCycleYearTo: currentPayCycle?.year,
            payCycleMonthFrom: '04',
            payCycleMonthTo: currentPayCycle?.month,
            payCycleCode: currentPayCycle?.codes,
          })
        }
        if (arraysMatchReportTypeCode(groupCode3, dataViewFilter)) {
          setValues({
            payCycleYearFrom: previousPayCycle?.year,
            payCycleYearTo: currentPayCycle?.year,
            payCycleMonthFrom: previousPayCycle?.month,
            payCycleMonthTo: currentPayCycle?.month,
            payCycleCode: previousPayCycle?.codes,
            payCycleCodeCurrent: currentPayCycle.codes,
          })
        }
        if (arraysMatchReportTypeCode(groupCode4, dataViewFilter)) {
          setValues({
            payCycleYearFrom: '2024',
            payCycleYearTo: currentPayCycle?.year,
            payCycleMonthFrom: '04',
            payCycleMonthTo: currentPayCycle?.month,
            payCycleCode: ['01'],
          })
        }

        // }
        setdataList({ ...dataList, reportRequirements: filteredObjects }, () => {
          setActiveState(activeState + 1)
        })
      }
      // setActiveState(activeState + 1)
    }
    // allPosts?.records[0]?.code
    if (activeState === 1) {
      const newFilter = filterCriteriaCallBack(values, dataViewFilter)

      const data = filterDataUpdate(dataList?.reportRequirements, newFilter)
      const { zipOptionsDto, exportOptionsDto } = dataList.reportRequirements[0]
      setExportCriteria({
        ...zipOptionsDto, ...exportOptionsDto,
      })

      setdataList({ ...dataList, reportRequirements: data }, (newData:any) => {
        if (arraysMatchReportTypeCode(groupCode4, dataViewFilter)) {
          setActiveState(activeState + 2)
        } else {
          setActiveState(activeState + 1)
        }
      })
    }
    if (activeState === 2) {
      const newExport = exportCriteriaCallBack(exportCriteria)
      const data = filterDataUpdate(dataList?.reportRequirements, newExport)

      setdataList({ ...dataList, reportRequirements: data }, (newData:any) => {
        const dataValidate = newData?.reportRequirements?.find((o:any) => (o?.reportType === 'MPF Remittance Statement'))?.mpfRemittanceStatement

        const scheamNumberType:any = findSchemTypeForValidation(JSON.parse(JSON.stringify(allPostsSchemNumber?.records || [])), dataValidate?.schemeType === 'MPF' ? 'MC' : dataValidate?.schemeType)?.map((item:any) => ({
          schemeFileNumber: item.schemeFileNumber,
          serviceProviderCode: item.serviceProviderCode,
        })) || []
        const dataTypeSelected = scheamNumberType?.find((o:any) => (o?.schemeFileNumber === dataValidate?.schemeFileNumber))
        const newValidateData = newData.reportRequirements?.map((item:any) => {
          const data = {
            ...item,
            ...item.mpfRemittanceStatement,
            includeZeroDifference: item?.payrollComparisionDto?.includeZeroDifference,
            serviceProviderCode: dataTypeSelected?.serviceProviderCode,
          }

          return data
        })

        handleFinalSubmit(newValidateData, errorSetUp, successCallback, reportOptionError)
        const isValid = Object.keys(reportOptionError).length === 0 ? false : Object.values(reportOptionError).every((subObj:any) => subObj.isValidate === true)
        let dataListValidation:any
        if (checkMPFValidation.includes(dataTypeSelected?.serviceProviderCode)) {
          dataListValidation = {
            ...reportOptionError,
            PFRS: { isValidate: false },
          }
        } else {
          dataListValidation = {
            ...reportOptionError,
          }
        }

        // if (isValid && checkFields(reportOptionError, dataViewFilter)) {
        //   setActiveState(activeState + 1)
        // }
      })
      // const isValid = Object.keys(reportOptionError).length === 0 ? false : Object.values(reportOptionError).every((subObj:any) => subObj.isValidate === true)
      // if (isValid && checkFields(reportOptionError, dataViewFilter, dataTypeSelected?.serviceProviderCode)) {
      //   setActiveState(activeState + 1)
      // }

      // setActiveState(activeState + 1)
    }

    if (activeState === 3) {
      const newExport = exportCriteriaCallBack(exportCriteria)
      const data = filterDataUpdate(dataList?.reportRequirements, newExport)
      if (arraysMatchReportTypeCode(groupCode4, dataViewFilter)) {
        const newExport = exportCriteriaCallBack(exportCriteria)
        const data = filterDataUpdate(dataList?.reportRequirements, newExport)
        setdataList({ ...dataList, reportRequirements: data }, (newData:any) => {
          handleFinalSubmit(newData.reportRequirements, errorSetUp, successCallback, reportOptionError)
        })
      } else {
        setdataList({ ...dataList, reportRequirements: data })
      }
      handleExportCriteriaSubmit(schemaExportCriteria, exportCriteria, () => {
        setActiveState(activeState + 1)
      })
    }
    if (activeState === 4) {
      if (viewUrl) {
        updateStandardReport({ ...dataList, grpCode: allPosts?.records[0]?.code })
      } else {
        createStandardReport({ ...dataList, grpCode: allPosts?.records[0]?.code })
      }
    }
    // if (activeState === 0) {
    //   setActiveState(activeState + 2)
    // }
  }

  const htmString = '<div className="InsertContent" style={{width: \'100%\'}}><span style="color: \'#3B3839\', fontSize: 16, fontFamily: \'Lato\', fontWeight: \'400\', lineHeight: 24, wordWrap: \'break-word\'">Report generation has been submitted.<br/></span><span style="color: \'#3B3839\', fontSize: 16, fontFamily: \'Lato\', fontWeight: \'400\', lineHeight: 24, wordWrap: \'break-word\'">Payroll Summary Report<br/>Payroll Summary Report by Cost Center<br/>Payroll Summary Report by Charge Cost Center<br/>MPF Remittance Statement<br/>ORSO Contribution Listing<br/></span><span style="color: \'#3B3839\', fontSize: 16, fontFamily: \'Lato\', fontWeight: \'400\', lineHeight: 24, wordWrap: \'break-word\'">Please refer to the report listing for more information.</span></div>'
  // const plainString = htmString.replace(/<[^>]+>/g, '')
  const generateReportContent = (dataList:any) => `
      <div class="InsertContent" style="width: 100%;">
        <span style="
          color: #3B3839;
          font-size: 16px;
          font-family: Lato;
          font-weight: 400;
          line-height: 2;
          word-wrap: break-word;
        ">
          Report generation has been submitted.
          <br />
        </span>
        <span style="
          color: #3B3839;
          font-size: 16px;
          font-family: Lato;
          font-weight: 400;
          line-height: 2;
          word-wrap: break-word;
        ">
          ${dataList?.reportRequirements?.map((item:any) => `
            <span class="bullet-symbol">• </span>${item.reportType}<br />
          `).join('')}
        </span>
        <span style="
          color: #3B3839;
          font-size: 16px;
          font-family: Lato;
          font-weight: 400;
          word-wrap: break-word;
        ">
          Please refer to the report listing for more information.
        </span>
      </div>
    `

  const listItem = (dataList:any) => `
  <span style="
      color: #3B3839;
      font-size: 16px;
      font-family: Lato;
      font-weight: 400;
      line-height: 2;
      word-wrap: break-word;
    ">
      ${dataList?.reportRequirements?.map((item:any) => `
        ${item.reportType}<br />
      `).join('')}
    </span>`

  const plainString = listItem(dataList).replace(/<[^>]+>/g, '')
  return (
    <>
      {/* {plainString} */}
      {/* {sucssesScreen()} */}
      <OPRAlertControl
        callBack={(type) => {
        }}
        customMessage={generateReportContent(dataList)}
        error={createdStandardReportError}
        handleEditable={setEditable}
        handleSetValue={setValues}
        isError={createdStandardReportError}
        isLoading={createdStandardReportLoading || updateStandardReportLoading}
        isSuccess={createdStandardReportSuccess || updateStandardReportSuccess}
        name={values?.StandardReportName}
        title="Standard Report"
        type={id ? 'Update' : 'New'}
      />
      <OPRInnerFormLayout
        isHandleContinueClick
        isStepper
        customHeader={(
          <OPRLabel label={allPosts?.records[0]?.name} variant="h2" />
        )}
        error={false}
        handleBack={() => {
          setActiveState(activeState - 1)
        }}
        handleCancelClick={() => () => {
        }}
        handleContinueClick={(e:any) => {
          if (activeState === 1) {
            handleFormSubmit(e, submitReport)
          } else {
            submitReport()
          }
        }}
        handleEditable={setEditable}
        isBackButton={activeState > 0}
        isLoading={false}
        showbottomButton={false}
        title="Generate Group 1"
      // pageType="detailsPage"
      //   previousPageUrl={routes.userRolesListing}
      // subtitle={
      //   isEditable
      //     ? 'Please check the user details below.'
      //     : ''
      // }
      >
        <OPRStepper
          activeStep={activeState}
          steps={[
            t('Select report'),
            t('Filtering criteria'),
            t('Report option'),
            t('Export criteria'),
            t('Generate report'),
          ]}
        />
        <br />
        {/* {
          activeState === 2 && (
            <>

              <div
                className="LabelCopy"
                style={{
                  width: '100%', color: '#7D7B7C', fontSize: 14, fontFamily: 'Lato', fontWeight: '400', lineHeight: 3, wordWrap: 'break-word',
                }}
              >
                Report selected
              </div>
              {plainString}
              <br />
            </>
          )
        } */}
        {activeState === 0 && (
          <ReportGroupList
            dataList={dataList?.reportRequirements}
            groupType={allPosts?.records[0]?.code}
            rowDataList={dataList}
            selectAll={selectAll}
            selectedCodes={selectedCodes}
            setSelectAll={setSelectAll}
            setSelectedCodes={setSelectedCodes}
            setdataList={setdataList}
          />
        )}
        {activeState === 1 && (
          <FilteringCriteria
            errors={errors}
            filterCriteria={values}
            groupType={dataViewFilter}
            setFilterCriteria={setValues}
          />
        )}
        {activeState === 2 && (
          <ReportOption
            dataList={dataList || []}
            groupType={dataViewFilter}
            handleChangeError={handleSingleReportError}
            handleReportOption={setdataList}
            listItem={dataList.reportRequirements}
            reportOptionError={reportOptionError}
          />
        )}
        {activeState === 3 && (
          <ExportCriteria
            errors={exportCriteriaError}
            exportCriteria={exportCriteria}
            setExportCriteria={setExportCriteria}
          />
        )}
        {activeState === 4 && (
          <GenerateReport dataList={dataList} handleReportGenerate={saveTemplate} isNewtemplate={viewUrl} />
        )}
      </OPRInnerFormLayout>
    </>
  )
}

export default ReportForm
