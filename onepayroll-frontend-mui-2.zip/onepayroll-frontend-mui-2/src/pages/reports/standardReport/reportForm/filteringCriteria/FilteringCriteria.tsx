import { Grid } from '@mui/material'
import { useGetAllPayCycleMasterDropDownQuery } from 'api/payRollServices'
import OPRMultiSelect from 'components/atoms/multiSelectCheckbox/OPRMultiSelectCheckbox'
import OPRResponsiveGrid from 'components/molecules/OPRResponsiveGrid'
import OPRSelectorControl from 'components/molecules/OPRSelectorControl/OPRSelectorControl'
import { useState } from 'react'

import {
  arraysMatchReportTypeCode, groupCode1, groupCode2, groupCode3, groupCode4,
} from '../reportOption/validate'

function FilteringCriteria({
  filterCriteria, setFilterCriteria, errors, groupType,
}:any) {
  const [group, setGroup] = useState([1, 2, 3, 4])
  const {
    data: payCycleMasterDropdown,
  }:any = useGetAllPayCycleMasterDropDownQuery('')
  const handleChange = (key:any, value:any) => {
    setFilterCriteria((prev:any) => ({
      ...prev,
      [key]: value,
    }))
  }
  const yearDataList = payCycleMasterDropdown?.payCycleYear?.map((item:any) => ({
    label: item,
    value: item,
  }))
  const monthDataList = payCycleMasterDropdown?.months?.map((item:any) => ({
    label: item.label,
    value: item.label,
  }))
  const payCycleCodeList = payCycleMasterDropdown?.payCycleMasterCodeDtos?.map((item:any) => ({
    name: item?.id,
    value: item?.label?.toString(),
  }))
  // const payCycleValue = filterCriteria?.payCycleCode?.map((item:any) => ({
  //   name: item?.label,
  //   value: item?.id?.toString(),
  // }))
  // console.log(allPosts, 'payCycleCodeList', payCycleCodeList || [])

  return (
    <div style={{ gap: 20, display: 'flex', flexDirection: 'column' }}>
      {/* <div style={{
        width: '100%', color: '#3B3839', fontSize: 16, fontFamily: 'Lato', fontWeight: '400', wordWrap: 'break-word',
      }}
      >
        Payroll Summary Report, Payroll Summary Report by Cost Center, Payroll Summary Report by Charge Cost Center, MPF Remittance Statement, ORSO Contribution Listing
      </div> */}
      <div style={{
        width: '100%', color: '#3B3839', fontSize: 16, fontFamily: 'Lato', fontWeight: '400', wordWrap: 'break-word',
      }}
      >
        All fields are mandatory except those marked optional.
      </div>
      <div>
        <OPRResponsiveGrid>
          {
            (arraysMatchReportTypeCode(groupCode1, groupType) || arraysMatchReportTypeCode(groupCode3, groupType)) && (
              <Grid item md={2} sm={1} xs={1}>
                <OPRSelectorControl
                  isRequired
                  error={errors?.payCycleYearFrom}
                  // isEditable={isEditable}
                  keyName="label"
                  label="Pay cycle - From year"
                  multiple={false}
                  name="label"
                  options={yearDataList || []}
                  value={yearDataList?.find((o:any) => o?.value === filterCriteria?.payCycleYearFrom)}
                  valueKey="value"
                  onChange={(text:any) => {
                    handleChange('payCycleYearFrom', text?.value)
                  }}
                />
              </Grid>
            )
          }

          {(arraysMatchReportTypeCode(groupCode1, groupType) || arraysMatchReportTypeCode(groupCode3, groupType) || arraysMatchReportTypeCode(groupCode4, groupType)) && (
            <Grid item md={2} sm={1} xs={1}>
              <OPRSelectorControl
                isRequired
                error={errors?.payCycleYearTo}
                keyName="label"
                label="Pay cycle - To year"
                multiple={false}
                name="label"
                options={yearDataList || []}
                value={yearDataList?.find((o:any) => o?.value === filterCriteria?.payCycleYearTo)}
                valueKey="value"
                onChange={(text:any) => {
                  handleChange('payCycleYearTo', text?.value)
                }}
              />
            </Grid>
          )}
          { arraysMatchReportTypeCode(groupCode2, groupType) && (
            <Grid item md={2} sm={1} xs={1}>
              <OPRSelectorControl
                isRequired
                error={errors?.payCycleYearTo}
                keyName="label"
                label="Pay cycle - Year"
                multiple={false}
                name="label"
                options={yearDataList || []}
                value={yearDataList?.find((o:any) => o?.value === filterCriteria?.payCycleYearTo)}
                valueKey="value"
                onChange={(text:any) => {
                  handleChange('payCycleYearTo', text?.value)
                }}
              />
            </Grid>
          )}
          {
            (arraysMatchReportTypeCode(groupCode1, groupType) || arraysMatchReportTypeCode(groupCode3, groupType)) && (
              <Grid item md={2} sm={1} xs={1}>
                <OPRSelectorControl
                  isRequired
                  error={errors?.payCycleMonthFrom}
                  // isEditable={isEditable}
                  keyName="label"
                  label="Pay cycle - From Month"
                  multiple={false}
                  name="label"
                  options={monthDataList || []}
                  value={monthDataList?.find((o:any) => o?.value === filterCriteria?.payCycleMonthFrom)}
                  valueKey="label"
                  onChange={(text:any) => {
                    handleChange('payCycleMonthFrom', text?.label)
                  }}
                />
              </Grid>
            )
          }

          {arraysMatchReportTypeCode(groupCode3, groupType) && <Grid item md={2} sm={1} xs={1} />}
          {(arraysMatchReportTypeCode(groupCode1, groupType) || arraysMatchReportTypeCode(groupCode3, groupType) || arraysMatchReportTypeCode(groupCode1, groupType) || arraysMatchReportTypeCode(groupCode4, groupType)) && (
            <Grid item md={2} sm={1} xs={1}>
              <OPRSelectorControl
                isRequired
                error={errors?.payCycleMonthTo}
                // isEditable={isEditable}
                keyName="label"
                label="Pay cycle - To month"
                multiple={false}
                name="label"
                options={monthDataList || []}
                value={monthDataList?.find((o:any) => o?.value === filterCriteria?.payCycleMonthTo)}
                valueKey="value"
                onChange={(text:any) => {
                  handleChange('payCycleMonthTo', text?.value)
                }}
              />
            </Grid>
          )}

          {arraysMatchReportTypeCode(groupCode2, groupType) && (
            <Grid item md={2} sm={1} xs={1}>
              <OPRSelectorControl
                isRequired
                error={errors?.payCycleMonthTo}
                // isEditable={isEditable}
                keyName="label"
                label="Pay cycle - Month"
                multiple={false}
                name="label"
                options={monthDataList || []}
                value={monthDataList?.find((o:any) => o?.value === filterCriteria?.payCycleMonthTo)}
                valueKey="value"
                onChange={(text:any) => {
                  handleChange('payCycleMonthTo', text?.value)
                }}
              />
            </Grid>
          )}
          {/* <Grid item md={2} sm={1} xs={1}>
            <OPRSelectorControl
              isRequired
              error={errors?.payCycleCode}
              // isEditable={isEditable}
              keyName="payCycleCode"
              label="Pay cycle code"
              multiple={false}
              name="payCycleCode"
              options={allPosts?.records || []}
              value={allPosts?.records?.find((o:any) => o?.payCycleCode === filterCriteria?.payCycleCode) && null}
              valueKey="payCycleCode"
              onChange={(text:any) => {
                handleChange('payCycleCode', text?.payCycleCode)
              }}
            />
          </Grid> */}
          {!arraysMatchReportTypeCode(groupCode4, groupType) && (
            <Grid item md={2} sm={1} xs={1}>
              <OPRMultiSelect
                error={errors?.payCycleCode}
                label="Pay cycle code"
                name="payCycleCode"
                options={payCycleCodeList || []}
                placeholder="Select an option"
                value={filterCriteria?.payCycleCode || []} // Ensure value is initialized as an array
                onChange={(selectedFormat) => {
                  handleChange('payCycleCode', selectedFormat)
                // setFilterCriteria({
                //   ...filterCriteria,
                //   payCycleCode: selectedFormat,
                // })
                }}
              />
            </Grid>
          )}

          {(arraysMatchReportTypeCode(groupCode3, groupType)) && (
            <Grid item md={2} sm={1} xs={1}>
              <OPRMultiSelect
                error={errors?.payCycleCodeCurrent}
                label="Previous pay cycle code"
                name="payCycleCode"
                options={payCycleCodeList || []}
                placeholder="Select an option"
                value={filterCriteria?.payCycleCodeCurrent || []} // Ensure value is initialized as an array
                onChange={(selectedFormat) => {
                  handleChange('payCycleCodeCurrent', selectedFormat)
                // setFilterCriteria({
                //   ...filterCriteria,
                //   payCycleCode: selectedFormat,
                // })
                }}
              />
            </Grid>
          )}

        </OPRResponsiveGrid>
      </div>
    </div>
  )
}

export default FilteringCriteria
