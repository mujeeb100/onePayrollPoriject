import {
  arraysMatchReportTypeCode, groupCode1, groupCode2, groupCode3,
  groupCode4,
} from './reportOption/validate'

export const reportData = [
  {
    consolidateOption: 1,

    entityId: '9CD7E909-BA68-4FA1-B205-117891F51B64',
    exportOptionsDto: {
      exportFileFormat: 0,
      paperOrientation: 0,
      paperSize: 1,
    },
    groupingOptings: 2,
    includeAllActiveEmployees: false,
    currentPayCycle: {
      year: '2023',
      month: '02',
      codes: [
        '01',
      ],
    },
    previousPayCycle: {
      year: '2023',
      month: '01',
      codes: [
        '01',
      ],
    },
    reportDesignId: '4c0a73ad-bdaa-42bd-857e-acf334ed1fb4',
    reportType: 'Payroll Summary Report by Charge Cost Center',
    zipOptionsDto: {
      exportToSingleZipFile: false,
      zipFileName: 'demo',
      zipPassword: 'demozip',
    },
  },
  {
    entityId: '9CD7E909-BA68-4FA1-B205-117891F51B64',
    reportType: 'Payment Summary Report by Cost Center',
    reportDesignId: '3E52B06Dgt-3353-4171-92E5-6162DC1353E1',
    exportOptionsDto: {
      paperSize: 1,
      paperOrientation: 0,
      exportFileFormat: 0,
      ExportFileName: 'PS16April2024Eao',
    },
    currentPayCycle: {
      year: '2023',
      month: '02',
      codes: [
        '01',
      ],
    },
    previousPayCycle: {
      year: '2023',
      month: '01',
      codes: [
        '01',
      ],
    },
    ConsolidateOption: 1,
    IncludeAllActiveEmployees: false,
    GroupingOptings: 0,

  },
  {
    entityId: '9CD7E909-BA68-4FA1-B205-117891F51B64',
    reportType: 'Payment Summary Report',
    reportDesignId: '3E52B06D-hh3353-4171-92E5-6162DC1353E1',
    exportOptionsDto: {
      paperSize: 1,
      paperOrientation: 0,
      exportFileFormat: 0,
      ExportFileName: 'PS16April2024Eao',
    },
    currentPayCycle: {
      year: '2023',
      month: '02',
      codes: [
        '01',
      ],
    },
    previousPayCycle: {
      year: '2023',
      month: '01',
      codes: [
        '01',
      ],
    },
    ConsolidateOption: 2,
    IncludeAllActiveEmployees: false,
    GroupingOptings: 0,
  },
  {
    entityId: '9CD7E909-BA68-4FA1-B205-117891F51B64',
    reportType: 'MPF Remittance Statement',
    reportDesignId: '91f4281c-9f61-46c5-b8ab-cca2ce379788',
    mpfRemittanceStatementDto: null,
    exportOptionsDto: {
      paperSize: 0,
      paperOrientation: 0,
      exportFileFormat: 0,
    },
    currentPayCycle: {
      year: '2023',
      month: '02',
      codes: [
        '01',
      ],
    },
    previousPayCycle: {
      year: '2023',
      month: '01',
      codes: [
        '01',
      ],
    },
    employees: [],
    excludeEmployees: [],
  },
  {
    entityId: '9CD7E909-BA68-4FA1-B205-117891F51B64',
    reportType: 'EAO Wages Report',
    reportDesignId: '3E52B06D-3353-4171-92E5-6162DC1353E1',
    exportOptionsDto: {
      paperSize: 1,
      paperOrientation: 0,
      exportFileFormat: 0,
      ExportFileName: 'PS16April2024Eao',
    },
    currentPayCycle: {
      year: '2023',
      month: '02',
      codes: [
        '01',
      ],
    },
    previousPayCycle: {
      year: '2023',
      month: '01',
      codes: [
        '01',
      ],
    },
    IncludeAllActiveEmployees: false,
  },
  {
    entityId: '9CD7E909-BA68-4FA1-B205-117891F51B64',
    reportType: 'OSRO Contribution Listing',
    reportDesignId: 'A1EC975C-017C-4D80-8D53-271218F29BBB',
    payslipPayrollDto: {
      pensionFundSchemes: null,
      exchangeRate: 2.5,
    },
    exportOptionsDto: {
      paperSize: 0,
      paperOrientation: 0,
      exportFileFormat: 0,
    },
    currentPayCycle: {
      year: '2023',
      month: '02',
      codes: [
        '01',
      ],
    },
    previousPayCycle: {
      year: '2023',
      month: '01',
      codes: [
        '01',
      ],
    },
    employees: [],
    excludeEmployees: [],
  },
]

export const exportFileFormate = [{ name: 'Excel Formatted', value: 1 }, { name: 'Excel Raw Data', value: 2 }, { name: 'PDF', value: 0 }]
export const paperSize = [{ name: 'Default', value: 0 }, { name: 'A3', value: 1 }, { name: 'A4', value: 0 }]
export const paperOrientation = [{ name: 'Default', value: 0 }, { name: 'Landscape', value: 1 }, { name: 'Portait', value: 0 }]
export const exportToSingleFile = [{ name: 'Yes', value: true }, { name: 'No', value: false }]

export const filterCriteriaCallBack = (filterCriteriaData:any, groupType:any) => {
  const {
    payCycleYearFrom, payCycleYearTo, payCycleMonthFrom, payCycleMonthTo, payCycleCode, payCycleCodeCurrent,
  } = filterCriteriaData

  let filterCriteria:any
  if (arraysMatchReportTypeCode(groupCode1, groupType)) {
    filterCriteria = {
      currentPayCycle: {
        year: payCycleYearTo,
        month: payCycleMonthTo,
        codes: payCycleCode,
      },
      previousPayCycle: {
        year: payCycleYearFrom,
        month: payCycleMonthFrom,
        codes: payCycleCode,
      },
    }
  }
  if (arraysMatchReportTypeCode(groupCode2, groupType)) {
    filterCriteria = {
      currentPayCycle: {
        year: payCycleYearTo,
        month: payCycleMonthTo,
        codes: payCycleCode,
      },
      previousPayCycle: {
        year: '',
        month: '',
        codes: [],
      },
    }
  }
  if (arraysMatchReportTypeCode(groupCode3, groupType)) {
    filterCriteria = {
      currentPayCycle: {
        year: payCycleYearTo,
        month: payCycleMonthTo,
        codes: payCycleCodeCurrent,
      },
      previousPayCycle: {
        year: payCycleYearFrom,
        month: payCycleMonthFrom,
        codes: payCycleCode,
      },
    }
  }
  if (arraysMatchReportTypeCode(groupCode4, groupType)) {
    filterCriteria = {
      currentPayCycle: {
        year: payCycleYearTo,
        month: payCycleMonthTo,
      },
    }
  }
  return filterCriteria
}

export const exportCriteriaCallBack = (exportCriteriaData:any) => {
  const {
    exportFileFormat, paperSize, paperOrientation, customFileNameToBeAppended, exportToSingleZipFile,
    fileNameToBeAppended, exportFileName, zipPassword, zipFileName,
  } = exportCriteriaData
  const exportCriteria = {
    zipOptionsDto: {
      exportToSingleZipFile,
      zipFileName,
      zipPassword,
    },
    exportOptionsDto: {
      paperSize,
      paperOrientation,
      exportFileFormat,
      exportFileName,
      fileNameToBeAppended,
      customFileNameToBeAppended,
    },
  }

  return exportCriteria
}

export const reportGroupData = {
  code: 'ABC',
  name: 'Template 1',
  saveTemplate: true,
  reportRequirements: [

  ],
}

export function filterObjectsByIDs(arrayOfObjects:any, arrayOfIDs:any, grpCode:any) {
  return arrayOfObjects?.filter((obj:any) => arrayOfIDs?.includes(grpCode === 'GRP4' ? obj.designName : obj.reportType))
}

export const filterDataUpdate = (data:any, newFilter:any) => {
  const filteredObjects = data?.map((obj:any) => ({ ...obj, ...newFilter }))
  return filteredObjects
}

export const filterDataPredifned = (data:any, newFilter:any) => {
  const filteredObjects = data.map((obj:any) => ({ ...obj, ...newFilter }))
  return filteredObjects
}

export const dataDefault = (grpCode:any) => {
  const data = {
    exportOptionsDto: {
      paperSize: 0,
      paperOrientation: 0,
      exportFileFormat: 0,
      ExportFileName: '',
    },
    zipOptionsDto: {
      exportToSingleZipFile: false,
      zipFileName: '',
      zipPassword: '',
    },
    currentPayCycle: {
      year: '',
      month: '',
      codes: null,
    },
    previousPayCycle: {
      year: '',
      month: '',
      codes: null,
    },
    // previousPayCycleCode: null,
    consolidateOption: null,
    includeAllActiveEmployees: null,
    groupingOptings: null,

  }
  return data
}

export const dataTransformation:any = (dataList:any, grpCode:any) => {
  const modifiedData = {
    ...dataList,
    reportRequirements: dataList?.reportTypes?.map((item:any) => {
      const data = {
        ...item,
        ...dataDefault(grpCode),
        reportType: item.name,
      }
      delete data.name
      return data
    }),
    code: '',
    name: '',
  }
  delete modifiedData.reportTypes
  return modifiedData
}

const typeOfGroup = () => {

}

// Transform the data for customereport
export const transformedData = (data:any) => data?.map((reportType:any) => reportType?.reportDesigns?.map((design:any) => ({
  id: reportType.id,
  code: reportType.code,
  name: reportType.name,
  isStandard: reportType.isStandard,
  designId: design.id,
}))).flat()

export const transformedDataGRP4 = (data:any) => data?.map((reportType:any) => reportType?.reportDesigns?.map((design:any) => ({
  id: reportType.id,
  code: reportType.code,
  name: reportType.name,
  isStandard: reportType.isStandard,
  designName: design.reportName,
  designId: design.id,
}))).flat()
console.log(transformedData)

export function findSchemTypeForValidation(array:any, type:any) {
  return array.filter((obj:any) => obj.schemeType === type)
}
