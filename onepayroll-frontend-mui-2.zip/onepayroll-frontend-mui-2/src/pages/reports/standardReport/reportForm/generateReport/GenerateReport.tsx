import { Grid } from '@mui/material'
import OPRInputControl from 'components/molecules/OPRInputControl'
import OPRResponsiveGrid from 'components/molecules/OPRResponsiveGrid'
import React from 'react'

function GenerateReport({ dataList, handleReportGenerate, isNewtemplate }:any) {
  const handleGenerateReport = (e:any) => {
    const data = {
      ...dataList,
      saveTemplate: e,
    }
    handleReportGenerate(data)
    // handleGenerateReport(data)
  }
  return (
    <div style={{ gap: 20, display: 'flex', flexDirection: 'column' }}>
      <div style={{
        width: '100%', color: '#3B3839', fontSize: 16, fontFamily: 'Lato', fontWeight: '400', wordWrap: 'break-word',
      }}
      >
        Start by selecting at least 1 report
      </div>
      <div style={{
        width: '100%', height: '100%', justifyContent: 'flex-start', alignItems: 'flex-start', gap: 8, display: 'inline-flex',
      }}
      >
        <div style={{
          paddingTop: 1, paddingBottom: 1, justifyContent: 'flex-start', alignItems: 'center', display: 'flex',
        }}
        >
          <input
            checked={dataList.saveTemplate}
            type="checkbox"
            value={dataList.saveTemplate}
            onChange={(event) => {
              handleGenerateReport(event.target.checked)
            }}
          />
        </div>
        <div style={{
          flex: '1 1 0', flexDirection: 'column', justifyContent: 'flex-start', alignItems: 'flex-start', gap: 4, display: 'inline-flex',
        }}
        >
          <div style={{
            alignSelf: 'stretch', justifyContent: 'flex-start', alignItems: 'flex-start', gap: 8, display: 'inline-flex',
          }}
          >
            <div style={{
              flex: '1 1 0', color: '#3B3839', fontSize: 14, fontFamily: 'Lato', fontWeight: '700', wordWrap: 'break-word',
            }}
            >
              Save as template
            </div>
          </div>
          <div style={{
            alignSelf: 'stretch', justifyContent: 'flex-start', alignItems: 'center', gap: 8, display: 'inline-flex',
          }}
          >
            <div style={{
              flex: '1 1 0', color: '#666364', fontSize: 14, fontFamily: 'Lato', fontWeight: '400', wordWrap: 'break-word',
            }}
            >
              Save this report as a template group for future reuse.
            </div>
          </div>
        </div>

      </div>
      { (dataList.saveTemplate && !isNewtemplate) && (
        <OPRResponsiveGrid>
          <Grid item md={2} sm={1} xs={1}>
            <OPRInputControl
            // error={errors?.exchangeRate}
              isEditable={false}
              label="Template ID"
              name="code"
              value={dataList.code}
              onChange={(text:any) => {
                const data = {
                  ...dataList,
                  code: text?.target.value,
                }
                handleReportGenerate(data)
              // handleOnChange('yearOfServiceOption', text?.value)
              }}
            />

          </Grid>
          <Grid item md={2} sm={1} xs={1}>
            <OPRInputControl
            // error={errors?.exchangeRate}
              isEditable={false}
              label="Template name"
              name="name"
              value={dataList.name}
              onChange={(text:any) => {
                const data = {
                  ...dataList,
                  name: text?.target.value,
                }
                handleReportGenerate(data)
              // handleOnChange('yearOfServiceOption', text?.value)
              }}
            />

          </Grid>
        </OPRResponsiveGrid>
      )}
    </div>
  )
}

export default GenerateReport
