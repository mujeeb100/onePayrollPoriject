import { Checkbox } from '@mui/material'
import { useGetAllSettingsQuery } from 'api/entityServices'
import OPRSelectorControl from 'components/molecules/OPRSelectorControl/OPRSelectorControl'
import { t } from 'i18next'
import React, { useEffect, useState } from 'react'
import { generateFilterUrl } from 'utils'

interface CustomCheckboxProps {
    employees?: any[];
    selectedCodes?: string[];
    handleSelectAllChange?: any;
    selectAll?: boolean;
    setSelectedCodes?:any;
  }
function ReportGroupList({
  dataList, selectedCodes, selectAll, setSelectedCodes, setSelectAll, groupType, setdataList, rowDataList,
}:any) {
  const [checkDisable, setcheckDisabled]:any = useState(false)
  const handleCheckboxChange = (event: React.ChangeEvent<HTMLInputElement>, code: string) => {
    const { checked } = event.target
    if (checked) {
      setSelectedCodes([...selectedCodes, code])
    } else {
      setSelectedCodes(selectedCodes.filter((selectedCode:any) => selectedCode !== code))
    }
  }
  const {
    data: allPosts,
    isLoading: isLoadingAllPosts,
    isSuccess: isSuccessAllPosts,
    isError: isErrorAllPosts,
    error: errorAllPosts,
    refetch: refetchAllPosts,
  } = useGetAllSettingsQuery(generateFilterUrl({
    pageNumber: 1,
    pageSize: 20,
    totalItems: 0,
    orderByAsc: true,
    sortBy: '',
    SearchText: 'Apply HKEAO',
  }))
  const disabled = JSON.parse(JSON.stringify(allPosts?.records || []))[0]?.settingValue === 'N'
  // console.log(JSON.parse(JSON.stringify(allPosts?.records || []))[0]?.settingValue, 'allPostsallPostsallPostsallPosts', disabled, groupType)
  useEffect(() => {
    if (groupType === 'GRP2' && disabled) {
      setcheckDisabled(true)
      console.log(JSON.parse(JSON.stringify(allPosts?.records || []))[0]?.settingValue, 'allPostsallPostsallPostsallPosts', disabled, groupType)
    }
  }, [groupType, disabled])
  // const handleRemoveEmployee = (codeToRemove: string) => {
  //   // Filter out the selected employee code to remove it from the selectedCodes state
  //   setSelectedCodes(selectedCodes.filter((code:any) => code !== codeToRemove))
  // }
  const handleSelectAllChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const { checked } = event.target
    if (checked) {
      setSelectedCodes(dataList.map((employee:any) => (groupType === 'GRP4' ? employee.designName : employee.reportType)))
    } else {
      setSelectedCodes([])
    }
    setSelectAll(checked)
  }
  const checkData = (item:any) => {
    setdataList
  }
  useEffect(() => {
    const data = dataList?.map((report:any, index:any) => {
      report.reportDesignId = report.reportDesigns[0].id
      return report
    })

    setdataList({
      reportRequirements: data,
    })
  }, [])
  function setDesignIds(reports:any, i:any, designId:any) {
    const data = reports.map((report:any, index:any) => {
      if (index === i) {
        // alert(i)
        report.reportDesignId = designId
      }
      return report
    })
    return data

    // setdataList(data)
  }
  return (
    <div style={{ width: '100%' }}>
      <div style={{
        width: '100%', color: '#3B3839', fontSize: 16, fontFamily: 'Lato', fontWeight: '400', wordWrap: 'break-word',
      }}
      >
        Report can not be generated as Apply HKAO is set to NO
      </div>
      <br />
      {checkDisable ? (
        <div style={{
          width: '100%', color: 'red', fontSize: 16, fontFamily: 'Lato', fontWeight: '400', wordWrap: 'break-word',
        }}
        >
          Start by selecting at least 1 report
        </div>
      ) : ''}
      <div>
        <label style={{ marginBottom: '10px', marginTop: '10px', display: 'block' }}>
          <Checkbox
            checked={selectAll}
            disabled={checkDisable}
            onChange={handleSelectAllChange}
          />
          {/* <input /> */}
          {' '}
          Select All
        </label>
        <div style={{
          width: '100%', height: '100%', flexDirection: 'column', justifyContent: 'flex-start', alignItems: 'flex-start', display: 'inline-flex',
        }}
        >
          <div style={{
            alignSelf: 'stretch', justifyContent: 'flex-start', alignItems: 'flex-start', gap: 4, display: 'inline-flex',
          }}
          >
            <div style={{
              flex: '1 1 0', height: 48, paddingTop: 4, paddingBottom: 4, justifyContent: 'flex-start', alignItems: 'center', display: 'flex',
            }}
            >
              <div style={{
                padding: 4, justifyContent: 'flex-start', alignItems: 'center', gap: 4, display: 'flex',
              }}
              >
                <div style={{
                  color: '#3B3839', fontSize: 12, fontFamily: 'Lato', fontWeight: '700', lineHeight: 16, wordWrap: 'break-word',
                }}
                >
                  Report name |  Report code
                </div>
              </div>
            </div>

            <div style={{
              height: 48, paddingTop: 8, paddingBottom: 8, justifyContent: 'flex-start', alignItems: 'center', display: 'flex',
            }}
            >
              <div style={{
                padding: 8, justifyContent: 'flex-start', alignItems: 'center', gap: 8, display: 'flex',
              }}
              >
                <div style={{
                  color: '#3B3839', fontSize: 12, fontFamily: 'Lato', fontWeight: '700', lineHeight: 16, wordWrap: 'break-word',
                }}
                >
                  Type
                </div>
              </div>
            </div>
          </div>
        </div>
        {/* <hr style={{ borderColor: '#E8E6E7', marginBottom: '10px' }} /> */}
        {dataList?.map((employee:any, index:any) => (

          <div key={employee.code}>
            <div style={{
              width: '100%', height: '100%', flexDirection: 'column', justifyContent: 'flex-start', alignItems: 'flex-start', display: 'inline-flex',
            }}
            >
              <div style={{
                alignSelf: 'stretch', justifyContent: 'flex-start', alignItems: 'flex-start', gap: 4, display: 'inline-flex',
              }}
              >
                <div style={{
                  flex: '1 1 0', height: 48, justifyContent: 'flex-start', alignItems: 'center', display: 'flex',
                }}
                >
                  <div style={{
                    padding: 4, justifyContent: 'flex-start', alignItems: 'center', gap: 4, display: 'flex',
                  }}
                  >
                    <div style={{
                      color: '#3B3839', fontSize: 12, fontFamily: 'Lato', fontWeight: '700', lineHeight: 8, wordWrap: 'break-word',
                    }}
                    >
                      <label style={{ marginRight: '10px' }}>
                        <Checkbox
                          checked={selectedCodes.includes(groupType === 'GRP4' ? employee.designName : employee.reportType)}
                          disabled={checkDisable}
                          value={employee.reportType}
                          onChange={(event) => handleCheckboxChange(event, groupType === 'GRP4' ? employee.designName : employee.reportType)}
                        />
                        {/* <input /> */}
                        {groupType === 'GRP4' ? employee.designName : employee.reportType}
                        {' '}
                        | Report Name
                        {/* {`${employee.personalEmailAddress} (${employee.surname}, ${employee.givenName})`} */}
                      </label>
                    </div>
                  </div>
                </div>

                <div style={{
                  height: 48, justifyContent: 'flex-start', alignItems: 'center', display: 'flex',
                }}
                >
                  <div style={{
                    padding: 8, justifyContent: 'flex-start', alignItems: 'center', gap: 8, display: 'flex',
                  }}
                  >
                    {
                      employee.isStandard ? (
                        <div style={{
                          color: '#3B3839', fontSize: 12, fontFamily: 'Lato', fontWeight: '700', wordWrap: 'break-word',
                        }}
                        >
                          <div
                            className="Pill"
                            style={{
                              width: '100%', height: '100%', paddingLeft: 8, paddingRight: 8, paddingTop: 4, paddingBottom: 4, borderRadius: 12, overflow: 'hidden', justifyContent: 'center', alignItems: 'center', gap: 8, display: 'inline-flex',
                            }}
                          >
                            <div
                              className="Status"
                              style={{
                                color: '#3B3839', fontSize: 12, fontFamily: 'Lato', fontWeight: '700', wordWrap: 'break-word', width: '228px',
                              }}
                            >

                              <OPRSelectorControl
                                // error={errors?.employeeMovementType}
                                // isEditable={isEditable}
                                keyName="reportName"
                                label={t('')}
                                multiple={false}
                                name="reportName"
                                options={employee?.reportDesigns}
                                placeholder="Select"
                                value={employee?.reportDesigns.find((o:any) => o?.id === employee?.reportDesignId)}
                                valueKey="id"
                                onChange={(text:any) => {
                                  const data = setDesignIds(dataList, index, text.id)
                                  setdataList({
                                    ...rowDataList,
                                    reportRequirements: data,
                                  })
                                }}
                              />
                              {/* {employee.isStandard ? 'Standard' : 'Custom'} */}
                            </div>
                          </div>

                        </div>
                      )
                        : (
                          <div
                            className="Pill"
                            style={{
                              width: '100%', height: '100%', paddingLeft: 8, paddingRight: 8, paddingTop: 4, paddingBottom: 4, background: '#E9F4FF', borderRadius: 12, overflow: 'hidden', justifyContent: 'center', alignItems: 'center', gap: 8, display: 'inline-flex',
                            }}
                          >
                            <div
                              className="Status"
                              style={{
                                color: '#0049DB', fontSize: 12, fontFamily: 'Lato', fontWeight: '700', wordWrap: 'break-word',
                              }}
                            >

                              {/* {employee.isStandard ? 'Standard' : 'Custom'} */}
                            </div>
                          </div>
                        )
                    }
                  </div>
                </div>
              </div>
            </div>

            {/* <hr style={{ borderColor: '#E8E6E7', marginTop: '5px', marginBottom: '5px' }} /> */}
          </div>
        ))}

      </div>
    </div>

  )
}

export default ReportGroupList
