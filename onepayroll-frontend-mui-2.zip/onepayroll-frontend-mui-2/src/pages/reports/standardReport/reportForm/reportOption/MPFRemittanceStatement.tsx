import ExpandMoreIcon from '@mui/icons-material/ExpandMore'
import {
  Accordion, AccordionDetails, AccordionSummary, Grid,
} from '@mui/material'
import { useGetAllPensionFundSchemeQuery } from 'api/entityServices'
import { useGetAllProviderTypeSingleQuery } from 'api/globalServices'
import OPRResponsiveGrid from 'components/molecules/OPRResponsiveGrid'
import OPRSelectorControl from 'components/molecules/OPRSelectorControl/OPRSelectorControl'
import { useEffect, useState } from 'react'
import { generateFilterUrl } from 'utils'

import {
  errorsObj, validateDataMPF,
} from './validate'

export function MPFRemittanceStatement({
  handleReportOption, index, reportList, value, reportOptionError, handleChangeError,
}:any) {
  const [err, setErr]:any = useState(null)
  const [fileFormat, setFileFormat] = useState('')
  const [filterData, setFilterData]:any = useState({
    ProviderCode: '',
  })
  const [selectedType, setSelectedType] = useState('')
  const {
    data: allPosts,
    isLoading: isLoadingAllPosts,
    isSuccess: isSuccessAllPosts,
    isError: isErrorAllPosts,
    error: errorAllPosts,
    refetch: refetchAllPosts,
  } = useGetAllPensionFundSchemeQuery(generateFilterUrl(''))

  // get single provider type for the  remitteance file formet
  const {
    data: allPostsProviderTypeSingle,
    isLoading: isLoadingAllPostsProviderTypeSingle,
    isSuccess: isProviderTypeSingleSuccess, // Track API call success
    isError: isErrorAllPostsProviderCode,
    error: errorAllPostsProviderCode,
    refetch: refetchAllPostsProviderCode,
  } = useGetAllProviderTypeSingleQuery(generateFilterUrl(filterData))
  console.log(allPostsProviderTypeSingle?.remittanceStatementFileFormat, 'allPostsProviderTypeSingle')
  // useEffect(() => {
  //   validateYup(mpfObjectSchema, value, 'name').then((result:any) => {
  //     const obj:any = {
  //       schemeType: result[0],
  //       schemeFileNumber: result[1],
  //     }
  //     setErr(obj)
  //   })
  // }, [value.schemeType])

  const filterData1 = value?.schemeType === 'MPF' ? 'MC' : value?.schemeType
  const schemeNumber = value?.schemeFileNumber ? value?.schemeFileNumber : ''
  // useEffect(() => {
  //   setSelectedType(JSON.parse(JSON.stringify(allPosts?.records || [])).find((o:any) => (o?.schemeFileNumber === schemeNumber))?.serviceProviderCode)
  // }, [schemeNumber])
  // console.log(JSON.parse(JSON.stringify(allPosts?.records || [])), 'serviceProviderCodeserviceProviderCodeserviceProviderCode', JSON.parse(JSON.stringify(allPosts?.records || [])).find((o:any) => (o?.schemeFileNumber)))
  function filterByType(array:any, type:any) {
    return array.filter((obj:any) => obj.schemeType === type)
  }

  const scheamNumberType:any = filterByType(JSON.parse(JSON.stringify(allPosts?.records || [])), value?.schemeType === 'MPF' ? 'MC' : value?.schemeType)?.map((item:any) => ({
    schemeFileNumber: item.schemeFileNumber,
    serviceProviderCode: item.serviceProviderCode,
  })) || []

  const dataTypeSelected = scheamNumberType?.find((o:any) => (o?.schemeFileNumber === value?.schemeFileNumber))

  // verify the remittancdeStatementFileFormet
  useEffect(() => {
    if (isProviderTypeSingleSuccess && allPostsProviderTypeSingle) {
      setFileFormat(allPostsProviderTypeSingle.remittanceStatementFileFormat?.toUpperCase())
    }
  }, [isProviderTypeSingleSuccess, allPostsProviderTypeSingle])

  useEffect(() => {
    if (dataTypeSelected?.serviceProviderCode) {
      setFilterData((prevFilterData:any) => {
        if (prevFilterData.ProviderCode !== dataTypeSelected.serviceProviderCode) {
          return { ProviderCode: dataTypeSelected.serviceProviderCode }
        }
        return prevFilterData
      })
    }
  }, [dataTypeSelected])

  useEffect(() => {
    if (filterData.ProviderCode) {
      refetchAllPostsProviderCode()
    }
  }, [filterData])

  return (
    <Accordion
      defaultExpanded
      style={{ boxShadow: '0px 1px 1px -1px rgba(0,0,0,0.2), 0px 1px 1px 0px rgba(0,0,0,0.14), 0px 1px 3px 0px rgba(0,0,0,0.12)' }}
    >
      <AccordionSummary
        aria-controls="panel1-content"
        expandIcon={<ExpandMoreIcon />}
        id="panel1-header"
      >
        <div style={{
          width: '100%', color: '#3B3839', fontSize: 20, fontFamily: 'Lato', fontWeight: '700', wordWrap: 'break-word',
        }}
        >
          MPF Remittance Statement
        </div>
      </AccordionSummary>
      <AccordionDetails style={{ padding: 20 }}>
        <OPRResponsiveGrid>
          <Grid item md={2} sm={1} xs={1}>
            <OPRSelectorControl
              isRequired
              error={reportOptionError?.schemeType}
              // isEditable={isEditable}
              keyName="name"
              label="Scheme type"
              multiple={false}
              name="name"
              optionalText="Option"
              options={[{ name: 'MPF (MC & VC)', value: 'MPF' }, { name: 'ORSO', value: 'ORSO' }]}
              value={[{ name: 'MPF (MC & VC)', value: 'MPF' }, { name: 'ORSO', value: 'ORSO' }]?.find((o:any) => o?.value === value?.schemeType)}
              valueKey="value"
              onChange={(text:any) => {
                // const newData = {
                //   ...value,
                //   schemeType: text?.value,
                // }
                // validateDataMPF(errorsObj.PFRS, newData).then((data:any) => {
                //   handleChangeError(value?.code, data)
                // })
                handleReportOption('schemeType', text?.value ? text?.value : '', index, false)
              }}
            />
          </Grid>
          <Grid item md={2} sm={1} xs={1}>
            <OPRSelectorControl
              isRequired
              error={reportOptionError?.schemeFileNumber}
              keyName="schemeFileNumber"
              label="Scheme file number"
              multiple={false}
              name="schemeFileNumber"
              optionalText="Option"
              options={scheamNumberType}
              value={scheamNumberType?.find((o:any) => (o?.schemeFileNumber === value?.schemeFileNumber))}
              valueKey="schemeFileNumber"
              onChange={(text:any) => {
                // const newData = {
                //   ...value,
                //   schemeFileNumber: text?.schemeFileNumber,
                //   serviceProviderCode: dataTypeSelected?.serviceProviderCode,
                // }
                // validateDataMPF(errorsObj.PFRS, scheamNumberType).then((data:any) => {
                //   handleChangeError('PFRS', data)
                // })
                handleReportOption('schemeFileNumber', text.schemeFileNumber, index, false)
              }}
            />
          </Grid>
          {
            fileFormat === 'MANULIFE' && (
              <Grid item md={2} sm={1} xs={1}>
                <OPRSelectorControl
                  isRequired
                  error={reportOptionError?.yearOfServiceOption}
                  // isEditable={isEditable}
                  keyName="subSchemeFileNumber"
                  label="Sub-group number"
                  multiple={false}
                  name="subSchemeFileNumber"
                  // optionalText="Option"
                  options={JSON.parse(JSON.stringify(allPosts?.records || []))}
                  value={JSON.parse(JSON.stringify(allPosts?.records || [])).find((o:any) => (o?.subSchemeFileNumber === value.schemeNumber))}
                  valueKey="subSchemeFileNumber"
                  onChange={(text:any) => {
                    const newData = {
                      ...value,
                      subSchemeFileNumber: text.subSchemeFileNumber,
                      serviceProviderCode: dataTypeSelected?.serviceProviderCode,
                    }
                    validateDataMPF(errorsObj.PFRS, newData, 'subSchemeFileNumber').then((data:any) => {
                      handleChangeError('PFRS', { ...data })
                    })

                    handleReportOption('subSchemeFileNumber', text?.subSchemeFileNumber, index, true)
                  }}
                />
              </Grid>
            )
          }
          {
            fileFormat === 'HSBC' && (
              <Grid item md={2} sm={1} xs={1}>
                <OPRSelectorControl
                  isRequired
                  error={reportOptionError?.payCentre}
                  // isEditable={isEditable}
                  keyName="payCentre"
                  label="Pay centre"
                  multiple={false}
                  name="payCentre"
                  options={JSON.parse(JSON.stringify(allPosts?.records || []))}
                  value={JSON.parse(JSON.stringify(allPosts?.records || [])).find((o:any) => (o?.payCentre === value.payCentre))}
                  valueKey="payCentre"
                  onChange={(text:any) => {
                    const newData = {
                      ...value,
                      payCentre: text.payCentre,
                      serviceProviderCode: dataTypeSelected?.serviceProviderCode,
                    }
                    validateDataMPF(errorsObj.PFRS, newData, 'payCentre').then((data:any) => {
                      handleChangeError('PFRS', { ...data })
                    })
                    handleReportOption('payCentre', text?.payCentre ? text?.payCentre : null, index, false)
                  }}
                />
              </Grid>
            )
          }
          {
            fileFormat === 'AIA' && (
              <Grid item md={2} sm={1} xs={1}>
                <OPRSelectorControl
                  isRequired
                  error={reportOptionError?.sequenceNumber}
                  // isEditable={isEditable}
                  keyName="name"
                  label="Sequence number"
                  multiple={false}
                  name="name"
                  options={[{ name: '0', value: 0 }, { name: '1', value: 1 }, { name: '2', value: 2 }]}
                  value={[{ name: '0', value: 0 }, { name: '1', value: 1 }, { name: '2', value: 2 }].find((o:any) => (o?.value === value.sequenceNumber))}
                  valueKey="value"
                  onChange={(text:any) => {
                    const newData = {
                      ...value,
                      sequenceNumber: text.value,
                      serviceProviderCode: dataTypeSelected?.serviceProviderCode,
                    }
                    validateDataMPF(errorsObj.PFRS, newData, 'sequenceNumber').then((data:any) => {
                      handleChangeError('PFRS', { ...data })
                    })
                    handleReportOption('sequenceNumber', text?.value, index, false)
                  }}
                />
              </Grid>
            )
          }
          {
            (fileFormat === 'AIA' || fileFormat === 'HSBC' || fileFormat === 'MANULIFE') && (
              <Grid item md={2} sm={1} xs={1}>
                <OPRSelectorControl
                  isRequired
                  error={reportOptionError?.generateInterfaceFile}
                  // isEditable={isEditable}
                  keyName="name"
                  label="Generate interface file"
                  multiple={false}
                  name="name"
                  options={[{ name: 'Yes', value: true }, { name: 'No', value: false }]}
                  value={[{ name: 'Yes', value: true }, { name: 'No', value: false }].find((o:any) => (o?.value === value.generateInterfaceFile))}
                  valueKey="value"
                  onChange={(text:any) => {
                    const newData = {
                      ...value,
                      generateInterfaceFile: text.value,
                      serviceProviderCode: dataTypeSelected?.serviceProviderCode,
                    }
                    validateDataMPF(errorsObj.PFRS, newData, 'pensionFundSchemeCode').then((data:any) => {
                      handleChangeError('PFRS', { ...data })
                    })
                    handleReportOption('generateInterfaceFile', text?.value, index, false)
                  }}
                />
              </Grid>
            )
          }

        </OPRResponsiveGrid>
        {/* <Button onClick={() => {
          const data = handleFormSubmit(mpfObjectSchema, value, () => {
            console.log('calllllllllllllllllll')
          })
          data.then((value:any) => {
            setErr(value)
          })
        }}
        >
          Validate
        </Button> */}
      </AccordionDetails>
    </Accordion>
  )
}
