import ExpandMoreIcon from '@mui/icons-material/ExpandMore'
import {
  Accordion, AccordionDetails, AccordionSummary, Grid,
} from '@mui/material'
import OPRResponsiveGrid from 'components/molecules/OPRResponsiveGrid'
import OPRSelectorControl from 'components/molecules/OPRSelectorControl/OPRSelectorControl'

import {
  consolidateOption, includeEmployees,
} from './data'
import { errorsObj, validateDataMPF } from './validate'

export function SummaryReportCostCenter({
  handleReportOption, index, reportList, value, reportOptionError, handleChangeError,
}:any) {
  return (
    <Accordion
      defaultExpanded
      style={{ boxShadow: '0px 1px 1px -1px rgba(0,0,0,0.2), 0px 1px 1px 0px rgba(0,0,0,0.14), 0px 1px 3px 0px rgba(0,0,0,0.12)' }}
    >
      <AccordionSummary
        aria-controls="panel1-content"
        expandIcon={<ExpandMoreIcon />}
        id="panel1-header"
      >
        <div style={{
          width: '100%', color: '#3B3839', fontSize: 20, fontFamily: 'Lato', fontWeight: '700', wordWrap: 'break-word',
        }}
        >
          Payroll Summary Report by Cost Center
        </div>
      </AccordionSummary>
      <AccordionDetails style={{ padding: 20 }}>
        <OPRResponsiveGrid>
          <Grid item md={2} sm={1} xs={1}>
            <OPRSelectorControl
              isRequired
              error={reportOptionError?.consolidateOption}
              // isEditable={isEditable}
              keyName="name"
              label="Consolidate option"
              multiple={false}
              name="name"
              options={consolidateOption}
              value={consolidateOption.find((o:any) => o?.value === value?.consolidateOption)}
              valueKey="value"
              onChange={(text:any) => {
                const newData = {
                  ...value,
                  consolidateOption: text?.value,
                }
                validateDataMPF(errorsObj.PSRMC, newData, 'consolidateOption').then((data:any) => {
                  handleChangeError(value.code, { ...data })
                })
                handleReportOption('consolidateOption', text?.value, index)
              }}
            />
          </Grid>
          {/* <Grid item md={2} sm={1} xs={1}>
            <OPRSelectorControl
              isRequired
              error={reportOptionError?.groupingOptings}
              // isEditable={isEditable}
              keyName="name"
              label="Grouping option"
              multiple={false}
              name="name"
              options={groupingOptionMain}
              value={groupingOptionMain.find((o:any) => o?.value === value.groupingOptings)}
              valueKey="value"
              onChange={(text:any) => {
                const newData = {
                  ...value,
                  groupingOptings: text?.value,
                }
                validateDataMPF(errorsObj.PSRMC, newData).then((data:any) => {
                  handleChangeError(value.code, data)
                })
                handleReportOption('groupingOptings', text?.value, index)
              }}
            />
          </Grid> */}
          <Grid item md={2} sm={1} xs={1}>
            <OPRSelectorControl
              isRequired
              error={reportOptionError?.includeAllActiveEmployees}
              // isEditable={isEditable}
              keyName="name"
              label="Include all active employees"
              multiple={false}
              name="name"
              options={includeEmployees}
              value={includeEmployees.find((o:any) => o?.value === value.includeAllActiveEmployees)}
              valueKey="value"
              onChange={(text:any) => {
                const newData = {
                  ...value,
                  includeAllActiveEmployees: text?.value,
                }
                validateDataMPF(errorsObj.PSRMC, newData, 'includeAllActiveEmployees').then((data:any) => {
                  handleChangeError(value.code, { ...data })
                })
                handleReportOption('includeAllActiveEmployees', text?.value, index)
              }}
            />
          </Grid>
        </OPRResponsiveGrid>
      </AccordionDetails>
    </Accordion>
  )
}
