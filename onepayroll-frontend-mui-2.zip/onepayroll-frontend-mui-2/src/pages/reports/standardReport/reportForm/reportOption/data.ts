export const includeEmployees = [
  { name: 'Yes', value: true },
  { name: 'No', value: false },
]

export const consolidateOption = [
  { name: 'Consolidate by Pay Cycle', value: 0 },
  { name: 'Consolidate by Month', value: 1 },
  { name: 'Consolidate into One', value: 2 },
]

export const IncludeZERO = [
  { name: 'Yes, include with and without difference', value: true },
  { name: 'No, include only with difference', value: false },
]

export const GroupingOptionDataList = [
  { name: 'Employee Code -> Item Code', value: 0 },
  { name: 'Item Code -> Employee Code', value: 2 },
]

export const groupingOption = [
  { name: 'Employee Code', value: 0 },
  { name: 'Main Cost Center', value: 1 },
  { name: 'Charge Cost Center', value: 2 },
]
export const groupingOptionMain = [
  { name: 'Main Cost Center', value: 1 },
]
export const groupingOptionPSR = [
  { name: 'Employee Code', value: 0 },
]
export const groupingOptionPSRCharge = [
  { name: 'Charge Cost Center', value: 2 },
]

export const generateInterfaceFile = [
  { name: 'Yes', value: true },
  { name: 'No', value: false },
]
