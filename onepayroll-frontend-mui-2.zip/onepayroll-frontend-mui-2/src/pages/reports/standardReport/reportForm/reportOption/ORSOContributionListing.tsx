import ExpandMoreIcon from '@mui/icons-material/ExpandMore'
import {
  Accordion, AccordionDetails, AccordionSummary, Grid,
} from '@mui/material'
import { useGetAllPensionFundSchemeQuery } from 'api/entityServices'
import OPRInputControl from 'components/molecules/OPRInputControl'
import OPRResponsiveGrid from 'components/molecules/OPRResponsiveGrid'
import OPRSelectorControl from 'components/molecules/OPRSelectorControl/OPRSelectorControl'
import { generateFilterUrl } from 'utils'

import { includeEmployees } from './data'
import { errorsObj, validateDataMPF } from './validate'

export function ORSOContributionListing({
  handleReportOption, index, reportList, value, reportOptionError, handleChangeError,
}:any) {
  const {
    data: allPosts,
    isLoading: isLoadingAllPosts,
    isSuccess: isSuccessAllPosts,
    isError: isErrorAllPosts,
    error: errorAllPosts,
    refetch: refetchAllPosts,
  } = useGetAllPensionFundSchemeQuery(generateFilterUrl(''))
  const pensionFundList = allPosts?.records?.map((item:any) => {
    const data = {
      name: `${item.pensionFundSchemeCode}`,
      ...item,
    }
    return data
  })

  return (
    <Accordion
      defaultExpanded
      style={{ boxShadow: '0px 1px 1px -1px rgba(0,0,0,0.2), 0px 1px 1px 0px rgba(0,0,0,0.14), 0px 1px 3px 0px rgba(0,0,0,0.12)' }}
    >
      <AccordionSummary
        aria-controls="panel1-content"
        expandIcon={<ExpandMoreIcon />}
        id="panel1-header"
      >
        <div style={{
          width: '100%', color: '#3B3839', fontSize: 20, fontFamily: 'Lato', fontWeight: '700', wordWrap: 'break-word',
        }}
        >
          ORSO Contribution Listing
        </div>
      </AccordionSummary>
      <AccordionDetails style={{ padding: 20 }}>
        <OPRResponsiveGrid>
          <Grid item md={2} sm={1} xs={1}>
            <OPRSelectorControl
              isRequired
              error={reportOptionError?.pensionFundSchemeCode}
              // isEditable={isEditable}
              keyName="pensionFundSchemeCode"
              label="Pension fund scheme"
              multiple={false}
              name="pensionFundSchemeCode"
              optionalText="Option"
              options={pensionFundList || []}
              value={pensionFundList?.find((o:any) => o?.pensionFundSchemeCode === value?.pensionFundSchemeCode)}
              valueKey="pensionFundSchemeCode"
              onChange={(text:any) => {
                const newData = {
                  ...value,
                  pensionFundSchemeCode: text.pensionFundSchemeCode,
                }
                validateDataMPF(errorsObj.ORSO, newData, 'pensionFundSchemeCode').then((data:any) => {
                  handleChangeError(value.code, { ...data })
                })
                handleReportOption('pensionFundSchemeCode', text?.pensionFundSchemeCode, index)
              }}
            />
          </Grid>
          <Grid item md={2} sm={1} xs={1}>
            <OPRInputControl
              isRequired
              error={reportOptionError?.exchangeRate}
              isEditable={false}
              label="Exchange rate"
              name="exchangeRate"
              optionalText="Option"
              value={value?.exchangeRate}
              onChange={(text:any) => {
                const newData = {
                  ...value,
                  exchangeRate: text?.target.value,
                }
                validateDataMPF(errorsObj.ORSO, newData, 'exchangeRate').then((data:any) => {
                  handleChangeError(value.code, { ...data })
                })
                handleReportOption('exchangeRate', text?.target.value, index)
              }}
            />

          </Grid>
          <Grid item md={2} sm={1} xs={1}>
            <OPRSelectorControl
              isRequired
              error={reportOptionError?.includeAllActiveEmployees}
              // isEditable={isEditable}
              keyName="name"
              label="Include all active employees"
              multiple={false}
              name="name"
              options={includeEmployees || []}
              value={includeEmployees?.find((o:any) => o?.value === value?.includeAllActiveEmployees)}
              valueKey="value"
              onChange={(text:any) => {
                const newData = {
                  ...value,
                  includeAllActiveEmployees: text?.value,
                }
                validateDataMPF(errorsObj.ORSO, newData, 'includeAllActiveEmployees').then((data:any) => {
                  handleChangeError(value.code, { ...data })
                })
                handleReportOption('includeAllActiveEmployees', text?.value, index)
              }}
            />
          </Grid>
        </OPRResponsiveGrid>
      </AccordionDetails>
    </Accordion>
  )
}
