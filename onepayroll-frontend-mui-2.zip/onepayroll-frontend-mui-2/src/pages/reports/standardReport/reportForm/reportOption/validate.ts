import { useLayoutEffect, useRef, useState } from 'react'
import * as Yup from 'yup'

export const allObjectValidation = Yup.object().shape({
  schemeType: Yup.string().nullable(),
  // schemeFileNumber: Yup.number().nullable(),
  consolidateOption: Yup.string().test({
    name: 'consolidateOption',
    exclusive: true,
    message: 'Consolidate Option is filled.',
    test(value, { parent }) {
      if (['PSRCC', 'PSR', 'PSRMC'].includes(parent?.code)) {
        return !!value
      }
      return true
    },
  }).nullable(),
  includeZeroDifference: Yup.string().test({
    name: 'includeZeroDifference',
    exclusive: true,
    message: 'Include Zero Difference is filled.',
    test(value, { parent }) {
      if (['PCRPI', 'PCREE'].includes(parent?.code)) {
        return !!value
      }
      return true
    },
  }).nullable(),
  includeAllActiveEmployees: Yup.string().test({
    name: 'includeAllActiveEmployees',
    exclusive: true,
    message: 'Include all active employees is filled.',
    test(value, { parent }) {
      if (['PSRCC', 'PSR', 'PSRMC', 'ORSO'].includes(parent?.code)) {
        return !!value
      }
      return true
    },
  }).nullable(),
  payCentre: Yup.string().test({
    name: 'payCentre',
    exclusive: true,
    message: 'Pay Centre must be selected.',
    test(value, { parent }) {
      if (parent?.serviceProviderCode === 'HSBC' && parent?.code === 'PFRS') {
        return !!value
      }
      return true
    },
  }).nullable(),
  sequenceNumber: Yup.string().test({
    name: 'sequenceNumber',
    exclusive: true,
    message: 'Sequence Number must be selected.',
    test(value, { parent }) {
      if (parent?.serviceProviderCode === 'AIA' && parent?.code === 'PFRS') {
        return !!value
      }
      return true
    },
  }).nullable(),
  generateInterfaceFile: Yup.string().test({
    name: 'generateInterfaceFile',
    exclusive: true,
    message: 'Generate Interface File must be selected.',
    test(value, { parent }) {
      if ((parent?.serviceProviderCode === 'ML' || parent?.serviceProviderCode === 'HSBC' || parent?.serviceProviderCode === 'AIA') && parent?.code === 'PFRS') {
        return !!value
      }
      return true
    },
  }).nullable(),
})

const objectSchema = Yup.object().shape({
  consolidateOption: Yup.string()
    .required('Consolidate Option is filled'),
  // groupingOptings: Yup.string()
  //   .required('groupingOptings is filled'),
  includeAllActiveEmployees: Yup.string()
    .required('Include All ActiveEmployees is filled'),

})

export const errorsObj:any = {
  PCREE: Yup.object().shape({
    includeZeroDifference: Yup.string().test({
      name: 'includeZeroDifference',
      exclusive: true,
      message: 'Include Zero Difference is filled.',
      test(value, { parent }) {
        console.log('hhhhhhhhhhhhhhhhhhhhh', parent)

        if (['PCRPI', 'PCREE'].includes(parent?.code)) {
          return !!value
        }
        return true
      },
    }).nullable(),
  }),
  PCRPI: Yup.object().shape({
    includeZeroDifference: Yup.string().test({
      name: 'includeZeroDifference',
      exclusive: true,
      message: 'Include Zero Difference is filled.',
      test(value, { parent }) {
        if (['PCRPI', 'PCREE'].includes(parent?.code)) {
          return !!value
        }
        return true
      },
    }).nullable(),
  }),
  // PFRS MPF
  PFRS: Yup.object().shape({
    // schemeType: Yup.string(),
    schemeFileNumber: Yup.string().nullable(),
    // subSchemeFileNumber: Yup.string().test({
    //   name: 'schemeType',
    //   exclusive: true,
    //   message: 'Sub Scheme File Number must be selected.',
    //   test(value, { parent }) {
    //     console.log('hhhhhhhhhhhhhhhhhhhhh')

    //     if (parent?.serviceProviderCode === 'HSBC' || ) {
    //       return !!value
    //     }
    //     return true
    //   },
    // }).nullable(),
    payCentre: Yup.string().test({
      name: 'schemeFileNumber',
      exclusive: true,
      message: 'Pay Centre must be selected.',
      test(value, { parent }) {
        console.log('hhhhhhhhhhhhhhhhhhhhh')

        if (parent?.serviceProviderCode === 'HSBC') {
          return !!value
        }
        return true
      },
    }).nullable(),
    sequenceNumber: Yup.string().test({
      name: 'schemeFileNumber',
      exclusive: true,
      message: 'Sequence Number must be selected.',
      test(value, { parent }) {
        if (parent?.serviceProviderCode === 'AIA') {
          return !!value
        }
        return true
      },
    }).nullable(),
    generateInterfaceFile: Yup.string().test({
      name: 'schemeFileNumber',
      exclusive: true,
      message: 'Generate Interface File must be selected.',
      test(value, { parent }) {
        if (parent?.serviceProviderCode === 'ML' || parent?.serviceProviderCode === 'HSBC' || parent?.serviceProviderCode === 'AIA') {
          return !!value
        }
        return true
      },
    }).nullable(),
  }),
  ORSO: Yup.object().shape({
    includeAllActiveEmployees: Yup.string()
      .required('Include All Active Employees must be selected'),
  }),
  PSRCC: Yup.object().shape({
    consolidateOption: Yup.string()
      .required('Consolidate Option must be selected'),
    includeAllActiveEmployees: Yup.string()
      .required('Include All Active Employees must be selected'),
  }),
  PSR: Yup.object().shape({
    consolidateOption: Yup.string()
      .required('Consolidate Option must be selected'),
    includeAllActiveEmployees: Yup.string()
      .required('Include All Active Employees must be selected'),
  }),
  PSRMC: Yup.object().shape({
    consolidateOption: Yup.string()
      .required('Consolidate Option must be selected'),
    includeAllActiveEmployees: Yup.string()
      .required('Include All Active Employees must be selected'),
  }),
  EAO: Yup.object().shape({
    // consolidateOption: Yup.string()
    //   .required('consolidateOption must be selected'),
    // groupingOptings: Yup.string()
    //   .required('groupingOptings must be selected'),
    includeAllActiveEmployees: Yup.string()
      .required('Include All Active Employees must be selected'),
  }),
}

// Custom function to validate the data
export const validateData = async (data: any) => {
  let errorList = {}
  try {
    await objectSchema?.validate(data, { abortEarly: false })
  } catch (err) {
    if (err instanceof Yup.ValidationError) {
      console.error('Validation failed:', err.errors)
      errorList = err.errors
    }
  }
  return errorList
}

export const mpfObjectSchema = Yup.object().shape({
  schemeType: Yup.string()
    .required('Consolidate Option is required'),
  schemeFileNumber: Yup.number()
    .required('Consolidate Option is required'),
})

export const validateDataMPF = async (schema:any, data: any, key:any) => {
  let errorList
  try {
    await schema.validate(data, { abortEarly: false })
    errorList = { isValidate: true }
  } catch (err) {
    if (err instanceof Yup.ValidationError) {
      const errs = await schema.validate(data, { abortEarly: false }).catch((err:any) => {
        const errors = err.inner.flatMap((e:any) => ({ [e.path]: e.errors[0] })).reduce((result:any, current:any) => Object.assign(result, current), {})
        return errors
      })

      errorList = errs
    } else {
      console.log('passsssssssss')
    }
  }
  return errorList
}

export const validateYup:any = async (schema: any, data: any, name:any, error:any) => {
  let errorList:any
  await schema
    .validate(data, { abortEarly: false })
    .then(() => {
    //   setErrors({})
    // successCallback(values)
    })
    .catch(async (err:any) => {
      if (err.name === 'ValidationError') {
        const errs = await schema?.validate(data, { abortEarly: false }).catch((err:any) => {
          const errors = err?.inner?.flatMap((e:any) => ({ [e.path]: e.errors[0] })).reduce((result:any, current:any) => Object.assign(result, current), {})
          return errors[name]
          // Update form errors state:
        })

        // errorList = { ...error, [name]: errs }
        // setErrors({ ...errors, [name]: errs })
      }
    })

  return errorList
}
const schema = Yup.object().shape({
  name: Yup.string()
    .required('Name is required')
    .min(2, 'Name must be at least 2 characters long'),
  age: Yup.number()
    .required('Age is required')
    .min(0, 'Age must be a positive number')
    .max(120, 'Age must be less than or equal to 120'),
  email: Yup.string()
    .required('Email is required')
    .email('Email must be a valid email address'),
})

export const schemaExportCriteria = Yup.object().shape({
  zipFileName: Yup.string().test({
    name: 'zipFileName',
    exclusive: true,
    message: 'Zip FileName must be filled.',
    test(value, { parent }) {
      if (parent?.exportToSingleZipFile) {
        return !!value
      }
      return true
    },
  }).nullable(),
  zipPassword: Yup.string().test({
    name: 'zipPassword',
    exclusive: true,
    message: 'Zip Password must be filled.',
    test(value, { parent }) {
      if (parent?.exportToSingleZipFile) {
        return !!value
      }
      return true
    },
  }).nullable(),
})
export const handleFormSubmit:any = async (schema:any, values:any, successCallback:any) => {
//   event.preventDefault()

  //   if (!isValidating) setIsValidating(true)
  let errorList:any = {}
  await schema
    ?.validate(values, { abortEarly: false })
    .then(() => {
    //   setErrors({})
      successCallback(values)
    })
    .catch(async (err:any) => {
      if (err?.name === 'ValidationError') {
        const errs = await schema?.validate(values, { abortEarly: false }).catch((err:any) => {
          const errors = err?.inner?.flatMap((e:any) => ({ [e.path]: e.errors[0] })).reduce((result:any, current:any) => Object.assign(result, current), {})
          return errors
          // Update form errors state:
        })
        errorList = errs
        // setErrors(errs)
      }
    })
  return errorList
}

export const handleExportSubmit:any = async (schema:any, values:any, successCallback:any) => {
  //   event.preventDefault()

  //   if (!isValidating) setIsValidating(true)
  let errorList:any = {}
  await schema
    ?.validate(values, { abortEarly: false })
    .then(() => {
      //   setErrors({})
      successCallback({})
    })
    .catch(async (err:any) => {
      if (err?.name === 'ValidationError') {
        const errs = await schema?.validate(values, { abortEarly: false }).catch((err:any) => {
          const errors = err?.inner?.flatMap((e:any) => ({ [e.path]: e.errors[0] })).reduce((result:any, current:any) => Object.assign(result, current), {})
          return errors
          // Update form errors state:
        })
        errorList = errs
        // setErrors(errs)
      }
    })
  return errorList
}
function isEmptyObject(obj:any) {
  return Object.keys(obj).length === 0 && obj.constructor === Object
}
export const handleFinalSubmit:any = async (values:any, setError:any, successCallback:any, reportOptionError:any) => {
  //   event.preventDefault()

  //   if (!isValidating) setIsValidating(true)

  let errorList:any = {}
  await values?.map((item:any, index:any) => {
    const key = item.code
    allObjectValidation?.validate(item, { abortEarly: false })
      .then((err:any) => {
        const isValid = Object.keys(reportOptionError).length === 0 ? false : Object.values(reportOptionError).every((subObj:any) => subObj.isValidate === true)

        if (isValid) {
          successCallback()
        }
      })
      .catch(async (err:any) => {
        if (err?.name === 'ValidationError') {
          const errs = await allObjectValidation?.validate(item, { abortEarly: false }).catch((err:any) => {
            const errors = err?.inner?.flatMap((e:any) => ({ [e.path]: e.errors[0] })).reduce((result:any, current:any) => Object.assign(result, current), {})

            return errors
            // Update form errors state:
          })

          errorList = { ...errorList, [item.code]: errs }
          setError(errorList)
        }
      })

    return item
  })
  console.log()

  return errorList
}

export const useStateWithCallback = (initialState:any) => {
  const [state, setState] = useState(initialState)
  const callbackRef:any = useRef(null) // Use ref to store the callback

  const updateState = (newState:any, callback:any) => {
    callbackRef.current = callback // Store the callback
    setState(newState)
  }

  useLayoutEffect(() => {
    // If there's a callback, call it after the state has been updated
    if (callbackRef.current) {
      callbackRef.current(state)
      callbackRef.current = null // Reset callback after execution
    }
  }, [state]) // Depend on state to ensure it runs after every state change

  return [state, updateState]
}

export const groupCode1 = ['PFRS', 'PSRCC', 'PSR', 'PSRMC', 'ORSO']
export const groupCode2 = ['EAO']
// export const groupCode3 = ['PCTPI', 'PCREE']PCRPI

export const groupCode3 = ['PCRPI', 'PCREE'] // PCRPI
export const groupCode4 = ['CUST']

export const findGroupType = (groupCode1:any, groupCode2:any) => JSON.stringify(groupCode1) === JSON.stringify(groupCode2)
export const arraysMatchReportTypeCode = (arr1:any, arr2:any) => arr1?.some((item:any) => arr2?.includes(item))
export const checkMPFValidation = ['Manulife', 'HSBC', 'AIA', 'Sunlife']
export function checkFields(objects:any, fields:any) {
  return fields
    .every((key:any) => Object.prototype.hasOwnProperty.call(objects, key))
}

export const deleteDataModification = (rowData:any, key:any) => {
  const data = rowData
  return delete data[key]
}
