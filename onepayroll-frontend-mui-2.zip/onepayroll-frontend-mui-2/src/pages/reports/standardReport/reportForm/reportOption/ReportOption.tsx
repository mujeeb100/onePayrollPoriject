import { EAOWagesReport } from './EAOWagesReport'
import { MPFRemittanceStatement } from './MPFRemittanceStatement'
import { ORSOContributionListing } from './ORSOContributionListing'
import { PayRollSummaryReport } from './PayReportSummary'
import { PayrollComparisonReportEmployee } from './PayrollComparisonReportEmployee'
import { PayrollComparisonReportPayItem } from './PayrollComparisonReportPayItem'
import { SummaryReportChargeCostCenter } from './SummaryReportChargeCostCenter'
import { SummaryReportCostCenter } from './SummaryReportCostCenter'

function filterObjectsByIDs(arrayOfObjects:any, arrayOfIDs:any) {
  return arrayOfObjects.filter((obj:any) => arrayOfIDs.includes(obj.reportType))
}
function ReportOption({
  listItem, handleReportOption, dataList, reportOptionError, handleChangeError, groupType,
}:any) {
  console.log('payrollComparisionDtopayrollComparisionDto', listItem)

  const {
    ORSO, PFRS, PSR, PSRCC, PSRMC,
  } = reportOptionError
  const reportType = ['Payroll Summary Report', 'Payroll Summary Report by Cost Center', 'Payroll Summary Report by Charge Cost Center', 'MPF Remittance Statement', 'OSRO Contribution Listing', 'EAO Wages Report', 'Payroll Comparison Report by Employee', 'Payroll Comparison Report by Pay Item']
  const filteredObjects = filterObjectsByIDs(listItem, reportType)

  const handleChange = (key:any, value:any, index:any) => {
    const obj = [
      ...listItem.map((item:any, i:any) => {
        if (i === index) {
          return {
            ...item,
            [key]: value,
          }
        }
        return item
      }),
    ]

    handleReportOption({ ...dataList, reportRequirements: obj })
  }
  const handleChangeMPF = (key:any, value:any, index:any, isArray:any) => {
    const obj = [
      ...listItem.map((item:any, i:any) => {
        if (i === index) {
          if (isArray) {
            return {
              ...item,
              mpfRemittanceStatement: {
                ...item.mpfRemittanceStatement,
                [key]: value,
              },

            }
          }
          return {
            ...item,
            mpfRemittanceStatement: {
              ...item.mpfRemittanceStatement,
              [key]: value,
            },
            // [key]: value,
          }
        }

        return item
      }),
    ]
    handleReportOption({ ...dataList, reportRequirements: obj })
  }
  const handleChangeORC = (key:any, value:any, index:any) => {
    console.log(key, value, index)

    const obj = [
      ...listItem.map((item:any, i:any) => {
        if (i === index) {
          return {
            ...item,
            [key]: value,
          }
        }
        return item
      }),
    ]
    handleReportOption({ ...dataList, reportRequirements: obj })
  }

  const handleChangeGRP3 = (key:any, value:any, index:any) => {
    const obj = [
      ...listItem.map((item:any, i:any) => {
        if (i === index) {
          return {
            ...item,
            payrollComparisionDto: {
              includeZeroDifference: value,
            },
          }
        }
        return item
      }),
    ]
    handleReportOption({ ...dataList, reportRequirements: obj })
  }

  const listItemLayout = (dataList:any) => `
  <span style="
      color: #3B3839;
      font-size: 16px;
      font-family: Lato;
      font-weight: 400;
      line-height: 2;
      word-wrap: break-word;
    ">
      ${dataList?.reportRequirements?.map((item:any) => `
        ${item.reportType}<br />
      `).join(',')}.
    </span>`

  const plainString = listItemLayout(dataList).replace(/<[^>]+>/g, '')
  return (
    <div style={{
      display: 'flex', flexDirection: 'column', gap: 5, width: '100%',
    }}
    >
      {
        plainString
      }
      <br />
      <br />
      <div style={{
        width: '100%', color: '#3B3839', fontSize: 16, fontFamily: 'Lato', fontWeight: '400', wordWrap: 'break-word',
      }}
      >
        All fields are mandatory except those marked optional.
      </div>
      <div>
        {filteredObjects.map((obj:any, index:any) => (
          <div key={obj.id}>
            {/* Render different UI components based on the filtered result */}
            {obj.reportType === 'Payroll Summary Report' && <PayRollSummaryReport handleChangeError={handleChangeError} handleReportOption={handleChange} index={index} reportList={listItem} reportOptionError={reportOptionError.PSR} value={obj} />}
            {obj.reportType === 'Payroll Summary Report by Cost Center' && <SummaryReportCostCenter handleChangeError={handleChangeError} handleReportOption={handleChange} index={index} reportList={listItem} reportOptionError={reportOptionError.PSRMC} value={obj} />}
            {obj.reportType === 'Payroll Summary Report by Charge Cost Center' && <SummaryReportChargeCostCenter handleChangeError={handleChangeError} handleReportOption={handleChange} index={index} reportList={listItem} reportOptionError={reportOptionError.PSRCC} value={obj} />}
            {obj.reportType === 'MPF Remittance Statement' && <MPFRemittanceStatement handleChangeError={handleChangeError} handleReportOption={handleChangeMPF} index={index} reportList={listItem} reportOptionError={reportOptionError.PFRS} value={obj?.mpfRemittanceStatement} />}
            {obj.reportType === 'OSRO Contribution Listing' && <ORSOContributionListing handleChangeError={handleChangeError} handleReportOption={handleChangeORC} index={index} reportList={listItem} reportOptionError={reportOptionError?.ORSO} value={obj} />}
            {obj.reportType === 'EAO Wages Report' && (
              <EAOWagesReport
                handleChangeError={handleChangeError}
                handleReportOption={handleChange}
                index={index}
                reportList={listItem}
                reportOptionError={reportOptionError.EAO}
                value={obj}
              />
            )}
            {obj.reportType === 'Payroll Comparison Report by Employee' && (
              <PayrollComparisonReportEmployee
                handleChangeError={handleChangeError}
                handleReportOption={handleChangeGRP3}
                index={index}
                reportList={listItem}
                reportOptionError={reportOptionError.PCREE}
                value={obj?.payrollComparisionDto}
              />
            )}
            {obj.reportType === 'Payroll Comparison Report by Pay Item' && (
              <PayrollComparisonReportPayItem
                handleChangeError={handleChangeError}
                // handleChangeGRP3={handleChangeGRP3}
                handleReportOption={handleChangeGRP3}
                index={index}
                reportList={listItem}
                reportOptionError={reportOptionError.PCRPI}
                value={obj?.payrollComparisionDto}
              />
            )}
            {/* Add more conditions for different IDs */}
          </div>
        ))}
      </div>
      {/* <Accordion
        defaultExpanded
        style={{ boxShadow: '0px 1px 1px -1px rgba(0,0,0,0.2), 0px 1px 1px 0px rgba(0,0,0,0.14), 0px 1px 3px 0px rgba(0,0,0,0.12)' }}
      >
        <AccordionSummary
          aria-controls="panel1-content"
          expandIcon={<ExpandMoreIcon />}
          id="panel1-header"
        >
          <div style={{
            width: '100%', color: '#3B3839', fontSize: 20, fontFamily: 'Lato', fontWeight: '700', wordWrap: 'break-word',
          }}
          >
            Payroll Summary Report
          </div>
        </AccordionSummary>
        <AccordionDetails style={{ padding: 20 }}>
          <OPRResponsiveGrid>
            <Grid item md={2} sm={1} xs={1}>
              <OPRSelectorControl
                isRequired
                // error={errors?.yearOfServiceOption}
                // isEditable={isEditable}
                keyName="name"
                label="Consolidate option"
                multiple={false}
                name="name"
                options={[{ name: 'Commencement Date', value: 'Commencement Date' }, { name: 'Date Join Group', value: 'Date Join Group' }, { name: '418 Start Date', value: '418 Start Date' }]}
                value={[{ name: 'Commencement Date', value: 'Commencement Date' }, { name: 'Date Join Group', value: 'Date Join Group' }, { name: '418 Start Date', value: '418 Start Date' }].find((o:any) => o?.value === "'418 Start Date'")}
                valueKey="value"
                onChange={(text:any) => {
                // handleOnChange('yearOfServiceOption', text?.value)
                }}
              />
            </Grid>
            <Grid item md={2} sm={1} xs={1}>
              <OPRSelectorControl
                isRequired
                // error={errors?.yearOfServiceOption}
                // isEditable={isEditable}
                keyName="name"
                label="Grouping option"
                multiple={false}
                name="name"
                options={[{ name: 'Commencement Date', value: 'Commencement Date' }, { name: 'Date Join Group', value: 'Date Join Group' }, { name: '418 Start Date', value: '418 Start Date' }]}
                value={[{ name: 'Commencement Date', value: 'Commencement Date' }, { name: 'Date Join Group', value: 'Date Join Group' }, { name: '418 Start Date', value: '418 Start Date' }].find((o:any) => o?.value === "'418 Start Date'")}
                valueKey="value"
                onChange={(text:any) => {
                // handleOnChange('yearOfServiceOption', text?.value)
                }}
              />
            </Grid>
            <Grid item md={2} sm={1} xs={1}>
              <OPRSelectorControl
                isRequired
                // error={errors?.yearOfServiceOption}
                // isEditable={isEditable}
                keyName="name"
                label="Include all active employees"
                multiple={false}
                name="name"
                options={[{ name: 'Commencement Date', value: 'Commencement Date' }, { name: 'Date Join Group', value: 'Date Join Group' }, { name: '418 Start Date', value: '418 Start Date' }]}
                value={[{ name: 'Commencement Date', value: 'Commencement Date' }, { name: 'Date Join Group', value: 'Date Join Group' }, { name: '418 Start Date', value: '418 Start Date' }].find((o:any) => o?.value === "'418 Start Date'")}
                valueKey="value"
                onChange={(text:any) => {
                // handleOnChange('yearOfServiceOption', text?.value)
                }}
              />
            </Grid>
          </OPRResponsiveGrid>
        </AccordionDetails>
      </Accordion>
      <Accordion
        defaultExpanded
        style={{ boxShadow: '0px 1px 1px -1px rgba(0,0,0,0.2), 0px 1px 1px 0px rgba(0,0,0,0.14), 0px 1px 3px 0px rgba(0,0,0,0.12)' }}
      >
        <AccordionSummary
          aria-controls="panel1-content"
          expandIcon={<ExpandMoreIcon />}
          id="panel1-header"
        >
          <div style={{
            width: '100%', color: '#3B3839', fontSize: 20, fontFamily: 'Lato', fontWeight: '700', wordWrap: 'break-word',
          }}
          >
            Payroll Summary Report
          </div>
        </AccordionSummary>
        <AccordionDetails style={{ padding: 20 }}>
          <OPRResponsiveGrid>
            <Grid item md={2} sm={1} xs={1}>
              <OPRSelectorControl
                isRequired
                // error={errors?.yearOfServiceOption}
                // isEditable={isEditable}
                keyName="name"
                label="Consolidate option"
                multiple={false}
                name="name"
                options={[{ name: 'Commencement Date', value: 'Commencement Date' }, { name: 'Date Join Group', value: 'Date Join Group' }, { name: '418 Start Date', value: '418 Start Date' }]}
                value={[{ name: 'Commencement Date', value: 'Commencement Date' }, { name: 'Date Join Group', value: 'Date Join Group' }, { name: '418 Start Date', value: '418 Start Date' }].find((o:any) => o?.value === "'418 Start Date'")}
                valueKey="value"
                onChange={(text:any) => {
                // handleOnChange('yearOfServiceOption', text?.value)
                }}
              />
            </Grid>
            <Grid item md={2} sm={1} xs={1}>
              <OPRSelectorControl
                isRequired
                // error={errors?.yearOfServiceOption}
                // isEditable={isEditable}
                keyName="name"
                label="Grouping option"
                multiple={false}
                name="name"
                options={[{ name: 'Commencement Date', value: 'Commencement Date' }, { name: 'Date Join Group', value: 'Date Join Group' }, { name: '418 Start Date', value: '418 Start Date' }]}
                value={[{ name: 'Commencement Date', value: 'Commencement Date' }, { name: 'Date Join Group', value: 'Date Join Group' }, { name: '418 Start Date', value: '418 Start Date' }].find((o:any) => o?.value === "'418 Start Date'")}
                valueKey="value"
                onChange={(text:any) => {
                // handleOnChange('yearOfServiceOption', text?.value)
                }}
              />
            </Grid>
            <Grid item md={2} sm={1} xs={1}>
              <OPRSelectorControl
                isRequired
                // error={errors?.yearOfServiceOption}
                // isEditable={isEditable}
                keyName="name"
                label="Include all active employees"
                multiple={false}
                name="name"
                options={[{ name: 'Commencement Date', value: 'Commencement Date' }, { name: 'Date Join Group', value: 'Date Join Group' }, { name: '418 Start Date', value: '418 Start Date' }]}
                value={[{ name: 'Commencement Date', value: 'Commencement Date' }, { name: 'Date Join Group', value: 'Date Join Group' }, { name: '418 Start Date', value: '418 Start Date' }].find((o:any) => o?.value === "'418 Start Date'")}
                valueKey="value"
                onChange={(text:any) => {
                // handleOnChange('yearOfServiceOption', text?.value)
                }}
              />
            </Grid>
          </OPRResponsiveGrid>
        </AccordionDetails>
      </Accordion>
      <Accordion
        defaultExpanded
        style={{ boxShadow: '0px 1px 1px -1px rgba(0,0,0,0.2), 0px 1px 1px 0px rgba(0,0,0,0.14), 0px 1px 3px 0px rgba(0,0,0,0.12)' }}
      >
        <AccordionSummary
          aria-controls="panel1-content"
          expandIcon={<ExpandMoreIcon />}
          id="panel1-header"
        >
          <div style={{
            width: '100%', color: '#3B3839', fontSize: 20, fontFamily: 'Lato', fontWeight: '700', wordWrap: 'break-word',
          }}
          >
            Payroll Summary Report
          </div>
        </AccordionSummary>
        <AccordionDetails style={{ padding: 20 }}>
          <OPRResponsiveGrid>
            <Grid item md={2} sm={1} xs={1}>
              <OPRSelectorControl
                isRequired
                // error={errors?.yearOfServiceOption}
                // isEditable={isEditable}
                keyName="name"
                label="Consolidate option"
                multiple={false}
                name="name"
                options={[{ name: 'Commencement Date', value: 'Commencement Date' }, { name: 'Date Join Group', value: 'Date Join Group' }, { name: '418 Start Date', value: '418 Start Date' }]}
                value={[{ name: 'Commencement Date', value: 'Commencement Date' }, { name: 'Date Join Group', value: 'Date Join Group' }, { name: '418 Start Date', value: '418 Start Date' }].find((o:any) => o?.value === "'418 Start Date'")}
                valueKey="value"
                onChange={(text:any) => {
                // handleOnChange('yearOfServiceOption', text?.value)
                }}
              />
            </Grid>
            <Grid item md={2} sm={1} xs={1}>
              <OPRSelectorControl
                isRequired
                // error={errors?.yearOfServiceOption}
                // isEditable={isEditable}
                keyName="name"
                label="Grouping option"
                multiple={false}
                name="name"
                options={[{ name: 'Commencement Date', value: 'Commencement Date' }, { name: 'Date Join Group', value: 'Date Join Group' }, { name: '418 Start Date', value: '418 Start Date' }]}
                value={[{ name: 'Commencement Date', value: 'Commencement Date' }, { name: 'Date Join Group', value: 'Date Join Group' }, { name: '418 Start Date', value: '418 Start Date' }].find((o:any) => o?.value === "'418 Start Date'")}
                valueKey="value"
                onChange={(text:any) => {
                // handleOnChange('yearOfServiceOption', text?.value)
                }}
              />
            </Grid>
            <Grid item md={2} sm={1} xs={1}>
              <OPRSelectorControl
                isRequired
                // error={errors?.yearOfServiceOption}
                // isEditable={isEditable}
                keyName="name"
                label="Include all active employees"
                multiple={false}
                name="name"
                options={[{ name: 'Commencement Date', value: 'Commencement Date' }, { name: 'Date Join Group', value: 'Date Join Group' }, { name: '418 Start Date', value: '418 Start Date' }]}
                value={[{ name: 'Commencement Date', value: 'Commencement Date' }, { name: 'Date Join Group', value: 'Date Join Group' }, { name: '418 Start Date', value: '418 Start Date' }].find((o:any) => o?.value === "'418 Start Date'")}
                valueKey="value"
                onChange={(text:any) => {
                // handleOnChange('yearOfServiceOption', text?.value)
                }}
              />
            </Grid>
          </OPRResponsiveGrid>
        </AccordionDetails>
      </Accordion>
      <Accordion
        defaultExpanded
        style={{ boxShadow: '0px 1px 1px -1px rgba(0,0,0,0.2), 0px 1px 1px 0px rgba(0,0,0,0.14), 0px 1px 3px 0px rgba(0,0,0,0.12)' }}
      >
        <AccordionSummary
          aria-controls="panel1-content"
          expandIcon={<ExpandMoreIcon />}
          id="panel1-header"
        >
          <div style={{
            width: '100%', color: '#3B3839', fontSize: 20, fontFamily: 'Lato', fontWeight: '700', wordWrap: 'break-word',
          }}
          >
            Payroll Summary Report
          </div>
        </AccordionSummary>
        <AccordionDetails style={{ padding: 20 }}>
          <OPRResponsiveGrid>
            <Grid item md={2} sm={1} xs={1}>
              <OPRSelectorControl
                isRequired
                // error={errors?.yearOfServiceOption}
                // isEditable={isEditable}
                keyName="name"
                label="Scheme type"
                multiple={false}
                name="name"
                options={[{ name: 'Commencement Date', value: 'Commencement Date' }, { name: 'Date Join Group', value: 'Date Join Group' }, { name: '418 Start Date', value: '418 Start Date' }]}
                value={[{ name: 'Commencement Date', value: 'Commencement Date' }, { name: 'Date Join Group', value: 'Date Join Group' }, { name: '418 Start Date', value: '418 Start Date' }].find((o:any) => o?.value === "'418 Start Date'")}
                valueKey="value"
                onChange={(text:any) => {
                // handleOnChange('yearOfServiceOption', text?.value)
                }}
              />
            </Grid>
            <Grid item md={2} sm={1} xs={1}>
              <OPRSelectorControl
                isRequired
                // error={errors?.yearOfServiceOption}
                // isEditable={isEditable}
                keyName="name"
                label="Scheme file number"
                multiple={false}
                name="name"
                options={[{ name: 'Commencement Date', value: 'Commencement Date' }, { name: 'Date Join Group', value: 'Date Join Group' }, { name: '418 Start Date', value: '418 Start Date' }]}
                value={[{ name: 'Commencement Date', value: 'Commencement Date' }, { name: 'Date Join Group', value: 'Date Join Group' }, { name: '418 Start Date', value: '418 Start Date' }].find((o:any) => o?.value === "'418 Start Date'")}
                valueKey="value"
                onChange={(text:any) => {
                // handleOnChange('yearOfServiceOption', text?.value)
                }}
              />
            </Grid>
          </OPRResponsiveGrid>
        </AccordionDetails>
      </Accordion>
      <Accordion
        defaultExpanded
        style={{ boxShadow: '0px 1px 1px -1px rgba(0,0,0,0.2), 0px 1px 1px 0px rgba(0,0,0,0.14), 0px 1px 3px 0px rgba(0,0,0,0.12)' }}
      >
        <AccordionSummary
          aria-controls="panel1-content"
          expandIcon={<ExpandMoreIcon />}
          id="panel1-header"
        >
          <div style={{
            width: '100%', color: '#3B3839', fontSize: 20, fontFamily: 'Lato', fontWeight: '700', wordWrap: 'break-word',
          }}
          >
            Payroll Summary Report
          </div>
        </AccordionSummary>
        <AccordionDetails style={{ padding: 20 }}>
          <OPRResponsiveGrid>
            <Grid item md={2} sm={1} xs={1}>
              <OPRSelectorControl
                isRequired
                // error={errors?.yearOfServiceOption}
                // isEditable={isEditable}
                keyName="name"
                label="Pension fund scheme"
                multiple={false}
                name="name"
                options={[{ name: 'Commencement Date', value: 'Commencement Date' }, { name: 'Date Join Group', value: 'Date Join Group' }, { name: '418 Start Date', value: '418 Start Date' }]}
                value={[{ name: 'Commencement Date', value: 'Commencement Date' }, { name: 'Date Join Group', value: 'Date Join Group' }, { name: '418 Start Date', value: '418 Start Date' }].find((o:any) => o?.value === "'418 Start Date'")}
                valueKey="value"
                onChange={(text:any) => {
                // handleOnChange('yearOfServiceOption', text?.value)
                }}
              />
            </Grid>
            <Grid item md={2} sm={1} xs={1}>
              <OPRSelectorControl
                isRequired
                // error={errors?.yearOfServiceOption}
                // isEditable={isEditable}
                keyName="name"
                label="Exchange rate"
                multiple={false}
                name="name"
                options={[{ name: 'Commencement Date', value: 'Commencement Date' }, { name: 'Date Join Group', value: 'Date Join Group' }, { name: '418 Start Date', value: '418 Start Date' }]}
                value={[{ name: 'Commencement Date', value: 'Commencement Date' }, { name: 'Date Join Group', value: 'Date Join Group' }, { name: '418 Start Date', value: '418 Start Date' }].find((o:any) => o?.value === "'418 Start Date'")}
                valueKey="value"
                onChange={(text:any) => {
                // handleOnChange('yearOfServiceOption', text?.value)
                }}
              />
            </Grid>
            <Grid item md={2} sm={1} xs={1}>
              <OPRSelectorControl
                isRequired
                // error={errors?.yearOfServiceOption}
                // isEditable={isEditable}
                keyName="name"
                label="Include all active employees"
                multiple={false}
                name="name"
                options={[{ name: 'Commencement Date', value: 'Commencement Date' }, { name: 'Date Join Group', value: 'Date Join Group' }, { name: '418 Start Date', value: '418 Start Date' }]}
                value={[{ name: 'Commencement Date', value: 'Commencement Date' }, { name: 'Date Join Group', value: 'Date Join Group' }, { name: '418 Start Date', value: '418 Start Date' }].find((o:any) => o?.value === "'418 Start Date'")}
                valueKey="value"
                onChange={(text:any) => {
                // handleOnChange('yearOfServiceOption', text?.value)
                }}
              />
            </Grid>
          </OPRResponsiveGrid>
        </AccordionDetails>
      </Accordion> */}
    </div>
  )
}

export default ReportOption
