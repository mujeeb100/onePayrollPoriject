import {
  Box, FormControl, FormControlLabel, FormLabel, Radio, RadioGroup,
} from '@mui/material'
import {
  useGetAllStandardReportGroupQuery, useGetAllStandardReportQuery, useStandardReportDeleteCreateMutation,
} from 'api/reports'
import { LeftCaretBlue } from 'assets/svg-images/SvgComponents'
import OPRButton from 'components/atoms/button/OPRButton'
import OPRLabel from 'components/atoms/label/OPRLabel'
import { CustomDialog } from 'components/atoms/modal/OPRModal'
import { standardReportColumn } from 'components/atoms/table/OPRTableConstant'
import { OPRInnerListLayout } from 'components/organism/OPRInnerLayoutList'
import { t } from 'i18next'
import React, { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { routes } from 'routes/routes'
import {
  generateFilterUrl, setRouteValues,
} from 'utils'

function StandardReportList() {
  const navigate: any = useNavigate()
  const [isGenerateReport, setIsGenerateReport] = useState(false)
  const [isGroupSelection, setGroupSelection] = useState(true)
  const [reportType, setReportType] = useState(null)
  const [isManageReport, setManageReport] = useState(false)
  const [selectAll, setSelectAll] = useState(false)
  const [selectedCodes, setSelectedCodes] = useState<string[]>([])
  const [filterData, setFilterData]:any = useState({
    pageNumber: 1,
    pageSize: 20,
    totalItems: 0,
    orderByAsc: false,
    sortBy: '',
    SearchText: '',
    isGroup: true,
  })
  const {
    data: allPosts,
    error: createAllPostsBankAccountError,
    isLoading: isLoadingAllPosts,
    isSuccess: isSuccessAllPosts,
    isError: isErrorAllPosts,
    error: errorAllPosts,
  } = useGetAllStandardReportQuery(generateFilterUrl(filterData), {
    pollingInterval: 5000,
  })
  // const allPosts:any = []
  const [deleteStandardReportById,
    {
      data: deleteStandardReportResponse,
      error: deleteStandardReportError,
      isLoading: deleteStandardReportLoading,
      isSuccess: deleteStandardReportSuccess,
      isError: deleteStandardReportIsError,
    }] = useStandardReportDeleteCreateMutation()
  useEffect(() => {
    if (deleteStandardReportSuccess) {
      setIsGenerateReport(false)
      setManageReport(false)
    }
  }, [deleteStandardReportSuccess])

  useEffect(() => {
    if (!isGenerateReport) {
      setManageReport(false)
    }
  }, [isGenerateReport])

  const sorting = (
    event: React.MouseEvent<unknown>,
    property: keyof any,
  ) => {
    const isAsc = filterData.sortBy === property && filterData.orderByAsc === true
    setFilterData({ ...filterData, orderByAsc: !isAsc, sortBy: property })
    // setOrder(isAsc ? 'desc' : 'asc')
    // setOrderBy(property)
  }

  useEffect(() => {
    setFilterData({ ...filterData, totalItems: allPosts?.totalItems ? allPosts?.totalItems : 0 })
  }, [allPosts?.pageNumber, filterData.sortBy, filterData.orderByAsc, allPosts?.totalItems])

  const onSearch = (e: any, data: any) => {
    setFilterData({ ...filterData, ...data })
  }
  const handlePagination = (pageNumber: number, pageSize: number) => {
    setFilterData({ ...filterData, pageNumber })
  }
  const viewAcoount = (data: any, type:string) => {

  }
  const handleView = (data: any) => {

  }
  const handleGenerateReport = () => {
    if (reportType) {
      setGroupSelection(false)
    }
    // navigate(`/${routes.standardReportsGenerate}`)
  }
  const goToNextGenerateReport = (id:any) => {
    navigate(
      setRouteValues(`/${reportType === 'false' ? routes.standardReportsGenerate : routes.standardReportsGenerateView}`, {
        id,
        state: reportType,
      }),
    )
  }
  return (
    <Box sx={{ display: 'flex' }}>
      {/* <ReportForm /> */}
      <CustomDialog
        CustomStyles={{ borderRadius: '16px' }}
        isOpen={isGenerateReport}
        type="loader"
      >
        {
          isGroupSelection ? <GroupSelection handleGenerateReport={handleGenerateReport} value={reportType} onChange={setReportType} />
          : (
            <GroupSelectionList
              deleteStandardReportById={deleteStandardReportById}
              goToNextGenerateReport={goToNextGenerateReport}
              isGenerateReport={isGenerateReport}
              isManageReport={isManageReport}
              reportType={reportType}
              selectAll={selectAll}
              selectedCodes={selectedCodes}
              setIsGenerateReport={setIsGenerateReport}
              setSelectAll={setSelectAll}
              setSelectedCodes={setSelectedCodes}
            />
          )
        }

        {/* <GroupSelectionList
          isGenerateReport={isGenerateReport}
          setIsGenerateReport={setIsGenerateReport}
        /> */}

        <Box sx={{
          display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: 5,
        }}
        >
          <OPRButton
            color="info"
            variant="text"
            onClick={() => {
              setReportType(null)
              setGroupSelection(true)
              setIsGenerateReport(false)
            }}
          >
            Cancel
          </OPRButton>
          {
            reportType === 'true' && !isGroupSelection ? (
              <OPRButton
                color="info"
                variant="text"
                onClick={() => {
                  // handleGenerateReport()
                  if (isManageReport) {
                    deleteStandardReportById({
                      ids: selectedCodes,
                    })
                  } else {
                    setManageReport(!isManageReport)
                  }
                }}
              >
                {isManageReport ? 'Delete Report' : 'Manage Report' }
              </OPRButton>
            ) : (
              <OPRButton
                color="info"
                variant="text"
                onClick={() => {
                  handleGenerateReport()
                  // setManageReport(!isManageReport)
                }}
              >
                Continue
              </OPRButton>
            )
          }
        </Box>
      </CustomDialog>
      <OPRInnerListLayout
        Search={filterData.SearchText}
        addHandleClick={() => {
          setIsGenerateReport(true)
        }}
        columns={standardReportColumn(viewAcoount)}
        dataList={JSON.parse(JSON.stringify(allPosts?.records || []))}
        error={deleteStandardReportError}
        filterData={filterData}
        handlePagination={handlePagination}
        handleSearch={onSearch}
        isError={deleteStandardReportIsError}
        loading={deleteStandardReportLoading || isLoadingAllPosts}
        rowClickHandler={handleView}
        rowNumber={0}
        sortHandleClick={sorting}
        success={deleteStandardReportSuccess}
        title={t('Standard Report')}
      />
    </Box>
  )
}

export default StandardReportList

function GroupSelection({ handleGenerateReport, value, onChange }:any) {
  return (
    <FormControl>
      <FormLabel
        id="demo-radio-buttons-group-label"
        style={{
          width: '100%', color: '#3B3839', fontSize: 24, fontFamily: 'Lato', fontWeight: '700', wordWrap: 'break-word',
        }}
      >
        Generate report
      </FormLabel>
      <RadioGroup
        aria-labelledby="demo-radio-buttons-group-label"
        name="radio-buttons-group"
        value={value}
        onChange={(e) => {
          onChange(e.target.value)
        }}
      >
        <FormControlLabel control={<Radio />} label="Ad-hoc reporting" value={false} />
        <FormControlLabel value control={<Radio />} label="Pre-defined reporting" />
      </RadioGroup>
    </FormControl>

  )
}

function GroupSelectionList({
  isGenerateReport,
  setIsGenerateReport,
  reportType,
  goToNextGenerateReport,
  isManageReport,
  selectAll,
  setSelectAll,
  selectedCodes,
  setSelectedCodes,
}:any) {
  // const [dataList, setEmployees]:any = useState([])

  const [dataList, setDataList]:any = useState([])
  console.log(isManageReport, 'isManageReportisManageReport')

  const {
    data: allPosts,
    error: createAllPostsBankAccountError,
    isLoading: isLoadingAllPosts,
    isSuccess: isSuccessAllPosts,
    isError: isErrorAllPosts,
    error: errorAllPosts,
  } = useGetAllStandardReportGroupQuery(`&isTemplate=${reportType}`)
  const predefineLayout:any = (item:any) => (
    <>
      <div style={{
        alignSelf: 'stretch', color: '#3B3839', fontSize: 16, fontFamily: 'Lato', fontWeight: '700', wordWrap: 'break-word',
      }}
      >
        {item?.name}
      </div>
      <div style={{
        alignSelf: 'stretch', color: '#666364', fontSize: 14, fontFamily: 'Lato', fontWeight: '400', wordWrap: 'break-word',
      }}
      >
        {item?.reportRequirements?.join(', ')}
      </div>
    </>
  )

  const handleCheckboxChange = (event: React.ChangeEvent<HTMLInputElement>, code: string) => {
    const { checked } = event.target
    if (checked) {
      setSelectedCodes([...selectedCodes, code])
    } else {
      setSelectedCodes(selectedCodes.filter((selectedCode:any) => selectedCode !== code))
    }
  }
  const handleRemoveEmployee = (codeToRemove: string) => {
    // Filter out the selected employee code to remove it from the selectedCodes state
    setSelectedCodes(selectedCodes.filter((code:any) => code !== codeToRemove))
  }
  const handleSelectAllChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const { checked } = event.target
    if (checked) {
      setSelectedCodes(dataList.map((employee:any) => employee.id))
    } else {
      setSelectedCodes([])
    }
    setSelectAll(checked)
  }
  const handleEmployeeSelection = (selectedCodes: string[]) => {
    setDataList(selectedCodes)
  }
  const expectedOutPut = (rowData:any) => {
    const data = rowData?.map((item:any) => {
      let reportRequirements = item?.reportRequirements
      // const reportTypes = item?.reportTypes
      if (item?.reportRequirements?.length > 0) {
        reportRequirements = item?.reportRequirements.map((obj:any) => obj.reportType)
      }
      if (item?.reportTypes?.length > 0) {
        reportRequirements = item?.reportTypes.map((obj:any) => obj
          .name)
      }
      const modifiedItem = {
        ...item,
        reportRequirements,
      }
      return modifiedItem
    })
    return data
  }
  useEffect(() => {
    // console.log('&&&&&&&&&&&&&&&&&', expectedOutPut(allPosts?.records || []))

    // setDataList(expectedOutPut(rowData || []))
  }, [allPosts?.records.length])
  useEffect(() => {
    if (isSuccessAllPosts) {
      setDataList(expectedOutPut(allPosts?.records || []))
    }
  }, [isSuccessAllPosts])

  if (isLoadingAllPosts) return <div>Loading...</div>
  console.log(dataList, '*****************', isManageReport)

  return (
    <div>
      <div style={{
        width: '100%', color: '#3B3839', fontSize: 24, fontFamily: 'Lato', fontWeight: '700', wordWrap: 'break-word',
      }}
      >
        Select report group
      </div>
      <div style={{ overflowY: 'scroll', height: 400 }}>
        {/* {isManageReport && (
          <OPRMultiselectChckBox
            dataList={dataList}
            handleCheckboxChange={handleCheckboxChange}
            handleRemoveEmployee={handleRemoveEmployee}
            handleSelectAllChange={handleSelectAllChange}
            selectAll={selectAll}
            selectedCodes={selectedCodes}
            onChange={handleEmployeeSelection}
          />
        )} */}
        {isManageReport && (
          <>
            <label style={{ marginBottom: '10px', marginTop: '10px', display: 'block' }}>
              <input
                checked={selectAll}
                type="checkbox"
                onChange={handleSelectAllChange}
              />
              {' '}
              Select All
            </label>
            <hr style={{ borderColor: '#E8E6E7', marginBottom: '10px' }} />
          </>
        )}
        {dataList.map((item:any, index:any) => (
          <div style={{
            width: '100%', justifyContent: 'flex-start', cursor: 'pointer', alignItems: 'center', gap: 16, display: 'inline-flex',
          }}
          >
            <div style={{
              flex: '1 1 0', flexDirection: 'column', justifyContent: 'flex-start', alignItems: 'flex-start', display: 'inline-flex',
            }}
            >
              <div style={{
                alignSelf: 'stretch', paddingTop: 12, paddingBottom: 12, paddingLeft: 8, justifyContent: 'flex-start', alignItems: 'flex-start', gap: 8, display: 'inline-flex',
              }}
              >
                <div style={{
                  flex: '1 1 0', flexDirection: 'column', justifyContent: 'flex-start', alignItems: 'flex-start', display: 'inline-flex',
                }}
                >
                  {
                    isManageReport ? (
                      <div key={item.id}>
                        <div style={{ display: 'flex', alignItems: 'center', marginBottom: '5px' }}>
                          <label style={{ marginRight: '10px', display: 'flex' }}>
                            <input
                              checked={selectedCodes?.includes(item.id)}
                              type="checkbox"
                              value={item.id}
                              onChange={(event) => handleCheckboxChange(event, item.id)}
                            />
                            <div style={{ display: 'block' }}>
                              <OPRLabel label={` ${item?.name}`} variant="subtitle2" />
                              <OPRLabel label={`${item?.reportRequirements?.join(', ')}`} variant="body2" />
                            </div>
                          </label>
                        </div>
                        {/* <hr style={{ borderColor: '#E8E6E7', marginTop: '5px', marginBottom: '5px' }} /> */}
                      </div>
                    ) : (
                      <>
                        <div style={{
                          alignSelf: 'stretch', color: '#3B3839', fontSize: 16, fontFamily: 'Lato', fontWeight: '700', wordWrap: 'break-word',
                        }}
                        >
                          {item?.name}
                        </div>
                        <div style={{
                          alignSelf: 'stretch', color: '#666364', fontSize: 14, fontFamily: 'Lato', fontWeight: '400', wordWrap: 'break-word',
                        }}
                        >
                          {item?.reportRequirements?.join(', ')}
                        </div>
                      </>
                    )
                  }

                </div>
              </div>
            </div>
            <Box
              style={{
                justifyContent: 'flex-start', alignItems: 'flex-start', gap: 16, display: 'flex',
              }}
              onClick={() => {
                goToNextGenerateReport(item?.id)
              }}
            >
              <div style={{
                flexDirection: 'column', justifyContent: 'flex-start', alignItems: 'flex-end', display: 'inline-flex',
              }}
              >
                <div style={{
                  alignSelf: 'stretch', paddingTop: 12, paddingBottom: 12, paddingLeft: 8, justifyContent: 'flex-end', alignItems: 'center', gap: 8, display: 'inline-flex',
                }}
                >
                  <div style={{
                    paddingTop: 2, paddingBottom: 2, justifyContent: 'flex-start', alignItems: 'center', display: 'flex',
                  }}
                  >

                    <div style={{ width: 16, height: 16, position: 'relative' }}>
                      {/* <div style={{
                        width: 12, height: 7, left: 12.50, top: 2.50, position: 'absolute', transform: 'rotate(90deg)', transformOrigin: '0 0', background: '#0049DB',
                      }}
                      /> */}
                      <LeftCaretBlue />
                    </div>
                  </div>
                </div>
              </div>
            </Box>
          </div>
        ))}
      </div>
    </div>
  )
}
