import { useTheme } from '@emotion/react'
import {
  Box,
} from '@mui/material'
import { Info } from 'assets/svg-images/SvgComponents'
import OPRButton from 'components/atoms/button/OPRButton'
import OPRLabel from 'components/atoms/label/OPRLabel'
import { validationSchemaPasswordEmpgeneration } from 'constants/validate'
import useForm from 'hooks/useForm'
import React, { useState } from 'react'
import { useLocation, useNavigate } from 'react-router-dom'

import { CustomDialog } from '../../../components/atoms/modal/OPRModal'

type DropDownModalProps = {
    onClose: () => void;
    dropDown: boolean;
    handleFinalize: () => void;
    referenceNumber:any;
  };

  type VoidModalProps = {
    onClose: () => void;
    handlevoide: () => void;
    voideModal:boolean;
    referenceNumber:any;

  };
export function DropDownModal({
  dropDown, onClose, handleFinalize,
  referenceNumber,
}: DropDownModalProps) {
  const theme:any = useTheme()
  const location: any = useLocation()
  const [isNextModalOpen, setIsNextModalOpen] = useState(false)
  // useEffect(() => {
  //   console.log('Reference Number:', referenceNumber)
  // }, [referenceNumber])
  const {
    values,
    setValues,
    errors,
    handleChange,
    setErrors,
    handleFormSubmit,
    handleOnChange,
  } = useForm(validationSchemaPasswordEmpgeneration)
  const id = ''
  const navigate = useNavigate()

  const exportClose = () => {
    setIsNextModalOpen(false)
  }

  return (
    <Box>

      <CustomDialog
        isOpen={dropDown}
        type="loader"
      >
        <Box>
          <Box sx={{ display: 'block' }}>
            <OPRLabel sx={{ margin: '10px 0' }} variant="h4">Finalize generation reference confirmation</OPRLabel>
            <OPRLabel variant="body2">
              Are you sure you want to finalize
              {referenceNumber}
              ?
            </OPRLabel>
            <OPRLabel sx={{ margin: '10px 0' }} variant="body2">  You will not be able to revert it.</OPRLabel>
          </Box>

          <Box style={{
            justifyContent:
                     'space-between',
            alignItems: 'center',
            gap: 10,
            display: 'flex',
            marginTop: '20px',
          }}
          >

            <OPRButton
              color="primary"
              variant="contained"
              onClick={onClose}
            >
              Cancel
            </OPRButton>

            <OPRButton
              color="primary"
              variant="outlined"
              onClick={handleFinalize}
            >
              Confirm
            </OPRButton>

          </Box>
        </Box>

      </CustomDialog>

    </Box>
  )
}

export function VoidModal({
  onClose, handlevoide, voideModal, referenceNumber,
}: VoidModalProps) {
  const theme:any = useTheme()
  const location: any = useLocation()
  const [isNextModalOpen, setIsNextModalOpen] = useState(false)

  const {
    values,
    setValues,
    errors,
    handleChange,
    setErrors,
    handleFormSubmit,
    handleOnChange,
  } = useForm(validationSchemaPasswordEmpgeneration)
  const id = ''
  const navigate = useNavigate()

  const exportClose = () => {
    setIsNextModalOpen(false)
  }

  return (
    <Box>

      <CustomDialog
        isOpen={voideModal}
        type="loader"
      >
        <Box>
          <Box sx={{ display: 'block' }}>
            <OPRLabel sx={{ margin: '10px 0' }} variant="h4">Void generation reference confirmation</OPRLabel>
            <OPRLabel variant="body2">
              Are you sure you want to void
              {referenceNumber}
              ?
            </OPRLabel>
            <OPRLabel sx={{ margin: '10px 0' }} variant="body2">  You will not be able to revert it.</OPRLabel>
            <Box
              className="pop-up"
              sx={{
                display: 'flex',
                padding: '12px',
                gap: '12px',
                alignItems: 'flex-start',
                borderRadius: '4px',
                alignSelf: 'stretch',
                backgroundColor: `${theme.palette.Invite.main}`,
                marginTop: 3,
              }}
            >
              <Info />
              <OPRLabel
                CustomStyles={{
                  backgroundColor: `${theme.palette.Invite.main}`,
                }}
                backgroundColor={theme.palette.Invite.main}
                variant="body2"
              >
                After voiding the generation reference, you will not be able to export the reports/files associated with the generation reference.
              </OPRLabel>
            </Box>
          </Box>

          <Box style={{
            justifyContent:
                     'space-between',
            alignItems: 'center',
            gap: 10,
            display: 'flex',
            marginTop: '20px',
          }}
          >
            <OPRButton
              color="primary"
              variant="contained"
              onClick={onClose}
            >
              Cancel
            </OPRButton>

            <OPRButton
              color="primary"
              variant="outlined"
              onClick={handlevoide}
            >
              Confirm
            </OPRButton>
          </Box>

        </Box>

      </CustomDialog>

    </Box>
  )
}
