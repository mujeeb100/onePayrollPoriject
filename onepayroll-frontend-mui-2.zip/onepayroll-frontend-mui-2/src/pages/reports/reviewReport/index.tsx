import './index.css'

import { useTheme } from '@emotion/react'
import {
  Badge,
  Box,
  Grid,
  MenuItem,
  Tab,
  Tabs,
} from '@mui/material'
import {
  useGetAllReviewReportLogsFileQuery, useGetAllReviewReportQuery, useGetAllReviewReportViewQuery, useReviewReportCreateMutation,
  useReviewReportExportCreateMutation,
} from 'api/reportingServices'
import { ReactComponent as SuccessIcon } from 'assets/svg-icons/Tick.svg'
import axios from 'axios'
import OPRButton from 'components/atoms/button/OPRButton'
import OPRLabel from 'components/atoms/label/OPRLabel'
import { CustomDialog } from 'components/atoms/modal/OPRModal'
import OPRMultiSelectCheckbox from 'components/atoms/multiSelectCheckbox'
import {
  reviewReport,
  reviewReportLogs,
} from 'components/atoms/table/OPRTableConstant'
import OPRInputControl from 'components/molecules/OPRInputControl'
import OPRResponsiveGrid from 'components/molecules/OPRResponsiveGrid'
import OPRSelectorControl from 'components/molecules/OPRSelectorControl/OPRSelectorControl'
import OPRAlertControl from 'components/organism/OPRAlertControl'
import { OPRInnerListLayout } from 'components/organism/OPRInnerLayoutList'
import apiEndPoint from 'constants/apiEndPoint'
import { } from 'constants/exportColumnMappings'
import { displayFormatDateTime } from 'constants/index'
import { validationSchemaReviewReport } from 'constants/validate'
import saveAs from 'file-saver'
import { useEditable } from 'hooks/useEdit'
import useForm from 'hooks/useForm'
import { t } from 'i18next'
import { IOPRMultiSelectCheckboxSXProps } from 'interfaces'
import React, { useEffect, useState } from 'react'
// import { entityPayrollHistoryColumn, nationalityColumn } from 'components/atoms/table/OPRTableConstant'
import { useLocation, useNavigate } from 'react-router-dom'
import { routes } from 'routes/routes'
import { DropDownOption } from 'types'
import {
  flattenDropDownOptions,
  generateFilterUrl, getAPIWithEntityUrl, getauthToken,
} from 'utils'

import { DropDownModal, VoidModal } from './dropDownModal'
import { ExportReportModal } from './exportReportAlert'

interface TabPanelProps {
    children?: React.ReactNode;
    index: number;
    value: number;
  }

  type FilterData = {
    pageNumber: number
    pageSize: number
    orderByAsc: boolean
    sortBy: string | number | symbol
    reportTypeCodes: DropDownOption[]
  }
function CustomTabPanel(props: TabPanelProps) {
  const {
    children, value, index, ...other
  } = props

  return (
    <div
      aria-labelledby={`simple-tab-${index}`}
      hidden={value !== index}
      id={`simple-tabpanel-${index}`}
      role="tabpanel"
      {...other}
    >
      {value === index && (
        <Box sx={{ pt: 5 }}>
          {children}
        </Box>
      )}
    </div>
  )
}

function a11yProps(index: number) {
  return {
    id: `simple-tab-${index}`,
    'aria-controls': `simple-tabpanel-${index}`,
  }
}

function ReviewReportList(props: any) {
  const location: any = useLocation()
  const { anchorEl } = props
  // const [reportData, setreportData] = useState(null)
  const [value, setValue] = useState(0)
  const [isSuccess, setIsSuccess]:any = useState(false)
  const [isOpen, setIsOpen]:any = useState(false)
  const [isDropdownOpen, setIsDropdownOpen] = useState(false)
  const [isDropDownModalOpen, setIsDropDownModalOpen] = useState(false)
  const [isvoidModalOpen, setIsVoidModalOpen] = useState(false)
  const [referenceNumber, setReferenceNumber] = useState('')
  const [finalizedDate, setFinalizedDate] = useState('')
  const [voidDate, setVoidDate] = useState('')
  const [isVoidSuccess, setIsVoidSuccess] = useState(false)
  const [selectedType, setSelectedType] = useState(null)
  const [selectedCodes, setSelectedCode] = useState<string[]>([])

  const {
    values,
    setValues,
    errors,
    handleChange,
    setErrors,
    handleFormSubmit,
    handleOnChange,
  } = useForm(validationSchemaReviewReport)
  const { isEditable, setEditable } = useEditable()

  // Checkbox state
  const [selectedPayrollCodes, setSelectedCodes]:any = useState([])
  const [filterAction, setFilterAction]:any = React.useState({
    publishTime: '',
    actionStatus: '',
    finalizedDate: '',
    voidDate: '',
  })

  const theme:any = useTheme()
  const navigate: any = useNavigate()
  // const [selectedOptions, setSelectedOptions]:any = useState<any>(
  //   {
  //     reportCode: [],

  //   },

  // )

  const handleTabChange = (event: React.SyntheticEvent, newValue: number) => {
    setValue(newValue)
  }
  const [filteringOptions, setFilteringOptions] = useState({
    reports: [],
  })

  const initialFilterData = {
    actionStatus: '',
    jobStatus: 'Success',
    pageSize: 2000,
    sortBy: '',
    SearchText: '',
    referenceId: '',
    reportTypeCodes: [],
  }

  const [filterData, setFilterData]: any = useState(initialFilterData)

  const transformData = () => {
    const payload: any = { ...filterData }
    payload.reportTypeCodes = flattenDropDownOptions(filterData.reportTypeCodes)
    return payload
  }
  const [reportData, setReportData]:any = useState({
    referenceId: '',

  })

  const {
    data: allPostsLog,
    isLoading: isLoadingAllPostsLogs,
    isSuccess: isSuccessAllPostsLogs,
    isError: isErrorAllPostsLogs,
    error: errorAllPostsLogs,
    refetch: refetchAllPostsLogs,
  } = useGetAllReviewReportLogsFileQuery(`${generateFilterUrl('')}`)

  // files api
  const {
    data: allPosts,
    isLoading: isLoadingAllPosts,
    isSuccess: isSuccessAllPosts,
    isError: isErrorAllPosts,
    error: errorAllPosts,
    refetch: refetchAllPosts,
  } = useGetAllReviewReportQuery(generateFilterUrl(transformData()))

  // reporting view api getting reference API from this
  const {
    data: allRef,
    refetch: refetchAllRef,
  } = useGetAllReviewReportViewQuery(generateFilterUrl(filterData))
  //

  // download multi api
  const [createExportReport, {
    data: createdExportReportData,
    error: createdExportReportError,
    isLoading: createdExportReportLoading,
    isSuccess: createdExportReportSuccess,
    isError: createdExportReportIsError,
  }] = useReviewReportExportCreateMutation()

  function findObjectById(array:any, id:any) { return array.find((obj:any) => obj.id === id) }

  useEffect(() => {
    if (isSuccessAllPosts) {
      const options = filteringOptions.reports.filter((item: DropDownOption) => (filterData.reportTypeCodes.some((reportTypeCodes: DropDownOption) => reportTypeCodes.roleCode === item.roleCode)))
      filterData.reportTypeCodes = options
      setFilterData({ ...filterData })
    }
  }, [isSuccessAllPosts, filteringOptions])

  useEffect(() => {
    if (isSuccessAllPosts) {
      const reportCodeOptionSet = new Set()
      allPosts?.records?.forEach((item: any) => {
        reportCodeOptionSet.add(item.batchJob?.reportType?.id)
      })
      const reportCodeOption = Array.from(reportCodeOptionSet).map((id: any) => {
        const item = allPosts?.records.find((record: any) => record.batchJob?.reportType?.id === id)
        return {
          roleCode: item?.batchJob?.reportType?.code,
          roleName: item?.batchJob?.reportType?.name,
        }
      })
      setFilteringOptions((prev: any) => ({
        ...prev, reports: reportCodeOption,
      }))
    }
  }, [isSuccessAllPosts])

  // useEffect(() => {
  //   if (isSuccessAllPosts) {
  //     const reports = allPosts?.records.map((item: any) => ({
  //       roleCode: item?.batchJob?.reportType?.code,
  //       roleName: item?.batchJob?.reportType?.name,
  //     }))

  //     setFilteringOptions({
  //       reports,
  //     })
  //   }
  // }, [allPosts])

  const sorting = (
    event: React.MouseEvent<unknown>,
    property: keyof any,
  ) => {
    const isAsc = filterData.sortBy === property && filterData.orderByAsc === true
    setFilterData({ ...filterData, orderByAsc: !isAsc, sortBy: property })
  }

  useEffect(() => {
    setFilterData({ ...filterData, totalItems: allPosts?.totalItems ? allPosts?.totalItems : 0 })
  }, [allPosts?.pageNumber, filterData.sortBy, filterData.orderByAsc, allPosts?.totalItems])

  const onSearch = (e: any, data: any) => {
    setFilterData({ ...filterData, ...data })
  }
  const handlePagination = (pageNumber: number, pageSize: number) => {
    setFilterData({ ...filterData, pageNumber })
  }
  // report action api
  const [createReviewReportAction, {
    data: createdReviewReportActionData,
    error: createdReviewReportActionError,
    isLoading: createdReviewReportActionLoading,
    isSuccess: createdReviewReportActionSuccess,
    isError: createdReviewReportActionIsError,
  }] = useReviewReportCreateMutation()

  useEffect(() => {
    if (createdReviewReportActionSuccess) {
      setFilterData(initialFilterData) // Reset the filterData to initial state
    }
  }, [createdReviewReportActionSuccess])

  const handleExportButtonClick = () => {
    setIsOpen(true)
  }

  const renderValue = (selected: string[], filterName: string) => (
    <Box key={filterName} style={{ display: 'flex', justifyContent: 'space-between' }}>
      <span style={{ paddingLeft: '10px' }}>
        {t(`${filterName}`)}
      </span>
      <Badge
        badgeContent={selected?.length || 0}
        sx={{
          '& .MuiBadge-badge': {
            color: '#0037A4',
            backgroundColor: 'white',
            fontWeight: '700',
            fontSize: '14px',
          },
          marginTop: '12px',
          marginRight: '10px',
        }}
      />
    </Box>
  )
  const handleManageReportsClick = (e:any) => {
    setIsDropdownOpen(!isDropdownOpen)
  }
  const handleOptionClick = () => {
    setIsDropDownModalOpen(true) // finalize modal
    setIsDropdownOpen(false) // Close the dropdown
  }
  const handleOptionClick1 = (e:any) => {
    setSelectedType(e)
    if (e === 'Void') {
      setIsVoidModalOpen(true) // void modal
      setIsDropdownOpen(false) // Close the dropdown
    } else {
      setIsDropDownModalOpen(true) // finalize modal
      setIsDropdownOpen(false) // Close the dropdown
    }
  }
  // #region Filter Layout
  const dropdownInputStyle = (selected?: DropDownOption[]) : IOPRMultiSelectCheckboxSXProps => {
    const count = selected?.length || 0
    let result: IOPRMultiSelectCheckboxSXProps = { }
    if (count > 0) {
      result = { ...result, backgroundColor: '#0037A4', color: '#FFFFFF' }
    }
    return result
  }
  const filterLayout = () => (
    <OPRMultiSelectCheckbox
      listOfOptions={filteringOptions?.reports || []}
      renderValue={(selected:any) => renderValue(selected, 'Report Type')}
      selectedOptions={filterData?.reportTypeCodes}
      setSelectedOptions={(item: any) => {
        filterData.reportTypeCodes = item
        setFilterData({ ...filterData })
      }}
      // sx={dropdownInputStyle(filterData.reportTypeCodes)}
    />
  )

  const handleSubmit = () => {

  }

  const handleFinalize = async () => {
    if (allRef?.records.length > 0 && allPosts?.records.length > 0) {
      const selectedRecord = allRef?.records.find((record: any) => record.referenceNumber === referenceNumber)

      if (selectedRecord) {
        // const actionType = selectedRecord.actionStatus === 'Draft' ? 'Finalized' : 'Void'

        const payload = {
          generationReference: selectedRecord.id,
          actionType: selectedType,
        }

        try {
          const { data, actionType: responseActionType } = await createReviewReportAction(payload)

          if (data && responseActionType) {
          // Update the action status in the selectedRecord based on the actionType from the response
            selectedRecord.actionStatus = responseActionType

            // Update the filterAction status
            setFilterAction({ ...filterAction, actionStatus: responseActionType })
          }
        } catch (error) {
        // Handle error
        }
      }
    } else {
      alert('No records found.') // Alert when no record is found
    }

    // Close the modals
    setIsDropDownModalOpen(false)
    setIsVoidModalOpen(false)
  }

  useEffect(() => {
    if (createdReviewReportActionSuccess === true) {
      const selectedRecord = allRef?.records.find((record: any) => record.referenceNumber === referenceNumber)

      // Set the reference number

      if (selectedRecord) {
        setFilterAction((prevFilterAction: any) => {
          const updatedAction = {
            ...prevFilterAction,
            actionType: selectedType,
          }

          if (selectedType === 'Finalized') {
            setIsSuccess(true)
            updatedAction.finalizedDate = new Date().toISOString() // Convert to string
            updatedAction.voidDate = undefined
          } else if (selectedType === 'Void') {
            setIsVoidSuccess(true)
            updatedAction.voidDate = new Date().toISOString() // Convert to string
            updatedAction.finalizedDate = undefined
          }

          // Update finalizedDate and voidDate based on selectedType
          if (updatedAction.actionStatus === selectedType) {
            updatedAction.finalizedDate = new Date().toISOString()
            updatedAction.voidDate = new Date().toISOString()
          }

          // Update actionStatus after createdReviewReportActionSuccess
          const newActionStatus = selectedType // Replace with your dynamic value for actionStatus
          updatedAction.actionStatus = newActionStatus

          // Update actionStatus after createdReviewReportActionSuccess

          // Set the reference number
          // setReferenceNumber(selectedRecord.referenceNumber)
          setSelectedType(newActionStatus)
          return updatedAction
        })
      }
    }
  }, [createdReviewReportActionSuccess])

  const renderTopButtons = () => (
    <Box sx={{ display: 'flex', justifyContent: 'space-between', margin: '20px 0 0' }}>
      <div>

        <OPRLabel variant="h2">Reference details</OPRLabel>

      </div>
      <div style={{ position: 'relative' }}>
        <OPRButton
          exportIcon
          color="primary"
          style={{ borderRadius: '110px', marginRight: '10px' }}
          variant="outlined"
          onClick={handleExportButtonClick}
        >
          Export reports
        </OPRButton>
        <OPRButton
          color="primary"
          disabled={filterAction?.actionStatus === 'Void'}
          onClick={handleManageReportsClick}
        >
          Manage reports
        </OPRButton>

        {/* Dropdown menu */}
        {isDropdownOpen && (
          <div
            className="dropdown-menu"
            style={{
              background: 'white', padding: '20px', zIndex: 999,
            }}
          >
            <ul className="report-drpdwn">
              <MenuItem disabled={filterAction?.actionStatus === 'Finalized'} onClick={() => handleOptionClick1('Finalized')}> Finalize generation reference</MenuItem>
              <MenuItem sx={{ color: '#DA3237' }} onClick={() => handleOptionClick1('Void')}>Void generation reference</MenuItem>
              {/* Add more options as needed */}
            </ul>
          </div>
        )}
      </div>
    </Box>
  )
  const handleOnChange1 = (event: { target: { name: string; value: any; } }) => {
    const { name, value } = event.target

    // Update filterData state
    setFilterData((prevFilterData: any) => ({
      ...prevFilterData,
      [name]: value,
      pageSize: prevFilterData.pageSize || 2000, // Ensure pageSize is maintained
      pageNumber: prevFilterData.pageNumber || 1, // Ensure pageNumber is maintained
    }))

    // Set the value of the input field
    setValues((prevValues: any) => ({
      ...prevValues,
      [name]: value,
    }))

    // Check if the changed field is referenceNumber
    if (name === 'referenceNumber') {
      const selectedOption = allRef.records.find((obj:any) => obj.referenceNumber
      === value)

      if (selectedOption) {
        setFilterAction({
          publishTime: selectedOption.publishTime,
          actionStatus: selectedOption.actionStatus,
          finalizedDate: selectedOption.finalizedDate,
          voidDate: selectedOption.voidDate,
        })
        setFilterData((prevFilterData: any) => ({
          ...prevFilterData,
          referenceId: selectedOption.id,
          actionStatus: selectedOption.actionStatus,
          pageSize: prevFilterData.pageSize || 2000,
          pageNumber: prevFilterData.pageNumber || 1,
        }))
      } else {
        // If selectedOption is not found, reset actionStatus to empty string
        setFilterData((prevFilterData: any) => ({
          ...prevFilterData,
          actionStatus: '',
          pageSize: prevFilterData.pageSize || 2000,
          pageNumber: prevFilterData.pageNumber || 1,
        }))
      }

      setReferenceNumber(value)
    }
  }

  const handleCancel = () => {
    setIsOpen(true)
  }
  const handleExport = async () => {
    // Check if referenceNumber is not empty

    if (referenceNumber && selectedCodes.length > 0) {
      // Construct the payload
      const payload = {
        ReportRecordListId: selectedCodes, // Include all selected codes
        GenerationReference: referenceNumber,
        MultiDownload: true,
      }
      // Fetch the filename from the payload
      const reportName = allPosts?.records.find((record: any) => selectedCodes.includes(record.id))?.fileName

      try {
        // Call the API to export reports
        const response = await createExportReport(payload)

        if (response) {
          // If the API call is successful, initiate file download
          const urldownload = `${process.env.REACT_APP_MP_BASE_URL}/${apiEndPoint.createReviewReportExport}`
          const token = getauthToken() // Assuming you have a function to get the auth token

          const downloadResponse = await axios.post(
            getAPIWithEntityUrl(urldownload),
            payload,
            {
              responseType: 'blob',
              headers: {
                Authorization: `Bearer ${token}`,
              },
            },
          )

          if (downloadResponse.status === 200) {
            const contentDisposition = downloadResponse.headers['content-disposition']
            const regExpFilename = /filename\*=UTF-8''(.+?)(;|$)|filename="(.+?)"(;|$)|filename=(.+?)(;|$)/
            let filename = `${referenceNumber}.zip`

            const matches = regExpFilename.exec(contentDisposition)
            if (matches) {
              filename = decodeURIComponent(matches[1] || matches[3] || matches[5])
            } else {
              filename = `${referenceNumber}.zip`
              // filename = selectedCodes.length > 1 ? `${referenceNumber}.zip` : reportName
            }

            // Create a new Blob object with the response data
            const blob = new Blob([downloadResponse.data], { type: downloadResponse.headers['content-type'] })

            // Use file-saver to save the file
            saveAs(blob, filename)

            // Refresh the page (if needed)
            // window.location.reload()
          }
        }
      } catch (error) {
        console.log('Error during file download:', error)
      }

      // Close modal and show success alert
      setIsOpen(false)
    }
  }
  const viewAcoount = async (data: any, type: string) => {
    if (type === 'Export file') {
      const { selectedId } = data // Single selected ID
      const reportName = JSON.parse(JSON.stringify(allPosts?.records || []))
        .find((o:any) => (o?.id === selectedId))

      if (!selectedId) {
        return
      }

      // const selectedRecord = allRef?.records.find((record: any) => record.id === selectedId)

      if (referenceNumber && selectedId.length > 0) {
        const payload = {
          ReportRecordListId: [selectedId],
          GenerationReference: referenceNumber,
          MultiDownload: false,
        }

        try {
          const response = await createExportReport(payload)

          if (response) {
            const urldownload = `${process.env.REACT_APP_MP_BASE_URL}/${apiEndPoint.createReviewReportExport}`
            const token = getauthToken()

            const downloadResponse = await axios.post(getAPIWithEntityUrl(urldownload), payload, {
              responseType: 'blob',
              headers: {
                Authorization: `Bearer ${token}`,
              },
            })

            if (downloadResponse.status === 200) {
              let filename = reportName?.fileName
              const contentDisposition = downloadResponse.headers['content-disposition']
              const regExpFilename = /filename\*=UTF-8''(.+?)(;|$)|filename="(.+?)"(;|$)|filename=(.+?)(;|$)/
              const matches = regExpFilename.exec(contentDisposition)

              if (matches) {
                filename = decodeURIComponent(matches[1] || matches[3] || matches[5])
              }

              const blob = new Blob([downloadResponse.data], { type: downloadResponse.headers['content-type'] })
              saveAs(blob, filename)
            }
          }
        } catch (error) {
          console.log('Error during file download:', error)
        }
      } else {
        console.log('Selected record not found for provided ID')
      }
    } else {
      console.log('Invalid action type:', type)
    }
  }

  return (
    <>

      <Box sx={{ display: 'flex', flexDirection: 'column' }}>
        <OPRLabel label={t('Review reports')} variant="h2" />
        <Box>
          <Tabs aria-label="basic tabs example" value={value} onChange={handleTabChange}>
            <Tab label="Reports" {...a11yProps(0)} />
            <Tab label="Logs" {...a11yProps(1)} />
          </Tabs>
        </Box>
        <CustomTabPanel index={0} value={value}>
          <Box sx={{ marginTop: '30px', marginBottom: '30px' }}>
            <OPRResponsiveGrid>
              <Grid item md={2} sm={1} xs={1}>
                <OPRSelectorControl
                  // disabled={createdReviewReportActionSuccess}
                  error={errors?.referenceNumber}
                  // isEditable={createdReviewReportActionSuccess ? true : isEditable}
                  keyName="label"
                  label="Generation reference"
                  multiple={false}
                  name="label"
                  options={(allRef?.records || []).map((record: any) => ({
                    value: `${record?.referenceNumber} ${record?.actionStatus}`,
                    label: `${record?.referenceNumber} ${record?.actionStatus}`,
                    publishTime: record?.publishTime,
                    actionStatus: record?.actionStatus,
                    referenceNumber: record?.referenceNumber,
                  }))}
                  placeholder="Select an option"
                  value={(allRef?.records || []).map((record: any) => ({
                    value: `${record?.referenceNumber} ${record?.actionStatus}`,
                    label: `${record?.referenceNumber} ${record?.actionStatus}`,
                    publishTime: record?.publishTime,
                    actionStatus: record?.actionStatus,
                    referenceNumber: record?.referenceNumber,
                  })).find((o: any) => o?.referenceNumber === values?.referenceNumber) || filterAction?.actionStatus}
                  valueKey="value"
                  onChange={(selectedOption: any) => {
                    handleOnChange1({
                      target: {
                        name: 'referenceNumber',
                        value: selectedOption?.referenceNumber,
                      },
                    })
                  }}
                />
              </Grid>
            </OPRResponsiveGrid>
          </Box>

          { renderTopButtons()}

          <OPRAlertControl
            error={createdReviewReportActionError}
            handleEditable={setEditable}
            handleSetValue={setValues}
            handleSubmit={handleSubmit}
            isError={createdReviewReportActionError}
            isLoading={createdReviewReportActionLoading}
            title={t('generation references')}
          />

          <Box sx={{ marginTop: '30px' }}>
            <OPRResponsiveGrid>
              <Grid item md={2} sm={1} xs={1}>
                <OPRInputControl
                  isEditable
                  error={errors?.publishTime}
                  label="Generation date"
                  name="publishTime"
                  value={displayFormatDateTime(filterAction.publishTime || '-')}
                  onChange={handleOnChange1}
                />
              </Grid>
              <Grid item md={2} sm={1} xs={1}>
                <OPRInputControl
                  isEditable
                  error={errors?.actionStatus}
                  label="Status"
                  name="actionStatus"
                  value={filterAction?.actionStatus || ''}
                  onChange={handleOnChange1}
                />
              </Grid>
              {/* <Grid item md={1} sm={1} xs={1} /> */}

              {/* Conditional rendering for the finalizedDate input */}
              {filterAction?.actionStatus === 'Finalized' ? (
                <Grid item md={2} sm={1} xs={1}>
                  <OPRInputControl
                    isEditable // Assuming finalizedDate is not editable
                    label="Finalized Date"
                    name="finalizedDate"
                    value={displayFormatDateTime(filterAction?.finalizedDate)}
                    onChange={handleOnChange1}
                  />
                </Grid>
              ) : (null)}

              {filterAction?.actionStatus === 'Void' ? (
                <Grid item md={2} sm={1} xs={1}>
                  <OPRInputControl
                    isEditable // Assuming finalizedDate is not editable
                    label="Void Date"
                    name="voidDate"
                    value={displayFormatDateTime(filterAction?.voidDate)}
                    onChange={handleOnChange1}
                  />
                </Grid>
              ) : (null)}
            </OPRResponsiveGrid>
          </Box>

          <ExportReportModal
            allPosts={allPosts}
            handleCancel={handleCancel}
            handleExport={handleExport}
            open={isOpen}
            selectedCodes={selectedCodes}
            setSelectedCode={setSelectedCode}
            onClose={() => setIsOpen(false)}
          />
          <DropDownModal dropDown={isDropDownModalOpen} handleFinalize={handleFinalize} referenceNumber={referenceNumber} onClose={() => setIsDropDownModalOpen(false)} />
          <VoidModal handlevoide={handleFinalize} referenceNumber={referenceNumber} voideModal={isvoidModalOpen} onClose={() => setIsVoidModalOpen(false)} />

          <OPRInnerListLayout
            Search={filterData.SearchText}
            columns={reviewReport(viewAcoount)}
            dataList={JSON.parse(JSON.stringify(allPosts?.records || []))}
            error={errorAllPosts}
            filterData={filterData}
            filterLayout={filterLayout}
            handlePagination={handlePagination}
            handleSearch={onSearch}
            isAdd={false}
            isError={isErrorAllPosts}
            loading={isLoadingAllPosts}
            rowNumber={0}
            selectedCodes={selectedPayrollCodes}
            sortHandleClick={sorting}
            success=""
            title={t('')}
          />
        </CustomTabPanel>

        <CustomTabPanel index={1} value={value}>
          <OPRInnerListLayout
            Search={filterData.SearchText}
            addHandleClick={() => navigate(routes.createRunPayroll)}
            columns={reviewReportLogs('')}
            dataList={JSON.parse(JSON.stringify(allPostsLog?.records || []))}
            deleteCallBack=""
            error={errorAllPosts}
            filterData={filterData}
            handlePagination={handlePagination}
            handleSearch={onSearch}
            isAdd={false}
            isError={isErrorAllPosts}
            loading={isLoadingAllPosts}
            sortHandleClick={sorting}
            success=""
            title={t('')}
          />
        </CustomTabPanel>
      </Box>
      {isSuccess && (

        <CustomDialog
          CustomStyles={{ borderRadius: '16px' }}
          isOpen={isSuccess}
          type="loader"
        >
          <div
            className="AtomPopupTitleStrip"
            style={{
              width: '100%', flexDirection: 'column', justifyContent: 'flex-start', alignItems: 'flex-start', gap: 16, display: 'inline-flex',
            }}
          >
            <div
              className="Header"
              style={{
                alignSelf: 'stretch', justifyContent: 'flex-start', alignItems: 'flex-start', gap: 8, display: 'inline-flex',
              }}
            >
              <div
                className="Icon"
                style={{
                  paddingTop: 5, paddingBottom: 5, justifyContent: 'flex-start', alignItems: 'flex-start', display: 'flex',
                }}
              >
                <div className="Tick" style={{ width: 24, height: 24, position: 'relative' }}>
                  <SuccessIcon />
                </div>
              </div>
              <div
                className="Text"
                style={{
                  flex: '1 1 0', flexDirection: 'column', justifyContent: 'flex-start', alignItems: 'flex-start', display: 'inline-flex',
                }}
              >
                <OPRLabel CustomStyles={{ marginTop: 2 }} variant="h4">
                  Generation reference finalization submitted

                </OPRLabel>
                <OPRLabel
                  CustomStyles={{
                    marginTop: '12px',
                    display: 'flex',
                    alignItems: 'center',
                    gap: '12px',
                  }}
                  variant="body2"
                >

                  {referenceNumber}
                  {' '}
                  {' '}
                  has been successfully submitted for finalization.
                  Please refer to the logs for more information.
                </OPRLabel>

              </div>
            </div>
          </div>

          <Box sx={{
            display: 'flex', justifyContent: 'space-between', marginTop: 5,
          }}
          >

            <OPRButton
              color="info"
              style={{ textAlign: 'left', paddingLeft: '15px' }} // Align button text to the left
              variant="text"
              onClick={() => {
                navigate(-1)
              }}
            >
              Go to log
            </OPRButton>

            <OPRButton
              color="info"
              style={{
                display: 'flex',
                padding: '8px 16px',
                alignItems: 'center',
                gap: '12px',
                color: '#FFF',
                background: 'var(--blue-blue-5000049-db, #0049DB)',
              }}
              variant="text"
              onClick={() => {
                setIsSuccess(false)
              }}
            >
              Close
            </OPRButton>

          </Box>
        </CustomDialog>

      )}

      {isVoidSuccess && (
        <CustomDialog
          CustomStyles={{ borderRadius: '16px' }}
          isOpen={isVoidSuccess}
          type="loader"
        >
          <div
            className="AtomPopupTitleStrip"
            style={{
              width: '100%', flexDirection: 'column', justifyContent: 'flex-start', alignItems: 'flex-start', gap: 16, display: 'inline-flex',
            }}
          >
            <div
              className="Header"
              style={{
                alignSelf: 'stretch', justifyContent: 'flex-start', alignItems: 'flex-start', gap: 8, display: 'inline-flex',
              }}
            >
              <div
                className="Icon"
                style={{
                  paddingTop: 5, paddingBottom: 5, justifyContent: 'flex-start', alignItems: 'flex-start', display: 'flex',
                }}
              >
                <div className="Tick" style={{ width: 24, height: 24, position: 'relative' }}>
                  <SuccessIcon />
                </div>
              </div>
              <div
                className="Text"
                style={{
                  flex: '1 1 0', flexDirection: 'column', justifyContent: 'flex-start', alignItems: 'flex-start', display: 'inline-flex',
                }}
              >
                <OPRLabel CustomStyles={{ marginTop: 2 }} variant="h4">
                  Generation references voided

                </OPRLabel>
                <OPRLabel
                  CustomStyles={{
                    marginTop: '12px',
                    display: 'flex',
                    alignItems: 'center',
                    gap: '12px',
                  }}
                  variant="body2"
                >

                  {referenceNumber}
                  {' '}
                  has been successfully submitted for finalization.
                  Please refer to the logs for more information.
                </OPRLabel>

              </div>
            </div>
          </div>

          <Box sx={{
            display: 'flex', justifyContent: 'space-between', marginTop: 5,
          }}
          >

            <OPRButton
              color="info"
              style={{ textAlign: 'left', paddingLeft: '15px' }} // Align button text to the left
              variant="text"
              onClick={() => {
                navigate(-1)
              }}
            >
              Go to log
            </OPRButton>

            <OPRButton
              color="info"
              style={{
                display: 'flex',
                padding: '8px 16px',
                alignItems: 'center',
                gap: '12px',
                color: '#FFF',
                background: 'var(--blue-blue-5000049-db, #0049DB)',
              }}
              variant="text"
              onClick={() => {
                setIsVoidSuccess(false)
              }}
            >
              Close
            </OPRButton>

          </Box>
        </CustomDialog>

      )}
    </>
  )
}

export default ReviewReportList
