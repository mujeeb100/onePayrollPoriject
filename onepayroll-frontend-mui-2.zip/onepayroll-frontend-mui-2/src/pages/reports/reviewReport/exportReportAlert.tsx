import { useTheme } from '@emotion/react'
import {
  Box, Checkbox,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
} from '@mui/material'
import { RighCaretBlue } from 'assets/svg-images/SvgComponents'
import OPRButton from 'components/atoms/button/OPRButton'
import OPRLabel from 'components/atoms/label/OPRLabel'
import React, { useState } from 'react'
import { useLocation, useNavigate } from 'react-router-dom'

import { CustomDialog } from '../../../components/atoms/modal/OPRModal'

type ExportReportModalProps = {
    onClose: () => void;
    open: boolean;
    handleExport: () => void;
    handleCancel: () => void;
    allPosts: any;
    setSelectedCode:any;
    selectedCodes:any;
  };

export function ExportReportModal({
  open, onClose, handleCancel, allPosts, handleExport, selectedCodes, setSelectedCode,
}: ExportReportModalProps) {
  const navigate: any = useNavigate()

  const theme:any = useTheme()
  const location: any = useLocation()
  const [isNextModalOpen, setIsNextModalOpen] = useState(false)

  const [selectAll, setSelectAll] = useState(false)

  const exportClose = () => {
    setIsNextModalOpen(false)
  }
  const handleCheckboxChange = (event: React.ChangeEvent<HTMLInputElement>, code: string) => {
    const { checked } = event.target
    if (checked) {
      setSelectedCode([...selectedCodes, code])
    } else {
      setSelectedCode(selectedCodes.filter((selectedCode:any) => selectedCode !== code))
    }
  }

  const handleSelectAllChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const { checked } = event.target
    if (checked) {
      setSelectedCode(allPosts?.records?.map((employee:any) => employee.id))
    } else {
      setSelectedCode([])
    }
    setSelectAll(checked)
  }

  return (
    <Box>

      <CustomDialog
        isOpen={open}
        type="loader"
      >
        <Box>
          <OPRLabel sx={{ margin: '10px 0' }} variant="h4">Export reports</OPRLabel>
          <Box>
            <label>
              <Checkbox
                checked={selectAll}
                onChange={handleSelectAllChange}
              />
              Select All
            </label>
            <hr />
            <TableContainer>
              <Table>
                <TableHead>
                  <TableRow>
                    <TableCell>Selct</TableCell>
                    <TableCell>Report Type</TableCell>
                    <TableCell>File Name</TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {allPosts?.records?.map((employee: any) => (
                    <TableRow key={employee.id}>
                      <TableCell>
                        <Checkbox
                          checked={selectedCodes.includes(employee.id)}
                          onChange={(event) => handleCheckboxChange(event, employee.id)}
                        />
                      </TableCell>
                      <TableCell>{employee?.batchJob?.reportType?.name}</TableCell>
                      <TableCell>{employee?.fileName}</TableCell>
                    </TableRow>
                  ))}

                </TableBody>

              </Table>
            </TableContainer>
            <div style={{
              borderRadius: '4px',
              background: '#E9F4FF',
              width: '100%',
              padding: '10px',
            }}
            >
              <OPRLabel
                variant="body2"
              >

                <>
                  Total selected employees:
                  {selectedCodes.length}
                </>

              </OPRLabel>
            </div>
          </Box>

          <Box style={{
            justifyContent:
                     'space-between',
            alignItems: 'center',
            gap: 10,
            display: 'flex',
            marginTop: '20px',
          }}
          >
            <OPRButton
              color="primary"
              variant="text"
              onClick={onClose}
            >
              Cancel
            </OPRButton>

            <Box style={{
              justifyContent: 'flex-end',
              alignItems:
                    'center',
              gap: 24,
              display: 'flex',
            }}
            >
              <OPRButton
                color="primary"
                variant="contained"
                onClick={() => { onClose(); setIsNextModalOpen(true) }}
              >
                Continue
              </OPRButton>
            </Box>
          </Box>

        </Box>

      </CustomDialog>

      <CustomDialog
        isOpen={isNextModalOpen}
        type="loader"
      >
        <Box>
          <OPRLabel sx={{ margin: '10px 0' }} variant="h4">Export reports</OPRLabel>
          <OPRLabel variant="body2">Please check the files to export listed below.</OPRLabel>
          <div style={{ margin: '20px 0' }}>
            <OPRLabel
              variant="body2"
            >

              <>
                Files:
                (
                {selectedCodes.length}
                )
              </>

            </OPRLabel>
          </div>
          <Box>

            <hr />
            <TableContainer>
              <Table>
                <TableHead>
                  <TableRow>
                    <TableCell>Report Type</TableCell>
                    <TableCell>File Name</TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {allPosts?.records?.filter((employee:any) => selectedCodes.includes(employee.id)).map((employee: any) => (
                    <TableRow key={employee.id}>
                      <TableCell>{employee?.batchJob?.reportType?.name}</TableCell>
                      <TableCell>{employee?.fileName}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </TableContainer>

          </Box>

          <Box sx={{
            display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: 5,
          }}
          >
            <OPRButton color="info" variant="text" onClick={exportClose}>
              Cancel
            </OPRButton>
            <>
              <OPRButton
                style={{ marginLeft: 'auto' }}
                variant="text"
                onClick={() => {
                  // alert('back')
                  handleCancel()
                }}
              >
                <RighCaretBlue />
                Back
              </OPRButton>
              <OPRButton
                color="primary"
                variant="contained"
                onClick={() => {
                  onClose()
                  setIsNextModalOpen(false)
                  handleExport()
                }}
              >

                Export reports
              </OPRButton>
            </>
          </Box>

        </Box>
      </CustomDialog>

    </Box>
  )
}
