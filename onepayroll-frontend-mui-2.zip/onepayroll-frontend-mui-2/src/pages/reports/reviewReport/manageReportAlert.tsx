import {
  Box, DialogActions, DialogContent,
} from '@mui/material'
import { useCustomReportDesignerCreateMutation, useGetAllCustomReportDesignerQuery } from 'api/report'
import OPRButton from 'components/atoms/button/OPRButton'
import OPRLabel from 'components/atoms/label/OPRLabel'
import { CustomDialog } from 'components/atoms/modal/OPRModal'
// import ExportReportInnerForm from './ExportReportInnerForm'
import { useEditable } from 'hooks/useEdit'
import { useEffect, useState } from 'react'
import { useLocation, useNavigate } from 'react-router-dom'

type Props = {
  onClose: () => void,
  isOpen:boolean,
};
function ManageReportAlert(props: Props) {
  const {
    onClose,
    isOpen,
  } = props
  const location: any = useLocation()
  // const id = getParamsValue(location, routes.createCustomExportReport)
  const [isManageExportReportAlertOpen, setIsExportReportAlertAlertOpen]:any = useState(false)
  const [mode, setMode] = useState('view') // Default mode is edit
  const { isEditable, setEditable } = useEditable()
  const [selectedOptions, setSelectedOptions]:any = useState([])
  const [showUnsavedChangesDialogue, setShowUnsavedChangesDialogue]:any = useState(false)

  const [filterData, setFilterData]:any = useState({
    pageNumber: 1,
    pageSize: 10000,
    totalItems: 0,
    orderByAsc: true,
    sortBy: '',
    SearchText: '',
  })

  const navigate = useNavigate()
  // view all custom report
  const {
    data: allReportsName,
    isLoading: allReportsNameLoading,
    isSuccess: allReportsNameSuccess,
    isError: allReportsNameIsError,
    error: allReportsNameError,
  } = useGetAllCustomReportDesignerQuery('')

  useEffect(() => {
    console.log('custom report', allReportsName?.records?.reportName)
  }, [allReportsName])

  const [
    createCustomExportReport,
    {
      data: createdCustomExportReportData,
      error: createdCustomExportReportError,
      isLoading: createdCustomExportReportLoading,
      isSuccess: createdCustomExportReportSuccess,
      isError: createdCustomExportReportIsError,
    },
  ] = useCustomReportDesignerCreateMutation()

  // useEffect(() => {
  //   if (id) {
  //     setValues(updatedCustomExportReportByIdResponse?.data)
  //   } else {
  //     setValues(location.state ? location.state : {})
  //   }
  // }, [updatedCustomExportReportByIdResponse?.data])

  // Function to handle closing the dialogue
  const handleCloseDialogue = () => {
    setShowUnsavedChangesDialogue(false)
  }
  // Define the list of options
  const listOfOptions = [
    { id: 1, roleName: 'Option 1' },
    { id: 2, roleName: 'Option 2' },
    // Add more options as needed
  ]

  useEffect(() => {
    if (createdCustomExportReportSuccess) {
      setIsExportReportAlertAlertOpen(true)
    }
  }, [createdCustomExportReportSuccess])

  // Define a function to render selected options
  const renderValue = (selected: any) => selected.join(', ') // Render selected options as a comma-separated string
  return (
    <Box sx={{ display: 'flex' }}>

      <CustomDialog
        CustomStyles={{ borderRadius: '16px' }}
        isOpen={isOpen}
        type="loader"

      >
        <h2>hi</h2>
        {/* <DialogTitle>Add Custom Report</DialogTitle> */}
        <div style={{ marginBottom: '15px' }}>
          <OPRLabel variant="h4">
            {`
           Add Custom Report
            `}
          </OPRLabel>
        </div>
        <DialogContent />
        <DialogActions>
          <OPRButton
            color="info"
            variant="text"
            onClick={() => {
              onClose()
            }}
          >
            Cancel
          </OPRButton>
          <OPRButton
            color="info"
            variant="text"
            //   onClick={handleSubmit}
            // onClick={() => {
            //   // Set isDataPopulated to true to indicate data population is in progress

            //   // Redirect to the iframe page
            //   navigate('/Iframe')
            //   // window.location.href = 'https://hk.mp.dev.onepayroll.net/reporting-designer/9cd7e909-ba68-4fa1-b205-117891f51b64'
            // }}
          >
            Confirm
          </OPRButton>
        </DialogActions>
      </CustomDialog>

    </Box>
  )
}

export default ManageReportAlert
