import {
  Box, FormControl, FormControlLabel, FormLabel, Radio, RadioGroup,
} from '@mui/material'
import { useGetAllReportSlipModalQuery, useGetAllStandardReportQuery, useStandardReportDeleteMutation } from 'api/reports'
import { RightDirection } from 'assets/svg-images/SvgComponents'
import OPRButton from 'components/atoms/button/OPRButton'
import { CustomDialog } from 'components/atoms/modal/OPRModal'
import { standardReportColumn } from 'components/atoms/table/OPRTableConstant'
import { OPRInnerListLayout } from 'components/organism/OPRInnerLayoutList'
import { reportCodeType } from 'constants/index'
import { t } from 'i18next'
import React, { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { routes } from 'routes/routes'
import {
  generateFilterUrl, setRouteValues,
} from 'utils'

function StandardReportList() {
  const navigate: any = useNavigate()
  const [isGenerateReport, setIsGenerateReport] = useState(false)
  const [isGroupSelection, setGroupSelection] = useState(true)
  const [reportType, setReportType] = useState(null)
  const [filterData, setFilterData]:any = useState({
    pageNumber: 1,
    pageSize: 20,
    totalItems: 0,
    orderByAsc: false,
    sortBy: '',
    SearchText: '',
    reportTypeId: '',
    reportTypeCode: reportCodeType.ACR,
  })
  console.log(filterData, '444444444444444')

  const {
    data: allPosts,
    error: createAllPostsBankAccountError,
    isLoading: isLoadingAllPosts,
    isSuccess: isSuccessAllPosts,
    isError: isErrorAllPosts,
    error: errorAllPosts,
  } = useGetAllStandardReportQuery(generateFilterUrl(filterData), {
    pollingInterval: 5000, // 30 seconds
  })

  const {
    data: allReportModal,
    error: createAllReportModalBankAccountError,
    isLoading: isLoadingAllReportModal,
    isSuccess: isSuccessAllReportModal,
    isError: isErrorAllReportModal,
    error: errorAllReportModal,
  } = useGetAllReportSlipModalQuery(generateFilterUrl({
    // SearchText: 'Payroll Comparison Report by Employee',
  }))

  // const allPosts:any = []
  const [deleteStandardReportById,
    {
      data: deleteStandardReportResponse,
      error: deleteStandardReportError,
      isLoading: deleteStandardReportLoading,
      isSuccess: deleteStandardReportSuccess,
      isError: deleteStandardReportIsError,
    }] = useStandardReportDeleteMutation()

  const sorting = (
    event: React.MouseEvent<unknown>,
    property: keyof any,
  ) => {
    const isAsc = filterData.sortBy === property && filterData.orderByAsc === true
    setFilterData({ ...filterData, orderByAsc: !isAsc, sortBy: property })
    // setOrder(isAsc ? 'desc' : 'asc')
    // setOrderBy(property)
  }

  useEffect(() => {
    setFilterData({ ...filterData, totalItems: allPosts?.totalItems ? allPosts?.totalItems : 0 })
  }, [allPosts?.pageNumber, filterData.sortBy, filterData.orderByAsc, allPosts?.totalItems])

  const onSearch = (e: any, data: any) => {
    console.log('%%%%%%%%%%%%%%%%')

    setFilterData({ ...filterData, SearchText: e.target.value })
  }
  const handlePagination = (pageNumber: number, pageSize: number) => {
    setFilterData({ ...filterData, pageNumber })
  }
  const viewAcoount = (data: any, type:string) => {

  }
  const handleView = (data: any) => {

  }
  const handleGenerateReport = () => {
    if (reportType) {
      setGroupSelection(false)
    }
    // navigate(`/${routes.standardReportsGenerate}`)
  }
  const goToNextGenerateReport = (id:any) => {
    navigate(
      setRouteValues(`/${routes.annualCompensationReportCreate}`, {
        id,
        view: false,
      }),
    )
  }
  return (
    <Box sx={{ display: 'flex' }}>
      {/* <ReportForm /> */}
      <CustomDialog
        CustomStyles={{ borderRadius: '16px' }}
        isOpen={isGenerateReport}
        type="loader"
      >

        <GroupSelectionList
          goToNextGenerateReport={goToNextGenerateReport}
          isGenerateReport={isGenerateReport}
          reportType={reportType}
          setIsGenerateReport={setIsGenerateReport}
        />

        {/* <GroupSelectionList
          isGenerateReport={isGenerateReport}
          setIsGenerateReport={setIsGenerateReport}
        /> */}

        <Box sx={{
          display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: 5,
        }}
        >
          <OPRButton
            color="info"
            variant="text"
            onClick={() => {
              setIsGenerateReport(false)
            }}
          >
            Cancel
          </OPRButton>
          {/* <OPRButton
            color="info"
            variant="text"
            onClick={() => {
              handleGenerateReport()
            }}
          >
            Continue
          </OPRButton> */}
        </Box>
      </CustomDialog>
      <OPRInnerListLayout
        Search={filterData.SearchText}
        addHandleClick={() => {
          setIsGenerateReport(true)
        }}
        columns={standardReportColumn(viewAcoount)}
        customAdd="Generate Report"
        dataList={JSON.parse(JSON.stringify(allPosts?.records || []))}
        error={deleteStandardReportError}
        filterData={filterData}
        handlePagination={handlePagination}
        handleSearch={onSearch}
        isError={deleteStandardReportIsError}
        loading={deleteStandardReportLoading}
        rowClickHandler={handleView}
        rowNumber={0}
        sortHandleClick={sorting}
        success={deleteStandardReportSuccess}
        title={t('Annual Compensation Reports')}
      />
    </Box>
  )
}

export default StandardReportList

function GroupSelection({ handleGenerateReport, value, onChange }:any) {
  return (
    <FormControl>
      <FormLabel
        id="demo-radio-buttons-group-label"
        style={{
          width: '100%', color: '#3B3839', fontSize: 24, fontFamily: 'Lato', fontWeight: '700', wordWrap: 'break-word',
        }}
      >
        Generate report
      </FormLabel>
      <RadioGroup
        aria-labelledby="demo-radio-buttons-group-label"
        name="radio-buttons-group"
        value={value}
        onChange={(e) => {
          onChange(e.target.value)
        }}
      >
        <FormControlLabel control={<Radio />} label="Ad-hoc reporting" value="true" />
        <FormControlLabel control={<Radio />} label="Pre-defined reporting" value="false" />
      </RadioGroup>
    </FormControl>

  )
}

function GroupSelectionList({
  isGenerateReport, setIsGenerateReport, reportType, goToNextGenerateReport,
}:any) {
  const [dataList, setDataList] = useState([])
  const {
    data: allPosts,
    error: createAllPostsBankAccountError,
    isLoading: isLoadingAllPosts,
    isSuccess: isSuccessAllPosts,
    isError: isErrorAllPosts,
    error: errorAllPosts,
  } = useGetAllReportSlipModalQuery(generateFilterUrl({
    SearchText: 'Annual Compensation Report',
  }))

  const expectedOutPut = (rowData:any) => {
    const data = rowData?.map((item:any) => {
      const jobs = item?.jobs[0]
      return jobs.reportType
    })
    return data
  }

  useEffect(() => {
    if (isSuccessAllPosts) {
      setDataList(allPosts?.records || [])
    }
  }, [isSuccessAllPosts])

  if (isLoadingAllPosts) return <div>Loading...</div>

  return (
    <div>
      <div style={{
        width: '100%', color: '#3B3839', fontSize: 24, fontFamily: 'Lato', fontWeight: '700', wordWrap: 'break-word',
      }}
      >
        Select report
      </div>
      <div style={{
        width: '100%', color: '#3B3839', fontSize: 16, fontFamily: 'Lato', fontWeight: '400', lineHeight: 2.40, wordWrap: 'break-word',
      }}
      >
        Descriptions
      </div>
      <div style={{ overflowY: 'scroll', height: 400 }}>
        {dataList?.map((item:any, index) => (
          <div style={{
            width: '100%', flexDirection: 'column', justifyContent: 'flex-start', alignItems: 'flex-start', display: 'inline-flex',
          }}
          >
            <div style={{
              alignSelf: 'stretch', justifyContent: 'flex-start', alignItems: 'flex-start', gap: 2, display: 'inline-flex',
            }}
            >
              <div style={{
                flex: '1 1 0', flexDirection: 'column', justifyContent: 'flex-start', alignItems: 'flex-start', display: 'inline-flex',
              }}
              >
                <div style={{
                  alignSelf: 'stretch', paddingTop: 2, paddingBottom: 2, paddingLeft: 8, justifyContent: 'flex-start', alignItems: 'flex-start', gap: 8, display: 'inline-flex',
                }}
                >
                  <div style={{
                    flex: '1 1 0', flexDirection: 'column', justifyContent: 'flex-start', alignItems: 'flex-start', display: 'inline-flex',
                  }}
                  >
                    <div style={{
                      alignSelf: 'stretch', color: '#3B3839', fontSize: 14, fontFamily: 'Lato', fontWeight: '700', lineHeight: 2, wordWrap: 'break-word',
                    }}
                    >
                      {item.reportName}
                    </div>
                    <div style={{
                      alignSelf: 'stretch', color: '#666364', fontSize: 12, fontFamily: 'Lato', fontWeight: '400', lineHeight: 2, wordWrap: 'break-word',
                    }}
                    >
                      {item.reportCode}
                    </div>
                  </div>
                </div>
              </div>
              <div style={{
                flex: '1 1 0', height: 44, justifyContent: 'flex-start', alignItems: 'flex-start', gap: 16, display: 'flex',
              }}
              >
                <div style={{
                  flex: '1 1 0', flexDirection: 'column', justifyContent: 'flex-start', alignItems: 'flex-start', display: 'inline-flex',
                }}
                >
                  <div style={{
                    alignSelf: 'stretch', paddingTop: 12, paddingBottom: 12, paddingLeft: 8, justifyContent: 'flex-start', alignItems: 'center', gap: 8, display: 'inline-flex',
                  }}
                  >
                    <div style={{
                      paddingLeft: 8, paddingRight: 8, paddingTop: 4, paddingBottom: 4, background: '#E8E6E7', borderRadius: 12, overflow: 'hidden', justifyContent: 'center', alignItems: 'center', gap: 8, display: 'flex',
                    }}
                    >
                      <div style={{
                        color: '#3B3839', fontSize: 12, fontFamily: 'Lato', fontWeight: '700', lineHeight: 2, wordWrap: 'break-word',
                      }}
                      >
                        {item.isStandard ? 'Satndard' : 'Custome'}
                      </div>
                    </div>
                  </div>
                </div>
                <div style={{
                  flexDirection: 'column', justifyContent: 'flex-start', alignItems: 'flex-start', display: 'inline-flex',
                }}
                >
                  <div style={{
                    paddingTop: 12, paddingBottom: 12, paddingLeft: 8, justifyContent: 'flex-end', alignItems: 'center', gap: 8, display: 'inline-flex',
                  }}
                  >
                    <div style={{
                      paddingTop: 2, paddingBottom: 2, justifyContent: 'flex-start', alignItems: 'center', display: 'flex',
                    }}
                    >
                      <OPRButton
                        color="secondary"
                        variant="text"
                        onClick={() => {
                          console.log('cancel')
                          goToNextGenerateReport(item.id)
                        }}
                      >
                        <RightDirection />
                      </OPRButton>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div style={{ alignSelf: 'stretch', height: 1, background: '#E8E6E7' }} />
          </div>
        ))}
      </div>
    </div>
  )
}
