import { Grid } from '@mui/material'
import { useGetAllPayCycleMasterDropDownQuery, useGetAllPayrollCycleQuery } from 'api/payRollServices'
import OPRMultiSelect from 'components/atoms/multiSelectCheckbox/OPRMultiSelectCheckbox'
import OPRResponsiveGrid from 'components/molecules/OPRResponsiveGrid'
import OPRSelectorControl from 'components/molecules/OPRSelectorControl/OPRSelectorControl'
import React from 'react'
import { generateFilterUrl } from 'utils'

function FilteringCriteria({ values, handleOnChange, errors }:any) {
  const {
    data: allPosts,
    isLoading: isLoadingAllPosts,
    isSuccess: isSuccessAllPosts,
    isError: isErrorAllPosts,
    error: errorAllPosts,
    refetch: refetchAllPosts,
  } = useGetAllPayrollCycleQuery(generateFilterUrl(''))
  const {
    data: payCycleMasterDropdown,
  }:any = useGetAllPayCycleMasterDropDownQuery('')

  const payCycleCodeList = payCycleMasterDropdown?.payCycleMasterCodeDtos?.map((item:any) => ({
    name: item?.id,
    value: item?.label?.toString(),
  }))
  const yearDataList = payCycleMasterDropdown?.payCycleYear.map((item:any) => ({
    label: item,
    value: item,
  }))
  const monthDataList = payCycleMasterDropdown?.months?.map((item:any) => ({
    label: item.label,
    value: item.label,
  }))
  // const handleChange = (key:any, value:any) => {
  //   setFilterCriteria((prev:any) => ({
  //     ...prev,
  //     [key]: value,
  //   }))
  // }

  return (
    <div style={{ gap: 20, display: 'flex', flexDirection: 'column' }}>
      {/* <div style={{
        width: '100%', color: '#3B3839', fontSize: 16, fontFamily: 'Lato', fontWeight: '400', wordWrap: 'break-word',
      }}
      >
        Payroll Summary Report, Payroll Summary Report by Cost Center, Payroll Summary Report by Charge Cost Center, MPF Remittance Statement, ORSO Contribution Listing
      </div> */}
      <div style={{
        width: '100%', color: '#3B3839', fontSize: 16, fontFamily: 'Lato', fontWeight: '400', wordWrap: 'break-word',
      }}
      >
        All fields are mandatory except those marked optional.
      </div>
      <div>
        <OPRResponsiveGrid>
          <Grid item md={2} sm={1} xs={1}>
            <OPRSelectorControl
              isRequired
              error={errors?.year}
              // isEditable={isEditable}
              keyName="label"
              label="Pay cycle - From year"
              multiple={false}
              name="label"
              options={yearDataList || []}
              value={yearDataList?.find((o:any) => o?.value === values?.year)}
              valueKey="label"
              onChange={(text:any) => {
                handleOnChange('year', text?.value)
              }}
            />
          </Grid>

          <Grid item md={2} sm={1} xs={1}>
            <OPRSelectorControl
              isRequired
              error={errors?.month}
              // isEditable={isEditable}
              keyName="label"
              label="Pay cycle - From Month"
              multiple={false}
              name="label"
              options={monthDataList || []}
              value={monthDataList?.find((o:any) => o?.value === values?.month)}
              valueKey="label"
              onChange={(text:any) => {
                handleOnChange('month', text?.value)
              }}
            />
          </Grid>

          {/* <Grid item md={2} sm={1} xs={1}>
            <OPRSelectorControl
              isRequired
              // error={errors?.yearOfServiceOption}
              // isEditable={isEditable}
              keyName="payCycleCode"
              label="Pay cycle code"
              multiple={false}
              name="payCycleCode"
              options={allPosts?.records || []}
              value={allPosts?.records?.find((o:any) => o?.payCycleCode === values?.codes)}
              valueKey="codes"
              onChange={(text:any) => {
                handleOnChange('codes', text?.payCycleCode)
              }}
            />
          </Grid> */}
          {/* <Grid item md={2} sm={1} xs={1}>
            <OPRMultiSelect
              error={errors?.payCycleCode}
              label="Pay cycle code"
              name="payCycleCode"
              options={payCycleCodeList || []}
              placeholder="Select an option"
              value={values?.payCycleCode || []} // Ensure value is initialized as an array
              onChange={(selectedFormat) => {
                handleOnChange('payCycleCode', selectedFormat)
                // setFilterCriteria({
                //   ...filterCriteria,
                //   payCycleCode: selectedFormat,
                // })
              }}
            />
          </Grid> */}

          <Grid item md={2} sm={1} xs={1}>
            <OPRMultiSelect
              error={errors?.payCycleCode}
              label="Pay cycle code"
              name="payCycleCode"
              options={payCycleCodeList || []}
              placeholder="Select an option"
              value={values?.payCycleCode || []} // Ensure value is initialized as an array
              onChange={(selectedFormat) => {
                handleOnChange('payCycleCode', selectedFormat)
                // setFilterCriteria({
                //   ...filterCriteria,
                //   payCycleCode: selectedFormat,
                // })
              }}
            />
          </Grid>
        </OPRResponsiveGrid>
      </div>
    </div>
  )
}

export default FilteringCriteria
