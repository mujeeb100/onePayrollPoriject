import { useGetAllEmployeeProfileQuery } from 'api/employeeServices'
import { useStandardReportCreateMutation } from 'api/reports'
import OPRStepper from 'components/atoms/stepper'
import OPRAlertControl from 'components/organism/OPRAlertControl'
import { OPRInnerFormLayout } from 'components/organism/OPRInnerFormLayout'
import { defaultPageSize } from 'constants/index'
import {
  payCycleCodevalidationSchemaFilterCriteria,
  validationSchemaFilterCriteriaAdditionalfilter, validationSchemaFilterCriteriaExportOption, validationSchemaFilterCriteriaReportOption,
} from 'constants/validate'
import { useEditable } from 'hooks/useEdit'
import useForm from 'hooks/useForm'
import { t } from 'i18next'
import React, { useEffect, useState } from 'react'
import { useLocation } from 'react-router-dom'
import { routes } from 'routes/routes'
import { generateFilterUrl, getParamsValue } from 'utils'

import AdditionalFilteringCriteria from './additionalFilteringCriteria/AdditionalFilteringCriteria'
import { reportACRData } from './data'
import ExportCriteria from './exportCriteria/ExportCriteria'
import FilteringCriteria from './filteringCriteria/FilteringCriteria'
import ReportOption from './reportOption/ReportOption'

const validation = (selectedTab:any) => {
  const errorsValidation = {}
  switch (selectedTab) {
    case 0:
      return payCycleCodevalidationSchemaFilterCriteria
    case 1:
      return validationSchemaFilterCriteriaAdditionalfilter
    case 2:
      return validationSchemaFilterCriteriaReportOption
    case 3:
      return validationSchemaFilterCriteriaExportOption
    default:
      return 'ONE'
  }
}
function ReportForm() {
  const [activeState, setActiveState] = useState(0)
  const { isEditable, setEditable } = useEditable()
  const [employees, setEmployees]:any = useState([])
  const [selectAll, setSelectAll] = useState(false)
  const [selectedCodes, setSelectedCodes] = useState<string[]>([])
  const location: any = useLocation()
  const { id, viewUrl } = getParamsValue(location, routes.annualCompensationReportCreate)
  const {
    values,
    setValues,
    errors,
    handleChange,
    setErrors,
    handleFormSubmit,
    handleOnChange,
  } = useForm(validation(activeState))

  // const {
  //   data: allPosts,
  //   error: createAllPostsBankAccountError,
  //   isLoading: isLoadingAllPosts,
  //   isSuccess: isSuccessAllPosts,
  //   isError: isErrorAllPosts,
  //   error: errorAllPosts,
  // } = useGetAllARCReportQuery('')
  const {
    data: employeeDataList,
    isLoading: isLoadingEmployeeDataList,
    isSuccess: isSuccessEmployeeDataList,
    isError: isErrorEmployeeDataList,
    error: errorEmployeeDataList,
    refetch: refetchEmployeeDataList,
  } = useGetAllEmployeeProfileQuery(generateFilterUrl({
    EffectiveDate: '10/10/2040',
    ...defaultPageSize,
  }))
  const [createStandardReport, {
    data: createdStandardReportData,
    error: createdStandardReportError,
    isLoading: createdStandardReportLoading,
    isSuccess: createdStandardReportSuccess,
    isError: createdStandardReportIsError,
  }] = useStandardReportCreateMutation()
  useEffect(() => {
    if (isSuccessEmployeeDataList) {
      setEmployees(JSON.parse(JSON.stringify(employeeDataList?.records || [])))
    }
  }, [isSuccessEmployeeDataList])
  const handleCheckboxChange = (event: React.ChangeEvent<HTMLInputElement>, code: string) => {
    const { checked } = event.target
    if (checked) {
      setSelectedCodes([...selectedCodes, code])
    } else {
      setSelectedCodes(selectedCodes.filter((selectedCode) => selectedCode !== code))
    }
  }
  const handleRemoveEmployee = (codeToRemove: string) => {
    // Filter out the selected employee code to remove it from the selectedCodes state
    setSelectedCodes(selectedCodes.filter((code) => code !== codeToRemove))
  }
  const handleSelectAllChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const { checked } = event.target
    if (checked) {
      setSelectedCodes(employees.map((employee:any) => employee.employeeCode))
    } else {
      setSelectedCodes([])
    }
    setSelectAll(checked)
  }
  function findNamesByIds(array:any, ids:any) {
    return array?.filter((obj:any) => ids?.includes(obj?.name))
      .map((obj:any) => obj?.value)
  }
  const consolitationList:any = [{ name: 'Consolidate by Employee', value: 0 }, { name: 'Consolidate by Entity', value: 1 }]
  const employeesList:any = [{ name: 'Active Staff Only', value: 0 }, { name: 'Terminated Staff', value: 1 }, { name: 'IRD Staff', value: 2 }, { name: 'Non-IRD Staff', value: 3 }]
  const createACR = () => {
    const data = {
      ...values,
      consolidateOption: findNamesByIds(consolitationList, values?.consolidateOption) || [],
      includeEmployeeGroupOption: findNamesByIds(employeesList, values?.includeEmployeeGroupOption) || [],
      reportDesignId: id,
      employees: [...selectedCodes],
    }
    // console.log(reportACRData(data), selectAll, 'final data', id)
    createStandardReport(reportACRData(data))
  }
  const handlesubmit = () => {
    if (activeState === 3) {
      createACR()
      // return
    }
    setActiveState(activeState + 1)
    // console.log(reportACRData(values, selectedCodes), 'final Data')
    // createStandardReport(reportACRData(values, employees))
  }
  function findReportNameObjectById(array:any, id:any) {
    return array.find((obj:any) => obj.id === 'c5121b2e-9ecc-45a3-be08-62274a065cd5')
  }
  const successfullMessage:any = () => {
    const htmString = '<div className="InsertContent" style={{width: \'100%\'}}><span style="color: \'#3B3839\', fontSize: 16, fontFamily: \'Lato\', fontWeight: \'700\', lineHeight: 24, wordWrap: \'break-word\'">Annual compensation report </span><span style="color: \'#3B3839\', fontSize: 16, fontFamily: \'Lato\', fontWeight: \'400\', lineHeight: 24, wordWrap: \'break-word\'">generation has been submitted.<br/>Please refer to the report listing for more information.</span></div>'
    const plainString = htmString.replace(/<[^>]+>/g, '')
    return plainString
  }
  return (
    <>
      <OPRAlertControl
        addAnother={false}
        callBack={(type) => {
          // if (type === 'success') {
          //   navigate(-1)
          // }
        }}
        customMessage={successfullMessage()}
        error={createdStandardReportError}
        handleEditable={setEditable}
        handleSetValue={setValues}
        handleSubmit={createACR}
        isError={createdStandardReportIsError}
        isLoading={createdStandardReportLoading}
        isSuccess={createdStandardReportSuccess}
        name=""
        title="Report generation submitted"
        type={id ? 'New' : 'New'}

        // previousUrl={routes.country}
      />
      <OPRInnerFormLayout
        isHandleContinueClick
        // customHeader={(
        //   <OPRLabel label="Generate annual compensation reportGenerate" variant="h2" />
        // )}
        isStepper
        error={false}
        handleBack={(item:any) => {
          setActiveState(activeState - 1)
        }}
        handleCancelClick={() => () => {
          console.log('Cancel clicked')
        }}
        handleContinueClick={(e:any) => {
          handleFormSubmit(e, handlesubmit)
        }}
        handleEditable={setEditable}
        isBackButton={activeState > 0}
        isLoading={false}
        pageType="detailsPage"
        //   previousPageUrl={routes.userRolesListing}
        subtitle={
          isEditable
            ? 'Please check the user details below.'
            : ''
        }
        title="Generate annual compensation report"

      >
        <OPRStepper
          activeStep={activeState}
          steps={[
            t('Filtering criteria'),
            t('Additional filtering criteria'),
            t('Report option'),
            t('Export criteria'),
          // t('Generate report'),
          ]}
        />
        <br />
        {activeState === 0 && (
          <FilteringCriteria
            errors={errors}
            handleOnChange={handleOnChange}
            values={values}
            onChange={setValues}
          />
        )}
        {activeState === 1 && (
          <AdditionalFilteringCriteria
            employees={employees}
            errors={errors}
            handleChange={handleChange}
            handleCheckboxChange={handleCheckboxChange}
            handleOnChange={handleOnChange}
            handleRemoveEmployee={handleRemoveEmployee}
            handleSelectAllChange={handleSelectAllChange}
            selectAll={selectAll}
            selectedCodes={selectedCodes}
            values={values}
          />
        )}
        {activeState === 2 && (
          <ReportOption
            errors={errors}
            handleOnChange={handleOnChange}
            values={values}
            onChange={setValues}
          />
        )}
        {activeState === 3 && (
          <ExportCriteria
            errors={errors}
            handleOnChange={handleOnChange}
            values={values}
            onChange={setValues}
          />
        )}
        {/* {activeState === 4 && (
        <GenerateReport />
      )} */}
      </OPRInnerFormLayout>
    </>
  )
}

export default ReportForm
