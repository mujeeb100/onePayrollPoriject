import React, { useState } from 'react'

  interface CustomCheckboxProps {
    employees: { code: string; personalEmailAddress: string; surname: string; givenName: string }[];
    selectedCodes: string[];
    handleCheckboxChange: (event: React.ChangeEvent<HTMLInputElement>, code: string) => void;
    handleRemoveEmployee: (codeToRemove: string) => void;
    handleSelectAllChange: (event: React.ChangeEvent<HTMLInputElement>) => void;
    selectAll: boolean;
  }
function ReportGroupList() {
  const [employees, setEmployees]:any = useState([
    { code: 'EMP001', name: 'John Doe' },
    { code: 'EMP002', name: 'Jane Smith' },
    { code: 'EMP003', name: 'Michael Johnson' },
    // Add more employees as needed
  ])
  const [selectedCodes, setSelectedCodes] = useState<string[]>([])
  const [selectAll, setSelectAll] = useState(false)
  const handleCheckboxChange = (event: React.ChangeEvent<HTMLInputElement>, code: string) => {
    const { checked } = event.target
    if (checked) {
      setSelectedCodes([...selectedCodes, code])
    } else {
      setSelectedCodes(selectedCodes.filter((selectedCode) => selectedCode !== code))
    }
  }
  const handleRemoveEmployee = (codeToRemove: string) => {
    // Filter out the selected employee code to remove it from the selectedCodes state
    setSelectedCodes(selectedCodes.filter((code) => code !== codeToRemove))
  }
  const handleSelectAllChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const { checked } = event.target
    if (checked) {
      setSelectedCodes(employees.map((employee:any) => employee.code))
    } else {
      setSelectedCodes([])
    }
    setSelectAll(checked)
  }
  return (
    <div>
      <label style={{ marginBottom: '10px', marginTop: '10px', display: 'block' }}>
        <input
          checked={selectAll}
          type="checkbox"
          onChange={handleSelectAllChange}
        />
        {' '}
        Select All
      </label>
      <div style={{
        width: '100%', height: '100%', flexDirection: 'column', justifyContent: 'flex-start', alignItems: 'flex-start', display: 'inline-flex',
      }}
      >
        <div style={{
          alignSelf: 'stretch', justifyContent: 'flex-start', alignItems: 'flex-start', gap: 4, display: 'inline-flex',
        }}
        >
          <div style={{
            flex: '1 1 0', height: 48, paddingTop: 4, paddingBottom: 4, justifyContent: 'flex-start', alignItems: 'center', display: 'flex',
          }}
          >
            <div style={{
              padding: 4, justifyContent: 'flex-start', alignItems: 'center', gap: 4, display: 'flex',
            }}
            >
              <div style={{
                color: '#3B3839', fontSize: 12, fontFamily: 'Lato', fontWeight: '700', lineHeight: 16, wordWrap: 'break-word',
              }}
              >
                Report name |  Report code
              </div>
            </div>
          </div>

          <div style={{
            height: 48, paddingTop: 8, paddingBottom: 8, justifyContent: 'flex-start', alignItems: 'center', display: 'flex',
          }}
          >
            <div style={{
              padding: 8, justifyContent: 'flex-start', alignItems: 'center', gap: 8, display: 'flex',
            }}
            >
              <div style={{
                color: '#3B3839', fontSize: 12, fontFamily: 'Lato', fontWeight: '700', lineHeight: 16, wordWrap: 'break-word',
              }}
              >
                Type
              </div>
            </div>
          </div>
        </div>
      </div>
      {/* <hr style={{ borderColor: '#E8E6E7', marginBottom: '10px' }} /> */}
      {employees.map((employee:any) => (

        <div key={employee.code}>
          <div style={{
            width: '100%', height: '100%', flexDirection: 'column', justifyContent: 'flex-start', alignItems: 'flex-start', display: 'inline-flex',
          }}
          >
            <div style={{
              alignSelf: 'stretch', justifyContent: 'flex-start', alignItems: 'flex-start', gap: 4, display: 'inline-flex',
            }}
            >
              <div style={{
                flex: '1 1 0', height: 48, justifyContent: 'flex-start', alignItems: 'center', display: 'flex',
              }}
              >
                <div style={{
                  padding: 4, justifyContent: 'flex-start', alignItems: 'center', gap: 4, display: 'flex',
                }}
                >
                  <div style={{
                    color: '#3B3839', fontSize: 12, fontFamily: 'Lato', fontWeight: '700', lineHeight: 8, wordWrap: 'break-word',
                  }}
                  >
                    <label style={{ marginRight: '10px' }}>
                      <input
                        checked={selectedCodes.includes(employee.code)}
                        type="checkbox"
                        value={employee.code}
                        onChange={(event) => handleCheckboxChange(event, employee.code)}
                      />
                      {`${employee.personalEmailAddress} (${employee.surname}, ${employee.givenName})`}
                    </label>
                  </div>
                </div>
              </div>

              <div style={{
                height: 48, justifyContent: 'flex-start', alignItems: 'center', display: 'flex',
              }}
              >
                <div style={{
                  padding: 8, justifyContent: 'flex-start', alignItems: 'center', gap: 8, display: 'flex',
                }}
                >
                  <div style={{
                    color: '#3B3839', fontSize: 12, fontFamily: 'Lato', fontWeight: '700', lineHeight: 16, wordWrap: 'break-word',
                  }}
                  >
                    Type
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* <hr style={{ borderColor: '#E8E6E7', marginTop: '5px', marginBottom: '5px' }} /> */}
        </div>
      ))}

    </div>
  )
}

export default ReportGroupList
