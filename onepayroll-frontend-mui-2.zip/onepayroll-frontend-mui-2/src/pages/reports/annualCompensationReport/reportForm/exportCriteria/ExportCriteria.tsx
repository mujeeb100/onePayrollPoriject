import { Grid } from '@mui/material'
import { useGetAllPayCycleGenerationDropDownQuery, useGetAllPayrollCycleQuery } from 'api/payRollServices'
import OPRInputControl from 'components/molecules/OPRInputControl'
import OPRResponsiveGrid from 'components/molecules/OPRResponsiveGrid'
import OPRSelectorControl from 'components/molecules/OPRSelectorControl/OPRSelectorControl'
import React, { useState } from 'react'
import { generateFilterUrl } from 'utils'

import {
  exportFileFormate, exportToSingleFile, paperOrientation, paperSize,
} from '../data'

function ExportCriteria({ values, handleOnChange, errors }:any) {
  const {
    data: allData,
    error: createAllDatasBankAccountError,
    isLoading: isLoadingAllData,
    isSuccess: isSuccessAllData,
    isError: isErrorAllData,
    error: errorAllData,
  } = useGetAllPayCycleGenerationDropDownQuery('')
  const {
    data: allPosts,
    isLoading: isLoadingAllPosts,
    isSuccess: isSuccessAllPosts,
    isError: isErrorAllPosts,
    error: errorAllPosts,
    refetch: refetchAllPosts,
  } = useGetAllPayrollCycleQuery(generateFilterUrl(''))
  const [error, setError] = useState<any>({})
  // const handleOnChange = (key:any, value:any) => {
  //   setExportCriteria((prev:any) => ({
  //     ...prev,
  //     [key]: value,
  //   }))
  // }

  return (
    <div style={{ gap: 20, display: 'flex', flexDirection: 'column' }}>
      {/* <div style={{
        width: '100%', color: '#3B3839', fontSize: 16, fontFamily: 'Lato', fontWeight: '400', wordWrap: 'break-word',
      }}
      >
        Payroll Summary Report, Payroll Summary Report by Cost Center, Payroll Summary Report by Charge Cost Center, MPF Remittance Statement, ORSO Contribution Listing
      </div> */}
      <div style={{
        width: '100%', color: '#3B3839', fontSize: 16, fontFamily: 'Lato', fontWeight: '400', wordWrap: 'break-word',
      }}
      >
        All fields are mandatory except those marked optional.
      </div>
      <div>
        <OPRResponsiveGrid>
          <Grid item md={2} sm={1} xs={1}>
            <OPRSelectorControl
              isRequired
              error={errors?.exportFileFormat}
              // isEditable={isEditable}
              keyName="name"
              label="Export file format"
              multiple={false}
              name="name"
              options={exportFileFormate}
              value={exportFileFormate.find((o:any) => o?.value === values?.exportFileFormat)}
              valueKey="value"
              onChange={(text:any) => {
                handleOnChange('exportFileFormat', text?.value)
              }}
            />
          </Grid>
          <Grid item md={2} sm={1} xs={1}>
            <OPRSelectorControl
              isRequired
              error={errors?.paperSize}
              // isEditable={isEditable}
              keyName="name"
              label="Paper size"
              multiple={false}
              name="name"
              options={paperSize}
              value={paperSize.find((o:any) => o?.value === values?.paperSize)}
              valueKey="value"
              onChange={(text:any) => {
                handleOnChange('paperSize', text?.value)
              }}
            />
          </Grid>
          <Grid item md={2} sm={1} xs={1}>
            <OPRSelectorControl
              isRequired
              error={errors?.paperOrientation}
              // isEditable={isEditable}
              keyName="name"
              label="Paper orientation"
              multiple={false}
              name="name"
              options={paperOrientation}
              value={paperOrientation.find((o:any) => o?.value === values?.paperOrientation)}
              valueKey="value"
              onChange={(text:any) => {
                handleOnChange('paperOrientation', text?.value)
              }}
            />
          </Grid>
          <Grid item md={2} sm={1} xs={1}>
            <OPRSelectorControl
              isRequired
              error={errors?.exportToSingleZipFile}
              // isEditable={isEditable}
              keyName="name"
              label="Export to a single ZIP file"
              multiple={false}
              name="name"
              options={exportToSingleFile}
              value={exportToSingleFile?.find((o:any) => o?.value === values?.exportToSingleZipFile)}
              valueKey="value"
              onChange={(text:any) => {
                handleOnChange('exportToSingleZipFile', text?.value)
              }}
            />
          </Grid>
          <Grid item md={2} sm={1} xs={1}>

            <OPRInputControl
              error={errors?.zipPassword}
              isEditable={false}
              label="ZIP password"
              name="zipPassword"
              value={values?.zipPassword}
              onChange={(e:any) => {
                handleOnChange('zipPassword', e.target?.value)
              }}
            />
          </Grid>
          <Grid item md={2} sm={1} xs={1}>
            <OPRInputControl
              error={errors?.zipFileName}
              isEditable={false}
              label="ZIP File Name"
              name="zipFileName"
              value={values?.zipFileName}
              onChange={(e:any) => {
                handleOnChange('zipFileName', e.target?.value)
              }}
            />
          </Grid>
        </OPRResponsiveGrid>
      </div>
    </div>
  )
}

export default ExportCriteria
