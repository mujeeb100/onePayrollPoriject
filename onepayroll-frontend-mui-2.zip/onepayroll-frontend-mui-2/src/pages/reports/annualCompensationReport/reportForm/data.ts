export const reportData = [
  {
    reportType: 'OSRO Contribution Listing',
    entityId: '3fa85f64-5717-4562-b3fc-2c963f66afa6',
    reportDesignId: 'b57a6feb-285d-44c5-b705-351e7e3e7fb7',
    payslipPayrollDto: {
      receivePayslipMethods: [
        'string',
      ],
      sortingOption: 'string',
      payDate: '2024-04-11T12:07:10.751Z',
      dateToTrustee: '2024-04-11T12:07:10.751Z',
      relevantIncomeIndicator: 'string',
      exportOptions: 0,
      userFilePassword: 'string',
      pensionFundSchemes: [
        'string',
      ],
      exchangeRate: 0.0,
    },
    payrollComparisionDto: {
      includeZeroDifference: true,
      groupingOption: 0,
    },
    zipOptionsDto: {
      exportToSingleZipFile: true,
      zipFileName: 'string',
      zipPassword: 'string',
    },
    exportOptionsDto: {
      paperSize: 0,
      paperOrientation: 0,
      exportFileFormat: 0,
      exportFileName: 'string',
      fileNameToBeAppended: 'string',
      customFileNameToBeAppended: 'string',
    },
    mpfRemittanceStatement: {
      includeAllActivemployees: 'string',
      schemeType: 'string',
      pensionFundScheme: [
        'string',
      ],
    },
    currentPayCycle: {
      year: 'string',
      month: 'string',
      codes: [
        'string',
      ],
    },
    previousPayCycle: {
      year: 'string',
      month: 'string',
      codes: [
        'string',
      ],
    },
    employees: [
      'string',
    ],
    excludeEmployees: [
      'string',
    ],
    departments: [
      'string',
    ],
    costCenters: [
      'string',
    ],
  },
  {
    reportType: 'EAO Wages Report',
    entityId: '3fa85f64-5717-4562-b3fc-2c963f66afa6',
    reportDesignId: '880b0875-b3e9-40da-96e1-347d8873e855',
    payslipPayrollDto: {
      receivePayslipMethods: [
        'string',
      ],
      sortingOption: 'string',
      payDate: '2024-04-11T12:07:10.751Z',
      dateToTrustee: '2024-04-11T12:07:10.751Z',
      relevantIncomeIndicator: 'string',
      exportOptions: 0,
      userFilePassword: 'string',
      pensionFundSchemes: [
        'string',
      ],
      exchangeRate: 0.0,
    },
    payrollComparisionDto: {
      includeZeroDifference: true,
      groupingOption: 0,
    },
    zipOptionsDto: {
      exportToSingleZipFile: true,
      zipFileName: 'string',
      zipPassword: 'string',
    },
    exportOptionsDto: {
      paperSize: 0,
      paperOrientation: 0,
      exportFileFormat: 0,
      exportFileName: 'string',
      fileNameToBeAppended: 'string',
      customFileNameToBeAppended: 'string',
    },
    mpfRemittanceStatement: {
      includeAllActivemployees: 'string',
      schemeType: 'string',
      pensionFundScheme: [
        'string',
      ],
    },
    currentPayCycle: {
      year: 'string',
      month: 'string',
      codes: [
        'string',
      ],
    },
    previousPayCycle: {
      year: 'string',
      month: 'string',
      codes: [
        'string',
      ],
    },
    employees: [
      'string',
    ],
    excludeEmployees: [
      'string',
    ],
    departments: [
      'string',
    ],
    costCenters: [
      'string',
    ],
  },
]

export const exportFileFormate = [{ name: 'Excel Formatted', value: 1 }, { name: 'Excel Raw Data', value: 2 }, { name: 'PDF', value: 0 }]
export const paperSize = [{ name: 'Default', value: 0 }, { name: 'A3', value: 1 }, { name: 'A4', value: 0 }]
export const paperOrientation = [{ name: 'Default', value: 0 }, { name: 'Landscape', value: 1 }, { name: 'Portait', value: 0 }]
export const exportToSingleFile = [{ name: 'Yes', value: true }, { name: 'No', value: false }]
export const reportACRData:any = (rowData:any, employee:any) => {
  const data = {
    reportRequirements: [
      {
        reportDesignId: rowData.reportDesignId,
        reportType: 'Annual Compensation Report',
        exportOptionsDto: {
          paperSize: rowData.paperSize,
          paperOrientation: rowData.paperOrientation,
          exportFileFormat: rowData.exportFileFormat,
        },
        annualCompensationReportDto:
        {
          consolidateOption: rowData.consolidateOption,
          showIRDCodeOption: rowData.showIRDCodeOption,
          includeEmployeeGroupOption: rowData.includeEmployeeGroupOption,
          includePaymentHistoryOption: rowData.includePaymentHistoryOption,
        },
        currentPayCycle: {
          year: rowData.year,
          month: rowData.month,
          codes: rowData.codes,
        },
        employees: rowData.employees,
        departments: rowData.departmentCodes,
        costCenters: rowData.costCenterCodes,
        payItems: rowData.payItems,
        zipOptionsDto: {
          exportToSingleZipFile: rowData?.exportToSingleZipFile,
          zipFileName: rowData.zipFileName,
          zipPassword: rowData.zipPassword,
        },
      },

    ],
  }

  return data
}
