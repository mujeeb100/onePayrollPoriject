import React from 'react'

function GenerateReport({ name, id, bio = 'Bio empty' }:any) {
  return (
    <div style={{ gap: 20, display: 'flex', flexDirection: 'column' }}>
      <div style={{
        width: '100%', color: '#3B3839', fontSize: 16, fontFamily: 'Lato', fontWeight: '400', wordWrap: 'break-word',
      }}
      >
        Start by selecting at least 1 report
      </div>
      <div style={{
        width: '100%', height: '100%', justifyContent: 'flex-start', alignItems: 'flex-start', gap: 8, display: 'inline-flex',
      }}
      >
        <div style={{
          paddingTop: 1, paddingBottom: 1, justifyContent: 'flex-start', alignItems: 'center', display: 'flex',
        }}
        >
          <input
            // checked={selectedCodes.includes(employee.code)}
            type="checkbox"
            // value={employee.code}
            // onChange={(event) => handleCheckboxChange(event, employee.code)}
          />
        </div>
        <div style={{
          flex: '1 1 0', flexDirection: 'column', justifyContent: 'flex-start', alignItems: 'flex-start', gap: 4, display: 'inline-flex',
        }}
        >
          <div style={{
            alignSelf: 'stretch', justifyContent: 'flex-start', alignItems: 'flex-start', gap: 8, display: 'inline-flex',
          }}
          >
            <div style={{
              flex: '1 1 0', color: '#3B3839', fontSize: 14, fontFamily: 'Lato', fontWeight: '700', wordWrap: 'break-word',
            }}
            >
              Save as template
            </div>
          </div>
          <div style={{
            alignSelf: 'stretch', justifyContent: 'flex-start', alignItems: 'center', gap: 8, display: 'inline-flex',
          }}
          >
            <div style={{
              flex: '1 1 0', color: '#666364', fontSize: 14, fontFamily: 'Lato', fontWeight: '400', wordWrap: 'break-word',
            }}
            >
              Save this report as a template group for future reuse.
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

export default GenerateReport
