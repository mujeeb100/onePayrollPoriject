import { Grid } from '@mui/material'
import OPRMultiSelect from 'components/atoms/multiSelectCheckbox/OPRMultiSelectCheckbox'
import OPRResponsiveGrid from 'components/molecules/OPRResponsiveGrid'
import OPRSelectorControl from 'components/molecules/OPRSelectorControl/OPRSelectorControl'
import React from 'react'

const consolitationList:any = [{ name: 'Consolidate by Employee', value: 'Consolidate by Employee' }, { name: 'Consolidate by Entity', value: 'Consolidate by Entity' }]
const employeesList:any = [{ name: 'Active Staff Only', value: 'Active Staff Only' }, { name: 'Terminated Staff', value: 'Terminated Staff' }, { name: 'IRD Staff', value: 'IRD Staff' }, { name: 'Non-IRD Staff', value: 'Non-IRD Staff' }]
function ReportOption({ values, handleOnChange, errors }:any) {
  function findNamesByIds(array:any, ids:any) {
    return array?.filter((obj:any) => ids?.includes(obj?.value))
      .map((obj:any) => obj?.name)
  }
  console.log(findNamesByIds(consolitationList, values?.consolidateOption), 'vvvvvvvvvv', values?.consolidateOption)

  return (
    <div style={{
      display: 'flex', flexDirection: 'column', gap: 5, width: '100%',
    }}
    >
      <div style={{
        width: '100%', color: '#3B3839', fontSize: 16, fontFamily: 'Lato', fontWeight: '400', wordWrap: 'break-word',
      }}
      >
        All fields are mandatory except those marked optional.
      </div>
      <OPRResponsiveGrid>
        {/* <Grid item md={2} sm={1} xs={1}>
          <OPRSelectorControl
            isRequired
            error={errors?.consolidateOption}
            keyName="name"
            label="Consolidate option"
            multiple={false}
            name="name"
            options={[{ name: 'Consolidate by Employee', value: 0 }, { name: 'Consolidate by Entity', value: 1 }]}
            value={[{ name: 'Consolidate by Employee', value: 0 }, { name: 'Consolidate by Entity', value: 1 }].find((o:any) => o?.value === values?.consolidateOption)}
            valueKey="value"
            onChange={(text:any) => {
              handleOnChange('consolidateOption', text?.value)
            }}
          />
        </Grid> */}
        <Grid item md={2} sm={1} xs={1}>
          <OPRMultiSelect
            error={errors?.consolidateOption}
            label="Consolidate option"
            name="consolidateOption"
            options={consolitationList}
            placeholder="Select an option"
            value={values?.consolidateOption || []} // Ensure value is initialized as an array
            onChange={(consolidateOption:any) => {
              handleOnChange('consolidateOption', consolidateOption)
              // setFilterCriteria({
              //   ...filterCriteria,
              //   payCycleCode: selectedFormat,
              // })
            }}
          />
        </Grid>
        <Grid item md={2} sm={1} xs={1}>
          <OPRSelectorControl
            isRequired
            error={errors?.orderBy}
            // isEditable={isEditable}
            keyName="name"
            label="Order by"
            multiple={false}
            name="name"
            options={[{ name: 'Department, Employee Name', value: 0 }, { name: 'Department, Employee Code', value: 1 }, { name: 'Employee Code', value: 2 }, { name: 'Employee Name', value: 3 }]}
            value={[{ name: 'Department, Employee Name', value: 0 }, { name: 'Department, Employee Code', value: 1 }, { name: 'Employee Code', value: 2 }, { name: 'Employee Name', value: 3 }].find((o:any) => o?.value === values?.orderBy)}
            valueKey="value"
            onChange={(text:any) => {
              handleOnChange('orderBy', text?.value)
            }}
          />
        </Grid>
        <Grid item md={2} sm={1} xs={1}>
          <OPRSelectorControl
            isRequired
            error={errors?.showIRDCodeOption}
            // isEditable={isEditable}
            keyName="name"
            label="Show IRD code"
            multiple={false}
            name="name"
            options={[{ name: 'Based on IR56B', value: 0 }, { name: 'Based on IR56F', value: 1 }, { name: 'Based on IR56G', value: 2 }, { name: 'Do not show', value: 3 }]}
            value={[{ name: 'Based on IR56B', value: 0 }, { name: 'Based on IR56F', value: 1 }, { name: 'Based on IR56G', value: 2 }, { name: 'Do not show', value: 3 }].find((o:any) => o?.value === values?.showIRDCodeOption)}
            valueKey="value"
            onChange={(text:any) => {
              handleOnChange('showIRDCodeOption', text?.value)
            }}
          />
        </Grid>
        {/* <Grid item md={2} sm={1} xs={1}>
          <OPRSelectorControl
            isRequired
            error={errors?.includeEmployeeGroupOption}
            // isEditable={isEditable}
            keyName="name"
            label="Include employee group"
            multiple={false}
            name="name"
            options={[{ name: 'Active Staff Only', value: 0 }, { name: 'Terminated Staff', value: 1 }, { name: 'IRD Staff', value: 2 }, { name: 'Non-IRD Staff', value: 3 }]}
            value={[{ name: 'Active Staff Only', value: 0 }, { name: 'Terminated Staff', value: 1 }, { name: 'IRD Staff', value: 2 }, { name: 'Non-IRD Staff', value: 3 }].find((o:any) => o?.value === values.includeEmployeeGroupOption)}
            valueKey="value"
            onChange={(text:any) => {
              handleOnChange('includeEmployeeGroupOption', text?.value)
            }}
          />
        </Grid> */}
        <Grid item md={2} sm={1} xs={1}>
          <OPRMultiSelect
            error={errors?.includeEmployeeGroupOption}
            label="Include employee group"
            name="includeEmployeeGroupOption"
            options={employeesList}
            placeholder="Select an option"
            value={values?.includeEmployeeGroupOption || []} // Ensure value is initialized as an array
            onChange={(includeEmployeeGroupOption:any) => {
              handleOnChange('includeEmployeeGroupOption', includeEmployeeGroupOption)
              // setFilterCriteria({
              //   ...filterCriteria,
              //   payCycleCode: selectedFormat,
              // })
            }}
          />
        </Grid>
        <Grid item md={2} sm={1} xs={1}>
          <OPRSelectorControl
            isRequired
            error={errors?.includePaymentHistoryOption}
            // isEditable={isEditable}
            keyName="name"
            label="Include payment history before commencement date"
            multiple={false}
            name="name"
            options={[{ name: 'No', value: 0 }, { name: 'Yes, include only from same entity', value: 1 }, { name: 'Yes, include only from same and other entities', value: 2 }]}
            value={[{ name: 'No', value: 0 }, { name: 'Yes, include only from same entity', value: 1 }, { name: 'Yes, include only from same and other entities', value: 2 }].find((o:any) => o?.value === values?.includePaymentHistoryOption)}
            valueKey="value"
            onChange={(text:any) => {
              handleOnChange('includePaymentHistoryOption', text?.value)
            }}
          />
        </Grid>

      </OPRResponsiveGrid>

    </div>
  )
}

export default ReportOption
