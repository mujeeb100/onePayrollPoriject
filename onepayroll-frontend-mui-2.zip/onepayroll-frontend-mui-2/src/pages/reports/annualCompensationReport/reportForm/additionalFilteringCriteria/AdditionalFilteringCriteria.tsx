import { Box, Grid } from '@mui/material'
import { useGetAllCostCenterQuery, useGetAllDepartmentQuery } from 'api/entityServices'
import { useGetAllPayGroupDropDownQuery, useGetAllPayItemMasterQuery, useGetAllPayRollNonRecurringDropDownQuery } from 'api/payRollServices'
import { EmpIcon, MenuKebab } from 'assets/svg-images/SvgComponents'
import OPRButton from 'components/atoms/button/OPRButton'
import OPRLabel from 'components/atoms/label/OPRLabel'
import { CustomDialog } from 'components/atoms/modal/OPRModal'
import OPRMultiSelect from 'components/atoms/multiSelectCheckbox/OPRMultiSelectCheckbox'
import OPRResponsiveGrid from 'components/molecules/OPRResponsiveGrid'
import OPRSelectorControl from 'components/molecules/OPRSelectorControl/OPRSelectorControl'
import { defaultPageSize } from 'constants/index'
import CustomCheckbox from 'pages/payroll/runPayroll/EmployeeCheckbox'
import React, { useState } from 'react'
import { generateFilterUrl } from 'utils'

function AdditionalFilteringCriteria({
  employees, errors, handleChange, handleCheckboxChange, handleOnChange, handleRemoveEmployee,
  handleSelectAllChange, selectAll, selectedCodes, values,
}:any) {
  const [selectedEmployeeCodes, setSelectedEmployeeCodes] = useState<string[]>([])
  const [isEmployeeModalOpen, setIsEmployeeModalOpen] = useState(false)
  const handleEmployeeSelection = (selectedCodes: string[]) => {
    setSelectedEmployeeCodes(selectedCodes)
  }

  const {
    data: PayCycleCodeData,

  } = useGetAllPayGroupDropDownQuery(generateFilterUrl(defaultPageSize))

  const {
    data: allDepartment,
  } = useGetAllDepartmentQuery(generateFilterUrl(defaultPageSize))
  const {
    data: allPosts,
    error: createAllPostsBankAccountError,
    isLoading: isLoadingAllPosts,
    isSuccess: isSuccessAllPosts,
    isError: isErrorAllPosts,
    error: errorAllPosts,
  } = useGetAllPayItemMasterQuery(generateFilterUrl(defaultPageSize))

  const {
    data: payCycleMonthDropdown,
  } = useGetAllPayRollNonRecurringDropDownQuery(generateFilterUrl(defaultPageSize))

  const {
    data: allCostCenter,
  } = useGetAllCostCenterQuery(generateFilterUrl(defaultPageSize))
  const handleContinue = () => {
    // Handle continue button click, e.g., save data or perform any action
    handleEmployeeModalClose()
  }

  const payItemList = allPosts?.records?.map((item:any) => {
    const data = {
      ...item,
      name: `${item.payItemCode} - ${item.payItemName}`,
      value: item.payItemCode,
    }
    return data
  })
  // Function to handle closing the employee modal
  const handleEmployeeModalClose = () => {
    setIsEmployeeModalOpen(false)
  }

  const allDepartmentList = (allDepartment?.records || []).map((item:any) => ({
    name: `${item?.departmentCode} - ${item?.departmentDescription}`,
    value: item?.departmentCode,
  }))

  const allCostCenterDataList = (allCostCenter?.records || []).map((item:any) => ({
    name: `${item?.costCenterCode} - ${item?.costCenterDescription}`,
    value: item?.costCenterCode,
  }))

  const selectedEmployees = selectedCodes?.map((code:any) => {
    const employee = employees?.find((emp:any) => emp.employeeCode === code)
    if (employee) {
      return (
        <Box
          key={code}
          style={{
            display: 'flex', alignItems: 'center', justifyContent: 'space-between', margin: '5px 20px',
          }}
        >
          <Box>
            <OPRLabel label={`${employee?.employeeProfile?.givenName} ${employee?.employeeProfile?.surname}`} variant="subtitle2" />

            <OPRLabel label={employee.employeeCode} variant="body2" />
          </Box>

          <Box>
            <OPRButton variant="text" onClick={() => handleRemoveEmployee(code)}><MenuKebab /></OPRButton>
          </Box>
        </Box>
      )
    }

    return null
  })

  // Function to handle opening the employee modal
  const handleEmployeeModalOpen = () => {
    setIsEmployeeModalOpen(true)
  }
  return (
    <div style={{ gap: 20, display: 'flex', flexDirection: 'column' }}>
      <div style={{
        width: '100%', color: '#3B3839', fontSize: 16, fontFamily: 'Lato', fontWeight: '400', wordWrap: 'break-word',
      }}
      >
        Select specific group of employees to generate report.
      </div>

      <div>
        <OPRResponsiveGrid>
          <Grid item md={2} sm={1} xs={1}>
            <OPRMultiSelect
              error={errors?.departmentCodes}
              label="Department"
              name="departmentCode"
              optionalText="Optional"
              options={allDepartmentList || []}
              placeholder="Select an option"
              value={values?.departmentCodes || []} // Ensure value is initialized as an array
              onChange={(selectedFormat) => {
                console.log(selectedFormat, 'selectedFormatselectedFormat', allDepartmentList)

                handleOnChange('departmentCodes', selectedFormat)
                // setFilterCriteria({
                //   ...filterCriteria,
                //   payCycleCode: selectedFormat,
                // })
              }}
            />
          </Grid>
          {/* <Grid item md={2} sm={1} xs={1}>
            <OPRSelectorControl
              error={errors?.departmentCode}
              keyName="departmentCode"
              label="Department"
              multiple={false}
              name="departmentCode"
              optionalText="Optional"
              options={(allDepartment?.records || [])}
              placeholder="Select an option"
              value={(allDepartment?.records || [])?.find((o:any) => o?.departmentCode === values?.departmentCodes) || {}}
              valueKey="departmentCode"
              onChange={(text:any) => {
                handleOnChange('departmentCodes', text?.departmentCode)
              }}
            />
          </Grid> */}
          <Grid item md={2} sm={1} xs={1}>
            <OPRMultiSelect
              error={errors?.costCenterCode}
              label="Cost Center"
              name="name"
              optionalText="Optional"
              options={allCostCenterDataList || []}
              placeholder="Select an option"
              value={values?.costCenterCodes || []} // Ensure value is initialized as an array
              onChange={(selectedFormat) => {
                handleOnChange('costCenterCodes', selectedFormat)
                // setFilterCriteria({
                //   ...filterCriteria,
                //   payCycleCode: selectedFormat,
                // })
              }}
            />
          </Grid>
          {/* <Grid item md={2} sm={1} xs={1}>
            <OPRSelectorControl
              error={errors?.costCenterCode}
              keyName="costCenterCode"
              label="Cost Center"
              multiple={false}
              name="costCenterCode"
              optionalText="Optional"
              options={(allCostCenter?.records || [])}
              placeholder="Select an option"
              value={(allCostCenter?.records || [])?.find((o:any) => o?.costCenterCode === values?.costCenterCodes) || {}}
              valueKey="costCenterCode"
              onChange={(text:any) => {
                handleOnChange('costCenterCodes', text?.costCenterCode)
              }}
            />
          </Grid> */}
          <Grid item md={2} sm={1} xs={1}>
            <OPRMultiSelect
              error={errors?.payItems}
              label="Pay item"
              name="payItem"
              optionalText="Optional"
              options={payItemList || []}
              placeholder="Select an option"
              value={values?.payItems || []} // Ensure value is initialized as an array
              onChange={(selectedFormat) => {
                handleOnChange('payItems', selectedFormat)
                // setFilterCriteria({
                //   ...filterCriteria,
                //   payCycleCode: selectedFormat,
                // })
              }}
            />
          </Grid>
          {/* <Grid item md={2} sm={1} xs={1}>
            <OPRSelectorControl
              isRequired
              // error={errors?.yearOfServiceOption}
              // isEditable={isEditable}
              keyName="name"
              label="Pay item"
              multiple={false}
              name="name"
              optionalText="Optional"
              options={(payItemList || [])}
              value={payItemList?.find((o:any) => o?.payItemCode === values.payItems)}
              valueKey="payItemCode"
              onChange={(text:any) => {
                handleOnChange('payItems', text?.payItemCode)
              }}
            />
          </Grid> */}
          <div style={{ display: 'block', width: '100%', margin: '40px 20px 20px' }}>
            <OPRLabel variant="h3">Employee</OPRLabel>
            <OPRLabel variant="body2">If no employee is selected, the system will process payroll for all employees for the selected pay cycles.</OPRLabel>
            <Box sx={{ display: 'block', justifyContent: 'space-between', marginTop: '20px' }}>
              <Grid item md={2} sm={1} xs={1}>
                <OPRSelectorControl
                  error={errors.excludeEmployees}
                  keyName="name"
                  label="Include/Exclude"
                  multiple={false}
                  name="name"
                  options={[
                    { name: 'Include', value: 'Include' },
                    { name: 'Exclude', value: 'Exclude' },
                  ]}
                  placeholder="Select an option"
                  value={[
                    { name: 'Include', value: 'Include' },
                    { name: 'Exclude', value: 'Exclude' },
                  ].find((o:any) => o?.value === values.excludeEmployees)}
                  valueKey="value"
                  onChange={(text:any) => {
                    handleOnChange('excludeEmployees', text?.value)
                  }}
                />
              </Grid>

            </Box>
            {/* Check if selectedEmployees array has any selected employees */}
            {selectedEmployees?.length > 0 ? (
            // Render only if there are selected employees
              selectedEmployees
            ) : (
            // Render the buttons if no employees are selected

              <Box sx={{ display: 'block', justifyContent: 'space-between', marginTop: '80px' }}>
                <Box
                  className="pop-up"
                  sx={{
                    display: 'flex',

                    gap: '12px',
                    alignItems: 'center',
                    borderRadius: '4px',
                    alignSelf: 'stretch',
                    justifyContent: 'center',
                    marginTop: 1,
                  }}
                >
                  <EmpIcon />
                  <OPRLabel variant="body2">

                    No employee is selected

                  </OPRLabel>
                </Box>

                <OPRButton
                // disabled={}
                  sx={{ margin: '0px auto', display: 'flex' }}
                  variant="text"
                  onClick={handleEmployeeModalOpen}
                >
                  Select Employee
                </OPRButton>

                <Box sx={{ display: 'flex', justifyContent: 'space-between', marginTop: '50px' }}>
                  {/* <OPRButton
                  sx={{ marginLeft: '10px' }}
                  variant="outlined"
                  onClick={handleEmployeeModalClose} // Close the modal if cancel is clicked
                >
                  Cancel
                </OPRButton> */}
                  {/* Conditional rendering based on whether skip button should be shown */}
                  {/* {selectedCodes.length === 0 ? (
                // Render the skip button if no employees are selected
                  <OPRButton
                    variant="outlined"
                    onClick={handleContinue} // If skip is clicked, handle it as continue
                  >
                    Skip
                  </OPRButton>
                ) : null} */}
                </Box>
              </Box>
            )}
          </div>
          <CustomDialog
            isResume
            closeTitle="Cancel"
            handleClose={handleEmployeeModalClose}
            handleResume={handleContinue} // Pass handleContinue here
            isOpen={isEmployeeModalOpen}
            resumeTitle="Continue"
            title="Employee Selection"
            onSelection={handleEmployeeSelection}
          >
            <Box sx={{ }}>
              <Box>
                <div>
                  {/* Display selected employee codes */}
                  {selectedEmployeeCodes.length > 0 && (
                    <div>
                      <p>
                        Selected Employee Codes:
                        {selectedEmployeeCodes.join(', ')}

                      </p>
                    </div>
                  )}
                  {/* Pass handleEmployeeSelection as a prop to CustomCheckbox */}
                  <CustomCheckbox
                    employees={employees}
                    handleCheckboxChange={handleCheckboxChange}
                    handleRemoveEmployee={handleRemoveEmployee}
                    handleSelectAllChange={handleSelectAllChange}
                    selectAll={selectAll}
                    selectedCodes={selectedCodes}
                    onChange={handleEmployeeSelection}
                  />
                </div>
              </Box>
            </Box>
          </CustomDialog>
        </OPRResponsiveGrid>
      </div>
    </div>
  )
}

export default AdditionalFilteringCriteria
