export const dataTransformation = (rowData:any) => {
  const data = {
    reportRequirements: [
      {
        entityId: rowData.entityId,
        reportType: rowData.reportType,
        reportDesignId: rowData.reportDesignId,
        exportOptionsDto: {
          paperSize: rowData.paperSize,
          paperOrientation: rowData.paperOrientation,
          exportFileFormat: rowData.exportFileFormat,
        },
        annualCompensationReportDto:
                {
                  consolidateOption: rowData.consolidateOption,
                  showIRDCodeOption: rowData.showIRDCodeOption,
                  includeEmployeeGroupOption: rowData.includeEmployeeGroupOption,
                  includePaymentHistoryOption: rowData.includePaymentHistoryOption,
                },
        currentPayCycle: {
          year: rowData.year,
          month: rowData.month,
          codes: [rowData.codes],
        },
        employees: [rowData.employees],
      },
    ],
  }
  return data
}
