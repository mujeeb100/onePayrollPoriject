import { useTheme } from '@emotion/react'
import {
  Box,
  Button, ModalProps,
} from '@mui/material'
import { Info } from 'assets/svg-images/SvgComponents'
import OPRLabel from 'components/atoms/label/OPRLabel'
import { CustomDialog } from 'components/atoms/modal/OPRModal'
import React from 'react'
// import { useHistory } from 'react-router-dom'

interface ConfirmationModalProps extends Omit<ModalProps, 'children'> {
    open: boolean;
    onClose: () => void;
    // children: any; // Update children prop type
    children?: React.ReactNode;
}

function ConfirmationModal({ open, onClose, children }: ConfirmationModalProps) {
  const theme:any = useTheme()
  // const history = useHistory()

  const handleConfirmClick = () => {
    // Perform any additional actions here before going back
    window.history.back()
    onClose() // Close the modal
    // history.push('/reportdesigner/customreport') // Navigate back to the specified page
  }
  return (
    <Box>
      <CustomDialog isOpen={open} type="loader">
        {/* <Box sx={{
          width: '100%', maxWidth: 400, p: 4, borderRadius: 16,
        }}
        > */}
        <Box style={{ marginBottom: '15px' }}>
          <OPRLabel variant="h4">
            Confirm closing report designer
          </OPRLabel>
        </Box>

        <Box
          className="pop-up"
          sx={{
            display: 'flex',
            padding: '12px',
            gap: '12px',
            alignItems: 'flex-start',
            borderRadius: '4px',
            alignSelf: 'stretch',
            backgroundColor: `${theme.palette.Invite.main}`,
            marginTop: 1,
          }}
        >
          <Info />
          <OPRLabel
            CustomStyles={{
              backgroundColor: `${theme.palette.Invite.main}`,
            }}
            backgroundColor={theme.palette.Invite.main}
            variant="body2"
          >
            Please ensure that you save the report before closing. Any unsaved changes will be lost.
          </OPRLabel>
        </Box>
        <Box display="flex" justifyContent="space-between" mt={4}>
          {/* <Grid container spacing={2}> */}
          {/* <Grid item xs={6}> */}
          <Button color="primary" variant="text" onClick={onClose}>
            Cancel
          </Button>
          {/* </Grid> */}
          {/* <Grid item xs={6}> */}
          <Button color="primary" variant="text" onClick={handleConfirmClick}>
            Confirm
          </Button>
          {/* </Grid> */}
          {/* </Grid> */}
        </Box>

        {/* </Box> */}
      </CustomDialog>
    </Box>
  )
}

export default ConfirmationModal
