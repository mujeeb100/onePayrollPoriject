import '../../styles/style.css'

import {
  Box,
  ModalProps,
} from '@mui/material'
import OPRButton from 'components/atoms/button/OPRButton'
import OPRLabel from 'components/atoms/label/OPRLabel'
import { CustomDialog } from 'components/atoms/modal/OPRModal'
import React, { useState } from 'react'

import quickGuide from '../../assets/images/quichGuide.png'

interface ConfirmationModalProps extends Omit<ModalProps, 'children'> {
    open: boolean;
    onClose: () => void;
    handleNext: () => void; // Added handleNext prop
    children?: React.ReactNode;
    handleSkip: () => void; // Added handleSkip prop
}

function IframeQuickGuideReport2({
  open, onClose, handleNext, handleSkip,
}: ConfirmationModalProps) {
  const [isNextModalOpen, setIsNextModalOpen] = useState(false)

  return (
    <>

      <Box style={{ }}>

        <CustomDialog className="custom-report-change" isOpen={open} type="loader">
          <Box className="custom-dialog-content">
            <Box className="image-container">
              <img
                alt="Logo"
                className="custom-image"
                src={quickGuide}
              />
            </Box>

            <Box className="text-container">
              <Box className="text-data">

                <OPRLabel CustomStyles={{ marginBottom: '10px' }} variant="h4">Report designer</OPRLabel>
                <OPRLabel CustomStyles={{ marginBottom: '10px' }} variant="subtitle1">How to use report template</OPRLabel>
                <OPRLabel variant="body2">To utilize the existing report template, follow these steps:</OPRLabel>
                <ul className="ul-data">
                  <li>
                    Select the
                    <b>File</b>
                    {' '}
                    tab located on the top left next to
                    {' '}
                    <b>Home.</b>
                  </li>
                  <li>
                    Search for the desired report template and click on
                    <b>Open Report.</b>
                  </li>
                </ul>
              </Box>
              <Box className="button-container">
                <OPRButton
                  color="primary"
                  variant="text"
                  onClick={handleSkip}

                >
                  Skip
                </OPRButton>
                <OPRButton
                  color="primary"
                  variant="contained"
                  onClick={handleNext}
                >
                  Next
                </OPRButton>
              </Box>
            </Box>
          </Box>
        </CustomDialog>
      </Box>
      {/* // the next modal */}
      {/* <ReportDesignerNext /> */}

    </>
  )
}

export default IframeQuickGuideReport2
