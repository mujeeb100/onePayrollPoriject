import {
  AppBar, Button,
  IconButton, Toolbar, Typography,
} from '@mui/material'
import { useState } from 'react'
import { getSelectedEntity } from 'utils'

import IframeQuickGuideReport from './IframeQuickGuideReport'
import IframeQuickGuideReport2 from './IframeQuickGuideReport2'
import IframeReportAlert from './IframeReportAlert'

function Iframe() {
  const [isConfirmationModalOpen, setConfirmationModalOpen]:any = useState(false)
  const [isquickModalOpen, setQuickModalOpen]:any = useState(false)
  const [isNextModalOpen, setIsNextModalOpen]:any = useState(false)
  const selectedEntity = getSelectedEntity()

  const handleConfirmationModalOpen = () => {
    setConfirmationModalOpen(true)
  }

  const handleConfirmationModalClose = () => {
    setConfirmationModalOpen(false)
  }

  const handleQuickModalOpen = () => {
    setQuickModalOpen(true)
  }

  const handleQuickModalClose = () => {
    setQuickModalOpen(false)
  }

  const handleNextModalOpen = () => {
    setIsNextModalOpen(true)
    setQuickModalOpen(false) // Close the first modal when opening the second
  }

  const handleNextModalClose = () => {
    setIsNextModalOpen(false)
  }

  const handleBackModalOpen = () => {
    setIsNextModalOpen(false)
    setQuickModalOpen(true) // Reopen the first modal when going back
  }

  const handleSkip = () => {
    setQuickModalOpen(false)
    setIsNextModalOpen(false)
  }
  const baseUrl = process.env.REACT_APP_REPORTING_DESIGNER_BASE_URL

  return (
    <>
      <IframeReportAlert
        open={isConfirmationModalOpen}
        onClose={handleConfirmationModalClose}
      />
      {/* report designer quick guide model start */}
      <IframeQuickGuideReport2
        handleNext={handleNextModalOpen} // Pass the handleNext function
        handleSkip={handleSkip} // Pass the handleSkip function
        open={isquickModalOpen && !isNextModalOpen}
        onClose={handleQuickModalClose}
      />

      <IframeQuickGuideReport
        handleBack={handleBackModalOpen}
        handleSkip={handleSkip} // Pass the handleSkip function
        open={isNextModalOpen}
        onClose={handleNextModalClose}
      />
      {/* <button onClick={() => setIsNextModalOpen(true)}>Open Next Modal</button> */}
      {/* report designer quick guide model end */}

      <AppBar color="default" position="static">
        <Toolbar>
          <Typography component="div" sx={{ flexGrow: 1 }} variant="h6">
            Designer
          </Typography>
          <IconButton
            aria-label="menu"
            color="inherit"
            edge="start"
            size="large"
            sx={{ mr: 2 }}

          >
            <Button
              component="div"
              sx={{
                color: '#0049DB',
                borderRadius: '110px',
                fontWeight: '700',
                fontSize: '14px',
                border: '1px solid #0049DB',
              }}
              onClick={handleQuickModalOpen}
            >
              Quick guide
            </Button>
          </IconButton>
          <IconButton
            aria-label="menu"
            color="inherit"
            edge="start"
            size="large"
            sx={{ mr: 2 }}

          >
            <Typography
              component="div"
              sx={{
                color: 'white',
                fontWeight: '700',
                backgroundColor: '#0049DB',
                fontSize: '14px',
                borderRadius: '110px',
                padding: '4px 12px',
              }}
              variant="subtitle1"
              onClick={handleConfirmationModalOpen}
            >
              Close
            </Typography>
          </IconButton>
        </Toolbar>
      </AppBar>
      <div>
        <iframe
          frameBorder="0"
          height="1000px"
          // src={`https://dev.onepayroll.net/reporting-designer/${selectedEntity?.id}`}
          src={`${baseUrl}/${selectedEntity?.id}`}
          title="Web Designer Active Report"
          width="100%"
        />
      </div>
    </>

  )
}

export default Iframe
