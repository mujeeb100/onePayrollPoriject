declare module 'debounce';
declare module '*.png';
declare module '*.svg';
declare module '@okta/okta-react';
